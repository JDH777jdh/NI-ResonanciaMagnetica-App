# AXON Motor DICOM — Export completo (27-oct-2026)

Un solo ZIP con todo lo del motor DICOM que existe en este chat y en el Proyecto. Para retomar el trabajo: `AXON_TRASPASO_SESION_NUEVA_2026-10-27.md`.

| Carpeta | Contenido |
|---|---|
| `1_motor_dicom_para_correr/` | El motor completo y verificado (motor 92/92 + frontend 5/5): `src/`, `test/` con fixtures reales, `frontend/`, `package.json`, `README.md` actualizado. Sin `node_modules`. |
| `2_documentacion/` | Todos los documentos del Proyecto, con el dossier actualizado (§1–18) y el traspaso. |
| `3_scripts_validacion/` | `rebuild_tree.sh` (arma el árbol dentro del entorno del Proyecto de Claude), `obtener_fixtures_externos.py` y los scripts de validación cruzada con pydicom. |
| `4_para_subir_al_proyecto/` | Los archivos nuevos o reemplazados, con los nombres planos del Proyecto (lista y acciones en el dossier §18.7). |
| `5_snapshot_proyecto_original/` | Copia fiel del Proyecto tal como estaba antes de este export. Contiene dos binarios dañados conocidos (`CT_small.dcm` y `consentimiento_prueba.pdf`): los buenos están en `1_…/test/fixtures/`. |
| `6_extras_fuera_de_alcance/` | Verificaciones de los identificadores de MAIN que se empezaron; no son parte del motor. |

## Correr el motor
```bash
cd 1_motor_dicom_para_correr
npm install && npm test                              # 10 archivos, 92 checks
cd frontend && npm install && npx vitest run         # 5 tests
```
Requiere Node ≥ 22.13 (lo pide `dcmjs`).

## Qué NO incluye
- El archivo de identificadores de MAIN (`MasterIdentifierService`): lo administra MAIN y solo se consume.
- `node_modules` (se regenera con `npm install`).
