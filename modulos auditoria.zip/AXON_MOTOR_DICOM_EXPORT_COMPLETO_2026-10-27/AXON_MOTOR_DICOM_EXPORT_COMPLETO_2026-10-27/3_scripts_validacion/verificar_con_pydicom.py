# Decoder RLE INDEPENDIENTE (pydicom) leyendo lo que produjo MI encoder; compara contra los píxeles originales.
import json, sys, glob, os
import numpy as np, pydicom
ok = True
for dcm in sorted(glob.glob('/tmp/rle_out/*.dcm')):
    base = dcm[:-4]; meta = json.load(open(base + '.json')); raw = open(base + '.raw', 'rb').read()
    try:
        ds = pydicom.dcmread(dcm); arr = ds.pixel_array
        dt = np.dtype('<i2' if meta['signed'] else '<u2') if meta['bits'] == 16 else np.dtype('u1')
        esperado = np.frombuffer(raw, dtype=dt).reshape(meta['rows'], meta['cols'])
        igual = bool(np.array_equal(arr, esperado)) and arr.shape == esperado.shape
        print(f"{os.path.basename(base)}: TS={ds.file_meta.TransferSyntaxUID} {arr.shape} {arr.dtype} -> {'✅ idéntico a lo que codificó mi encoder' if igual else '❌ DIFERENTE'}")
    except Exception as e:
        igual = False; print(f"{os.path.basename(base)}: ❌ pydicom no pudo decodificar: {type(e).__name__}: {e}")
    ok = ok and igual
print('RESULTADO:', 'TODO IDÉNTICO' if ok else 'HAY DIFERENCIAS'); sys.exit(0 if ok else 1)
