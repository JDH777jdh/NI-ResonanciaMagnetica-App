// Genera con MI encoder (RleCodec.comprimirFrame) archivos DICOM RLE completos para que un decoder AJENO (pydicom) los lea.
const fs = require('fs');
const W = '/home/claude/rle-work/src';
const Explicit = require(W + '/pdu/ExplicitVrCodec');
const Rle = require(W + '/pdu/RleCodec');
const { buildStoredFile } = require(W + '/server/CStoreDataset');
const RLE_UID = '1.2.840.10008.1.2.5';
function lcg(seed) { let s = seed >>> 0; return () => { s = (Math.imul(s, 1664525) + 1013904223) >>> 0; return s >>> 24; }; }
function construir(nombre, rows, cols, bits, signed, gen) {
  const bps = bits / 8, pix = Buffer.alloc(rows * cols * bps);
  for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) {
    const v = gen(r, c, rows, cols), off = (r * cols + c) * bps;
    if (bits === 8) pix.writeUInt8(v & 0xff, off); else if (signed) pix.writeInt16LE(v, off); else pix.writeUInt16LE(v & 0xffff, off);
  }
  const frame = Rle.comprimirFrame(pix, bits, cols);
  const uid = (n) => `1.2.826.0.1.3680043.99999.${n}.${rows}.${cols}.${bits}`;
  const ds = Explicit.encodeDataset([
    { tag: '00080016', vr: 'UI', value: '1.2.840.10008.5.1.4.1.1.7' }, { tag: '00080018', vr: 'UI', value: uid(1) },
    { tag: '00080060', vr: 'CS', value: 'OT' }, { tag: '00100010', vr: 'PN', value: 'RLE^PRUEBA' }, { tag: '00100020', vr: 'LO', value: 'RLE-0001' },
    { tag: '0020000D', vr: 'UI', value: uid(2) }, { tag: '0020000E', vr: 'UI', value: uid(3) },
    { tag: '00280002', vr: 'US', value: 1 }, { tag: '00280004', vr: 'CS', value: 'MONOCHROME2' },
    { tag: '00280010', vr: 'US', value: rows }, { tag: '00280011', vr: 'US', value: cols },
    { tag: '00280100', vr: 'US', value: bits }, { tag: '00280101', vr: 'US', value: bits }, { tag: '00280102', vr: 'US', value: bits - 1 },
    { tag: '00280103', vr: 'US', value: signed ? 1 : 0 },
    { tag: '7fe00010', vr: 'OB', value: { encapsulado: true, fragmentos: [frame] } },
  ]);
  fs.writeFileSync(`/tmp/rle_out/${nombre}.dcm`, buildStoredFile({ sopClassUID: '1.2.840.10008.5.1.4.1.1.7', sopInstanceUID: uid(1), transferSyntaxUID: RLE_UID, implementationClassUID: '1.2.840.99999.1.1', datasetBuf: ds }));
  fs.writeFileSync(`/tmp/rle_out/${nombre}.raw`, pix);
  fs.writeFileSync(`/tmp/rle_out/${nombre}.json`, JSON.stringify({ rows, cols, bits, signed }));
  console.log(`${nombre}: ${rows}x${cols} ${bits}bit${signed ? ' con signo' : ''} — crudo ${pix.length} B -> fragmento RLE ${frame.length} B`);
}
const rnd = lcg(12345);
construir('A_16bit_sin_signo_32x32', 32, 32, 16, false, (r, c, R) => r < R / 4 ? 1000 : r < R / 2 ? (c * 257) & 0xffff : r < (3 * R) / 4 ? (c % 2 ? 0xff00 : 0x00ff) : [0, 65535, 0x1234, 32768][c % 4]);
construir('B_16bit_con_signo_33x20', 20, 33, 16, true, (r, c) => (r % 3 === 0 ? -32768 : r % 3 === 1 ? ((c * 997) % 65536) - 32768 : -1));
construir('C_8bit_dimensiones_impares_17x31', 17, 31, 8, false, (r, c) => (r < 4 ? 200 : r < 8 ? c * 8 : r < 12 ? (c % 2 ? 255 : 0) : (r * c) & 0xff));
construir('D_8bit_aleatorio_64x64', 64, 64, 8, false, () => rnd());
construir('E_16bit_constante_corridas_largas_3x300', 3, 300, 16, false, () => 4660);
construir('F_8bit_1x1', 1, 1, 8, false, () => 77);
