const fs = require('fs');
const Explicit = require('/home/claude/rle-work/src/pdu/ExplicitVrCodec');
const Rle = require('/home/claude/rle-work/src/pdu/RleCodec');

function leerPart10(ruta) {
  const buf = fs.readFileSync(ruta);
  if (buf.slice(128, 132).toString('ascii') !== 'DICM') throw new Error('sin DICM');
  const primero = Explicit.decodeElementAt(buf, 132);
  const finMeta = primero.nextOffset + primero.value;
  const meta = [];
  let o = primero.nextOffset;
  while (o < finMeta) { const el = Explicit.decodeElementAt(buf, o); meta.push(el); o = el.nextOffset; }
  const ts = meta.find((e) => e.tag === '00020010').value.replace(/\0+$/, '');
  const dataset = Explicit.decodeDataset(buf.slice(finMeta));
  return { ts, dataset };
}
const get = (ds, tag) => { const e = ds.find((x) => x.tag === tag); return e ? e.value : undefined; };

for (const f of ['MR_small_RLE.dcm', 'OBXXXX1A_rle.dcm', 'emri_small_RLE.dcm', 'SC_rgb_rle.dcm']) {
  console.log('\n=== ' + f + ' ===');
  try {
    const { ts, dataset } = leerPart10('/tmp/rle_real/' + f);
    console.log('Transfer Syntax:', ts);
    const rows = get(dataset, '00280010'), cols = get(dataset, '00280011'), bits = get(dataset, '00280100');
    const spp = get(dataset, '00280002'), fr = get(dataset, '00280008'), pi = get(dataset, '00280004'), pr = get(dataset, '00280103');
    console.log('Rows', rows, 'Cols', cols, 'BitsAllocated', bits, 'SamplesPerPixel', spp, 'NumberOfFrames', fr, 'Photometric', pi, 'PixelRepresentation', pr);
    const px = dataset.find((e) => e.tag === '7fe00010');
    console.log('Pixel Data: vr =', px.vr, '| encapsulado =', !!(px.value && px.value.encapsulado));
    if (px.value && px.value.encapsulado) {
      const { basicOffsetTable, fragmentos } = px.value;
      console.log('  BOT bytes:', basicOffsetTable.length, '| fragmentos:', fragmentos.length);
      fragmentos.slice(0, 3).forEach((fr_, i) => {
        const nseg = fr_.readUInt32LE(0);
        const offs = []; for (let k = 0; k < nseg; k++) offs.push(fr_.readUInt32LE(4 + 4 * k));
        const restoCero = fr_.slice(4 + 4 * nseg, 64).every((b) => b === 0);
        const lens = offs.map((of, k) => (k + 1 < nseg ? offs[k + 1] : fr_.length) - of);
        console.log(`  fragmento ${i}: ${fr_.length} bytes | segmentos=${nseg} | offsets=${JSON.stringify(offs)} | largos de segmento=${JSON.stringify(lens)} (pares: ${lens.map((l) => l % 2 === 0)}) | slots no usados en 0: ${restoCero}`);
      });
    }
  } catch (e) { console.log('❌', e.message); }
}
