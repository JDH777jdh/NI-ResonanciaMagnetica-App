#!/bin/bash
# Reconstruye el árbol de trabajo del motor DICOM a partir de:
#   - los archivos REALES del Proyecto (/mnt/project)
#   - mis piezas de RLE guardadas en outputs/rle-wip (pisan a las del Proyecto cuando existen ahí)
#   - los fixtures binarios decodificados desde los .txt Base64 del Proyecto
set -e
WORK=/home/claude/rle-work
WIP=/mnt/user-data/outputs/rle-wip
P=/mnt/project
rm -rf "$WORK"
mkdir -p "$WORK"/src/{pdu,server,storage,config,rendering,wrapping} "$WORK"/test/fixtures "$WORK"/frontend

pick() { # pick <archivo> <destino>: usa mi versión de outputs/rle-wip si existe, si no la del Proyecto
  if [ -f "$WIP/$1" ]; then cp "$WIP/$1" "$2"; else cp "$P/$1" "$2"; fi
}
for f in PDU.js DimseCommand.js ImplicitVrCodec.js ExplicitVrCodec.js VrLimits.js TransferSyntaxRegistry.js RleCodec.js EncapsulatedPixelData.js; do pick $f "$WORK/src/pdu/$f"; done
pick AeRegistry.js "$WORK/src/config/AeRegistry.js"
for f in AssociationServer.js CStoreDataset.js DicomWebServer.js WorklistApiServer.js; do pick $f "$WORK/src/server/$f"; done
for f in StudyIndex.js WorklistStore.js; do pick $f "$WORK/src/storage/$f"; done
for f in PngEncoder.js RenderInstance.js; do pick $f "$WORK/src/rendering/$f"; done
pick EncapsulatedDocument.js "$WORK/src/wrapping/EncapsulatedDocument.js"
pick WorklistClient.js "$WORK/frontend/WorklistClient.js"
pick package.json "$WORK/package.json"

# tests: nombres planos del Proyecto -> nombres con puntos que espera package.json
for t in "$P"/*_test.js "$WIP"/*_test.js "$WIP"/*.test.js; do
  [ -f "$t" ] || continue
  b=$(basename "$t"); n=$(echo "$b" | sed 's/_e2e_test\.js$/.e2e.test.js/; s/_test\.js$/.test.js/')
  cp "$t" "$WORK/test/$n"
done

# fixtures binarios desde los .txt Base64 (el panel del Proyecto no acepta .dcm)
base64 -d "$P/CT_small_dcm_base64.txt" > "$WORK/test/fixtures/CT_small.dcm"
base64 -d "$P/MR_small_dcm_base64.txt" > "$WORK/test/fixtures/MR_small.dcm"
base64 -d "$P/consentimiento_prueba_pdf_base64.txt" > "$WORK/test/fixtures/consentimiento_prueba.pdf"
# fixtures extra (MR_small_RLE): el .txt Base64 de rle-wip y, si ya lo subiste al Proyecto, el de /mnt/project
for f in "$WIP"/*_dcm_base64.txt "$P"/MR_small_RLE_dcm_base64.txt; do
  [ -f "$f" ] || continue
  b=$(basename "$f" _dcm_base64.txt)
  base64 -d "$f" > "$WORK/test/fixtures/$b.dcm" && echo "(fixture extra decodificado: $b.dcm)"
done
echo "--- hashes de fixtures (esperados: 3dd31e5c… CT_small / 3f27d1c2… MR_small / 2e5cb608… MR_small_RLE / 5cdada5c… consentimiento) ---"
sha256sum "$WORK"/test/fixtures/* | cut -c1-16,65-

cd "$WORK" && npm install --no-audit --no-fund 2>&1 | tail -2

# Frontend: árbol propio, con dependencias distintas del motor. En el Proyecto los archivos están planos y con
# otros nombres (frontend-package.json / frontend-vitest_config.mjs / HIS-RIS-PACS_interaction_test.jsx).
# (Hasta el 18-oct-2026 este script NO lo armaba: quedaba solo WorklistClient.js y la suite Vitest no corría.)
pick HIS-RIS-PACS.jsx "$WORK/frontend/HIS-RIS-PACS.jsx"
cp "$P/HIS-RIS-PACS_interaction_test.jsx" "$WORK/frontend/HIS-RIS-PACS.interaction.test.jsx"
cp "$P/frontend-package.json" "$WORK/frontend/package.json"
cp "$P/frontend-vitest_config.mjs" "$WORK/frontend/vitest.config.mjs"
(cd "$WORK/frontend" && npm install --no-audit --no-fund 2>&1 | tail -2)
echo "=== árbol reconstruido en $WORK ==="
