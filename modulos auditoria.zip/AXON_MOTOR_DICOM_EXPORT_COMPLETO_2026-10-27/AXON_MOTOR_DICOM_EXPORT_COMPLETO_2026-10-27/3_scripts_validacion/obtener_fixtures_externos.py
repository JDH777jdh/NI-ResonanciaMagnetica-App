#!/usr/bin/env python3
"""
obtener_fixtures_externos.py — obtiene los archivos RLE de referencia (generados por OTRA
implementación, no por el motor de AXON) desde pydicom 3.0.2 y verifica su sha256 contra los
que se usaron en la validación cruzada de octubre de 2026 (dossier §18).

Por qué NO viven en el Proyecto: todo archivo del Proyecto entra al contexto de CADA sesión, y el
Base64 pesa ~1,33x y casi no se comprime en tokens. Solo MR_small_RLE.dcm (7,8 KB) se versiona
(como Base64), porque `npm test` lo necesita. Los demás (~670 KB) se bajan acá, solo cuando se
quiere repetir la validación cruzada (validar_real_rle.js, probe_estructura_rle.js).

Uso:
    pip install pydicom==3.0.2
    python3 obtener_fixtures_externos.py [directorio_destino]     # por defecto: /tmp/rle_real

pydicom entrega algunos archivos dentro del propio paquete (MR_small*.dcm, SC_rgb_rle.dcm) y baja el
resto del repositorio pydicom-data a ~/.pydicom/data la primera vez (requiere red hacia GitHub).

Código de salida: 0 si todos coinciden por hash; 1 si falta alguno o es una versión distinta (en ese
caso la validación documentada NO aplica a ese archivo: hay que volver a medir, no asumir).
"""
import hashlib
import os
import shutil
import sys

from pydicom.data import get_testdata_file

ESPERADOS = {
    "MR_small.dcm":      "3f27d1c22f1a66e80d7bb7c911e8610fd0bb70325a76746a7adb1c0ddefcf2bb",
    "MR_small_RLE.dcm":  "2e5cb60878dc0acc494298ccdad28fce2cf14c51096e5d8cedab40248ea02e6c",
    "emri_small.dcm":    "151233ec63f64ebb63b979df51aa827cd612a53422c073f6ef341770c7bc9a56",
    "emri_small_RLE.dcm": "93c19bca3fb6b7202dcd067de8d16cb6b3f7c6e9a0632e474aab81175ee45266",
    "OBXXXX1A.dcm":      "164a460bebdc15fbe391ad4bfe4c84672eb2bad57adfe7dad372fd7367b0f63e",
    "OBXXXX1A_rle.dcm":  "aaf57785817dbe35503c6175d677d2efa811f90e931fc5017611ba9ff4c7f92a",
    "SC_rgb_rle.dcm":    "3f98ee352e75b10ccd6d279ca30b0cb1e363a0c9dde318803f0ec660111327d6",
}


def main() -> int:
    destino = sys.argv[1] if len(sys.argv) > 1 else "/tmp/rle_real"
    os.makedirs(destino, exist_ok=True)
    fallas = 0
    for nombre, esperado in ESPERADOS.items():
        ruta = get_testdata_file(nombre)
        if not ruta:
            print(f"FALTA     {nombre}")
            fallas += 1
            continue
        with open(ruta, "rb") as f:
            real = hashlib.sha256(f.read()).hexdigest()
        if real != esperado:
            print(f"DISTINTO  {nombre}: sha256 {real[:12]}… (esperado {esperado[:12]}…) — otra versión de "
                  f"pydicom-data; la validación previa NO aplica a este archivo")
            fallas += 1
            continue
        shutil.copyfile(ruta, os.path.join(destino, nombre))
        print(f"OK        {nombre:<20} {os.path.getsize(ruta):>7} bytes  sha256 {real[:12]}…")
    return 1 if fallas else 0


if __name__ == "__main__":
    sys.exit(main())
