const fs = require('fs');
const dcmjs = require('dcmjs');
const Explicit = require('/home/claude/rle-work/src/pdu/ExplicitVrCodec');
const Rle = require('/home/claude/rle-work/src/pdu/RleCodec');

function leerRle(ruta) {                       // MI código: ExplicitVrCodec + sobre encapsulado
  const buf = fs.readFileSync(ruta);
  const primero = Explicit.decodeElementAt(buf, 132);
  const fin = primero.nextOffset + primero.value;
  const ds = Explicit.decodeDataset(buf.slice(fin));
  const g = (t) => { const e = ds.find((x) => x.tag === t); return e && e.value; };
  return { rows: g('00280010'), cols: g('00280011'), bits: g('00280100'), frames: Number(g('00280008') || 1), px: ds.find((x) => x.tag === '7fe00010').value };
}
function leerReferenciaDcmjs(ruta) {           // dcmjs: lee los píxeles SIN comprimir (referencia independiente)
  const b = fs.readFileSync(ruta);
  const d = dcmjs.data.DicomMessage.readFile(b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength));
  return Buffer.concat(d.dict['7FE00010'].Value.map((ab) => Buffer.from(ab)));
}

const pares = [
  ['MR_small_RLE.dcm', 'MR_small.dcm'],
  ['OBXXXX1A_rle.dcm', 'OBXXXX1A.dcm'],
  ['emri_small_RLE.dcm', 'emri_small.dcm'],
];
let todoOk = true;
for (const [rleF, refF] of pares) {
  console.log(`\n=== ${rleF}  vs  ${refF} (referencia leída con dcmjs) ===`);
  try {
    const r = leerRle('/tmp/rle_real/' + rleF);
    const ref = leerReferenciaDcmjs('/tmp/rle_real/' + refF);
    const bytesFrame = r.rows * r.cols * (r.bits / 8);
    console.log(`${r.rows}x${r.cols}, ${r.bits} bits, ${r.frames} frame(s), referencia: ${ref.length} bytes (esperado ${bytesFrame * r.frames})`);
    let okDecod = 0, identicosAlRecomprimir = 0;
    for (let i = 0; i < r.frames; i++) {
      const crudo = Rle.descomprimirFrame(Buffer.from(r.px.fragmentos[i]), r.rows * r.cols, r.bits);
      const esperado = ref.slice(i * bytesFrame, (i + 1) * bytesFrame);
      if (Buffer.compare(crudo, esperado) === 0) okDecod++; else console.log(`  ❌ frame ${i}: NO coincide`);
      // ENCODER: re-comprimir el mismo frame con MI encoder y comparar contra el fragmento real
      const mio = Rle.comprimirFrame(esperado, r.bits, r.cols);
      const real = Buffer.from(r.px.fragmentos[i]);
      if (Buffer.compare(mio, real) === 0) identicosAlRecomprimir++;
      else if (i === 0) { let k = 0; while (k < Math.min(mio.length, real.length) && mio[k] === real[k]) k++; console.log(`  (frame 0) mi encoder != real: largos ${mio.length} vs ${real.length}, primera diferencia en byte ${k}`); }
    }
    console.log(`  DECODER (mi código leyendo archivo ajeno): ${okDecod}/${r.frames} frames idénticos byte a byte a la referencia ${okDecod === r.frames ? '✅' : '❌'}`);
    console.log(`  ENCODER (mi código re-comprimiendo): ${identicosAlRecomprimir}/${r.frames} frames idénticos al fragmento comprimido real`);
    if (okDecod !== r.frames) todoOk = false;
  } catch (e) { console.log('  ❌ ERROR:', e.message); todoOk = false; }
}

console.log('\n=== SC_rgb_rle.dcm (RGB, 3 segmentos) — fuera de alcance: debe rechazar con motivo, no devolver basura ===');
try {
  const r = leerRle('/tmp/rle_real/SC_rgb_rle.dcm');
  Rle.descomprimirFrame(Buffer.from(r.px.fragmentos[0]), r.rows * r.cols, 8);
  console.log('❌ aceptó un RGB como si fuera escala de grises'); todoOk = false;
} catch (e) { console.log('✅ rechazó con:', e.message); }

console.log('\nRESULTADO GLOBAL:', todoOk ? '✅ TODO COINCIDE' : '❌ HAY DIFERENCIAS');
