#!/usr/bin/env node
/**
 * verificar_identificadores.mjs — verificación EMPÍRICA de MasterIdentifierService.js
 * (identificadores administrados por MAIN, aplicado 2026-09-11; reemplaza a cup.js).
 *
 * Contexto: MAIN administra CUP/CUT/CUC/CUIT…; el motor DICOM y los satélites los CONSUMEN.
 * Este script no modifica nada: ejecuta el archivo real de MAIN y lo contrasta con una
 * implementación independiente, con las restricciones de DICOM, y con lo que hoy genera
 * HIS-RIS-PACS.jsx. Lo que no se pudo verificar se dice, no se asume.
 *
 * Uso:  node verificar_identificadores.mjs [servicio.mjs] [HIS-RIS-PACS.jsx] [salida_ids.json]
 *   - REGLA: el servicio lo administra MAIN; este repositorio NO guarda una copia (nosotros solo lo consumimos).
 *     Es ESM e importa `crypto-js`, así que se ejecuta desde un directorio con node_modules/crypto-js y un SYMLINK con
 *     extensión .mjs que apunta al archivo de MAIN:   ln -s <ruta del servicio de MAIN> /tmp/mis/MIS.mjs
 *     y se corre con:   node --preserve-symlinks verificar_identificadores.mjs /tmp/mis/MIS.mjs
 *   - por defecto: /tmp/mis/MIS.mjs · /mnt/project/HIS-RIS-PACS.jsx · /tmp/mis/ids_main.json
 */
import fs from 'node:fs';
import crypto from 'node:crypto';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const RUTA_SERVICIO = path.resolve(process.argv[2] || '/tmp/mis/MIS.mjs'); // symlink al archivo de MAIN — nunca una copia
const RUTA_JSX = process.argv[3] || '/mnt/project/HIS-RIS-PACS.jsx';
const SALIDA_IDS = process.argv[4] || '/tmp/mis/ids_main.json';
const M = await import(pathToFileURL(RUTA_SERVICIO).href);

let n = 0;
let malos = 0;
const ok = (d) => { n++; console.log(`OK   [${n}] ${d}`); };
const fail = (d) => { n++; malos++; console.log(`FAIL [${n}] ${d}`); };
const nota = (d) => console.log(`NOTA  ${d}`);
const chequear = (cond, dOk, dFail) => (cond ? ok(dOk) : fail(dFail || dOk));

// ───────────────────────── 1) CHK2 ─────────────────────────
console.log('\n── 1) CHK2: ¿hace lo que dice el encabezado del archivo? ──');
const enc = (b) => String.fromCharCode(65 + Math.floor(b / 10)) + String(b % 10);
const byte0 = (s) => crypto.createHash('sha256').update(s, 'utf8').digest()[0];

const bases = [];
for (let i = 0; i < 5000; i++) bases.push(`CUP-CL-13-2026-${String(i).padStart(8, '0')}`);
bases.push('CUT-CL-13-ÁÉÍÓÚÑ-0001', 'áéíóú', '');
const difs = bases.filter((b) => M.calcularCheck2(b) !== enc(byte0(b))).length;
chequear(difs === 0,
  `CHK2 del servicio (CryptoJS) == implementación independiente (crypto de Node: primer byte de SHA-256 → letra+dígito) en ${bases.length} bases, incl. acentos y vacía`,
  `CHK2 difiere de la implementación independiente en ${difs}/${bases.length} bases`);

const porByte = new Map();
let incoherentes = 0;
for (let i = 0; porByte.size < 256 && i < 300000; i++) {
  const b = `COBERTURA-${i}`;
  const by = byte0(b);
  const c = M.calcularCheck2(b);
  if (porByte.has(by) && porByte.get(by) !== c) incoherentes++;
  porByte.set(by, c);
}
const codigos = [...porByte.values()];
chequear(porByte.size === 256, 'los 256 valores posibles del primer byte aparecen y cada uno produce un código');
chequear(codigos.every((c) => /^[A-Z]\d$/.test(c)), 'todos los códigos tienen forma letra+dígito');
chequear(new Set(codigos).size === 256, '256 códigos distintos: la codificación es inyectiva (dos bytes distintos nunca dan el mismo código)');
chequear(codigos.every((c) => !/^Z[6-9]$/.test(c)), 'nunca se emiten Z6..Z9 (los 4 códigos inalcanzables de los 260 posibles — coincide con el comentario del archivo)');
chequear(incoherentes === 0, 'determinista: el mismo byte siempre produce el mismo código');

let ejemplo = null;
for (let i = 0; i < 200000 && !ejemplo; i++) if (byte0(`EJ-${i}`) === 0x89) ejemplo = `EJ-${i}`;
chequear(M.calcularCheck2(ejemplo) === 'N7', `ejemplo del encabezado reproducido: primer byte 0x89 (137) → "N7" (base real: "${ejemplo}")`,
  `ejemplo del encabezado NO se reproduce: 0x89 dio "${M.calcularCheck2(ejemplo)}"`);

// ───────────────────────── 2) los 15 identificadores ─────────────────────────
console.log('\n── 2) Generar los identificadores (15 de la versión anterior + CUV si el archivo lo trae) y validarlos ──');
const base = { paisISO2: 'CL', regionCode: '13', secuencia: 47 };
const ids = {
  'CUP': M.generarCUP({ ...base, anio: 2026 }),
  'CUP-RN': M.generarCUPRN({ ...base, anio: 2026 }),
  'CUP-NN': M.generarCUPNN({ ...base, anio: 2026 }),
  'CUT': M.generarCUT({ ...base, tenantCode: 'CLINICA1' }),
  'CUC': M.generarCUC({ ...base, tenantCode: 'CLINICA1', secuencia: 7, anio: 2026 }),
  'CUT-AXON-ADM': M.generarCUTAxonAdm({ paisISO2: 'CL', secuencia: 3 }),
  'CUT-AXON-WLD': M.generarCUTAxonWld(base),
  'CUTG-AXON-WLD': M.generarCUTGAxonWld(base),
  'CUT-AXON-CTRY': M.generarCUTAxonCtry(base),
  'CUTG-AXON-CTRY': M.generarCUTGAxonCtry(base),
  'CUIT-AXON': M.generarCUITAxon(base),
  'CUT-AXON': M.generarCUTAxon(base),
  'CUC-AXON': M.generarCUCAxon({ ...base, corpCode: 'CORP0001', anio: 2026 }),
  'CUIT-CORE': M.generarCUITAxonCore({ ...base, tenantCode: 'TENANT01' }),
  'CUIT-CORE-LITE': M.generarCUITAxonCoreLite({ ...base, tenantCode: 'TENANT01' }),
};
if (typeof M.generarCUV === 'function') ids['CUV'] = M.generarCUV({ paisISO2: 'CL', regionCode: '13', ambitoCode: M.CUV_AMBITO_RADE, secuencia: 1 }); // solo si el archivo de MAIN trae CUV
for (const [k, v] of Object.entries(ids)) console.log(`      ${k.padEnd(15)} ${String(v.length).padStart(2)} car.  ${v}`);
nota(`forma de retorno de los validadores: ${JSON.stringify(M.validarCUP(ids.CUP))}`);

const propios = { 'CUP': M.validarCUP, 'CUP-RN': M.validarCUPRN, 'CUP-NN': M.validarCUPNN, 'CUT': M.validarCUT, 'CUC': M.validarCUC };
for (const [k, f] of Object.entries(propios)) {
  const r = f(ids[k]);
  chequear(r.valido === true, `${k} generado → su validador propio lo acepta`, `${k} generado NO pasa su propio validador: ${JSON.stringify(r)}`);
}
// cada validador acepta SOLO su tipo (matriz 5×5)
let cruces = 0;
for (const [kv, f] of Object.entries(propios)) for (const ki of Object.keys(propios)) if (kv !== ki && f(ids[ki]).valido) cruces++;
chequear(cruces === 0, 'matriz 5×5 de validadores: ningún validador acepta el identificador de otro tipo (CUP/CUP-RN/CUP-NN/CUT/CUC no se confunden)',
  `${cruces} cruces: algún validador acepta un identificador de otro tipo`);

// Los 10 nuevos no tienen validador propio: el archivo ofrece validarGenerico(valor, regex). Las regex salen
// de los formatos que el propio archivo documenta/genera (construirId), no se inventan.
const D2 = '([A-Z]{2})'; const R = '([A-Z0-9]{1,3})'; const T8 = '([A-Z0-9]{8})'; const S4 = '(\\d{4})'; const CK = '([A-Z]\\d)';
const FORMATOS_NUEVOS = {
  'CUT-AXON-ADM': `CUT-AXON-ADM-${D2}-${S4}-${CK}`,
  'CUT-AXON-WLD': `CUT-AXON-WLD-${D2}-${R}-${S4}-${CK}`,
  'CUTG-AXON-WLD': `CUTG-AXON-WLD-${D2}-${R}-${S4}-${CK}`,
  'CUT-AXON-CTRY': `CUT-AXON-CTRY-${D2}-${R}-${S4}-${CK}`,
  'CUTG-AXON-CTRY': `CUTG-AXON-CTRY-${D2}-${R}-${S4}-${CK}`,
  'CUIT-AXON': `CUIT-${D2}-${R}-AXON-${S4}-${CK}`,
  'CUT-AXON': `CUT-${D2}-${R}-AXON-${S4}-${CK}`,
  'CUC-AXON': `CUC-AXON-${D2}-${R}-${T8}-${S4}-${S4}-${CK}`,
  'CUIT-CORE': `CUIT-${D2}-${R}-${T8}-${S4}-${CK}`,
  'CUIT-CORE-LITE': `CUIT-${D2}-${R}-${T8}-${S4}-${CK}`,
};
const fallosNuevos = Object.entries(FORMATOS_NUEVOS)
  .map(([k, f]) => [k, M.validarGenerico(ids[k], new RegExp(`^${f}$`))])
  .filter(([, r]) => !r.valido);
chequear(fallosNuevos.length === 0, 'los 10 identificadores nuevos pasan validarGenerico con la regex de su formato documentado (forma + dígito verificador)',
  `no pasan validarGenerico: ${JSON.stringify(fallosNuevos)}`);
chequear(ids['CUIT-CORE'] === ids['CUIT-CORE-LITE'], 'CUIT Core y CUIT Core Lite generan la MISMA cadena para las mismas entradas (se distinguen por identifier_type, no por forma — el archivo lo declara)');

// ───────────────────────── 3) bordes: generador vs. validador ─────────────────────────
console.log('\n── 3) Bordes: ¿el generador respeta lo que su propio validador exige? ──');
const bordes = [
  ['CUP con secuencia de 9 dígitos (123456789)', () => M.generarCUP({ ...base, anio: 2026, secuencia: 123456789 }), M.validarCUP],
  ['CUT con secuencia 10000 (5 dígitos; el formato es SEQ4)', () => M.generarCUT({ ...base, tenantCode: 'CLINICA1', secuencia: 10000 }), M.validarCUT],
  ['CUC con secuencia 1000 (4 dígitos; el formato es SEQ3)', () => M.generarCUC({ ...base, tenantCode: 'CLINICA1', anio: 2026, secuencia: 1000 }), M.validarCUC],
  ['CUP con región de 4 caracteres ("ABCD"; el formato admite 1–3)', () => M.generarCUP({ ...base, regionCode: 'ABCD', anio: 2026 }), M.validarCUP],
  ['CUP con país de 3 letras ("CHL"; el formato exige ISO2)', () => M.generarCUP({ ...base, paisISO2: 'CHL', anio: 2026 }), M.validarCUP],
];
let silenciosos = 0;
for (const [desc, gen, val] of bordes) {
  try {
    const id = gen();
    const r = val(id);
    if (r.valido) nota(`${desc}: generó "${id}" y es VÁLIDO`);
    else { silenciosos++; nota(`${desc}: generó "${id}" SIN error, pero su propio validador lo rechaza (${r.error})`); }
  } catch (e) { nota(`${desc}: el generador lanzó error → ${e.message}`); }
}
if (silenciosos > 0) nota(`HALLAZGO PARA MAIN: ${silenciosos} de ${bordes.length} entradas fuera de rango producen un identificador inválido SIN error en la generación (padStart no trunca y no hay guardas). No afecta al motor DICOM; sí a quien emita el identificador.`);
chequear(true, `bordes ejecutados y reportados (${silenciosos}/${bordes.length} silenciosos)`);

let revoc = 'no lanzó';
try { M.revocarCUT(ids['CUT-AXON'], 'prueba', 'verificador'); } catch (e) { revoc = `lanzó: "${e.message}"`; }
let revocCut = 'no lanzó';
try { const r = M.revocarCUT(ids['CUT'], 'prueba', 'verificador'); revocCut = r.cutActivo === false ? 'OK (cutActivo=false)' : 'respuesta inesperada'; } catch (e) { revocCut = `lanzó: "${e.message}"`; }
nota(`revocarCUT(CUT de tenant) → ${revocCut}   ·   revocarCUT(CUT-AXON de AXON Health) → ${revoc}`);
nota(`validarCUT(CUT-AXON) → ${JSON.stringify(M.validarCUT(ids['CUT-AXON']))} (esperable: el segmento tenant de CUT-AXON es "AXON", 4 caracteres, y CUT_REGEX exige 8)`);

// ───────────────────────── 4) compatibilidad con DICOM ─────────────────────────
console.log('\n── 4) ¿Caben en DICOM? (el motor guarda el CUP como Patient ID, VR LO, máx. 64 caracteres) ──');
const todos = Object.entries(ids);
chequear(todos.every(([, v]) => v.length <= 64), `los 15 miden ≤ 64 caracteres (máx. observado: ${Math.max(...todos.map(([, v]) => v.length))})`);
chequear(todos.every(([, v]) => /^[A-Z0-9-]+$/.test(v)), 'los 15 usan solo A-Z, 0-9 y guion: ASCII puro, sin "\\" (separador de valores en DICOM) ni caracteres de control');
const peor = [
  M.generarCUP({ paisISO2: 'CL', regionCode: 'ABC', secuencia: 99999999, anio: 2026 }),
  M.generarCUPRN({ paisISO2: 'CL', regionCode: 'ABC', secuencia: 99999999, anio: 2026 }),
  M.generarCUPNN({ paisISO2: 'CL', regionCode: 'ABC', secuencia: 99999999, anio: 2026 }),
  M.generarCUT({ paisISO2: 'CL', regionCode: 'ABC', tenantCode: 'ABCDEFGH', secuencia: 9999 }),
  M.generarCUC({ paisISO2: 'CL', regionCode: 'ABC', tenantCode: 'ABCDEFGH', secuencia: 999, anio: 2026 }),
  M.generarCUCAxon({ paisISO2: 'CL', regionCode: 'ABC', corpCode: 'ABCDEFGH', secuencia: 9999, anio: 2026 }),
];
chequear(Math.max(...peor.map((s) => s.length)) <= 64, `peor caso de longitud con entradas máximas legítimas: ${Math.max(...peor.map((s) => s.length))} caracteres (≤ 64)`);
chequear(todos.every(([, v]) => v.length > 16), `ninguno cabe en un SH (máx. 16): el más corto mide ${Math.min(...todos.map(([, v]) => v.length))} → el Accession Number y el Requested Procedure ID NO pueden ser identificadores de MAIN`);
nota('ACC y OT no están definidos en este archivo (siguen en makeACC/makeOT de HIS-RIS-PACS.jsx). Restricción para quien los defina: ≤ 16 caracteres (VR SH, PS3.5 Tabla 6.2-1).');
nota(`cupAFHIRIdentifier(CUP) → ${JSON.stringify(M.cupAFHIRIdentifier(ids.CUP))}`);

// ───────────────────────── 5) lo que genera HIS-RIS-PACS.jsx hoy ─────────────────────────
console.log('\n── 5) Contraste con HIS-RIS-PACS.jsx: ¿los CUP/CUT que genera hoy el satélite los acepta el validador real? ──');
const jsx = fs.readFileSync(RUTA_JSX, 'utf8');
const mCheck = jsx.match(/const checkDigitLocal = [\s\S]*?\n\};/);
const mCup = jsx.match(/const makeCUP = [\s\S]*?\n\};/);
const mCut = jsx.match(/const makeCUT = [\s\S]*?\n\};/);
if (!mCheck || !mCup || !mCut) {
  fail('no se pudo extraer checkDigitLocal/makeCUP/makeCUT del JSX (¿cambió el archivo?) — la comparación no se hizo');
} else {
  const { makeCUP, makeCUT } = new Function(`${mCheck[0]}\n${mCup[0]}\n${mCut[0]}\nreturn { makeCUP, makeCUT };`)();
  const res = { valido: 0, formato: 0, digito: 0 };
  const ejemplos = [];
  for (let k = 2001; k <= 2024; k++) {
    const cup = makeCUP(k);
    const r = M.validarCUP(cup);
    if (r.valido) res.valido++; else if (/Formato/.test(r.error)) res.formato++; else res.digito++;
    if (ejemplos.length < 3) ejemplos.push(`${cup} → ${r.valido ? 'válido' : r.error}`);
  }
  nota(`CUPs de la SEED de HIS-RIS-PACS.jsx (makeCUP 2001..2024): ${res.valido} válidos · ${res.formato} "Formato CUP inválido" · ${res.digito} "Dígito verificador inválido"`);
  ejemplos.forEach((e) => nota(`   ej.: ${e}`));
  const cutLocal = makeCUT(1);
  nota(`makeCUT(1) del JSX = ${cutLocal} → validarCUT: ${JSON.stringify(M.validarCUT(cutLocal))}`);
  chequear(true, 'comparación con el satélite ejecutada (resultado en las NOTAS de arriba: el CUP del JSX usa un hash local de reemplazo, ya documentado como tal en el propio JSX)');
}

fs.writeFileSync(SALIDA_IDS, JSON.stringify({ ids, peorCaso: peor }, null, 2));
console.log(`\n(identificadores generados guardados en ${SALIDA_IDS} para la prueba contra el motor)`);
console.log(`=== RESULTADO verificación MasterIdentifierService: ${malos ? `${malos} FALLA(S) — ver arriba` : `${n} checks OK, 0 fallas`} ===`);
process.exit(malos ? 1 : 0);
