'use strict';
/**
 * verificar_motor_con_identificadores.js — ¿los identificadores REALES de MAIN rompen el motor DICOM?
 *
 * Entrada: el JSON que deja verificar_identificadores.mjs (identificadores generados por el
 * MasterIdentifierService real). Nada se mockea: servidor DIMSE real, sockets reales, HTTP real.
 *
 *   Parte A — con los identificadores de MAIN (CUP, CUP-RN, CUP-NN, y el peor caso de longitud):
 *     A1) Modality Worklist (C-FIND) en Implicit VR LE y en Explicit VR LE: el CUP viaja como Patient ID
 *         (0010,0020, VR LO) y vuelve idéntico.
 *     A2) C-STORE con ese Patient ID → QIDO-RS filtrando por PatientID devuelve exactamente ese estudio.
 *   Parte B — sonda de robustez (cada caso en un PROCESO HIJO, para poder observar si el motor muere):
 *     qué pasa si el Worklist contiene un valor que excede el máximo de su VR (lo que un identificador mal
 *     formado, o un registro viejo persistido, podría provocar).
 *
 * Uso: node verificar_motor_con_identificadores.js [raiz_del_motor] [ids_main.json]
 *   por defecto: /home/claude/rle-work  ·  /tmp/mis/ids_main.json
 */
const path = require('path');
const fs = require('fs');
const net = require('net');
const http = require('http');
const os = require('os');
const { spawn } = require('child_process');

const RAIZ = process.argv[2] || '/home/claude/rle-work';
const IDS_JSON = process.argv[3] || '/tmp/mis/ids_main.json';
const { ids, peorCaso } = JSON.parse(fs.readFileSync(IDS_JSON, 'utf8'));
const SRC = path.join(RAIZ, 'src');
const PDU = require(path.join(SRC, 'pdu', 'PDU'));
const DIMSE = require(path.join(SRC, 'pdu', 'DimseCommand'));
const Implicit = require(path.join(SRC, 'pdu', 'ImplicitVrCodec'));
const Explicit = require(path.join(SRC, 'pdu', 'ExplicitVrCodec'));
const WorklistStore = require(path.join(SRC, 'storage', 'WorklistStore'));
const { iniciarServidor, MODALITY_WORKLIST_SOP_CLASS } = require(path.join(SRC, 'server', 'AssociationServer'));
const DicomWebServer = require(path.join(SRC, 'server', 'DicomWebServer'));

const IMPLICIT_LE = '1.2.840.10008.1.2';
const EXPLICIT_LE = '1.2.840.10008.1.2.1';
const MR_STORAGE = '1.2.840.10008.5.1.4.1.1.4';

let n = 0; let malos = 0;
const ok = (d) => { n++; console.log(`OK   [${n}] ${d}`); };
const fail = (d) => { n++; malos++; console.log(`FAIL [${n}] ${d}`); };
const nota = (d) => console.log(`NOTA  ${d}`);

// ───────────── cliente DIMSE mínimo (mismo patrón que los tests del motor) ─────────────
function decodeAssociateAC(buf) {
  let o = 6; o += 2; o += 2; o += 16; o += 16; o += 32;
  const results = [];
  while (o < buf.length) {
    const t = buf.readUInt8(o); const l = buf.readUInt16BE(o + 2);
    const body = buf.slice(o + 4, o + 4 + l);
    if (t === 0x21) results.push({ id: body.readUInt8(0), accepted: body.readUInt8(2) === 0 });
    o += 4 + l;
  }
  return { results };
}
async function conectar(port) {
  const socket = net.connect(port, '127.0.0.1');
  await new Promise((res, rej) => { socket.once('connect', res); socket.once('error', rej); });
  let buffer = Buffer.alloc(0); let cerrado = false;
  const cola = []; const esperando = [];
  const cerrar = () => { cerrado = true; while (esperando.length) esperando.shift().rej(new Error('la conexión se cerró sin respuesta')); };
  socket.on('close', cerrar); socket.on('error', cerrar);
  socket.on('data', (chunk) => {
    buffer = Buffer.concat([buffer, chunk]);
    let h;
    while ((h = PDU.peekPduHeader(buffer)) && buffer.length >= h.totalSize) {
      const pdu = buffer.slice(0, h.totalSize); buffer = buffer.slice(h.totalSize);
      if (esperando.length) esperando.shift().res(pdu); else cola.push(pdu);
    }
  });
  const nextPdu = (t = 3000) => new Promise((res, rej) => {
    if (cola.length) return res(cola.shift());
    if (cerrado) return rej(new Error('la conexión se cerró sin respuesta'));
    const tm = setTimeout(() => rej(new Error('timeout esperando respuesta')), t);
    esperando.push({ res: (p) => { clearTimeout(tm); res(p); }, rej: (e) => { clearTimeout(tm); rej(e); } });
  });
  return { socket, nextPdu };
}
async function asociar(port, contextos) {
  const s = await conectar(port);
  s.socket.write(PDU.encodeAssociateRQ({ calledAE: 'AXON_RIS', callingAE: 'CT_SALA1', presentationContexts: contextos, maxPduLength: 16384, implementationClassUID: '1.2.840.99999.1.1' }));
  const ac = decodeAssociateAC(await s.nextPdu());
  if (!ac.results.every((r) => r.accepted)) throw new Error('contexto no aceptado: ' + JSON.stringify(ac.results));
  return s;
}
/** C-FIND de Modality Worklist; devuelve los datasets crudos de cada Pending. */
async function mwlFind(port, ts) {
  const s = await asociar(port, [{ id: 1, abstractSyntax: MODALITY_WORKLIST_SOP_CLASS, transferSyntaxes: [ts] }]);
  s.socket.write(PDU.encodePDataTF([{ presentationContextId: 1, isCommand: true, isLast: true, data: DIMSE.encodeCommandSet({ '00000002': MODALITY_WORKLIST_SOP_CLASS, '00000100': DIMSE.COMMAND_FIELD.C_FIND_RQ, '00000110': 1, '00000800': 0x0101 }) }]));
  const items = [];
  for (;;) {
    const pdvs = PDU.decodePDataTF(await s.nextPdu());
    const cmd = DIMSE.decodeCommandSet(pdvs.find((p) => p.isCommand).data);
    const ds = pdvs.find((p) => !p.isCommand);
    if (cmd['00000900'] === DIMSE.STATUS.PENDING) { if (ds) items.push(ds.data); } else if (cmd['00000900'] === DIMSE.STATUS.SUCCESS) break;
  }
  s.socket.write(PDU.encodeReleaseRQ()); await s.nextPdu(); s.socket.end();
  return items;
}
const httpJson = (url) => new Promise((resolve, reject) => {
  http.get(url, (res) => { let d = ''; res.on('data', (c) => { d += c; }); res.on('end', () => resolve(JSON.parse(d))); }).on('error', reject);
});
const limpio = (s) => String(s).replace(/[\0\s]+$/, '');
const tmpDir = (p) => fs.mkdtempSync(path.join(os.tmpdir(), p));

async function main() {
  // ═════════════ PARTE A ═════════════
  console.log('\n══ PARTE A — identificadores REALES de MAIN contra el motor ══');
  const ALM = tmpDir('axon-ids-A-');
  const cups = [
    ['CUP', ids.CUP], ['CUP-RN', ids['CUP-RN']], ['CUP-NN', ids['CUP-NN']],
    ['CUP (peor caso de longitud)', peorCaso[0]], ['CUP-RN (peor caso)', peorCaso[1]], ['CUP-NN (peor caso)', peorCaso[2]],
  ];
  cups.forEach(([, cup], i) => WorklistStore.agregar({
    nombre: `PRUEBA^MAIN${i + 1}`, cup, acc: `ACC-0000000${i + 1}`, ot: `OT-2026-00000${i + 1}`,
    fechaAAAAMMDD: '20261018', horaHHMM: '0900', modalidad: 'MR', estudio: 'RM PRUEBA',
  }, path.join(ALM, '.worklist-store.json')));

  const server = iniciarServidor({ port: 0, almacenPath: ALM, tlsOptions: null });
  await new Promise((r) => server.once('listening', r));
  const port = server.address().port;
  const httpServer = http.createServer(DicomWebServer.crearHandler({ almacenPath: ALM }));
  await new Promise((r) => httpServer.listen(0, r));
  const base = `http://127.0.0.1:${httpServer.address().port}`;

  for (const [nombreTs, ts, codec, extra] of [['Implicit VR LE', IMPLICIT_LE, Implicit, { '00400100': true }], ['Explicit VR LE', EXPLICIT_LE, Explicit, undefined]]) {
    try {
      const items = await mwlFind(port, ts);
      const decod = items.map((d) => codec.decodeDataset(d, extra));
      const vistos = decod.map((ds) => limpio(ds.find((e) => e.tag === '00100020').value)).sort();
      const esperados = cups.map(([, c]) => c).sort();
      if (JSON.stringify(vistos) === JSON.stringify(esperados)) ok(`A1 MWL en ${nombreTs}: los ${cups.length} Patient ID (CUP/CUP-RN/CUP-NN y peor caso, hasta ${Math.max(...esperados.map((c) => c.length))} car.) llegan IDÉNTICOS por C-FIND`);
      else fail(`A1 MWL en ${nombreTs}: difieren. Esperados ${JSON.stringify(esperados)} · vistos ${JSON.stringify(vistos)}`);
    } catch (e) { fail(`A1 MWL en ${nombreTs}: ${e.message}`); }
  }

  try {
    const s = await asociar(port, [{ id: 1, abstractSyntax: MR_STORAGE, transferSyntaxes: [EXPLICIT_LE] }]);
    let msg = 100;
    for (const [i, [nombre, cup]] of cups.slice(0, 3).entries()) {
      const sop = `1.2.826.0.1.3680043.99999.80${i}.3`;
      const ds = Explicit.encodeDataset([
        { tag: '00080016', vr: 'UI', value: MR_STORAGE }, { tag: '00080018', vr: 'UI', value: sop },
        { tag: '00080050', vr: 'SH', value: `ACC-0000010${i}` }, { tag: '00080060', vr: 'CS', value: 'MR' },
        { tag: '00100010', vr: 'PN', value: 'PRUEBA^MAIN' }, { tag: '00100020', vr: 'LO', value: cup },
        { tag: '0020000D', vr: 'UI', value: `1.2.826.0.1.3680043.99999.80${i}.1` }, { tag: '0020000E', vr: 'UI', value: `1.2.826.0.1.3680043.99999.80${i}.2` },
      ]);
      s.socket.write(PDU.encodePDataTF([
        { presentationContextId: 1, isCommand: true, isLast: true, data: DIMSE.encodeCommandSet({ '00000002': MR_STORAGE, '00000100': DIMSE.COMMAND_FIELD.C_STORE_RQ, '00000110': ++msg, '00000700': 0, '00000800': 0x0102, '00001000': sop }) },
        { presentationContextId: 1, isCommand: false, isLast: true, data: ds },
      ]));
      const rsp = DIMSE.decodeCommandSet(PDU.decodePDataTF(await s.nextPdu())[0].data);
      if (rsp['00000900'] !== DIMSE.STATUS.SUCCESS) throw new Error(`C-STORE de ${nombre}: status 0x${(rsp['00000900'] || 0).toString(16)}`);
      const q = await httpJson(`${base}/studies?PatientID=${encodeURIComponent(cup)}`);
      const idq = q.length === 1 && q[0]['00100020'] && q[0]['00100020'].Value[0] === cup;
      if (idq) ok(`A2 ${nombre}: C-STORE con Patient ID = ${cup} → QIDO-RS /studies?PatientID=… devuelve exactamente ese estudio, con el mismo Patient ID`);
      else fail(`A2 ${nombre}: QIDO-RS no devolvió el estudio esperado (${JSON.stringify(q).slice(0, 160)})`);
    }
    s.socket.write(PDU.encodeReleaseRQ()); await s.nextPdu(); s.socket.end();
  } catch (e) { fail(`A2 C-STORE/QIDO: ${e.message}`); }
  httpServer.close(); server.close();

  // ═════════════ PARTE B ═════════════
  console.log('\n══ PARTE B — sonda de robustez: ¿qué pasa si el Worklist trae un valor fuera de los límites de su VR? ══');
  console.log('      (cada caso corre en un PROCESO HIJO del motor, para poder observar si el proceso muere)');
  const HIJO = path.join(__dirname, 'servidor_hijo.js');
  async function sonda(descripcion, registro) {
    const dir = tmpDir('axon-ids-B-');
    WorklistStore.agregar(registro, path.join(dir, '.worklist-store.json'));
    const hijo = spawn(process.execPath, [HIJO, RAIZ, dir], { stdio: ['ignore', 'pipe', 'pipe'] });
    let stderr = ''; let salida = null;
    hijo.stderr.on('data', (c) => { stderr += c; });
    hijo.on('exit', (code, signal) => { salida = { code, signal }; });
    const puerto = await new Promise((res, rej) => {
      let buf = '';
      const tm = setTimeout(() => rej(new Error('el hijo no arrancó')), 8000);
      hijo.stdout.on('data', (c) => { buf += c; const m = buf.match(/PUERTO (\d+)/); if (m) { clearTimeout(tm); res(Number(m[1])); } });
    });
    let respondio = false; let motivo = '';
    try { await mwlFind(puerto, IMPLICIT_LE); respondio = true; } catch (e) { motivo = e.message; }
    await new Promise((r) => setTimeout(r, 700));
    const murio = salida !== null;
    if (!murio) hijo.kill();
    const linea = (stderr.match(/(?:\w*Error): [^\n]+/) || [''])[0].slice(0, 190);
    return { descripcion, respondio, murio, salida, motivo, linea };
  }
  const resultados = [];
  resultados.push(await sonda('CONTROL — registro válido (ACC de 12 caracteres, nombre corto)', { nombre: 'PRUEBA^CONTROL', cup: ids.CUP, acc: 'ACC-00000001', ot: 'OT-2026-000001', fechaAAAAMMDD: '20261018', horaHHMM: '0900', modalidad: 'MR', estudio: 'RM' }));
  resultados.push(await sonda('ACC de 17 caracteres ("ACC-2026-00000001", formato anterior al 31-ago)', { nombre: 'PRUEBA^ACCVIEJO', cup: ids.CUP, acc: 'ACC-2026-00000001', ot: 'OT-2026-000001', fechaAAAAMMDD: '20261018', horaHHMM: '0900', modalidad: 'MR', estudio: 'RM' }));
  resultados.push(await sonda('Nombre de paciente de 70 caracteres (PN admite 64)', { nombre: 'A'.repeat(70), cup: ids.CUP, acc: 'ACC-00000002', ot: 'OT-2026-000002', fechaAAAAMMDD: '20261018', horaHHMM: '0900', modalidad: 'MR', estudio: 'RM' }));
  for (const r of resultados) {
    const estado = r.murio ? `MOTOR CAÍDO (exit ${r.salida.code}${r.salida.signal ? `, ${r.salida.signal}` : ''})` : 'motor vivo';
    console.log(`      ${r.respondio ? 'respondió el C-FIND' : 'SIN respuesta      '} · ${estado.padEnd(24)} · ${r.descripcion}`);
    if (r.linea) console.log(`          └ ${r.linea}`);
  }
  const control = resultados[0];
  if (control.respondio && !control.murio) ok('B0 control: con un registro válido la sonda obtiene respuesta y el motor sigue vivo (la sonda mide lo que dice medir)');
  else fail(`B0 control FALLÓ: ${JSON.stringify(control)}`);
  const caidos = resultados.slice(1).filter((r) => r.murio).length;
  if (caidos > 0) nota(`HALLAZGO (motor, independiente de MAIN): ${caidos} de ${resultados.length - 1} registros con un valor fuera del límite de su VR TUMBAN el proceso completo del motor al consultarse el Worklist — no hay try/catch alrededor del encode del MWL.`);
  else nota('el motor sobrevivió a todos los valores fuera de límite.');

  console.log(`\n=== RESULTADO motor + identificadores de MAIN: ${malos ? `${malos} FALLA(S)` : `${n} checks OK, 0 fallas`} ===`);
  process.exit(malos ? 1 : 0);
}
main().catch((e) => { console.error('ERROR FATAL:', e); process.exit(1); });
