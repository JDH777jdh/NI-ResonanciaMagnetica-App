# Extras fuera de alcance — identificadores de MAIN

Estas verificaciones se empezaron al recibir el archivo de identificadores de MAIN. **No son parte del motor DICOM** y el usuario aclaró que los identificadores los trabaja MAIN: el motor solo los consume. Quedaron **sin terminar**:

- `verificar_identificadores.mjs` — ejecuta el archivo de MAIN y lo contrasta con una implementación independiente (funciona; edición a medias: faltan los textos dinámicos y la sección de CUV). Toma la ruta del archivo de MAIN por argumento (symlink); **no hay copia de ese archivo en este export**.
- `RESULTADO_verificar_identificadores.txt` — salida de una corrida sobre la primera versión recibida (21 checks OK).
- `verificar_motor_con_identificadores.js` — prueba del motor con esos identificadores; **nunca se ejecutó** y le falta `servidor_hijo.js`.

Lo que sí importa para el motor está resumido en el dossier §18.6.
