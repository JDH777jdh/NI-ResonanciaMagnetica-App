# AXON RIS/PACS — Dossier Técnico Maestro
## Documento de traspaso — leer esto primero en la próxima sesión

**Fecha de corte:** 17-jul-2026 · **Propósito:** que una sesión nueva (o una persona nueva) entienda en 10 minutos qué existe, qué está probado de verdad, y qué sigue — sin releer la conversación completa.

---

## 1. Filosofía del proyecto (no negociable, repetir en cada sesión nueva)

1. **RIS/PACS propio, desde cero** — no se adopta Orthanc/dcm4chee/Weasis como servidor. Se construye el motor DICOM real (protocolo DIMSE, PS3.7/PS3.8) en Node.js, apoyado solo en librerías de bajo nivel para lo que corresponde (`dcmjs` para parseo de dataset), nunca en un PACS completo de terceros.
2. **Puertas etiquetadas** — cada capacidad futura (IA, herramientas avanzadas de visor, dictado por voz de producción) se deja como interfaz visible pero apagada, con el motivo explícito, nunca como botón que finge funcionar.
3. **Un solo lenguaje backend: Node.js** — el proyecto MAIN real es Vite + React + Vercel serverless + Firebase (confirmado revisando el zip real del proyecto). El motor DICOM es Node también, corriendo como proceso persistente en el servidor propio del cliente (no en Vercel — DIMSE necesita un listener TCP siempre encendido, incompatible con serverless).
4. **Nada de datos de pacientes reales** — en varias vueltas el usuario adjuntó DICOM reales y una captura con datos de paciente real de su trabajo. Se rechazó procesarlos explícitamente (Ley 21.719). Todo el desarrollo usa datos sintéticos generados por código.
5. **Multi-tenant, escala nacional/internacional** — 20 tipos de tenant confirmados en el proyecto MAIN (`tenantTypes.config.js`), los 30 módulos se activan siempre desde el día uno para cualquier tenant.

---

## 2. Inventario de archivos (todo en este paquete)

| Archivo | Qué es | Estado |
|---|---|---|
| `HIS-RIS-PACS.jsx` | Componente React único: Worklist (4 pestañas) + Visor DICOM pantalla completa + panel de Informe | En desarrollo activo, funcional |
| `dicom-engine/README.md` | Explica qué está probado y qué no, del motor | Vigente |
| `dicom-engine/src/pdu/PDU.js` | Codificación/decodificación binaria real del DICOM Upper Layer (PS3.8) | **Probado con tests, verificado** |
| `dicom-engine/src/pdu/DimseCommand.js` | Command Sets DIMSE (C-STORE, C-FIND) en Implicit VR LE (PS3.7) | **Probado** |
| `dicom-engine/src/pdu/ImplicitVrCodec.js` | Codec de datasets con soporte real de Secuencias (SQ) anidadas | **Probado** (round-trip de Scheduled Procedure Step Sequence) |
| `dicom-engine/src/server/AssociationServer.js` | El motor en sí: TCP/TLS, negociación de asociación, C-STORE, C-FIND/MWL | **Probado end-to-end** (equipo simulado → almacén → recuperación) |
| `dicom-engine/src/server/CStoreDataset.js` | Envoltorio Part10 (preámbulo+File Meta) + integración `dcmjs` (con fallback si no está instalado) | Probado el envoltorio; `dcmjs` no se pudo probar en este sandbox (sin red para `npm install`) |
| `dicom-engine/src/server/DicomWebServer.js` | QIDO-RS y WADO-RS (PS3.18) sobre el mismo almacén | **Probado end-to-end** (equipo→DIMSE→HTTP→navegador) |
| `dicom-engine/src/config/AeRegistry.js` | Registro de equipos DICOM — la "puerta etiquetada" de hardware | Probado |
| `dicom-engine/src/storage/StudyIndex.js` | Índice consultable que alimenta QIDO-RS | Probado |
| `dicom-engine/ui/EquipmentConfigPanel.jsx` | Panel React para agregar equipos sin tocar código | Construido, no probado en navegador real |
| `bosquejo_visualizador_pantalla_completa.html` | Boceto estático del visor (ya superado por la versión real en `HIS-RIS-PACS.jsx`) | Histórico, se puede archivar |
| `AXON_Dossier_RISPACS_Ampliacion.md` | Dossier de 13 puntos de una sesión anterior (timestamps múltiples, ACC/OT, consentimiento, etc.) | Mayoría ya implementada — ver §4 |

---

## 3. `HIS-RIS-PACS.jsx` — inventario funcional completo

### 3.1 Worklist (4 pestañas)
Agendados / Admisión / Worklist·RIS / Exámenes·PACS, con:
- Máquina de estados real (fase + estado) — avanzar un paciente lo mueve de pestaña de verdad
- Timestamps múltiples por pestaña (hora agendada/presentación/admisión/arribo/atención/almacenado)
- Columnas OT y Acceso (Accession Number real, verificado contra el estándar DICOM oficial — tag (0008,0050))
- RUT en columna propia, Procedencia antes del nombre, colores de modalidad en filtros y celdas
- Categorías clínicas configurables desde la interfaz (Aislamiento, Nivel de cuidados, Urgencia — incluye "Paciente estable")
- Prioridad editable independiente de procedencia
- Adjuntar examen externo (foto/PDF real vía input de archivo, o link)
- Botón único **Guardar** en Worklist — reemplaza el viejo flujo de 2 botones; guarda y envía sola la ficha a Exámenes (simula el ciclo MWL→equipo→C-STORE real, sin botón humano de "enviar a PACS")
- Panel de detalle con: TENS/TM/Radiólogo (selects), validación de consentimiento, datos clínicos (creatinina/talla/peso/contraste + selector de medio de contraste), **calculadora de función renal real** (Cockcroft-Gault y Schwartz bedside 2009, fórmulas verificadas contra fuentes clínicas)

### 3.2 Visor DICOM (pantalla completa)
- Reemplaza el modal chico original — toma toda la pantalla, con botón Volver
- Selector de vistas 1 a 6 con miniaturas visuales (no botones de texto)
- Herramientas reales: Ventana (arrastre = brillo/contraste, no sliders), Pan, Zoom, Rotar (rotación real de la matriz de píxeles, verificada con test unitario), Invertir, Medir (línea + distancia en px), Referencia cruzada (crosshair sincronizado entre paneles)
- **Scroll del mouse = cambiar de corte** (no botones), como cualquier visor real
- 3 herramientas avanzadas visibles pero apagadas a propósito, con el motivo (MPR, Cobb, Fusión PET-CT — necesitan datos volumétricos reales que hoy no existen)
- Genera y decodifica datasets DICOM sintéticos reales en el navegador (mismo esquema Implicit VR LE que el motor Node) — es una prueba real de encode→decode→pintar, no una imagen estática

### 3.3 Panel de Informe (solo si el rol lo permite)
- Gating real por rol: solo `t_med_radiologo` y `t_tec_imagen_coord` ven "Abrir informe"/"Validar y firmar" — el resto ve el motivo explícito
- Datos del paciente y estudio a la mano (RUT, edad, código de examen, procedencia, médico solicitante)
- Botón "Ver orden médica" (verifica lo vendido vs. lo que se está informando)
- Patología crítica que requiere notificación, Horario (Hábil/Inhábil), Título editable
- Comentario TM (de la Worklist) + Antecedentes Clínicos como campos separados
- **CIE-10 en dos ubicaciones separadas** (Indicación clínica al inicio, Conclusión codificada al final de Impresión) — siguiendo el estándar chileno real que el usuario investigó y compartió; nunca códigos dentro del cuerpo de Hallazgos
- Multibox de CIE-10 con búsqueda por texto, usando una muestra verificada (no inventada) de códigos reales: M54.x, M51.x, M1[5-9].x, R90-R94 completo
- Plantillas privadas por radiólogo — cargar y **guardar nuevas** desde la sesión
- **Dictado por voz real** (Web Speech API nativo del navegador) en Técnica/Hallazgos/Impresión — transcribe de verdad. Producción: reemplazar por Whisper large-v3 autoalojado (decisión del usuario, con `initial_prompt` de vocabulario radiológico) detrás del mismo botón

### 3.4 Sesión y roles (§ alineado con MAIN — ver sección 5)
- Selector de sesión (`SESIONES_DEMO`) — **temporal, solo para pruebas**. En producción, `sesión` sale del login (OAuth2/OIDC), no de un dropdown.
- IDs de rol reales copiados de `roles.config.js`: `t_med_radiologo`, `t_tec_imagen_coord`, `t_tec_imagen`, `t_tec_imagen_tens`
- Auditoría con nombres de evento reales de `security.config.js` (`view_imaging_report`, etc.)

---

## 4. Hallazgos de investigación verificados en esta sesión (no inventados)

| Dato | Verificado contra | Uso en el proyecto |
|---|---|---|
| Ley 21.719 reemplaza a Ley 19.628, vigencia plena 1-dic-2026 | Búsqueda web | Cambia el cronograma de cumplimiento del roadmap original |
| SOP Class UIDs de Storage (CT, MR, US, CR/DX, MG, XA, NM, PT) | ZIP oficial DICOM 2026c (dicomstandard.org) | `AssociationServer.js` → `STORAGE_SOP_CLASSES` |
| Tags de Modality Worklist (Patient Name 0010,0010; Accession Number 0008,0050; Scheduled Station AE Title 0040,0001; etc.) | ZIP oficial DICOM 2026c, Anexo K de PS3.4 | `_handleCFindWorklist()` |
| Fórmulas Cockcroft-Gault y Schwartz (clásica + bedside 2009) | Fuentes clínicas actuales | Calculadora de función renal en Worklist |
| Umbrales ACR 2025 / ESUR de contraste (eGFR<30, <45) | Guías actuales | Contexto de alerta en la calculadora |
| CIE-10 R90-R94 y M15-M54 | CSV oficial que el usuario adjuntó + verificación web cruzada | `CIE10_MUESTRA` |
| `t_med_radiologo`, `t_tec_imagen_coord`, `t_tec_imagen_tens` | `roles.config.js` real del proyecto MAIN | Gating de permisos del Informe |

---

## 5. Alineación con el proyecto MAIN — qué se hizo, qué falta

**Hecho:**
- Roles de sesión y gating de "Abrir informe/Validar" migrados a IDs reales de `roles.config.js`
- Nombres de eventos de auditoría alineados a `security.config.js` (`audit.criticalEvents`)
- CUP y formato de OT/ACC alineados al formato real (`CUP-{PAÍS}-{REGIÓN}-{AÑO}-{SEQ8}-{CHK}`)
- EventBus con la misma firma (`publish`/`EVENTS`) que el real

**Pendiente — archivos ya recibidos pero no procesados todavía:**
- `security_config.js` completo — falta que `puedeInformar` termine llamando algo equivalente a `canAccessClinicalRecord()` en vez de comparar directo contra `ROLES_INFORMANTES`
- `userTypes_config.js` (actualizado) — no revisado aún en esta sesión
- `AXON_Infraestructura_TLS_AES256.zip` — no abierto todavía
- `tenantTypes.config (1).js` (20 tipos) — revisado, no hay acción pendiente específica para RIS/PACS (multi-tenant ya asumido desde el diseño)

**Pendiente — de la captura real de otro RIS/PACS (Informar Examen):**
- Convertir "Ver estudios previos" de modal a sidebar siempre visible (hoy sigue siendo modal con estado vacío honesto)
- Iconos de acceso rápido/macros sobre el campo Hallazgos (se vieron en la captura, no replicados aún)

---

## 6. Próximos pasos sugeridos, en orden

1. Terminar la alineación con `security.config.js` (§5) — es la pieza que falta para decir que el módulo está "main-ready" en materia de permisos.
2. Revisar `userTypes_config.js` actualizado y el zip de TLS/AES256.
3. Sidebar de estudios previos (layout, no lógica nueva).
4. Conectar `dcmjs` de verdad (`npm install dcmjs`) — hoy el motor detecta su ausencia y sigue funcionando en modo degradado honesto.
5. Endpoint `WADO-RS /rendered` (JPEG/PNG) para que un visor externo no necesite decodificar DICOM él mismo.
6. Ingreso manual de paciente + flujo de bono/pago en Admisión (del dossier de ampliación, sección aún no tocada).
7. Cuando el motor tenga datos volumétricos reales: activar las 3 puertas etiquetadas del visor (MPR, Cobb, Fusión PET-CT).

---

## 7. Cómo continuar en una sesión nueva

Pegar este documento completo al inicio de la conversación nueva, junto con `HIS-RIS-PACS.jsx` y la carpeta `dicom-engine/`. Con eso, cualquier sesión (o persona) tiene el contexto completo sin releer el historial.
