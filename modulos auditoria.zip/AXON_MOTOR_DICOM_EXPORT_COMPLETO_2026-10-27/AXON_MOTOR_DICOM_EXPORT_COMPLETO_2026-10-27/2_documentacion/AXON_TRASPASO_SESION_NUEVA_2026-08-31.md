# AXON Motor DICOM — Documento de Traspaso a Sesión Nueva
## Generado al cierre de esta sesión (26/31-ago-2026) — leer esto PRIMERO en el chat nuevo, junto con el dossier maestro

**Qué es esto:** no repite el detalle técnico — para eso está `AXON_MOTOR_DICOM_Mapa_y_Estado_Verificado_2026-08-25.md` (17 secciones, la fuente completa). Esto es solo: qué pasó en resumen, qué archivo hacer con cada archivo antes de empezar la sesión nueva, y cómo arrancarla.

---

## 1 · Resumen de lo que se hizo en esta sesión (detalle completo en el dossier maestro)

1. Se verificó el motor completo corriendo la suite real (no solo leyendo) — se encontraron y corrigieron 2 archivos de prueba dañados por el panel de subida del proyecto.
2. Se construyó el puente real Worklist↔Motor que no existía: `WorklistStore.js` + `WorklistApiServer.js` (API HTTP) — probado en ambas direcciones contra DIMSE real.
3. Se cableó `HIS-RIS-PACS.jsx` para hablar con esa API real, reemplazando el `useState` local — con pantallas de carga/error reales, sin ninguna simulación.
4. Se evaluó un documento externo de arquitectura (recibido durante la sesión) y se integró como §14 del dossier maestro — no se creó un dossier aparte.
5. Se corrigió el bug de VR length/Accession Number (17 caracteres en un campo de máximo 16) — confirmado independientemente por ese mismo documento externo.
6. Se construyó `TransferSyntaxRegistry.js` — reemplaza el ternario hardcodeado que elegía codec.
7. Se encontraron y corrigieron 3 bugs reales en el camino (tipos de id inconsistentes, una carrera entre el update optimista y el polling, y un problema de exports vacíos con `"type":"module"`), más una falla intermitente de test resuelta con un patrón de reintento (`clickResiliente`).
8. El sandbox se reinició **dos veces** durante la sesión — ambas veces se reconstruyó todo desde los archivos ya guardados; nada de código de producción se perdió, solo trabajo reciente sin guardar todavía (ver §6 de este documento).

**Estado final verificado:** motor 9/9 archivos de test en verde, frontend 5/5 en verde (confirmado con 12 corridas seguidas sin fallas), `esbuild` compila el bundle completo sin warnings.

---

## 2 · Acción sobre archivos — REEMPLAZAR (mismo nombre en el proyecto, versión vieja ya no sirve)

Verificado uno por uno contra lo que hay HOY en el proyecto (no supuesto) — estos 10 están desactualizados:

| Archivo | Por qué la versión del proyecto ya no sirve |
|---|---|
| `AeRegistry.js` | No tiene la referencia a `TransferSyntaxRegistry` |
| `AssociationServer.js` | Tiene el cableado de `WorklistStore` (§11-12) pero NO el refactor de `TransferSyntaxRegistry` (§16) |
| `ImplicitVrCodec.js` | No tiene la validación de longitud de VR |
| `ExplicitVrCodec.js` | No tiene la validación de longitud de VR |
| `WorklistStore.js` | No tiene la función `upsert()` |
| `package.json` (el del motor) | Solo tiene 6 tests en la cadena, faltan `worklist-api`, `worklist-client`, `vr-limits` |
| `README.md` | No documenta `WorklistApiServer` ni `TransferSyntaxRegistry` |
| `HIS-RIS-PACS.jsx` | Es la versión SIN cablear — sigue con `useState` local, no habla con la API |
| `HIS-RIS-PACS_interaction_test.jsx` | Es la versión vieja (4 tests, asume datos síncronos) — la nueva tiene 5, contra la API real |
| `AXON_MOTOR_DICOM_Mapa_y_Estado_Verificado_2026-08-25.md` | Le faltan las secciones 14 a 17 (todo desde la evaluación del documento externo en adelante) |
| `consentimiento_prueba.pdf` | Sigue siendo el ZIP disfrazado de PDF, no el PDF real (ver §4) |

## 3 · Acción sobre archivos — AGREGAR (nunca existieron en el proyecto)

| Archivo | Qué es |
|---|---|
| `VrLimits.js` | Tabla de longitud máxima por VR + validación |
| `TransferSyntaxRegistry.js` | Registro real de Transfer Syntax → codec |
| `WorklistApiServer.js` | API HTTP sobre el Worklist |
| `worklist-api.e2e.test.js` | Test de la API HTTP (10 checks) |
| `worklist-client.test.js` | Test del cliente de datos del frontend (7 checks) |
| `vr-limits.test.js` | Test de la validación de VR (8 checks) |
| `WorklistClient.js` | Capa de datos del frontend — habla con la API |

**Sobre nombres de archivo repetidos:** el frontend tiene su propio `package.json` y su propio `vitest.config.mjs`, separados a propósito del `package.json` del motor (son dos árboles de dependencias distintos — ver §13 del dossier maestro). Como el proyecto sube todo plano (sin carpetas), **subilos con nombre distinto** para que no choquen con el `package.json` del motor:
- El `package.json` del frontend → subir como **`frontend-package.json`**
- El `vitest.config.mjs` del frontend → subir como **`frontend-vitest.config.mjs`**

Cuando alguna sesión necesite correr de verdad el frontend, hay que renombrarlos de vuelta a `package.json`/`vitest.config.mjs` dentro de su propia carpeta — dejá esto anotado para esa sesión, no hace falta resolverlo ahora.

## 4 · Atención especial — archivos que solo subiste al CHAT, no al proyecto

Estos 4 no van a estar disponibles en la sesión nueva a menos que los subas al PROYECTO (no alcanza con haberlos subido acá, a este chat — un chat nuevo no ve los archivos de este chat, aunque esté en el mismo proyecto):

| Archivo | Estado |
|---|---|
| `CT_small.dcm` | La versión buena (39.206 bytes, DICOM real verificado) — la que está en el proyecto sigue corrupta |
| `MR_small.dcm` | Nunca llegó al proyecto — solo existe en lo que subiste a este chat |
| `consentimiento_prueba.pdf` | La versión buena (1.754 bytes, PDF real) — la del proyecto sigue siendo el ZIP |
| `AXON_DICOM_Dossier_Maestro_Arquitectura_Implementacion_Interoperabilidad_v1_0.docx` | El documento externo que evaluamos — su contenido ya quedó destilado en el dossier maestro §14, así que no es obligatorio volver a subirlo, pero si querés tenerlo disponible para releerlo directo, hace falta subirlo al proyecto aparte |

**Importante:** subir binarios (`.dcm`, `.pdf`) por el panel de archivos del proyecto ya los corrompió dos veces en esta sesión. Lo que funcionó fue adjuntarlos directo a un mensaje del chat — probá subirlos al proyecto de la misma forma si el panel de "agregar archivos" del proyecto lo permite; si no, subilos como adjunto al primer mensaje de la sesión nueva (recordá pedirle a Claude que los guarde en el proyecto o que los use así, según corresponda) y avisá si el panel los sigue dañando.

## 5 · Sin cambios — no hace falta tocarlos

Todo lo demás del proyecto sigue vigente tal cual: `PDU.js`, `DimseCommand.js`, `PngEncoder.js`, `RenderInstance.js`, `DicomWebServer.js`, `CStoreDataset.js`, `StudyIndex.js`, `EncapsulatedDocument.js`, los 5 tests que no cambiaron (`explicit-vr_e2e_test.js`, `render_e2e_test.js`, `real-dicom-explicit-vr_e2e_test.js`, `encapsulated-pdf_e2e_test.js`, `engine_e2e_test.js`), `worklist-store_e2e_test.js` (confirmado idéntico, 195 líneas en ambos lados), `EquipmentConfigPanel.jsx`, y todos los dossiers históricos (Dossier Maestro original, las 5 Adendas, Ampliación, Especificación Técnica, Sincronización con MAIN, y los documentos de otros módulos satélite).

**Limpieza opcional, de baja prioridad, ya sugerida desde el dossier original:** `bosquejo_visualizador_pantalla_completa.html` sigue marcado como histórico/archivable desde la primera sesión — se puede borrar si querés, no es urgente. `package-lock.json` del motor quedó desactualizado respecto al `package.json` nuevo — no es necesario para nada de lo documentado, se puede regenerar corriendo `npm install` cuando haga falta.

**Nota aparte, no bloqueante:** `AXON_MOTOR_DICOM_Especificacion_Tecnica.md` (la referencia técnica para otros equipos) sigue siendo válida pero ya no está 100% completa — no menciona la API del Worklist ni `TransferSyntaxRegistry`. Podría actualizarse en alguna sesión futura si otro equipo satélite la va a consultar pronto; no es parte de lo pendiente inmediato.

---

## 6 · Sobre los 2 reinicios de sandbox de esta sesión

El entorno de trabajo se reinició dos veces sin aviso durante esta sesión (es una característica conocida del sandbox, no un error puntual). Las dos veces se pudo reconstruir todo sin pérdida real porque los archivos ya estaban guardados como descargas — pero la lección que vale la pena que la sesión nueva tenga presente desde el principio: **guardar (presentar como archivo descargable) cada pieza de trabajo apenas queda terminada, no al final de un tramo largo.** Si estás por pedirle a la sesión nueva que haga un cambio de varios pasos, vale la pena pedirle explícitamente que vaya guardando de a uno.

---

## 7 · Cómo arrancar la sesión nueva

1. Asegurate de que los archivos de §2 y §3 ya estén reemplazados/agregados en el proyecto (y §4 si conseguiste subir los binarios).
2. Abrí un chat nuevo dentro de este mismo proyecto.
3. Pegá algo como: *"Continuamos el Motor DICOM de AXON. Leé el dossier `AXON_MOTOR_DICOM_Mapa_y_Estado_Verificado_2026-08-25.md` completo (17 secciones) para el estado real verificado, y este documento de traspaso para lo que falta. El próximo paso sugerido es RLE end-to-end (§14.7 del dossier), pero confirmame antes de empezar."*
4. La sesión nueva no tiene memoria de esta conversación — todo lo que necesita saber tiene que estar en los archivos del proyecto, no en lo que se habló acá.

## 8 · Próximo paso sugerido (sin decidir nada por vos)

Según el propio orden del documento externo evaluado en §14 del dossier maestro, con VR length/Accession Number ya cerrado (§15) y `TransferSyntaxRegistry` ya construido (§16), el siguiente ítem natural es **RLE end-to-end** — el primer codec comprimido real, ya identificado como el candidato más simple (compresión sin pérdida a nivel de imagen, sin códec de video de por medio). No es la única opción — los 6 gaps de UI de §4 del dossier siguen abiertos y ahora se pueden cerrar directo contra la API real, sin migrar nada después.
