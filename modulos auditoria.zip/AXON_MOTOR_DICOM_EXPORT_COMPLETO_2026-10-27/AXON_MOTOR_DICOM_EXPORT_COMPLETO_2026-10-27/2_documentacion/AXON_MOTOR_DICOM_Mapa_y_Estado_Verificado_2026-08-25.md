# AXON RIS/PACS — Mapa de Lectura + Estado Real Verificado
## Sesión 25-ago-2026 — leer junto con (no en vez de) los dossiers anteriores

**Qué es esto:** el punto de entrada de hoy. No repite el detalle técnico que ya está bien documentado en las Adendas — para eso, sigan siendo la fuente. Esto es: qué está vigente y qué es histórico, y sobre todo, **qué se verificó de verdad esta sesión corriendo la suite de tests real** (`npm test`, archivo por archivo, con `dcmjs`/`pngjs` reales instalados), no repitiendo de memoria lo que decían las Adendas.

**Contexto de esta sesión:** llegué con los ~40 archivos del proyecto — dossiers propios, código del motor, `HIS-RIS-PACS.jsx`, y los documentos de otros módulos satélite que subiste para contexto (Arquitectura de Interoperabilidad Nacional, Sincronización con Satélites/MAIN, Hoja de Ruta Backend MAIN, Portal Paciente, Consentimiento/Investigación). Ya los leí todos. Antes de proponer próximos pasos, verifiqué lo verificable.

---

## 1 · Mapa de lectura

### 1.1 Corrección de fechas (para que no confunda)
La Adenda `..._ADENDA_2026-07-20.md` ("Adenda 1") está fechada 20-jul-2026, pero la propia Adenda 2 (`..._2026-07-21.md`) aclara en su texto que la fecha real de esa sesión fue 21-jul-2026 — Adenda 2 es continuación directa el mismo día, no una sesión aparte. No cambia el contenido, solo el orden si alguna vez importa la cronología exacta.

### 1.2 Histórico — no hace falta releer para trabajar hoy
- `AXON_Dossier_RISPACS_Ampliacion.md` (06-jul) — 13 puntos originales. Ver §4 abajo: 7 cerraron, 6 no.
- `AXON_DOSSIER_MAESTRO.md` (corte 17-jul) — bastante desactualizado ya (dice "no probado" en cosas que hoy sí lo están). Su §1 (filosofía del proyecto) sigue vigente palabra por palabra.
- Las 5 Adendas (07-20 / 07-21 / 07-21-b / 07-23 / 07-31) — cada una documentó bien su sesión; quedan como archivo histórico de decisiones, no hace falta releerlas para saber el estado actual.

### 1.3 Vigente — los documentos "vivos" que ya cumplen el rol de sincronización que pediste
- **`AXON_MOTOR_DICOM_Especificacion_Tecnica.md`** (31-jul) — referencia técnica oficial para otros equipos. Sigue correcta.
- **`AXON_Sincronizacion_Main_Discrepancias.md`** (31-jul, con §E del 16-ago) — documento vivo de sync con MAIN. Es el que hay que seguir actualizando, no reemplazar.

Este documento es un tercero: no compite con esos dos, agrega el chequeo empírico de hoy.

---

## 2 · Lo primero que hice: correr la suite de tests real

Los archivos habían llegado planos al proyecto (`PDU.js`, `AssociationServer.js`, etc. sueltos), no en la estructura `dicom-engine/src/pdu/`, `src/server/`... que el propio código espera vía `require()`. Reconstruí esa estructura, corrí `npm install` (Node v22.22.2 en este sandbox — cumple el `>=22.13` que pide `dcmjs`; instaló `dcmjs`+`pngjs` reales, no mocks), y corrí los 5 archivos de test **por separado** (no encadenados con `&&`, para ver los 5 resultados aunque alguno falle).

| Archivo | Resultado | Nota |
|---|---|---|
| `engine.e2e.test.js` | ✅ **12/12** | Datos sintéticos. Asociación, C-ECHO, C-FIND/MWL con secuencia anidada, C-STORE, Part10 válido, StudyIndex con dcmjs real, QIDO-RS, WADO-RS |
| `render.e2e.test.js` | ✅ **8/8** | Datos sintéticos. Windowing, CRC32 contra el vector de referencia PNG oficial, pipeline completo decodificado con pngjs, 422 explícito para RGB |
| `explicit-vr.e2e.test.js` | ✅ **5/5** | Resuelto — ver actualización en §3. `CT_small.dcm`/`MR_small.dcm` reales, subidos de nuevo directo al chat, decodifican Rows/Columns/Modality exacto |
| `real-dicom-explicit-vr.e2e.test.js` | ✅ **5/5** | Resuelto. C-STORE genuino de `CT_small.dcm` vía DIMSE, dataset guardado (38.870 bytes) idéntico byte a byte al original, `/rendered` real (12.340 bytes PNG) |
| `encapsulated-pdf.e2e.test.js` | ✅ **10/10** | Resuelto. PDF real (1.754 bytes) encapsulado, C-STORE, extracción byte a byte idéntica, QIDO-RS con 2 series bajo el mismo Study Instance UID, `/rendered` 422 para el documento |

**Total: 40 de 40 checks pasan — el 100% que reclama el README, confirmado hoy, no de memoria.** Historial: los 3 últimos fallaban al principio de la sesión por archivos de prueba dañados (§3), no por bugs de código; se resolvió subiendo los archivos de nuevo directo al chat en vez de por el panel de archivos del proyecto.

---

## 3 · Hallazgo (RESUELTO en esta misma sesión): los 2 archivos binarios de prueba no habían llegado bien al proyecto

Esto era lo que ya sospechabas en tu punto 2 ("el zip no me permite subirlo... 1 o 2 archivos dicom de prueba tampoco me permitió") — lo confirmé con precisión de bytes, en los archivos que estaban en `/mnt/project/`:

| Archivo | Qué debería ser | Qué era en `/mnt/project/` |
|---|---|---|
| `CT_small.dcm` | DICOM Part10 real (pydicom test files): 128 bytes en `0x00` + `"DICM"` en offset 128 | **Corrupto.** El offset 128 no decía `DICM`. El patrón de bytes (secuencias UTF-8 válidas de 3 bytes, repetidas) era consistente con que el binario pasó en algún momento por una conversión a texto que lo dañó |
| `MR_small.dcm` | DICOM Part10 real | **No estaba.** No existía en el proyecto bajo ningún nombre |
| `consentimiento_prueba.pdf` | PDF real (generado con reportlab, según Adenda 5) | **No era un PDF.** Era un ZIP (`PK\x03\x04`) con `1.jpeg` + `1.txt` + `manifest.json` — forma de caché interna de una conversión PDF→imagen |

**Por qué esto nunca fue un bug del motor:** en los mismos tests, todo lo que NO dependía de estos 3 archivos pasaba limpio — incluida la parte más delicada (SQ de longitud indefinida armada a mano, byte a byte). El motor fallaba explícito con el motivo (`"pdfBytes no parece un PDF válido..."`), no en silencio — el mismo principio de puerta etiquetada del resto del proyecto.

**Resuelto:** subiste los 3 archivos de nuevo, esta vez directo a un mensaje del chat en vez del panel de archivos del proyecto. Verifiqué a nivel de bytes que llegaron íntegros — `CT_small.dcm` (39.206 bytes) y `MR_small.dcm` (9.830 bytes) con el preámbulo de 128×`0x00` + `"DICM"` correcto, `consentimiento_prueba.pdf` (1.754 bytes) empezando en `%PDF-1.3` real. Los metadatos que salieron al decodificarlos (`PatientName: CompressedSamples^CT1`, UIDs con prefijo `1.3.6.1.4.1.5962...`) confirman que son los fixtures reales y estándar del repositorio de pydicom, no sustitutos. Con estos 3 archivos, los 5 tests pasan 40/40 (§2) — Explicit VR y el consentimiento encapsulado quedan re-confirmados contra datos reales, no solo contra la lógica propia.

**Para que no se repita:** el panel de archivos del proyecto parece corromper o sustituir archivos binarios (al menos `.dcm` y en este caso el `.pdf`); subir directo a un mensaje del chat sí preservó los bytes. Si en algún momento quieren que estos 3 archivos queden disponibles para una sesión nueva sin tener que volver a subirlos al chat, probablemente valga la pena intentar agregarlos al proyecto por ese mismo camino (chat → proyecto) en vez del panel de carga directa, o avisarme si vuelve a pasar para diagnosticarlo de nuevo.

---

## 4 · Hallazgo: 6 puntos de Ampliación (06-jul) que siguen sin cerrar en `HIS-RIS-PACS.jsx`

Leí el `HIS-RIS-PACS.jsx` que está en el proyecto hoy buscando cada función que las Adendas dicen haber cerrado. La mayoría de los 13 puntos del dossier de Ampliación sí están — pero encontré 6 que el código no respalda, y que no aparecen marcados como pendientes en ninguna Adenda posterior (es decir, es fácil perderlos de vista):

| § Ampliación | Qué pedía | Qué hay hoy en el código |
|---|---|---|
| §1 | `tomarPaciente()` debe bifurcar según el rol de quien ejecuta (auto-registro si es TM, selector si es TENS/admin) | No existe esa función. La asignación de TM es un `<StaffSelect>` genérico — no lee `sesión.rol` para decidir comportamiento |
| §2 | Selector de Prioridad editable en el panel de detalle (ya marcado como "gap a cerrar" en el dossier original) | Sigue siendo solo lectura (`<PrioTag>`). No hay `setPrioridad` ni `onChange` en ningún lado |
| §3 | Al validar consentimiento: mostrar firma FES + encuesta clínica + antecedentes de alergia, no un solo click | `toggleConsentimiento(id)` sigue siendo un botón booleano simple (la propia Adenda 5 lo confirma de paso, al hablar de consentimiento de doble firma: *"hoy solo existe un campo booleano y un checkbox de validación"*) |
| §4 | Campo de anamnesis, editable por el TM durante la atención | `record.anamnesis` existe y se **muestra** en el panel de Informe si tiene contenido, pero no hay ningún `<textarea>` en la Worklist que permita escribirlo — nace vacío y no hay forma de que deje de estarlo desde la interfaz |
| §5a | Selector de medio de contraste (lista `MEDIOS_CONTRASTE`) antes de los 4 campos clínicos | El array y el campo `medioContraste` existen en el modelo, pero no hay ningún `<select>` que los use — el grid de Worklist solo tiene los 4 `MiniField` (creatinina/talla/peso/contraste ml) |
| §5b | Calculadora de función renal **en tiempo real**, con aviso visual bajo umbral ACR/ESUR | `calcularFuncionRenal()` existe, está bien escrita, y se verificó contra casos de referencia a mano (Adenda 20-jul) — pero **nunca se llama** desde ningún lado del componente. Hoy no hay ningún resultado visible en el panel de detalle |

**Para que quede balanceado:** de los 13 puntos, estos 6 son los únicos abiertos. Los otros 7 (timestamps múltiples, ACC/OT, selector de fecha, ingreso manual, bono/pago con sus 3 sub-casos, categorías clínicas configurables, y la corrección del flujo automático a PACS) están cerrados y verificados en el código — varios con tests de interacción reales (`HIS-RIS-PACS.interaction.test.jsx`, 4 tests — confirmé que existen y su forma, no los corrí hoy porque montar Vitest+React+jsdom es un setup más largo; lo hago si lo quieren como próximo paso).

---

## 5 · Estado consolidado del motor — con lo de hoy incorporado

| Capacidad | Estado | Nota de hoy |
|---|---|---|
| C-ECHO / C-FIND (MWL) / C-STORE | ✅ Probado | Confirmado de nuevo hoy (`engine.e2e.test.js`, 12/12) |
| Implicit VR LE | ✅ Probado | Sin cambios |
| Explicit VR LE | ✅ Probado, incluido con DICOM real | Re-confirmado hoy contra `CT_small.dcm`/`MR_small.dcm` reales vía C-STORE genuino — dataset idéntico byte a byte (§3) |
| Transfer Syntax comprimida (JPEG/JPEG2000) | ❌ No soportado | Sin cambios — sigue siendo la brecha #1 según `AXON_Arquitectura_Interoperabilidad_Nacional.md` |
| QIDO-RS / WADO-RS | ✅ Probado | Confirmado de nuevo hoy |
| WADO-RS `/rendered` | ✅ Probado | Confirmado de nuevo hoy (`render.e2e.test.js`, 8/8, incluye el caso 422 para RGB) |
| Multiframe / color | ❌ No soportado | Puerta etiquetada, sin cambios |
| MPPS | ❌ No implementado | Puerta etiquetada, sin cambios |
| Encapsulated PDF (consentimiento) | ✅ Probado, incluido con PDF real | Re-confirmado hoy: PDF real embebido y extraído byte a byte idéntico, 2 series bajo el mismo Study Instance UID (§3) |
| Video Photographic Image | ❌ Fuera de alcance | Aclarado 16-ago: es una IOD distinta, necesita compresión primero |
| Worklist (4 pestañas, máquina de estados, bono/pago, ingreso manual) | ✅ Construido y verificado | Sin cambios |
| Visor DICOM pantalla completa | ✅ Construido y verificado | Sin cambios (los 7 bugs de Adenda 4 siguen corregidos) |
| Panel de Informe | ⚠️ Construido, con 6 gaps reales | Ver §4 — nuevo hallazgo de hoy |
| `EquipmentConfigPanel.jsx` | Construido, no probado en navegador real | Sin cambios |

---

## 6 · Bloqueado — sin cambios respecto al 31-jul / 16-ago

Sigue exactamente igual que en `AXON_Sincronizacion_Main_Discrepancias.md` §A — lo repito acá solo para no tener que abrir ese archivo:

| Falta de MAIN | Para qué |
|---|---|
| `security_config.js` completo | `puedeInformar` debería llamar `canAccessClinicalRecord()` real |
| `roles.config.js` (en preparación activa) | Re-confirmar los IDs de rol que usamos hoy (`t_med_radiologo`, etc.) |
| `userTypes_config.js` actualizado | TENS no existe como tipo formal; "radiologo" sigue colgado de tecnólogo, no de médico |
| `AXON_Infraestructura_TLS_AES256.zip` | TLS en el motor sigue opcional |
| `AXON_Actualizacion_Roles_Modulos_Satelite.md` | Nunca llegó a subirse |

Según `AXON_Hoja_de_Ruta_Backend_MAIN (5).md` (16/20-ago), MAIN todavía está en su Fase 1 (cerrar un solo loop end-to-end con Convenios/CUC) — Keycloak (identidad real) es Fase 2. Es coherente que estos archivos sigan sin llegar; no parece un olvido, es que MAIN todavía no está ahí.

---

## 7 · Lo que aprendí de los módulos satélite que nos toca directo a nosotros

- **Discrepancia de formato de CUP — nos afecta a nosotros también, no solo a los satélites de Agenda.** `Sincronizacion_Satelites_MAIN.md` §1.1 encontró que `security.config.js` documenta el CUP con 3 segmentos (`CUP-XXXX-XXXXXXX-XX`), pero los módulos satélite generan 5 (`CUP-{PAÍS}-{REGIÓN}-{AÑO}-{SEQ8}-{CHK2}`). **`makeCUP()` en `HIS-RIS-PACS.jsx` usa el mismo formato de 5 segmentos** — si el comentario de `security.config.js` resulta ser la fuente de verdad real, nuestro generador también está en el formato equivocado, no es un problema exclusivo de Agenda. Vale la pena preguntarlo junto con lo demás que está pendiente de `cup.js`.
- **Explicit VR ya no es la prioridad #1 del motor** — `AXON_Arquitectura_Interoperabilidad_Nacional.md` (25-jul) lo marcaba como tal, pero eso fue antes de la Adenda 5 (31-jul). Con Explicit VR cerrado, la siguiente brecha que ese mismo documento identifica como la que más limita conectar equipo real es **Transfer Syntax comprimida (JPEG2000)**.
- **Contrato de integración con Agenda Web, confirmado en ambas direcciones:** una cita externa crea un registro con `fase: "agendados"`, mismo molde que "Ingreso manual" usa para `fase: "admision"`; ACC/OT quedan en `null` hasta Admisión — confirmado línea por línea contra `HIS-RIS-PACS.jsx` real en `Sincronizacion_Satelites_MAIN.md` §3.1.
- **Aclaración arquitectónica (16-ago, en el propio doc de sync):** la Agenda de citas NO nace del Motor DICOM — es una capacidad genérica de HIS/AXON-Core. El Motor solo se conecta vía MWL una vez que la cita ya existe y de verdad produce contenido DICOM. Relevante si en algún momento alguien propone que construyamos algo de agenda desde acá — no correspondería.
- **Cruce con el dossier de Consentimiento/VFG (`Dossier_Maestro_AXON_Consentimiento...v3.docx`):** buena noticia — nuestras fórmulas de Cockcroft-Gault y Schwartz bedside 2009 coinciden con las que ese dossier documenta por separado como "implementación legado a preservar". Y su §24 ("DICOM nativo, Study Instance UID y Documentos") describe exactamente el mecanismo que ya construimos en la Adenda 5 (Encapsulated PDF compartiendo Study Instance UID con las imágenes). Sin acción pendiente, solo confirma que vamos alineados con lo que ese equipo está especificando aparte.
- **MINSAL NID:** `AXON_Arquitectura_Interoperabilidad_Nacional.md` recomienda que el modelo de paciente nazca compatible con el perfil `MINSALPaciente` desde ya. No nos toca construir el modelo de paciente a nosotros, pero si en algún momento el motor genera o recibe identificadores de paciente, vale la pena tenerlo presente.

---

## 8 · Próximos pasos posibles — para decidir juntos, no elijo yo solo

~~Volver a subir los 3 archivos binarios~~ — **hecho, ver §3.** Motor al 100% verificado con datos reales. Quedan 5 caminos, ninguno depende de archivos de MAIN que no tenemos (siguen bloqueados igual, §6). No son mutuamente excluyentes:

1. **Cerrar los 6 gaps de UI de §4** en `HIS-RIS-PACS.jsx` — trabajo autocontenido, no depende de nadie más. El más rápido de los 6 es probablemente conectar `calcularFuncionRenal()` a la UI (la función ya existe y está probada, solo falta invocarla y mostrar el resultado).
2. **Empezar Transfer Syntax comprimida (JPEG2000/RLE)** en el motor — la brecha que el propio análisis de interoperabilidad nacional marca como la que más limita conectar equipo real hoy. Es trabajo de motor puro, no depende de MAIN.
3. **Preguntar por la discrepancia de formato de CUP** (§7) — antes de seguir generando CUPs con el formato de 5 segmentos si el de 3 segmentos de `security.config.js` resulta ser el real.
4. **Correr `HIS-RIS-PACS.interaction.test.jsx`** con el setup completo (Vitest + RTL + jsdom) para verificar con evidencia, no solo lectura, que los 7 puntos cerrados de Ampliación siguen sanos.
5. **Probar `EquipmentConfigPanel.jsx` en navegador real** — pendiente desde el dossier original, nunca se hizo. Vale recordar: la última vez que se hizo esto con `HIS-RIS-PACS.jsx` (Adenda 4), aparecieron 7 bugs reales que ni la lectura de código ni los tests automatizados habían detectado — este panel corre el mismo riesgo real, no es solo un checkbox pendiente.

Decime cuál priorizamos (o si es otro orden) y sigo por ahí.

---

## 9 · Corrección + propuesta: conectar de verdad el flujo Worklist ↔ Motor

### 9.1 Corrección a mi recomendación de §8 — tenías razón en parte

De los 6 gaps de §4, 2 sí están genuinamente bloqueados por cosas externas:
- **§1 (`tomarPaciente` por rol)** — bloqueado de verdad: necesita los IDs/comportamiento reales de `roles.config.js` (§6, sigue sin llegar de MAIN).
- **§3 (consentimiento con firma FES + encuesta + alergias)** — bloqueado en la práctica: necesitaría un modelo de datos para firma FES/encuesta/alergias que no existe en ningún lado todavía — no es un archivo que falte de MAIN, es diseño propio que nunca se hizo.

Los otros 4 **no** dependen de estudio ni de rol, se podrían cerrar hoy si volvemos a esto después:
- §2 (Prioridad editable) — un `onChange`, nada más.
- §4 (anamnesis) — un `<textarea>`, mismo caso.
- §5a (selector de medio de contraste) — el selector *manual* no depende del catálogo de exámenes; eso solo bloquea la parte *automática* (que decide sola si un examen requiere contraste), que la propia Ampliación marcó "pendiente de diseño" desde el 06-jul.
- §5b (calculadora renal en vivo) — la fórmula ya está hecha y probada, es cableado de UI puro.

### 9.2 Lo que encontré cuando pensé en "el flujo de RIS/PACS"

Hoy **no existe ningún camino real entre el Worklist de la interfaz y el motor DICOM** — son dos simulaciones que nunca se tocaron entre sí:

- **Lado UI:** `guardarYEnviar()` en `HIS-RIS-PACS.jsx` usa un `setTimeout(1400ms)` para fingir que el equipo mandó C-STORE. Ningún equipo ni motor de por medio.
- **Lado motor:** en los 5 archivos de test — y en cualquier uso real hoy — `worklistProvider` (la función que el motor llama para responder un C-FIND de Modality Worklist) siempre devuelve un array hardcodeado. Nunca lee el estado real del Worklist que se ve en pantalla.

El propio README del motor lo dice de pasada: *"`worklistProvider` es el punto de enganche con la Worklist real de AXON (hoy en React/useState, mañana en DatabaseService)"* — pero eso es literalmente imposible tal cual está hoy: `useState` vive en el navegador de quien tiene la pestaña abierta, el motor corre como proceso Node en el servidor. No hay puente entre esos dos mundos todavía.

Dónde SÍ hay un puente real ya construido y probado: la mitad de "recuperar imágenes" — QIDO-RS/WADO-RS lee del mismo `StudyIndex` que llena el C-STORE (verificado hoy, §2). La mitad que falta es la de "antes del examen": que el motor sepa en tiempo real quién está en la pestaña Worklist esperando ser escaneado, y que cuando llega un C-STORE real, se lo devuelva a la interfaz.

### 9.3 Propuesta concreta — para confirmar antes de empezar

Construir **`WorklistStore.js`** en el motor, mismo patrón que ya usa `StudyIndex.js` (JSON en disco, sin base de datos nueva, mismo estilo del resto del proyecto):

1. `WorklistStore.js`: `listar()` / `agregar(registro)` / `actualizar(id, cambios)`, persistido en JSON — igual forma que `StudyIndex`.
2. `worklistProvider` en `AssociationServer.js` deja de recibir un array fijo — pasa a leer `WorklistStore.listar()` filtrado por `fase === "worklist"`, de verdad.
3. `_handleCStore`, además de guardar la imagen, busca el registro de Worklist correspondiente (por Accession Number, que ya viaja en el C-STORE) y lo marca `fase: "examenes", estado: "almacenado"` — esto reemplaza al `setTimeout` falso de `guardarYEnviar()`.
4. Test end-to-end nuevo (mismo estilo que los otros 5): entra un paciente al `WorklistStore` → un equipo simulado hace C-FIND real y lo recibe → el mismo equipo hace C-STORE real → se verifica que `WorklistStore` marcó el registro como Almacenado solo, sin ningún timer falso de por medio.

Esto se puede construir y probar **enteramente del lado del motor**, sin tocar `HIS-RIS-PACS.jsx` todavía — mismo principio de ir de a un componente a la vez con red de seguridad. Una vez probado motor↔motor (sin UI de por medio), el segundo paso sería cablear `HIS-RIS-PACS.jsx` para que hable con este store en vez de su `useState` local — eso sí es un cambio más grande al componente principal, lo dejaría como paso aparte, después de confirmar que el primero funciona.

**Lo que sí te toca decidir a vos:** este `WorklistStore.js` sería, a propósito, un stub honesto — mismo principio que ya usan el `EventBus` y el check digit de CUP en el proyecto: forma y firma reales, para que cuando el `DatabaseService.js` de MAIN exista de verdad, cambiarlo sea una línea y no una reescritura.

---

## 10 · Video Photographic Image — verificado contra la fuente primaria (dicom.nema.org, edición 2026c)

Siguiendo tu indicación de ir a la fuente oficial y no a copias secundarias, verifiqué la IOD directo en NEMA/DICOM Standards Committee:

- **`A.32.7 Video Photographic Image IOD`** — descrita como "specifies the Attributes of VL Multi-frame photographic Images". Fuente: [sect_A.32.7.html](https://dicom.nema.org/medical/dicom/current/output/chtml/part03/sect_A.32.7.html).
- **23 módulos confirmados, contados uno por uno de la tabla oficial** (Patient, Clinical Trial Subject, General Study, Patient Study, Clinical Trial Study, General Series, Clinical Trial Series, Synchronization, General Equipment, General Acquisition, General Image, General Reference, Cine, Multi-frame, Image Pixel, Acquisition Context, Device, Specimen, VL Image, ICC Profile, SOP Common, Common Instance Reference, Frame Extraction) — coincide exacto con lo que ya decía Adenda 5. Fuente: [tabla A.32.7-1](https://dicom.nema.org/medical/dicom/current/output/chtml/part03/sect_A.32.7.3.html).
- **Modality obligatoria = `XC`** (External-Camera Photography) — dato que no teníamos documentado antes.
- **Cine (C.7.6.5) y Multi-frame (C.7.6.6) son módulos OBLIGATORIOS** — confirma con la fuente primaria que es un objeto de video/multi-cuadro real, categóricamente distinto de una imagen estática o de un documento encapsulado.
- **Hay una segunda IOD relacionada pero distinta:** `A.32.10 Real-Time Video Photographic Image IOD`, para streaming en vivo — no es lo mismo que un clip guardado. Si esto se retoma algún día, hay que decidir cuál de las 2 corresponde al caso de uso real antes de construir, no asumir que es la primera.

**Hallazgo nuevo que nuestros documentos anteriores no tenían:** verificando PS3.5 (Data Structures and Encoding), la lista de Transfer Syntax comprimidas registradas hoy es más larga que "MPEG-2/MPEG-4". El Anexo A.4 de la edición actual incluye, en orden: JPEG (A.4.1), RLE (A.4.2), JPEG-LS (A.4.3), JPEG 2000 (A.4.4), MPEG2 (A.4.5), MPEG-4 AVC/H.264 High Profile Level 4.1 (A.4.6) y 4.2 (A.4.7), MPEG-4 AVC/H.264 Stereo (A.4.8), **HEVC/H.265 Main Profile Level 5.1 (A.4.9) y Main 10 Profile Level 5.1 (A.4.10)** — HEVC/H.265 es una adición real que no estaba en lo que teníamos documentado. Si algún día se construye video de verdad, HEVC es el códec más moderno y eficiente de la lista completa, vale la pena tenerlo en el radar en vez de apuntar directo a MPEG-2 (el más antiguo, aunque sigue vigente en el estándar). Fuente: búsqueda cruzada contra PS3.5 Anexo A.4, dicom.nema.org.

**Confirma la recomendación de la sesión anterior:** de esta misma lista, RLE (A.4.2) sigue siendo la Transfer Syntax comprimida más simple — compresión sin pérdida a nivel de imagen, sin códec de video de por medio. Sigue siendo el candidato más razonable como primer paso real hacia "Transfer Syntax comprimida", antes de tocar cualquier códec de video (MPEG/HEVC).

**Conclusión honesta, sin cambios de fondo respecto a lo que ya decía la Especificación Técnica:** Video Photographic Image sigue bloqueado por la misma razón — necesita soporte de Transfer Syntax comprimida, que hoy no existe en el motor en absoluto. Lo nuevo de esta verificación es que ahora sabemos con precisión qué tan grande es el objeto (23 módulos reales, no una estimación) y que el abanico de códecs válidos es más amplio (y más moderno) de lo que pensábamos.

---

## 11 · `WorklistStore.js` — construido, cableado y probado hoy (26-ago-2026)

Se construyó lo propuesto en §9.3, tal cual se planteó:

- **`src/storage/WorklistStore.js`** (nuevo) — `listar()` / `listarPorFase()` / `agregar()` / `actualizar()` / `buscarPorAcc()`, persistido en JSON, mismo patrón que `StudyIndex.js`. Stub honesto a propósito, mismo principio que `EventBus`: forma y firma reales, para que cambiar a `DatabaseService.js` de MAIN cuando exista sea una línea, no una reescritura.
- **`AssociationServer.js` (modificado):**
  - `worklistProvider` ahora es opcional de verdad: si no se pasa uno explícito, el motor responde el C-FIND del Worklist con `WorklistStore.listarPorFase('worklist')` — datos reales, no un array de prueba.
  - `_handleCStore` busca el registro por Accession Number (el campo correcto según PS3.4 — el mismo que un equipo real copia de la respuesta MWL hacia su C-STORE) y lo marca `fase: "examenes", estado: "almacenado"` cuando corresponde. Esto es lo que reemplaza al `setTimeout` falso de `guardarYEnviar()` — del lado del motor.
  - Los 5 tests existentes pasan **sin ningún cambio** (los 5 siguen pasando su propio `worklistProvider`, así que nunca tocan el código nuevo) — regresión confirmada antes de escribir el test nuevo, no asumida.
- **`test/worklist-store.e2e.test.js`** (nuevo, 7 checks) — ciclo completo: un paciente se siembra en `WorklistStore` → un equipo simulado hace C-FIND real (sin `worklistProvider` de prueba) y recibe exactamente ese registro → el mismo equipo manda C-STORE real copiando el mismo Accession Number → se verifica, leyendo el store directo, que quedó `Almacenado` sin ningún timer de por medio → un segundo C-FIND confirma que el registro ya no aparece en el Worklist.

`npm test` corre ahora **6 archivos, 47 checks en total** — confirmado corriendo el comando completo, no archivo por archivo.

**Hallazgo aparte, documentado pero no corregido hoy (es trabajo de UI, no de motor):** el Accession Number que usó el test (`ACC00000099`, 12 caracteres) cabe en el límite de la VR `SH` (máximo 16 caracteres, PS3.5). El formato real que genera `makeACC()` en `HIS-RIS-PACS.jsx` (`ACC-2026-00000001`) tiene **17 caracteres** — excede ese límite. Hoy esto no rompe nada porque ni `ImplicitVrCodec.js` ni `ExplicitVrCodec.js` validan longitud de VR al codificar, pero un equipo DICOM real conforme al estándar podría truncar o rechazar el valor. Vale la pena corregir `makeACC()` cuando se retome trabajo de UI — no es parte de lo que se hizo hoy.

**Lo que sigue, y que es aparte:** `HIS-RIS-PACS.jsx` todavía no habla con este store — sigue con su `useState` local. Cablear eso es el segundo paso que ya se había anticipado en §9.3, y que se deja como tarea separada, después de esta confirmación de que el lado del motor funciona solo.

### Archivos entregados esta sesión (para agregar de vuelta al proyecto)

`WorklistStore.js`, `AssociationServer.js` (reemplaza al actual), `worklist-store.e2e.test.js`, `package.json` (reemplaza al actual — agrega el 6° test a la cadena), `README.md` (reemplaza al actual — documenta lo nuevo). Mismo aviso de la sesión anterior: si el panel de archivos del proyecto sigue corrompiendo o renombrando archivos, el método que funcionó hoy fue subirlos directo a un mensaje del chat.

---

## 12 · `WorklistApiServer.js` — el navegador ya puede hablarle al Worklist real (26-ago-2026)

Segundo tramo del mismo trabajo: `WorklistStore.js` le dio al motor un lugar real de dónde leer/escribir, pero es un archivo en disco — `HIS-RIS-PACS.jsx` corre en el navegador y no puede hacer `require('fs')`. Faltaba el puente HTTP.

- **`src/server/WorklistApiServer.js`** (nuevo) — `GET/POST /worklist`, `GET/PATCH /worklist/:id`, CORS abierto para desarrollo local (anotado como puerta etiquetada: restringir orígenes es tarea de producción, no resuelto en silencio). Sin Express, mismo estilo framework-agnostic que `DicomWebServer.js`.
- **A propósito NO se mezcló con `DicomWebServer.js`**: ese archivo implementa QIDO-RS/WADO-RS, el estándar DICOMweb real (PS3.18). Esta API de Worklist es invención propia de AXON, no protocolo estándar — separarlos deja esa distinción clara con solo mirar el nombre del archivo.
- **`test/worklist-api.e2e.test.js`** (nuevo, 10 checks) — CRUD HTTP básico (POST/GET/PATCH/404/400) y, lo que más importa, **integración real en ambas direcciones** contra un `AssociationServer` corriendo en paralelo sobre el mismo almacén:
  - **B.1 (API → DIMSE):** un registro creado por `POST /worklist` aparece en un C-FIND real, con los datos exactos.
  - **B.2 (DIMSE → API):** un C-STORE real marca "Almacenado" un registro, y `GET /worklist/:id` ya lo refleja — la API nunca lo tocó directo, fue el motor DIMSE solo.

Esto confirma que la API HTTP y el motor DIMSE comparten **una sola fuente de verdad**, no dos copias que se puedan desincronizar — la pregunta que de verdad importaba antes de construir nada más encima.

`npm test` corre ahora **7 archivos, 57 checks en total** — regresión de los 6 anteriores confirmada antes de escribir el test nuevo, no asumida.

### Archivos entregados esta sesión (actualización — reemplaza a la lista de §11)

`WorklistStore.js`, `WorklistApiServer.js`, `AssociationServer.js`, `worklist-store.e2e.test.js`, `worklist-api.e2e.test.js`, `package.json`, `README.md` — los 5 de §11 más estos 2 nuevos.

### Lo que sigue — y acá es donde el trabajo cambia de forma

Con esto, todo el lado del motor (DIMSE + HTTP) ya habla con una sola fuente de verdad real. Lo único que falta para que el "flujo de RIS/PACS" sea de punta a punta de verdad es **el lado de `HIS-RIS-PACS.jsx`**: hoy sigue con `useState(SEED)` local, nunca llamó a esta API.

Ese es un trabajo de otra naturaleza, no solo de otro tamaño:
- Toca casi todas las funciones de mutación del componente (`patch`, `setStaff`, `setClinico`, `avanzarAgendado`, `completarAdmision`, `guardarYEnviar`, `abrirInforme`, `validarInforme`, `ingresarBono`, `resolverBono`, `crearIngresoManual`, etc.) — pasan de mutar estado local sincrónico a llamar la API y esperar respuesta.
- Necesita decidir cómo el navegador se entera de cambios que **no** disparó él mismo (ej. un C-STORE real marcando Almacenado mientras la pestaña está abierta) — la opción honesta más simple es *polling* (repreguntar `GET /worklist` cada N segundos), dejando *WebSocket/SSE en tiempo real* como puerta etiquetada explícita para más adelante, no fingida ahora.
- **No tengo Chromium real disponible en este sandbox** (el acceso de red está restringido a paquetes npm/pip/github, no a descargar un navegador) — que es justo el método que en la Adenda 4 encontró 7 bugs reales que ni la lectura de código ni los tests automatizados habían visto, en este mismo componente. Puedo compensar parcialmente montando `HIS-RIS-PACS.interaction.test.jsx` (Vitest + RTL + jsdom, que sí puedo correr) como red de seguridad, pero no es lo mismo que clic a clic en un navegador real.

Por el tamaño y el riesgo, antes de tocar el componente principal quiero confirmar contigo el enfoque (¿todo de una vez o por fases — por ejemplo, primero solo lectura de la pestaña Worklist, después escritura, después el resto de las fases?) y si el plan de verificación (Vitest+RTL+jsdom en vez de navegador real) te sirve como red de seguridad suficiente para este paso.

---

## 13 · `HIS-RIS-PACS.jsx` cableado a la API real — construido, probado, funcionando de punta a punta (26-ago-2026)

El segundo paso de §12: cablear la interfaz para que hable con `WorklistApiServer` en vez de `useState` local. Hecho todo de una vez (no por fases) con Vitest+RTL+jsdom como red de seguridad, tal como se planteó — sin Chromium real disponible en este sandbox.

### 13.1 Qué se construyó

- **`frontend/WorklistClient.js`** (nuevo) — capa de datos pura, sin React: `cargarWorklist` / `crearRegistro` / `actualizarRegistro` / `ponerRegistro` / `sembrarSiVacio` / `restablecerDemo`, todo vía `fetch` contra `WorklistApiServer`.
- **`frontend/HIS-RIS-PACS.jsx` (modificado)**:
  - Props nuevas: `apiBaseUrl` (default `localhost:8043`) y `pollIntervalMs` (default 4000, configurable — los tests usan 200ms para no esperar segundos reales).
  - `useState(SEED)` → `useState([])` + carga real al montar (`sembrarSiVacio`: puebla la SEED solo si el motor está vacío, nunca pisa datos reales) + polling.
  - `patch()` — el mutador central que ya usan ~15 funciones (`setStaff`, `avanzarAgendado`, `ingresarBono`, etc.) — es el único lugar que hubo que tocar para conectarlas todas de una.
  - `guardarYEnviar()` ya NO tiene el `setTimeout` falso — el motor real marca "Almacenado" cuando llega el C-STORE, el polling lo detecta, la UI se actualiza sola.
  - `crearIngresoManual()` crea el registro vía POST real, usa la respuesta del servidor (no el objeto local) para el estado.
  - "Restablecer demo" hace upsert real de la SEED — no borra registros que no sean parte de ella (ej. ingresos manuales).
  - Pantallas de carga/error explícitas — si no hay conexión con la API, se dice así, nunca cae en silencio a datos fingidos.
- **`frontend/HIS-RIS-PACS.interaction.test.jsx` (reescrito completo)** — la versión de la Adenda 3 ya no aplicaba (asumía datos síncronos locales). 5 tests, todos contra una `WorklistApiServer` real: los 3 escenarios de antes (fecha, tótem, ingreso manual + bono) adaptados, más uno nuevo — el que más importa: un **C-STORE real disparado por fuera de React** (mismo cliente DIMSE crudo que los tests del motor) y la UI lo detecta sola.
- **`frontend/package.json` + `vitest.config.mjs`** (nuevos) — árbol de dependencias propio, separado del motor (React/lucide-react/Vitest/RTL/jsdom viven acá, no ensucian el `package.json` del backend).

### 13.2 Tres bugs reales encontrados y corregidos — por los tests, no por lectura

1. **Tipos de id inconsistentes.** `upsert()` (entra por URL) siempre guardaba el id como string; `agregar()` (entra por POST body) podía guardarlo como número. Dos registros "con el mismo id" no coincidían en `===`. Corregido en `WorklistStore.js`: `agregar`/`actualizar`/`upsert` normalizan siempre a string — decisión confirmada contigo antes de aplicarla.
2. **Carrera entre el update optimista y el polling.** Si un poll llega justo después de un `patch()` pero antes de que el servidor procesó el PATCH, puede pisar el cambio optimista con datos viejos — encontrado por el test de ingreso manual, que fallaba de forma intermitente-determinística por esto. Corregido: `patch()` reconcilia con la respuesta *confirmada* del servidor apenas llega, así cualquier poll que haya ganado la carrera se corrige solo.
3. **`WorklistClient.js` con exports vacíos en un build de producción real.** Al agregar `"type": "module"` al `package.json` del frontend (necesario, en apariencia, para que `vitest.config.js` con sintaxis ESM cargara), `esbuild` empezó a tratar `WorklistClient.js` (escrito en CommonJS) como ESM real — sus `module.exports` dejaban de reconocerse, cualquier función importada de ahí quedaba `undefined`. **Vitest no lo detectó** — sus tests pasaron igual, porque Vite/Vitest son más permisivos con la interop CJS/ESM que un bundler estricto. Solo se encontró corriendo `esbuild` de verdad sobre el bundle completo (con `WorklistClient.js` incluido, no excluido) — otro recordatorio de que pasar los tests propios no es lo mismo que un build real. Corregido: se sacó `"type": "module"` del package.json, `vitest.config.js` pasó a `vitest.config.mjs` (ESM explícito por extensión, no depende del `type` del package).

### 13.3 Verificación — 3 niveles

- **`esbuild`** sobre el componente completo, con `WorklistClient.js` incluido en el bundle (no excluido con `--external`): compila sin ningún warning — confirma que la interop CJS→ESM funciona en un build tipo producción, no solo en el entorno permisivo de Vitest.
- **Vitest + RTL + jsdom**: 5/5 tests, cada uno contra su propia `WorklistApiServer` real (puerto efímero, store JSON temporal aislado) — nunca un mock de `fetch`.
- **La prueba que más importa**: un C-STORE real, mandado con el mismo cliente DIMSE crudo que usan los tests del motor, disparado completamente por fuera de React — React no sabe que está pasando, nadie llama ninguna función del componente — y la UI lo detecta y lo muestra sola. Confirma el "flujo de RIS/PACS" de punta a punta, interfaz incluida, no solo el motor.

### 13.4 Estado del motor tras hoy

`npm test` del motor sigue en **8 archivos, 8/8 en verde** (sin cambios de comportamiento en los 7 anteriores — la regresión se confirmó antes y después de cada cambio de esta sesión).

### 13.5 Lo que queda pendiente — sin cambios de fondo

Los 6 gaps de UI de §4 (Prioridad editable, anamnesis, medio de contraste, calculadora renal en vivo, consentimiento rico con FES, `tomarPaciente` por rol) siguen abiertos — nada de eso se tocó hoy. La diferencia es que ahora, cuando se retomen, se agregan directo contra la forma final (la API real), no contra un `useState` que después habría que migrar — exactamente la secuencia que se había acordado en el mensaje que empezó este tramo de trabajo.

---

## 14 · Evaluación del "Dossier Maestro de Arquitectura, Implementación e Interoperabilidad v1.0" (documento externo, recibido 30-ago-2026)

### 14.1 Qué es

96 secciones + 8 anexos, ~2.950 líneas. Su propio Anexo F ("Estado documental del proyecto y trazabilidad de fuentes") confirma que usó como fuente primaria **este mismo dossier** (hasta el snapshot de "57 checks", es decir, hasta después de `WorklistApiServer` pero antes del cableado de `HIS-RIS-PACS.jsx` de §13, que se hizo recién en esta sesión) y el `README.md` del motor, más un `.xlsx` de estructuración, la Especificación de Ficha Clínica Digital, el dossier de Identidad/Portales, y dos PDFs de investigación de visores. Encima de eso agrega fuentes normativas reales, citadas con URL: DICOM 2026c (PS3.1 a PS3.22), IHE Radiology TF Rev. 23.0 e ITI TF, y documentación pública de dcmjs/dcm4che/DCMTK/OHIF/Cornerstone3D/Orthanc además de GE True PACS, Sectra, Siemens Syngo Carbon, Philips, Agfa, Fujifilm y Canon Vitrea.

**Evaluación honesta: es un documento sólido.** No es genérico — está construido específicamente sobre nuestro estado real, con investigación normativa verificable encima. Vale la pena adoptarlo como referencia de fondo, con los matices de las secciones siguientes.

### 14.2 Confirmación cruzada — encontró lo mismo que ya habíamos encontrado, por su cuenta

Su §78 PASO 2 dice literalmente "corregir VR length/validation y Accession Number" — es **exactamente** el bug que documentamos en §11 de este dossier (el `ACC-2026-00000001` de `makeACC()` tiene 17 caracteres, la VR `SH` de DICOM tiene máximo 16). No es casualidad — es la misma brecha real, vista desde una fuente que llegó a la misma conclusión trabajando desde nuestros propios documentos más la norma. Buena señal de que el hallazgo es sólido y no un capricho de interpretación nuestra.

### 14.3 La tensión real que hay que resolver: el orden de trabajo

El documento (§78-80) recomienda explícitamente **no tocar la UI grande todavía**, y ubica "conectar Worklist UI a persistencia real" (PASO 13 de 18, punto 11 de 16 en el orden inmediato) **después** de: fundaciones de Transfer Syntax, RLE end-to-end, JPEG/JPEG-LS/JPEG2000 según demanda, multiframe, MPPS, Storage Commitment, Transfer Queue durable con retry/backoff/DLQ, e Image Manager/IOCM.

**Nosotros hicimos lo opuesto en esta misma sesión: cableamos el Worklist primero** (§13), antes de tocar Transfer Syntax comprimida, MPPS, Storage Commitment, o Transfer Queue.

**Por qué pasó así, con la cabeza fría (no a la defensiva):** el documento fue generado a partir de un snapshot de este dossier anterior al cableado — cuando se escribió, "conectar Worklist a persistencia real" todavía era un paso futuro recomendado, no algo ya decidido en curso. En paralelo, dentro de esta misma sesión, vos preguntaste directamente "¿qué más podemos avanzar?" después de que varios de los 6 gaps de UI resultaran bloqueados por roles/catálogo de exámenes sin terminar, y la respuesta razonable en ese momento — con la información que teníamos ahí — fue el Worklist real. No es que el documento estuviera "equivocado" ni que nosotros lo estuviéramos ignorando; son dos procesos de planificación en paralelo llegando a secuencias distintas desde un punto de partida parecido.

**¿Fue trabajo perdido?** No. Dos razones concretas:
1. `WorklistStore.js`/`WorklistApiServer.js` se construyeron a propósito como **stubs honestos con firma real** — mismo principio que el `EventBus` y el check digit de CUP en el resto del proyecto. Si más adelante se construye el Transfer Queue/Image Manager que describe el documento, y eso implica que el Worklist necesite un estado más granular (ej. usar MPPS real en vez de C-STORE como proxy de "terminado" — brecha que YA teníamos documentada nosotros mismos, no es nueva), el cambio es extender lo que existe, no reescribirlo desde cero.
2. El cableado de hoy no es solo "una UI más linda" — es lo que permitió encontrar y corregir 3 bugs reales (tipos de id inconsistentes, la carrera patch/polling, y el problema de exports vacíos con `"type":"module"`) que ningún trabajo aislado del motor iba a exponer, porque solo aparecen cuando de verdad hay dos sistemas (UI async + motor DIMSE) hablándose entre sí.

**Recomendación concreta:** no deshacer nada de §13. Pero **de acá en adelante, adoptar el orden que propone el documento** — es decir, el próximo tramo de trabajo real es motor puro (§14.7 abajo), no más UI, hasta que ese tramo esté cerrado.

### 14.4 Lo genuinamente nuevo y accionable que aporta (más allá de confirmar lo que ya sabíamos)

- **`TransferSyntaxRegistry` + `CodecInterface`** (§78 PASO 3) — patrón limpio para dejar de decidir el codec con un `? :` hardcodeado (como hace hoy `_handleCFindWorklist`: `codec = transferSyntax === '1.2.840.10008.1.2.1' ? ExplicitVR : ImplicitVR`) y pasar a un registro donde agregar RLE/JPEG/etc. sea sumar una entrada, no tocar cada `if`.
- **Matriz de Transfer Syntax más completa que la que ya habíamos verificado nosotros mismos** (Anexo A) — además de JPEG/RLE/JPEG-LS/JPEG2000/MPEG/HEVC (lo que confirmamos contra la fuente primaria en §10 de este mismo dossier), el estándar 2026c también registra **HTJ2K, JPEG XL, y SMPTE ST 2110-20/30** (video/audio sin comprimir para flujos en tiempo real) — no lo teníamos anotado, vale la pena sumarlo al radar aunque no se implemente pronto.
- **Storage Commitment** — servicio DICOM real (el PACS confirma "ya lo guardé de forma segura y durable" para que el equipo emisor pueda borrar su copia local) que no habíamos ni discutido hasta ahora. Es una pieza real de confiabilidad operacional en cualquier PACS de producción.
- **Transfer Queue durable con retry/backoff/DLQ** (§82) — hoy, si un C-STORE falla o si quisiéramos reenviar a un segundo destino, no hay ningún mecanismo — se pierde. Esto es un gap de resiliencia real, no cosmético.
- **Image Manager + IOCM** (§81) — gobernanza real de corregir/rechazar/reemplazar/eliminar objetos DICOM ya guardados, con motivo obligatorio, segunda aprobación, y propagación del cambio. Hoy un C-STORE solo escribe el archivo; no hay ningún flujo para "esto se guardó mal, hay que corregirlo" con trazabilidad.

### 14.5 Reglas de diseño (Anexo D) — ya las cumplimos, vale la pena mantenerlas explícitas de acá en adelante

De las 18 reglas del Anexo D, revisamos contra nuestro estado real — cumplimos todas las que ya nos tocaban: no mezclamos Study con prestación financiera (el motor no toca facturación), no confundimos AXON ID con autorización clínica, no convertimos el Portal Paciente en repositorio clínico maestro (no existe ese portal desde acá), no guardamos secrets en código, no asumimos que toda imagen es grayscale single-frame (por eso `/rendered` responde 422 explícito para RGB/multiframe en vez de fingir). Vale la pena usarlas como checklist recurrente, no solo para hoy.

### 14.6 Aspiracional / largo plazo — contexto útil, no acción inmediata

- **Matriz de especialidades** (Anexo C) — 17 especialidades clínicas más allá de Radiología (Oftalmología, Patología/WSI, Cardiología, ORL, Cirugía, etc.). Confirma lo que ya habíamos concluido en `AXON_Arquitectura_Interoperabilidad_Nacional.md`: el motor está bien diseñado para esto porque es genérico, no específico de Radiología — pero construir cualquiera de estas es trabajo aparte, no de ahora.
- **Perfiles IHE** (Anexo B: SWF.b, PIR, IOCM, XDS-I.b, XCA-I, etc.) — buen checklist de referencia para cuando se busque interoperabilidad certificada o un Connectathon real. No es para hoy.
- **Estrategia de visor** (§16, §80) — coincide con lo que ya sabíamos: nuestro visor actual es una prueba real de encode→decode→pintar, no un visor clínico completo (sin MPR, sin hanging protocols, sin anotaciones persistentes). El documento sugiere mirar OHIF/Cornerstone3D como referencia de patrones, sin copiar su identidad visual. Coherente con la filosofía del proyecto (§1 del dossier original: nada de adoptar un PACS de terceros completo, sí referencia de patrones probados).
- **Gobernanza de open source, SBOM, license scanning** — aplica cuando se empiece a sumar dependencias de codecs reales (§14.4). Anotado para entonces.

### 14.7 Próximo tramo de trabajo — siguiendo el orden del documento desde acá

Dado que el Worklist ya está cableado (§13), el punto de continuación real según el propio plan del documento (§78, PASOS 2-6) es:

1. **Corregir VR length/validation + Accession Number** (§14.2) — el más chico y ya lo teníamos identificado.
2. **`TransferSyntaxRegistry` + `CodecInterface`** — la base limpia antes de sumar ningún codec nuevo.
3. **RLE end-to-end** — primer codec comprimido, coincide con lo que ya habíamos acordado como punto de partida en una sesión anterior de este mismo dossier.
4. Después, según demanda real de equipos: JPEG/JPEG-LS/JPEG2000.
5. Multiframe — antes de cualquier especialidad compleja (Cardiología, Endoscopía).

¿Arrancamos por acá (VR length + Accession Number, es lo más chico y ya lo teníamos mapeado), o preferís otro orden dentro de este mismo tramo?

---

## 15 · VR length/validation + Accession Number — corregido y probado (31-ago-2026)

Primer ítem del tramo de §14.7. Verificado contra la fuente primaria (PS3.5 Tabla 6.2-1, dicom.nema.org, consultada hoy) antes de escribir ninguna línea.

### 15.1 Qué se construyó

- **`src/pdu/VrLimits.js`** (nuevo) — tabla de longitud máxima por VR (AE=16, AS=4, CS=16, DA=8, DS=16, DT=26, IS=12, LO=64, LT=10240, PN=64, SH=16, ST=1024, TM=14, UI=64) + `validarLongitudVR(vr, valor)`, que lanza un error explícito con el motivo si se excede — mismo principio de "fallar con el motivo, no en silencio" del resto del proyecto. VRs sin límite práctico real (UC/UR/UT, "2^32-2 bytes" en el estándar) no se validan a propósito — poner un número ahí sería un límite inventado nuestro, no uno real.
- **`ImplicitVrCodec.js` y `ExplicitVrCodec.js` (modificados)** — la rama genérica de codificación de texto ahora llama a `validarLongitudVR()` antes de construir el buffer, en los dos codecs (el bug real, encontrado en Adenda 5, era justamente que un fix se había hecho en uno y no en el otro — acá se corrigió en ambos desde el principio).
- **`HIS-RIS-PACS.jsx` — `makeACC()` corregido**: el formato viejo (`ACC-2026-00000001`, 17 caracteres) excedía el máximo real de 16 de la VR SH — nadie lo había notado porque ningún codec validaba. Nuevo formato: `ACC-${n}` con 8 dígitos (`ACC-00000001`, 12 caracteres) — se sacó el año del medio (ya vive en el CUP, no hacía falta duplicarlo). `soloNumero()` (la función que recorta el prefijo para mostrar en las columnas de la tabla) sigue funcionando sin cambios, porque el prefijo `ACC-` se mantuvo idéntico. `makeOT()` no necesitó cambios (14 caracteres, ya estaba dentro del límite).

### 15.2 Verificación

- **`test/vr-limits.test.js`** (nuevo, 8 checks): la tabla contra los valores conocidos de PS3.5; `validarLongitudVR()` en aislamiento; **el bug real reproducido y confirmado corregido en los dos codecs** (`ImplicitVrCodec.encodeElement` y `ExplicitVrCodec.encodeElement` ambos rechazan el ACC viejo de 17 caracteres con el motivo explícito, y aceptan el corregido de 12); y una confirmación de que valores reales ya en uso en el proyecto (UID de estudio, nombre de paciente, AE Title, modalidad) siguen codificando sin problema — la validación no rompe el uso normal.
- **Regresión completa**: los 9 archivos del motor (`npm test`) y los 5 tests del frontend, todos en verde con la validación estricta ya activa. En el log de auditoría del test end-to-end del frontend se confirma el ACC real fluyendo ya en formato corregido: `"accessionNumber":"ACC-00000012"`.

### 15.3 Qué significa esto de acá en adelante

Cualquier VR de texto que exceda su máximo real ahora se rechaza al codificar, en cualquiera de los dos codecs — no hay forma de que un valor no conforme salga del motor en silencio, sin importar por dónde entre. Si en el futuro aparece otro campo generado con un formato demasiado largo (por ejemplo, si se agrega un ID nuevo en algún lado), el error va a aparecer de inmediato al primer intento de codificarlo, no meses después al conectar equipo real — exactamente el tipo de problema que este fix estaba destinado a prevenir hacia adelante, no solo corregir hacia atrás.

**Siguiente ítem del tramo (§14.7):** `TransferSyntaxRegistry` + `CodecInterface` — la base limpia antes de sumar RLE.

---

## 16 · `TransferSyntaxRegistry` — construido, y un reinicio de sandbox en el medio (31-ago-2026)

### 16.1 Qué se construyó

- **`src/pdu/TransferSyntaxRegistry.js`** (nuevo) — un solo lugar para saber, de cualquier Transfer Syntax UID, si el motor la soporta hoy, con qué codec, y si es comprimida. Reemplaza el ternario hardcodeado (`codec = transferSyntax === '...1.2.1' ? ExplicitVR : ImplicitVR`) que vivía en `_handleCFindWorklist`. Incluye a propósito UIDs conocidas por el estándar pero **no** soportadas todavía (RLE, JPEG Baseline, JPEG-LS, JPEG 2000 — con `codec: null`) — mismo principio de puerta etiquetada del resto del proyecto. UIDs verificados cruzando varios conformance statements reales (Philips, GE HealthCare, Canon Medical) más una propuesta de corrección oficial de DICOM.
- **`AeRegistry.js`** — `TRANSFER_SYNTAXES_ESTANDAR` ahora se **deriva** de `TransferSyntaxRegistry.listarSoportadas()` en vez de mantenerse como lista aparte — una sola fuente de verdad.
- **`AssociationServer.js`** — `_handleCFindWorklist` usa `TransferSyntaxRegistry.obtenerCodec(transferSyntax)`; se sacaron los `require` directos de `ImplicitVrCodec`/`ExplicitVrCodec` que quedaron sin uso.
- **Regresión completa**: los 9 tests del motor y los 5 del frontend, todos en verde, sin cambio de comportamiento — el refactor es puramente interno, no cambia qué Transfer Syntax se acepta hoy (siguen siendo las mismas 2).

### 16.2 Incidente: el sandbox se reinició en el medio de este trabajo

Justo después de terminar el refactor (antes de guardarlo en `outputs`), el entorno de trabajo (`/home/claude/`) se reinició solo — perdí `TransferSyntaxRegistry.js`, la modificación de `AeRegistry.js`, y el refactor de `AssociationServer.js`, ninguno de los tres se había copiado a `outputs` todavía. Node/npm y `/mnt/project/` (los archivos originales del proyecto) siguieron disponibles con normalidad; tus 3 archivos binarios (`CT_small.dcm`, `MR_small.dcm`, `consentimiento_prueba.pdf`) también sobrevivieron porque viven en `/mnt/user-data/uploads/`, no en el directorio de trabajo.

**Lo que esto confirma:** `/mnt/user-data/outputs/` (donde vengo copiando cada entregable) es lo único que persiste de forma confiable a través de un reinicio — todo lo que solo vive en el directorio de trabajo puede desaparecer sin aviso. Reconstruí el árbol completo desde ahí + los originales de `/mnt/project/` + tus uploads, y rehice de memoria las 3 piezas que no había alcanzado a guardar (son las mismas, verificadas de nuevo con la regresión completa de arriba).

**Cambio de práctica de acá en adelante:** guardar en `outputs` cada archivo apenas se termina, no al final de cada tramo de trabajo — así un reinicio, si vuelve a pasar, pierde como máximo el archivo en el que estoy trabajando en ese instante, no un tramo completo.

### 16.3 Mejora de paso: se eliminó un ruido de test que había quedado pendiente

Antes del reinicio había detectado (corriendo la suite del frontend 6 veces seguidas) un mensaje intermitente `"[HIS-RIS-PACS] Error al refrescar el Worklist desde el motor: fetch failed"` — no hacía fallar ningún test, pero era ruido: un intervalo de polling de un test anterior seguía vivo un instante después de que ese test cerrara su propio servidor. Se agregó `afterEach(cleanup)` de React Testing Library al archivo de tests — confirmado con 4 corridas seguidas sin el mensaje.

---

## 17 · Falla intermitente real en el test de interacción — causa raíz y fix (31-ago-2026)

### 17.1 El síntoma y la causa raíz

Después de §16.3, el test grande (ingreso manual + bono) seguía fallando de forma intermitente (2 de 6 corridas) en distintos puntos — cada vez, un `getByText(...)` instantáneo justo después de un `fireEvent.click` anterior. **Vos identificaste la causa correcta** (con ayuda de Gemini): el patrón "esperar con `waitFor`/confirmar que algo existe" separado de "actuar sobre eso" en dos pasos deja una brecha síncrona en el medio — y con el polling real corriendo (200ms en estos tests, 4s en producción), un poll puede re-renderizar justo en esa brecha, dejando la siguiente búsqueda instantánea mirando una foto que ya quedó vieja.

**No era un bug del componente ni del motor** — es una propiedad inherente de probar una UI con polling real contra un servidor real: exactamente lo que se buscaba (nada mockeado) tiene como costo que el timing ya no es 100% determinista, y los tests tienen que estar escritos para tolerar eso.

### 17.2 El fix

Se agregó `clickResiliente(buscar)` — un helper que busca y clickea un elemento **como una sola unidad reintentable** (`waitFor(() => fireEvent.click(buscar()))`), en vez de separar "esperar" de "actuar". El click es siempre idempotente en este componente (seleccionar el mismo id de nuevo, con los mismos datos), así que reintentarlo cuantas veces haga falta es seguro. Se aplicó en los 2 tests que lo necesitaban (tótem, ingreso manual+bono) en cada punto donde una búsqueda seguía a una acción que depende de estado sincronizado con el servidor — y se reemplazaron las referencias a filas capturadas antes de renders intermedios (`let fila = ...`) por búsquedas frescas en el momento de usarlas.

**Verificación real, no solo "ya no falló una vez":** 12 corridas seguidas de la suite completa, 12/12 en verde — la corrida anterior a este fix había mostrado fallas en aproximadamente 1 de cada 3.

### 17.3 Segundo reinicio de sandbox — mismo patrón, ya resuelto de forma distinta

El sandbox se reinició una segunda vez mientras se investigaba esta falla (antes de que el archivo de test con los fixes llegara a `outputs`) — se perdieron las correcciones recién escritas, otra vez ninguna tocaba código de producción. Esta vez, apenas se reescribió el archivo completo, se copió a `outputs` **antes** de correr ningún test (no después) — el cambio de práctica anotado en §16.2 ya se aplicó de verdad acá, no solo quedó escrito.

---

## 18 · RLE Lossless de punta a punta — construido y verificado (trabajo del 18-oct-2026; exportado el 27-oct-2026)

### 18.1 Qué se construyó

| Archivo | Rol |
|---|---|
| `src/pdu/EncapsulatedPixelData.js` (nuevo) | Sobre genérico de Pixel Data encapsulado (PS3.5 Anexo A.4): Basic Offset Table + Items + delimitador. No sabe de compresión. El encoder escribe BOT vacía (válida) con un fragmento por frame; el decoder lee BOT con o sin valores. |
| `src/pdu/RleCodec.js` (nuevo) | RLE Lossless (PackBits, PS3.5 Anexo G): 8 y 16 bits, 1 canal, codifica por fila, segmentos siempre de longitud par. |
| `src/pdu/ExplicitVrCodec.js` (editado) | Encode/decode de Pixel Data encapsulado (longitud indefinida) en lugar del `throw` anterior. |
| `src/pdu/TransferSyntaxRegistry.js` (editado) | RLE Lossless pasa de `codec: null` a `codec: ExplicitVR`. |
| `src/rendering/RenderInstance.js` (editado) | Descomprime RLE antes del windowing; una Transfer Syntax sin decoder lanza error explícito (el handler lo responde 422 nombrándola). |
| `test/rle.e2e.test.js` (nuevo) | 18 checks, ver §18.3. |
| `test/fixtures/MR_small_RLE.dcm` (nuevo; en el Proyecto como `MR_small_RLE_dcm_base64.txt`) | RLE real generado por OTRA implementación (pydicom 3.0.2). |

`AeRegistry.js` y `AssociationServer.js` **no cambiaron**: la lista de Transfer Syntax aceptadas se deriva del registro (§16), así que RLE entra a la negociación sola.

### 18.2 Bug real encontrado y corregido

`RenderInstance.js` no sabía de compresión: dcmjs entrega el Pixel Data tal como viene en el archivo y el renderer lo leía como si fueran muestras planas. Con un RLE real (`MR_small_RLE.dcm`), `/rendered` respondía **200 con una imagen equivocada**: 72 niveles de gris distintos contra 204 de la imagen correcta, y **4087 de 4096 píxeles distintos** respecto al archivo sin comprimir. (Una predicción anterior de "imagen negra" era incorrecta: era peor, una imagen de aspecto plausible.) Con el fix: 0 de 4096 píxeles distintos y el PNG es idéntico byte a byte al del archivo sin comprimir. Con el renderer original, un frame RLE truncado también respondía `200 image/png`.

### 18.3 Evidencia (qué se probó y contra qué)

- **Decoder propio contra archivos RLE de otra implementación** (pydicom 3.0.2; sha256 en `scripts_validacion/obtener_fixtures_externos.py`): `MR_small_RLE` 1/1 idéntico a la referencia sin comprimir; `emri_small_RLE` (10 frames) 10/10; `OBXXXX1A_rle` 1/1 (es PALETTE COLOR: `/rendered` lo rechaza igual que a su versión sin comprimir); `SC_rgb_rle` (3 segmentos) rechazado con motivo explícito. `/rendered` de `emri_small_RLE` vs `emri_small` (sin comprimir): PNG idéntico (verificado en el sandbox, fuera de la suite).
- **Encoder propio leído por pydicom como decoder independiente**: 6/6 casos (32×32 16 bits; 20×33 16 bits con signo; 17×31 8 bits; 64×64 8 bits aleatorio; 3×300 16 bits con corridas largas; 1×1 8 bits). Los bytes comprimidos difieren de los de otros encoders (RLE no prescribe dónde cortar): lo que define conformidad es que cualquier decoder recupere los píxeles exactos.
- **`test/rle.e2e.test.js` (18/18)**: registro; negociación (RLE solo → aceptado; JPEG Baseline solo → rechazado; SCU que ofrece [JPEG, RLE, Explicit] → el motor elige RLE); archivo real externo por C-STORE (guardado idéntico byte a byte, muestras descomprimidas == píxeles sin comprimir, QIDO-RS, `/rendered` idéntico al del sin comprimir); imagen sintética 8 bits 256×256 enviada en PDUs de 4096 bytes (reensamblado DIMSE); 16 bits 37×29 con 3 frames distintos (se renderiza el primero); un frame partido en 2 fragmentos; frame truncado → 422; Transfer Syntax sin decoder → 422 nombrándola y WADO-RS sigue sirviendo el objeto crudo. En los casos sintéticos el esperado sale de las muestras originales + la fórmula de ventana, no de otro render del motor.
- **El test muerde (prueba de mutación)**: sin el fix de `RenderInstance.js` fallan 6 checks (los de imagen y los dos de rechazo explícito, que devuelven `200 image/png` donde debe ser 422); con el registro original (sin RLE) falla la negociación.
- **Árbol reconstruido desde cero** con `scripts_validacion/rebuild_tree.sh` (Proyecto + estos archivos): motor **92/92** en 10 archivos (`npm test`, exit 0) y frontend Vitest **5/5** en dos corridas.

### 18.4 Alcance explícito / puertas etiquetadas

- RLE: solo `SamplesPerPixel = 1`, 8 y 16 bits. RGB/YBR → rechazo explícito.
- `/rendered`: solo el primer frame. Multiframe RLE exige un fragmento por frame; un frame único partido en varios fragmentos sí se soporta.
- JPEG / JPEG-LS / JPEG 2000 / HTJ2K / video: sin decoder. La negociación los rechaza y `/rendered` responde 422 nombrando la Transfer Syntax.
- Siguen sin implementar: MPPS, Storage Commitment, Transfer Queue durable, IOCM (§14.4).

### 18.5 Hallazgos abiertos — NO corregidos, decisión pendiente (con su nivel de evidencia)

1. **Código de rechazo de la negociación.** `PDU.encodeAssociateAC` envía siempre result `3` (abstract-syntax-not-supported) para cualquier contexto no aceptado; PS3.8 §9.3.3.2 define `4` (transfer-syntaxes-not-supported) para "Transfer Syntax no soportada". Evidencia: lectura del código. Cambio chico: `AssociationServer` distingue la causa y `encodeAssociateAC` la usa.
2. **Relleno de UI en los codecs de dataset.** `ImplicitVrCodec` y `ExplicitVrCodec` rellenan con espacio (0x20) todo VR de texto de longitud impar, incluido UI; PS3.5 §6.2 pide NULL (0x00) para UI. `DimseCommand` y el File Meta sí usan 0x00. dcmjs lo tolera (los tests pasan); el riesgo es un lector estricto de objetos escritos por el motor (p. ej. el Encapsulated PDF del consentimiento). Evidencia: lectura del código; medición explícita pendiente.
3. **Robustez del MWL — SOSPECHA, no probada.** `_handleCFindWorklist` no tiene `try/catch` alrededor de `codec.encodeDataset(...)`. Desde la validación de VR (31-ago), un registro del Worklist con un valor fuera del máximo de su VR (p. ej. un ACC de 17 caracteres persistido antes de esa fecha, o un nombre de más de 64 caracteres) lanzaría una excepción dentro del handler del socket y podría tumbar el proceso del motor. Es una hipótesis por lectura del código: primero hay que confirmarla con una sonda (motor en un proceso hijo + C-FIND con un registro así). Mitigación propuesta si se confirma: `try/catch` por registro (omitirlo y auditar) y una guarda global en `_onData`.
4. `rebuild_tree.sh` no armaba el frontend (quedaba solo `WorklistClient.js` y la suite Vitest no corría). Corregido en este export.
5. Documentos desactualizados: la **Especificación Técnica** (31-jul) dice que las Transfer Syntax comprimidas, incluida RLE, no están soportadas.

### 18.6 Identificadores de MAIN — solo cómo calzan en el motor

Los identificadores (CUP, CUT, CUC, CUV…) los administra MAIN; el motor y los satélites **solo los consumen**. No se copia el archivo de MAIN al repositorio. Lo que importa para el motor:

- El motor trata el CUP como cadena opaca: viaja como Patient ID (0010,0020, VR LO, máx. 64 caracteres) y no valida su formato. Los identificadores generados por el archivo de MAIN miden como máximo 37 caracteres (medido ejecutando ese archivo), así que caben. Ninguno cabe en un SH (máx. 16): el **Accession Number y el Requested Procedure ID no pueden ser identificadores de MAIN** y deben seguir cumpliendo ≤ 16 (hoy `makeACC` = 12 caracteres y `makeOT` = 14, en `HIS-RIS-PACS.jsx`).
- Conclusión: **no se requiere ningún cambio en el motor.** Evidencia: lectura del código del motor + longitudes medidas contra el archivo de MAIN; no se corrió una prueba del motor con esos identificadores.
- Del lado de `HIS-RIS-PACS.jsx`: los CUP que genera hoy (`makeCUP`, hash local) son marcadores; 0 de 24 de la SEED validan con el validador real de MAIN (medido ejecutándolo). Al integrar con MAIN se reemplazan por su generador.

### 18.7 Archivos para agregar o reemplazar en el Proyecto

| Acción | Archivos |
|---|---|
| Agregar | `EncapsulatedPixelData.js`, `RleCodec.js`, `rle_e2e_test.js`, `MR_small_RLE_dcm_base64.txt`, `obtener_fixtures_externos.py`, `AXON_TRASPASO_SESION_NUEVA_2026-10-27.md` |
| Reemplazar | `ExplicitVrCodec.js`, `TransferSyntaxRegistry.js`, `RenderInstance.js`, `package.json`, `README.md`, `rebuild_tree.sh`, este dossier |
| Sin cambios | el resto (incluidos `AeRegistry.js`, `AssociationServer.js`, `HIS-RIS-PACS.jsx`) |
| Quitar | `AXON_TRASPASO_SESION_NUEVA_2026-08-31.md` (lo reemplaza el nuevo) y `package-lock.json` (desactualizado; `npm install` lo regenera) |
