# Sincronización Módulos Satélite ↔ MAIN — Discrepancias y Pendientes

> Cruce completo entre lo construido en los 3 archivos satélite (`AtencionMedicaAgenda.jsx`, `AtencionMedicaPresencial.jsx`, `AtencionAgendaImagenologia.jsx`) contra los archivos reales de MAIN disponibles: `security.config.js`, `roles.config.js`, `userTypes.config.js`, `tenantTypes.config.js`, `modules.config.js`, `identityLifecycle.config.js`, `workTeams.config.js`, `terminology.seed.js`, `TerminologyService.js`, `aes.js`, `deviceUUID.js` — más `HIS-RIS-PACS.jsx` (módulo operativo real). Pensado para pasarle esto tal cual al equipo de MAIN.

**Fecha:** 2026-08-06

---

## 1. Discrepancias encontradas (satélite construyó distinto de lo que MAIN ya define)

### 1.1 — Formato de CUP/CUT: dos formatos que no calzan entre sí

`security.config.js` (`IDENTITY_SCHEMA.PERSON_FIELDS`) documenta el formato así, textual:
```
cup: "string | null — CUP-XXXX-XXXXXXX-XX"
cut: "string | null — CUT-XXXX-XXXXXXX-XX"
```
Eso son **3 segmentos** después del prefijo (4 caracteres, 7 caracteres, 2 caracteres).

Los 3 satélites (heredado desde la primera sesión de Agenda) generan **5 segmentos**:
```
CUP-{PAIS:2}-{REGIÓN:2}-{AÑO:4}-{SECUENCIA:8}-{DV:2}
CUT-{PAIS:2}-{REGIÓN:2}-{CLÍNICA:4}-{SECUENCIA:8}-{DV:2}
```
**No sabemos cuál es la fuente de verdad real** — el comentario de `security.config.js` puede ser una simplificación no literal, o puede ser el formato real y lo que construimos en los satélites está mal desde el principio. Esto afecta a **los 3 archivos satélite por igual**, es la base de todo el motor de identificadores. Hay que confirmarlo con quien mantiene `cup.js` real (mencionado pero nunca leído — ver punto 3.4).

### 1.2 — Color de módulo (`Agenda de Imagenología`)

Usamos `#0D47A1` a mano. `modules.config.js` ya define `#1A4DA8` para `atencion_clinica`. Pendiente de corregir en el `.jsx`.

### 1.3 — Granularidad de submódulos (`atencion_clinica`)

Conversamos ~18-19 unidades de agenda (Imagenología, Laboratorio, Oftalmología, ORL, Anatomía Patológica, Cardiología, Medicina Nuclear, Gastroenterología, Urología, Ginecología, Dermatología, Neurología, Broncopulmonología, Oncología/Radioterapia, Odontología Dx, Terapia y Rehabilitación, Obstetricia/Matronería, Psicología). `modules.config.js` real solo tiene **9 submódulos**: `clin_img`, `clin_lab`, `clin_oft`, `clin_otl`, `clin_morfo`, `clin_cardio`, `clin_esp` (catch-all "Exámenes de Especialidad"), `clin_terapia`, `clin_psicologia`. Varias de las que conversamos no tienen submódulo propio — probablemente caerían en `clin_esp`, sin confirmar.

### 1.4 — Marca de agua: 3 valores distintos conviviendo, ninguno es el de fábrica

| Fuente | Opacidad | Tamaño letra | Ángulo | Repeticiones |
|---|---|---|---|---|
| `security.config.js` (fábrica) | 0.03 | 14 | -45° | 3×5 |
| `AtencionMedicaAgenda.jsx` / `Presencial.jsx` | 0.06 | 20 | -45° | 3×5 |
| `AtencionAgendaImagenologia.jsx` | 0.07 | 21 | -30° | patrón SVG continuo (sin repeticiones fijas) |

La desviación de Atención Médica ya estaba documentada como decisión explícita del usuario (pidió más visible, citando la ley de protección de datos). Imagenología se desvió un poco más, y además cambió el mecanismo de renderizado (patrón SVG en vez de texto repetido). **No hay un valor único acordado con MAIN** — si `security.config.js` es la fuente de verdad real que después van a leer todos los módulos, hay que decidir un valor y converger los 3 archivos a ese mismo número, o formalizar que cada módulo puede desviarse (y en tal caso, dejarlo escrito en `security.config.js` mismo, no solo en nuestros dossiers).

### 1.5 — Botón de pánico: el gatillo por "mantener presionado" no existe en el config real

`security.config.js` solo documenta `gesture: "triple_click"`, `windowMs: 1200`. Los 3 satélites agregaron un segundo gatillo (mantener presionado ~3 segundos, con mouse y touch) que **no está en el config maestro**. Ya estaba anotado como extensión propia en el dossier de Atención Médica — se repite acá para que quede una sola vez consolidado: **falta que MAIN decida si esto se adopta oficialmente** (y si sí, agregar `holdMs` al config real) o si hay que sacarlo de los satélites.

### 1.6 — `IDENTITY_SCHEMA.PERSON_FIELDS` no tiene teléfono ni correo

Verificado literal en `security.config.js` — los únicos campos de una persona son: `personaId, rut, nombres, apellidoPaterno, apellidoMaterno, fechaNacimiento, sexo, cup, cut, cupActivo, cutActivo, cutRevokedAt, cutRevokedReason, createdAt, updatedAt, fhirPersonId`. **No hay ni un campo de teléfono ni de correo electrónico en todo el esquema.**

Agenda de Imagenología ya agrega 2 teléfonos + correo al registrar un paciente nuevo (necesario para la confirmación por WhatsApp/correo que se dejó como puerta etiquetada). **Esto es más que una discrepancia — es un campo que falta en el esquema real** si MAIN quiere que cualquier módulo satélite pueda algún día enviar confirmaciones automáticas. Vale la pena levantarlo como requerimiento, no solo como nota.

### 1.7 — Roles simulados no están atados a `roles.config.js`

Los `USUARIOS_DEMO` de los 3 satélites usan un campo `rol` con valores como `"ADMIN_STAFF"` o `"MEDICO_STAFF"` — que sí existen como **USER_TYPES** en `userTypes.config.js`, así que ese nivel calza. Pero ningún usuario demo lleva un **rol real de `roles.config.js`** (por ejemplo `t_med_ambulatorio`, `t_adm_administrativo`). Es una capa que falta conectar: hoy el "Viendo como" de los satélites es solo un label de UI, no un id real navegable contra el árbol de roles.

### 1.8 — Catálogo CIE-10/11 y especialidad médica: no pasan por `TerminologyService`

`TerminologyService.js` + `terminology.seed.js` ya definen exactamente el mecanismo para esto (`BINDING_POINTS.DIAGNOSTICO_PRINCIPAL` → CodeSystem `cie-10` real, `BINDING_POINTS.ESPECIALIDAD_MEDICA` → `cs-especialidad-med-cl`), pensado para que cambiar CIE-10→CIE-11 sea un cambio de dato en BD, no de código.

Los 3 satélites usan catálogos **locales hardcodeados** (`CATALOGO_SEMILLA_CIE10` en Presencial, `MAPEO_CIE` + catálogo propio en Imagenología, `ESPECIALIDADES_LIST` como array plano de strings en Agenda/Presencial) — ninguno llama a `getActiveCodeSystem()`. Es coherente para un componente sin backend (ya está documentado como límite honesto), pero hay que dejar explícito que **el día que haya backend, el reemplazo es directo**: cambiar la fuente de datos del picker por una llamada a `TerminologyService`, no hay que rediseñar el componente.

### 1.9 — Auditoría: solo se registran acciones, no consultas de datos clínicos

`security.config.js` (`audit.criticalEvents`) incluye `"view_lab_result"`, `"view_imaging_report"`, `"access_patient_history"` — es decir, **ver** un dato clínico ya es un evento auditable, no solo modificarlo. Los 3 satélites solo registran en `auditoria` las acciones de escritura (crear/confirmar/cancelar/etc.) — **abrir el panel de detalle de una orden o de una atención para solo mirarla no queda registrado en ningún lado.** Es una brecha real si `security.config.js` es vinculante.

### 1.10 — Médico externo (referente) no tiene un `USER_TYPE` real

Agenda de Imagenología inventó una categoría propia (`MEDICOS_REFERENTES_SEED`, `origen: "externo"`) para médicos que emiten una orden pero no tienen cuenta en AXON. `userTypes.config.js` tiene `MEDICO_INDEPENDIENTE` (médico que SÍ usa la plataforma por su cuenta, con `selfTenant:true`, pagando membresía) — es un concepto distinto: un médico referente externo no necesariamente quiere ni necesita una cuenta AXON, solo que quede registrado como emisor de la orden. **No hay un `USER_TYPE` que represente esto hoy.**

### 1.11 — `identityLifecycle.config.js` no se usa en ningún satélite

`NN_DOCUMENTACION_CONFIG`, `RECIEN_NACIDO_CONFIG` y `MAYORIA_DE_EDAD_POR_PAIS` (con su función `requiereRepresentanteLegal`) existen y están listos, pero ningún formulario de registro de paciente nuevo (en Agenda, Presencial o Imagenología) los usa. Ningún satélite valida si un paciente es menor de edad para exigir representante legal, ni tiene flujo de paciente NN (no identificado). Relevante sobre todo para Imagenología (pediatría, urgencias) y Presencial.

---

## 2. Qué necesitan los módulos satélite de MAIN para poder sincronizar de verdad

- **Confirmar el formato real de CUP/CUT** (punto 1.1) — es lo más urgente, afecta todo lo demás.
- **Leer `cup.js` actualizado** — mencionado varias veces desde la sesión 2 del dossier original, nunca compartido. Se supone que ya incluye la lógica de **CUC (Código Único Club)**, que sigue sin definición ni ejemplo de formato.
- **Confirmar granularidad de `atencion_clinica`** (punto 1.3) antes de propagar el patrón de Imagenología a otras unidades — si no, se corre el riesgo de construir pantallas para submódulos que no van a existir con ese nombre.
- **Color oficial confirmado por módulo** — ya lo tenemos para `atencion_medica` (`#C62828`, coincide) y `atencion_clinica` (`#1A4DA8`, pendiente de aplicar). Faltaría a medida que se agreguen más módulos.
- **Decisión sobre el gatillo de pánico por hold** (punto 1.5) — adoptarlo en el config real o sacarlo de los satélites.
- **Un valor único de marca de agua** (punto 1.4), o la confirmación explícita de que cada módulo puede tener el suyo.
- **Extender `IDENTITY_SCHEMA.PERSON_FIELDS`** con teléfono(s) y correo (punto 1.6) si se quiere que las confirmaciones automáticas (WhatsApp/correo) sean un estándar transversal, no algo que cada satélite invente por su cuenta con su propia forma.
- **Definir si un médico referente externo necesita un `USER_TYPE`** propio (punto 1.10) o si el patrón que armamos en Imagenología (catálogo separado, sin cuenta) es aceptable tal cual.

---

## 3. Qué le comunicamos nosotros al equipo de MAIN (hallazgos útiles desde el lado satélite)

### 3.1 — Confirmación cruzada del ciclo de vida ACC/OT

Verificamos contra `HIS-RIS-PACS.jsx` real (no de memoria): ACC y OT quedan `null` mientras un registro está en fase `"agendados"`, y se generan recién al completar Admisión (`makeACC(id)` + `makeOT(id)`, líneas 309-310 y 1312 de ese archivo). Confirma que la Agenda de Imagenología **no debe generar esos identificadores** — coincide con lo que ya construimos después de corregirlo. Vale la pena que este contrato quede escrito en algún config compartido (hoy solo vive como código/comentario dentro de `HIS-RIS-PACS.jsx`), para que cualquier otro módulo que alimente `"agendados"` (Laboratorio, Oftalmología, etc.) lo sepa sin tener que leer ese archivo entero.

### 3.2 — Confirmado: `HIS-RIS-PACS.jsx` real no maneja no-show ni cancelación en fase "agendados"

Revisado explícitamente (sin resultados al buscar `no_show`/`cancelad` en ese archivo). Confirma que esos 2 estados son responsabilidad exclusiva de la Agenda, nunca llegan al módulo operativo — coincide con cómo lo construimos.

### 3.3 — Cámara vs. escáner físico — para que MAIN no invierta esfuerzo de más

Un componente en el navegador **sí puede** activar la cámara (webcam o celular) vía `getUserMedia()`, API estándar, sin backend — ya está implementado y funciona de verdad en Imagenología. Un **escáner físico de oficina** (TWAIN/WIA) **no es accesible** desde el navegador sin una app puente local con su propia API — no es algo que se pueda resolver solo en frontend, cualquier plan de integración real necesita ese componente de infraestructura aparte.

### 3.4 — CUC sigue sin definición, después de 2 sesiones preguntando

Mencionado por el usuario en la sesión 3 del dossier original, con la promesa de que `cup.js` actualizado ya lo incluye — nunca se compartió el archivo ni se explicó el caso de uso. Sigue bloqueando cómo conecta con `PAGADORES`/convenios en cualquier módulo satélite que maneje facturación.

### 3.5 — Propuesta: el panel de notas de 4 niveles como componente compartido

Construido y validado primero en Imagenología (Generales / día de la semana / fecha exacta / por registro individual, todo acotado por contexto). Pensado desde el diseño para reutilizarse en las ~19 unidades de agenda, no solo en Imagenología — buen candidato a vivir en una librería de componentes compartidos de MAIN en vez de copiarse archivo por archivo.

### 3.6 — Los 3 caminos para "activar llegada" (recepción / tótem / portal) como patrón, no solo para Imagenología

Implementado con `canalLlegada` registrado en la orden y en la auditoría. Si Laboratorio, Oftalmología, etc. van a tener el mismo problema (un paciente puede llegar por distintos canales pero el estado final es el mismo), este patrón ya está resuelto y probado, no hay que rediseñarlo por unidad.

---

## 4. Resumen para decidir rápido

| # | Tema | Bloquea qué | Urgencia |
|---|---|---|---|
| 1.1 | Formato real de CUP/CUT | Todo el motor de identificadores, en los 3 satélites | Alta |
| 1.6 | Teléfono/correo faltan en `IDENTITY_SCHEMA` | Confirmaciones automáticas (WhatsApp/correo) | Alta |
| 1.3 | Granularidad de `atencion_clinica` | Propagar el patrón de Imagenología a otras unidades | Alta (antes de seguir construyendo) |
| 3.4 | CUC sin definir | Facturación/convenios en cualquier satélite nuevo | Media — ya lleva 2 sesiones abierta |
| 1.2 | Color de Imagenología | Solo estético | Baja |
| 1.4 | Marca de agua sin converger | Consistencia visual entre módulos | Baja |
| 1.5 | Gatillo de pánico por hold | Formalizar o retirar la extensión | Baja |
| 1.7 / 1.8 / 1.9 / 1.10 / 1.11 | Conexiones pendientes con roles/terminología/auditoría/tipos de usuario/ciclo de vida | Todas son "honestas" — no bloquean, pero hay que dejarlas explícitas para no perder el hilo | Media, para cuando haya backend |
