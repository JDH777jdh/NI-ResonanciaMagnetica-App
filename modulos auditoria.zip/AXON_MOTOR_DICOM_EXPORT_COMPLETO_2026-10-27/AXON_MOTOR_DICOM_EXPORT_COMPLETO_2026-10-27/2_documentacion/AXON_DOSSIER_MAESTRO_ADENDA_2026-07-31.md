# AXON RIS/PACS — Adenda 5: Explicit VR real + validación con DICOM reales por DIMSE
## Sesión 31-jul-2026 — continuación directa de la Adenda 4 (punto 1: el motor)

## 1. Qué se construyó

`dicom-engine/src/pdu/ExplicitVrCodec.js` — codec real de Explicit VR Little Endian (PS3.5 §6.2.1), mismo estilo que `ImplicitVrCodec.js` (propio, byte a byte, bien comentado). Soporta:
- Forma corta (longitud de 2 bytes) y forma larga (2 reservados + longitud de 4 bytes) según el VR — la distinción real que exige el estándar.
- VRs numéricos binarios (US/UL/SS/SL/FL/FD) — encode y decode simétricos.
- Secuencias (SQ) con longitud **definida e indefinida** — el segundo caso con Item Delimitation y Sequence Delimitation reales, encontrados recorriendo elementos de verdad (recursivo), no adivinados por bytes sueltos.
- Ventaja real sobre el decoder de Implicit VR: como el VR viene en el propio stream, no necesita el diccionario externo (`knownSQTags`) para saber qué es una secuencia.

`AeRegistry.TRANSFER_SYNTAXES_ESTANDAR` vuelve a aceptar Explicit VR LE — esta vez de verdad soportada, no solo negociada (ver Adenda 4 §3 para la historia del hallazgo original). `AssociationServer._handleCFindWorklist` ahora elige el codec correcto según el Transfer Syntax realmente negociado para cada Presentation Context, no asume uno fijo.

## 2. Un bug propio encontrado y corregido en el camino

El primer intento del decoder no tenía el lado de decodificación para VRs numéricos (US/UL/etc.) — solo el de encode. Es el mismo bug que ya habíamos encontrado y corregido en `ImplicitVrCodec.js` hace algunas sesiones, y se repitió acá a pesar de ya conocerlo. Los tests lo encontraron de inmediato (Group Length del File Meta se leía como texto corrupto en vez de como entero), se corrigió antes de seguir.

## 3. Verificación — 3 niveles, el último con DICOM real por DIMSE genuino

- **Round-trip propio** (`test/explicit-vr.e2e.test.js`): VRs planos, binario, SQ con longitud definida — contra el propio encoder.
- **Longitud indefinida armada a mano** (mismo archivo): un buffer de secuencia con Item/Sequence Delimitation construido byte a byte en el test, no generado por el codec — para no probar el decoder contra sí mismo.
- **DICOM reales completos, sin dcmjs**: `CT_small.dcm`/`MR_small.dcm` (pydicom, ya usados en sesiones anteriores) decodificados de punta a punta — File Meta + dataset — con el codec propio nuevo. Rows/Columns/Modality coinciden exacto con lo ya confirmado antes con dcmjs.
- **La prueba decisiva** (`test/real-dicom-explicit-vr.e2e.test.js`, nuevo, con `test/fixtures/CT_small.dcm` como fixture permanente del repo): `CT_small.dcm` real enviado por **C-STORE genuino vía DIMSE completo** — la asociación acepta Explicit VR (antes se rechazaba), el C-STORE se completa, y el dataset guardado (incluye Pixel Data) es **byte a byte idéntico** al original. El File Meta difiere entre original y guardado — correcto por estándar, cada sistema receptor reconstruye el suyo, un C-STORE no transmite el File Meta del emisor. WADO-RS `/rendered` funciona sobre la imagen recién ingresada.

`npm test` corre los 4 archivos — 30 checks en total, confirmado también desde una instalación limpia (`npm install` desde cero).

## 4. Estado de la lista de gaps (Adenda 4 §1)

Explicit VR: **cerrado**. Pendiente en la misma categoría: multiframe (cine US/XA), color (RGB/YBR), y compresión (JPEG/JPEG2000) — ninguno bloqueado por este trabajo, todos documentados como puerta etiquetada en el README del motor.

## 5. Otros temas tratados esta sesión (fuera del motor, resumen)

- **Integración con Agenda Web** (módulo satélite): confirmado el punto de integración — una cita externa debe crear un registro directo en `fase: "agendados"`, mismo molde que ya usa "Ingreso manual" para `fase: "admision"`. Recomendado FHIR REST (`ServiceRequest`/`Appointment`) sobre HL7v2, dado que no hay sistema legado de por medio. Gap real identificado: no tenemos MPPS — se usa la llegada de C-STORE como aproximación honesta para el webhook de "examen terminado" mientras no se construya el servicio DIMSE real (N-CREATE/N-SET).
- **Consentimiento informado, EIMS, VNA — evaluación honesta de dónde estamos parados** (dossier "Integración Agenda Web con RIS/PACS con consentimiento informado"): los 2 SOP Class UID que trae el documento se verificaron correctos contra el estándar (`1.2.840.10008.5.1.4.1.1.104.1` Encapsulated PDF, `1.2.840.10008.5.1.4.1.1.77.1.4.1` Video Photographic Image). Pero el diseño de consentimiento de doble firma (FESpa/FESpro) con encapsulación DICOM que describe **no está construido** — hoy solo existe un campo booleano y un checkbox de validación. Tampoco somos todavía un EIMS (falta wrapping de no-DICOM, ingesta multi-protocolo) ni tenemos un VNA (tenemos el motor DICOM propio y neutral que un VNA necesita por debajo — la parte más difícil — pero no la capa VNA en sí: wrapping, ILM, gateways FHIR/HL7 para no-imagen). Ver conversación completa para el detalle punto por punto.

## 6. Próximos pasos

Sin cambios de fondo respecto a la Adenda 4 — bloqueados por los mismos archivos de siempre (`security_config.js`, `roles.config.js`, `userTypes_config.js`, TLS zip, roles satélite). Candidatos concretos para la próxima sesión de motor: multiframe o color en `/rendered` (ninguno requiere decisión de producto todavía), o el wrapping DICOM Encapsulated PDF para consentimiento (extensión chica de `CStoreDataset.js`, ya con SOP Class UID verificado).
