# AXON RIS/PACS — Adenda 3: Ingreso manual + Bono/Pago + Tótem + Selector de fecha
## Sesión 21-jul-2026 (continuación) — mientras se preparan roles.config.js / security.config.js / userTypes_config.js

**Contexto:** se pidió avanzar en algo que no dependiera de esos 3 archivos. Se tomó §10 y §11 del dossier de ampliación (ingreso manual + bono/pago), que son autocontenidos dentro de `HIS-RIS-PACS.jsx`. De paso se cerró §9 (selector de fecha), que ya tenía el estado (`fechaFiltro`) listo pero sin ningún control de UI conectado — hallazgo menor encontrado al revisar la barra de filtros.

**Todo lo de esta adenda está verificado con interacción real** (jsdom + Testing Library, no solo lectura de código ni snapshot): se montó el componente, se simularon clics/inputs reales, y se verificó el DOM resultante en cada paso — igual rigor que los tests del motor DICOM.

---

## 1. Selector de fecha (§9) — hecho

`fechaFiltro`/`setFechaFiltro` ya existían y se usaban para filtrar, pero no había ningún `<input>` conectado. Se agregó un `<input type="date">` entre el buscador y los chips de modalidad, con botón para limpiarlo. Verificado: cambia de valor correctamente al interactuar.

## 2. Autoatención por tótem (§11b) — hecho

Nuevo botón "Autoatención (tótem)" junto a "Marcar llegada", visible solo cuando el paciente está en estado `agendado`/`confirmado`. Un solo clic simula portal+tótem completo: asigna un bono (`origen: "autoatencion"`, autogenerado) y salta directo de Agendados a Worklist — "sin pasar por revisión de administrativa", tal como pide el dossier.

**Verificado interactivamente:** clic en el botón → el paciente desaparece de la tabla de Agendados → aparece en la tabla de Worklist con estado Arribado → **no** aparece todavía en Admisión (correcto: el bono queda pendiente pero el examen no ha llegado a Almacenado, así que no debe activarse la alerta antes de tiempo).

## 3. Bono / Pago (§11a, §11b.2, §11b.3) — hecho

**Modelo de datos:** `bono: null | { numero, origen: "presencial"|"autoatencion", estado: "pendiente_pago"|"validado"|"anulado" }`. Se agregó el estado `reagendado` a `ESTADOS` (no existía).

**Visibilidad cruzada en Admisión:** además de `fase === "admision"`, la pestaña Admisión ahora también muestra cualquier registro con bono pendiente cuyo examen ya llegó a Almacenado o Reagendado — es la interpretación literal de "administrativa lo busca en la pestaña Admisión" (§11b.2), incluso si el registro ya avanzó de fase. El contador de la pestaña se ajustó para que coincida con lo que realmente se ve.

**4 estados visuales en la columna Bono** (componente `BonoCell`, reusado también en el panel de detalle):
1. Sin bono → botón "Ingresar bono".
2. Bono pendiente, examen no Almacenado → visible, no clickeable.
3. Bono pendiente **y** Almacenado/Reagendado → botón con alerta parpadeante (reusa la animación `rpPulse` que ya existía para prioridad "stat" — mismo lenguaje visual, no una animación nueva) → abre la mini-ventana.
4. Bono resuelto → badge final.

**Mini-ventana de "finalizar pago":** ofrece Validar bono / Anular bono / **Reagendar en su lugar** — las 3 juntas a propósito (ver nota de diseño abajo).

**Verificado interactivamente, ciclo completo:** ingresar bono → fila muestra "pendiente" (no accionable) → completar admisión → Worklist → Guardar → (esperar el `setTimeout` real de `guardarYEnviar`, no simulado) → Almacenado → vuelve a aparecer en Admisión con la alerta parpadeante → abrir mini-ventana → aparecen las 3 opciones → Validar bono → desaparece de Admisión (ya no necesita la visibilidad cruzada).

**Nota de diseño (decisión mía, avisar si no calza):** el dossier separa "se reagenda" (§11b.1) de "Validar/Anular bono" (§11b.2) como si fueran ramas distintas del flujo. Modelar cuál de las dos corresponde según lo que el paciente "quiso" habría significado inventar un estado que el dossier no pide — en vez de eso, las 3 opciones quedan juntas en la misma mini-ventana y quien está mirando la pantalla (que ya habló con el paciente, o constató que no volvió) elige la que corresponde.

## 4. Ingreso manual de paciente (§10) — hecho

Botón "Ingreso manual" — **solo en la pestaña Worklist**, tal como especifica el título de esa sección del dossier ("botón en Worklist"). Abre una mini-ventana con RUT (con match automático: si el RUT ya existe en cualquier fase, muestra el nombre encontrado y reutiliza el mismo CUP en vez de crear uno nuevo), nombre, edad, sexo, modalidad, procedencia, examen a realizar, y adjuntar orden médica (PDF/foto). El registro nuevo nace en fase Admisión, con la misma forma exacta que un registro del SEED (mismo cálculo de ACC/OT/timestamps/CIE-10 vacío, etc.) — no es un objeto distinto "a medias".

**Decisión de UX (mía, no estaba especificada):** al confirmar, la pestaña activa cambia sola a Admisión, para que se vea de inmediato dónde quedó el paciente — el botón vive en Worklist pero el registro aterriza en otra pestaña, y sin este salto automático quedaría "invisible" para quien lo acaba de crear.

**Verificado interactivamente:** escribir un RUT que ya existe en el SEED (Isidora Vergara) muestra el aviso de match con el nombre correcto → completar el resto → confirmar → el modal se cierra solo → el nuevo registro aparece en Admisión.

## 5. Un bug real encontrado y corregido en el camino

`ImplicitVrCodec.encodeElement` no soportaba VRs numéricos binarios (US/UL/SS/SL/FL/FD) — ver README de `dicom-engine` y Adenda 2 para el detalle completo; se menciona acá también porque es el mismo motivo por el que hubo que tocar ese archivo esta sesión, aunque el trabajo de esta adenda es sobre `HIS-RIS-PACS.jsx`, no sobre el motor.

## 6. Verificación — qué se corrió, no solo qué se leyó

- **jsdom + `@testing-library/dom` crudo:** 24 aserciones, cubriendo cada paso del ciclo completo (ver §2-4 arriba).
- **Portado a Vitest + `@testing-library/react` + `@vitejs/plugin-react`** (el stack idiomático de un proyecto Vite real, no mi arnés artesanal) — `HIS-RIS-PACS.interaction.test.jsx`, incluido en el paquete. 4 tests, 4 pasan, corrido desde un entorno limpio con `npm install` real.
- Para correrlo en tu proyecto: `npm install -D vitest @testing-library/react @testing-library/dom jsdom @vitejs/plugin-react` y luego `npx vitest run HIS-RIS-PACS.interaction.test.jsx` con esta config mínima (`vitest.config.js`, no incluida en el paquete para no pisar la tuya si ya tienes una):
  ```js
  import { defineConfig } from 'vitest/config';
  import react from '@vitejs/plugin-react';
  export default defineConfig({ plugins: [react()], test: { environment: 'jsdom', globals: true } });
  ```
- `esbuild` confirma sintaxis válida en cada paso (se usó como chequeo rápido intermedio mientras se editaba, no como verificación final por sí solo).

## 7. Pendiente — sin cambios de fondo

Sigue igual que Adenda 1 y 2: bloqueados por archivos faltantes (`security_config.js`, `roles.config.js`, `userTypes_config.js`, TLS zip, `AXON_Actualizacion_Roles_Modulos_Satelite.md`). Todo lo de §10-11 del dossier de ampliación queda cerrado con esta adenda.
