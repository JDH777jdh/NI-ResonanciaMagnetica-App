# AXON — Arquitectura de Interoperabilidad Nacional
## Documento de consolidación · 5 vueltas de discusión arquitectónica · 25-jul-2026

**Qué es esto:** consolida cinco conversaciones sobre cómo debería crecer AXON de "RIS/PACS de Imagenología" a "HIS-EMR-ERP nacional" — comparación contra sistemas de alta gama, cómo se integra imagen+laboratorio+ficha clínica en el mundo real, el marco legal chileno verificado ley por ley, el estándar técnico concreto que ya existe en MINSAL, el caso específico de patología digital, y la evaluación + chequeo regulatorio del dossier comercial (AXON Health/Core/Country/World). Todo lo legal y lo de MINSAL fue verificado por búsqueda directa, no es memoria de entrenamiento — se anota la fuente en cada punto que importa.

---

## Resumen ejecutivo

1. **El motor DICOM ya construido (`dicom-engine`) es, de diseño, la pieza correcta para escalar** — no sabe ni le importa qué departamento produjo la imagen, así que sumar Cardiología, Oftalmología o Patología digital no es "otro PACS", es registrar equipos nuevos y construir una capa de Worklist liviana encima del mismo motor.
2. **Laboratorio (LIS) no es una imagen y no debe forzarse a un archivo tipo PACS** — es un tipo de dato distinto (valores estructurados), se integra al mismo paciente vía FHIR (`Observation`/`DiagnosticReport`), no vía DICOM.
3. **La arquitectura federada no es una preferencia de diseño — es requisito legal.** La Ley 21.668 obliga a compartir la ficha clínica entre prestadores, pero cada prestador sigue siendo el custodio; no existe (ni se puede construir legalmente) un repositorio centralizado único de propiedad de AXON.
4. **MINSAL ya tiene un estándar técnico concreto en desarrollo activo** — el Núcleo de Interoperabilidad de Datos (NID), con perfil de paciente propio y operaciones de cruce de identidad ya definidas. Diseñar el modelo de paciente de AXON compatible con esto desde ya evita una migración cara después.
5. **Multi-tenant no significa una sola base de datos con una columna `tenant_id`** — el estándar recomendado para SaaS de salud en esta etapa es esquema separado por tenant, con camino claro a base de datos separada para clientes grandes.
6. **Entre clínicas distintas que usen AXON, no existe una base de pacientes compartida por defecto** — el cruce de identidad entre organizaciones separadas se hace bajo consentimiento, vía operaciones FHIR estándar (`Patient/$match`), no por infraestructura compartida.
7. **Patología digital (biopsias) sí converge hacia PACS/DICOM a nivel mundial** (Suplemento 145 de DICOM, WSI), y la propia ley chilena ya reconoce trato especial para patologías complejas (cáncer) con retención más allá de los 15 años estándar.
8. **Cualquier plataforma que almacene datos de salud o haga telemedicina necesita acreditación MINSAL — no es un requisito exclusivo del nivel "AXON Country", aplica desde el primer tenant.** La telemedicina en sí ya es real y masiva en Chile (Ley 21.541, millones de teleconsultas/año) — el dossier comercial no está apostando a algo hipotético.
9. **"AXON Country" tal como está planteado en el dossier comercial necesita reformularse.** El NID-MINSAL es una especificación, no una aplicación desplegada — eso es correcto — pero el rol de acreditar/fiscalizar es una función legal de MINSAL que no es tercerizable a quien construya primero. El camino realista no es "AXON reemplaza al Estado", es "AXON se acredita como nodo conformante" (disponible ya) o "AXON gana una licitación para construir piezas de la infraestructura" (real, pero vía procedimiento formal).
10. **El dossier comercial describe 5-6 productos masivos (ambulancias, delivery de fármacos, wearables, dashboard epidemiológico, analítica OMS) sobre una base técnica que recién está terminando su primer módulo.** No es necesario recortar la visión, pero sí secuenciarla — cada uno abre su propio mundo regulatorio (transporte de pacientes, dispensación farmacéutica, posible clasificación como dispositivo médico para los wearables).

---

## 1. Comparación — AXON RIS/PACS vs. sistemas de alta gama (OsiriX/Horos y PACS enterprise)

Lo que ya está a la par: el protocolo de red. AXON ya implementa C-STORE, C-FIND/MWL, C-ECHO y DICOMweb (QIDO-RS, WADO-RS, `/rendered`) — la misma base de protocolo que usa OsiriX (que soporta C-STORE SCP, C-FIND SCU, WADO, y hoy también DICOMweb completo).

**Brechas por prioridad:**

| Nivel | Falta | Por qué importa |
|---|---|---|
| Protocolo (bloquea equipos reales) | Explicit VR + Transfer Syntax comprimida (JPEG2000) | Confirmado con archivos reales de pydicom: equipo real ofrece Explicit VR con frecuencia: el motor hoy lo rechaza (correcto, no lo corrompe) pero limita compatibilidad real |
| Protocolo | Multiframe (cine US/XA) y color (Doppler, endoscopía) | Ya marcados como puerta etiquetada, correcto no fingir que funcionan |
| Clínico | MPR/3D real, fusión PET-CT | Necesita datos volumétricos reales (spacing entre cortes), no una imagen sintética — coherente mantenerlos apagados hasta tener esos datos |
| Clínico | DICOM SR (Structured Report) | El Informe hoy guarda texto/CIE-10 en modelo propio, no como objeto DICOM estándar — necesario para que OTROS sistemas lean el informe, no solo la propia UI |
| Clínico | Presentation States (GSPS) | Guardar/restaurar ventana, zoom y anotaciones como objeto DICOM — hoy se pierde al cerrar el visor |
| Clínico | Hanging protocols automáticos, comparación real con estudios previos | El sidebar de previos ya tiene el lugar, falta el dato |
| Empresa | IA/CAD (identificación de anatomía, prellenado de mediciones) | Tendencia fuerte 2026, no urgente ahora — pero vale dejar el informe estructurado para que un modelo lo prellene después sin rediseñar todo |
| Empresa | SSO/MFA real, TLS obligatorio, conformance statement formal, auditoría tipo ATNA | Hoy: sesión demo, TLS opcional, sin conformance statement, auditoría solo en consola |

---

## 2. Cómo se integra imagen + laboratorio en el mundo real

Una VNA (Vendor Neutral Archive) de verdad depende de 3 estándares trabajando juntos: DICOM para codificación de imagen y query/retrieve, perfiles IHE XDS/XDS-I para compartir documentos entre organizaciones, y HL7 para ligar la imagen al paciente. Eso es exactamente lo que `dicom-engine` ya es, en miniatura.

**Corrección importante a una confusión de terminología surgida en la discusión:** LIS (Laboratory Information System) es un término real y válido — el sistema que gestiona el flujo de laboratorio. El error es hablar de "LIS-PACS": PACS específicamente significa archivo/comunicación de **imágenes**, y un resultado de laboratorio no es una imagen, es un valor numérico con unidad y rango de referencia. El estándar mismo (FHIR) trata imagen y laboratorio como tipos de datos distintos que confluyen en el reporte, no como el mismo tipo de archivo: un `DiagnosticReport` referencia `ImagingStudy` (imagen) y `Observation` (resultado de laboratorio) por separado, nunca fusiona ambos en un solo objeto.

**Recursos FHIR clave y su rol:**
- `Patient` — identidad del paciente
- `ImagingStudy` — puntero/metadato de un estudio DICOM (no la imagen en sí — la imagen vive en el motor DICOM/DICOMweb)
- `Observation` — un resultado individual (ej. nivel de glucosa, una medición)
- `DiagnosticReport` — el informe completo, referencia a `ImagingStudy` y/o a una o más `Observation`
- `ServiceRequest` — la orden/solicitud que origina todo el flujo
- `Encounter` — cada consulta o ingreso
- `Condition` — diagnósticos bajo CIE-10/CIE-11
- `MedicationRequest` — receta médica

Codificación estándar para que distintos laboratorios/clínicas se entiendan: **LOINC** para nombres de pruebas de laboratorio, **SNOMED-CT** para términos clínicos generales, CIE-10/CIE-11 para diagnósticos (ya en uso en AXON).

---

## 3. Arquitectura recomendada — "una plataforma, módulos separables"

Un `DiagnosticReport` amarra todo sin fusionar nada: referencia `ImagingStudy` (imagen) y `Observation` (laboratorio) por separado. Ese es el patrón a replicar en AXON:

- **AXON-Core** — identidad de paciente (CUP), sesión/roles, auditoría. Al centro.
- **AXON-Imaging** — el `dicom-engine` ya construido. Sirve a cualquier departamento que produzca DICOM: Radiología (hecho), Cardiología, Oftalmología, Patología digital, Endoscopía.
- **AXON-Lab** — módulo nuevo, modelo de datos tipo `Observation`/`DiagnosticReport`, sin relación con el motor DICOM.
- **EMR** — la capa que junta ambos por paciente, más notas clínicas/narrativa.

Cada módulo se desarrolla, prueba y despliega por separado — pero comparten identidad de paciente y login desde el día uno (idealmente vía SMART on FHIR: mismo OAuth2 tanto para la API FHIR como para DICOMweb).

---

## 4. Dónde viven las fichas clínicas — modelo multi-tenant

Para un SaaS de salud multi-clínica en esta etapa (recién empezando, escalando a nacional/internacional), el patrón recomendado es **schema separado por tenant** — no una tabla compartida con una columna `tenant_id` (Row-Level Security de PostgreSQL por sí sola NO es suficiente aislamiento para cumplir con lo que exige una revisión de seguridad enterprise en salud), y tampoco base de datos separada por tenant desde el día uno (demasiado overhead operacional para el tamaño actual). Schema-per-tenant da el aislamiento real que exige compliance, con camino claro a "database-per-tenant" para clientes grandes que lo exijan más adelante.

**Cada clínica (tenant) es dueña y custodia de su propia ficha clínica**, viviendo en su propio schema — nunca mezclada con la de otras clínicas que usen AXON, ni siquiera lógicamente.

---

## 5. HL7/FHIR entre clínicas — identidad de paciente a través de tenants

Esta es la pregunta que más cambia el diseño: **no existe una base de pacientes compartida entre todas las clínicas que usen AXON.** Mezclar datos de instituciones distintas sin consentimiento explícito del paciente violaría la Ley 19.628/21.719.

El patrón real, con nombre:
- **Dentro de una sola organización** (una clínica, sus distintas sedes): un **MPI** (Master Patient Index) centralizado — recibe datos demográficos desde múltiples sistemas de origen, aplica coincidencia determinística/probabilística, asigna un ID único de empresa. Esto ya lo tienes: tu CUP.
- **Entre organizaciones separadas** (dos clínicas distintas, cada una dueña de sus datos): el patrón IHE es **PIX/PDQ** (Patient Identifier Cross-referencing / Patient Demographics Query) para consultar identidad entre sistemas, o su equivalente más nuevo, **XCPD** (Cross-Community Patient Discovery) y **PMIR** (Patient Master Identity Registry, basado en FHIR) — mantienen una "identidad dorada" colaborativa entre fuentes que cooperan, consultada solo cuando hay un motivo real (una derivación, un paciente que autoriza compartir su historial entre dos clínicas).

**En la práctica para AXON:** cada clínica tiene su RUT-CUP interno. El día que dos clínicas necesiten ver al mismo paciente, no se fusionan las bases — se expone un endpoint FHIR tipo `Patient/$match` para que una consulte a la otra, con el consentimiento como parte del flujo, no como configuración de infraestructura.

---

## 6. Marco legal chileno — verificado ley por ley

| Ley | Qué dice (verificado) | Implicancia para AXON |
|---|---|---|
| **Ley 21.668** (28-may-2024, modifica Ley 20.584) | Obliga a compartir la ficha clínica entre prestadores públicos y privados para continuidad de cuidado. Los prestadores **conservan la custodia** — mínimo 15 años desde el último ingreso de información. Un reglamento (pendiente, MINSAL tiene 18 meses desde la entrada en vigencia para dictarlo) fijará cómo se garantiza la interoperabilidad. | Confirma: AXON debe ser autopista de datos, no dueño — arquitectura federada no es opción, es la única legal |
| **Ley 21.668 — retención extendida** | Se acordó que un reglamento determine qué información **nunca debe desecharse** en el caso de patologías complejas como cáncer y enfermedades raras — más allá de los 15 años estándar | Conecta directo con por qué la anatomía patológica/biopsias reciben trato especial (ver §7) |
| **Ley 21.663** (8-abr-2024, Marco de Ciberseguridad) | Crea la ANCI. Clasifica "salud" entre los sectores de Servicios Esenciales. El nivel más exigente, Operador de Importancia Vital (notificación de incidentes en 3 horas), requiere calificación individual por resolución fundada de la ANCI — no es automático por estar en salud | AXON probablemente parte como Servicio Esencial; OIV es una calificación posterior, no un punto de partida |
| **Ley 19.628 → Ley 21.719** | 19.628 (protección de datos, vigente hoy) está siendo reemplazada por 21.719, con vigencia plena recién el 1-dic-2026. Los plazos de la 21.719 son anteriores a la mayoría de los plazos técnicos de la 21.668 — protección de datos es el paso más urgente, antes que la interoperabilidad técnica | Diseñar contra 21.719 directamente, no contra la ley que está por reemplazarse |

---

## 7. El estándar técnico concreto — NID-MINSAL

No es solo "FHIR genérico exigido por el Ministerio" — existe un desarrollo activo, público, verificable hoy:

- **Núcleo de Interoperabilidad de Datos (NID-MINSAL)** — `interoperabilidad.minsal.cl/fhir/ig/nid/`, código en GitHub (`Minsal-CL/NID`), versión activa 0.4.9 (STU1 Draft — no es publicación autorizada todavía, es *continuous build*), sobre FHIR R4.
- Incluye un **MPI** (Índice Maestro de Pacientes) y un **HPD** (Directorio de Prestadores Individuales e Institucionales) ya definidos.
- Operaciones de cruce de identidad ya especificadas: **`$ihe-pix`** y **`$match`** — exactamente los mecanismos PIX/PDQ del §5, ya con nombre y forma concretos en el estándar chileno.
- Perfil de paciente propio, **"MINSAL Paciente"**, que extiende el `Patient` FHIR estándar con campos chilenos: Cobertura de Salud (FONASA/Isapre), Nivel Educacional, Ocupación, Situación de Discapacidad.

**Recomendación concreta:** el modelo de `Patient` de AXON debería nacer compatible con el perfil `MINSALPaciente` desde ahora — mismo campo, mismo formato — para no migrar identidades después. El CUP interno de AXON debería poder mapear 1:1 al futuro identificador del MPI nacional.

**Sobre "el momento exacto" (confirmado, no es solo intuición):** la Agencia de Salud Digital (ASD) ya se formalizó como organismo técnico a cargo de operar la Red Nacional de Salud Digital, el NID sigue en desarrollo activo semana a semana en GitHub, y MINSAL tiene plazo legal para actualizar el reglamento de ficha clínica dentro de 18 meses desde la entrada en vigencia de la Ley 21.668 (2024) — ese plazo ya está corriendo.

---

## 8. Caso especial — Patología digital / Anatomía Patológica

**Sí, es real que la patología converge hacia PACS/DICOM**, no es percepción: el Suplemento 145 de DICOM agregó soporte específico para Whole Slide Imaging (imágenes en mosaico, multi-resolución), con un grupo de trabajo dedicado (WG-26) que organiza pruebas de interoperabilidad anuales entre fabricantes de escáneres y PACS. Filips, Leica/Aperio y Roche/Ventana ya soportan esto.

**Fricciones técnicas reales, no resueltas del todo ni siquiera por los jugadores grandes:**
- DICOM usa enteros de 16 bits para dimensiones de imagen — límite de 32.768×32.768 píxeles, un problema real que el estándar tuvo que abordar específicamente para WSI.
- Un escáner de patología standalone no lee DICOM por sí solo — necesita software que arme el archivo completo con datos del caso que vienen del LIS **después** del escaneo. A diferencia de Radiología (MWL llega *antes* del examen), en Patología el flujo es LIS-primero, protocolo-después — un patrón genuinamente distinto al que ya construimos.
- No todos los PACS/VNA están listos para servir WSI por su tamaño y forma de acceso (confirmado en fuente de 2025) — sigue siendo fricción activa, no resuelta.

**Regulación de diagnóstico primario (EE.UU., vía FDA):** un escáner pensado para que el patólogo diagnostique directo desde la imagen digital (sin revisar el vidrio físico) se clasifica como dispositivo Clase II, requiere autorización 510(k). Primera aprobación: Philips IntelliSite, abril 2017. Roche recién obtuvo la suya en 2024. No se investigó el equivalente chileno (ISP) — pendiente si es relevante para el roadmap.

**Gancho legal chileno directo:** la Ley 21.668 ya prevé retención más allá de los 15 años estándar específicamente para patologías complejas como cáncer — que se confirma mayormente por biopsia. Es la base legal de por qué "las biopsias son más importantes", no solo protocolo clínico.

**Qué significa para AXON:** el protocolo (DIMSE, DICOMweb) ya sirve — un WSI real podría entrar por el mismo `dicom-engine`. Lo que falta: un visor que pinte mosaicos por nivel de resolución (el `/rendered` actual pinta la imagen completa de una sola vez, no serviría para un gigapixel sin rehacerlo), y un flujo de Worklist que parta desde el LIS, no desde MWL. Puerta etiquetada candidata para cuando le toque el turno — no ahora.

---

## 9. El dossier comercial (AXON Health / Core / Country / World) — evaluación y chequeo regulatorio

Resume un documento interno (no oficial, no revisado aún por el equipo que desarrolla el main) que plantea 4 capas de plataforma — **AXON Health** (red de profesionales independientes, ambulancias, delivery de fármacos, juntas médicas), **AXON Core** (SaaS para instituciones — clínicas, hospitales, centros de diagnóstico, laboratorios: es literalmente donde vive todo lo que hemos construido hasta ahora), **AXON Country** (consola de gobernanza para Seremis/MINSAL), **AXON World** (analítica global con OMS/OPS) — con un modelo de monetización de 5 dimensiones (B2C freemium, B2B2C, SaaS B2B, G2B/B2G, marketplace con comisiones) y 7 niveles de escalabilidad de comuna a mundial.

### 9.1 Qué calza bien con lo ya construido

CUP, CUT (Código Único Trabajador) y CUI (Código Único Institución) son consistentes con lo que ya existe en el código — CUP ya es un campo real en los registros de Worklist, no algo que este documento inventa. AXON Core, específicamente, es donde vive el RIS/PACS, el futuro LIS y la futura Patología digital de los que hablan las secciones 1-8 de este documento — vale la pena que el equipo tenga explícito que "lo que estamos construyendo" = "AXON Core", y que Country/World son ambiciones de otro orden y horizonte.

### 9.2 Chequeo regulatorio — verificado, no asumido

| Afirmación del dossier | Verificación | Implicancia |
|---|---|---|
| Red de telemedicina (AXON Health) | **Real y ya masivo.** Ley 21.541 (marzo 2023) regula la atención a distancia. Las teleconsultas pasaron de 1% (2019) a 15-20% de las consultas (2025); Chile superó 5 millones de teleconsultas anuales en el sistema público hacia 2026. No es apuesta, hay demanda validada | El módulo es viable — pero ver el punto siguiente antes de construirlo |
| Cualquier tier de AXON que almacene datos de salud o haga telemedicina | **Requiere acreditación MINSAL vía reglamento y normas técnicas.** No es un requisito de "AXON Country" — aplica desde AXON Core, desde el primer tenant | Meter el trámite de acreditación al roadmap de cumplimiento ahora, no al final |
| Delivery de medicamentos (marketplace B2B) | **Regulado, pero la responsabilidad legal es de la farmacia, no de AXON.** Cada farmacia necesita autorización ISP propia para venta electrónica; el director técnico (químico farmacéutico) responde por la conservación y calidad del despacho. Para medicamentos de control especial, la receta electrónica necesita firma electrónica avanzada (Ley 19.799) con bloqueo de reuso, específicamente para prevenir tráfico ilícito | AXON no necesita licencia de farmacia — pero debe validar que cada farmacia socia tenga su autorización ISP vigente antes de conectarla, y su receta electrónica debe hablar con firma avanzada real, no un campo de texto |
| Emisión de licencias médicas por telemedicina | Ley 21.746 (mayo 2025) exige **Sello de Calidad RCE** y certificación de la plataforma ante FONASA específicamente para esta función | Requisito adicional, separado de la acreditación general, solo si se persigue esta función puntual |

### 9.3 "AXON Country" — el análisis de si ese espacio está libre para ocupar

Surgió la pregunta directa: ¿el NID-MINSAL es solo una guía técnica (no una aplicación), así que AXON podría ocupar el lugar de "aplicación" que falta?

**La premisa es correcta:** un FHIR Implementation Guide es una especificación — perfiles de datos, operaciones, reglas de conformidad — no un software desplegado. Nadie "opera" un IG, se opera un servidor que lo implementa.

**Pero la conclusión no se sostiene del todo:** que la especificación esté vacía de aplicación no significa que el rol de *operarla* esté vacío también. MINSAL tiene, entre sus funciones legales definidas, establecer el sistema de acreditación para los prestadores autorizados a funcionar — es decir, el rol de MINSAL es estructuralmente el de **regulador/acreditador**, una función que no es tercerizable a un privado por definición (un acreditador no puede tercerizar su propia función, porque entonces ¿quién lo acredita a él?).

Con un matiz real encontrado: una propuesta de política pública reciente señala que la institucionalidad actual **carece de las facultades transversales necesarias** para estandarizar y fiscalizar la salud digital en todo el ecosistema público y privado — comparando con modelos de otros países: Canadá usa Canada Health Infoway, un organismo financiado por el gobierno federal pero de operación semi-independiente; Estonia resuelve esto como infraestructura 100% estatal (X-Road). Ningún precedente serio es "una empresa privada se convierte en la infraestructura por defecto" — el modelo operativo definitivo en Chile, de hecho, **todavía parece estar en debate de política pública activo**, no cerrado.

**Dos caminos realistas, no uno:**
1. **Disponible ya, sin necesidad de ganarle nada al Estado:** AXON construye su `Patient` compatible con `MINSALPaciente`, se acredita como plataforma de salud digital (trámite obligatorio de todas formas), y cada clínica-tenant de AXON queda lista para conectarse a la red nacional el día que exista — ventaja competitiva real sobre cualquiera que lo resuelva después.
2. **Ambicioso pero legítimo:** competir por o ganar una licitación pública o convenio de colaboración con MINSAL/la futura entidad rectora para construir piezas específicas de la infraestructura — hay precedente de privados construyendo infraestructura de salud pública en Chile, siempre bajo contrato formal, nunca por ocupación unilateral.

**Recomendación para el material del dossier:** reformular "AXON Country" de *"AXON reemplaza/es la infraestructura de gobierno"* a *"AXON se acredita y ofrece sus capacidades para que MINSAL/la entidad rectora las adopte o licite"* — mismo objetivo comercial, pero alineado con cómo realmente se otorgan estos roles en Chile. Importa especialmente si este material llega a inversionistas o al propio Ministerio.

### 9.4 Riesgo de alcance — nota honesta, no una crítica a la ambición

El dossier describe, en los hechos, 5-6 productos distintos y masivos — despacho de ambulancias, delivery de fármacos, monitoreo con wearables, dashboard epidemiológico nacional, analítica predictiva mundial con la OMS — cada uno con su propio mundo regulatorio (transporte de pacientes, dispensación farmacéutica, posible clasificación como dispositivo médico si los wearables emiten alertas automáticas de forma autónoma). Nada de esto es imposible, pero el equipo técnico hoy está recién estabilizando el primer módulo (RIS/PACS de Imagenología). La ambición no sobra — la secuencia sí importa: el propio dossier ya define 7 niveles de escalabilidad comercial, vale la pena usar esa misma progresión para decidir qué construir primero técnicamente, no solo qué vender primero.

### 9.5 Lo directamente aprovechable para la estructura RIS/PACS multimodal

1. El dossier liga parte del cobro SaaS institucional al "volumen de exámenes de imagenología o laboratorio" — requisito técnico real y accionable ya: `StudyIndex` debería poder responder "cuántos estudios de modalidad X tuvo el tenant Y este mes/período" desde ahora, porque es insumo de facturación, no solo de reporting clínico.
2. El aislamiento de datos que describe el dossier (§G del documento comercial) es específicamente para **cobros/facturación** — cada tenant con su propio entorno de facturación aislado. Es coherente con el schema-per-tenant recomendado en §4 de este documento para datos clínicos, pero son **dos aislamientos distintos que necesitan el mismo rigor**: uno para dinero, otro para fichas. El dossier resuelve bien el primero; el segundo hay que mantenerlo igual de explícito, no asumirlo.

---

## 10. Decisiones pendientes para el equipo

1. ¿Cuál es el segundo departamento a sumar después de Imagenología — Cardiología, Laboratorio, o Patología digital? Cada uno tiene un costo de entrada distinto (ver §1, §8).
2. Confirmar con el ISP si existe un equivalente chileno a la exigencia FDA para diagnóstico primario en patología digital, antes de comprometerse a esa ruta.
3. Decidir si el modelo de `Patient` de AXON se construye ya compatible con `MINSALPaciente` (recomendado) o se pospone.
4. Definir el punto de corte para pasar de schema-per-tenant a database-per-tenant (¿por volumen de pacientes? ¿por exigencia contractual de un cliente grande?).
5. Priorizar Explicit VR/JPEG2000 en el motor DICOM — es lo que más limita conectar equipo real hoy.
6. Reformular la narrativa de "AXON Country" en el material comercial/pitch (§9.3) antes de compartirlo con inversionistas o con el propio MINSAL.
7. Incorporar el trámite de acreditación MINSAL como plataforma de salud digital al roadmap de cumplimiento — aplica desde AXON Core, no solo en el horizonte de "AXON Country" (§9.2).
8. Si se persigue delivery de medicamentos, definir el proceso de verificación de autorización ISP de cada farmacia socia antes de conectarla al marketplace (§9.2).
9. Secuenciar los módulos del dossier comercial (ambulancias, wearables, delivery, dashboard de gobierno) respecto al roadmap técnico actual — decidir qué se construye en qué orden, no solo qué se vende en qué orden (§9.4).

