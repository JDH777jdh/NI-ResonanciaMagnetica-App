# AXON MAIN — Hoja de Ruta de Backend
## De dónde estamos hoy a dónde apunta la arquitectura ya diseñada

**Fecha:** 2026-08-16 · Responde a los puntos 1 y 9 de `Respuestas para el equipo MAIN + (2).txt`.

**Principio rector:** no hay que diseñar arquitectura desde cero. `axon_architecture_blueprint_v2_1.md` y `axon_technical_architecture_backend_dicom_db.md` ya la diseñaron con detalle real (esquemas SQL, diagramas de secuencia, stack tecnológico completo), y `COMENTARIOS_DEL_MD_DE_ARQUITECTURA.txt` ya validó y afinó decisiones clave (ej. partición de Kafka por CUP, no por TenantID; Row-Level Security como capa de blindaje). Esta hoja de ruta no reemplaza esos documentos — los **secuencia** contra lo que hoy existe de verdad en el código, siguiendo el mismo principio que ya usan Epic/Oracle Health en sus propias migraciones (evolución incremental, nunca reescritura total — ver `LA_MIRADA_DE_QUE_TENEMOS_vs_...pdf`).

Cada fase deja algo **funcionando de punta a punta** antes de sumar la siguiente capa de complejidad. No se salta ninguna fase.

---

## Fase 0 · Inventario — lo que ya existe (no repetir trabajo)

| Pieza | Estado real |
|---|---|
| `docker-compose.yml` | Postgres + Keycloak + HAPI FHIR + CoreAdapter + nginx (TLS) — sintaxis válida, **nunca levantado en vivo** |
| `CoreAdapter` (`index.js`) | 3 endpoints reales (`GET /facturas/:id`, `POST /ordenes-compra/:ocId/factura`, `GET /health`); el resto son placeholders 501 o arrays vacíos |
| `01-init.sql` | 10 tablas en esquema `core` (facturas cifradas, roles_activos, categorías/órdenes de compra, valores×2, convenios×4) — un solo esquema, no todavía schema-per-tenant |
| `DatabaseService.js` | El seam de abstracción ya existe (FhirAdapter/CoreAdapter/MockAdapter) — el frontend casi no lo llama todavía |
| HAPI FHIR | Imagen genérica en docker-compose, sin Chile Core IG cargado; `FhirAdapter._token()` lanza error a propósito ("aún no implementado") |
| Keycloak | Referenciado en docker-compose, cero realm/client/MFA configurado |
| Los 7 archivos de configuración fuente (`roles`, `security`, `userTypes`, `tenantTypes`, `cup`, `standards`, `iomt`) | Existen y son consistentes entre sí, con brechas ya identificadas y documentadas |
| Blueprint de arquitectura completo | Ya diseñado — ver los 2 documentos MD de arquitectura |

---

## Fase 1 · Cerrar UN loop real de punta a punta

**Sin Keycloak ni Kafka todavía.** Objetivo único: probar que `Frontend → DatabaseService.js → CoreAdapter → Postgres → vuelta` funciona de verdad, una vez, con datos reales — no mockeados.

**Candidato concreto:** `MarketingConvenios.jsx` + generación de CUC. Está ~90% listo: `generarCUC()` en `cup.js` ya tiene su formato final, `01-init.sql` ya tiene `core.convenios_empresas` con exactamente esos campos, la pantalla ya funciona en mock. Falta:
1. Levantar `docker-compose up` por primera vez y confirmar que los 5 servicios arrancan y se hablan entre sí.
2. Agregar `POST /convenios-empresas` a `CoreAdapter` (hoy no existe — es el único endpoint nuevo que hace falta para este flujo).
3. Conectar `DatabaseService.js` + `MarketingConvenios.jsx` a ese endpoint real, en vez de al `MockAdapter`.
4. Confirmar cifrado real end-to-end (el patrón `pgp_sym_encrypt` ya está probado en `facturas`, replicarlo si el convenio lleva datos sensibles).

*Por qué este y no Paciente/FHIR primero:* Paciente depende de Keycloak (Fase 2) para el token real y de mapeo FHIR (Fase 4) — sería resolver 3 fases a la vez para la primera prueba. Convenios/CUC no depende de ninguna de las dos.

---

## Fase 2 · Identidad real (Keycloak)

- Configurar el realm real, los clients, y el mapeo `roles.config.js` → roles de Keycloak (los 152+ roles ya existen, falta que Keycloak los reconozca).
- Resolver el intercambio de token que `FhirAdapter._token()` hoy deja explícitamente sin implementar — **nunca debe vivir en el navegador** (el client_secret quedaría expuesto), necesita un endpoint propio del servidor, tal como ya lo documenta el comentario de ese mismo archivo.
- Proteger el flujo de Fase 1 con JWT real — recién ahí "Fase 1" pasa de prueba de concepto a algo que podría ir a producción.

---

## Fase 3 · Completar CoreAdapter + organizar por dominio

- Construir los ~12 endpoints que todavía faltan (roles activos por tenant, valores FONASA/ISAPRE, categorías de compra reales, estándares de salud, etc.), cada uno contra la tabla de `01-init.sql` que ya le corresponde.
- **Nuevo (2026-08-19) — Panel de Módulos AXON, ya diseñado, pendiente de tu confirmación para construir:** responde a tu pregunta de si el personal de AXON puede activar/autorizar un módulo sin tocar código nunca. **Sí, y ya existe el precedente exacto en el propio proyecto:** `core.roles_activos` (en `01-init.sql`) + `CatalogosRoles.jsx` ya hacen esto mismo para roles — activar/desactivar es un dato en Postgres, no una línea de código. Propongo replicar el mismo patrón un nivel arriba, para módulos:
  - Tabla nueva `core.modulos_activos` (mismo shape que `roles_activos`: tenant_id, modulo_id, activo, actualizado_por_rol, actualizado_en).
  - Tabla nueva `core.solicitudes_modulo` (tenant_id, modulo_id, solicitado_por_rol, fecha_solicitud, estado [pendiente/aprobado/rechazado], resuelto_por_rol, fecha_resolucion, nota) — mismo patrón pendiente→aprobado que ya usan `CalidadEstandaresSalud.jsx` y las solicitudes de Farmacia/Bodega.
  - Dos pantallas: una del lado tenant ("Solicitar módulo nuevo", para `t_dir_admin_aplicacion`) que solo crea la solicitud; y un panel del lado AXON (para `axon_owner`/`axon_it`, ve solicitudes de **todos** los tenants) que aprueba/rechaza y ahí sí flipea `modulos_activos`.
  - Esto resuelve el choque de `userTypes.config.js`: el `permiso_extra` de `ADMIN_CLINICA` pasa de `"activar_modulos"` a `"solicitar_modulos"` (nunca activa directo); un permiso nuevo `"autorizar_modulos"` queda exclusivo de `axon_owner`/`axon_it`.
  - **No lo construyo todavía** — toca `01-init.sql` y `userTypes.config.js`, quiero tu confirmación explícita antes de tocar esos dos.
- Organizar el código de `CoreAdapter` en carpetas por dominio (`facturas/`, `convenios/`, `roles/`, `valores/`, `modulos/`...) aunque siga corriendo como un solo proceso Node — deja cortes limpios para separar en microservicios más adelante sin reescribir nada, sin construir Kafka/Kubernetes todavía.
- Empezar a aplicar Row-Level Security (`app.current_tenant_id` como variable de sesión) como capa de blindaje adicional — el diseño completo con SQL de ejemplo ya está en `axon_technical_architecture_backend_dicom_db.md`, sección de RLS.

---

## Fase 4 · FHIR real

- **Decidido (2026-08-16): HAPI FHIR, no Medplum** — por robustez para trabajar con MINSAL. Cargar el Chile Core IG en la instancia ya referenciada en `docker-compose.yml`.
- Mapear las tablas de Postgres que ya existen hacia recursos FHIR reales (Patient, Encounter, etc.).
- Activar el resto de `DatabaseService.js` (`crearPaciente`, `buscarPacientes`) contra el FHIR real en vez del mock.
- *Nota de capacidad:* confirmé que puedo ayudar a escribir/revisar el código que habla con HAPI FHIR (`FhirAdapter`, mapeos), pero no puedo levantar un HAPI FHIR real y persistente desde mi entorno — no tengo Docker ni acceso a su registro de imágenes, y este sandbox se reinicia entre tareas. El primer `docker-compose up` en vivo tiene que pasar en tu infraestructura.

---

## Fase 5 · Eventos + AXON NID Bridge

- Recién acá entra Kafka — con la estrategia que ya está decidida y razonada en `COMENTARIOS_DEL_MD_DE_ARQUITECTURA.txt`: **partición por CUP, no por TenantID.** Particionar por tenant satura la partición del hospital grande y deja vacía la de la posta rural (hot partitioning); particionar por CUP distribuye la carga parejo Y garantiza que todos los eventos de un mismo paciente lleguen en orden cronológico estricto, sin importar en qué tenant se atendió.
- **AXON NID Bridge como su propio microservicio** (ver respuesta a tu pregunta b arriba) — IHE PIX/PDQ/HPD, más Mirth Connect para el puente HL7 v2 legacy hacia SIDRA. No antes de esta fase: cruza la frontera público/privado y necesita el resto de la plataforma (identidad real, eventos, FHIR) ya funcionando debajo.
- **Resiliencia de NID Bridge (decidido 2026-08-16) — reutiliza el mismo patrón de 3 capas de `RESILIENCIA_IOMT`** (ya adoptado, diseñado originalmente para dispositivos médicos, aplica igual acá):
  - Capa tenant: cada tenant sigue operando 100% local aunque se caiga la conexión a MINSAL — nunca depende de NID Bridge para funcionar.
  - Capa transporte (el propio NID Bridge): *store-and-forward* — encola local si no puede enviar, reenvía al volver la conexión.
  - Capa aplicación: todo dato pendiente de envío se marca explícitamente (`en_vivo`/`desactualizado`/`sin_conexion`) — nunca se muestra como ya enviado si no lo está.
  - Servidor gemelo en la nube: una vez que Kafka esté con replicación activa, la durabilidad del evento deja de depender de que un solo nodo esté vivo — antes de eso, el store-and-forward de arriba es la cobertura real.
- **Timestamp seguro (decidido 2026-08-16):** NTP-sincronizado entre servidores para el log de auditoría interno; **sellado de tiempo de un prestador acreditado** (Decreto 181, Ley 19.799 Art. 5°) para todo lo que ya lleva FEA (epicrisis, consentimientos, certificados) — es lo que le da valor probatorio pleno a la fecha, no solo la firma. Falta elegir proveedor de sellado de tiempo cuando lleguemos a esta fase.
- **Modo de envío a MINSAL — viable ofrecer ambos (confirmado 2026-08-16):** automático (FHIR sync de esta fase, tier pago) vs. descarga estructurada + envío manual del propio tenant (tier base) — NID Bridge de todas formas necesita una función de exportación interna para pruebas, así que exponerla como autoservicio no es desarrollo aparte. Encaja con el modelo de monetización B2G tipo peaje que ya describe el documento maestro.
- Consolidar de una vez los eventos clínicos de acción (medicamento administrado, aislamiento, etc. — ya viven en `security.config.js` desde hoy) hacia el bus real, no solo hacia el log de auditoría.

---

## Fase 6 · Separación real en microservicios + Kubernetes

- Solo cuando el monolito de `CoreAdapter` ya esté completo, estable, y en uso real (no antes) — los cortes de dominio de la Fase 3 son justamente lo que permite separar sin reescritura.
- Recién acá Kubernetes. Antes de esto, K8s no tiene qué orquestar todavía.

---

## Fase 7 · AXON Country / World — diseño de datos (construcción al final, diseño ahora)

Respondido en detalle el 2026-08-20 — ya no es checklist abierto, es diseño real:

**Seudonimización (dentro de Chile) vs. anonimización (hacia el extranjero) — decidido:**
- Dentro de Chile: seudonimización reversible. Token↔RUT vive en una bóveda criptográfica aparte, cifrada con llaves gestionadas por HSM, accesible solo para revertir en auditorías/correcciones/reportes obligatorios. La base clínica operativa solo ve el Token, nunca el RUT directo.
- Hacia AXON World / fuera de Chile: anonimización irreversible antes de cruzar la frontera — deja de ser dato personal bajo Ley 21.719, evita el problema regulatorio de transferencia internacional.

**Pipeline de 3 zonas (Zero Trust):**
1. **Zona 1 — Operación clínica (Chile):** ingesta → servicio de tokenización → bóveda criptográfica (HSM) → almacenamiento clínico solo con Token.
2. **Zona 2 — Enclave de transformación:** servidor aislado, SIN acceso a la bóveda, solo lee de la base ya seudonimizada. Idealmente un TEE (Intel SGX / AWS Nitro Enclaves) para que ni el admin de sistema pueda ver el dato en memoria durante el proceso. Acá se ejecutan las 4 técnicas (abajo) y se destruye el token antes de exportar.
3. **Zona 3 — Analítica global:** recibe el dataset ya purgado — legalmente es exportación de estadísticas, no transferencia de datos personales.

**Las 4 técnicas, en orden, dentro de la Zona 2:**
1. Generalización forzada — fecha exacta→rango etario, comuna→región, fecha de transacción→semana epidemiológica/mes.
2. K-Anonimato (k≥5) — cada combinación de cuasi-identificadores debe repetirse al menos k veces; los atípicos (outliers) se suprimen de la exportación.
3. L-Diversidad — dentro de cada grupo k, el diagnóstico debe tener al menos L valores distintos bien representados (si no, un atacante que ubica el grupo igual infiere la enfermedad).
4. Privacidad diferencial — ruido estadístico (Laplace) sobre los resultados agregados, para que nunca se pueda probar si un registro específico participó del cálculo.
- Herramientas de referencia: ARX Data Anonymization Tool / `pycanon` (K-anon + L-diversidad), Google `differential-privacy` / OpenDP / IBM Privacy Toolkit (privacidad diferencial).

**Granularidad por nivel:** Local (establecimiento/comuna) = datos macro de gestión · Regional (provincia/región) = epidemiológico con bandas etarias amplias · Nacional (país) = diagnósticos agrupados · Internacional (continente/mundial) = altamente agregado.

**Categorías de dato a incluir** — alineadas a estándares (CIE, ATC/RxNorm, LOINC, SNOMED-CT, HL7 FHIR): GRD/Case Mix Index, Estancia Media Ajustada por Riesgo, Costo por Alta, PROMs/PREMs, tasa de resolutividad de telemedicina, No-Show Rate, índice de burnout/rotación (nivel país); y para AXON World/OMS: resistencia antimicrobiana (clasificación AWaRe), Índice UHC, gasto de bolsillo, mortalidad atribuible a factores ambientales, DALYs de salud mental, tasa de mortalidad por suicidio (indicador ODS).

**Frecuencia:** por lote (batch), no tiempo real — minimiza riesgo y permite aplicar disociación/agregación antes de transmitir. Tiempo real solo se justifica para gestión clínica interna del país (alertas sanitarias críticas vía FHIR Subscriptions/webhooks), no para el reporte hacia OMS/OPS.

**Visibilidad OMS/OPS vs. administrador de País:** Country administra solo su propio país — no ve otros países salvo que sea representante OMS/OPS o delegado nacional autorizado para ese fin. Administrador de País ve la vista micro-atómica (línea a línea, seudonimizada o identificada según el caso) para trazabilidad y gestión de red local. OMS/OPS ven solo vista macro-agregada (recuentos y tendencias por semana epidemiológica, según el Reglamento Sanitario Internacional) — nunca datos transaccionales individuales. *Pendiente: el documento de roles de AXON World/Country que vas a adjuntar.*

**Consentimiento:** sin opt-out para Enfermedades de Notificación Obligatoria (ENO) — el Código Sanitario y las excepciones de interés público de la Ley 21.719 facultan la recolección obligatoria. Si en el futuro un tercero (app privada externa al ecosistema estatal) consume estos datos, ahí sí se necesita consentimiento explícito y cláusulas modelo validadas por la APDP para transferencia internacional.

**Sellado de tiempo:** candidato Chilecertifica, a confirmar cuando lleguemos a esa fase — sin bloquear nada por ahora.



- **`defaultModules` por tipo de tenant — mecanismo propuesto (2026-08-19), falta que corrijas la lista de cada perfil:** en vez de escribir el set de módulos 20 veces (uno por cada `TENANT_TYPES`), propongo 5 **perfiles reutilizables** con nombre, y que cada tipo de tenant apunte a uno — así se corrige una vez y actualiza a todos los tenants de ese perfil. Borrador inicial a partir de tus 5 ejemplos, corrígeme lo que no calce:
  - `PERFIL_HOSPITAL_COMPLETO` = todo (`ALL_MODULE_IDS`, el default actual) — para Hospital.
  - `PERFIL_CLINICA` = igual que Hospital menos lo más gubernamental/gremial (`comite_etica`, `comite_medico`, `junta_medica`, `docencia`, `investigacion`, `servicio_rescate`) — es mi supuesto más débil de los 5, dijiste "su cierta cantidad" sin detallar, necesito que me la confirmes o reemplaces.
  - `PERFIL_CENTRO_AGENDA` = `dashboard`, `directorio`, `portal_trabajador`, `administrativas`, `atencion_medica` — para Centro Médico ("solo agenda y consulta médica").
  - `PERFIL_FARMACIA` = `dashboard`, `directorio`, `portal_trabajador`, `farmacia_bodega`, `contabilidad` — para Farmacia Pública/Privada.
  - `PERFIL_EDUCACION_SALUD` = `dashboard`, `atencion_clinica`, `his_sistema` (+ `portal_trabajador`, supuesto mío para que la enfermería escolar tenga personal) — para colegios/universidades.
  - Falta decidir a cuál de los 5 perfiles apunta cada uno de los 20 `TENANT_TYPES` actuales — no lo asigno solo, es demasiada decisión de negocio para adivinar.
- **`defaultModules` por tipo de tenant — actualizado con el PDF de modularidad (2026-08-20):** el PDF trae una lista de **25 tipos de tenant estándar para AXON Core** (antes solo teníamos 20 en `tenantTypes.config.js`). Confirma los 2 que ya sabíamos que faltaban (Centro de Alimentación, Centro de Rescate) y agrega **6 tipos nuevos que no había detectado antes**: Residencia de Adulto Mayor, Policlínico Industrial, Mutual de Seguridad, Centro de Educación, Fuerzas Públicas y Uniformadas, Complejos Penitenciarios. (Sigue sin aparecer "Hospital Mixto" en esta lista puntual — no significa que se descarte, puede que se maneje como un flag sobre Hospital Público/Privado en vez de un tipo propio; no lo asumo, pregúntamelo cuando quieras resolverlo.)
  - Perfiles borrador (sin cambios respecto a lo anterior, siguen esperando tu corrección): `PERFIL_HOSPITAL_COMPLETO`, `PERFIL_CLINICA`, `PERFIL_CENTRO_AGENDA`, `PERFIL_FARMACIA`, `PERFIL_EDUCACION_SALUD` — con 25 tipos reales en vez de 20, probablemente hagan falta 1-2 perfiles más (ej. uno para Mutual de Seguridad/Policlínico Industrial — salud ocupacional es un caso de uso distinto a clínica general; uno para Fuerzas Públicas/Complejos Penitenciarios, que seguramente necesitan reglas de acceso/privacidad especiales). No los invento — necesito tu input para no adivinar mal algo con implicancias legales (ej. salud penitenciaria tiene normativa propia).
  - `AXON Core Lite` — el PDF también amplía la lista de profesionales independientes más allá de lo que hoy cubre `userTypes.config.js`: menciona explícitamente enfermeras y matronas independientes, que hoy **no tienen ningún `USER_TYPE`** (solo existen `MEDICO_INDEPENDIENTE`, `ESPECIALISTA_INDEPENDIENTE` con kinesiólogo/nutricionista/psicóloga, y `TECNOLOGO_INDEPENDIENTE`). Fonoaudiólogo sigue confirmado como faltante (ya lo habíamos visto). "Médico de urgencia" y "paramédico" independientes son conceptualmente raros (urgencia normalmente implica infraestructura física, no consulta individual) — pregunta para confirmar antes de crear tipos nuevos por esos dos.
- Falta un `BILLING_TIER` institucional gratuito si de verdad quieres el Freemium rural — a la espera del documento que vas a detallar con los 8 tipos de monetización.
- **Checklist para cuando envíes el documento de Country/World** (para diseñar bien el alcance de `GLOBAL_OVERSIGHT_ROLES` y la anonimización):
  1. ¿Anonimización o seudonimización en el sentido estricto de la Ley 21.719? (umbrales legales distintos)
  2. Granularidad por nivel — ¿Regional=comuna, País=región, Continental=país, Mundial=continente, o es otra lógica?
  3. Qué categorías de dato entran (diagnósticos CIE, ocupación de camas, tiempos de espera, bandas etarias, resultados) y cuáles quedan fuera.
  4. Frecuencia de actualización — ¿tiempo real o consolidado por lote?
  5. ¿OMS/OPS ven lo mismo que un administrador de País, o una vista distinta/más agregada?
  6. ¿Dato obligatorio por vigilancia epidemiológica (sin opt-out) o hay mecanismo de consentimiento?
- Proveedor de sellado de tiempo acreditado (Decreto 181) para FEA — sin elegir todavía, no bloquea hasta Fase 5.
