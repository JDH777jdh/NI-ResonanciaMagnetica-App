# AXON RIS/PACS — Sincronización con Main y Módulos Satélite
## Discrepancias, bloqueos, y qué comunicar — 31-jul-2026

---

## A. Bloqueado — esperando que Main entregue

| Falta | Para qué |
|---|---|
| `security_config.js` completo | `puedeInformar` en `HIS-RIS-PACS.jsx` hoy compara directo contra `ROLES_INFORMANTES` — debería llamar `canAccessClinicalRecord()` real |
| `roles.config.js` | En preparación activa. Los IDs de rol usados hoy en RIS/PACS (ver §B) se copiaron de una versión anterior — hay que re-confirmarlos contra la versión final |
| `userTypes_config.js` actualizado | TENS no existe como tipo de usuario formal; "radiologo" cuelga de `TECNOLOGO_MED_STAFF` en vez de `MEDICO_STAFF` (pregunta abierta, nunca resuelta) |
| `AXON_Infraestructura_TLS_AES256.zip` | No abierto todavía — TLS en el motor DICOM sigue opcional, no obligatorio |
| `AXON_Actualizacion_Roles_Modulos_Satelite.md` | Citado en un comentario de `HIS-RIS-PACS.jsx` como fuente de `ROLES_INFORMANTES` — nunca llegó a subirse |

## B. Discrepancias encontradas — nombres o formas que no coinciden entre documentos

| Qué | Dónde A | Dónde B | Estado |
|---|---|---|---|
| Código de institución | "CUI" (dossier comercial original) | "CUIT" (dossier ampliado) | Sin unificar — mismo concepto, dos siglas |
| Dígito verificador del CUP | Hash local de reemplazo en `HIS-RIS-PACS.jsx` (`checkDigitLocal`) | Algoritmo real, se dijo que vive en `cup.js` | `cup.js` nunca se integró — el formato del CUP ya calza exacto con lo que main espera, el algoritmo del check digit no |
| IDs de rol en RIS/PACS (`t_med_radiologo`, `t_tec_imagen_coord`, `t_tec_imagen`, `t_tec_imagen_tens`) | Copiados de una versión de `roles.config.js` en una sesión anterior | Versión actual en preparación | Re-confirmar contra el `roles.config.js` final antes de dar por cerrado el gating de permisos |

## C. Lo que RIS/PACS ya tiene — para comunicar a Main y a los módulos satélite

- **Especificación técnica completa del motor** (protocolos, SOP Class, endpoints, formatos de identificador) — ver `AXON_MOTOR_DICOM_Especificacion_Tecnica.md`, entregado aparte.
- **Modelo CUP/ACC/OT** ya alineado en formato con lo que describe el dossier comercial (`CUP-{ISO2}-{REG}-{AÑO}-{SEQ8}-{CHK2}`) — confirmado campo por campo.
- **La fase `agendados`** como superficie de integración para cualquier módulo externo que cree pacientes (Agenda Web, ingreso manual) — mismo molde de registro sin importar el origen.
- **EventBus** (`publish`/`EVENTS`) con la misma firma que se espera del real — hoy solo deja rastro en consola, cambio de una línea cuando el real esté disponible.
- **Nombres de eventos de auditoría** alineados a los que se conocen de `security.config.js` (`audit.criticalEvents`) — alineados por nombre, no verificados contra el archivo real todavía (bloqueado, ver §A).
- **Wrapping DICOM de documentos no-imagen** (31-jul-2026, nuevo) — PDF de consentimiento como objeto DICOM real, mismo Study Instance UID que las imágenes del mismo evento. Listo para que el equipo de consentimiento informado (FESpa/FESpro) lo use como paso final de su pipeline.
- **Motor DICOM con Explicit VR real** — equipo real (no solo sintético) ya probado conectándose y siendo aceptado.

## D. Regla para todos los módulos satélite, sin excepción

Todo lo que pertenezca al mismo evento clínico de un paciente (imagen, documento, futuro laboratorio) debe compartir el mismo **Study Instance UID** — es el campo que amarra todo en el motor. No inventar un UID nuevo por tipo de contenido.

## E. Aclaración arquitectónica — la Agenda NO nace del Motor DICOM (16-ago-2026)

Surgió la pregunta de si las agendas de consultas ambulatorias/médicos deberían "nacer" del Motor DICOM, dado que la Agenda de Imagenología se conecta a él. La relación es la inversa: la Agenda (calendario, disponibilidad, reserva de cupo) es una capacidad genérica de nivel HIS/AXON-Core, independiente del motor. El Motor DICOM es un **servicio especializado** al que solo se conectan las citas que de verdad producen contenido DICOM (una orden de imagenología) — vía MWL una vez que la cita ya existe. Una consulta ambulatoria sin componente de imagen no debe tocar el motor DICOM en absoluto. Esto hay que dejarlo explícito en el documento maestro de Agenda antes de que se diseñe asumiendo la dirección equivocada.

## F. Confirmación cruzada contra un documento externo de síntesis

Se recibió un documento (de otra herramienta/sesión) que dice haber sincronizado Satélites↔MAIN↔Motor DICOM. Se verificaron sus afirmaciones técnicas contra el estado real del motor — coinciden: formato de CUP, ACC/OT en null durante "agendados", el flujo de consentimiento como Encapsulated PDF vía Explicit VR (recién construido y probado esta sesión), MPPS no soportado con C-STORE como proxy, y la restricción de Video/Multiframe por Transfer Syntax comprimida (coincide con la corrección hecha en este mismo documento). No se pudieron verificar sus afirmaciones sobre archivos de MAIN que no se han recibido (`security.config.js` "obsoleto", `modules.config.js`, monto de multa de la Ley 21.719) — no se contradicen, tampoco se dan por confirmadas sin verlas directamente.
