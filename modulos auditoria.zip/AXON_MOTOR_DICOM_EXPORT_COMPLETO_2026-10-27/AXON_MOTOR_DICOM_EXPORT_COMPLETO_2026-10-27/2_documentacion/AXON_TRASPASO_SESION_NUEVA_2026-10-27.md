# AXON Motor DICOM — Traspaso a sesión nueva
## Generado el 27-oct-2026 — leer esto PRIMERO en el chat nuevo

**Qué es:** el estado real del motor DICOM, qué falta decidir y cómo retomar. El detalle técnico está en el dossier (`AXON_MOTOR_DICOM_Mapa_y_Estado_Verificado_2026-08-25.md`, §1–18); esto no lo repite. Reemplaza a `AXON_TRASPASO_SESION_NUEVA_2026-08-31.md`.

---

## 1 · Estado (verificado)

- **Motor:** 10 archivos de test, **92/92 checks** (`npm test`, exit 0). **Frontend** (Vitest): **5/5**. Medido sobre un árbol reconstruido desde cero con `scripts_validacion/rebuild_tree.sh` (Proyecto + este export), y repetido sobre el zip exportado ya desempacado.
- **Último tramo cerrado:** RLE Lossless de punta a punta (dossier §18): codec propio, negociación, C-STORE, almacén, QIDO-RS y `/rendered`. Validado contra archivos RLE de otra implementación (pydicom) y con prueba de mutación (el test falla si se quita el fix).
- **Puertas etiquetadas (el motor NO hace todavía):** JPEG / JPEG-LS / JPEG 2000 / video, color en `/rendered`, multiframe en `/rendered` (solo el primer frame), MPPS, Storage Commitment, Transfer Queue durable, IOCM.

## 2 · Reglas de trabajo (las fijó el usuario)

- **Este equipo trabaja SOLO en el motor DICOM.** Los identificadores (CUP, CUT, CUC, CUV…) los administra MAIN: se consumen; **no se copian al repositorio** ni se verifica su lógica interna. Solo se mira cómo calzan en el motor (dossier §18.6).
- Preguntas y respuestas largas van al **dossier**; al chat solo lo corto. Mantener el chat liviano.
- **Decisiones mayores: confirmarlas con el usuario antes de aplicarlas.**
- Guardar cada archivo en `outputs` apenas termina: **el sandbox se reinicia sin aviso** (volvió a pasar al exportar).
- Sobre archivos existentes: partir del archivo real y aplicar ediciones puntuales con verificación; no reconstruir de memoria.
- Los binarios (`.dcm`, `.pdf`) entran al Proyecto solo como `*_base64.txt` (el panel los corrompe o rechaza).

## 3 · Pendiente — para decidir juntos (detalle y evidencia en dossier §18.5)

1. **Código de rechazo de la negociación:** hoy todo rechazo sale como `3`; para "Transfer Syntax no soportada" PS3.8 pide `4`. Cambio chico.
2. **Relleno de UI en los codecs de dataset:** hoy 0x20 (espacio); PS3.5 pide 0x00. Medir primero, después corregir en los dos codecs.
3. **Robustez del MWL (sospecha, no probada):** sin `try/catch` alrededor del encode del Worklist, un registro con un valor fuera del máximo de su VR podría tumbar el proceso. Primero confirmar con una sonda; si se confirma, `try/catch` por registro + guarda global.
4. **Actualizar la Especificación Técnica** (dice que RLE no está soportada; tampoco menciona la API del Worklist ni `TransferSyntaxRegistry`) — la consultan los equipos satélite.
5. **Siguiente trabajo técnico del plan (dossier §14.7):** JPEG / JPEG-LS / JPEG 2000 según demanda real de equipos; multiframe en `/rendered`; MPPS; Storage Commitment; Transfer Queue durable; IOCM.
6. **UI de `HIS-RIS-PACS.jsx` (4 gaps abiertos, §9.1):** prioridad editable, anamnesis, medio de contraste, calculadora renal en vivo — solo si se quiere retomar.
7. **Al integrar con MAIN:** los CUP/CUT de `HIS-RIS-PACS.jsx` son marcadores y se reemplazan por los de MAIN; ACC y OT siguen ≤ 16 caracteres (VR SH).
8. **Proyecto:** subir los archivos de `para_subir_al_proyecto/` y quitar los obsoletos (lista en dossier §18.7).

## 4 · Qué contiene el export (un solo ZIP)

- `1_motor_dicom_para_correr/` — el motor completo y verificado: `src/`, `test/` (con fixtures reales), `frontend/`, `package.json`, `README.md` actualizado. Sin `node_modules`.
- `2_documentacion/` — todos los documentos del Proyecto, con el dossier actualizado (§1–18) y este traspaso.
- `3_scripts_validacion/` — `rebuild_tree.sh` (arma todo el árbol desde el Proyecto), `obtener_fixtures_externos.py` (archivos RLE de pydicom, con verificación sha256) y los scripts de validación cruzada con pydicom.
- `4_para_subir_al_proyecto/` — los archivos nuevos o reemplazados, con los nombres planos del Proyecto.
- `5_snapshot_proyecto_original/` — copia fiel del Proyecto tal como estaba (incluye dos binarios dañados conocidos: `CT_small.dcm` y `consentimiento_prueba.pdf`; los buenos están en `1_…/test/fixtures/`).
- `6_extras_fuera_de_alcance/` — verificaciones de los identificadores de MAIN que se empezaron; **no son parte del motor** y quedaron sin terminar.
- **No incluye** el archivo de identificadores de MAIN (`MasterIdentifierService`): lo administra MAIN y solo se consume.

## 5 · Cómo retomar

Mensaje sugerido para el chat nuevo, dentro de este Proyecto:

> *Continuamos el Motor DICOM de AXON. Leé `AXON_TRASPASO_SESION_NUEVA_2026-10-27.md` y las secciones 14 a 18 del dossier. Confirmame antes de empezar el siguiente ítem.*

El chat nuevo no recuerda esta conversación: todo lo que necesita está en los archivos del Proyecto.
