# AXON RIS/PACS — Adenda 4: Verificación visual real + 9 bugs corregidos + DICOM reales
## Sesión 23-jul-2026 — continuación directa de la Adenda 3

**Contexto:** se pidió (1) ver visualmente el resultado real, no solo confiar en tests, y (2) probar con DICOM reales anonimizados. En vez de esperar la anonimización propia, se usaron archivos de prueba **reales, públicos y ya seguros** (repositorio de test files de pydicom) mientras se prepara el resto.

**Esto es lo más importante de esta adenda:** montar la app en un navegador real (no solo tests/lectura de código) hizo caer el visor pantalla completa. La causa fueron **7 referencias rotas** que ningún chequeo anterior (grep, lectura, incluso los tests automatizados) podía detectar, porque los tests nunca ejercitaron esa ruta de la UI. Se encontraron y corrigieron todas, más un bug de negociación de protocolo real encontrado recién al probar con DICOM verdaderos.

---

## 1. Cómo se verificó (no solo se leyó)

- Se usó un Chromium real ya cacheado en el entorno (vía Playwright) — nada de mockups ni capturas simuladas.
- Se montó `HIS-RIS-PACS.jsx` empaquetado con esbuild (mismo runtime JSX automático que usaría Vite) y se navegó con clics/inputs reales.
- Se agregó captura de errores de página (`pageerror`) — así se encontraron los bugs reales, no solo layout.
- Después de cada fix, se corrió **ESLint con `no-undef` + `react/jsx-no-undef`** sobre el archivo completo, para encontrar el resto de una sola pasada en vez de seguir chocando con la app una por una.

## 2. Los 7 bugs del visor / panel de Informe (todos con la misma causa raíz)

Código de una sesión anterior que quedó **a medio conectar** entre `VisorPantallaCompleta` y el componente principal — declarado en el lado equivocado, o nunca creado:

| Roto | Sección | Causa | Fix |
|---|---|---|---|
| `horario`/`setHorario` | Horario Hábil/Inhábil | Declarado en el componente principal, usado en `VisorPantallaCompleta` | Pasó a ser estado **local** del visor (no necesita sobrevivir cerrar/abrir) |
| `nombrePlantilla`/`setNombrePlantilla` | Guardar plantilla | Mismo problema | Prop nueva, viene del principal (debe persistir en la sesión) |
| `guardarPlantilla` | Guardar plantilla | Mismo problema | Prop nueva |
| `misPlantillas` | Cargar plantilla | Mismo problema | Prop nueva |
| `setTitulo` | Título editable del informe | Nunca se creó — el campo existía en el registro, el setter no | Función nueva basada en `patch()`, igual que el resto de los setters de campo |
| `setClasificacionCritica` | Checkbox de patología crítica | Mismo problema | Función nueva basada en `patch()` |
| `setCie10` | Los 2 multibox CIE-10 (Indicación/Conclusión) | Mismo problema — **encontrado por ESLint, no por clic** | Función nueva basada en `patch()` |
| ícono `Mic` | Botones de dictado por voz (×3) | Nunca se importó de `lucide-react` | Agregado al import |
| `<I .../>` en `TabCard` | Ícono de cada tarjeta de pestaña | Nunca se extrajo `fase.icon` | `const I = fase.icon;` |

**Efecto antes del fix:** cualquier sesión con permiso de informar (`t_med_radiologo`, `t_tec_imagen_coord`) que abriera el visor sobre un examen en fase Exámenes veía la app caerse en blanco — sin límite de alcance, era el 100% de las veces, para el 100% de esos roles. El panel de Informe completo (una de las piezas más grandes del proyecto) estaba inutilizable desde que se escribió, y ni la lectura de código ni los tests automatizados anteriores lo habían detectado.

**Verificado después del fix:** ESLint limpio (0 errores) sobre las 1843 líneas, y confirmado en el navegador real — el visor abre, el panel de Informe renderiza completo (14× más contenido en el screenshot que en el estado roto), sin errores de consola.

## 3. Bug de protocolo real, encontrado recién al probar con DICOM verdaderos

**Este no se podía encontrar con datos sintéticos — solo con archivos reales.**

`AeRegistry.TRANSFER_SYNTAXES_ESTANDAR` incluía tanto Implicit VR LE como Explicit VR LE como "aceptadas" en la negociación de asociación. Pero `ImplicitVrCodec.js` — el parser propio del motor — **nunca soportó Explicit VR**, tal como dice su propio README. Con datasets sintéticos (siempre codificados como Implicit VR por el mismo proyecto) esto nunca se notaba.

Al probar con `CT_small.dcm` y `MR_small.dcm` reales (ver §4) — que vienen codificados en Explicit VR LE, como ofrece por defecto muchísimo equipo real — la asociación se **aceptaba** igual, aunque el motor no puede interpretar ese contenido con su propio parser.

**Impacto real:** no corrompía lo ya guardado (el C-STORE guarda los bytes tal cual llegan, y `dcmjs` sí lee Explicit VR bien para la indexación y WADO-RS), pero es una negociación deshonesta — y un riesgo latente real si en el futuro algo usa `ImplicitVrCodec.decodeDataset()` directo sobre datos de C-STORE, o si `dcmjs` no está instalado.

**Fix:** la negociación ahora solo acepta Implicit VR LE, consistente con lo que el codec real soporta.

**Implicación para producción, sin resolver todavía:** un equipo que solo ofrezca Explicit VR (sin caer a Implicit VR) va a quedar rechazado por la asociación. Hay que confirmar que el equipo real de destino sepa negociar Implicit VR LE — es obligatorio por el estándar DICOM, así que la inmensa mayoría de los equipos lo soporta como *fallback*, pero vale la pena confirmarlo antes de ir a producción, o directamente sumar soporte real de Explicit VR al codec (trabajo pendiente, no trivial pero tampoco enorme).

## 4. Prueba con DICOM reales (pydicom test files — públicos, ya seguros)

Se usaron 4 archivos del repositorio `robyoung/dicom-test-files` (recopila los archivos de prueba oficiales de pydicom, usados en toda la comunidad DICOM para testing entre librerías — nada de datos de pacientes):

| Archivo | Qué es | Resultado contra el motor |
|---|---|---|
| `CT_small.dcm` | CT real 128×128, 16 bits, Explicit VR LE | DIMSE: rechazado correctamente (Explicit VR, ver §3). WADO-RS `/rendered` directo: **200 OK, PNG real de una imagen de CT reconocible** |
| `MR_small.dcm` | MR real 64×64, 16 bits, Explicit VR LE | Igual que el anterior — PNG real de un corte de MR reconocible |
| `SC_rgb.dcm` | Secondary Capture a color, 100×100, RGB | `/rendered`: `422` con el motivo ("RGB no soportado todavía") — la puerta etiquetada funciona con datos reales, no solo con el caso sintético que yo armé |
| `rtplan.dcm` | RT Plan (sin Pixel Data) | `/rendered`: `422` ("no trae Rows/Columns") — correcto, es un objeto sin imagen |

Las imágenes reales renderizadas (`real_CT_small.png`, `real_MR_small.png`) quedan adjuntas — son cortes médicos reales reconocibles, no un patrón sintético.

## 5. Visualizador interactivo

`HIS-RIS-PACS.jsx` queda adjunto como artifact — se puede interactuar en vivo (Worklist, Admisión con la columna Bono, Agendados con el botón de tótem, Ingreso manual, y el visor + panel de Informe ya sin el crash). Usa datos de demostración (`SEED`), no los DICOM reales de §4 — esos se probaron contra el motor de verdad (Node), que es una superficie distinta del componente de UI.

## 6. Artifact no cargaba — causa real encontrada

El visualizador interactivo fallaba al cargar con "usa bibliotecas que no admite". La causa **no era ningún import real** (los 40 íconos de `lucide-react` se verificaron uno por uno contra la versión exacta 0.383.0, todos existen) — era un **comentario de documentación** (línea ~239) que contenía, como texto ilustrativo, la línea literal `import { TENANT_ROLES, findRole } from "../config/roles.config.js";`, explicando cómo se vería el código una vez integrado al proyecto real. El cargador de artifacts aparentemente hace un escaneo de texto para detectar imports **antes** de parsear el archivo de verdad, sin distinguir comentario de código real — vio esa ruta relativa local (no una librería de npm) y rechazó todo el archivo. Reescrito para explicar lo mismo sin usar la sintaxis literal `import ... from "..."` dentro del comentario. Verificado: no queda ningún otro patrón `from "..."` en el archivo salvo los 2 imports reales (react, lucide-react).

## 7. Próximos pasos

- Confirmar si el equipo real de destino negocia Implicit VR LE (§3) antes de ir a producción.
- Seguir bloqueados por los mismos archivos de siempre: `security_config.js`, `roles.config.js`, `userTypes_config.js`, TLS zip, `AXON_Actualizacion_Roles_Modulos_Satelite.md`.
- Cuando tengas tus propios DICOM anonimizados, puedo verificar la metadata contra el perfil PS3.15 y revisar visualmente una muestra buscando texto quemado en píxeles, antes de usarlos.
