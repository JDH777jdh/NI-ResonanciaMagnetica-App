# AXON dicom-engine — Especificación técnica para equipos satélite
## Versión al 31-jul-2026 · para instruir a otros equipos de desarrollo, no es bitácora de sesión

**Qué es:** motor DICOM propio de AXON (protocolo DIMSE + DICOMweb), Node.js, proceso persistente en servidor propio (no serverless — DIMSE necesita un listener TCP siempre encendido). No depende de ningún PACS de terceros (Orthanc/dcm4chee/etc.) — está escrito desde cero, byte a byte, sobre las especificaciones oficiales DICOM PS3.7/PS3.8/PS3.18.

---

## 1. DIMSE — protocolo de red DICOM (puerto TCP)

El motor actúa siempre como **SCP** (Service Class Provider) — recibe conexiones, nunca las inicia. No hay rol SCU implementado (no puede empujar a un PACS externo ni consultar un MWL remoto).

| Servicio | Soportado | Notas |
|---|---|---|
| **C-ECHO** | Sí | Verificación/ping DICOM estándar |
| **C-FIND** (Modality Worklist) | Sí | SOP Class `1.2.840.10008.5.1.4.31`. Responde con los pendientes reales del Worklist — Pending×N + Success final |
| **C-STORE** | Sí | Ver tabla de SOP Class de Storage abajo |
| C-MOVE / C-GET | No | Sin query/retrieve clásico — solo Worklist + Storage |
| MPPS (N-CREATE/N-SET) | **No** | Puerta etiquetada activa — ver §7 |
| Print, Storage Commitment | No | Fuera de alcance |

**Transfer Syntax soportadas (ambas genuinas, no solo negociadas):**
| UID | Nombre | Estado |
|---|---|---|
| `1.2.840.10008.1.2` | Implicit VR Little Endian | Soportada (`ImplicitVrCodec.js`) |
| `1.2.840.10008.1.2.1` | Explicit VR Little Endian | Soportada (`ExplicitVrCodec.js`, 31-jul-2026) |
| Cualquier comprimida (JPEG, JPEG2000, RLE) | — | **No soportada** — la asociación la rechaza en la negociación, no se acepta a medias |

**SOP Class de Storage aceptadas (C-STORE):**
| UID | Modalidad |
|---|---|
| `1.2.840.10008.5.1.4.1.1.1` | CR |
| `1.2.840.10008.5.1.4.1.1.1.1` | DX |
| `1.2.840.10008.5.1.4.1.1.1.2` | MG |
| `1.2.840.10008.5.1.4.1.1.2` | CT |
| `1.2.840.10008.5.1.4.1.1.4` | MR |
| `1.2.840.10008.5.1.4.1.1.6.1` | US |
| `1.2.840.10008.5.1.4.1.1.12.1` | XA |
| `1.2.840.10008.5.1.4.1.1.20` | NM |
| `1.2.840.10008.5.1.4.1.1.128` | PT |
| `1.2.840.10008.5.1.4.1.1.7` | OT (Secondary Capture — genérico, útil para pantallazos/capturas derivadas) |

Cualquier SOP Class de Storage fuera de esta lista es rechazada en la negociación. Agregar una nueva (ej. para sumar otra modalidad) es una línea en `STORAGE_SOP_CLASSES` (`AssociationServer.js`) — no requiere cambios estructurales.

**TLS:** el servidor acepta `tlsOptions` y los usa si se le pasan — hoy queda **opcional** (para poder probar en texto plano); para producción es obligatorio (perfil PS3.15 del estándar).

---

## 2. DICOMweb — API HTTP (QIDO-RS / WADO-RS)

| Método | Ruta | Qué hace |
|---|---|---|
| GET | `/studies` | QIDO-RS — busca estudios (filtros por query string) |
| GET | `/studies/{studyUID}/metadata` | Metadata del estudio |
| GET | `/studies/{studyUID}/series` | Series de un estudio |
| GET | `/studies/{studyUID}/series/{seriesUID}/instances` | Instancias de una serie |
| GET | `/studies/{studyUID}/series/{seriesUID}/instances/{sopUID}` | WADO-RS — instancia cruda, `application/dicom` (single-part, no multipart) |
| GET | `/studies/{studyUID}/series/{seriesUID}/instances/{sopUID}/rendered` | WADO-RS `/rendered` — PNG de 8 bits listo para `<img>` |

**`/rendered` — alcance exacto:**
- Solo escala de grises (MONOCHROME1/MONOCHROME2) — cubre CT/MR/CR/DX/NM/PT, que es lo único que el motor recibe hoy de verdad.
- Solo el primer frame — sin soporte multiframe/cine todavía.
- Windowing: usa WindowCenter/WindowWidth del dataset si existen, si no hace auto-ventana con el mínimo/máximo real de la imagen.
- **Si la instancia no se puede renderizar (color, sin Pixel Data, etc.), responde `422` con el motivo explícito en el body — nunca `500` silencioso ni una imagen inventada.** Cualquier equipo satélite que consuma este endpoint debe manejar el caso 422 explícitamente, no asumir que siempre llega una imagen.
- No soportado: STOW-RS (subir por HTTP) — el único camino de ingesta es C-STORE por DIMSE.

---

## 3. Identificadores

| Identificador | Formato | Generado por |
|---|---|---|
| CUP | `CUP-{ISO2}-{REG}-{AÑO}-{SEQ8}-{CHK2}` — ej. `CUP-CL-13-2026-00002001-A4` | `makeCUP()` en `HIS-RIS-PACS.jsx` (el dígito verificador hoy es un hash local de reemplazo — el algoritmo real vive en `cup.js`, pendiente de integrar) |
| Study/Series/SOP Instance UID | UID DICOM estándar (formato `X.X.X...`) | Se generan sintéticamente en el mock; en producción los genera quien construye el dataset real (equipo o AXON, según el flujo) |
| ACC / OT | Formato interno simple (`ACC{8 dígitos}`, `OT{6 dígitos}`) | `makeACC()`/`makeOT()` — sin dígito verificador todavía, a diferencia del CUP |

**Regla que cualquier módulo satélite debe respetar:** el Study Instance UID es el campo que amarra imagen + orden + lo que sea que se agregue después (ej. el PDF de consentimiento, cuando esté el wrapping) — todo lo que pertenezca al mismo evento clínico debe compartir el mismo Study Instance UID, no inventar uno nuevo por tipo de contenido.

---

## 4. Registro de equipos (`AeRegistry`)

Cualquier sistema que vaya a hablar DIMSE con el motor (un equipo real, o un simulador) tiene que existir en el registro. Campos:

```js
{
  id: "identificador_interno",
  nombre: "Nombre legible",
  aeTitle: "AE_TITLE_DICOM",   // como se identifica en la negociación DIMSE
  ip: "x.x.x.x",
  port: 104,                    // puerto DICOM estándar, o el que corresponda
  modalidad: "CT",              // código de modalidad
  scp: true,                    // puede recibir C-STORE
  scu: true,                    // puede iniciar asociaciones (informativo, el motor no actúa como SCU)
  mwl: true,                    // puede consultar el Worklist
  activo: true,
}
```

Se agrega editando `equipos.json` (o vía `ui/EquipmentConfigPanel.jsx`, construido pero no probado en navegador real todavía) — no requiere tocar el motor.

---

## 5. Puertas etiquetadas activas — explícitamente NO soportado hoy

| Falta | Motivo | Bloquea a |
|---|---|---|
| Multiframe (cine US/XA) | `/rendered` solo pinta el primer frame | Cardiología, Endoscopía |
| Color (RGB/YBR) | `/rendered` responde 422 para no-MONOCHROME | Doppler, Endoscopía, Dermatología |
| Compresión (JPEG/JPEG2000) | Ningún codec la decodifica | Cualquier equipo que no ofrezca fallback sin comprimir |
| MPPS (N-CREATE/N-SET) | No implementado — servicio DIMSE distinto (normalizado, no compuesto) | Notificación real de "examen iniciado/terminado". Hoy se aproxima con la llegada de C-STORE como señal de "terminado" |
| Wrapping DICOM de no-imagen (PDF, video, STL) | En construcción ahora mismo | Consentimiento informado, informes externos, cualquier documento que deba vivir junto a las imágenes |
| SCU (iniciar asociaciones) | No implementado | Empujar a un PACS externo, consultar un MWL remoto |

---

## 6. Para el equipo de Agenda Web específicamente

- Punto de integración: una cita creada externamente debe generar un registro en AXON con `fase: "agendados"` — mismo molde de registro que ya usa "Ingreso manual" para `fase: "admision"` (mismo cálculo de CUP/ACC/OT/timestamps).
- Protocolo recomendado: FHIR REST (`ServiceRequest`/`Appointment`), no HL7v2 — no hay sistema legado de por medio.
- Notificación de "examen terminado" hacia la agenda: hoy se puede enganchar a la llegada de C-STORE (ver §5, MPPS) — no es la señal ideal (no distingue inicio de fin del examen) pero es lo que existe y funciona.

## 7. Para cualquier módulo que necesite adjuntar contenido NO-imagen (PDF, video, foto)

**Listo y probado (31-jul-2026), ya no es un plan.** El PDF se envuelve como objeto DICOM válido (Encapsulated PDF, SOP Class `1.2.840.10008.5.1.4.1.1.104.1`, verificado contra el estándar oficial) y se guarda por el mismo camino que una imagen (C-STORE), ligado al mismo Study Instance UID del evento clínico correspondiente — probado con un PDF real conviviendo con una imagen bajo el mismo estudio, visible como 2 series separadas en QIDO-RS. Campos clave del objeto: `Modality="DOC"`, `MIMETypeOfEncapsulatedDocument="application/pdf"`, `VerificationFlag` (`"UNVERIFIED"` mientras solo firmó el paciente / `"VERIFIED"` cuando el profesional también firma — mapeo directo para el flujo FESpa/FESpro). Se codifica en **Explicit VR LE**, no Implicit — para tags poco comunes, dcmjs necesita el VR en el stream para no adivinar mal.

**Corrección (16-ago-2026):** la versión anterior de este documento decía que Video Photographic Image "queda con el mismo mecanismo disponible, solo falta la función equivalente". Eso estaba mal — verificado ahora contra el estándar. Video Photographic Image es una IOD de imagen multi-frame real, con **23 módulos** (Patient/Study/Series/Equipment/Image), codificada con códecs de video reales (MPEG-2/MPEG-4 según la Transfer Syntax) — categóricamente distinta a Encapsulated PDF, que es un blob opaco envuelto en un solo elemento. No es "cambiar el SOP Class y listo": requiere soporte de Transfer Syntax comprimida (§5) antes de poder construirse en serio. Queda fuera de alcance hasta que exista esa base — no es el siguiente paso natural después del PDF, aunque lo parecía a primera vista.

Cualquier equipo satélite que hoy adjunte archivos como metadata suelta (ej. el campo `adjuntos` de `HIS-RIS-PACS.jsx`) puede migrar a este mecanismo sin cambiar de dónde saca los bytes — solo cambia cómo se guardan.
