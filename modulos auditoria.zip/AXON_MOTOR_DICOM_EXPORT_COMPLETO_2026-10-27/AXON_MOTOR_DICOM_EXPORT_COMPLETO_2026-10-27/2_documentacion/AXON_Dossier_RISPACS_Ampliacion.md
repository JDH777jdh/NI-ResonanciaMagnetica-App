# AXON RIS/PACS — Dossier Técnico de Ampliación
## Módulo Imagenología · Sesión de especificación 06-jul-2026

**Propósito:** registrar, en un solo lugar, las 13 definiciones de esta sesión antes de tocar código — sirve como esquema de implementación para la próxima sesión y como material técnico para la carpeta de venta de AXON.

---

## 1. Asignación de roles: quién queda registrado y cómo

| Rol | Mecanismo | Detalle |
|---|---|---|
| **TM (Tecnólogo Médico)** | **Auto-registro** si el TM logueado ejecuta la acción "Tomar paciente" — o **asignación manual** si es TENS/administrativa quien asigna el examen a un TM en turno | La acción debe leer `sesión.rol`: si es `tecnologo_med`, el CUT de la sesión se auto-completa como TM; si es `tens` o `administrativo`, se abre el selector para elegir a qué TM en turno se asigna |
| **Radiólogo** | Selector, lo asigna TM o TENS | Confirmado sin cambios |
| **TENS** | Selector | Confirmado sin cambios |

**Implicación técnica:** la función `tomarPaciente()` deja de ser una sola acción — se bifurca según el rol de quien la ejecuta. Esto es además el primer punto real donde `SESION_ACTUAL` (hoy mock) deja de ser solo decorativo y pasa a decidir comportamiento.

---

## 2. Tres campos distintos — no intercambiables

| Campo | Qué es | Obligatoriedad |
|---|---|---|
| **Procedencia** | De dónde viene el paciente: Ambulatorio / Hospitalizado / Urgencia | Siempre presente |
| **Categoría clínica** | Aislamiento, nivel de cuidados, o cuadro específico (Paro CR, COVID-19, **Paciente estable** — categoría nueva a agregar) | **Opcional si Ambulatorio. Obligatoria si Hospitalizado o Urgencia** — sin este campo, un hospitalizado/urgencia no debería poder derivarse a Imagenología |
| **Prioridad** | Urgencia de **informar** el estudio — independiente de procedencia | Editable en cualquier momento por el paciente, incluso ambulatorio (ej. médico tratante pide prioridad sin que sea urgencia) |

**Categoría nueva a agregar al registro configurable:** "Paciente estable" (grupo *Nivel de cuidados* o uno nuevo *General*) — para hospitalizados/urgencias que no requieren preparación especial de sala ni personal.

**Cambio de UI pendiente:** agregar selector de Prioridad editable dentro del panel de detalle (hoy el campo existe en el modelo de datos pero no es editable desde la interfaz — es el gap a cerrar).

---

## 3. Consentimiento informado — vista completa, no un solo click

Al validar, el panel debe **mostrar**, no solo marcar:
- Firma FES (Firma Electrónica Simple) del paciente
- Respuestas de la encuesta clínica pre-examen
- Antecedentes de alergia y otros antecedentes relevantes

**Qué exámenes lo requieren (lista abierta, depende de la orden médica, no es fija por modalidad):**
- Más común: TC/RM con medio de contraste
- También: biopsias, angiografía cardíaca o cerebral
- Poco común / en desuso pero existe: RX o mamografía en casos puntuales

**Dos mecanismos para determinarlo (ambos necesarios, no uno u otro):**
1. **Código de examen predetermina:** el código del examen vendido/ingresado trae consigo si requiere contraste/consentimiento — es la vía más común y la que se resuelve primero.
2. **Modificación dinámica en el proceso:** si la decisión de usar contraste se toma *durante* el examen (no se podía esperar el triage regular), el registro del Worklist se modifica ahí mismo y se genera un **nuevo consentimiento informado** para que el paciente lo firme al salir del examen — firmado también por el TM.

**Pendiente de diseño (no resuelto aún, para próxima sesión):** un registro/catálogo de códigos de examen con flag `requiereContraste` / `requiereConsentimiento`, que es lo que en realidad dispara el mecanismo 1.

---

## 4. Anamnesis clínica — campo nuevo

Campo de texto libre, lo redacta el TM durante la anamnesis en sala (ejemplo real de formato esperado: motivo de consulta, antecedentes relevantes no registrados en ficha, hallazgos de laboratorio externos adjuntos, antecedentes familiares). Va en el mismo bloque que consentimiento/datos clínicos del TM.

---

## 5. Medio de contraste + calculadora de función renal

**Antes de los 4 campos existentes (creatinina, talla, peso, contraste ml):** agregar selector de **medio de contraste administrado**, tomado de una lista — a futuro esa lista se alimenta del stock real de la sub-bodega de Imagenología dependiente de Farmacia Central (mismo patrón `workTeams.config.js` que ya usa `farmacia_bodega`).

**Calculadora en tiempo real — fórmulas verificadas hoy contra fuentes clínicas actuales:**

| Fórmula | Ecuación | Uso |
|---|---|---|
| **Cockcroft-Gault** (adultos) | CrCl (mL/min) = [(140 − edad) × peso(kg)] / [72 × creatinina(mg/dL)] × 0.85 si es mujer | Estándar para dosificación en adultos desde 1976, sigue siendo la referencia para ajuste de contraste |
| **Schwartz clásica** (pediatría, 1976/1987) | eGFR = (K × talla(cm)) / creatinina(mg/dL) — K: 0.33 (prematuro <1a), 0.45 (lactante de término <1a), 0.55 (niños 1–13a y adolescentes mujeres >13a), 0.70 (adolescentes hombres >13a) | Constantes históricas, todavía citadas como referencia clásica |
| **Schwartz bedside/modificada** (CKiD 2009) | eGFR = 0.413 × talla(cm) / creatinina(mg/dL) | La que recomiendan las guías actuales para 1–16 años, un solo K |

**Contexto clínico para la alerta (ACR 2025 / ESUR):** eGFR/CrCl < 30 mL/min/1.73m² es el umbral de precaución más citado (ACR); ESUR distingue < 45 para vía intra-arterial de primer paso y < 30 para intravenosa. La calculadora debería mostrar un aviso visual (no un bloqueo) si el resultado cae bajo esos umbrales — la decisión clínica la toma el radiólogo/médico, la herramienta solo la hace visible a tiempo.

---

## 6. Flujo automático a PACS — corrección de arquitectura

**Investigado hoy (DICOM PS3.4, Modality Worklist):** no existe, en la realidad, un botón humano "enviar a PACS". El flujo real es:

1. RIS genera la Orden (Scheduled Procedure Step) con Número de Acceso + Study Instance UID
2. El equipo de imagen **consulta** (C-FIND) al MWL SCP — el equipo pregunta, el RIS no empuja
3. Tecnólogo confirma el paciente correcto en la consola del propio equipo (no en esta app web)
4. El equipo informa avance/fin vía **MPPS** (Modality Performed Procedure Step)
5. El equipo envía las imágenes al PACS vía **C-STORE** — ahí recién nace el estado "Almacenado"

**Corrección a aplicar:** el botón "Enviar a PACS →" que existe hoy en el Worklist debe replantearse — no es una decisión de staff, es un evento que debería llegar solo (en producción, vía listener MPPS/C-STORE real). En el mock, se deja como **simulación explícita de ese evento entrante**, no como acción de negocio.

---

## 7. Timestamps múltiples — dos columnas de hora por pestaña, no una

| Pestaña | Columna 1 | Columna 2 |
|---|---|---|
| Agendados | Hora agendada | Hora presentación (activación de llegada en recepción) |
| Admisión | Hora presentación | Hora admisión (fin del ingreso) |
| Worklist | Hora agendada | Hora arribo (llegada desde admisión a worklist) |
| Exámenes | Hora atención | Hora almacenado |

Esto reemplaza el campo único `hora` del modelo actual — pasa a ser un objeto de timestamps por etapa (el mismo que ya se había anotado como necesario para las métricas de tiempos de espera/RTAT de sesiones anteriores).

---

## 8. Identificadores ACC y OT

- **OT (Orden de Trabajo):** el RIS la genera al programar el estudio.
- **ACC (Número de Acceso / Accession Number):** identificador único que el equipo de imagen y el PACS usan para procesar y guardar — es, de hecho, el campo estándar DICOM que referencian tanto RIS como PACS para no perder la trazabilidad entre sistemas.

**Visibilidad:** ambas columnas en todas las pestañas **excepto Agendados** (donde el estudio aún no tiene ni orden ni acceso formalmente emitidos).

---

## 9. Selector de fecha/calendario

Entre el buscador (Paciente/CUP/RUT) y los chips de modalidad: un rectángulo selector que al hacer click despliega un mini-calendario mensual para filtrar por fecha.

---

## 10. Ingreso manual de paciente (botón en Worklist)

Mini-ventana con: datos personales (autocompletado si ya existe RUT/CUP en base), examen a realizar, adjuntar orden médica, y lo necesario para pasar directo a Admisión y Worklist. Debe generar match entre el ingreso manual, el registro CUP (existente o nuevo), y conciliar después el flujo de pago en Admisión.

---

## 11. Flujo de pago/bono en Admisión

**a) Ingreso presencial:** administrativa ingresa número de bono al registrar → se activa un botón en la fila del paciente → una vez el examen está Almacenado, el paciente vuelve con la administrativa → ese botón abre la mini-ventana para finalizar pago.

**b) Autoatención (portal + tótem):** paciente ya trae bono asociado a su cupo agendado (match hecho por el portal, que no permite errores de ingreso) → activa llegada en el tótem → va directo a Admisión y Worklist, sin pasar por revisión de administrativa.
- **b.1** Si termina el examen: se retira sin volver a administrativa. Si no termina: se reagenda directo con administrativa.
- **b.2** Si no termina y no quiere reagendarse: administrativa lo busca en la pestaña Admisión y, al abrirlo, tiene las opciones **Validar bono** / **Anular bono**.
- **b.3** Si el paciente se retira sin pasar por administrativa: la fila en Admisión necesita una **alerta visual** (parpadeo sutil, color llamativo) en el botón de validar/anular cuando el estado pase a Almacenado o Reagendado sin bono resuelto — para que quien esté revisando esa pestaña lo note y actúe.

---

## 12. Arquitectura de roles — aclaración (confirmado hoy contra `userTypes.config.js`)

- `_STAFF` no es exclusivo de ningún rol — lo llevan todos los tipos institucionales (MEDICO_STAFF, ENFERMERO_STAFF, TECNOLOGO_MED_STAFF, ADMIN_STAFF, AUXILIAR_STAFF, COORDINADOR_STAFF). `_INDEPENDIENTE` es la contraparte para profesionales externos que usan la app por cuenta propia, sin ser planta de la institución.
- **TENS no existe todavía** como tipo de usuario/rol en el archivo real — falta crearlo (ej. `TENS_STAFF` con `rolesPermitidos:["tens"]`).
- El rol `"radiologo"` hoy cuelga de `TECNOLOGO_MED_STAFF` y de `TECNOLOGO_INDEPENDIENTE` — clínicamente un radiólogo es médico, no tecnólogo; queda como pregunta abierta para decidir si se mueve bajo `MEDICO_STAFF`.
- No se encontró una sección de administración de roles dedicada en el zip revisado — hoy los `.config.js` son la única fuente de verdad. Vale la pena definir esa sección (candidatos naturales: `his_sistema` o `rrhh`).

---

## 13. Próximos pasos sugeridos

1. Actualizar el modelo de datos del Worklist: timestamps múltiples (§7), campo Prioridad editable (§2), categoría "Paciente estable" (§2), campos de anamnesis y selector de medio de contraste + calculadora (§4, §5), columnas ACC/OT (§8), selector de fecha (§9).
2. Reemplazar el botón "Enviar a PACS" por la simulación de evento entrante (§6).
3. Construir el ingreso manual (§10) y el flujo de pago/bono en Admisión con su alerta visual (§11).
4. Crear TENS como rol formal y decidir la reubicación de "radiologo" (§12) — esto es edición de `userTypes.config.js`, fuera de este componente.
5. Retomar el Workstation (visor + informe) con estos mismos campos ya alineados, para no reconstruirlo dos veces.
