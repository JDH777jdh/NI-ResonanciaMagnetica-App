# AXON RIS/PACS — Adenda de verificación independiente
## Sesión 20-jul-2026 — se lee junto con AXON_DOSSIER_MAESTRO.md, no lo reemplaza

**Qué es esto:** el dossier maestro pedía que la próxima sesión llegara con el contexto completo sin releer todo. Esta adenda documenta que esa sesión (esta) no se limitó a *leer* el contexto — lo *ejecutó*, con un test end-to-end real escrito de cero, para confirmar (o corregir) cada etiqueta "Probado" del dossier maestro contra evidencia, no contra la palabra de la sesión anterior.

---

## 1. Aclaración sobre el paquete (resuelta, no era un problema real)

El mensaje de traspaso decía "21 archivos, ~205KB". La extracción real dio 14 archivos de contenido. Verificado contra el zip original:

- `unzip -l` cuenta **21 entradas** porque incluye 7 marcadores de carpeta (`dicom-engine/`, `dicom-engine/src/`, `dicom-engine/src/pdu/`, etc.) junto a los 14 archivos reales — es el conteo crudo de la herramienta, no un archivo perdido.
- Los "205 KB" son los **205.361 bytes descomprimidos** que el propio `unzip -l` reporta como total — no el peso del `.zip` (que pesa 66.134 bytes / ~64.6 KB comprimido).
- Los 14 archivos extraídos coinciden 1:1 con los 14 listados en la tabla del dossier maestro (§2). Nada faltaba.

## 2. Metodología — qué se ejecutó, no solo se leyó

Se escribió `dicom-engine/test/engine.e2e.test.js` (nuevo, versionado, sin dependencias de test framework) que simula un equipo real (SCU) hablando DIMSE contra el `AssociationServer` (SCP), y confirma cada paso decodificando la respuesta real del servidor — no asumiendo que llegó bien:

| # | Verificación | Resultado |
|---|---|---|
| 1-2 | Conexión TCP + A-ASSOCIATE-AC con 3 Presentation Contexts (Echo/MWL/Storage) negociados | ✅ |
| 3 | C-ECHO-RSP Status Success | ✅ |
| 4-5 | C-FIND/MWL: Pending×N + Success final, **y round-trip real de la Scheduled Procedure Step Sequence (0040,0100) anidada** — se decodificó lo que el servidor mandó y se confirmó que la Modalidad vive dentro del item de la secuencia, no suelta | ✅ |
| 6-7 | C-STORE-RSP Success + archivo Part10 válido en disco (preámbulo 128×0x00 + "DICM") | ✅ |
| 8 | StudyIndex indexado por Study Instance UID real (no "DESCONOCIDO") | ✅ (tras instalar dcmjs, ver §3) |
| 9 | A-RELEASE-RQ/RP: cierre limpio | ✅ |
| 10-12 | QIDO-RS `/studies` y `/series` devuelven lo que dejó el C-STORE; WADO-RS devuelve bytes **idénticos** a los guardados | ✅ |

Test repetido desde cero en una carpeta limpia (`unzip` del paquete final → `npm install` → `npm test`) para confirmar que lo que se entrega funciona igual fuera de mi entorno de trabajo. Mismo resultado: 12/12.

Además, dos funciones puras de `HIS-RIS-PACS.jsx` se extrajeron y probaron por separado contra casos de referencia:
- `rotar90CW`: matriz 2×2 conocida → resultado correcto; 4 rotaciones sucesivas devuelven la matriz original (invariante geométrico).
- `calcularFuncionRenal`: Cockcroft-Gault (hombre y mujer, con el factor 0.85) y Schwartz bedside 2009, contra casos de referencia calculados a mano — coinciden exacto.

Ambos componentes (`HIS-RIS-PACS.jsx` y `EquipmentConfigPanel.jsx`) se compilaron con `esbuild` — 0 errores de sintaxis.

## 3. Completado esta sesión (no solo verificado — resuelto)

- **`dcmjs` conectado de verdad** (§6 punto 4 del dossier maestro). La sesión anterior no pudo por falta de red en su sandbox; esta sí tuvo acceso al registro de npm. `npm install dcmjs` → `dcmjs@0.52.0` instalado, y el test end-to-end confirma que `extractTagsWithDcmjs` ya parsea de verdad: `StudyIndex` pasó de indexar todo bajo un bucket único `"DESCONOCIDO"` a indexar por el Study Instance UID real.
- `dicom-engine/package.json` + `package-lock.json` creados — no existía ninguno en el paquete original (ninguna dependencia estaba declarada en ningún lado).
- `dicom-engine/README.md` corregido: decía que el MWL iba con tags planos; el código ya anida la secuencia de verdad (confirmado por el test), el README solo estaba desactualizado. Se dejó nota de la corrección.

## 4. Otras discrepancias/matices encontrados (documentados, no todos bloqueantes)

| Hallazgo | Detalle | Estado |
|---|---|---|
| `PDU.js` no exporta `decodeAssociateAC` | Solo decodifica el lado SCP (RQ) y codifica el lado que responde (AC) — falta la mitad para que el motor actúe como **SCU** algún día (empujar a PACS externo, consultar MWL remoto). No bloquea el uso actual (siempre SCP). | Documentado en el README, no resuelto |
| Sin `dcmjs`, `StudyIndex` colapsaba en `"DESCONOCIDO"` | Confirmado por el test antes de instalar dcmjs. Con dcmjs instalado (ahora normal), no aplica. | Resuelto (§3) |
| Solo Schwartz **bedside 2009** implementada | El dossier de ampliación (§5) documentó también la Schwartz **clásica** (1976/1987, con K por edad/sexo) como fórmula verificada, pero no llegó a `HIS-RIS-PACS.jsx` — solo la bedside. | Abierto — decidir si hace falta la clásica también |
| `CIE10_MUESTRA` no cubre "R90-R94 completo" al 100% | Cubre R90.0, R91, R92.2, R93.2/4/5/6/7, R94 — bastantes subcódigos pero no todos los que existen en ese rango. Sigue siendo una muestra real, no inventada, solo no exhaustiva. | Nota de precisión, no un error |
| `dcmjs` trae `adm-zip` con vulnerabilidad conocida (alta severidad, DoS por ZIP manipulado) | No se explota con el uso actual (solo se usa `readFile`/`naturalizeDataset`, no la parte ZIP). `npm audit fix --force` bajaría a dcmjs 0.29.6 (breaking change) — no se aplicó unilateralmente. | Anotado en el README, pendiente decisión |
| **Referencia a un archivo no incluido en ningún upload**: `AXON_Actualizacion_Roles_Modulos_Satelite.md` | `HIS-RIS-PACS.jsx` cita ese archivo en un comentario como la fuente confirmada para `ROLES_INFORMANTES`. No está en el zip ni se subió antes. Relevante directo para "desarrollo satélite". | **Nuevo hallazgo — subir si todavía existe** |
| No había ningún archivo de test en el paquete original, pese a las etiquetas "Probado"/"Probado end-to-end" | Esas pruebas, si ocurrieron, pasaron en el sandbox efímero de una sesión anterior y no dejaron artefacto. No implica que fueran falsas — de hecho todas se confirmaron ciertas ahora — pero no eran verificables hasta esta sesión. | Resuelto: ahora existe `test/engine.e2e.test.js`, versionado, corre con `npm test` |

## 5. Estado real de §5 y §6 del dossier maestro (pendientes)

- **Bloqueados por falta de archivo** (no por falta de trabajo): `security_config.js` completo, `userTypes_config.js` actualizado, `AXON_Infraestructura_TLS_AES256.zip`, y ahora también `AXON_Actualizacion_Roles_Modulos_Satelite.md` — ninguno de los 4 está en los 3 archivos subidos esta sesión.
- **Desbloqueado y resuelto esta sesión:** punto 4 (`dcmjs`).
- **Desbloqueados, sin tocar todavía:** sidebar de estudios previos (layout), endpoint `WADO-RS /rendered`, ingreso manual de paciente + flujo de bono/pago (Ampliación §10-11), TENS como rol formal + reubicación de "radiologo" (Ampliación §12).

---
*Generado automáticamente al final de la verificación — pegar junto con AXON_DOSSIER_MAESTRO.md al inicio de la próxima sesión.*
