'use strict';
/**
 * RenderInstance.js — motor de WADO-RS /rendered: toma un archivo Part10 ya
 * guardado en el almacén y lo convierte en un PNG de 8 bits, con windowing.
 * Usa dcmjs para el parseo semántico del dataset (Rows, Columns, PixelData,
 * etc.) — el mismo dcmjs que ya usa CStoreDataset.js para indexar, no una
 * librería nueva.
 *
 * Por qué existe: hoy, para ver una imagen desde un visor externo simple (o
 * para una miniatura en un sistema de terceros), hay que traer el DICOM
 * completo y decodificarlo — WADO-RS /rendered evita eso, el servidor ya
 * entrega un PNG listo para un <img src>.
 *
 * Alcance de esta primera versión (puerta etiquetada, no fingido):
 *   - Solo escala de grises (MONOCHROME1/MONOCHROME2) — es lo único que el
 *     motor recibe hoy de verdad (CT/MR/CR/DX). RGB/YBR (ecografía Doppler
 *     a color, por ejemplo) lanza un error explícito, no una imagen
 *     incorrecta en silencio.
 *   - Solo el primer frame — no soporta cine/multiframe todavía.
 *   - BitsAllocated 8 o 16, con o sin signo (PixelRepresentation).
 *   - Solo Transfer Syntax no comprimida (Implicit VR LE) — coherente con
 *     que el motor tampoco recibe otra cosa hoy (ver README del motor).
 *   - Windowing: usa WindowCenter/WindowWidth del dataset si existen —
 *     misma fórmula lineal (PS3.3 C.11.2.1.2) que aplicarVentana() en
 *     HIS-RIS-PACS.jsx, a propósito, para que cliente y servidor rindan
 *     igual. Si no existen, hace auto-ventana con el mínimo/máximo real de
 *     la imagen (mismo criterio que cualquier visor sin VOI LUT declarada).
 */
const fs = require('fs');
const dcmjs = require('dcmjs');
const { codificarGrises8 } = require('./PngEncoder');

function primerValor(x) {
  if (Array.isArray(x)) return x.length ? Number(x[0]) : undefined;
  return x == null ? undefined : Number(x);
}

// Misma fórmula que aplicarVentana() en HIS-RIS-PACS.jsx — a propósito, no reinventada acá.
function aplicarVentana(x, center, width) {
  const w = Math.max(width, 1);
  if (x <= center - 0.5 - (w - 1) / 2) return 0;
  if (x > center - 0.5 + (w - 1) / 2) return 255;
  return ((x - (center - 0.5)) / (w - 1) + 0.5) * 255;
}

/**
 * @param {string} rutaArchivo - ruta absoluta al .dcm ya guardado por C-STORE
 * @returns {Buffer} PNG de 8 bits listo para servir
 */
function renderizarInstanciaAPng(rutaArchivo) {
  const buf = fs.readFileSync(rutaArchivo);
  const arrayBuffer = buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength);
  const dicomDict = dcmjs.data.DicomMessage.readFile(arrayBuffer);
  const ds = dcmjs.data.DicomMetaDictionary.naturalizeDataset(dicomDict.dict);

  const rows = primerValor(ds.Rows);
  const cols = primerValor(ds.Columns);
  if (!rows || !cols) throw new Error('El dataset no trae Rows/Columns válidos — no se puede renderizar.');

  const fotometria = (ds.PhotometricInterpretation || '').toUpperCase().trim();
  if (fotometria && !fotometria.startsWith('MONOCHROME')) {
    throw new Error(`PhotometricInterpretation "${ds.PhotometricInterpretation}" no soportada todavía — /rendered hoy solo cubre escala de grises (MONOCHROME1/MONOCHROME2).`);
  }

  if (!ds.PixelData || !ds.PixelData[0]) throw new Error('El dataset no trae Pixel Data.');
  const crudo = ds.PixelData[0]; // ArrayBuffer del primer frame/fragmento

  const bitsAlojados = primerValor(ds.BitsAllocated) || 16;
  const conSigno = primerValor(ds.PixelRepresentation) === 1;
  const slope = ds.RescaleSlope != null ? primerValor(ds.RescaleSlope) : 1;
  const intercept = ds.RescaleIntercept != null ? primerValor(ds.RescaleIntercept) : 0;

  const totalPixeles = rows * cols;
  const muestras = new Float64Array(totalPixeles);
  if (bitsAlojados === 8) {
    const vista = new Uint8Array(crudo);
    for (let i = 0; i < totalPixeles; i++) muestras[i] = vista[i] * slope + intercept;
  } else {
    const vista = conSigno ? new Int16Array(crudo) : new Uint16Array(crudo);
    for (let i = 0; i < totalPixeles; i++) muestras[i] = vista[i] * slope + intercept;
  }

  let center = primerValor(ds.WindowCenter);
  let width = primerValor(ds.WindowWidth);
  if (center == null || width == null || !isFinite(width) || width <= 0) {
    let min = Infinity, max = -Infinity;
    for (let i = 0; i < totalPixeles; i++) { if (muestras[i] < min) min = muestras[i]; if (muestras[i] > max) max = muestras[i]; }
    center = (min + max) / 2;
    width = Math.max(max - min, 1);
  }

  const invertir = fotometria === 'MONOCHROME1'; // en MONOCHROME1, 0 = blanco (al revés del caso normal)
  const salida8 = Buffer.alloc(totalPixeles);
  for (let i = 0; i < totalPixeles; i++) {
    let v = aplicarVentana(muestras[i], center, width);
    if (invertir) v = 255 - v;
    salida8[i] = Math.round(Math.max(0, Math.min(255, v)));
  }

  return codificarGrises8(salida8, cols, rows);
}

module.exports = { renderizarInstanciaAPng };
