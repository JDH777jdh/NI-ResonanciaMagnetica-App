# AXON — Motor DICOM (DIMSE) propio

Implementación propia del protocolo DICOM Upper Layer (PS3.7/PS3.8) — sin adoptar Orthanc/dcm4chee. Node.js puro para la capa de red y para el PNG de `/rendered`; `dcmjs` se usa solo para el parseo semántico del dataset clínico (Rows/Columns/PixelData/etc.), nunca para la red ni la lógica de negocio.

## Qué está construido y **probado** (`npm test` corre 7 archivos, 57 checks en total):

- **`WorklistApiServer.js` — API HTTP sobre el Worklist, para que el navegador pueda hablarle (26-ago-2026).** `WorklistStore.js` le dio al motor un lugar real de dónde leer/escribir el Worklist, pero es un archivo en disco — `HIS-RIS-PACS.jsx` corre en el navegador y no puede hacer `require('fs')`. Esto es la API HTTP (`GET/POST/PATCH /worklist`, sin Express, mismo estilo framework-agnostic que `DicomWebServer.js`) que le da al navegador ese acceso. A propósito es un archivo separado de `DicomWebServer.js`: ese implementa QIDO-RS/WADO-RS, que SON el estándar DICOMweb real — esta API de Worklist es invención propia de AXON, no protocolo estándar, y mezclarlas confundiría cuál es cuál. `test/worklist-api.e2e.test.js` (10 checks) prueba el CRUD HTTP solo, y — lo que más importa — la integración real en **ambas direcciones** contra un `AssociationServer` corriendo en paralelo sobre el mismo almacén: un registro creado por `POST /worklist` aparece en un C-FIND real (API→DIMSE), y un C-STORE real marca "Almacenado" un registro que después `GET /worklist/:id` ya refleja (DIMSE→API) — confirmado que API y motor DIMSE comparten una sola fuente de verdad, no dos copias que se puedan desincronizar.
- **`WorklistStore.js` — el Worklist ya es real, no dos simulaciones separadas (26-ago-2026).** Hasta esta sesión, `worklistProvider` (el gancho que responde el C-FIND de Modality Worklist) siempre recibía un array hardcodeado — en los 5 tests y en cualquier uso real — y del otro lado, `guardarYEnviar()` en `HIS-RIS-PACS.jsx` fingía con un `setTimeout` que "llegó" el C-STORE. Ahora: si no se le pasa un `worklistProvider` explícito a `iniciarServidor()`, el motor responde el C-FIND con lo que de verdad hay en `WorklistStore` (JSON en disco, mismo patrón que `StudyIndex.js`); y cuando llega un C-STORE real cuyo Accession Number coincide con un registro pendiente, `_handleCStore` lo marca `fase: "examenes", estado: "almacenado"` — sin ningún timer de por medio. `test/worklist-store.e2e.test.js` prueba el ciclo completo: paciente sembrado → C-FIND real lo trae → C-STORE real lo marca Almacenado → un segundo C-FIND confirma que ya no aparece. Los 5 tests anteriores siguen pasando sin cambios (todos pasan su propio `worklistProvider`, así que nunca tocan este código nuevo). Sigue pendiente, aparte: cablear `HIS-RIS-PACS.jsx` para que hable con este store en vez de su `useState` local — ese es un cambio más grande al componente principal, queda como paso siguiente.

- **Asociación** (A-ASSOCIATE-RQ/AC/RJ) — negociación de Presentation Contexts contra `AeRegistry`.
- **C-ECHO** (verificación/ping DICOM).
- **C-STORE** — recibe la imagen, la guarda en disco (Part10 válido: preámbulo + File Meta + dataset), responde con Status Success. Emite evento de auditoría.
- **C-FIND / Modality Worklist** — responde con los pendientes reales de la Worklist (Pending × N + Success final), con la *Scheduled Procedure Step Sequence* (0040,0100) **realmente anidada** — confirmado por round-trip en el test (decodificando lo que el propio servidor emitió).
- **DICOMweb** (`DicomWebServer.js`) — QIDO-RS y WADO-RS sobre el mismo almacén, confirmado end-to-end (bytes recuperados por HTTP idénticos a los guardados por DIMSE).
- **WADO-RS `/rendered`** (21-jul-2026, `test/render.e2e.test.js`) — la instancia convertida a PNG de 8 bits, para que un visor externo no tenga que decodificar DICOM. Encoder PNG propio (`rendering/PngEncoder.js`, byte a byte, mismo estilo que `PDU.js`) + windowing con la misma fórmula que `aplicarVentana()` del visor cliente (`HIS-RIS-PACS.jsx`). Verificado con una librería PNG independiente (`pngjs`, solo como devDependency de test) decodificando y comparando los 64 píxeles de una imagen sintética, uno por uno, contra el valor esperado.
- **Registro de equipos configurable** (`AeRegistry.js` + `ui/EquipmentConfigPanel.jsx`) — agregar un equipo nuevo no toca este motor.
- **`dcmjs` conectado** (20-jul-2026) — `npm install` lo trae como dependencia real; `extractTagsWithDcmjs` ya no es un camino sin probar, el test confirma que el `StudyIndex` indexa bajo el Study Instance UID real, no bajo el bucket `DESCONOCIDO`.
- **`ImplicitVrCodec.encodeElement` ahora soporta VRs numéricos binarios** (US/UL/SS/SL/FL/FD — 21-jul-2026). Antes solo sabía de SQ y de valores tipo texto; tags como Rows/Columns/BitsAllocated (todos VR=US) se habrían escrito como texto ASCII en vez de enteros binarios. Nada del código existente lo necesitaba hasta ahora — `/rendered` sí, porque son tags obligatorios de cualquier imagen.
- **Explicit VR Little Endian — soportada de verdad (31-jul-2026)**, con `ExplicitVrCodec.js` nuevo (mismo estilo que `ImplicitVrCodec.js`, escrito byte a byte). Historia completa: se probó el motor contra DICOM **reales** (`CT_small.dcm`/`MR_small.dcm`, repositorio de test files de pydicom — ver `test/fixtures/`) y se encontró que vienen en Explicit VR LE, no Implicit — lo que ofrece la inmensa mayoría del equipo real. Primero (23-jul-2026) se corrigió la negociación para **rechazar** Explicit VR honestamente (el codec no la soportaba todavía, mejor rechazar que aceptar a medias). Ahora (31-jul-2026) se implementó el codec real y la negociación vuelve a aceptarla — pero esta vez de verdad: `test/real-dicom-explicit-vr.e2e.test.js` manda `CT_small.dcm` completo por **C-STORE genuino vía DIMSE**, confirma que la asociación acepta Explicit VR, y que el dataset guardado (con Pixel Data incluido) es **byte a byte idéntico** al original. Ventaja real del nuevo decoder sobre el de Implicit VR: como el VR viene en el propio stream, no necesita el diccionario externo (`knownSQTags`) para saber qué es una secuencia.
- **Negociación de Transfer Syntax** — la lista aceptada (`AeRegistry.TRANSFER_SYNTAXES_ESTANDAR`) ahora incluye Implicit VR LE y Explicit VR LE, ambas genuinamente soportadas por su codec correspondiente — `AssociationServer.js` elige el codec correcto según lo que se negoció para cada Presentation Context, no asume uno fijo.

*(Nota de actualización 20-jul-2026: la versión anterior de este README decía que el MWL iba con tags "planos" — eso ya no es así, quedó desactualizado respecto al código. El test end-to-end lo confirma.)*

## Simplificado a propósito (anotado en el código, no escondido):

- **`src/wrapping/EncapsulatedDocument.js` (31-jul-2026)** — envuelve un PDF real como objeto DICOM válido (Encapsulated PDF Storage, SOP Class `1.2.840.10008.5.1.4.1.1.104.1`, verificado contra el estándar y contra conformance statements reales), para que viva en el mismo almacén y comparta Study Instance UID con las imágenes del mismo evento clínico — primer caso de uso: consentimiento informado. Se codifica con `ExplicitVrCodec.js` a propósito, no con Implicit VR: para tags poco comunes como los de Encapsulated Document, dcmjs necesita el VR en el propio stream para no adivinar mal (encontrado en pruebas: bajo Implicit VR, dcmjs intentaba leer el documento como si fuera una secuencia y fallaba). `test/encapsulated-pdf.e2e.test.js` prueba de punta a punta: PDF real (generado con reportlab) + una imagen sintética, ambos bajo el mismo Study Instance UID vía C-STORE real, extracción del PDF byte a byte idéntica, QIDO-RS mostrando las 2 series del mismo estudio, y `/rendered` respondiendo 422 (no un crash) al pedírsele que "renderice" un documento que no es una imagen.
- `STORAGE_SOP_CLASSES` en `AssociationServer.js` ahora incluye el SOP Class de Encapsulated PDF — sin esto, la negociación rechazaba el Presentation Context del documento aunque el wrapping en sí estuviera bien construido (hallazgo real durante las pruebas, no evidente hasta correr el ciclo completo).

- **Sin `dcmjs` instalado**, `StudyIndex` cae en modo degradado: indexa todo bajo un único bucket `DESCONOCIDO` en vez de por Study Instance UID real (porque el Command Set DIMSE no trae Study/Series Instance UID — esos tags viven en el dataset, que solo `dcmjs` sabe parsear hoy). Con `dcmjs` instalado (caso normal desde ahora), esto no aplica.
- Transfer Syntax soportada hoy: Implicit VR LE y Explicit VR LE (ambas sin comprimir). Compresión (JPEG/JPEG2000/RLE) queda para cuando haya equipos reales que la exijan — es un cambio de formato de Pixel Data, no de estructura de dataset, así que no obliga a tocar ninguno de los dos codecs actuales.
- TLS: el servidor acepta `tlsOptions` y los usa si se le pasan — para producción es obligatorio (perfil PS3.15), acá quedó opcional para poder probar en texto plano contra el test end-to-end.
- `PDU.js` hoy solo decodifica el lado **SCP** (`decodeAssociateRQ`) y codifica el lado que responde (`encodeAssociateAC`) — no existe `decodeAssociateAC`. Alcanza para el caso de uso actual (el motor siempre responde asociaciones entrantes de equipos, nunca las inicia), pero si AXON necesita algún día actuar como SCU (por ejemplo, empujar a un PACS externo o consultar un MWL remoto), falta esa mitad. `test/engine.e2e.test.js` tuvo que reimplementar un decoder mínimo solo para poder leer la respuesta del servidor en la prueba.
- `dcmjs` trae una dependencia transitiva (`adm-zip`) con una vulnerabilidad conocida de severidad alta (asignación de memoria de 4GB con un ZIP manipulado — `npm audit` para el detalle). No se explota por el uso actual (solo se usa `DicomMessage.readFile`/`naturalizeDataset`, no la parte de ZIP de dcmjs), pero vale la pena revisarlo antes de producción.
- **`/rendered` hoy solo cubre escala de grises** (MONOCHROME1/MONOCHROME2 — CT/MR/CR/DX). Una instancia RGB/YBR (ecografía Doppler a color, por ejemplo) responde `422` con el motivo explícito, no una imagen inventada ni un `500`. Tampoco soporta multiframe (solo el primer frame) ni Transfer Syntax comprimida — coherente con que el motor tampoco recibe otra cosa hoy.
- El encoder PNG (`rendering/PngEncoder.js`) usa siempre filtro de fila "None" — el PNG es 100% válido igual, solo comprime un poco menos que con un filtro adaptativo (Paeth, etc.). No vale la pena esa complejidad para imágenes médicas.
- `pngjs` está en `devDependencies`, **no** en `dependencies` — se usa solo dentro de `test/render.e2e.test.js` para decodificar el PNG con una librería independiente y confirmar que el encoder propio produce bytes realmente válidos. El código de producción (`PngEncoder.js`, `RenderInstance.js`, `DicomWebServer.js`) nunca la importa.

## Cómo correrlo

```js
const { iniciarServidor } = require('./src/server/AssociationServer');
iniciarServidor({
  port: 104,
  almacenPath: '/var/axon/almacen',
  worklistProvider: (equipo) => obtenerPendientesDesdeWorklistReal(equipo),
  tlsOptions: { key: fs.readFileSync('server.key'), cert: fs.readFileSync('server.crt') },
});
```

`worklistProvider` es el punto de enganche con la Worklist real de AXON (hoy en React/useState, mañana en `DatabaseService`).

```js
const http = require('http');
const { crearHandler } = require('./src/server/DicomWebServer');
http.createServer(crearHandler({ almacenPath: '/var/axon/almacen' })).listen(8042);
// GET /studies · /studies/{uid}/series · .../instances · .../instances/{uid} · .../instances/{uid}/rendered
```

```js
const http = require('http');
const path = require('path');
const { crearHandler } = require('./src/server/WorklistApiServer');
const ALMACEN = '/var/axon/almacen';
http.createServer(crearHandler({ storePath: path.join(ALMACEN, '.worklist-store.json') })).listen(8043);
// GET/POST /worklist · GET/PATCH /worklist/{id} — mismo archivo que lee AssociationServer.js si le pasás el mismo almacenPath
```
