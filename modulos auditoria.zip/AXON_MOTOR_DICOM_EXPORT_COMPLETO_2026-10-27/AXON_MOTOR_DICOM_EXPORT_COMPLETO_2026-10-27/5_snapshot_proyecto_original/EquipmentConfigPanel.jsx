import { useState } from "react";
import { Monitor, Plus, Trash2, Power, Radio, Search, HardDrive, Wifi, X, ShieldCheck } from "lucide-react";

/* ════════════════════════════════════════════════════════════════════
   Panel de configuración de equipos DICOM — la puerta etiquetada de hardware.
   Agregar un TC/RM/RX nuevo es llenar este formulario; el motor
   (AssociationServer.js + AeRegistry.js) lee exactamente esta misma forma
   de datos. Acá vive en memoria del componente — en producción, "Guardar"
   llama a una API que escribe en AeRegistry (equipos.json / DB).
   ════════════════════════════════════════════════════════════════════ */

const D = {
  bg: "#0A1420", sfc: "#111F32", sfc2: "#0D1A29", brd: "#1E3350",
  txt: "#EAF0FA", txm: "#96AAC6", txl: "#5E7593",
  pri: "#4C8DFF", tea: "#22D3B8", dan: "#FF5C6C", war: "#FFA359", suc: "#5FD97A", pur: "#B37FE0",
};

const MODALIDADES = ["TC", "RM", "RX", "US", "MG", "XA", "PT", "MN"];

const SEED_EQUIPOS = [
  { id: "ct_sala1", nombre: "TC Sala 1", aeTitle: "CT_SALA1", ip: "192.168.1.21", port: 104, modalidad: "TC", scp: true, scu: true, mwl: true, activo: true },
  { id: "mr_sala1", nombre: "RM Sala 1", aeTitle: "MR_SALA1", ip: "192.168.1.22", port: 104, modalidad: "RM", scp: true, scu: true, mwl: true, activo: true },
  { id: "dx_sala1", nombre: "RX Sala 1", aeTitle: "DX_SALA1", ip: "192.168.1.23", port: 104, modalidad: "RX", scp: true, scu: true, mwl: true, activo: true },
];

const emptyForm = { nombre: "", aeTitle: "", ip: "", port: 104, modalidad: "TC", scp: true, scu: true, mwl: true };

const RoleBadge = ({ label, on, color }) => (
  <span style={{ display: "inline-flex", alignItems: "center", gap: 3, padding: "2px 7px", borderRadius: 5, fontSize: 9, fontWeight: 700, background: on ? `${color}22` : "transparent", color: on ? color : D.txl, border: `1px solid ${on ? color + "44" : D.brd}` }}>
    {label}
  </span>
);

const Field = ({ label, children }) => (
  <div>
    <div style={{ fontSize: 9.5, fontWeight: 700, color: D.txl, textTransform: "uppercase", letterSpacing: "0.4px", marginBottom: 5 }}>{label}</div>
    {children}
  </div>
);
const inputStyle = { width: "100%", padding: "8px 10px", borderRadius: 7, border: `1px solid ${D.brd}`, background: D.bg, color: D.txt, fontSize: 12 };

export default function EquipmentConfigPanel() {
  const [equipos, setEquipos] = useState(SEED_EQUIPOS);
  const [search, setSearch] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [error, setError] = useState("");
  const [testResult, setTestResult] = useState({});

  const filtrados = equipos.filter((e) => !search || e.nombre.toLowerCase().includes(search.toLowerCase()) || e.aeTitle.toLowerCase().includes(search.toLowerCase()));

  const toggleActivo = (id) => setEquipos((prev) => prev.map((e) => (e.id === id ? { ...e, activo: !e.activo } : e)));
  const eliminar = (id) => setEquipos((prev) => prev.filter((e) => e.id !== id));

  const guardar = () => {
    if (!form.nombre.trim() || !form.aeTitle.trim() || !form.ip.trim()) { setError("Nombre, AE Title e IP son obligatorios."); return; }
    if (equipos.some((e) => e.aeTitle === form.aeTitle.trim().toUpperCase())) { setError(`Ya existe un equipo con AE Title "${form.aeTitle}".`); return; }
    const nuevo = { id: `eq_${Date.now()}`, ...form, aeTitle: form.aeTitle.trim().toUpperCase(), port: Number(form.port), activo: true };
    setEquipos((prev) => [...prev, nuevo]);
    setForm(emptyForm); setShowForm(false); setError("");
  };

  /* Simulación honesta: en producción esto dispara un C-ECHO real (Verification SOP Class) contra ip:port. */
  const probarConexion = (id) => {
    setTestResult((prev) => ({ ...prev, [id]: "probando" }));
    setTimeout(() => setTestResult((prev) => ({ ...prev, [id]: Math.random() > 0.15 ? "ok" : "error" })), 900);
  };

  return (
    <div style={{ background: D.bg, minHeight: 600, padding: 20, fontFamily: "'Inter',system-ui,-apple-system,sans-serif" }}>
      <style>{`*{box-sizing:border-box;} select{-webkit-appearance:none;} ::-webkit-scrollbar{width:5px;height:5px;} ::-webkit-scrollbar-thumb{background:#2A415F;border-radius:4px;}`}</style>

      <div style={{ display: "flex", alignItems: "center", gap: 6, opacity: 0.55, marginBottom: 10 }}>
        <div style={{ width: 16, height: 16, borderRadius: 5, background: `linear-gradient(135deg, ${D.pri}, ${D.pur})`, display: "flex", alignItems: "center", justifyContent: "center" }}>
          <span style={{ fontSize: 9, fontWeight: 800, color: "#0A1420" }}>A</span>
        </div>
        <span style={{ fontSize: 9, fontWeight: 700, color: D.txl, textTransform: "uppercase", letterSpacing: "1.2px" }}>AXON · Config DICOM</span>
      </div>

      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 10, marginBottom: 18 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{ background: `${D.pri}18`, borderRadius: 10, padding: 10 }}><Monitor size={22} color={D.pri} /></div>
          <div>
            <h2 style={{ margin: 0, fontSize: 17, fontWeight: 700, color: D.txt }}>Equipos DICOM</h2>
            <p style={{ margin: "2px 0 0", fontSize: 11, color: D.txl }}>Registrar un equipo acá es la única puerta — el motor no se toca</p>
          </div>
        </div>
        <button onClick={() => { setShowForm((s) => !s); setError(""); }} style={{ display: "flex", alignItems: "center", gap: 6, padding: "8px 14px", borderRadius: 8, border: "none", background: D.pri, color: "#0A1420", fontSize: 12, fontWeight: 700, cursor: "pointer" }}>
          <Plus size={14} />Agregar equipo
        </button>
      </div>

      {showForm && (
        <div style={{ background: D.sfc, border: `1px solid ${D.brd}`, borderRadius: 12, padding: 16, marginBottom: 16 }}>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(150px,1fr))", gap: 10, marginBottom: 12 }}>
            <Field label="Nombre"><input value={form.nombre} onChange={(e) => setForm({ ...form, nombre: e.target.value })} placeholder="Ej. TC Sala 2" style={inputStyle} /></Field>
            <Field label="AE Title"><input value={form.aeTitle} onChange={(e) => setForm({ ...form, aeTitle: e.target.value })} placeholder="Ej. CT_SALA2" style={{ ...inputStyle, fontFamily: "monospace" }} /></Field>
            <Field label="Modalidad">
              <select value={form.modalidad} onChange={(e) => setForm({ ...form, modalidad: e.target.value })} style={inputStyle}>
                {MODALIDADES.map((m) => <option key={m} value={m}>{m}</option>)}
              </select>
            </Field>
            <Field label="IP"><input value={form.ip} onChange={(e) => setForm({ ...form, ip: e.target.value })} placeholder="192.168.1.30" style={{ ...inputStyle, fontFamily: "monospace" }} /></Field>
            <Field label="Puerto"><input type="number" value={form.port} onChange={(e) => setForm({ ...form, port: e.target.value })} style={{ ...inputStyle, fontFamily: "monospace" }} /></Field>
          </div>
          <div style={{ display: "flex", gap: 16, marginBottom: 14, flexWrap: "wrap" }}>
            {[["scp", "Recibe imágenes (Storage SCP)"], ["scu", "Consulta al PACS (SCU)"], ["mwl", "Recibe Worklist (MWL)"]].map(([k, label]) => (
              <label key={k} style={{ display: "flex", alignItems: "center", gap: 7, fontSize: 11.5, color: D.txm, cursor: "pointer" }}>
                <input type="checkbox" checked={form[k]} onChange={(e) => setForm({ ...form, [k]: e.target.checked })} />{label}
              </label>
            ))}
          </div>
          {error && <div style={{ fontSize: 11, color: D.dan, marginBottom: 10 }}>{error}</div>}
          <div style={{ display: "flex", gap: 8 }}>
            <button onClick={guardar} style={{ padding: "8px 16px", borderRadius: 7, border: "none", background: D.suc, color: "#0A1420", fontSize: 12, fontWeight: 700, cursor: "pointer" }}>Guardar equipo</button>
            <button onClick={() => { setShowForm(false); setError(""); }} style={{ padding: "8px 16px", borderRadius: 7, border: `1px solid ${D.brd}`, background: "transparent", color: D.txm, fontSize: 12, fontWeight: 600, cursor: "pointer" }}>Cancelar</button>
          </div>
        </div>
      )}

      <div style={{ display: "flex", alignItems: "center", background: D.sfc, border: `1px solid ${D.brd}`, borderRadius: 8, padding: "7px 11px", gap: 7, maxWidth: 320, marginBottom: 14 }}>
        <Search size={13} color={D.txl} />
        <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Buscar por nombre o AE Title…" style={{ border: "none", outline: "none", background: "none", fontSize: 12, color: D.txt, width: "100%" }} />
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        {filtrados.map((e) => (
          <div key={e.id} style={{ background: D.sfc, border: `1px solid ${e.activo ? D.brd : D.brd}`, borderRadius: 10, padding: "12px 14px", display: "flex", alignItems: "center", justifyContent: "space-between", gap: 10, flexWrap: "wrap", opacity: e.activo ? 1 : 0.5 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 14, flexWrap: "wrap" }}>
              <div>
                <div style={{ fontSize: 12.5, fontWeight: 700, color: D.txt }}>{e.nombre}</div>
                <div style={{ display: "flex", alignItems: "center", gap: 6, marginTop: 2, fontSize: 10, color: D.txl, fontFamily: "monospace" }}><Wifi size={11} />{e.aeTitle} · {e.ip}:{e.port}</div>
              </div>
              <span style={{ fontSize: 10, fontWeight: 700, color: D.pri, background: `${D.pri}18`, padding: "2px 8px", borderRadius: 5 }}>{e.modalidad}</span>
              <div style={{ display: "flex", gap: 5 }}>
                <RoleBadge label="SCP" on={e.scp} color={D.suc} />
                <RoleBadge label="SCU" on={e.scu} color={D.pri} />
                <RoleBadge label="MWL" on={e.mwl} color={D.tea} />
              </div>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
              <button onClick={() => probarConexion(e.id)} style={{ display: "flex", alignItems: "center", gap: 5, padding: "6px 10px", borderRadius: 6, border: `1px solid ${D.brd}`, background: "transparent", color: D.txm, fontSize: 10.5, fontWeight: 600, cursor: "pointer" }}>
                <Radio size={11} />{testResult[e.id] === "probando" ? "Probando…" : "Probar (C-ECHO)"}
              </button>
              {testResult[e.id] === "ok" && <span style={{ fontSize: 9.5, color: D.suc, fontWeight: 700 }}>✓ responde</span>}
              {testResult[e.id] === "error" && <span style={{ fontSize: 9.5, color: D.dan, fontWeight: 700 }}>✗ sin respuesta</span>}
              <button onClick={() => toggleActivo(e.id)} title={e.activo ? "Desactivar" : "Activar"} style={{ background: "none", border: "none", cursor: "pointer", color: e.activo ? D.suc : D.txl }}><Power size={14} /></button>
              <button onClick={() => eliminar(e.id)} title="Eliminar" style={{ background: "none", border: "none", cursor: "pointer", color: D.txl }}><Trash2 size={14} /></button>
            </div>
          </div>
        ))}
        {filtrados.length === 0 && <div style={{ fontSize: 12, color: D.txl, textAlign: "center", padding: 24 }}>Sin equipos que coincidan.</div>}
      </div>

      <div style={{ marginTop: 16, display: "flex", alignItems: "center", gap: 7, fontSize: 10.5, color: D.txl }}>
        <ShieldCheck size={13} />Toda conexión pasa por TLS (perfil PS3.15) — un AE Title no listado acá se rechaza en la asociación, no en este panel.
      </div>
    </div>
  );
}
