'use strict';
/**
 * real-dicom-explicit-vr.e2e.test.js — la prueba decisiva del hallazgo de esta
 * sesión: CT_small.dcm real (Explicit VR LE genuino, del repositorio de test
 * files de pydicom — test/fixtures/CT_small.dcm) ingresado por C-STORE de
 * verdad, no simulado. Antes de este fix, la asociación rechazaba Explicit VR
 * limpiamente (correcto, no corrompía nada, pero limitaba qué equipo real podía
 * conectarse). Ahora se acepta y se procesa de punta a punta.
 *
 * Verifica, con datos reales, no sintéticos:
 *   - La asociación acepta Explicit VR LE (antes se rechazaba a propósito).
 *   - El C-STORE completo funciona con el dataset real de un CT.
 *   - El dataset guardado (todo lo posterior al File Meta, incluyendo Pixel
 *     Data) es BYTE A BYTE idéntico al original — nada se corrompe.
 *   - WADO-RS /rendered funciona sobre la imagen recién ingresada por DIMSE.
 */
const net = require('net');
const path = require('path');
const fs = require('fs');
const http = require('http');

const SRC = path.join(__dirname, '..', 'src');
const PDU = require(path.join(SRC, 'pdu', 'PDU'));
const DIMSE = require(path.join(SRC, 'pdu', 'DimseCommand'));
const Explicit = require(path.join(SRC, 'pdu', 'ExplicitVrCodec'));
const { iniciarServidor } = require(path.join(SRC, 'server', 'AssociationServer'));
const DicomWebServer = require(path.join(SRC, 'server', 'DicomWebServer'));

const FIXTURE = path.join(__dirname, 'fixtures', 'CT_small.dcm');

let paso = 0;
function ok(d) { paso++; console.log(`OK  [${paso}] ${d}`); }
function fail(d) { paso++; console.log(`FAIL[${paso}] ${d}`); process.exitCode = 1; }

function decodeAssociateAC(buf) {
  let o = 6; o += 2; o += 2; o += 16; o += 16; o += 32;
  const results = [];
  while (o < buf.length) {
    const t = buf.readUInt8(o); const l = buf.readUInt16BE(o + 2);
    const body = buf.slice(o + 4, o + 4 + l);
    if (t === 0x21) results.push({ id: body.readUInt8(0), accepted: body.readUInt8(2) === 0 });
    o += 4 + l;
  }
  return { results };
}

// Todo lo que va DESPUÉS del File Meta Information — exactamente lo que un
// C-STORE-RQ real llevaría como payload de dataset.
function extraerDatasetCrudo(rutaArchivo) {
  const buf = fs.readFileSync(rutaArchivo);
  const primerElemento = Explicit.decodeElementAt(buf, 132); // 128 preámbulo + 4 "DICM"
  const finDeFileMeta = primerElemento.nextOffset + primerElemento.value;
  const fileMeta = Explicit.decodeDataset(buf.slice(132, finDeFileMeta));
  const sopClassUID = fileMeta.find((e) => e.tag === '00020002').value.replace(/\0+$/, '');
  const sopInstanceUID = fileMeta.find((e) => e.tag === '00020003').value.replace(/\0+$/, '');
  return { datasetCrudo: buf.slice(finDeFileMeta), sopClassUID, sopInstanceUID };
}

async function main() {
  const WORKDIR = path.join(__dirname, '.tmp-real-explicit-vr-test');
  fs.rmSync(WORKDIR, { recursive: true, force: true });
  fs.mkdirSync(WORKDIR, { recursive: true });
  const ALMACEN = path.join(WORKDIR, 'almacen');

  const server = iniciarServidor({ port: 0, almacenPath: ALMACEN, worklistProvider: () => [], tlsOptions: null });
  await new Promise((r) => server.once('listening', r));
  const PORT = server.address().port;
  const socket = net.connect(PORT, '127.0.0.1');
  await new Promise((res, rej) => { socket.once('connect', res); socket.once('error', rej); });

  let buffer = Buffer.alloc(0); const pduQueue = []; const waiters = [];
  socket.on('data', (chunk) => {
    buffer = Buffer.concat([buffer, chunk]);
    let header;
    while ((header = PDU.peekPduHeader(buffer)) && buffer.length >= header.totalSize) {
      const pdu = buffer.slice(0, header.totalSize); buffer = buffer.slice(header.totalSize);
      if (waiters.length) waiters.shift()(pdu); else pduQueue.push(pdu);
    }
  });
  function nextPdu(t = 3000) { return new Promise((res, rej) => { if (pduQueue.length) return res(pduQueue.shift()); const tm = setTimeout(() => rej(new Error('timeout')), t); waiters.push((p) => { clearTimeout(tm); res(p); }); }); }

  const { datasetCrudo, sopClassUID, sopInstanceUID } = extraerDatasetCrudo(FIXTURE);
  ok(`CT_small.dcm real: SOP Class ${sopClassUID}, dataset crudo extraído (${datasetCrudo.length} bytes)`);

  const rq = PDU.encodeAssociateRQ({
    calledAE: 'AXON_RIS', callingAE: 'CT_SALA1',
    presentationContexts: [{ id: 1, abstractSyntax: sopClassUID, transferSyntaxes: ['1.2.840.10008.1.2.1'] }],
    maxPduLength: 16384, implementationClassUID: '1.2.840.99999.1.1',
  });
  socket.write(rq);
  const ac = decodeAssociateAC(await nextPdu());
  if (ac.results[0] && ac.results[0].accepted) ok('A-ASSOCIATE-AC: Explicit VR LE ACEPTADO (antes de este fix, se rechazaba)');
  else { fail('Explicit VR LE fue rechazado — no debería, ya está soportado'); socket.end(); server.close(); process.exit(1); }

  const storeRq = DIMSE.encodeCommandSet({ '00000002': sopClassUID, '00000100': DIMSE.COMMAND_FIELD.C_STORE_RQ, '00000110': 1, '00000700': 0, '00000800': 0x0102, '00001000': sopInstanceUID });
  socket.write(PDU.encodePDataTF([
    { presentationContextId: 1, isCommand: true, isLast: true, data: storeRq },
    { presentationContextId: 1, isCommand: false, isLast: true, data: datasetCrudo },
  ]));
  const storeRsp = DIMSE.decodeCommandSet(PDU.decodePDataTF(await nextPdu())[0].data);
  if (storeRsp['00000900'] === DIMSE.STATUS.SUCCESS) ok('C-STORE-RSP: Status SUCCESS — CT real (Explicit VR) aceptado y guardado vía DIMSE genuino');
  else fail('C-STORE-RSP con status inesperado: 0x' + (storeRsp['00000900'] || 0).toString(16));

  const rutaArchivo = path.join(ALMACEN, sopInstanceUID.replace(/[^0-9.]/g, '_') + '.dcm');
  if (fs.existsSync(rutaArchivo)) {
    const guardado = fs.readFileSync(rutaArchivo);
    // El File Meta lo reconstruye el receptor (su propio Implementation Class UID) —
    // correcto por estándar, un C-STORE no transmite el File Meta del emisor. Lo que
    // SÍ debe ser idéntico es el dataset completo, incluyendo Pixel Data.
    const finFileMetaGuardado = Explicit.decodeElementAt(guardado, 132);
    const datasetGuardado = guardado.slice(finFileMetaGuardado.nextOffset + finFileMetaGuardado.value);
    if (Buffer.compare(datasetCrudo, datasetGuardado) === 0) {
      ok(`Dataset guardado (${datasetGuardado.length} bytes, incluye Pixel Data) IDÉNTICO byte a byte al original — nada se corrompió al pasar por DIMSE`);
    } else fail('El dataset guardado difiere del original — esto sí sería corrupción real');
  } else fail('No se encontró el archivo guardado');

  socket.write(PDU.encodeReleaseRQ());
  await nextPdu();
  socket.end();

  const httpServer = http.createServer(DicomWebServer.crearHandler({ almacenPath: ALMACEN }));
  await new Promise((r) => httpServer.listen(0, r));
  const port = httpServer.address().port;
  const estudios = JSON.parse(await new Promise((resolve) => { http.get(`http://127.0.0.1:${port}/studies`, (res) => { let d = ''; res.on('data', (c) => d += c); res.on('end', () => resolve(d)); }); }));
  if (estudios.length === 1) {
    const studyUID = estudios[0]['0020000D'].Value[0];
    const series = JSON.parse(await new Promise((resolve) => { http.get(`http://127.0.0.1:${port}/studies/${studyUID}/series`, (res) => { let d = ''; res.on('data', (c) => d += c); res.on('end', () => resolve(d)); }); }));
    const seriesUID = series[0]['0020000E'].Value[0];
    const wadoBytes = await new Promise((resolve) => { http.get(`http://127.0.0.1:${port}/studies/${studyUID}/series/${seriesUID}/instances/${sopInstanceUID}/rendered`, (res) => { const chunks = []; res.on('data', (c) => chunks.push(c)); res.on('end', () => resolve(Buffer.concat(chunks))); }); });
    const firmaValida = wadoBytes.slice(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]));
    if (firmaValida) ok(`WADO-RS /rendered sobre el CT ingresado por DIMSE con Explicit VR: PNG real y válido (${wadoBytes.length} bytes)`);
    else fail('PNG inválido desde WADO-RS');
  } else fail('QIDO-RS no devolvió el estudio esperado');

  httpServer.close(); server.close();
  fs.rmSync(WORKDIR, { recursive: true, force: true });
  console.log(`\n=== RESULTADO: ${process.exitCode ? 'HAY FALLAS ARRIBA' : 'TODO PASÓ — CT real ingresado por DIMSE genuino con Explicit VR, de punta a punta'} ===`);
  process.exit(process.exitCode || 0);
}
main().catch((e) => { console.error('ERROR FATAL:', e); process.exit(1); });
