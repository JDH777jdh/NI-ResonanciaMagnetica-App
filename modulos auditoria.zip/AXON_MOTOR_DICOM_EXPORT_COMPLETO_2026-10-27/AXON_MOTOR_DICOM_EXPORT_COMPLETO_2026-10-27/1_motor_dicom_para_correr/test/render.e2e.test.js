'use strict';
/**
 * render.e2e.test.js — WADO-RS /rendered, de punta a punta.
 *
 * Tres niveles de verificación, cada uno independiente:
 *   A) La fórmula de windowing (RenderInstance.js) contra valores calculados
 *      a mano — no contra sí misma.
 *   B) El CRC32 del PNG (PngEncoder.js) contra el vector de referencia
 *      estándar de la especificación ("123456789" -> 0xCBF43926).
 *   C) El pipeline completo: construir una imagen sintética con un patrón
 *      conocido -> guardarla -> indexarla -> pedirla por HTTP a
 *      /rendered -> decodificar el PNG con `pngjs` (librería independiente,
 *      SOLO de test — nunca se usa desde el código de producción) -> los
 *      píxeles decodificados tienen que coincidir con lo esperado.
 */
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const http = require('http');
const { PNG } = require('pngjs');

const SRC = path.join(__dirname, '..', 'src');
const ImplicitVR = require(path.join(SRC, 'pdu', 'ImplicitVrCodec'));
const { buildStoredFile, extractTagsWithDcmjs } = require(path.join(SRC, 'server', 'CStoreDataset'));
const StudyIndex = require(path.join(SRC, 'storage', 'StudyIndex'));
const DicomWebServer = require(path.join(SRC, 'server', 'DicomWebServer'));
const { crc32 } = require(path.join(SRC, 'rendering', 'PngEncoder'));

let paso = 0;
function ok(desc) { paso++; console.log(`OK  [${paso}] ${desc}`); }
function fail(desc) { paso++; console.log(`FAIL[${paso}] ${desc}`); process.exitCode = 1; }

// --- A) aplicarVentana, extraída de HIS-RIS-PACS.jsx, contra valores hechos a mano ---
function aplicarVentana(x, center, width) {
  const w = Math.max(width, 1);
  if (x <= center - 0.5 - (w - 1) / 2) return 0;
  if (x > center - 0.5 + (w - 1) / 2) return 255;
  return ((x - (center - 0.5)) / (w - 1) + 0.5) * 255;
}
try {
  assert.strictEqual(aplicarVentana(0, 128, 256), 0);
  assert.strictEqual(aplicarVentana(255, 128, 256), 255);
  assert.ok(Math.abs(aplicarVentana(128, 128, 256) - 128) < 0.01);
  assert.strictEqual(aplicarVentana(-100, 128, 256), 0); // clamp por abajo
  assert.strictEqual(aplicarVentana(9999, 128, 256), 255); // clamp por arriba
  ok('Fórmula de windowing (center=128,width=256): x=0→0, x=128→~128, x=255→255, clamps correctos');
} catch (e) { fail('Fórmula de windowing: ' + e.message); }

// --- B) CRC32 contra el vector de referencia estándar de la especificación PNG ---
try {
  const resultado = crc32(Buffer.from('123456789', 'ascii'));
  assert.strictEqual(resultado, 0xcbf43926);
  ok(`CRC32("123456789") = 0x${resultado.toString(16)} — coincide con el vector de referencia estándar`);
} catch (e) { fail('CRC32: ' + e.message); }

function httpGetBinary(url) {
  return new Promise((resolve, reject) => {
    http.get(url, (res) => { const chunks = []; res.on('data', (c) => chunks.push(c)); res.on('end', () => resolve({ status: res.statusCode, body: Buffer.concat(chunks) })); }).on('error', reject);
  });
}

async function main() {
  const WORKDIR = path.join(__dirname, '.tmp-render-test');
  fs.rmSync(WORKDIR, { recursive: true, force: true });
  fs.mkdirSync(WORKDIR, { recursive: true });
  const ALMACEN = path.join(WORKDIR, 'almacen');
  fs.mkdirSync(ALMACEN, { recursive: true });

  // --- C) Imagen sintética 8x8, 16 bits, patrón conocido: pixel(i) = i * 100 ---
  const W = 8, H = 8, TOTAL = W * H;
  const pixelBuf = Buffer.alloc(TOTAL * 2);
  for (let i = 0; i < TOTAL; i++) pixelBuf.writeUInt16LE(i * 100, i * 2); // 0, 100, 200, ..., 6300

  const CENTER = 3150, WIDTH = 6300; // a propósito: abarca exacto el rango real de la imagen (0..6300)

  const sopInstanceUID = '1.2.826.0.1.3680043.99999.100';
  const studyInstanceUID = '1.2.826.0.1.3680043.99999.101';
  const seriesInstanceUID = '1.2.826.0.1.3680043.99999.102';
  const datasetBuf = ImplicitVR.encodeDataset([
    { tag: '00280004', vr: 'CS', value: 'MONOCHROME2' },
    { tag: '00280010', vr: 'US', value: H },
    { tag: '00280011', vr: 'US', value: W },
    { tag: '00280100', vr: 'US', value: 16 },
    { tag: '00280101', vr: 'US', value: 16 },
    { tag: '00280103', vr: 'US', value: 0 },
    { tag: '00281050', vr: 'DS', value: String(CENTER) },
    { tag: '00281051', vr: 'DS', value: String(WIDTH) },
    { tag: '0020000D', vr: 'UI', value: studyInstanceUID },
    { tag: '0020000E', vr: 'UI', value: seriesInstanceUID },
    { tag: '7fe00010', vr: 'OW', value: pixelBuf },
  ]);

  const parte10 = buildStoredFile({
    sopClassUID: '1.2.840.10008.5.1.4.1.1.7',
    sopInstanceUID,
    transferSyntaxUID: '1.2.840.10008.1.2',
    implementationClassUID: '1.2.840.99999.1.1',
    datasetBuf,
  });
  const archivoRelativo = sopInstanceUID.replace(/[^0-9.]/g, '_') + '.dcm';
  fs.writeFileSync(path.join(ALMACEN, archivoRelativo), parte10);

  // Indexar con el mismo extractTagsWithDcmjs que usa el C-STORE real (no un atajo de test)
  const lectura = extractTagsWithDcmjs(parte10);
  assert.ok(lectura.ok, 'extractTagsWithDcmjs debería poder leer esta imagen (dcmjs instalado)');
  assert.strictEqual(lectura.dataset.studyInstanceUID, studyInstanceUID, 'el Study Instance UID extraído debería ser el mismo que se escribió');
  assert.strictEqual(lectura.dataset.seriesInstanceUID, seriesInstanceUID, 'el Series Instance UID extraído debería ser el mismo que se escribió');
  StudyIndex.indexarInstancia({ archivoRelativo, sopInstanceUID, tags: lectura.dataset }, path.join(ALMACEN, '.study-index.json'));
  ok(`Imagen sintética 8x8/16-bit guardada e indexada bajo el Study/Series Instance UID reales (confirmados, no "DESCONOCIDO")`);

  const httpServer = http.createServer(DicomWebServer.crearHandler({ almacenPath: ALMACEN }));
  await new Promise((resolve) => httpServer.listen(0, resolve));
  const port = httpServer.address().port;

  const { status, body } = await httpGetBinary(`http://127.0.0.1:${port}/studies/${lectura.dataset.studyInstanceUID}/series/${lectura.dataset.seriesInstanceUID}/instances/${sopInstanceUID}/rendered`);
  if (status === 200) ok('WADO-RS /rendered respondió 200');
  else { fail('WADO-RS /rendered respondió ' + status + ': ' + body.toString()); return finalizar(); }

  const firmaValida = body.slice(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]));
  if (firmaValida) ok('Los bytes devueltos empiezan con la firma PNG correcta');
  else fail('Firma PNG inválida en la respuesta');

  // Decodificado por una librería PNG independiente (pngjs) — no por mi propio código
  const png = PNG.sync.read(body);
  if (png.width === W && png.height === H) ok(`pngjs decodificó el PNG correctamente: ${png.width}x${png.height} (esperado ${W}x${H})`);
  else fail(`Dimensiones incorrectas: ${png.width}x${png.height}, esperado ${W}x${H}`);

  // pngjs decodifica siempre a RGBA — para escala de grises R=G=B y A=255; comparamos el canal R contra lo esperado
  let coincideTodo = true;
  const primerosPixeles = [];
  for (let i = 0; i < TOTAL; i++) {
    const valorOriginal = i * 100;
    const esperado = Math.round(Math.max(0, Math.min(255, aplicarVentana(valorOriginal, CENTER, WIDTH))));
    const r = png.data[i * 4];
    const g = png.data[i * 4 + 1];
    const b = png.data[i * 4 + 2];
    const a = png.data[i * 4 + 3];
    if (r !== esperado || g !== esperado || b !== esperado || a !== 255) coincideTodo = false;
    if (i < 4 || i === TOTAL - 1) primerosPixeles.push(`px[${i}] original=${valorOriginal} esperado=${esperado} decodificado=${r}`);
  }
  if (coincideTodo) ok(`Los ${TOTAL} píxeles decodificados coinciden EXACTO con el windowing esperado (ej: ${primerosPixeles.join(' | ')})`);
  else fail('Al menos un píxel no coincide con lo esperado — ver detalle: ' + primerosPixeles.join(' | '));

  // --- D) Puerta etiquetada: una instancia a color debe responder 422 con el motivo, no 500 ni una imagen incorrecta ---
  const sopColor = '1.2.826.0.1.3680043.99999.200';
  const datasetColor = ImplicitVR.encodeDataset([
    { tag: '00280004', vr: 'CS', value: 'RGB' },
    { tag: '00280010', vr: 'US', value: 2 },
    { tag: '00280011', vr: 'US', value: 2 },
    { tag: '00280100', vr: 'US', value: 8 },
    { tag: '0020000D', vr: 'UI', value: studyInstanceUID },
    { tag: '0020000E', vr: 'UI', value: seriesInstanceUID },
    { tag: '7fe00010', vr: 'OW', value: Buffer.alloc(12) },
  ]);
  const parte10Color = buildStoredFile({ sopClassUID: '1.2.840.10008.5.1.4.1.1.7', sopInstanceUID: sopColor, transferSyntaxUID: '1.2.840.10008.1.2', implementationClassUID: '1.2.840.99999.1.1', datasetBuf: datasetColor });
  const archivoColor = sopColor.replace(/[^0-9.]/g, '_') + '.dcm';
  fs.writeFileSync(path.join(ALMACEN, archivoColor), parte10Color);
  const lecturaColor = extractTagsWithDcmjs(parte10Color);
  StudyIndex.indexarInstancia({ archivoRelativo: archivoColor, sopInstanceUID: sopColor, tags: lecturaColor.dataset }, path.join(ALMACEN, '.study-index.json'));

  const respuestaColor = await httpGetBinary(`http://127.0.0.1:${port}/studies/${studyInstanceUID}/series/${seriesInstanceUID}/instances/${sopColor}/rendered`);
  if (respuestaColor.status === 422 && /RGB|no soportad/i.test(respuestaColor.body.toString())) {
    ok(`Imagen RGB: 422 con el motivo explícito ("${JSON.parse(respuestaColor.body).error}") — no 500, no una imagen inventada`);
  } else {
    fail(`Imagen RGB: se esperaba 422 con motivo, llegó ${respuestaColor.status}: ${respuestaColor.body.toString()}`);
  }

  await finalizar();

  async function finalizar() {
    httpServer.close();
    fs.rmSync(WORKDIR, { recursive: true, force: true });
    console.log(`\n=== RESULTADO /rendered: ${process.exitCode ? 'HAY FALLAS ARRIBA' : 'TODO PASÓ'} ===`);
    process.exit(process.exitCode || 0);
  }
}

main().catch((e) => { console.error('ERROR FATAL:', e); process.exit(1); });
