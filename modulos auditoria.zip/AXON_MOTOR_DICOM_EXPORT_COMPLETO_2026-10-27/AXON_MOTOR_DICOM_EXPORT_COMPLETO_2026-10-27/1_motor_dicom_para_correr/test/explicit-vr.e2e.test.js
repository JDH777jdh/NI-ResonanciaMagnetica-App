'use strict';
/**
 * explicit-vr.e2e.test.js — verifica ExplicitVrCodec.js en 3 niveles:
 *   A) Round-trip propio (encode->decode) para VRs planos, binarios y SQ con
 *      longitud definida.
 *   B) Un buffer armado a mano con longitud INDEFINIDA (Item Delimitation +
 *      Sequence Delimitation reales) — el codec propio nunca genera esto, así
 *      que se prueba aparte, a mano, para no probar el decoder contra sí mismo.
 *   C) Los archivos DICOM reales (CT_small.dcm, MR_small.dcm de pydicom) —
 *      decodificando File Meta + dataset completo con ESTE codec, sin dcmjs,
 *      y comparando contra los valores ya confirmados en sesiones anteriores.
 */
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const Explicit = require(path.join(__dirname, '..', 'src', 'pdu', 'ExplicitVrCodec'));

let paso = 0;
function ok(desc) { paso++; console.log(`OK  [${paso}] ${desc}`); }
function fail(desc) { paso++; console.log(`FAIL[${paso}] ${desc}`); process.exitCode = 1; }

// ───────────────── A) Round-trip propio ─────────────────
try {
  const original = [
    { tag: '00080060', vr: 'CS', value: 'CT' },
    { tag: '00100010', vr: 'PN', value: 'PRUEBA^EXPLICIT' },
    { tag: '00280010', vr: 'US', value: 128 },
    { tag: '00280011', vr: 'US', value: 128 },
    { tag: '7fe00010', vr: 'OW', value: Buffer.from([1, 2, 3, 4, 5, 6, 7, 8]) },
    {
      tag: '00400100', vr: 'SQ', value: [[
        { tag: '00400001', vr: 'AE', value: 'CT_SALA1' },
        { tag: '00080060', vr: 'CS', value: 'CT' },
      ]],
    },
  ];
  const buf = Explicit.encodeDataset(original);
  const decoded = Explicit.decodeDataset(buf);
  assert.strictEqual(decoded.find((e) => e.tag === '00080060').value, 'CT');
  assert.strictEqual(decoded.find((e) => e.tag === '00100010').value, 'PRUEBA^EXPLICIT');
  assert.strictEqual(decoded.find((e) => e.tag === '00280010').vr, 'US');
  assert.strictEqual(Buffer.compare(decoded.find((e) => e.tag === '7fe00010').value, Buffer.from([1, 2, 3, 4, 5, 6, 7, 8])), 0);
  const sq = decoded.find((e) => e.tag === '00400100');
  assert.strictEqual(sq.vr, 'SQ');
  assert.strictEqual(sq.value[0].find((e) => e.tag === '00400001').value, 'CT_SALA1');
  ok('Round-trip propio: VRs planos, binario (Pixel Data) y SQ con longitud definida — todos coinciden exacto');
} catch (e) { fail('Round-trip propio: ' + e.message); }

// US como número real, no como texto (el mismo bug que encontramos en ImplicitVrCodec)
try {
  const buf = Explicit.encodeDataset([{ tag: '00280010', vr: 'US', value: 512 }]);
  // US es "forma corta": Group(2)+Element(2)+VR(2)+Longitud(2) = 8 bytes de cabecera, luego 2 bytes de valor = 10 total
  assert.strictEqual(buf.length, 10);
  assert.strictEqual(buf.readUInt16LE(8), 512); // el valor debe ser el entero binario 512, no "512" en ASCII
  ok('US se codifica como entero binario real (2 bytes), no como texto — mismo chequeo que encontramos roto en Implicit VR');
} catch (e) { fail('US binario: ' + e.message); }

// ───────────────── B) Longitud indefinida, armado a mano ─────────────────
try {
  // Una SQ (0040,0100) con longitud INDEFINIDA, conteniendo UN item también de
  // longitud indefinida, que a su vez tiene 2 elementos simples adentro.
  // Armado byte a byte, a propósito, para no probar el decoder contra su propio encoder.
  const parts = [];
  function u16le(n) { const b = Buffer.alloc(2); b.writeUInt16LE(n, 0); return b; }
  function u32le(n) { const b = Buffer.alloc(4); b.writeUInt32LE(n, 0); return b; }

  // --- contenido del item: (0040,0001) AE "CT_SALA1" + (0008,0060) CS "CT" ---
  const aeVal = Buffer.from('CT_SALA1', 'ascii'); // 8 bytes, ya par
  const itemContenido = Buffer.concat([
    u16le(0x0040), u16le(0x0001), Buffer.from('AE', 'ascii'), u16le(aeVal.length), aeVal,
    u16le(0x0008), u16le(0x0060), Buffer.from('CS', 'ascii'), u16le(2), Buffer.from('CT', 'ascii'),
  ]);

  // --- Item (FFFE,E000) con longitud INDEFINIDA (0xFFFFFFFF) envolviendo lo anterior,
  //     cerrado con Item Delimitation (FFFE,E00D) longitud 0 ---
  const item = Buffer.concat([
    u16le(0xfffe), u16le(0xe000), u32le(0xffffffff),
    itemContenido,
    u16le(0xfffe), u16le(0xe00d), u32le(0x00000000),
  ]);

  // --- la SQ misma (0040,0100), forma larga, longitud INDEFINIDA, cerrada con
  //     Sequence Delimitation (FFFE,E0DD) longitud 0 ---
  const sqBuf = Buffer.concat([
    u16le(0x0040), u16le(0x0100), Buffer.from('SQ', 'ascii'), u16le(0x0000), u32le(0xffffffff),
    item,
    u16le(0xfffe), u16le(0xe0dd), u32le(0x00000000),
  ]);

  const decoded = Explicit.decodeDataset(sqBuf);
  assert.strictEqual(decoded.length, 1);
  assert.strictEqual(decoded[0].vr, 'SQ');
  assert.strictEqual(decoded[0].value.length, 1);
  assert.strictEqual(decoded[0].value[0].find((e) => e.tag === '00400001').value, 'CT_SALA1');
  assert.strictEqual(decoded[0].value[0].find((e) => e.tag === '00080060').value, 'CT');
  ok('Secuencia con LONGITUD INDEFINIDA (Item Delimitation + Sequence Delimitation reales, armados a mano): decodificada correctamente');
} catch (e) { fail('Longitud indefinida: ' + e.message); }

// ───────────────── C) Archivos DICOM reales completos ─────────────────
function decodificarArchivoCompleto(rutaArchivo) {
  const buf = fs.readFileSync(rutaArchivo);
  // preámbulo (128 bytes) + "DICM" (4 bytes) -> ahí empieza File Meta, que SIEMPRE es Explicit VR LE
  let o = 132;
  const fileMetaElementos = [];
  // (0002,0000) File Meta Information Group Length, UL, forma corta -> primeros 12 bytes
  const primerElemento = Explicit.decodeElementAt(buf, o);
  assert.strictEqual(primerElemento.tag, '00020000', 'El primer elemento del File Meta debería ser el Group Length (0002,0000)');
  const groupLength = primerElemento.value; // VR=UL -> ya viene como número real
  const finDeFileMeta = primerElemento.nextOffset + groupLength;
  o = primerElemento.nextOffset;
  while (o < finDeFileMeta) {
    const el = Explicit.decodeElementAt(buf, o);
    fileMetaElementos.push(el);
    o = el.nextOffset;
  }
  const transferSyntaxUID = fileMetaElementos.find((e) => e.tag === '00020010').value.replace(/\0+$/, '');
  assert.strictEqual(transferSyntaxUID, '1.2.840.10008.1.2.1', 'Se esperaba Explicit VR LE');

  // el dataset principal empieza justo después del File Meta, y ya confirmamos que es Explicit VR LE también
  const datasetBuf = buf.slice(finDeFileMeta);
  const dataset = Explicit.decodeDataset(datasetBuf);
  return dataset;
}

try {
  const ct = decodificarArchivoCompleto(path.join(__dirname, 'fixtures', 'CT_small.dcm'));
  const rows = ct.find((e) => e.tag === '00280010');
  const cols = ct.find((e) => e.tag === '00280011');
  const modalidad = ct.find((e) => e.tag === '00080060');
  assert.strictEqual(rows.value, 128);
  assert.strictEqual(cols.value, 128);
  assert.strictEqual(modalidad.value, 'CT');
  ok(`CT_small.dcm REAL decodificado con ExplicitVrCodec propio (sin dcmjs): Rows=128, Columns=128, Modality=CT — coincide exacto con lo ya confirmado`);
} catch (e) { fail('CT_small.dcm real: ' + e.message); }

try {
  const mr = decodificarArchivoCompleto(path.join(__dirname, 'fixtures', 'MR_small.dcm'));
  const rows = mr.find((e) => e.tag === '00280010');
  const cols = mr.find((e) => e.tag === '00280011');
  const modalidad = mr.find((e) => e.tag === '00080060');
  assert.strictEqual(rows.value, 64);
  assert.strictEqual(cols.value, 64);
  assert.strictEqual(modalidad.value, 'MR');
  ok(`MR_small.dcm REAL decodificado con ExplicitVrCodec propio (sin dcmjs): Rows=64, Columns=64, Modality=MR — coincide exacto`);
} catch (e) { fail('MR_small.dcm real: ' + e.message); }

console.log(`\n=== RESULTADO ExplicitVrCodec: ${process.exitCode ? 'HAY FALLAS ARRIBA' : 'TODO PASÓ'} ===`);
process.exit(process.exitCode || 0);
