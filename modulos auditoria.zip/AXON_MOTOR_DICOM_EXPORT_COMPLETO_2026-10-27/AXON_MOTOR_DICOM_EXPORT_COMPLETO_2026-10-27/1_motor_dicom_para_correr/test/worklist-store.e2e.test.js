'use strict';
/**
 * worklist-store.e2e.test.js — prueba el primer tramo real del "flujo
 * RIS→PACS de punta a punta" (26-ago-2026).
 *
 * Hasta esta sesión, el ciclo completo (paciente en Worklist → equipo lo ve
 * por MWL → equipo manda C-STORE → paciente pasa a "Almacenado") vivía como
 * DOS simulaciones separadas que nunca se tocaban entre sí:
 *   - Lado UI: guardarYEnviar() en HIS-RIS-PACS.jsx fingía con un
 *     setTimeout(1400ms) que "llegó" el C-STORE del equipo.
 *   - Lado motor: worklistProvider, en los 5 tests existentes y en
 *     cualquier uso real hasta hoy, siempre devolvía un array hardcodeado —
 *     nunca leía datos reales de ningún lado.
 *
 * Este test prueba que ya no hace falta ninguna de las dos simulaciones:
 *   1. Un registro real entra a WorklistStore (equivalente a "un paciente
 *      completó Admisión y está en la pestaña Worklist").
 *   2. Un equipo (SCU) simulado se asocia SIN que nadie le pase un
 *      worklistProvider de prueba — usa el default real de
 *      AssociationServer.js — y hace C-FIND: debe recibir exactamente ese
 *      registro, con los tags correctos.
 *   3. El mismo equipo manda C-STORE de una imagen, con el mismo Accession
 *      Number que vio en el MWL (así es como un equipo real amarra la
 *      imagen con la orden, PS3.4).
 *   4. Se verifica, leyendo el store directo (no la red), que el registro
 *      quedó en fase "examenes"/estado "almacenado" — sin ningún timer de
 *      por medio, es una consecuencia real y directa del C-STORE.
 *   5. Un segundo C-FIND confirma que el registro ya NO aparece en el
 *      Worklist (coherencia de punta a punta, no solo "se puso una bandera").
 */
const assert = require('assert');
const net = require('net');
const path = require('path');
const fs = require('fs');

const SRC = path.join(__dirname, '..', 'src');
const PDU = require(path.join(SRC, 'pdu', 'PDU'));
const DIMSE = require(path.join(SRC, 'pdu', 'DimseCommand'));
const ImplicitVR = require(path.join(SRC, 'pdu', 'ImplicitVrCodec'));
const WorklistStore = require(path.join(SRC, 'storage', 'WorklistStore'));
const { iniciarServidor, MODALITY_WORKLIST_SOP_CLASS, VERIFICATION_SOP_CLASS } = require(path.join(SRC, 'server', 'AssociationServer'));

let paso = 0;
function ok(desc) { paso++; console.log(`OK  [${paso}] ${desc}`); }
function fail(desc) { paso++; console.log(`FAIL[${paso}] ${desc}`); process.exitCode = 1; }

// Mismo decoder mínimo de A-ASSOCIATE-AC que usan engine.e2e.test.js y
// real-dicom-explicit-vr.e2e.test.js — PDU.js todavía no expone uno (gap
// documentado desde la Adenda del 20-jul-2026, no es nuevo de este test).
function decodeAssociateAC(buf) {
  let o = 6; o += 2; o += 2; o += 16; o += 16; o += 32;
  const results = [];
  while (o < buf.length) {
    const t = buf.readUInt8(o); const l = buf.readUInt16BE(o + 2);
    const body = buf.slice(o + 4, o + 4 + l);
    if (t === 0x21) results.push({ id: body.readUInt8(0), accepted: body.readUInt8(2) === 0 });
    o += 4 + l;
  }
  return { results };
}

async function main() {
  const WORKDIR = path.join(__dirname, '.tmp-worklist-store-test');
  fs.rmSync(WORKDIR, { recursive: true, force: true });
  fs.mkdirSync(WORKDIR, { recursive: true });
  const ALMACEN = path.join(WORKDIR, 'almacen');
  const WORKLIST_STORE_PATH = path.join(ALMACEN, '.worklist-store.json'); // misma derivación que el default real de AssociationHandler

  // --- 1) Paciente real entra al Worklist (equivalente a "completó Admisión") ---
  // ACC de 12 caracteres a propósito: cabe en SH (máx 16, PS3.5) — el
  // formato real makeACC() de HIS-RIS-PACS.jsx ("ACC-2026-00000001", 17
  // caracteres) EXCEDE ese máximo; es un hallazgo aparte, documentado en el
  // dossier, no algo que este test deba reproducir ni silenciar.
  const registroSembrado = WorklistStore.agregar({
    nombre: 'PRUEBA^WORKLISTSTORE',
    cup: 'CUP-CL-13-2026-00009001-Z9',
    acc: 'ACC00000099',
    ot: 'OT000099',
    fechaAAAAMMDD: '20260826',
    horaHHMM: '0930',
    modalidad: 'CT',
    estudio: 'TC DE TORAX CON CONTRASTE',
  }, WORKLIST_STORE_PATH);
  ok(`Registro sembrado en WorklistStore real (fase=${registroSembrado.fase}, acc=${registroSembrado.acc}), archivo en disco: ${fs.existsSync(WORKLIST_STORE_PATH)}`);

  // --- 2) Arranca el servidor SIN worklistProvider de prueba — usa el default real ---
  const server = iniciarServidor({ port: 0, almacenPath: ALMACEN, tlsOptions: null }); // sin worklistProvider a propósito
  await new Promise((r) => server.once('listening', r));
  const PORT = server.address().port;

  const socket = net.connect(PORT, '127.0.0.1');
  await new Promise((res, rej) => { socket.once('connect', res); socket.once('error', rej); });

  let buffer = Buffer.alloc(0); const pduQueue = []; const waiters = [];
  socket.on('data', (chunk) => {
    buffer = Buffer.concat([buffer, chunk]);
    let header;
    while ((header = PDU.peekPduHeader(buffer)) && buffer.length >= header.totalSize) {
      const pdu = buffer.slice(0, header.totalSize); buffer = buffer.slice(header.totalSize);
      if (waiters.length) waiters.shift()(pdu); else pduQueue.push(pdu);
    }
  });
  function nextPdu(t = 3000) { return new Promise((res, rej) => { if (pduQueue.length) return res(pduQueue.shift()); const tm = setTimeout(() => rej(new Error('timeout')), t); waiters.push((p) => { clearTimeout(tm); res(p); }); }); }

  const rq = PDU.encodeAssociateRQ({
    calledAE: 'AXON_RIS', callingAE: 'CT_SALA1', // AE Title ya sembrado en AeRegistry (SEED_EQUIPOS)
    presentationContexts: [
      { id: 1, abstractSyntax: VERIFICATION_SOP_CLASS, transferSyntaxes: ['1.2.840.10008.1.2'] },
      { id: 3, abstractSyntax: MODALITY_WORKLIST_SOP_CLASS, transferSyntaxes: ['1.2.840.10008.1.2'] },
      { id: 5, abstractSyntax: '1.2.840.10008.5.1.4.1.1.2', transferSyntaxes: ['1.2.840.10008.1.2'] }, // CT Storage
    ],
    maxPduLength: 16384, implementationClassUID: '1.2.840.99999.1.1',
  });
  socket.write(rq);
  const ac = decodeAssociateAC(await nextPdu());
  if (ac.results.every((r) => r.accepted)) ok('A-ASSOCIATE-AC: Echo + MWL + Storage(CT) aceptados');
  else fail('Algún Presentation Context no fue aceptado: ' + JSON.stringify(ac.results));

  // --- 3) C-FIND real al Worklist — SIN worklistProvider de prueba de por medio ---
  socket.write(PDU.encodePDataTF([{ presentationContextId: 3, isCommand: true, isLast: true, data: DIMSE.encodeCommandSet({ '00000002': MODALITY_WORKLIST_SOP_CLASS, '00000100': DIMSE.COMMAND_FIELD.C_FIND_RQ, '00000110': 1, '00000800': 0x0101 }) }]));
  let pendientesRecibidos = [];
  while (true) {
    const pdvs = PDU.decodePDataTF(await nextPdu());
    const cmd = DIMSE.decodeCommandSet(pdvs.find((p) => p.isCommand).data);
    const dsPdv = pdvs.find((p) => !p.isCommand);
    if (cmd['00000900'] === DIMSE.STATUS.PENDING) {
      if (dsPdv) pendientesRecibidos.push(ImplicitVR.decodeDataset(dsPdv.data, { '00400100': true }));
    } else if (cmd['00000900'] === DIMSE.STATUS.SUCCESS) break;
  }
  if (pendientesRecibidos.length === 1) ok('C-FIND real (sin worklistProvider de prueba): devolvió exactamente 1 pendiente — el que sembramos en WorklistStore, no un array hardcodeado');
  else fail(`C-FIND real: se esperaba 1 pendiente, llegaron ${pendientesRecibidos.length}`);

  const ds0 = pendientesRecibidos[0] || [];
  const accRecibido = ds0.find((e) => e.tag === '00080050')?.value?.trim();
  const nombreRecibido = ds0.find((e) => e.tag === '00100010')?.value?.trim();
  if (accRecibido === registroSembrado.acc && nombreRecibido === registroSembrado.nombre) {
    ok(`El registro que llegó por DIMSE coincide exacto con el sembrado: ACC=${accRecibido}, Nombre=${nombreRecibido}`);
  } else {
    fail(`Datos no coinciden: ACC recibido="${accRecibido}" (esperado "${registroSembrado.acc}"), Nombre recibido="${nombreRecibido}"`);
  }

  // --- 4) El equipo hace C-STORE real, copiando el MISMO Accession Number que vio en el MWL ---
  const sopInstanceUID = '1.2.826.0.1.3680043.99999.9001';
  const studyInstanceUID = '1.2.826.0.1.3680043.99999.9002';
  const datasetImagen = ImplicitVR.encodeDataset([
    { tag: '00100010', vr: 'PN', value: registroSembrado.nombre },
    { tag: '00100020', vr: 'LO', value: registroSembrado.cup },
    { tag: '00080050', vr: 'SH', value: registroSembrado.acc }, // el vínculo real con la orden — PS3.4
    { tag: '00080060', vr: 'CS', value: 'CT' },
    { tag: '0020000D', vr: 'UI', value: studyInstanceUID },
    { tag: '0020000E', vr: 'UI', value: '1.2.826.0.1.3680043.99999.9003' },
    { tag: '7fe00010', vr: 'OW', value: Buffer.from([10, 20, 30, 40, 50, 60, 70, 80]) },
  ]);
  socket.write(PDU.encodePDataTF([
    { presentationContextId: 5, isCommand: true, isLast: true, data: DIMSE.encodeCommandSet({ '00000002': '1.2.840.10008.5.1.4.1.1.2', '00000100': DIMSE.COMMAND_FIELD.C_STORE_RQ, '00000110': 2, '00000700': 0, '00000800': 0x0102, '00001000': sopInstanceUID }) },
    { presentationContextId: 5, isCommand: false, isLast: true, data: datasetImagen },
  ]));
  const storeRsp = DIMSE.decodeCommandSet(PDU.decodePDataTF(await nextPdu())[0].data);
  if (storeRsp['00000900'] === DIMSE.STATUS.SUCCESS) ok('C-STORE-RSP: Status SUCCESS');
  else fail('C-STORE-RSP con status inesperado: 0x' + (storeRsp['00000900'] || 0).toString(16));

  // Le da un instante al handler async de dcmjs (extractTagsWithDcmjs es síncrono
  // en la práctica, pero se espera un tick igual para no asumir de más sobre timing interno).
  await new Promise((r) => setTimeout(r, 150));

  // --- 5) Verificación directa contra el store — sin red, sin timers, sin adivinar ---
  const registroFinal = WorklistStore.buscarPorAcc(registroSembrado.acc, WORKLIST_STORE_PATH);
  if (registroFinal && registroFinal.fase === 'examenes' && registroFinal.estado === 'almacenado') {
    ok(`WorklistStore actualizado SOLO por el C-STORE real: fase="${registroFinal.fase}", estado="${registroFinal.estado}" — sin ningún setTimeout de por medio, esto es lo que reemplaza a guardarYEnviar() simulado`);
  } else {
    fail(`El registro no quedó marcado como Almacenado: ${JSON.stringify(registroFinal)}`);
  }

  // --- 6) Coherencia de punta a punta: un segundo C-FIND ya NO debe traer este registro ---
  socket.write(PDU.encodePDataTF([{ presentationContextId: 3, isCommand: true, isLast: true, data: DIMSE.encodeCommandSet({ '00000002': MODALITY_WORKLIST_SOP_CLASS, '00000100': DIMSE.COMMAND_FIELD.C_FIND_RQ, '00000110': 3, '00000800': 0x0101 }) }]));
  let segundosPendientes = 0;
  while (true) {
    const pdvs = PDU.decodePDataTF(await nextPdu());
    const cmd = DIMSE.decodeCommandSet(pdvs.find((p) => p.isCommand).data);
    if (cmd['00000900'] === DIMSE.STATUS.PENDING) segundosPendientes++;
    else if (cmd['00000900'] === DIMSE.STATUS.SUCCESS) break;
  }
  if (segundosPendientes === 0) ok('Segundo C-FIND: el registro ya NO aparece en el Worklist (pasó a fase "examenes") — coherencia real de punta a punta, no solo una bandera aislada');
  else fail(`Segundo C-FIND: todavía aparecen ${segundosPendientes} pendiente(s) — el registro no debería seguir en el Worklist`);

  socket.write(PDU.encodeReleaseRQ());
  await nextPdu();
  socket.end();
  server.close();
  fs.rmSync(WORKDIR, { recursive: true, force: true });
  console.log(`\n=== RESULTADO WorklistStore: ${process.exitCode ? 'HAY FALLAS ARRIBA' : 'TODO PASÓ — flujo Worklist→MWL real→C-STORE real→Almacenado, sin ninguna simulación de por medio'} ===`);
  process.exit(process.exitCode || 0);
}

main().catch((e) => { console.error('ERROR FATAL:', e); process.exit(1); });
