'use strict';
/**
 * engine.e2e.test.js — primer test end-to-end real y versionado del motor.
 *
 * Escrito y ejecutado el 20-jul-2026 para verificar de cero (sin asumir nada
 * de sesiones anteriores) que el ciclo completo funciona: un equipo (SCU)
 * simulado se asocia, hace C-ECHO, consulta el Modality Worklist (con la
 * Scheduled Procedure Step Sequence realmente anidada), hace C-STORE de una
 * imagen sintética, y esa misma imagen queda recuperable por DICOMweb
 * (QIDO-RS/WADO-RS) — sin pasar por ningún PACS de terceros.
 *
 * Uso: `npm test` desde dicom-engine/, o `node test/engine.e2e.test.js`.
 * Sin dependencias de test framework a propósito (0 dependencias nuevas) —
 * usa `assert` nativo de Node.
 */
const assert = require('assert');
const net = require('net');
const path = require('path');
const fs = require('fs');
const http = require('http');

const SRC = path.join(__dirname, '..', 'src');
const PDU = require(path.join(SRC, 'pdu', 'PDU'));
const DIMSE = require(path.join(SRC, 'pdu', 'DimseCommand'));
const ImplicitVR = require(path.join(SRC, 'pdu', 'ImplicitVrCodec'));
const { iniciarServidor, MODALITY_WORKLIST_SOP_CLASS, VERIFICATION_SOP_CLASS } = require(path.join(SRC, 'server', 'AssociationServer'));
const DicomWebServer = require(path.join(SRC, 'server', 'DicomWebServer'));

let paso = 0;
function ok(desc) { paso++; console.log(`OK  [${paso}] ${desc}`); }
function fail(desc) { paso++; console.log(`FAIL[${paso}] ${desc}`); process.exitCode = 1; }

// decodeAssociateAC no está expuesto por PDU.js todavía (hoy el motor solo necesita
// decodificar RQ y codificar AC, porque solo actúa como SCP). Se replica acá,
// solo para que este test pueda leer la respuesta del servidor como lo haría un SCU real.
function decodeAssociateAC(buf) {
  let o = 6; o += 2; o += 2;
  o += 16; o += 16; // calledAE, callingAE (no se usan en este test)
  o += 32;
  const results = [];
  while (o < buf.length) {
    const itemType = buf.readUInt8(o);
    const itemLen = buf.readUInt16BE(o + 2);
    const itemBody = buf.slice(o + 4, o + 4 + itemLen);
    if (itemType === 0x21) {
      const pcId = itemBody.readUInt8(0);
      const resultByte = itemBody.readUInt8(2);
      let transferSyntax = null;
      if (itemBody.length > 4) {
        const subLen = itemBody.readUInt16BE(4 + 2);
        transferSyntax = itemBody.slice(4 + 4, 4 + 4 + subLen).toString('ascii').replace(/\0+$/, '');
      }
      results.push({ id: pcId, accepted: resultByte === 0, transferSyntax });
    }
    o += 4 + itemLen;
  }
  return { results };
}

function httpGetText(url) {
  return new Promise((resolve, reject) => {
    http.get(url, (res) => { let d = ''; res.on('data', (c) => (d += c)); res.on('end', () => resolve(d)); }).on('error', reject);
  });
}
function httpGetBinary(url) {
  return new Promise((resolve, reject) => {
    http.get(url, (res) => { const chunks = []; res.on('data', (c) => chunks.push(c)); res.on('end', () => resolve(Buffer.concat(chunks))); }).on('error', reject);
  });
}

let dcmjsDisponible = true;
try { require('dcmjs'); } catch (e) { dcmjsDisponible = false; }

async function main() {
  const WORKDIR = path.join(__dirname, '.tmp-test-run');
  fs.rmSync(WORKDIR, { recursive: true, force: true });
  fs.mkdirSync(WORKDIR, { recursive: true });
  const ALMACEN = path.join(WORKDIR, 'almacen');

  const worklistFake = [
    { nombre: 'PRUEBA^SINTETICA', cup: 'CUP-CL-TARA-2026-00000001-7', acc: 'ACC00000001', ot: 'OT00000001', fechaAAAAMMDD: '20260720', horaHHMM: '0800', modalidad: 'CT', estudio: 'TC DE TORAX' },
  ];

  const server = iniciarServidor({ port: 0, almacenPath: ALMACEN, worklistProvider: () => worklistFake, tlsOptions: null });
  await new Promise((resolve) => server.once('listening', resolve));
  const PORT = server.address().port;

  const socket = net.connect(PORT, '127.0.0.1');
  await new Promise((resolve, reject) => { socket.once('connect', resolve); socket.once('error', reject); });
  ok('Conexión TCP establecida con AssociationServer');

  let buffer = Buffer.alloc(0);
  const pduQueue = []; const waiters = [];
  socket.on('data', (chunk) => {
    buffer = Buffer.concat([buffer, chunk]);
    let header;
    while ((header = PDU.peekPduHeader(buffer)) && buffer.length >= header.totalSize) {
      const pdu = buffer.slice(0, header.totalSize);
      buffer = buffer.slice(header.totalSize);
      if (waiters.length) waiters.shift()(pdu); else pduQueue.push(pdu);
    }
  });
  function nextPdu(timeoutMs = 3000) {
    return new Promise((resolve, reject) => {
      if (pduQueue.length) return resolve(pduQueue.shift());
      const t = setTimeout(() => reject(new Error('timeout esperando PDU')), timeoutMs);
      waiters.push((pdu) => { clearTimeout(t); resolve(pdu); });
    });
  }

  const rq = PDU.encodeAssociateRQ({
    calledAE: 'AXON_RIS', callingAE: 'CT_SALA1', // AE Title ya sembrado en AeRegistry (SEED_EQUIPOS)
    presentationContexts: [
      { id: 1, abstractSyntax: VERIFICATION_SOP_CLASS, transferSyntaxes: ['1.2.840.10008.1.2'] },
      { id: 3, abstractSyntax: MODALITY_WORKLIST_SOP_CLASS, transferSyntaxes: ['1.2.840.10008.1.2'] },
      { id: 5, abstractSyntax: '1.2.840.10008.5.1.4.1.1.7', transferSyntaxes: ['1.2.840.10008.1.2'] },
    ],
    maxPduLength: 16384, implementationClassUID: '1.2.840.99999.1.1',
  });
  socket.write(rq);
  const acPdu = await nextPdu();
  assert.strictEqual(acPdu.readUInt8(0), PDU.PDU_TYPE.A_ASSOCIATE_AC, 'Se esperaba A-ASSOCIATE-AC');
  const ac = decodeAssociateAC(acPdu);
  const [e1, e3, e5] = [1, 3, 5].map((id) => ac.results.find((r) => r.id === id));
  if (e1?.accepted && e3?.accepted && e5?.accepted) ok('A-ASSOCIATE-AC: Echo + MWL + Storage(OT) aceptados con Transfer Syntax negociado');
  else fail('A-ASSOCIATE-AC: no todos los contextos aceptados -> ' + JSON.stringify(ac.results));

  socket.write(PDU.encodePDataTF([{ presentationContextId: 1, isCommand: true, isLast: true, data: DIMSE.encodeCommandSet({ '00000002': VERIFICATION_SOP_CLASS, '00000100': DIMSE.COMMAND_FIELD.C_ECHO_RQ, '00000110': 1, '00000800': 0x0101 }) }]));
  const echoRsp = DIMSE.decodeCommandSet(PDU.decodePDataTF(await nextPdu())[0].data);
  if (echoRsp['00000900'] === DIMSE.STATUS.SUCCESS) ok('C-ECHO-RSP: Status SUCCESS');
  else fail('C-ECHO-RSP con status inesperado: 0x' + (echoRsp['00000900'] || 0).toString(16));

  socket.write(PDU.encodePDataTF([{ presentationContextId: 3, isCommand: true, isLast: true, data: DIMSE.encodeCommandSet({ '00000002': MODALITY_WORKLIST_SOP_CLASS, '00000100': DIMSE.COMMAND_FIELD.C_FIND_RQ, '00000110': 2, '00000800': 0x0101 }) }]));
  let pendientes = 0, sqAnidadaConfirmada = false;
  while (true) {
    const pdvs = PDU.decodePDataTF(await nextPdu());
    const cmd = DIMSE.decodeCommandSet(pdvs.find((p) => p.isCommand).data);
    const dsPdv = pdvs.find((p) => !p.isCommand);
    if (cmd['00000900'] === DIMSE.STATUS.PENDING) {
      pendientes++;
      if (dsPdv) {
        const dataset = ImplicitVR.decodeDataset(dsPdv.data, { '00400100': true });
        const sq = dataset.find((e) => e.tag === '00400100');
        const nested = sq && sq.vr === 'SQ' && sq.value[0];
        const modalidadNested = nested && nested.find((e) => e.tag === '00080060');
        if (modalidadNested && modalidadNested.value.trim() === 'CT') sqAnidadaConfirmada = true;
      }
    } else if (cmd['00000900'] === DIMSE.STATUS.SUCCESS) break;
  }
  if (pendientes === worklistFake.length) ok(`C-FIND-RSP: ${pendientes} Pending + 1 Success final`);
  else fail(`C-FIND-RSP: se esperaban ${worklistFake.length} Pending, llegaron ${pendientes}`);
  if (sqAnidadaConfirmada) ok('Scheduled Procedure Step Sequence (0040,0100) confirmada anidada de verdad (PS3.4 Anexo K)');
  else fail('La secuencia NO llegó anidada correctamente');

  const sopInstanceUID = '1.2.826.0.1.3680043.99999.1';
  const datasetFalso = ImplicitVR.encodeDataset([
    { tag: '00100010', vr: 'PN', value: 'PRUEBA^SINTETICA' },
    { tag: '0020000D', vr: 'UI', value: '1.2.826.0.1.3680043.99999.2' },
    { tag: '0020000E', vr: 'UI', value: '1.2.826.0.1.3680043.99999.3' },
    { tag: '00080060', vr: 'CS', value: 'OT' },
    { tag: '7fe00010', vr: 'OW', value: Buffer.from([0, 1, 2, 3, 4, 5, 6, 7]) },
  ]);
  socket.write(PDU.encodePDataTF([
    { presentationContextId: 5, isCommand: true, isLast: true, data: DIMSE.encodeCommandSet({ '00000002': '1.2.840.10008.5.1.4.1.1.7', '00000100': DIMSE.COMMAND_FIELD.C_STORE_RQ, '00000110': 3, '00000700': 0, '00000800': 0x0102, '00001000': sopInstanceUID }) },
    { presentationContextId: 5, isCommand: false, isLast: true, data: datasetFalso },
  ]));
  const storeRsp = DIMSE.decodeCommandSet(PDU.decodePDataTF(await nextPdu())[0].data);
  if (storeRsp['00000900'] === DIMSE.STATUS.SUCCESS) ok('C-STORE-RSP: Status SUCCESS');
  else fail('C-STORE-RSP con status inesperado');

  const rutaArchivo = path.join(ALMACEN, sopInstanceUID.replace(/[^0-9.]/g, '_') + '.dcm');
  if (fs.existsSync(rutaArchivo)) {
    const bytes = fs.readFileSync(rutaArchivo);
    const preambleOk = bytes.slice(0, 128).every((b) => b === 0) && bytes.slice(128, 132).toString('ascii') === 'DICM';
    if (preambleOk) ok(`Archivo Part10 válido en disco (${bytes.length} bytes): 128×0x00 + "DICM" confirmados`);
    else fail('Archivo escrito pero preámbulo/magic Part10 inválido');
  } else fail('No se encontró el archivo esperado: ' + rutaArchivo);

  const indicePath = path.join(ALMACEN, '.study-index.json');
  if (fs.existsSync(indicePath)) {
    const indice = JSON.parse(fs.readFileSync(indicePath, 'utf8'));
    const claves = Object.keys(indice.estudios || {});
    if (dcmjsDisponible) {
      if (claves[0] && claves[0] !== 'DESCONOCIDO') ok(`StudyIndex indexó bajo el Study Instance UID real (${claves[0]}) — dcmjs está parseando de verdad`);
      else fail('dcmjs está instalado pero el índice igual quedó en DESCONOCIDO — revisar extractTagsWithDcmjs');
    } else {
      if (claves[0] === 'DESCONOCIDO') ok('Sin dcmjs instalado: StudyIndex cae en modo degradado honesto (bucket "DESCONOCIDO") — comportamiento esperado, correr `npm install` para activar el parseo real');
      else fail('Comportamiento inesperado sin dcmjs: ' + claves.join(','));
    }
  }

  socket.write(PDU.encodeReleaseRQ());
  const relPdu = await nextPdu();
  if (relPdu.readUInt8(0) === PDU.PDU_TYPE.A_RELEASE_RP) ok('A-RELEASE-RQ/RP: cierre limpio de la asociación');
  else fail('No llegó A-RELEASE-RP');
  socket.end();

  const httpServer = http.createServer(DicomWebServer.crearHandler({ almacenPath: ALMACEN }));
  await new Promise((resolve) => httpServer.listen(0, resolve));
  const httpPort = httpServer.address().port;

  const estudios = JSON.parse(await httpGetText(`http://127.0.0.1:${httpPort}/studies`));
  if (Array.isArray(estudios) && estudios.length >= 1) ok(`QIDO-RS /studies devolvió ${estudios.length} estudio(s) — mismo almacén que llenó el C-STORE por DIMSE`);
  else fail('QIDO-RS /studies vacío o inválido');

  if (estudios[0]) {
    const studyUID = estudios[0]['0020000D'].Value[0];
    const series = JSON.parse(await httpGetText(`http://127.0.0.1:${httpPort}/studies/${studyUID}/series`));
    if (series.length >= 1) {
      ok(`QIDO-RS /series devolvió ${series.length} serie(s)`);
      const seriesUID = series[0]['0020000E'].Value[0];
      const instancias = JSON.parse(await httpGetText(`http://127.0.0.1:${httpPort}/studies/${studyUID}/series/${seriesUID}/instances`));
      const instUID = instancias[0]['00080018'].Value[0];
      const wadoBytes = await httpGetBinary(`http://127.0.0.1:${httpPort}/studies/${studyUID}/series/${seriesUID}/instances/${instUID}`);
      const original = fs.readFileSync(rutaArchivo);
      if (Buffer.compare(wadoBytes, original) === 0) ok('WADO-RS: bytes recuperados idénticos a los guardados — ciclo equipo→DIMSE→HTTP→navegador CONFIRMADO');
      else fail('WADO-RS devolvió bytes distintos a los guardados');
    } else fail('QIDO-RS /series vacío');
  }

  httpServer.close(); server.close();
  fs.rmSync(WORKDIR, { recursive: true, force: true });
  console.log(`\n=== RESULTADO: ${process.exitCode ? 'HAY FALLAS ARRIBA' : 'TODO PASÓ'} (dcmjs ${dcmjsDisponible ? 'instalado' : 'NO instalado'}) ===`);
  process.exit(process.exitCode || 0);
}

main().catch((e) => { console.error('ERROR FATAL:', e); process.exit(1); });
