'use strict';
/**
 * worklist-api.e2e.test.js — prueba WorklistApiServer.js en 2 niveles:
 *
 *   A) CRUD HTTP básico: POST/GET/PATCH contra el handler, sin DIMSE de por
 *      medio — confirma que la API en sí funciona.
 *
 *   B) La prueba que de verdad importa — integración real en AMBAS
 *      direcciones, contra un AssociationServer real corriendo en paralelo,
 *      apuntando al MISMO WorklistStore (mismo archivo en disco):
 *        - HTTP API escribe (POST) → DIMSE lo ve (C-FIND real lo trae)
 *        - DIMSE escribe (C-STORE real marca Almacenado) → HTTP API lo ve (GET)
 *      Si esto pasa, confirma que la API y el motor DIMSE comparten UNA
 *      sola fuente de verdad — no dos copias que se puedan desincronizar.
 */
const assert = require('assert');
const net = require('net');
const http = require('http');
const path = require('path');
const fs = require('fs');

const SRC = path.join(__dirname, '..', 'src');
const PDU = require(path.join(SRC, 'pdu', 'PDU'));
const DIMSE = require(path.join(SRC, 'pdu', 'DimseCommand'));
const ImplicitVR = require(path.join(SRC, 'pdu', 'ImplicitVrCodec'));
const WorklistApiServer = require(path.join(SRC, 'server', 'WorklistApiServer'));
const { iniciarServidor, MODALITY_WORKLIST_SOP_CLASS, VERIFICATION_SOP_CLASS } = require(path.join(SRC, 'server', 'AssociationServer'));

let paso = 0;
function ok(desc) { paso++; console.log(`OK  [${paso}] ${desc}`); }
function fail(desc) { paso++; console.log(`FAIL[${paso}] ${desc}`); process.exitCode = 1; }

function decodeAssociateAC(buf) {
  let o = 6; o += 2; o += 2; o += 16; o += 16; o += 32;
  const results = [];
  while (o < buf.length) {
    const t = buf.readUInt8(o); const l = buf.readUInt16BE(o + 2);
    const body = buf.slice(o + 4, o + 4 + l);
    if (t === 0x21) results.push({ id: body.readUInt8(0), accepted: body.readUInt8(2) === 0 });
    o += 4 + l;
  }
  return { results };
}

async function main() {
  const WORKDIR = path.join(__dirname, '.tmp-worklist-api-test');
  fs.rmSync(WORKDIR, { recursive: true, force: true });
  fs.mkdirSync(WORKDIR, { recursive: true });
  const ALMACEN = path.join(WORKDIR, 'almacen');
  const STORE_PATH = path.join(ALMACEN, '.worklist-store.json'); // misma derivación que el default real de AssociationHandler

  // ───────────── A) CRUD HTTP básico ─────────────
  const apiServer = http.createServer(WorklistApiServer.crearHandler({ storePath: STORE_PATH }));
  await new Promise((r) => apiServer.listen(0, r));
  const apiPort = apiServer.address().port;
  const API = `http://127.0.0.1:${apiPort}`;

  const resPost = await fetch(`${API}/worklist`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ nombre: 'PRUEBA^API', cup: 'CUP-CL-13-2026-00009002-B1', acc: 'ACC00000123', ot: 'OT000123', modalidad: 'MR', estudio: 'RM RODILLA DERECHA', fechaAAAAMMDD: '20260828', horaHHMM: '1000' }),
  });
  const creado = await resPost.json();
  if (resPost.status === 201 && creado.id && creado.fase === 'worklist' && creado.estado === 'arribado') {
    ok(`POST /worklist: 201, id generado (${creado.id}), defaults fase="worklist"/estado="arribado" aplicados`);
  } else fail(`POST /worklist: status=${resPost.status}, body=${JSON.stringify(creado)}`);

  const resList = await (await fetch(`${API}/worklist?fase=worklist`)).json();
  if (resList.length === 1 && resList[0].id === creado.id) ok('GET /worklist?fase=worklist: devuelve exactamente el registro creado');
  else fail(`GET /worklist?fase=worklist: se esperaba 1 registro, llegaron ${resList.length}`);

  const resGetUno = await fetch(`${API}/worklist/${creado.id}`);
  const uno = await resGetUno.json();
  if (resGetUno.status === 200 && uno.acc === 'ACC00000123') ok('GET /worklist/:id: devuelve el registro puntual correcto');
  else fail('GET /worklist/:id: no coincide — ' + JSON.stringify(uno));

  const resPatch = await fetch(`${API}/worklist/${creado.id}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ estado: 'en_proceso' }) });
  const parcheado = await resPatch.json();
  if (resPatch.status === 200 && parcheado.estado === 'en_proceso' && parcheado.nombre === 'PRUEBA^API') {
    ok('PATCH /worklist/:id: cambia estado sin tocar el resto de los campos');
  } else fail('PATCH /worklist/:id: ' + JSON.stringify(parcheado));

  const resBadPost = await fetch(`${API}/worklist`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ estudio: 'sin nombre ni modalidad' }) });
  if (resBadPost.status === 400) ok('POST /worklist sin campos obligatorios: 400 explícito, no acepta a medias');
  else fail('POST /worklist inválido: se esperaba 400, llegó ' + resBadPost.status);

  const res404 = await fetch(`${API}/worklist/no-existe`);
  if (res404.status === 404) ok('GET /worklist/:id inexistente: 404');
  else fail('Se esperaba 404, llegó ' + res404.status);

  // PUT /worklist/:id — upsert (26-ago-2026, para sembrar/resetear datos de demo sin duplicar)
  const idSemilla = 'seed_test_1';
  const resPut1 = await fetch(`${API}/worklist/${idSemilla}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ nombre: 'PRUEBA^SEMILLA', modalidad: 'RX', fase: 'agendados', estado: 'agendado' }) });
  const put1 = await resPut1.json();
  if (resPut1.status === 201 && put1.id === idSemilla) ok('PUT /worklist/:id (id nuevo): 201, crea el registro con el id exacto que se pidió');
  else fail('PUT /worklist/:id primera vez: ' + resPut1.status + ' ' + JSON.stringify(put1));

  const resPut2 = await fetch(`${API}/worklist/${idSemilla}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ nombre: 'PRUEBA^SEMILLA', modalidad: 'RX', fase: 'agendados', estado: 'agendado' }) });
  const put2 = await resPut2.json();
  const totalConEseId = (await (await fetch(`${API}/worklist`)).json()).filter((r) => r.id === idSemilla);
  if (resPut2.status === 200 && totalConEseId.length === 1) ok('PUT /worklist/:id (mismo id de nuevo): 200 (no 201), y sigue habiendo UN solo registro con ese id — no duplicó');
  else fail(`PUT /worklist/:id segunda vez: status=${resPut2.status}, registros con ese id=${totalConEseId.length}`);

  // ───────────── B) Integración real con DIMSE, en ambas direcciones ─────────────
  // Reset: dejamos el registro de arriba en estado limpio "worklist"/"arribado"
  // para la prueba de integración, sembrando uno nuevo dedicado.
  const resPost2 = await fetch(`${API}/worklist`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ nombre: 'PRUEBA^INTEGRACION', cup: 'CUP-CL-13-2026-00009003-C2', acc: 'ACC00000456', ot: 'OT000456', modalidad: 'CT', estudio: 'TC ABDOMEN Y PELVIS', fechaAAAAMMDD: '20260828', horaHHMM: '1100' }),
  });
  const registroIntegracion = await resPost2.json();

  const server = iniciarServidor({ port: 0, almacenPath: ALMACEN, tlsOptions: null }); // mismo ALMACEN → mismo .worklist-store.json que usa la API
  await new Promise((r) => server.once('listening', r));
  const PORT = server.address().port;
  const socket = net.connect(PORT, '127.0.0.1');
  await new Promise((res, rej) => { socket.once('connect', res); socket.once('error', rej); });

  let buffer = Buffer.alloc(0); const pduQueue = []; const waiters = [];
  socket.on('data', (chunk) => {
    buffer = Buffer.concat([buffer, chunk]);
    let header;
    while ((header = PDU.peekPduHeader(buffer)) && buffer.length >= header.totalSize) {
      const pdu = buffer.slice(0, header.totalSize); buffer = buffer.slice(header.totalSize);
      if (waiters.length) waiters.shift()(pdu); else pduQueue.push(pdu);
    }
  });
  function nextPdu(t = 3000) { return new Promise((res, rej) => { if (pduQueue.length) return res(pduQueue.shift()); const tm = setTimeout(() => rej(new Error('timeout')), t); waiters.push((p) => { clearTimeout(tm); res(p); }); }); }

  socket.write(PDU.encodeAssociateRQ({
    calledAE: 'AXON_RIS', callingAE: 'CT_SALA1',
    presentationContexts: [
      { id: 1, abstractSyntax: VERIFICATION_SOP_CLASS, transferSyntaxes: ['1.2.840.10008.1.2'] },
      { id: 3, abstractSyntax: MODALITY_WORKLIST_SOP_CLASS, transferSyntaxes: ['1.2.840.10008.1.2'] },
      { id: 5, abstractSyntax: '1.2.840.10008.5.1.4.1.1.2', transferSyntaxes: ['1.2.840.10008.1.2'] },
    ],
    maxPduLength: 16384, implementationClassUID: '1.2.840.99999.1.1',
  }));
  const ac = decodeAssociateAC(await nextPdu());
  if (ac.results.every((r) => r.accepted)) ok('Asociación DIMSE aceptada (servidor apuntando al mismo ALMACEN que la API HTTP)');
  else fail('Asociación rechazada: ' + JSON.stringify(ac.results));

  // B.1 — HTTP API escribió (arriba, resPost2) → ¿lo ve un C-FIND real?
  socket.write(PDU.encodePDataTF([{ presentationContextId: 3, isCommand: true, isLast: true, data: DIMSE.encodeCommandSet({ '00000002': MODALITY_WORKLIST_SOP_CLASS, '00000100': DIMSE.COMMAND_FIELD.C_FIND_RQ, '00000110': 1, '00000800': 0x0101 }) }]));
  let vistosPorDimse = [];
  while (true) {
    const pdvs = PDU.decodePDataTF(await nextPdu());
    const cmd = DIMSE.decodeCommandSet(pdvs.find((p) => p.isCommand).data);
    const dsPdv = pdvs.find((p) => !p.isCommand);
    if (cmd['00000900'] === DIMSE.STATUS.PENDING) { if (dsPdv) vistosPorDimse.push(ImplicitVR.decodeDataset(dsPdv.data, { '00400100': true })); }
    else if (cmd['00000900'] === DIMSE.STATUS.SUCCESS) break;
  }
  const accVistoPorDimse = vistosPorDimse.map((ds) => ds.find((e) => e.tag === '00080050')?.value?.trim());
  if (accVistoPorDimse.includes('ACC00000456')) {
    ok(`B.1 HTTP API → DIMSE: el registro creado por POST /worklist (ACC00000456) aparece en un C-FIND real — misma fuente de verdad, no dos copias`);
  } else fail(`B.1: C-FIND no trajo el registro creado por la API. ACCs vistos: ${JSON.stringify(accVistoPorDimse)}`);

  // B.2 — DIMSE escribe (C-STORE real) → ¿la API HTTP lo refleja?
  const datasetImagen = ImplicitVR.encodeDataset([
    { tag: '00100010', vr: 'PN', value: registroIntegracion.nombre },
    { tag: '00080050', vr: 'SH', value: registroIntegracion.acc },
    { tag: '00080060', vr: 'CS', value: 'CT' },
    { tag: '0020000D', vr: 'UI', value: '1.2.826.0.1.3680043.99999.9101' },
    { tag: '0020000E', vr: 'UI', value: '1.2.826.0.1.3680043.99999.9102' },
    { tag: '7fe00010', vr: 'OW', value: Buffer.from([1, 2, 3, 4]) },
  ]);
  socket.write(PDU.encodePDataTF([
    { presentationContextId: 5, isCommand: true, isLast: true, data: DIMSE.encodeCommandSet({ '00000002': '1.2.840.10008.5.1.4.1.1.2', '00000100': DIMSE.COMMAND_FIELD.C_STORE_RQ, '00000110': 2, '00000700': 0, '00000800': 0x0102, '00001000': '1.2.826.0.1.3680043.99999.9100' }) },
    { presentationContextId: 5, isCommand: false, isLast: true, data: datasetImagen },
  ]));
  const storeRsp = DIMSE.decodeCommandSet(PDU.decodePDataTF(await nextPdu())[0].data);
  if (storeRsp['00000900'] === DIMSE.STATUS.SUCCESS) ok('C-STORE real: Status SUCCESS');
  else fail('C-STORE con status inesperado');

  await new Promise((r) => setTimeout(r, 150)); // mismo margen que worklist-store.e2e.test.js para extractTagsWithDcmjs

  const resGetTrasStore = await fetch(`${API}/worklist/${registroIntegracion.id}`);
  const trasStore = await resGetTrasStore.json();
  if (trasStore.fase === 'examenes' && trasStore.estado === 'almacenado') {
    ok(`B.2 DIMSE → HTTP API: GET /worklist/:id ya refleja fase="examenes"/estado="almacenado" — marcado por el C-STORE real, la API nunca lo tocó directo`);
  } else fail('B.2: la API no refleja el cambio hecho por DIMSE: ' + JSON.stringify(trasStore));

  socket.write(PDU.encodeReleaseRQ());
  await nextPdu();
  socket.end();
  server.close();
  apiServer.close();
  fs.rmSync(WORKDIR, { recursive: true, force: true });
  console.log(`\n=== RESULTADO WorklistApiServer: ${process.exitCode ? 'HAY FALLAS ARRIBA' : 'TODO PASÓ — API HTTP y motor DIMSE comparten una sola fuente de verdad, en ambas direcciones'} ===`);
  process.exit(process.exitCode || 0);
}

main().catch((e) => { console.error('ERROR FATAL:', e); process.exit(1); });
