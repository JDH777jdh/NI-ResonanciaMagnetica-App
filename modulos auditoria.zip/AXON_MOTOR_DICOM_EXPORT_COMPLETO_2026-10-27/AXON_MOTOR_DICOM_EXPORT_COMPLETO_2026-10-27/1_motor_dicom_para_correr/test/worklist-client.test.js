'use strict';
/**
 * worklist-client.test.js — prueba WorklistClient.js (la capa de datos que
 * usará HIS-RIS-PACS.jsx) SIN React y sin navegador — solo Node + fetch
 * nativo contra una WorklistApiServer real corriendo en un puerto efímero.
 *
 * Por qué aparte del test de la API (worklist-api.e2e.test.js): ese prueba
 * el servidor HTTP en sí. Este prueba la capa de conveniencia que el
 * componente React va a llamar de verdad — sembrarSiVacio() y
 * restablecerDemo() en particular, que tienen lógica propia (no son un
 * simple wrapper 1:1 de un endpoint) y conviene probar antes de que
 * cualquier bug ahí se disfrace de "bug de React".
 */
const assert = require('assert');
const http = require('http');
const path = require('path');
const fs = require('fs');

const WorklistApiServer = require(path.join(__dirname, '..', 'src', 'server', 'WorklistApiServer'));
const Client = require(path.join(__dirname, '..', 'frontend', 'WorklistClient'));

let paso = 0;
function ok(desc) { paso++; console.log(`OK  [${paso}] ${desc}`); }
function fail(desc) { paso++; console.log(`FAIL[${paso}] ${desc}`); process.exitCode = 1; }

const SEMILLA_PRUEBA = [
  { id: 1, nombre: 'PRUEBA^UNO', modalidad: 'TC', fase: 'agendados', estado: 'agendado', estudio: 'TC cerebro' },
  { id: 2, nombre: 'PRUEBA^DOS', modalidad: 'RM', fase: 'worklist', estado: 'arribado', estudio: 'RM rodilla' },
];

async function main() {
  const WORKDIR = path.join(__dirname, '.tmp-worklist-client-test');
  fs.rmSync(WORKDIR, { recursive: true, force: true });
  fs.mkdirSync(WORKDIR, { recursive: true });
  const STORE_PATH = path.join(WORKDIR, '.worklist-store.json');

  const server = http.createServer(WorklistApiServer.crearHandler({ storePath: STORE_PATH }));
  await new Promise((r) => server.listen(0, r));
  const API = `http://127.0.0.1:${server.address().port}`;

  // --- cargarWorklist en store vacío ---
  const vacio = await Client.cargarWorklist(API);
  if (Array.isArray(vacio) && vacio.length === 0) ok('cargarWorklist() en store recién creado: array vacío, no un error ni un crash');
  else fail('Se esperaba array vacío: ' + JSON.stringify(vacio));

  // --- sembrarSiVacio: primera vez, debe poblar ---
  const r1 = await Client.sembrarSiVacio(API, SEMILLA_PRUEBA);
  if (r1.sembrado === true && r1.datos.length === 2) ok('sembrarSiVacio() primera vez: sembrado=true, pobló los 2 registros de la semilla de prueba');
  else fail('sembrarSiVacio() primera vez: ' + JSON.stringify(r1));

  // --- sembrarSiVacio: segunda vez, NO debe duplicar ---
  const r2 = await Client.sembrarSiVacio(API, SEMILLA_PRUEBA);
  if (r2.sembrado === false && r2.datos.length === 2) ok('sembrarSiVacio() segunda vez: sembrado=false (ya había datos), sigue en 2 registros — no duplicó');
  else fail('sembrarSiVacio() segunda vez: ' + JSON.stringify(r2));

  // --- crearRegistro: agregar uno nuevo, fuera de la semilla (simula "Ingreso manual") ---
  const manual = await Client.crearRegistro(API, { nombre: 'PRUEBA^INGRESOMANUAL', modalidad: 'RX', fase: 'admision', estado: 'nuevo', estudio: 'RX tórax' });
  if (manual.id && !SEMILLA_PRUEBA.some((s) => s.id === manual.id)) ok(`crearRegistro(): agrega un registro fuera de la semilla, con id propio (${manual.id})`);
  else fail('crearRegistro(): ' + JSON.stringify(manual));

  // --- actualizarRegistro: modificar uno de la semilla ---
  const actualizado = await Client.actualizarRegistro(API, 2, { estado: 'en_proceso' });
  if (actualizado.estado === 'en_proceso' && actualizado.nombre === 'PRUEBA^DOS') ok('actualizarRegistro(): cambia el campo pedido, conserva el resto');
  else fail('actualizarRegistro(): ' + JSON.stringify(actualizado));

  // --- restablecerDemo: el registro de la semilla vuelve a su valor original, el manual NO se toca ---
  await Client.restablecerDemo(API, SEMILLA_PRUEBA);
  const trasReset = await Client.cargarWorklist(API);
  // Los ids siempre viajan como string una vez que pasan por la API (los
  // segmentos de URL son string por naturaleza) — comparar con String()
  // acá a propósito, es el mismo criterio que va a tener que usar
  // HIS-RIS-PACS.jsx cuando se cablee de verdad.
  const dosTrasReset = trasReset.find((r) => r.id === String(2));
  const manualTrasReset = trasReset.find((r) => r.id === manual.id);
  if (dosTrasReset && dosTrasReset.estado === 'arribado' && manualTrasReset) {
    ok('restablecerDemo(): el registro #2 volvió a estado="arribado" (su valor de semilla original), Y el registro de Ingreso manual sigue existiendo intacto — reset acotado, no un borrón general');
  } else {
    fail(`restablecerDemo(): estado#2=${dosTrasReset?.estado}, manual sigue=${!!manualTrasReset}`);
  }
  if (trasReset.length === 3) ok('Total de registros tras el reset: 3 (2 semilla + 1 manual) — confirma que no se perdió ni se duplicó nada');
  else fail('Total inesperado tras reset: ' + trasReset.length);

  server.close();
  fs.rmSync(WORKDIR, { recursive: true, force: true });
  console.log(`\n=== RESULTADO WorklistClient: ${process.exitCode ? 'HAY FALLAS ARRIBA' : 'TODO PASÓ'} ===`);
  process.exit(process.exitCode || 0);
}

main().catch((e) => { console.error('ERROR FATAL:', e); process.exit(1); });
