'use strict';
/**
 * encapsulated-pdf.e2e.test.js — verifica el wrapping DICOM de PDF (consentimiento
 * informado), de punta a punta:
 *   A) El dataset se arma con las validaciones correctas (rechaza bytes que no
 *      son PDF, campos obligatorios faltantes).
 *   B) Se guarda un PDF real (generado con reportlab, no un mock de texto) como
 *      Encapsulated PDF, junto a una imagen CT sintética, AMBOS bajo el MISMO
 *      Study Instance UID — el objetivo arquitectónico central de esto.
 *   C) El PDF extraído de vuelta es byte a byte idéntico al original.
 *   D) QIDO-RS ve las 2 series (imagen + documento) del mismo estudio.
 *   E) WADO-RS /rendered responde 422 para el documento (no es una imagen,
 *      nunca debe intentar "renderizarlo" como si lo fuera).
 */
const assert = require('assert');
const net = require('net');
const path = require('path');
const fs = require('fs');
const http = require('http');

const SRC = path.join(__dirname, '..', 'src');
const PDU = require(path.join(SRC, 'pdu', 'PDU'));
const DIMSE = require(path.join(SRC, 'pdu', 'DimseCommand'));
const ImplicitVR = require(path.join(SRC, 'pdu', 'ImplicitVrCodec'));
const { construirDatasetEncapsulado, construirDatasetEncapsuladoBuffer, ENCAPSULATED_PDF_SOP_CLASS } = require(path.join(SRC, 'wrapping', 'EncapsulatedDocument'));
const { iniciarServidor, STORAGE_SOP_CLASSES } = require(path.join(SRC, 'server', 'AssociationServer'));
const DicomWebServer = require(path.join(SRC, 'server', 'DicomWebServer'));

function decodeAssociateAC(buf) {
  let o = 6; o += 2; o += 2; o += 16; o += 16; o += 32;
  const results = [];
  while (o < buf.length) {
    const t = buf.readUInt8(o); const l = buf.readUInt16BE(o + 2);
    const body = buf.slice(o + 4, o + 4 + l);
    if (t === 0x21) results.push({ id: body.readUInt8(0), accepted: body.readUInt8(2) === 0 });
    o += 4 + l;
  }
  return { results };
}

let paso = 0;
function ok(d) { paso++; console.log(`OK  [${paso}] ${d}`); }
function fail(d) { paso++; console.log(`FAIL[${paso}] ${d}`); process.exitCode = 1; }

const PDF_FIXTURE = path.join(__dirname, 'fixtures', 'consentimiento_prueba.pdf');

// ─────────── A) Validaciones de construcción ───────────
try {
  assert.throws(() => construirDatasetEncapsulado({ pdfBytes: Buffer.from('no es un pdf'), patientName: 'X', patientID: 'Y', studyInstanceUID: '1', seriesInstanceUID: '2', sopInstanceUID: '3' }), /no parece un PDF válido/);
  ok('Rechaza bytes que no empiezan con "%PDF-" (no finge que cualquier binario es un PDF)');
} catch (e) { fail('Validación de PDF inválido: ' + e.message); }

try {
  assert.throws(() => construirDatasetEncapsulado({ pdfBytes: fs.readFileSync(PDF_FIXTURE), patientName: 'X' }), /falta "patientID"/);
  ok('Rechaza dataset incompleto (falta patientID, studyInstanceUID, etc.)');
} catch (e) { fail('Validación de campos obligatorios: ' + e.message); }

try {
  const pdfBytes = fs.readFileSync(PDF_FIXTURE);
  const dataset = construirDatasetEncapsulado({ pdfBytes, patientName: 'PRUEBA^SINTETICA', patientID: 'CUP-CL-13-2026-00000001-A1', studyInstanceUID: '1.2.3', seriesInstanceUID: '1.2.3.1', sopInstanceUID: '1.2.3.1.1', verificado: true });
  assert.strictEqual(dataset.find((e) => e.tag === '00080016').value, ENCAPSULATED_PDF_SOP_CLASS);
  assert.strictEqual(dataset.find((e) => e.tag === '00080060').value, 'DOC');
  assert.strictEqual(dataset.find((e) => e.tag === '00420012').value, 'application/pdf');
  assert.strictEqual(dataset.find((e) => e.tag === '00420013').value, 'VERIFIED');
  assert.strictEqual(Buffer.compare(dataset.find((e) => e.tag === '00420011').value, pdfBytes), 0);
  ok('Dataset construido con verificado=true -> VerificationFlag="VERIFIED", PDF embebido intacto');
} catch (e) { fail('Construcción básica: ' + e.message); }

// ─────────── B-E) Punta a punta: PDF + imagen, mismo Study, DIMSE real ───────────
async function main() {
  const WORKDIR = path.join(__dirname, '.tmp-encapsulated-pdf-test');
  fs.rmSync(WORKDIR, { recursive: true, force: true });
  fs.mkdirSync(WORKDIR, { recursive: true });
  const ALMACEN = path.join(WORKDIR, 'almacen');

  const server = iniciarServidor({ port: 0, almacenPath: ALMACEN, worklistProvider: () => [], tlsOptions: null });
  await new Promise((r) => server.once('listening', r));
  const PORT = server.address().port;
  const socket = net.connect(PORT, '127.0.0.1');
  await new Promise((res, rej) => { socket.once('connect', res); socket.once('error', rej); });

  let buffer = Buffer.alloc(0); const pduQueue = []; const waiters = [];
  socket.on('data', (chunk) => {
    buffer = Buffer.concat([buffer, chunk]);
    let header;
    while ((header = PDU.peekPduHeader(buffer)) && buffer.length >= header.totalSize) {
      const pdu = buffer.slice(0, header.totalSize); buffer = buffer.slice(header.totalSize);
      if (waiters.length) waiters.shift()(pdu); else pduQueue.push(pdu);
    }
  });
  function nextPdu(t = 3000) { return new Promise((res, rej) => { if (pduQueue.length) return res(pduQueue.shift()); const tm = setTimeout(() => rej(new Error('timeout')), t); waiters.push((p) => { clearTimeout(tm); res(p); }); }); }

  const studyInstanceUID = '1.2.826.0.1.3680043.99999.500';
  const seriesImagenUID = '1.2.826.0.1.3680043.99999.501';
  const seriesDocUID = '1.2.826.0.1.3680043.99999.502';
  const sopImagenUID = '1.2.826.0.1.3680043.99999.501.1';
  const sopDocUID = '1.2.826.0.1.3680043.99999.502.1';

  const rq = PDU.encodeAssociateRQ({
    calledAE: 'AXON_RIS', callingAE: 'CT_SALA1',
    presentationContexts: [
      { id: 1, abstractSyntax: '1.2.840.10008.5.1.4.1.1.7', transferSyntaxes: ['1.2.840.10008.1.2'] },
      { id: 3, abstractSyntax: ENCAPSULATED_PDF_SOP_CLASS, transferSyntaxes: ['1.2.840.10008.1.2.1'] },
    ],
    maxPduLength: 16384, implementationClassUID: '1.2.840.99999.1.1',
  });
  socket.write(rq);
  const acPdu = await nextPdu();
  if (acPdu.readUInt8(0) !== PDU.PDU_TYPE.A_ASSOCIATE_AC) { fail('No llegó A-ASSOCIATE-AC'); socket.end(); server.close(); process.exit(1); }
  const ac = decodeAssociateAC(acPdu);
  const pc1 = ac.results.find((r) => r.id === 1);
  const pc3 = ac.results.find((r) => r.id === 3);
  if (pc1 && pc1.accepted && pc3 && pc3.accepted) ok('Asociación aceptada con 2 Presentation Contexts: imagen (OT) + documento (Encapsulated PDF) — AMBOS confirmados individualmente');
  else { fail('Algún Presentation Context no fue aceptado: ' + JSON.stringify(ac.results)); socket.end(); server.close(); process.exit(1); }

  const datasetImagen = ImplicitVR.encodeDataset([
    { tag: '00100010', vr: 'PN', value: 'PRUEBA^SINTETICA' },
    { tag: '0020000D', vr: 'UI', value: studyInstanceUID },
    { tag: '0020000E', vr: 'UI', value: seriesImagenUID },
    { tag: '00080060', vr: 'CS', value: 'OT' },
    { tag: '7fe00010', vr: 'OW', value: Buffer.from([0, 1, 2, 3]) },
  ]);
  socket.write(PDU.encodePDataTF([
    { presentationContextId: 1, isCommand: true, isLast: true, data: DIMSE.encodeCommandSet({ '00000002': '1.2.840.10008.5.1.4.1.1.7', '00000100': DIMSE.COMMAND_FIELD.C_STORE_RQ, '00000110': 1, '00000700': 0, '00000800': 0x0102, '00001000': sopImagenUID }) },
    { presentationContextId: 1, isCommand: false, isLast: true, data: datasetImagen },
  ]));
  const rspImagen = DIMSE.decodeCommandSet(PDU.decodePDataTF(await nextPdu())[0].data);
  if (rspImagen['00000900'] === DIMSE.STATUS.SUCCESS) ok('C-STORE de la imagen del mismo evento clínico: SUCCESS');
  else fail('C-STORE de la imagen falló');

  const pdfBytes = fs.readFileSync(PDF_FIXTURE);
  const datasetDoc = construirDatasetEncapsuladoBuffer({
    pdfBytes, patientName: 'PRUEBA^SINTETICA', patientID: 'CUP-CL-13-2026-00000001-A1',
    studyInstanceUID, seriesInstanceUID: seriesDocUID, sopInstanceUID: sopDocUID,
    documentTitle: 'Consentimiento informado - TC torax con contraste', verificado: false,
  });
  socket.write(PDU.encodePDataTF([
    { presentationContextId: 3, isCommand: true, isLast: true, data: DIMSE.encodeCommandSet({ '00000002': ENCAPSULATED_PDF_SOP_CLASS, '00000100': DIMSE.COMMAND_FIELD.C_STORE_RQ, '00000110': 2, '00000700': 0, '00000800': 0x0102, '00001000': sopDocUID }) },
    { presentationContextId: 3, isCommand: false, isLast: true, data: datasetDoc },
  ]));
  const rspDoc = DIMSE.decodeCommandSet(PDU.decodePDataTF(await nextPdu())[0].data);
  if (rspDoc['00000900'] === DIMSE.STATUS.SUCCESS) ok(`C-STORE del PDF de consentimiento encapsulado (${pdfBytes.length} bytes de PDF real): SUCCESS`);
  else fail('C-STORE del documento encapsulado falló: 0x' + (rspDoc['00000900'] || 0).toString(16));

  socket.write(PDU.encodeReleaseRQ());
  await nextPdu();
  socket.end();

  const archivoDoc = fs.readdirSync(ALMACEN).find((f) => f.includes(sopDocUID.replace(/[^0-9.]/g, '_')));
  if (archivoDoc) {
    const dcmjs = require(path.join(SRC, '..', 'node_modules', 'dcmjs'));
    const bytes = fs.readFileSync(path.join(ALMACEN, archivoDoc));
    const ab = bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength);
    const dict = dcmjs.data.DicomMessage.readFile(ab);
    const ds = dcmjs.data.DicomMetaDictionary.naturalizeDataset(dict.dict);
    const pdfExtraido = Buffer.from(ds.EncapsulatedDocument[0]);
    if (Buffer.compare(pdfExtraido, pdfBytes) === 0) ok('PDF extraído del objeto DICOM guardado es BYTE A BYTE idéntico al original — dcmjs lo lee sin ayuda de código propio');
    else fail(`PDF extraído difiere: ${pdfExtraido.length} vs ${pdfBytes.length} bytes`);
    if (ds.Modality === 'DOC' && ds.MIMETypeOfEncapsulatedDocument === 'application/pdf') ok('Modality="DOC" y MIMEType="application/pdf" correctos, leídos por dcmjs');
    else fail('Modality/MIMEType incorrectos');
  } else fail('No se encontró el archivo del documento guardado');

  const httpServer = http.createServer(DicomWebServer.crearHandler({ almacenPath: ALMACEN }));
  await new Promise((r) => httpServer.listen(0, r));
  const port = httpServer.address().port;
  const series = JSON.parse(await new Promise((resolve) => { http.get(`http://127.0.0.1:${port}/studies/${studyInstanceUID}/series`, (res) => { let d = ''; res.on('data', (c) => d += c); res.on('end', () => resolve(d)); }); }));
  if (series.length === 2) ok('QIDO-RS: el estudio tiene 2 series (imagen + documento de consentimiento) bajo el MISMO Study Instance UID — objetivo arquitectónico confirmado');
  else fail(`QIDO-RS: se esperaban 2 series, llegaron ${series.length}`);

  const respuesta = await new Promise((resolve) => {
    http.get(`http://127.0.0.1:${port}/studies/${studyInstanceUID}/series/${seriesDocUID}/instances/${sopDocUID}/rendered`, (res) => {
      const chunks = []; res.on('data', (c) => chunks.push(c)); res.on('end', () => resolve({ status: res.statusCode, body: Buffer.concat(chunks).toString() }));
    });
  });
  if (respuesta.status === 422) ok(`WADO-RS /rendered sobre el documento: 422 con el motivo ("${JSON.parse(respuesta.body).error}") — no intenta renderizar un PDF como si fuera una imagen`);
  else fail(`Se esperaba 422, llegó ${respuesta.status}`);

  httpServer.close(); server.close();
  fs.rmSync(WORKDIR, { recursive: true, force: true });
  console.log(`\n=== RESULTADO Encapsulated PDF: ${process.exitCode ? 'HAY FALLAS ARRIBA' : 'TODO PASÓ'} ===`);
  process.exit(process.exitCode || 0);
}
main().catch((e) => { console.error('ERROR FATAL:', e); process.exit(1); });
