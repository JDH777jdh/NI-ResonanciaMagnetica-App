'use strict';
/**
 * vr-limits.test.js — prueba VrLimits.js y su integración real en los dos
 * codecs (31-ago-2026).
 *
 * Motivación: el hallazgo de ACC-2026-00000001 (17 caracteres, excede el
 * máximo 16 de VR=SH) — documentado en el dossier maestro y confirmado de
 * forma independiente por el documento de arquitectura externo recibido
 * 30-ago-2026 — reveló que ningún codec validaba longitud de VR al
 * codificar. Este test prueba la corrección: la tabla contra la fuente
 * primaria (PS3.5 Tabla 6.2-1), y que AMBOS codecs (Implicit y Explicit)
 * ahora rechazan valores demasiado largos con un error explícito, no en
 * silencio.
 */
const assert = require('assert');
const path = require('path');

const VrLimits = require(path.join(__dirname, '..', 'src', 'pdu', 'VrLimits'));
const ImplicitVR = require(path.join(__dirname, '..', 'src', 'pdu', 'ImplicitVrCodec'));
const ExplicitVR = require(path.join(__dirname, '..', 'src', 'pdu', 'ExplicitVrCodec'));

let paso = 0;
function ok(desc) { paso++; console.log(`OK  [${paso}] ${desc}`); }
function fail(desc) { paso++; console.log(`FAIL[${paso}] ${desc}`); process.exitCode = 1; }

// ───────────── A) La tabla en sí, contra casos conocidos de PS3.5 Tabla 6.2-1 ─────────────
try {
  assert.strictEqual(VrLimits.VR_MAX_LENGTH.SH, 16);
  assert.strictEqual(VrLimits.VR_MAX_LENGTH.CS, 16);
  assert.strictEqual(VrLimits.VR_MAX_LENGTH.UI, 64);
  assert.strictEqual(VrLimits.VR_MAX_LENGTH.LO, 64);
  assert.strictEqual(VrLimits.VR_MAX_LENGTH.IS, 12);
  assert.strictEqual(VrLimits.VR_MAX_LENGTH.AS, 4);
  ok('Tabla VR_MAX_LENGTH coincide con PS3.5 Tabla 6.2-1 para los casos verificados (SH=16, CS=16, UI=64, LO=64, IS=12, AS=4)');
} catch (e) { fail('Tabla VR_MAX_LENGTH: ' + e.message); }

// ───────────── B) validarLongitudVR() en aislamiento ─────────────
try {
  assert.doesNotThrow(() => VrLimits.validarLongitudVR('SH', 'ACC-00000001')); // 12 chars, el ACC ya corregido
  assert.throws(() => VrLimits.validarLongitudVR('SH', 'ACC-2026-00000001'), /excede el máximo de 16/); // 17 chars, el ACC viejo roto
  ok('validarLongitudVR(): acepta el ACC corregido (12 chars), rechaza el formato viejo (17 chars) con el motivo explícito');
} catch (e) { fail('validarLongitudVR(): ' + e.message); }

try {
  VrLimits.validarLongitudVR('UC', 'x'.repeat(500)); // UC no tiene límite práctico en nuestra tabla — no debe lanzar
  ok('VRs sin límite definido en la tabla (ej. UC) no lanzan — no inventamos un límite que el estándar no fija en la práctica');
} catch (e) { fail('VR sin límite: ' + e.message); }

// ───────────── C) Integración real en ImplicitVrCodec — el bug real, reproducido y confirmado corregido ─────────────
try {
  ImplicitVR.encodeElement(0x0008, 0x0050, 'SH', 'ACC-2026-00000001'); // 17 chars — el bug real que encontramos
  fail('ImplicitVrCodec.encodeElement debería haber rechazado un Accession Number de 17 caracteres en VR=SH');
} catch (e) {
  if (/excede el máximo de 16/.test(e.message)) ok('ImplicitVrCodec.encodeElement RECHAZA el ACC de 17 caracteres (el bug real) con el motivo — antes se codificaba en silencio');
  else fail('ImplicitVrCodec rechazó, pero con un mensaje inesperado: ' + e.message);
}
try {
  const buf = ImplicitVR.encodeElement(0x0008, 0x0050, 'SH', 'ACC-00000001'); // 12 chars — el ACC ya corregido
  const decoded = ImplicitVR.decodeDataset(buf);
  assert.strictEqual(decoded[0].value, 'ACC-00000001');
  ok('ImplicitVrCodec.encodeElement ACEPTA el ACC corregido (12 caracteres) y codifica/decodifica exacto');
} catch (e) { fail('ImplicitVrCodec con ACC corregido: ' + e.message); }

// ───────────── D) Integración real en ExplicitVrCodec — mismo caso ─────────────
try {
  ExplicitVR.encodeElement(0x0008, 0x0050, 'SH', 'ACC-2026-00000001');
  fail('ExplicitVrCodec.encodeElement debería haber rechazado el mismo ACC de 17 caracteres');
} catch (e) {
  if (/excede el máximo de 16/.test(e.message)) ok('ExplicitVrCodec.encodeElement RECHAZA el mismo ACC de 17 caracteres — el fix está en ambos codecs, no solo uno');
  else fail('ExplicitVrCodec rechazó, pero con mensaje inesperado: ' + e.message);
}
try {
  const buf = ExplicitVR.encodeElement(0x0008, 0x0050, 'SH', 'ACC-00000001');
  const decoded = ExplicitVR.decodeDataset(buf);
  assert.strictEqual(decoded[0].value, 'ACC-00000001');
  ok('ExplicitVrCodec.encodeElement ACEPTA el ACC corregido y codifica/decodifica exacto');
} catch (e) { fail('ExplicitVrCodec con ACC corregido: ' + e.message); }

// ───────────── E) No debe romper ningún VR usado hoy en el motor con valores reales del proyecto ─────────────
try {
  ImplicitVR.encodeElement(0x0008, 0x0018, 'UI', '1.2.826.0.1.3680043.99999.9001'); // UID típico del proyecto, ~31 chars, dentro de 64
  ImplicitVR.encodeElement(0x0010, 0x0010, 'PN', 'PRUEBA^WORKLISTSTORE');
  ImplicitVR.encodeElement(0x0040, 0x0001, 'AE', 'CT_SALA1');
  ImplicitVR.encodeElement(0x0008, 0x0060, 'CS', 'CT');
  ok('Valores reales ya en uso en el proyecto (UID de estudio, nombre de paciente, AE Title, modalidad) siguen codificando sin problema — la validación no rompe el uso normal');
} catch (e) { fail('Valores reales del proyecto: ' + e.message); }

console.log(`\n=== RESULTADO VrLimits: ${process.exitCode ? 'HAY FALLAS ARRIBA' : 'TODO PASÓ'} ===`);
process.exit(process.exitCode || 0);
