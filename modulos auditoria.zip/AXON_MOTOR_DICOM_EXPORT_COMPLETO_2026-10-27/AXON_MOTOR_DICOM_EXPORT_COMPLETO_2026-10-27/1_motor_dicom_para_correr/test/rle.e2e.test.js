'use strict';
/**
 * rle.e2e.test.js — RLE Lossless (Transfer Syntax 1.2.840.10008.1.2.5) de
 * punta a punta (18-oct-2026): negociación de asociación → C-STORE real por
 * DIMSE → almacén → QIDO-RS → WADO-RS /rendered → PNG.
 *
 * Qué prueba y contra qué (para distinguir evidencia fuerte de débil):
 *   A) Negociación: el motor ACEPTA RLE, RECHAZA una Transfer Syntax comprimida
 *      sin decoder (JPEG Baseline), y elige RLE cuando el SCU ofrece varias.
 *   B) Archivo RLE REAL generado por OTRA implementación (MR_small_RLE.dcm,
 *      repositorio de test files de pydicom — no por el encoder de este motor):
 *        - llega por C-STORE y queda guardado byte a byte idéntico;
 *        - sus muestras descomprimidas son idénticas a las del MR_small.dcm sin
 *          comprimir (comparación a nivel de muestras, antes de cualquier ventana);
 *        - /rendered devuelve un PNG byte a byte idéntico al del archivo sin
 *          comprimir. Este check es el que cubre el bug real encontrado hoy:
 *          RenderInstance leía los bytes comprimidos como píxeles y devolvía 200
 *          con una imagen equivocada (4087 de 4096 píxeles distintos).
 *   C) Imágenes sintéticas con muestras CONOCIDAS (el esperado sale de las
 *      muestras + la fórmula de ventana, no de otro render del propio motor):
 *        C1) 8 bits, 256×256, dataset enviado en PDUs de 4096 bytes
 *            (reensamblado de fragmentos DIMSE con contenido RLE real);
 *        C2) 16 bits, 37×29 (dimensiones impares), 3 frames que difieren entre sí
 *            (si se renderizara otro frame que el primero, se nota);
 *        C3) un frame RLE partido en 2 fragmentos de Pixel Data (válido en PS3.5).
 *   D) Puerta etiquetada: un archivo guardado con una Transfer Syntax sin
 *      decoder responde 422 con el nombre de la Transfer Syntax — nunca una
 *      imagen — y WADO-RS sigue sirviendo el objeto crudo.
 *   E) Datos RLE corruptos (frame truncado): 422, nunca una imagen incorrecta.
 *
 * Alcance honesto: los encoders usados para generar C1–C3 y E son los del propio
 * motor (RleCodec.js). Su corrección está validada aparte contra pydicom como
 * decoder independiente (ver dossier §18); acá el esperado nunca depende de
 * ellos (sale de las muestras originales).
 */
const assert = require('assert');
const net = require('net');
const path = require('path');
const fs = require('fs');
const http = require('http');
const { PNG } = require('pngjs');

const SRC = path.join(__dirname, '..', 'src');
const PDU = require(path.join(SRC, 'pdu', 'PDU'));
const DIMSE = require(path.join(SRC, 'pdu', 'DimseCommand'));
const Explicit = require(path.join(SRC, 'pdu', 'ExplicitVrCodec'));
const Rle = require(path.join(SRC, 'pdu', 'RleCodec'));
const TransferSyntaxRegistry = require(path.join(SRC, 'pdu', 'TransferSyntaxRegistry'));
const { iniciarServidor, VERIFICATION_SOP_CLASS } = require(path.join(SRC, 'server', 'AssociationServer'));
const DicomWebServer = require(path.join(SRC, 'server', 'DicomWebServer'));
const { renderizarInstanciaAPng } = require(path.join(SRC, 'rendering', 'RenderInstance'));
const { buildStoredFile, extractTagsWithDcmjs } = require(path.join(SRC, 'server', 'CStoreDataset'));
const StudyIndex = require(path.join(SRC, 'storage', 'StudyIndex'));

const RLE = '1.2.840.10008.1.2.5';
const JPEG_BASELINE = '1.2.840.10008.1.2.4.50';
const EXPLICIT_LE = '1.2.840.10008.1.2.1';
const IMPLICIT_LE = '1.2.840.10008.1.2';
const MR_STORAGE = '1.2.840.10008.5.1.4.1.1.4';
const FIX = path.join(__dirname, 'fixtures');

let paso = 0;
function ok(desc) { paso++; console.log(`OK  [${paso}] ${desc}`); }
function fail(desc) { paso++; console.log(`FAIL[${paso}] ${desc}`); process.exitCode = 1; }
async function escenario(nombre, fn) {
  try { await fn(); } catch (e) { fail(`${nombre}: ${e.message}`); }
}

// ───────────────────────── utilidades de protocolo ─────────────────────────

// Mismo decoder mínimo de A-ASSOCIATE-AC que usan los otros tests (PDU.js no expone uno todavía).
function decodeAssociateAC(buf) {
  let o = 6; o += 2; o += 2; o += 16; o += 16; o += 32;
  const results = [];
  while (o < buf.length) {
    const itemType = buf.readUInt8(o);
    const itemLen = buf.readUInt16BE(o + 2);
    const itemBody = buf.slice(o + 4, o + 4 + itemLen);
    if (itemType === 0x21) {
      const resultByte = itemBody.readUInt8(2);
      let transferSyntax = null;
      if (itemBody.length > 4) {
        const subLen = itemBody.readUInt16BE(4 + 2);
        transferSyntax = itemBody.slice(4 + 4, 4 + 4 + subLen).toString('ascii').replace(/\0+$/, '');
      }
      results.push({ id: itemBody.readUInt8(0), accepted: resultByte === 0, resultByte, transferSyntax });
    }
    o += 4 + itemLen;
  }
  return { results };
}

async function conectar(port) {
  const socket = net.connect(port, '127.0.0.1');
  await new Promise((res, rej) => { socket.once('connect', res); socket.once('error', rej); });
  let buffer = Buffer.alloc(0);
  const cola = []; const esperando = [];
  socket.on('data', (chunk) => {
    buffer = Buffer.concat([buffer, chunk]);
    let header;
    while ((header = PDU.peekPduHeader(buffer)) && buffer.length >= header.totalSize) {
      const pdu = buffer.slice(0, header.totalSize); buffer = buffer.slice(header.totalSize);
      if (esperando.length) esperando.shift()(pdu); else cola.push(pdu);
    }
  });
  const nextPdu = (t = 4000) => new Promise((res, rej) => {
    if (cola.length) return res(cola.shift());
    const tm = setTimeout(() => rej(new Error('timeout esperando PDU')), t);
    esperando.push((p) => { clearTimeout(tm); res(p); });
  });
  return { socket, nextPdu };
}

let msgIdSeq = 0;
/** C-STORE real. Sin `tamPdv`: comando + dataset en un solo P-DATA-TF (como los otros tests).
    Con `tamPdv`: el dataset viaja en varios P-DATA-TF de ese tamaño, solo el último con isLast. */
async function cStore(sesion, pcId, sopClassUID, sopInstanceUID, datasetBuf, tamPdv = null) {
  const cmd = DIMSE.encodeCommandSet({
    '00000002': sopClassUID, '00000100': DIMSE.COMMAND_FIELD.C_STORE_RQ, '00000110': ++msgIdSeq,
    '00000700': 0, '00000800': 0x0102, '00001000': sopInstanceUID,
  });
  let pdus = 0;
  if (!tamPdv) {
    sesion.socket.write(PDU.encodePDataTF([
      { presentationContextId: pcId, isCommand: true, isLast: true, data: cmd },
      { presentationContextId: pcId, isCommand: false, isLast: true, data: datasetBuf },
    ]));
    pdus = 1;
  } else {
    sesion.socket.write(PDU.encodePDataTF([{ presentationContextId: pcId, isCommand: true, isLast: true, data: cmd }]));
    for (let o = 0; o < datasetBuf.length; o += tamPdv) {
      sesion.socket.write(PDU.encodePDataTF([{
        presentationContextId: pcId, isCommand: false, isLast: o + tamPdv >= datasetBuf.length, data: datasetBuf.slice(o, o + tamPdv),
      }]));
      pdus++;
    }
  }
  const rsp = DIMSE.decodeCommandSet(PDU.decodePDataTF(await sesion.nextPdu())[0].data);
  return { status: rsp['00000900'], pdus };
}

function httpGet(url) {
  return new Promise((resolve, reject) => {
    http.get(url, (res) => {
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => resolve({ status: res.statusCode, tipo: res.headers['content-type'], body: Buffer.concat(chunks) }));
    }).on('error', reject);
  });
}
const httpJson = async (url) => JSON.parse((await httpGet(url)).body.toString());

// ───────────────────────── utilidades de DICOM / datos ─────────────────────────

const limpiarUid = (s) => String(s).replace(/[\0\s]+$/, '');
const elemento = (els, tag) => els.find((e) => e.tag === tag);

/** Lee un archivo Part10: File Meta (siempre Explicit VR LE) + el dataset crudo que le sigue. */
function leerPart10(ruta) {
  const buf = fs.readFileSync(ruta);
  const primero = Explicit.decodeElementAt(buf, 132); // 128 preámbulo + 4 "DICM"
  const finFileMeta = primero.nextOffset + primero.value;
  const fm = Explicit.decodeDataset(buf.slice(132, finFileMeta));
  const get = (tag) => limpiarUid(elemento(fm, tag).value);
  return { datasetCrudo: buf.slice(finFileMeta), sopClassUID: get('00020002'), sopInstanceUID: get('00020003'), transferSyntaxUID: get('00020010') };
}

// Misma fórmula de ventana que RenderInstance.js / HIS-RIS-PACS.jsx (PS3.3 C.11.2.1.2) — acá se
// reescribe a propósito, como en render.e2e.test.js, para que el esperado no dependa del código bajo prueba.
function aplicarVentana(x, center, width) {
  const w = Math.max(width, 1);
  if (x <= center - 0.5 - (w - 1) / 2) return 0;
  if (x > center - 0.5 + (w - 1) / 2) return 255;
  return ((x - (center - 0.5)) / (w - 1) + 0.5) * 255;
}
const aGris8 = (v, centro, ancho) => Math.round(Math.max(0, Math.min(255, aplicarVentana(v, centro, ancho))));

/** Compara un PNG contra un arreglo de grises esperado, píxel por píxel. */
function compararPng(pngBuf, esperado8, ancho, alto) {
  const png = PNG.sync.read(pngBuf);
  if (png.width !== ancho || png.height !== alto) return { ok: false, motivo: `dimensiones ${png.width}x${png.height}, esperado ${ancho}x${alto}` };
  let malos = 0; let primero = -1;
  for (let i = 0; i < ancho * alto; i++) {
    const r = png.data[i * 4];
    if (r !== esperado8[i] || png.data[i * 4 + 1] !== r || png.data[i * 4 + 2] !== r) { malos++; if (primero < 0) primero = i; }
  }
  return { ok: malos === 0, motivo: malos ? `${malos}/${ancho * alto} píxeles distintos (primero en #${primero}: esperado ${esperado8[primero]}, llegó ${png.data[primero * 4]})` : 'ok' };
}

/** 8 bits: mitad superior en bloques (corridas largas), mitad inferior con ruido determinista (literales). */
function muestras8(ancho, alto) {
  const b = Buffer.alloc(ancho * alto); let semilla = 12345;
  for (let y = 0; y < alto; y++) {
    for (let x = 0; x < ancho; x++) {
      semilla = (Math.imul(semilla, 1103515245) + 12345) >>> 0;
      b[y * ancho + x] = y < alto / 2 ? (((x >> 3) ^ (y >> 3)) * 29) & 0xff : (semilla >>> 16) & 0xff;
    }
  }
  return b;
}
/** 16 bits sin signo, valores en 0..2999; cada frame difiere de los demás. */
function muestras16(ancho, alto, frame) {
  const b = Buffer.alloc(ancho * alto * 2);
  for (let y = 0; y < alto; y++) {
    for (let x = 0; x < ancho; x++) b.writeUInt16LE((x * 37 + y * 91 + frame * 1000 + ((x * y) % 7) * 11) % 3000, (y * ancho + x) * 2);
  }
  return b;
}
const valoresDe = (buf, bits) => {
  const n = bits === 8 ? buf.length : buf.length / 2;
  return Array.from({ length: n }, (_, i) => (bits === 8 ? buf[i] : buf.readUInt16LE(i * 2)));
};

/** Dataset sintético (Explicit VR LE, tags en orden ascendente) con Pixel Data encapsulado. */
function datasetSintetico({ sopUID, studyUID, seriesUID, filas, columnas, bits, numFrames, fragmentosPixel, centro, ancho }) {
  return Explicit.encodeDataset([
    { tag: '00080016', vr: 'UI', value: MR_STORAGE },
    { tag: '00080018', vr: 'UI', value: sopUID },
    { tag: '00080060', vr: 'CS', value: 'MR' },
    { tag: '00100010', vr: 'PN', value: 'PRUEBA^RLE' },
    { tag: '00100020', vr: 'LO', value: 'RLE-TEST' },
    { tag: '0020000D', vr: 'UI', value: studyUID },
    { tag: '0020000E', vr: 'UI', value: seriesUID },
    { tag: '00280002', vr: 'US', value: 1 },
    { tag: '00280004', vr: 'CS', value: 'MONOCHROME2' },
    ...(numFrames ? [{ tag: '00280008', vr: 'IS', value: String(numFrames) }] : []),
    { tag: '00280010', vr: 'US', value: filas },
    { tag: '00280011', vr: 'US', value: columnas },
    { tag: '00280100', vr: 'US', value: bits },
    { tag: '00280101', vr: 'US', value: bits },
    { tag: '00280102', vr: 'US', value: bits - 1 },
    { tag: '00280103', vr: 'US', value: 0 },
    { tag: '00281050', vr: 'DS', value: String(centro) },
    { tag: '00281051', vr: 'DS', value: String(ancho) },
    { tag: '7fe00010', vr: 'OB', value: { encapsulado: true, fragmentos: fragmentosPixel } },
  ]);
}
const rutaAlmacenada = (almacen, sop) => path.join(almacen, `${sop.replace(/[^0-9.]/g, '_')}.dcm`);

// ───────────────────────── prueba ─────────────────────────

async function main() {
  const WORKDIR = path.join(__dirname, '.tmp-rle-test');
  fs.rmSync(WORKDIR, { recursive: true, force: true });
  fs.mkdirSync(WORKDIR, { recursive: true });
  const ALMACEN = path.join(WORKDIR, 'almacen');

  // ── 0) El registro dice la verdad (antes de tocar la red) ──
  await escenario('Registro', async () => {
    assert.strictEqual(TransferSyntaxRegistry.estaSoportada(RLE), true);
    assert.ok(TransferSyntaxRegistry.listarSoportadas().includes(RLE));
    assert.strictEqual(TransferSyntaxRegistry.estaSoportada(JPEG_BASELINE), false);
    ok('TransferSyntaxRegistry: RLE Lossless soportada y listada para la negociación; JPEG Baseline sigue siendo puerta etiquetada (sin decoder)');
  });

  const server = iniciarServidor({ port: 0, almacenPath: ALMACEN, worklistProvider: () => [], tlsOptions: null });
  await new Promise((r) => server.once('listening', r));
  const httpServer = http.createServer(DicomWebServer.crearHandler({ almacenPath: ALMACEN }));
  await new Promise((r) => httpServer.listen(0, r));
  const base = `http://127.0.0.1:${httpServer.address().port}`;
  const sesion = await conectar(server.address().port);

  // ── A) Negociación ──
  let negociacionOk = false;
  await escenario('A) Negociación', async () => {
    sesion.socket.write(PDU.encodeAssociateRQ({
      calledAE: 'AXON_RIS', callingAE: 'CT_SALA1',
      presentationContexts: [
        { id: 1, abstractSyntax: MR_STORAGE, transferSyntaxes: [RLE] },
        { id: 3, abstractSyntax: MR_STORAGE, transferSyntaxes: [JPEG_BASELINE] },
        { id: 5, abstractSyntax: MR_STORAGE, transferSyntaxes: [JPEG_BASELINE, RLE, EXPLICIT_LE] },
        { id: 7, abstractSyntax: VERIFICATION_SOP_CLASS, transferSyntaxes: [IMPLICIT_LE] },
      ],
      maxPduLength: 16384, implementationClassUID: '1.2.840.99999.1.1',
    }));
    const acPdu = await sesion.nextPdu();
    assert.strictEqual(acPdu.readUInt8(0), PDU.PDU_TYPE.A_ASSOCIATE_AC, 'se esperaba A-ASSOCIATE-AC');
    const por = Object.fromEntries(decodeAssociateAC(acPdu).results.map((r) => [r.id, r]));
    assert.ok(por[1].accepted && por[1].transferSyntax === RLE, `contexto 1 (solo RLE) debía aceptarse con RLE: ${JSON.stringify(por[1])}`);
    ok('Contexto que ofrece SOLO RLE Lossless: ACEPTADO con Transfer Syntax RLE (antes del cambio la negociación lo rechazaba)');
    // resultByte hoy siempre es 3 (abstract-syntax-not-supported) para cualquier rechazo; PS3.8 §9.3.3.2
    // define 4 (transfer-syntaxes-not-supported) para este caso — hallazgo aparte (dossier §18), por eso acá
    // solo se afirma que NO se aceptó, no el código exacto.
    assert.ok(!por[3].accepted, 'el contexto que ofrece solo JPEG Baseline no debía aceptarse');
    ok(`Contexto que ofrece SOLO JPEG Baseline (sin decoder): RECHAZADO — el motor no acepta lo que no sabe interpretar (código de rechazo enviado: ${por[3].resultByte})`);
    assert.ok(por[5].accepted && por[5].transferSyntax === RLE, `contexto 5 debía elegir RLE saltando JPEG: ${JSON.stringify(por[5])}`);
    ok('SCU que ofrece [JPEG Baseline, RLE, Explicit VR LE]: el motor salta la que no soporta y elige RLE (primera soportada de la lista del SCU)');
    assert.ok(por[7].accepted, 'C-ECHO debía seguir aceptándose');
    negociacionOk = true;
  });
  if (!negociacionOk) {
    fail('Sin asociación válida no se puede seguir con los escenarios de C-STORE');
    httpServer.close(); server.close(); fs.rmSync(WORKDIR, { recursive: true, force: true });
    process.exit(1);
  }

  // ── B) Archivo RLE REAL de otra implementación ──
  let estudioB = null; let serieB = null; let datasetB = null; let sopClassB = null;
  await escenario('B) MR_small_RLE.dcm real', async () => {
    const rutaRle = path.join(FIX, 'MR_small_RLE.dcm');
    const rutaPlano = path.join(FIX, 'MR_small.dcm');
    assert.ok(fs.existsSync(rutaRle), 'falta test/fixtures/MR_small_RLE.dcm (se reconstruye con rebuild_tree.sh desde MR_small_RLE_dcm_base64.txt)');
    const externo = leerPart10(rutaRle);
    assert.strictEqual(externo.transferSyntaxUID, RLE, 'el fixture debía ser RLE de verdad (File Meta)');
    datasetB = externo.datasetCrudo; sopClassB = externo.sopClassUID;
    ok(`Fixture externo confirmado como RLE por su propio File Meta (${externo.datasetCrudo.length} bytes de dataset, generado por otra implementación)`);

    const st = await cStore(sesion, 1, externo.sopClassUID, externo.sopInstanceUID, externo.datasetCrudo);
    assert.strictEqual(st.status, DIMSE.STATUS.SUCCESS, `C-STORE status 0x${(st.status || 0).toString(16)}`);
    ok('C-STORE real del RLE externo por DIMSE: Status SUCCESS');

    const guardado = leerPart10(rutaAlmacenada(ALMACEN, externo.sopInstanceUID));
    assert.strictEqual(guardado.transferSyntaxUID, RLE, 'el File Meta que escribe el motor debía declarar RLE (la negociada)');
    assert.strictEqual(Buffer.compare(guardado.datasetCrudo, externo.datasetCrudo), 0, 'el dataset guardado difiere del original');
    ok('Dataset guardado (con Pixel Data encapsulado) IDÉNTICO byte a byte al original; el File Meta que escribe el motor declara RLE');

    // Nivel de muestras, independiente de dcmjs y del renderer: RLE descomprimido == píxeles sin comprimir
    const elRle = Explicit.decodeDataset(externo.datasetCrudo);
    const elPlano = Explicit.decodeDataset(leerPart10(rutaPlano).datasetCrudo);
    const filas = elemento(elRle, '00280010').value; const cols = elemento(elRle, '00280011').value; const bits = elemento(elRle, '00280100').value;
    const pd = elemento(elRle, '7fe00010').value;
    assert.strictEqual(pd.encapsulado, true, 'el Pixel Data del RLE debía decodificarse como encapsulado');
    const descomprimido = Rle.descomprimirFrame(Buffer.concat(pd.fragmentos), filas * cols, bits);
    const original = elemento(elPlano, '7fe00010').value;
    assert.strictEqual(Buffer.compare(descomprimido, original), 0, 'las muestras descomprimidas difieren de las del archivo sin comprimir');
    ok(`Muestras: RleCodec descomprime el RLE externo (${filas}x${cols}, ${bits} bits) a EXACTAMENTE los mismos ${original.length} bytes del MR_small sin comprimir`);

    estudioB = limpiarUid(elemento(elRle, '0020000d').value);
    const series = await httpJson(`${base}/studies/${estudioB}/series`);
    assert.strictEqual(series.length, 1, 'QIDO-RS debía ver 1 serie');
    serieB = series[0]['0020000E'].Value[0];
    const inst = await httpJson(`${base}/studies/${estudioB}/series/${serieB}/instances`);
    assert.ok(inst.some((i) => i['00080018'].Value[0] === externo.sopInstanceUID), 'QIDO-RS no lista la instancia RLE');
    ok('QIDO-RS indexa la instancia RLE bajo su Study/Series Instance UID reales (dcmjs parsea el Part10 con Transfer Syntax RLE)');

    const r = await httpGet(`${base}/studies/${estudioB}/series/${serieB}/instances/${externo.sopInstanceUID}/rendered`);
    assert.strictEqual(r.status, 200, `/rendered respondió ${r.status}: ${r.body.toString().slice(0, 200)}`);
    const referencia = renderizarInstanciaAPng(rutaPlano);
    assert.strictEqual(Buffer.compare(r.body, referencia), 0, '/rendered del RLE no es idéntico al del archivo sin comprimir');
    ok('WADO-RS /rendered del RLE ingresado por DIMSE: PNG BYTE A BYTE idéntico al del archivo sin comprimir (antes: 4087/4096 píxeles distintos, con status 200)');
  });

  // ── C1) 8 bits grande, dataset fragmentado en PDUs de 4096 bytes ──
  await escenario('C1) 8 bits, PDUs fragmentados', async () => {
    const F = 256; const C = 256; const centro = 100; const ancho = 150;
    const px = muestras8(C, F);
    const frame = Rle.comprimirFrame(px, 8, C);
    const sop = '1.2.826.0.1.3680043.99999.702'; const est = '1.2.826.0.1.3680043.99999.700'; const ser = '1.2.826.0.1.3680043.99999.701';
    const ds = datasetSintetico({ sopUID: sop, studyUID: est, seriesUID: ser, filas: F, columnas: C, bits: 8, fragmentosPixel: [frame], centro, ancho });
    const st = await cStore(sesion, 1, MR_STORAGE, sop, ds, 4096);
    assert.strictEqual(st.status, DIMSE.STATUS.SUCCESS, `C-STORE status 0x${(st.status || 0).toString(16)}`);
    assert.ok(st.pdus >= 3, `se esperaba fragmentación real (≥3 PDUs), hubo ${st.pdus}`);
    assert.strictEqual(Buffer.compare(leerPart10(rutaAlmacenada(ALMACEN, sop)).datasetCrudo, ds), 0, 'el dataset reensamblado difiere del enviado');
    ok(`C-STORE de ${ds.length} bytes en ${st.pdus} P-DATA-TF de 4096: reensamblado SUCCESS y dataset guardado idéntico (el RLE comprimió ${px.length} → ${frame.length} bytes)`);
    const r = await httpGet(`${base}/studies/${est}/series/${ser}/instances/${sop}/rendered`);
    assert.strictEqual(r.status, 200, `/rendered respondió ${r.status}: ${r.body.toString().slice(0, 200)}`);
    const esperado = valoresDe(px, 8).map((v) => aGris8(v, centro, ancho));
    const cmp = compararPng(r.body, esperado, C, F);
    assert.ok(cmp.ok, cmp.motivo);
    ok('/rendered 8 bits (256×256, ventana C=100/W=150 con saturación en ambos extremos): los 65.536 píxeles coinciden con el esperado calculado desde las muestras originales');
  });

  // ── C2) 16 bits, dimensiones impares, 3 frames que difieren ──
  await escenario('C2) 16 bits multiframe', async () => {
    const F = 29; const C = 37; const centro = 1500; const ancho = 3000;
    const frames = [0, 1, 2].map((f) => muestras16(C, F, f));
    const sop = '1.2.826.0.1.3680043.99999.712'; const est = '1.2.826.0.1.3680043.99999.710'; const ser = '1.2.826.0.1.3680043.99999.711';
    const ds = datasetSintetico({ sopUID: sop, studyUID: est, seriesUID: ser, filas: F, columnas: C, bits: 16, numFrames: 3, fragmentosPixel: frames.map((p) => Rle.comprimirFrame(p, 16, C)), centro, ancho });
    const st = await cStore(sesion, 1, MR_STORAGE, sop, ds);
    assert.strictEqual(st.status, DIMSE.STATUS.SUCCESS);
    const guardado = leerPart10(rutaAlmacenada(ALMACEN, sop));
    assert.strictEqual(Buffer.compare(guardado.datasetCrudo, ds), 0);
    const pd = elemento(Explicit.decodeDataset(guardado.datasetCrudo), '7fe00010').value;
    assert.ok(pd.encapsulado && pd.fragmentos.length === 3, `se esperaban 3 fragmentos, hay ${pd.fragmentos && pd.fragmentos.length}`);
    ok('C-STORE de RLE multiframe (3 frames, 16 bits, 37×29): guardado idéntico y el codec propio lee de vuelta los 3 fragmentos');
    const r = await httpGet(`${base}/studies/${est}/series/${ser}/instances/${sop}/rendered`);
    assert.strictEqual(r.status, 200, `/rendered respondió ${r.status}: ${r.body.toString().slice(0, 200)}`);
    const esperado = valoresDe(frames[0], 16).map((v) => aGris8(v, centro, ancho));
    const cmp = compararPng(r.body, esperado, C, F);
    assert.ok(cmp.ok, cmp.motivo);
    ok('/rendered multiframe: renderiza el PRIMER frame (los otros 2 difieren, se distinguiría) con los 1.073 píxeles exactos, dimensiones impares incluidas');
  });

  // ── C3) un frame partido en 2 fragmentos ──
  await escenario('C3) frame en 2 fragmentos', async () => {
    const F = 29; const C = 37; const centro = 1500; const ancho = 3000;
    const px = muestras16(C, F, 0);
    const frame = Rle.comprimirFrame(px, 16, C);
    assert.strictEqual(frame.length % 2, 0, 'un frame RLE siempre tiene longitud par');
    const corte = Math.floor(frame.length / 4) * 2; // par, aprox. mitad
    const sop = '1.2.826.0.1.3680043.99999.722'; const est = '1.2.826.0.1.3680043.99999.720'; const ser = '1.2.826.0.1.3680043.99999.721';
    const ds = datasetSintetico({ sopUID: sop, studyUID: est, seriesUID: ser, filas: F, columnas: C, bits: 16, fragmentosPixel: [frame.slice(0, corte), frame.slice(corte)], centro, ancho });
    const st = await cStore(sesion, 1, MR_STORAGE, sop, ds);
    assert.strictEqual(st.status, DIMSE.STATUS.SUCCESS);
    const r = await httpGet(`${base}/studies/${est}/series/${ser}/instances/${sop}/rendered`);
    assert.strictEqual(r.status, 200, `/rendered respondió ${r.status}: ${r.body.toString().slice(0, 200)}`);
    const cmp = compararPng(r.body, valoresDe(px, 16).map((v) => aGris8(v, centro, ancho)), C, F);
    assert.ok(cmp.ok, cmp.motivo);
    ok(`/rendered de UN frame RLE partido en 2 fragmentos de Pixel Data (corte en el byte ${corte} de ${frame.length}): se concatenan y los píxeles coinciden exacto`);
  });

  // ── E) RLE corrupto: frame truncado ──
  await escenario('E) RLE corrupto', async () => {
    const F = 29; const C = 37;
    const frame = Rle.comprimirFrame(muestras16(C, F, 0), 16, C);
    const truncado = frame.slice(0, frame.length - 20); // longitud sigue par; el último segmento queda corto
    const sop = '1.2.826.0.1.3680043.99999.732'; const est = '1.2.826.0.1.3680043.99999.730'; const ser = '1.2.826.0.1.3680043.99999.731';
    const ds = datasetSintetico({ sopUID: sop, studyUID: est, seriesUID: ser, filas: F, columnas: C, bits: 16, fragmentosPixel: [truncado], centro: 1500, ancho: 3000 });
    const st = await cStore(sesion, 1, MR_STORAGE, sop, ds);
    assert.strictEqual(st.status, DIMSE.STATUS.SUCCESS, 'el motor guarda lo que llega: el contenido comprimido se valida al interpretarlo, no al recibirlo');
    const r = await httpGet(`${base}/studies/${est}/series/${ser}/instances/${sop}/rendered`);
    assert.strictEqual(r.status, 422, `un frame RLE truncado debía dar 422, dio ${r.status} (${r.tipo})`);
    assert.ok(/RLE|segmento|PackBits/i.test(JSON.parse(r.body.toString()).error), `el motivo no menciona RLE: ${r.body.toString().slice(0, 200)}`);
    ok(`Frame RLE truncado (${frame.length} → ${truncado.length} bytes): /rendered responde 422 con el motivo ("${JSON.parse(r.body.toString()).error.slice(0, 90)}…") — nunca una imagen incorrecta`);
  });

  // cierre limpio de la asociación
  sesion.socket.write(PDU.encodeReleaseRQ());
  await sesion.nextPdu();
  sesion.socket.end();

  // ── D) Puerta etiquetada: Transfer Syntax sin decoder ──
  await escenario('D) Transfer Syntax sin decoder', async () => {
    assert.ok(datasetB && estudioB, 'depende del escenario B');
    const sopD = '1.2.826.0.1.3680043.99999.741';
    // El mismo dataset RLE del escenario B, pero el File Meta declara JPEG Baseline: el renderer debe
    // negarse por la Transfer Syntax declarada, sin intentar decodificar ni inventar una imagen.
    const parte10 = buildStoredFile({ sopClassUID: sopClassB, sopInstanceUID: sopD, transferSyntaxUID: JPEG_BASELINE, implementationClassUID: '1.2.840.99999.1.1', datasetBuf: datasetB });
    const archivoRel = `${sopD.replace(/[^0-9.]/g, '_')}.dcm`;
    fs.writeFileSync(path.join(ALMACEN, archivoRel), parte10);
    const lectura = extractTagsWithDcmjs(parte10);
    assert.ok(lectura.ok, 'dcmjs debía poder leer el Part10 para indexarlo: ' + lectura.motivo);
    StudyIndex.indexarInstancia({ archivoRelativo: archivoRel, sopInstanceUID: sopD, tags: lectura.dataset }, path.join(ALMACEN, '.study-index.json'));

    const r = await httpGet(`${base}/studies/${estudioB}/series/${serieB}/instances/${sopD}/rendered`);
    assert.strictEqual(r.status, 422, `se esperaba 422, llegó ${r.status}`);
    const motivo = JSON.parse(r.body.toString()).error;
    assert.ok(/JPEG Baseline/.test(motivo) && motivo.includes(JPEG_BASELINE), `el motivo debía nombrar la Transfer Syntax: ${motivo}`);
    ok(`Transfer Syntax sin decoder: /rendered responde 422 nombrando "JPEG Baseline" y su UID — no una imagen, no un 500`);

    const raw = await httpGet(`${base}/studies/${estudioB}/series/${serieB}/instances/${sopD}`);
    assert.strictEqual(raw.status, 200);
    assert.strictEqual(Buffer.compare(raw.body, parte10), 0);
    ok('WADO-RS sigue sirviendo el objeto crudo idéntico: el motor no interpreta lo que no sabe, pero tampoco lo oculta ni lo altera');
  });

  httpServer.close(); server.close();
  fs.rmSync(WORKDIR, { recursive: true, force: true });
  console.log(`\n=== RESULTADO RLE end-to-end: ${process.exitCode ? 'HAY FALLAS ARRIBA' : 'TODO PASÓ — RLE Lossless negociado, recibido por DIMSE, guardado, indexado y renderizado, con rechazos explícitos para lo que no se sabe interpretar'} ===`);
  process.exit(process.exitCode || 0);
}

main().catch((e) => { console.error('ERROR FATAL:', e); process.exit(1); });
