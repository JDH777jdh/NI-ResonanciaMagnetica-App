'use strict';
/**
 * AeRegistry.js — Registro de equipos DICOM (Application Entities).
 *
 * Esta es la "puerta etiquetada" para hardware: agregar un resonador, un TC,
 * una sala de rayos nueva, es escribir una entrada acá (o, en producción,
 * guardarla desde el panel de configuración React) — nunca tocar el motor.
 *
 * AssociationServer.js consulta este registro para decidir si acepta o
 * rechaza una asociación entrante, y con qué Transfer Syntaxes.
 */

const fs = require('fs');
const path = require('path');

const DEFAULT_PATH = path.join(__dirname, 'equipos.json');

const TransferSyntaxRegistry = require('../pdu/TransferSyntaxRegistry');
/* Derivado del registro real (TransferSyntaxRegistry.js, 31-ago-2026) — antes
   esta era una lista mantenida a mano, aparte del ternario que elegía codec en
   AssociationServer.js (dos lugares que había que sincronizar manualmente).
   Ahora hay una sola fuente de verdad: sumar una Transfer Syntax nueva es
   registrarla en TransferSyntaxRegistry.js, no tocar esta lista también. */
const TRANSFER_SYNTAXES_ESTANDAR = TransferSyntaxRegistry.listarSoportadas();

/** Semilla — se usa solo si equipos.json todavía no existe. */
const SEED_EQUIPOS = [
  { id: 'ct_sala1', nombre: 'TC Sala 1', aeTitle: 'CT_SALA1', ip: '192.168.1.21', port: 104, modalidad: 'TC', scp: true, scu: true, mwl: true, activo: true },
  { id: 'mr_sala1', nombre: 'RM Sala 1', aeTitle: 'MR_SALA1', ip: '192.168.1.22', port: 104, modalidad: 'RM', scp: true, scu: true, mwl: true, activo: true },
  { id: 'dx_sala1', nombre: 'RX Sala 1', aeTitle: 'DX_SALA1', ip: '192.168.1.23', port: 104, modalidad: 'RX', scp: true, scu: true, mwl: true, activo: true },
];

function cargar(rutaArchivo = DEFAULT_PATH) {
  if (!fs.existsSync(rutaArchivo)) {
    fs.writeFileSync(rutaArchivo, JSON.stringify(SEED_EQUIPOS, null, 2));
  }
  return JSON.parse(fs.readFileSync(rutaArchivo, 'utf8'));
}

function guardar(equipos, rutaArchivo = DEFAULT_PATH) {
  fs.writeFileSync(rutaArchivo, JSON.stringify(equipos, null, 2));
}

/** ¿Este AE Title que llama está autorizado, y con qué transfer syntaxes lo aceptamos? */
function buscarPorAeTitle(aeTitle, rutaArchivo = DEFAULT_PATH) {
  const equipos = cargar(rutaArchivo);
  return equipos.find((e) => e.aeTitle === aeTitle && e.activo) || null;
}

function agregarEquipo(equipo, rutaArchivo = DEFAULT_PATH) {
  const equipos = cargar(rutaArchivo);
  if (equipos.some((e) => e.aeTitle === equipo.aeTitle)) {
    throw new Error(`Ya existe un equipo con AE Title "${equipo.aeTitle}"`);
  }
  equipos.push({ activo: true, transferSyntaxesSoportadas: TRANSFER_SYNTAXES_ESTANDAR, ...equipo });
  guardar(equipos, rutaArchivo);
  return equipos;
}

function actualizarEquipo(id, cambios, rutaArchivo = DEFAULT_PATH) {
  const equipos = cargar(rutaArchivo);
  const idx = equipos.findIndex((e) => e.id === id);
  if (idx === -1) throw new Error(`Equipo "${id}" no encontrado`);
  equipos[idx] = { ...equipos[idx], ...cambios };
  guardar(equipos, rutaArchivo);
  return equipos[idx];
}

function eliminarEquipo(id, rutaArchivo = DEFAULT_PATH) {
  const equipos = cargar(rutaArchivo).filter((e) => e.id !== id);
  guardar(equipos, rutaArchivo);
  return equipos;
}

module.exports = { TRANSFER_SYNTAXES_ESTANDAR, cargar, guardar, buscarPorAeTitle, agregarEquipo, actualizarEquipo, eliminarEquipo, DEFAULT_PATH };
