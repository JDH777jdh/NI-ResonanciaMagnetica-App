'use strict';
/**
 * PngEncoder.js — codificador PNG propio, mínimo, escrito byte a byte —
 * misma filosofía que PDU.js para DICOM: nada de librerías de imagen de
 * terceros para esto, es protocolo de formato de archivo, no lógica clínica.
 *
 * Alcance de esta primera versión (puerta etiquetada):
 *   - Escala de grises de 8 bits (ColorType 0, BitDepth 8) — cubre el caso
 *     real hoy: CT/MR/CR/DX/etc. son monocromos.
 *   - Sin interlace, sin paleta, filtro de fila "None" siempre — el PNG
 *     resultante es 100% válido igual, solo comprime un poco menos de lo
 *     que comprimiría con un filtro adaptativo (Paeth, etc.) — no vale la
 *     pena esa complejidad para imágenes médicas que ya son razonablemente
 *     uniformes por región.
 *   - RGB de 8 bits queda para cuando haya que renderizar algo a color
 *     (ecografía Doppler, por ejemplo) — no se usa todavía.
 *
 * La compresión DEFLATE la hace el zlib nativo de Node (zlib.deflateSync) —
 * reimplementar DEFLATE no tiene sentido, es la misma frontera que ya usa
 * el resto del proyecto (Node puro para protocolo, dcmjs solo para lo
 * semántico del dataset).
 *
 * Referencia: especificación pública del formato PNG (W3C/ISO 15948),
 * incluyendo el algoritmo de CRC32 del Anexo D, reproducido acá tal cual.
 */
const zlib = require('zlib');

const PNG_SIGNATURE = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);

const COLOR_TYPE = { GRAYSCALE: 0, RGB: 2 };

// --- CRC32 estándar de PNG ---
let TABLA_CRC = null;
function construirTablaCrc() {
  const tabla = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
    tabla[n] = c >>> 0;
  }
  return tabla;
}
function crc32(buf) {
  if (!TABLA_CRC) TABLA_CRC = construirTablaCrc();
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) c = TABLA_CRC[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

/** Un chunk PNG: [longitud(4)] [tipo(4) ascii] [data] [crc32(4) sobre tipo+data] */
function chunk(tipo, data) {
  const tipoBuf = Buffer.from(tipo, 'ascii');
  const out = Buffer.alloc(4 + 4 + data.length + 4);
  out.writeUInt32BE(data.length, 0);
  tipoBuf.copy(out, 4);
  data.copy(out, 8);
  out.writeUInt32BE(crc32(out.subarray(4, 8 + data.length)), 8 + data.length);
  return out;
}

function ihdr(width, height, bitDepth, colorType) {
  const data = Buffer.alloc(13);
  data.writeUInt32BE(width, 0);
  data.writeUInt32BE(height, 4);
  data.writeUInt8(bitDepth, 8);
  data.writeUInt8(colorType, 9);
  data.writeUInt8(0, 10); // método de compresión — el estándar solo define el 0 (deflate)
  data.writeUInt8(0, 11); // método de filtro — el estándar solo define el 0
  data.writeUInt8(0, 12); // interlace — 0 = ninguno (no Adam7)
  return chunk('IHDR', data);
}

/**
 * Codifica una imagen en escala de grises de 8 bits.
 * @param {Buffer|Uint8Array} pixeles8 - width*height bytes, fila por fila, 1 byte/píxel, 0=negro..255=blanco
 * @param {number} width
 * @param {number} height
 * @returns {Buffer} PNG completo, listo para escribir a disco o mandar por HTTP
 */
function codificarGrises8(pixeles8, width, height) {
  const total = width * height;
  if (pixeles8.length !== total) throw new Error(`codificarGrises8: se esperaban ${total} bytes (${width}x${height}), llegaron ${pixeles8.length}`);
  const buf = Buffer.isBuffer(pixeles8) ? pixeles8 : Buffer.from(pixeles8);

  // "raw" = lo que entra a DEFLATE: cada fila lleva 1 byte de tipo de filtro adelante
  const filaConFiltro = 1 + width;
  const raw = Buffer.alloc(height * filaConFiltro);
  for (let y = 0; y < height; y++) {
    const inicio = y * filaConFiltro;
    raw[inicio] = 0; // filtro "None"
    buf.copy(raw, inicio + 1, y * width, y * width + width);
  }

  const comprimido = zlib.deflateSync(raw); // stream zlib completo (header+adler32) — exactamente lo que PNG espera en IDAT

  return Buffer.concat([
    PNG_SIGNATURE,
    ihdr(width, height, 8, COLOR_TYPE.GRAYSCALE),
    chunk('IDAT', comprimido),
    chunk('IEND', Buffer.alloc(0)),
  ]);
}

module.exports = { codificarGrises8, crc32, PNG_SIGNATURE };
