'use strict';
/**
 * RenderInstance.js — motor de WADO-RS /rendered: toma un archivo Part10 ya
 * guardado en el almacén y lo convierte en un PNG de 8 bits, con windowing.
 * Usa dcmjs para el parseo semántico del dataset (Rows, Columns, PixelData,
 * etc.) — el mismo dcmjs que ya usa CStoreDataset.js para indexar, no una
 * librería nueva.
 *
 * Por qué existe: hoy, para ver una imagen desde un visor externo simple (o
 * para una miniatura en un sistema de terceros), hay que traer el DICOM
 * completo y decodificarlo — WADO-RS /rendered evita eso, el servidor ya
 * entrega un PNG listo para un <img src>.
 *
 * Alcance de esta primera versión (puerta etiquetada, no fingido):
 *   - Solo escala de grises (MONOCHROME1/MONOCHROME2) — es lo único que el
 *     motor recibe hoy de verdad (CT/MR/CR/DX). RGB/YBR (ecografía Doppler
 *     a color, por ejemplo) lanza un error explícito, no una imagen
 *     incorrecta en silencio.
 *   - Solo el primer frame — no soporta cine/multiframe todavía.
 *   - BitsAllocated 8 o 16, con o sin signo (PixelRepresentation).
 *   - Transfer Syntax: sin comprimir (Implicit/Explicit VR LE) y RLE Lossless
 *     (1.2.840.10008.1.2.5, desde 18-oct-2026 — se descomprime con
 *     RleCodec.js antes del windowing). Cualquier otra Transfer Syntax sin
 *     decoder (JPEG, JPEG-LS, JPEG 2000) lanza un error explícito: nunca se
 *     interpretan bytes comprimidos como si fueran píxeles.
 *   - Windowing: usa WindowCenter/WindowWidth del dataset si existen —
 *     misma fórmula lineal (PS3.3 C.11.2.1.2) que aplicarVentana() en
 *     HIS-RIS-PACS.jsx, a propósito, para que cliente y servidor rindan
 *     igual. Si no existen, hace auto-ventana con el mínimo/máximo real de
 *     la imagen (mismo criterio que cualquier visor sin VOI LUT declarada).
 */
const fs = require('fs');
const dcmjs = require('dcmjs');
const { codificarGrises8 } = require('./PngEncoder');
const TransferSyntaxRegistry = require('../pdu/TransferSyntaxRegistry');
const Rle = require('../pdu/RleCodec');

const RLE_LOSSLESS_UID = '1.2.840.10008.1.2.5';

function primerValor(x) {
  if (Array.isArray(x)) return x.length ? Number(x[0]) : undefined;
  return x == null ? undefined : Number(x);
}

// Misma fórmula que aplicarVentana() en HIS-RIS-PACS.jsx — a propósito, no reinventada acá.
function aplicarVentana(x, center, width) {
  const w = Math.max(width, 1);
  if (x <= center - 0.5 - (w - 1) / 2) return 0;
  if (x > center - 0.5 + (w - 1) / 2) return 255;
  return ((x - (center - 0.5)) / (w - 1) + 0.5) * 255;
}

/**
 * Devuelve el Pixel Data del primer frame como muestras PLANAS (ArrayBuffer),
 * que es lo que el resto de renderizarInstanciaAPng ya sabe interpretar —
 * sin importar si el archivo llegó sin comprimir o con RLE.
 *
 * Por qué existe (18-oct-2026): desde que el motor negocia RLE Lossless y
 * guarda imágenes con esa Transfer Syntax, dcmjs entrega el Pixel Data tal
 * como vino en el archivo — es decir, los bytes COMPRIMIDOS. Antes de este
 * paso esos bytes se leían como si fueran muestras planas: /rendered
 * respondía 200 con una imagen equivocada pero de aspecto plausible (medido
 * sobre MR_small_RLE.dcm real: 72 valores de gris distintos contra 204 de la
 * imagen correcta) — el peor tipo de falla, la que no avisa.
 * Ahora: RLE se descomprime con RleCodec.js; lo sin comprimir pasa tal cual;
 * cualquier otra Transfer Syntax sin decoder lanza un error explícito (el
 * handler de DicomWebServer lo convierte en 422 con el motivo).
 */
function _pixelDataPlano(dicomDict, ds, rows, cols, bitsAlojados) {
  const entrada = dicomDict.meta && dicomDict.meta['00020010']; // (0002,0010) Transfer Syntax UID del File Meta
  const tsUid = entrada && entrada.Value && entrada.Value.length
    ? String(entrada.Value[0]).replace(/\0+$/, '').trim()
    : null;
  // Un Part10 sin Transfer Syntax en el File Meta no es conforme; el motor siempre
  // escribe el suyo (CStoreDataset.buildFileMetaGroup), así que esto solo cubre
  // archivos ajenos — se conserva el comportamiento de siempre (muestras planas).
  if (!tsUid) return ds.PixelData[0];

  if (!TransferSyntaxRegistry.estaSoportada(tsUid)) {
    const info = TransferSyntaxRegistry.info(tsUid);
    throw new Error(`Transfer Syntax ${info ? `"${info.nombre}" ` : ''}(${tsUid}) sin decoder de Pixel Data en este motor — /rendered no puede interpretarla (puerta etiquetada, ver TransferSyntaxRegistry.js).`);
  }
  if (tsUid !== RLE_LOSSLESS_UID) return ds.PixelData[0]; // Implicit/Explicit VR LE: ya viene plano

  // RLE Lossless. Un frame RLE puede venir partido en varios fragmentos
  // (PS3.5 A.4.2): para un solo frame se concatenan todos; para multiframe solo
  // se acepta el caso un-fragmento-por-frame, y solo se renderiza el primero.
  const numFrames = Number(primerValor(ds.NumberOfFrames)) || 1;
  const fragmentos = ds.PixelData.map((ab) => Buffer.from(ab));
  let frameComprimido;
  if (numFrames === 1) frameComprimido = Buffer.concat(fragmentos);
  else if (fragmentos.length === numFrames) frameComprimido = fragmentos[0];
  else throw new Error(`RLE multiframe: ${fragmentos.length} fragmentos para ${numFrames} frames (algún frame viene partido en varios) — no soportado todavía en /rendered.`);

  const plano = Rle.descomprimirFrame(frameComprimido, rows * cols, bitsAlojados);
  return plano.buffer.slice(plano.byteOffset, plano.byteOffset + plano.byteLength);
}

/**
 * @param {string} rutaArchivo - ruta absoluta al .dcm ya guardado por C-STORE
 * @returns {Buffer} PNG de 8 bits listo para servir
 */
function renderizarInstanciaAPng(rutaArchivo) {
  const buf = fs.readFileSync(rutaArchivo);
  const arrayBuffer = buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength);
  const dicomDict = dcmjs.data.DicomMessage.readFile(arrayBuffer);
  const ds = dcmjs.data.DicomMetaDictionary.naturalizeDataset(dicomDict.dict);

  const rows = primerValor(ds.Rows);
  const cols = primerValor(ds.Columns);
  if (!rows || !cols) throw new Error('El dataset no trae Rows/Columns válidos — no se puede renderizar.');

  const fotometria = (ds.PhotometricInterpretation || '').toUpperCase().trim();
  if (fotometria && !fotometria.startsWith('MONOCHROME')) {
    throw new Error(`PhotometricInterpretation "${ds.PhotometricInterpretation}" no soportada todavía — /rendered hoy solo cubre escala de grises (MONOCHROME1/MONOCHROME2).`);
  }

  if (!ds.PixelData || !ds.PixelData[0]) throw new Error('El dataset no trae Pixel Data.');
  const bitsAlojados = primerValor(ds.BitsAllocated) || 16;
  // Muestras PLANAS del primer frame: sin comprimir pasa tal cual; con RLE se descomprime (ver _pixelDataPlano).
  const crudo = _pixelDataPlano(dicomDict, ds, rows, cols, bitsAlojados);
  const conSigno = primerValor(ds.PixelRepresentation) === 1;
  const slope = ds.RescaleSlope != null ? primerValor(ds.RescaleSlope) : 1;
  const intercept = ds.RescaleIntercept != null ? primerValor(ds.RescaleIntercept) : 0;

  const totalPixeles = rows * cols;
  const muestras = new Float64Array(totalPixeles);
  if (bitsAlojados === 8) {
    const vista = new Uint8Array(crudo);
    for (let i = 0; i < totalPixeles; i++) muestras[i] = vista[i] * slope + intercept;
  } else {
    const vista = conSigno ? new Int16Array(crudo) : new Uint16Array(crudo);
    for (let i = 0; i < totalPixeles; i++) muestras[i] = vista[i] * slope + intercept;
  }

  let center = primerValor(ds.WindowCenter);
  let width = primerValor(ds.WindowWidth);
  if (center == null || width == null || !isFinite(width) || width <= 0) {
    let min = Infinity, max = -Infinity;
    for (let i = 0; i < totalPixeles; i++) { if (muestras[i] < min) min = muestras[i]; if (muestras[i] > max) max = muestras[i]; }
    center = (min + max) / 2;
    width = Math.max(max - min, 1);
  }

  const invertir = fotometria === 'MONOCHROME1'; // en MONOCHROME1, 0 = blanco (al revés del caso normal)
  const salida8 = Buffer.alloc(totalPixeles);
  for (let i = 0; i < totalPixeles; i++) {
    let v = aplicarVentana(muestras[i], center, width);
    if (invertir) v = 255 - v;
    salida8[i] = Math.round(Math.max(0, Math.min(255, v)));
  }

  return codificarGrises8(salida8, cols, rows);
}

module.exports = { renderizarInstanciaAPng };
