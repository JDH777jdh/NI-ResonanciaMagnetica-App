'use strict';
/**
 * EncapsulatedDocument.js — envuelve un PDF (u otro documento) como objeto
 * DICOM válido (Encapsulated PDF Storage), para que viva en el mismo almacén
 * y comparta Study Instance UID con las imágenes del mismo evento clínico.
 *
 * Primer caso de uso: consentimiento informado (§ dossier "Integración Agenda
 * Web con RIS/PACS con consentimiento informado", 31-jul-2026) — el pipeline
 * completo descrito ahí (FESpa → RIS → FESpro → sellado → DICOM) termina acá:
 * este módulo es el paso final, "Conversión DICOM", de la Fase 4 de ese
 * documento.
 *
 * SOP Class UID verificado contra el estándar oficial y contra conformance
 * statements reales (Zeiss, Philips, GE) antes de usarlo:
 *   Encapsulated PDF Storage = 1.2.840.10008.5.1.4.1.1.104.1
 *
 * Tags elegidos verificando contra el estándar (PS3.3 Anexo A.45.1, tabla
 * C.24-2) y contra qué campos exige de verdad un visor real (RadiAnt) para
 * mostrar el documento sin errores — no son solo los mínimos "legales", son
 * los que hacen que el objeto se vea bien en un visor de producción.
 *
 * Alcance de esta primera versión (puerta etiquetada):
 *   - Un documento = una instancia DICOM completa (sin multi-page especial;
 *     un PDF de varias páginas va completo en un solo objeto, que es como
 *     realmente funciona el estándar — PDF ya maneja sus propias páginas).
 *   - Solo `application/pdf`. Video (Photographic Image, otro SOP Class,
 *     ya verificado también) y STL quedan para cuando haga falta.
 */
const ExplicitVR = require('../pdu/ExplicitVrCodec');

const ENCAPSULATED_PDF_SOP_CLASS = '1.2.840.10008.5.1.4.1.1.104.1';

function fechaHoraActualDicom() {
  const ahora = new Date();
  const fecha = ahora.toISOString().slice(0, 10).replace(/-/g, '');
  const hora = ahora.toISOString().slice(11, 19).replace(/:/g, '');
  return { fecha, hora };
}

/**
 * Construye el dataset DICOM (array de {tag,vr,value}) de un Encapsulated PDF.
 *
 * @param {Object} datos
 * @param {Buffer} datos.pdfBytes - el PDF tal cual, sin modificar
 * @param {string} datos.patientName - formato DICOM "Apellido^Nombre"
 * @param {string} datos.patientID - normalmente el RUT o el CUP
 * @param {string} datos.studyInstanceUID - EL MISMO que las imágenes del evento clínico
 * @param {string} datos.seriesInstanceUID - propio de esta "serie de documentos"
 * @param {string} datos.sopInstanceUID
 * @param {string} [datos.accessionNumber]
 * @param {string} [datos.documentTitle]
 * @param {boolean} [datos.verificado] - false mientras solo firmó el paciente (FESpa,
 *   "UNVERIFIED"); true cuando el profesional también firmó (FESpro, "VERIFIED") —
 *   mapeo directo al VerificationFlag real del estándar, no inventado para esto.
 * @param {number} [datos.seriesNumber] - por convención, fuera del rango de series de
 *   imagen (900+) para que no se confunda con una serie de cortes en el visor
 * @param {number} [datos.instanceNumber]
 */
function construirDatasetEncapsulado(datos) {
  const {
    pdfBytes, patientName, patientID, studyInstanceUID, seriesInstanceUID, sopInstanceUID,
    accessionNumber = '', documentTitle = 'Documento clinico', verificado = false,
    seriesNumber = 900, instanceNumber = 1,
  } = datos;

  if (!Buffer.isBuffer(pdfBytes)) throw new Error('pdfBytes debe ser un Buffer con el PDF real');
  if (pdfBytes.slice(0, 5).toString('ascii') !== '%PDF-') throw new Error('pdfBytes no parece un PDF válido (falta el encabezado %PDF-)');
  for (const campo of ['patientName', 'patientID', 'studyInstanceUID', 'seriesInstanceUID', 'sopInstanceUID']) {
    if (!datos[campo]) throw new Error(`construirDatasetEncapsulado: falta "${campo}"`);
  }

  const { fecha, hora } = fechaHoraActualDicom();

  return [
    // SOP Common
    { tag: '00080016', vr: 'UI', value: ENCAPSULATED_PDF_SOP_CLASS },
    { tag: '00080018', vr: 'UI', value: sopInstanceUID },
    // Patient
    { tag: '00100010', vr: 'PN', value: patientName },
    { tag: '00100020', vr: 'LO', value: patientID },
    // General Study
    { tag: '0020000D', vr: 'UI', value: studyInstanceUID },
    { tag: '00080050', vr: 'SH', value: accessionNumber },
    { tag: '00080020', vr: 'DA', value: fecha },
    { tag: '00080030', vr: 'TM', value: hora },
    // Encapsulated Document Series
    { tag: '0020000E', vr: 'UI', value: seriesInstanceUID },
    { tag: '00080060', vr: 'CS', value: 'DOC' }, // Modality = Document, convención del estándar para esto
    { tag: '00200011', vr: 'IS', value: String(seriesNumber) },
    // Encapsulated Document (PS3.3 tabla C.24-2)
    { tag: '00080023', vr: 'DA', value: fecha },   // Content Date
    { tag: '00080033', vr: 'TM', value: hora },    // Content Time
    { tag: '00200013', vr: 'IS', value: String(instanceNumber) },
    { tag: '00080064', vr: 'CS', value: 'WSD' },   // Conversion Type: Workstation (generado por software, no escaneado)
    { tag: '00420010', vr: 'ST', value: documentTitle },
    { tag: '00420011', vr: 'OB', value: pdfBytes }, // el PDF completo, sin modificar
    { tag: '00420012', vr: 'LO', value: 'application/pdf' },
    { tag: '00420013', vr: 'CS', value: verificado ? 'VERIFIED' : 'UNVERIFIED' },
    { tag: '00280301', vr: 'CS', value: 'YES' }, // Burned In Annotation: el documento SÍ muestra datos del paciente visualmente
  ];
}

function construirDatasetEncapsuladoBuffer(datos) {
  return ExplicitVR.encodeDataset(construirDatasetEncapsulado(datos));
}

module.exports = { construirDatasetEncapsulado, construirDatasetEncapsuladoBuffer, ENCAPSULATED_PDF_SOP_CLASS };
