'use strict';
/**
 * WorklistStore.js — persistencia real del Worklist que el motor consulta.
 *
 * Por qué existe (26-ago-2026): hasta hoy, `worklistProvider` — el gancho
 * que responde el C-FIND de Modality Worklist en AssociationServer.js —
 * siempre recibía un array hardcodeado, en los 5 tests y en cualquier uso
 * real. Nunca leía datos reales. Del otro lado, `guardarYEnviar()` en
 * HIS-RIS-PACS.jsx simulaba con un `setTimeout` que "llegó" el C-STORE del
 * equipo. Eran dos simulaciones que nunca se tocaron entre sí.
 *
 * Esto es lo que le da al motor un lugar real de dónde leer el Worklist —
 * mismo patrón que ya usa StudyIndex.js: JSON en disco, sin base de datos
 * nueva, coherente con el resto del proyecto.
 *
 * Stub honesto a propósito (mismo principio que EventBus y el check digit
 * de CUP en HIS-RIS-PACS.jsx): forma y firma reales — listar/agregar/
 * actualizar/buscar — para que cuando el DatabaseService.js real de MAIN
 * exista, reemplazar esto sea una línea, no una reescritura.
 *
 * Forma de un registro (mismos campos que _handleCFindWorklist ya espera
 * de cada item del Worklist, más fase/estado para el ciclo de vida):
 *   { id, fase, estado, nombre, cup, acc, ot, fechaAAAAMMDD, horaHHMM,
 *     modalidad, estudio }
 */

const fs = require('fs');
const path = require('path');

const DEFAULT_STORE_PATH = path.join(__dirname, 'worklist-store.json');

function _leer(rutaArchivo) {
  if (!fs.existsSync(rutaArchivo)) return { registros: [] };
  return JSON.parse(fs.readFileSync(rutaArchivo, 'utf8'));
}
function _guardar(datos, rutaArchivo) {
  fs.mkdirSync(path.dirname(rutaArchivo), { recursive: true });
  fs.writeFileSync(rutaArchivo, JSON.stringify(datos, null, 2));
}

/** Todos los registros, sin filtrar. */
function listar(rutaArchivo = DEFAULT_STORE_PATH) {
  return _leer(rutaArchivo).registros;
}

/** Solo los que están en una fase dada — el provider por defecto de
    AssociationServer.js usa esto filtrado por "worklist" para el C-FIND real. */
function listarPorFase(fase, rutaArchivo = DEFAULT_STORE_PATH) {
  return listar(rutaArchivo).filter((r) => r.fase === fase);
}

/**
 * Agrega un registro nuevo. `id` se genera solo si no se pasa uno.
 * `fase`/`estado` por defecto quedan en "worklist"/"arribado" — el punto
 * de entrada más común (equivalente a un paciente que ya completó Admisión
 * y está esperando el examen).
 */
function agregar(registro, rutaArchivo = DEFAULT_STORE_PATH) {
  const datos = _leer(rutaArchivo);
  // El id SIEMPRE queda como string, sin importar el camino de entrada
  // (POST puede traer un id numérico en el body; PUT/upsert siempre lo
  // saca de la URL, que ya es string). Consistencia de tipo acá evita que
  // comparaciones `r.id === id` fallen en silencio más adelante por un
  // number vs. string que deberían ser "el mismo" id.
  const id = registro.id != null ? String(registro.id) : `wl_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  const nuevo = { fase: 'worklist', estado: 'arribado', ...registro, id };
  datos.registros.push(nuevo);
  _guardar(datos, rutaArchivo);
  return nuevo;
}

/** Modifica un registro existente por id. Devuelve null si no existe. */
function actualizar(id, cambios, rutaArchivo = DEFAULT_STORE_PATH) {
  const idStr = String(id); // mismo criterio: comparar siempre como string, todos los ids guardados ya lo son
  const datos = _leer(rutaArchivo);
  const idx = datos.registros.findIndex((r) => r.id === idStr);
  if (idx === -1) return null;
  datos.registros[idx] = { ...datos.registros[idx], ...cambios };
  _guardar(datos, rutaArchivo);
  return datos.registros[idx];
}

/**
 * Busca por Accession Number (0008,0050). Es el campo correcto para amarrar
 * "llegó la imagen de este paciente en particular": un equipo real copia el
 * Accession Number que vio en la respuesta MWL hacia el C-STORE que manda
 * después — así es como de verdad se vincula la orden con el resultado en
 * un flujo DICOM real (PS3.4), no por Study Instance UID ni por nombre.
 */
function buscarPorAcc(acc, rutaArchivo = DEFAULT_STORE_PATH) {
  if (!acc) return null;
  return listar(rutaArchivo).find((r) => r.acc === acc) || null;
}

/**
 * Inserta si el id no existe, reemplaza completo si ya existe — pensado
 * para poblar datos de semilla (SEED) desde el cliente sin duplicar si
 * se llama más de una vez (ej. el componente se vuelve a montar).
 * A diferencia de `actualizar()` (que solo mezcla los campos que le pasás),
 * `upsert()` REEMPLAZA el registro completo — coherente con la semántica
 * HTTP de PUT que expone WorklistApiServer.js para esto.
 */
function upsert(registro, rutaArchivo = DEFAULT_STORE_PATH) {
  if (registro.id == null) throw new Error('upsert() necesita un id explícito — a diferencia de agregar(), no genera uno solo');
  const id = String(registro.id); // mismo criterio que agregar(): el id siempre queda como string
  const datos = _leer(rutaArchivo);
  const idx = datos.registros.findIndex((r) => r.id === id);
  if (idx === -1) {
    const nuevo = { fase: 'worklist', estado: 'arribado', ...registro, id };
    datos.registros.push(nuevo);
    _guardar(datos, rutaArchivo);
    return { registro: nuevo, creado: true };
  }
  datos.registros[idx] = { fase: 'worklist', estado: 'arribado', ...registro, id };
  _guardar(datos, rutaArchivo);
  return { registro: datos.registros[idx], creado: false };
}

module.exports = { listar, listarPorFase, agregar, actualizar, buscarPorAcc, upsert, DEFAULT_STORE_PATH };
