'use strict';
/**
 * StudyIndex.js — índice consultable de estudios/series/instancias.
 *
 * El almacén (`almacenPath`) solo tiene archivos .dcm sueltos por SOPInstanceUID
 * — no es buscable por sí mismo. Este índice es lo que hace posible QIDO-RS
 * (buscar) sin tener que abrir y parsear cada .dcm en cada búsqueda.
 *
 * Se alimenta en el mismo momento en que AssociationServer.js recibe un
 * C-STORE y ya parseó el dataset con dcmjs — no hay un segundo proceso
 * escaneando el disco por atrás.
 */

const fs = require('fs');
const path = require('path');

const DEFAULT_INDEX_PATH = path.join(__dirname, 'study-index.json');

function _leerIndice(rutaIndice) {
  if (!fs.existsSync(rutaIndice)) return { estudios: {} };
  return JSON.parse(fs.readFileSync(rutaIndice, 'utf8'));
}
function _guardarIndice(indice, rutaIndice) {
  fs.mkdirSync(path.dirname(rutaIndice), { recursive: true });
  fs.writeFileSync(rutaIndice, JSON.stringify(indice, null, 2));
}

/**
 * Se llama justo después de un C-STORE exitoso con los tags que dcmjs
 * pudo leer. Si dcmjs no está instalado (tags=null), igual se registra
 * la instancia con lo mínimo que sí tenemos del comando DIMSE, para no
 * perder la referencia al archivo.
 */
function indexarInstancia({ archivoRelativo, sopInstanceUID, tags }, rutaIndice = DEFAULT_INDEX_PATH) {
  const indice = _leerIndice(rutaIndice);
  const studyUID = (tags && tags.studyInstanceUID) || 'DESCONOCIDO';
  const seriesUID = (tags && tags.seriesInstanceUID) || 'DESCONOCIDO';

  if (!indice.estudios[studyUID]) {
    indice.estudios[studyUID] = {
      studyInstanceUID: studyUID,
      patientName: (tags && tags.patientName) || null,
      patientID: (tags && tags.patientID) || null,
      accessionNumber: (tags && tags.accessionNumber) || null,
      modalidades: [],
      series: {},
    };
  }
  const estudio = indice.estudios[studyUID];
  if (tags && tags.modality && !estudio.modalidades.includes(tags.modality)) estudio.modalidades.push(tags.modality);

  if (!estudio.series[seriesUID]) {
    estudio.series[seriesUID] = { seriesInstanceUID: seriesUID, modalidad: (tags && tags.modality) || null, instancias: [] };
  }
  estudio.series[seriesUID].instancias.push({ sopInstanceUID, archivoRelativo });

  _guardarIndice(indice, rutaIndice);
  return estudio;
}

/** QIDO-RS a nivel estudio: filtra por PatientID / AccessionNumber / Modality (parámetros típicos de PS3.18 §6.7.1). */
function buscarEstudios(filtros = {}, rutaIndice = DEFAULT_INDEX_PATH) {
  const indice = _leerIndice(rutaIndice);
  return Object.values(indice.estudios).filter((e) => {
    if (filtros.PatientID && e.patientID !== filtros.PatientID) return false;
    if (filtros.AccessionNumber && e.accessionNumber !== filtros.AccessionNumber) return false;
    if (filtros.ModalitiesInStudy && !e.modalidades.includes(filtros.ModalitiesInStudy)) return false;
    return true;
  });
}

function buscarSeries(studyInstanceUID, rutaIndice = DEFAULT_INDEX_PATH) {
  const indice = _leerIndice(rutaIndice);
  const estudio = indice.estudios[studyInstanceUID];
  return estudio ? Object.values(estudio.series) : [];
}

function buscarInstancia(sopInstanceUID, rutaIndice = DEFAULT_INDEX_PATH) {
  const indice = _leerIndice(rutaIndice);
  for (const estudio of Object.values(indice.estudios)) {
    for (const serie of Object.values(estudio.series)) {
      const inst = serie.instancias.find((i) => i.sopInstanceUID === sopInstanceUID);
      if (inst) return { ...inst, studyInstanceUID: estudio.studyInstanceUID, seriesInstanceUID: serie.seriesInstanceUID };
    }
  }
  return null;
}

module.exports = { indexarInstancia, buscarEstudios, buscarSeries, buscarInstancia, DEFAULT_INDEX_PATH };
