'use strict';
/**
 * ImplicitVrCodec.js — codec de datasets en Implicit VR Little Endian (PS3.5 §6.2.2)
 * con soporte real de Secuencias (VR=SQ), no solo elementos planos.
 *
 * Esto es lo que faltaba del Modality Worklist: Scheduled Station AE Title,
 * Modality, fecha/hora, etc. no van sueltos — van DENTRO de un Item de la
 * secuencia Scheduled Procedure Step Sequence (0040,0100), como exige PS3.4
 * Anexo K. Acá se arma esa anidación de verdad.
 *
 * Se usa longitud DEFINIDA en todos los niveles (no longitud indefinida +
 * Delimitation Item) — es una de las dos formas igual de válidas que permite
 * el estándar, y evita la complejidad extra del ítem delimitador.
 */

const SQ_ITEM_TAG = { group: 0xfffe, element: 0xe000 };
const VrLimits = require('./VrLimits');

/** value: string (UI/PN/etc, VR "plano") | Buffer (VR binario, ej. Pixel Data) | array de datasets anidados (VR "SQ"). */
function encodeElement(group, element, vr, value) {
  let valueBuf;
  if (vr === 'SQ') {
    const items = (value || []).map((nestedDataset) => {
      const nestedBuf = encodeDataset(nestedDataset);
      const itemHeader = Buffer.alloc(8);
      itemHeader.writeUInt16LE(SQ_ITEM_TAG.group, 0);
      itemHeader.writeUInt16LE(SQ_ITEM_TAG.element, 2);
      itemHeader.writeUInt32LE(nestedBuf.length, 4);
      return Buffer.concat([itemHeader, nestedBuf]);
    });
    valueBuf = Buffer.concat(items);
  } else if (Buffer.isBuffer(value)) {
    // VR binario (OB/OW/UN, ej. Pixel Data) — se usa tal cual, relleno con 0x00 (nunca espacio, eso es solo para texto).
    valueBuf = value.length % 2 !== 0 ? Buffer.concat([value, Buffer.from([0x00])]) : value;
  } else if (vr === 'US') {
    valueBuf = Buffer.alloc(2); valueBuf.writeUInt16LE(Number(value), 0);
  } else if (vr === 'UL') {
    valueBuf = Buffer.alloc(4); valueBuf.writeUInt32LE(Number(value), 0);
  } else if (vr === 'SS') {
    valueBuf = Buffer.alloc(2); valueBuf.writeInt16LE(Number(value), 0);
  } else if (vr === 'SL') {
    valueBuf = Buffer.alloc(4); valueBuf.writeInt32LE(Number(value), 0);
  } else if (vr === 'FL') {
    valueBuf = Buffer.alloc(4); valueBuf.writeFloatLE(Number(value), 0);
  } else if (vr === 'FD') {
    valueBuf = Buffer.alloc(8); valueBuf.writeDoubleLE(Number(value), 0);
  } else {
    const valorString = value == null ? '' : String(value);
    VrLimits.validarLongitudVR(vr, valorString, `tag (${group.toString(16).padStart(4, '0')},${element.toString(16).padStart(4, '0')})`);
    valueBuf = Buffer.from(valorString, 'ascii');
    if (valueBuf.length % 2 !== 0) valueBuf = Buffer.concat([valueBuf, Buffer.from([0x20])]); // pad con espacio (convención para strings)
  }
  const head = Buffer.alloc(8);
  head.writeUInt16LE(group, 0);
  head.writeUInt16LE(element, 2);
  head.writeUInt32LE(valueBuf.length, 4);
  return Buffer.concat([head, valueBuf]);
}

/**
 * dataset: array de { tag: "GGGGEEEE", vr: "UI"|"PN"|"DA"|"TM"|"US"|"SQ"|..., value }
 * Para "SQ", value es un array de datasets anidados (mismo formato, recursivo).
 */
function encodeDataset(dataset) {
  const parts = dataset
    .filter((el) => el.value !== undefined && el.value !== null)
    .map((el) => encodeElement(parseInt(el.tag.slice(0, 4), 16), parseInt(el.tag.slice(4, 8), 16), el.vr, el.value));
  return Buffer.concat(parts);
}

/** Decodificador simétrico — sirve para probar el round-trip sin depender de dcmjs. */
function decodeDataset(buf, knownSQTags = {}) {
  const result = [];
  let o = 0;
  while (o < buf.length) {
    const group = buf.readUInt16LE(o);
    const element = buf.readUInt16LE(o + 2);
    const length = buf.readUInt32LE(o + 4);
    const tag = group.toString(16).padStart(4, '0') + element.toString(16).padStart(4, '0');
    const valueBuf = buf.slice(o + 8, o + 8 + length);

    if (knownSQTags[tag]) {
      const items = [];
      let io = 0;
      while (io < valueBuf.length) {
        const itemGroup = valueBuf.readUInt16LE(io);
        const itemElement = valueBuf.readUInt16LE(io + 2);
        const itemLen = valueBuf.readUInt32LE(io + 4);
        if (itemGroup === SQ_ITEM_TAG.group && itemElement === SQ_ITEM_TAG.element) {
          items.push(decodeDataset(valueBuf.slice(io + 8, io + 8 + itemLen), knownSQTags));
        }
        io += 8 + itemLen;
      }
      result.push({ tag, vr: 'SQ', value: items });
    } else {
      result.push({ tag, vr: '??', value: valueBuf.toString('ascii').replace(/\s+$/, '') });
    }
    o += 8 + length;
  }
  return result;
}

module.exports = { encodeElement, encodeDataset, decodeDataset, SQ_ITEM_TAG };
