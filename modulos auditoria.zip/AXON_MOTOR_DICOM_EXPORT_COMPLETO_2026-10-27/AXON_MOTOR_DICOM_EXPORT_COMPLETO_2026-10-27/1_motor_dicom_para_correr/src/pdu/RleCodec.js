'use strict';
/**
 * RleCodec.js — RLE Lossless real (Transfer Syntax 1.2.840.10008.1.2.5),
 * PS3.5 Anexo G. Primer codec de Transfer Syntax COMPRIMIDA del motor —
 * candidata elegida desde hace varias sesiones precisamente por esto:
 * compresión sin pérdida a nivel de imagen, sin códec de video de por
 * medio (a diferencia de JPEG/JPEG2000/MPEG).
 *
 * Dos capas, cada una verificable por separado:
 *   1. PackBits (G.3) — el algoritmo de compresión byte a byte en sí,
 *      el mismo que usa TIFF PackBits. No sabe nada de DICOM ni de
 *      píxeles, solo comprime/descomprime un buffer de bytes.
 *   2. El "segmentado" específico de DICOM (G.5) — por qué una imagen de
 *      16 bits se parte en 2 segmentos (byte alto / byte bajo) en vez de
 *      comprimir los 2 bytes de cada muestra intercalados: intercalados,
 *      el byte bajo cambia demasiado entre píxeles vecinos (ruido) y
 *      comprime mal; separado por plano de bytes, el byte alto de una
 *      imagen médica suele repetirse mucho (grandes zonas del mismo
 *      "tono"), que es justamente lo que PackBits aprovecha.
 *
 * Alcance de esta versión (puerta etiquetada, no fingida): solo escala de
 * grises (1 muestra por píxel), 8 o 16 bits — es lo único que el motor
 * recibe hoy de verdad (igual alcance que RenderInstance.js). RGB/color
 * (3 muestras por píxel → 3 segmentos) queda para cuando haga falta.
 *
 * El encoder de PackBits de acá es greedy con una regla simple: una corrida
 * de 2+ bytes iguales al empezar un token se codifica como "replicate run",
 * pero una corrida literal en curso solo se interrumpe ante 3+ iguales (un
 * par aislado no vale el byte de control extra). Es correcto y comprime
 * bien, pero no es byte-óptimo — y NO existe un criterio canónico: RLE no
 * prescribe dónde cortar, y los 3 archivos reales con los que se validó
 * (generados por distintos encoders) no coinciden entre sí. Lo que define
 * la conformidad es que cualquier decoder recupere los píxeles exactos, y
 * eso se verificó en las dos direcciones (ver test/rle.e2e.test.js).
 * Mismo criterio que ya usa PngEncoder.js (filtro de fila siempre "None"):
 * no vale la pena más complejidad para imágenes médicas.
 */

// ───────────────────────── PackBits (PS3.5 G.3) ─────────────────────────

/**
 * Comprime un buffer de bytes planos con PackBits.
 * Byte de control N (interpretado como entero CON signo de 8 bits):
 *   0 a 127   -> literal: copiar los siguientes (N+1) bytes tal cual
 *   -1 a -127 -> replicate: el siguiente byte se repite (1-N) veces
 *   -128      -> no-op (no se genera acá, solo lo entiende el decoder)
 */
function packBitsComprimir(datos) {
  const salida = [];
  let i = 0;
  const n = datos.length;
  while (i < n) {
    // ¿Corrida de 2 o más bytes iguales empezando acá?
    let runLen = 1;
    while (i + runLen < n && datos[i + runLen] === datos[i] && runLen < 128) runLen++;

    if (runLen >= 2) {
      salida.push((256 - (runLen - 1)) & 0xff); // control = -(runLen-1) como byte sin signo
      salida.push(datos[i]);
      i += runLen;
    } else {
      // Acumular una corrida literal hasta la próxima corrida de 3+ iguales (o hasta 128 bytes).
      // Un par AISLADO de bytes iguales dentro de un literal NO lo interrumpe: cortar costaría
      // un byte de control extra para retomar el literal después. Con 3+ iguales sí conviene.
      // Medido contra 3 archivos RLE reales hechos por otros encoders (02-oct-2026): comprime
      // entre 0,6 % y 3,4 % mejor que cortar ante cualquier par, y en OBXXXX1A_rle.dcm
      // reproduce byte a byte lo que generó el encoder real.
      let j = i + 1;
      while (j < n && (j - i) < 128) {
        if (j + 2 < n && datos[j] === datos[j + 1] && datos[j] === datos[j + 2]) break; // viene una corrida de 3+ — cortar acá para que el próximo paso la capture
        j++;
      }
      const litLen = j - i;
      salida.push(litLen - 1);
      for (let k = i; k < j; k++) salida.push(datos[k]);
      i = j;
    }
  }
  return Buffer.from(salida);
}

/**
 * Descomprime PackBits. `longitudEsperada` corta la salida en el punto
 * justo — cualquier byte de relleno de alineación par que haya quedado
 * al final del segmento comprimido (ver EncapsulatedPixelData.js) se
 * ignora solo, porque el loop para apenas se completa la salida.
 */
function packBitsDescomprimir(buf, longitudEsperada) {
  const salida = Buffer.alloc(longitudEsperada);
  let oi = 0;
  let ii = 0;
  while (oi < longitudEsperada) {
    if (ii >= buf.length) throw new Error(`PackBits: se acabó el buffer de entrada (offset ${ii}) antes de completar la salida esperada (${longitudEsperada} bytes, van ${oi})`);
    const control = buf.readInt8(ii); ii++;
    if (control >= 0) {
      const litLen = control + 1;
      // Buffer.copy NO lanza error si el origen se acaba antes de tiempo — copia lo que haya
      // y sigue, dejando ceros: una imagen silenciosamente corrupta. Se valida explícito.
      if (ii + litLen > buf.length) throw new Error(`PackBits: corrida literal truncada — promete ${litLen} bytes y solo quedan ${buf.length - ii} de entrada`);
      if (oi + litLen > longitudEsperada) throw new Error(`PackBits: la corrida literal (${litLen} bytes) excede la salida esperada (${longitudEsperada} bytes, van ${oi}) — datos inconsistentes con las dimensiones declaradas`);
      buf.copy(salida, oi, ii, ii + litLen);
      ii += litLen; oi += litLen;
    } else if (control !== -128) {
      const repLen = 1 - control;
      if (ii >= buf.length) throw new Error('PackBits: corrida replicada sin su byte de valor (se acabó el buffer de entrada)');
      if (oi + repLen > longitudEsperada) throw new Error(`PackBits: la corrida replicada (${repLen} bytes) excede la salida esperada (${longitudEsperada} bytes, van ${oi}) — datos inconsistentes con las dimensiones declaradas`);
      salida.fill(buf[ii], oi, oi + repLen);
      ii++; oi += repLen;
    }
    // control === -128: no-op — no avanza oi, ii ya avanzó
  }
  return salida;
}

// ─────────────────── Frame RLE completo (PS3.5 G.2 / G.5) ───────────────────

const MAX_SEGMENTOS = 15; // límite real del formato: el header tiene exactamente 15 slots de offset

/** Arma el header de 64 bytes (nº de segmentos + hasta 15 offsets) + los segmentos comprimidos, uno atrás del otro. */
function _armarFrame(segmentosComprimidos) {
  if (segmentosComprimidos.length < 1 || segmentosComprimidos.length > MAX_SEGMENTOS) {
    throw new Error(`RLE: número de segmentos debe ser 1-${MAX_SEGMENTOS}, llegó ${segmentosComprimidos.length}`);
  }
  const header = Buffer.alloc(64);
  header.writeUInt32LE(segmentosComprimidos.length, 0);
  let offsetAcumulado = 64;
  for (let i = 0; i < segmentosComprimidos.length; i++) {
    header.writeUInt32LE(offsetAcumulado, 4 + i * 4);
    offsetAcumulado += segmentosComprimidos[i].length;
  }
  let frame = Buffer.concat([header, ...segmentosComprimidos]);
  if (frame.length % 2 !== 0) frame = Buffer.concat([frame, Buffer.from([0x00])]); // todo elemento/fragmento DICOM debe tener longitud par
  return frame;
}

/** Separa un frame RLE ya armado en sus segmentos comprimidos (sin descomprimirlos todavía). */
function _separarSegmentos(frameBuf) {
  const numSegmentos = frameBuf.readUInt32LE(0);
  if (numSegmentos < 1 || numSegmentos > MAX_SEGMENTOS) throw new Error(`RLE: cabecera de frame inválida — numSegmentos=${numSegmentos}`);
  const offsets = [];
  for (let i = 0; i < numSegmentos; i++) offsets.push(frameBuf.readUInt32LE(4 + i * 4));
  const segmentos = [];
  for (let i = 0; i < numSegmentos; i++) {
    const inicio = offsets[i];
    const fin = i + 1 < numSegmentos ? offsets[i + 1] : frameBuf.length;
    segmentos.push(frameBuf.slice(inicio, fin));
  }
  return segmentos;
}

/**
 * Comprime UN plano (segmento) fila por fila. Dos reglas del formato real,
 * confirmadas contra archivos RLE generados por otra implementación
 * (MR_small_RLE.dcm de pydicom, 02-oct-2026), no solo contra el texto del estándar:
 *   1. Cada fila se codifica POR SEPARADO — una corrida nunca cruza el límite de
 *      fila (misma regla que TIFF PackBits). Evidencia: en ese archivo el plano
 *      del byte bajo (64 columnas x 64 filas) pesa 4160 bytes = 64 filas x
 *      (1 byte de control + 64 literales); sin separar filas serían 4128.
 *   2. Cada segmento termina en longitud PAR (se agrega un 0x00 si hace falta) —
 *      los 4 archivos reales inspeccionados tienen todos sus segmentos pares.
 */
function _comprimirPlanoPorFilas(plano, columnas) {
  if (plano.length % columnas !== 0) throw new Error(`RLE: el plano tiene ${plano.length} bytes, no es múltiplo del ancho de fila (${columnas}) — filas incompletas`);
  const filas = [];
  for (let off = 0; off < plano.length; off += columnas) filas.push(packBitsComprimir(plano.slice(off, off + columnas)));
  let segmento = Buffer.concat(filas);
  if (segmento.length % 2 !== 0) segmento = Buffer.concat([segmento, Buffer.from([0x00])]);
  return segmento;
}

/**
 * Comprime un frame completo de píxeles en escala de grises (8 o 16 bits)
 * al formato RLE real de DICOM: header de 64 bytes + 1 segmento (8 bits)
 * o 2 segmentos byte-alto/byte-bajo (16 bits, PS3.5 G.5 — el byte alto va
 * SIEMPRE primero), cada segmento codificado fila por fila.
 * @param {Buffer} pixelBuf - muestras planas, little-endian si son de 16 bits
 * @param {number} bitsAlojados - 8 o 16
 * @param {number} columnas - ancho de fila en píxeles (el tag Columns) — hace falta
 *   porque las corridas no pueden cruzar filas, ver _comprimirPlanoPorFilas
 * @returns {Buffer} un frame RLE completo, listo para ser un fragmento
 */
function comprimirFrame(pixelBuf, bitsAlojados, columnas) {
  if (!Number.isInteger(columnas) || columnas < 1) throw new Error(`RLE: se necesita el ancho de fila (Columns) como entero positivo — llegó ${columnas}`);
  let segmentos;
  if (bitsAlojados === 8) {
    segmentos = [_comprimirPlanoPorFilas(pixelBuf, columnas)];
  } else if (bitsAlojados === 16) {
    if (pixelBuf.length % 2 !== 0) throw new Error('RLE 16 bits: el buffer de píxeles debe tener longitud par');
    const numPixeles = pixelBuf.length / 2;
    const msb = Buffer.alloc(numPixeles);
    const lsb = Buffer.alloc(numPixeles);
    for (let i = 0; i < numPixeles; i++) {
      const muestra = pixelBuf.readUInt16LE(i * 2);
      msb[i] = (muestra >> 8) & 0xff;
      lsb[i] = muestra & 0xff;
    }
    segmentos = [_comprimirPlanoPorFilas(msb, columnas), _comprimirPlanoPorFilas(lsb, columnas)]; // byte alto primero, PS3.5 G.5
  } else {
    throw new Error(`RLE: esta versión solo soporta escala de grises de 8 o 16 bits — llegó bitsAlojados=${bitsAlojados}`);
  }
  return _armarFrame(segmentos);
}

/**
 * Descomprime un frame RLE de vuelta a muestras planas.
 * @param {Buffer} frameBuf - el frame RLE completo (header + segmentos)
 * @param {number} numeroDePixeles
 * @param {number} bitsAlojados - 8 o 16 (debe coincidir con cómo se comprimió)
 * @returns {Buffer} muestras planas, little-endian si son de 16 bits — mismo formato que Pixel Data sin comprimir
 */
function descomprimirFrame(frameBuf, numeroDePixeles, bitsAlojados) {
  const segmentos = _separarSegmentos(frameBuf);
  if (bitsAlojados === 8) {
    if (segmentos.length !== 1) throw new Error(`RLE 8 bits: se esperaba 1 segmento, el frame trae ${segmentos.length}`);
    return packBitsDescomprimir(segmentos[0], numeroDePixeles);
  } else if (bitsAlojados === 16) {
    if (segmentos.length !== 2) throw new Error(`RLE 16 bits: se esperaban 2 segmentos (byte alto + byte bajo), el frame trae ${segmentos.length}`);
    const msb = packBitsDescomprimir(segmentos[0], numeroDePixeles);
    const lsb = packBitsDescomprimir(segmentos[1], numeroDePixeles);
    const salida = Buffer.alloc(numeroDePixeles * 2);
    for (let i = 0; i < numeroDePixeles; i++) salida.writeUInt16LE((msb[i] << 8) | lsb[i], i * 2);
    return salida;
  } else {
    throw new Error(`RLE: esta versión solo soporta escala de grises de 8 o 16 bits — llegó bitsAlojados=${bitsAlojados}`);
  }
}

module.exports = {
  packBitsComprimir, packBitsDescomprimir,
  comprimirFrame, descomprimirFrame,
  MAX_SEGMENTOS,
};
