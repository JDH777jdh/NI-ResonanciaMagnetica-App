'use strict';
/**
 * TransferSyntaxRegistry.js — un solo lugar para saber, de cualquier
 * Transfer Syntax UID: si el motor la soporta hoy, qué codec la maneja, y
 * si es una Transfer Syntax comprimida o no.
 *
 * Por qué existe (31-ago-2026): hasta hoy, decidir qué codec usar era un
 * ternario hardcodeado dentro de `_handleCFindWorklist` en
 * AssociationServer.js (`codec = transferSyntax === '...1.2.1' ? ExplicitVR
 * : ImplicitVR`), y la lista de "cuáles aceptamos" vivía aparte, en
 * `AeRegistry.TRANSFER_SYNTAXES_ESTANDAR` — dos lugares que había que
 * mantener sincronizados a mano. Con esto, agregar RLE (o cualquier codec
 * nuevo) es sumar una entrada acá, no tocar cada `if` que decide codec.
 * `AeRegistry.TRANSFER_SYNTAXES_ESTANDAR` ahora se DERIVA de este registro
 * (ver AeRegistry.js) — una sola fuente de verdad, no dos listas.
 *
 * Incluye a propósito Transfer Syntax que el estándar define pero que
 * este motor NO soporta todavía (`codec: null`) — mismo principio de
 * puerta etiquetada del resto del proyecto: decir explícitamente qué
 * existe y no tenemos, en vez de que solo aparezca lo que sí funciona.
 * Los UIDs de la sección "conocidas, no soportadas" se verificaron
 * cruzando varios conformance statements reales (Philips, GE HealthCare,
 * Canon Medical) y una propuesta de corrección oficial de DICOM — son de
 * uso extendido y estable en la industria, pero si en algún momento se
 * va a implementar alguna, hay que re-confirmar el UID exacto contra
 * PS3.5 Anexo A directo antes de darlo por bueno para código real.
 */
const ImplicitVR = require('./ImplicitVrCodec');
const ExplicitVR = require('./ExplicitVrCodec');

const REGISTRO = {
  // ── Soportadas hoy, de verdad (codec real, no solo negociadas) ──
  '1.2.840.10008.1.2': {
    nombre: 'Implicit VR Little Endian', comprimido: false, codec: ImplicitVR,
  },
  '1.2.840.10008.1.2.1': {
    nombre: 'Explicit VR Little Endian', comprimido: false, codec: ExplicitVR,
  },
  '1.2.840.10008.1.2.5': {
    nombre: 'RLE Lossless', comprimido: true, codec: ExplicitVR,
    nota: 'Soportada de verdad desde el 02-oct-2026 — primer codec comprimido real del motor. El framing del dataset es IDÉNTICO a Explicit VR LE (reutiliza el mismo codec acá), la única diferencia real es que Pixel Data viene encapsulado (Basic Offset Table + fragmentos, ver EncapsulatedPixelData.js) y comprimido con PackBits por segmento — 1 segmento para 8 bits, 2 (byte alto/byte bajo) para 16 bits, PS3.5 Anexo G. Esa parte la maneja RleCodec.js, no este registro ni ExplicitVrCodec.js.',
  },

  // ── Conocidas por el estándar, NO soportadas todavía (puerta etiquetada) ──
  '1.2.840.10008.1.2.2': {
    nombre: 'Explicit VR Big Endian', comprimido: false, codec: null,
    nota: 'Retirada del estándar en 2006 (PS3.5) — no vale la pena implementarla, casi ningún equipo moderno la ofrece.',
  },
  '1.2.840.10008.1.2.4.50': {
    nombre: 'JPEG Baseline (Process 1)', comprimido: true, codec: null,
    nota: 'La más ofrecida por equipo real que no soporta lossless — con pérdida, 8 bits.',
  },
  '1.2.840.10008.1.2.4.80': {
    nombre: 'JPEG-LS Lossless', comprimido: true, codec: null,
  },
  '1.2.840.10008.1.2.4.90': {
    nombre: 'JPEG 2000 Image Compression (Lossless Only)', comprimido: true, codec: null,
  },
  '1.2.840.10008.1.2.4.91': {
    nombre: 'JPEG 2000 Image Compression', comprimido: true, codec: null,
    nota: 'Con pérdida permitida — no confundir con la variante ".90" (solo sin pérdida).',
  },
};

/** ¿El motor sabe procesar de verdad esta Transfer Syntax? (tiene codec real, no solo una entrada de referencia) */
function estaSoportada(transferSyntaxUID) {
  const entrada = REGISTRO[transferSyntaxUID];
  return !!(entrada && entrada.codec);
}

/** Devuelve el codec (con encodeDataset/decodeDataset) para una Transfer Syntax soportada. Lanza si no lo está. */
function obtenerCodec(transferSyntaxUID) {
  const entrada = REGISTRO[transferSyntaxUID];
  if (!entrada || !entrada.codec) {
    const nombre = entrada ? entrada.nombre : 'desconocida';
    throw new Error(`Transfer Syntax "${transferSyntaxUID}" (${nombre}) no tiene codec soportado en este motor.`);
  }
  return entrada.codec;
}

/** Lista de UIDs con codec real — esto es lo que se ofrece/acepta en la negociación de asociación. */
function listarSoportadas() {
  return Object.keys(REGISTRO).filter((uid) => REGISTRO[uid].codec);
}

/** Info completa (nombre, comprimido, si está soportada) de cualquier UID conocido por el registro — null si ni siquiera es una de referencia. */
function info(transferSyntaxUID) {
  return REGISTRO[transferSyntaxUID] || null;
}

module.exports = { REGISTRO, estaSoportada, obtenerCodec, listarSoportadas, info };
