'use strict';
/**
 * VrLimits.js — límites de longitud por VR, verificados contra la fuente
 * primaria: DICOM PS3.5 2026c, Tabla 6.2-1 (dicom.nema.org/medical/dicom/
 * current/output/chtml/part05/sect_6.2.html), consultada el 31-ago-2026.
 *
 * Por qué existe: ni ImplicitVrCodec.js ni ExplicitVrCodec.js validaban
 * longitud al codificar — cualquier string, sin importar el VR, se
 * codificaba tal cual. Eso permitió que `makeACC()` en HIS-RIS-PACS.jsx
 * generara Accession Numbers de 17 caracteres (`ACC-2026-00000001`) para
 * un campo VR=SH cuyo máximo real es 16 — el bug pasó completamente
 * silencioso hasta que un test end-to-end lo hizo evidente (documentado
 * en el dossier maestro, hallazgo cruzado con el documento de arquitectura
 * externo recibido 30-ago-2026, que llegó a la misma conclusión).
 *
 * Alcance de esta validación (puerta etiquetada, no fingida):
 *   - Cubre los VRs de texto que los codecs codifican por la rama "string"
 *     genérica (AE, AS, CS, DA, DS, DT, IS, LO, LT, PN, SH, ST, TM, UI).
 *     UC/UR/UT tienen máximos definidos por el estándar como "2^32-2 bytes"
 *     — en la práctica ilimitados para cualquier uso real de este motor,
 *     así que no se validan (poner un número ahí sería un límite inventado
 *     nuestro, no uno real del estándar).
 *   - Valida el máximo (longitud de Value, antes del padding a longitud
 *     par que ya hace cada codec) — todos los máximos de la Tabla 6.2-1
 *     para estos VRs son números pares, por diseño del propio estándar,
 *     así que un valor exactamente en el máximo nunca necesita padding
 *     que lo empuje a excederlo.
 *   - No valida longitud MÍNIMA/fija para los VRs "fixed" (AS=4, DA=8,
 *     TM=14 con fracción, DT=26) — el objetivo es atrapar valores
 *     DEMASIADO LARGOS (la clase de bug real que encontramos), no exigir
 *     padding hacia arriba para valores cortos. Alcance deliberado, no
 *     una validación completa de conformidad.
 *   - No valida binarios (US/UL/SS/SL/FL/FD, ya se codifican con tamaño
 *     fijo por construcción propia) ni SQ/OB/OW (máximos de 2^32, jamás
 *     realistas de exceder en este proyecto).
 */

/** Máximo de caracteres (= bytes, dado que este motor solo codifica ASCII —
    no hay soporte de Specific Character Set multibyte todavía). */
const VR_MAX_LENGTH = {
  AE: 16,
  AS: 4,
  CS: 16,
  DA: 8,
  DS: 16,
  DT: 26,
  IS: 12,
  LO: 64,
  LT: 10240,
  PN: 64,
  SH: 16,
  ST: 1024,
  TM: 14,
  UI: 64,
};

/**
 * Lanza un error explícito si `valorString` excede el máximo real del VR
 * dado — mismo principio de "fallar con el motivo, no en silencio" que ya
 * usa el resto del proyecto (rechazo de Explicit VR no soportado, PDF
 * inválido en EncapsulatedDocument.js, etc.).
 *
 * @param {string} vr - VR de dos letras (ej. "SH")
 * @param {string} valorString - el valor YA convertido a string, antes del padding
 * @param {string} [contexto] - info opcional para el mensaje de error (ej. el tag)
 */
function validarLongitudVR(vr, valorString, contexto) {
  const max = VR_MAX_LENGTH[vr];
  if (max == null) return; // VR sin límite práctico definido acá (UC/UR/UT) o no es un VR de texto simple
  if (valorString.length > max) {
    const dondeStr = contexto ? ` (${contexto})` : '';
    throw new Error(
      `Valor VR=${vr}${dondeStr} tiene ${valorString.length} caracteres — excede el máximo de ${max} de PS3.5 Tabla 6.2-1. Valor: "${valorString}"`
    );
  }
}

module.exports = { VR_MAX_LENGTH, validarLongitudVR };
