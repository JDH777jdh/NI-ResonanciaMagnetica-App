'use strict';
/**
 * DimseCommand.js — Command Sets de PS3.7 (DIMSE Message Exchange).
 *
 * El Command Set SIEMPRE se codifica en Implicit VR Little Endian, sin
 * importar qué Transfer Syntax se haya negociado para el dataset clínico
 * (PS3.7 sección 6.3.1). Por eso este lector no necesita diccionario de VR
 * completo — solo necesita saber, para el puñado de tags de comando que
 * usamos, si el valor es un UID (string) o un entero de 16 bits (US).
 *
 * Verificado contra DocBookDICOM2026c (PS3.7, Anexo E — Command Fields).
 */

const COMMAND_FIELD = {
  C_STORE_RQ: 0x0001,
  C_STORE_RSP: 0x8001,
  C_GET_RQ: 0x0010,
  C_GET_RSP: 0x8010,
  C_FIND_RQ: 0x0020,
  C_FIND_RSP: 0x8020,
  C_MOVE_RQ: 0x0021,
  C_MOVE_RSP: 0x8021,
  C_ECHO_RQ: 0x0030,
  C_ECHO_RSP: 0x8030,
};

const STATUS = {
  SUCCESS: 0x0000,
  PENDING: 0xff00,
  CANCEL: 0xfe00,
  REFUSED_OUT_OF_RESOURCES: 0xa700,
  ERROR_SOP_CLASS_NOT_SUPPORTED: 0x0122,
};

/* Tags que manejamos, con su VR real (para saber cómo leer/escribir el valor). */
const TAG_VR = {
  '00000002': 'UI', // Affected SOP Class UID
  '00000003': 'UI', // Requested SOP Class UID
  '00000100': 'US', // Command Field
  '00000110': 'US', // Message ID
  '00000120': 'US', // Message ID Being Responded To
  '00000700': 'US', // Priority
  '00000800': 'US', // Data Set Type
  '00000900': 'US', // Status
  '00001000': 'UI', // Affected SOP Instance UID
};

function tagKey(group, element) {
  return group.toString(16).padStart(4, '0') + element.toString(16).padStart(4, '0');
}

/** Codifica un objeto {tagKey: value} como Implicit VR LE — usado para RQ y RSP. */
function encodeCommandSet(fields) {
  const elements = [];
  for (const [key, value] of Object.entries(fields)) {
    const group = parseInt(key.slice(0, 4), 16);
    const element = parseInt(key.slice(4, 8), 16);
    const vr = TAG_VR[key];
    let valueBuf;
    if (vr === 'UI') {
      valueBuf = Buffer.from(value, 'ascii');
      if (valueBuf.length % 2 !== 0) valueBuf = Buffer.concat([valueBuf, Buffer.from([0x00])]);
    } else if (vr === 'US') {
      valueBuf = Buffer.alloc(2);
      valueBuf.writeUInt16LE(value, 0);
    } else {
      throw new Error(`VR desconocido para tag ${key} — agregar a TAG_VR`);
    }
    const head = Buffer.alloc(8);
    head.writeUInt16LE(group, 0);
    head.writeUInt16LE(element, 2);
    head.writeUInt32LE(valueBuf.length, 4);
    elements.push(head, valueBuf);
  }
  const body = Buffer.concat(elements);
  // (0000,0000) Group Length — largo de todo lo que sigue en el grupo de comando
  const glHead = Buffer.alloc(8);
  glHead.writeUInt16LE(0x0000, 0);
  glHead.writeUInt16LE(0x0000, 2);
  glHead.writeUInt32LE(4, 4);
  const glVal = Buffer.alloc(4);
  glVal.writeUInt32LE(body.length, 0);
  return Buffer.concat([glHead, glVal, body]);
}

/** Decodifica un Command Set recibido (Implicit VR LE) a {tagKey: value}. */
function decodeCommandSet(buf) {
  const result = {};
  let o = 0;
  while (o < buf.length) {
    const group = buf.readUInt16LE(o);
    const element = buf.readUInt16LE(o + 2);
    const length = buf.readUInt32LE(o + 4);
    const valueBuf = buf.slice(o + 8, o + 8 + length);
    const key = tagKey(group, element);
    const vr = TAG_VR[key];
    if (vr === 'UI') result[key] = valueBuf.toString('ascii').replace(/\0+$/, '');
    else if (vr === 'US') result[key] = valueBuf.readUInt16LE(0);
    else if (key !== '00000000') result[key] = valueBuf; // desconocido: se guarda crudo, no se descarta
    o += 8 + length;
  }
  return result;
}

/** Azúcar sintáctica: arma un C-STORE-RSP de éxito respondiendo a un C-STORE-RQ ya decodificado. */
function buildCStoreResponse(rqCommand, status = STATUS.SUCCESS) {
  return encodeCommandSet({
    '00000002': rqCommand['00000002'], // mismo Affected SOP Class UID
    '00000100': COMMAND_FIELD.C_STORE_RSP,
    '00000120': rqCommand['00000110'], // Message ID Being Responded To = Message ID del RQ
    '00000800': 0x0101, // sin dataset en la respuesta
    '00000900': status,
    '00001000': rqCommand['00001000'], // mismo Affected SOP Instance UID
  });
}

/** Arma un C-FIND-RSP "Pending" con un item de worklist encontrado (el dataset va aparte, no acá). */
function buildCFindPendingResponse(rqCommand) {
  return encodeCommandSet({
    '00000002': rqCommand['00000002'],
    '00000100': COMMAND_FIELD.C_FIND_RSP,
    '00000120': rqCommand['00000110'],
    '00000800': 0x0102, // dataset presente (el identifier con los matches va en el siguiente PDV)
    '00000900': STATUS.PENDING,
  });
}
function buildCFindFinalResponse(rqCommand) {
  return encodeCommandSet({
    '00000002': rqCommand['00000002'],
    '00000100': COMMAND_FIELD.C_FIND_RSP,
    '00000120': rqCommand['00000110'],
    '00000800': 0x0101,
    '00000900': STATUS.SUCCESS,
  });
}

module.exports = {
  COMMAND_FIELD, STATUS, TAG_VR, tagKey,
  encodeCommandSet, decodeCommandSet,
  buildCStoreResponse, buildCFindPendingResponse, buildCFindFinalResponse,
};
