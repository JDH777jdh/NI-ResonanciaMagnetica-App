'use strict';
/**
 * ExplicitVrCodec.js — codec de datasets en Explicit VR Little Endian (PS3.5 §6.2.1)
 *
 * Por qué existe (23-jul-2026): probamos el motor contra DICOM reales (CT_small.dcm,
 * MR_small.dcm, del repositorio de test files de pydicom) y encontramos que vienen
 * codificados en Explicit VR LE, no Implicit — el mismo transfer syntax que ofrece
 * la inmensa mayoría del equipo real. Antes el motor lo rechazaba limpiamente en la
 * negociación (correcto, no corrompía nada) pero eso limitaba qué equipo real podía
 * conectarse de verdad. Ahora sí lo soporta.
 *
 * Diferencia real con Implicit VR (ver ImplicitVrCodec.js): acá el VR SÍ va en el
 * stream, como 2 caracteres ASCII justo después del tag — y el campo de longitud
 * cambia de tamaño según qué VR es:
 *   - "Forma corta" (la mayoría — UI, PN, DA, TM, CS, US, UL, SS, SL, FL, FD, etc.):
 *     Group(2) + Element(2) + VR(2) + Longitud(2) + Valor
 *   - "Forma larga" (OB, OW, OF, SQ, UN, UT, UC, UR — las que pueden ser grandes):
 *     Group(2) + Element(2) + VR(2) + Reservado(2) + Longitud(4) + Valor
 *
 * Ventaja real sobre el decodificador de Implicit VR: acá NO hace falta el
 * diccionario externo (knownSQTags) para saber qué es una secuencia — el propio
 * stream lo dice ("SQ" viene escrito ahí mismo). Una secuencia se reconoce sola.
 *
 * Los tags de Item (FFFE,E000), Item Delimitation (FFFE,E00D) y Sequence
 * Delimitation (FFFE,E0DD) son la única excepción real: por diseño del estándar,
 * ESOS tags nunca llevan VR explícito, ni siquiera en Explicit VR LE — siempre son
 * Group+Element+Longitud a secas, igual que en Implicit VR. Por eso el manejo de
 * items abajo lee esos 8 bytes directo, sin intentar leer un VR ahí.
 *
 * Alcance de esta versión (puerta etiquetada, no fingido):
 *   - Secuencias (SQ): soporta longitud DEFINIDA e INDEFINIDA (con Item/Sequence
 *     Delimitation real — se encuentra recorriendo elementos de verdad, no
 *     adivinando por bytes sueltos, así que secuencias anidadas dentro de items
 *     de longitud indefinida también funcionan).
 *   - Pixel Data (o cualquier otro OB/OW) con longitud INDEFINIDA — eso es
 *     encapsulado/comprimido (fragmentos + Basic Offset Table). Desde el
 *     02-oct-2026 esto SÍ se decodifica/codifica de forma genérica (ver
 *     EncapsulatedPixelData.js) — este archivo arma/lee el sobre (Items +
 *     delimitador), pero no sabe qué algoritmo comprimió cada fragmento.
 *     Interpretar esos bytes (ej. descomprimir RLE) es trabajo de quien
 *     llama (RleCodec.js); si nadie los interpreta, igual se devuelven
 *     los fragmentos crudos — nunca un valor vacío ni un crash silencioso.
 */

const SQ_ITEM_TAG = { group: 0xfffe, element: 0xe000 };
const SQ_ITEM_DELIM_TAG = { group: 0xfffe, element: 0xe00d };
const SQ_SEQ_DELIM_TAG = { group: 0xfffe, element: 0xe0dd };
const UNDEFINED_LENGTH = 0xffffffff;
const VrLimits = require('./VrLimits');
// Framing genérico de OB/OW encapsulado (Transfer Syntax comprimida) — 02-oct-2026,
// parte del trabajo de RLE end-to-end. Este archivo no sabe qué comprimió cada
// fragmento (eso es RleCodec.js); solo sabe partir/armar el sobre. Ver
// EncapsulatedPixelData.js para el porqué completo.
const EncapsulatedPixelData = require('./EncapsulatedPixelData');

// VRs de "forma larga": VR(2) + Reservado(2) + Longitud(4). Todo lo que no está
// acá usa "forma corta": VR(2) + Longitud(2), sin reservados.
const VR_FORMA_LARGA = new Set(['OB', 'OW', 'OF', 'OD', 'OL', 'SQ', 'UC', 'UR', 'UT', 'UN']);
function esFormaLarga(vr) { return VR_FORMA_LARGA.has(vr); }

// ───────────────────────── ENCODE ─────────────────────────

/** value: string (VR "plano") | Buffer (VR binario, ej. Pixel Data) | array de datasets anidados (VR "SQ"). */
function encodeElement(group, element, vr, value) {
  if (typeof vr !== 'string' || vr.length !== 2) {
    throw new Error(`VR inválido "${vr}" para tag (${group.toString(16)},${element.toString(16)}) — Explicit VR exige exactamente 2 caracteres`);
  }

  // Pixel Data (u otro OB/OW) encapsulado — Transfer Syntax comprimida
  // (RLE, JPEG...). Se reconoce por la FORMA del value (quien llama ya
  // armó los fragmentos, ej. con RleCodec.comprimirFrame), no por el tag —
  // este codec no decide solo si algo "debería" venir comprimido, 02-oct-2026.
  if (value && typeof value === 'object' && value.encapsulado === true) {
    if (vr !== 'OB' && vr !== 'OW') throw new Error(`Solo OB/OW pueden ir encapsulados — llegó VR=${vr}`);
    const valueBuf = EncapsulatedPixelData.armarValorEncapsulado(value.fragmentos);
    const tagBuf = Buffer.alloc(4);
    tagBuf.writeUInt16LE(group, 0);
    tagBuf.writeUInt16LE(element, 2);
    const vrBuf = Buffer.from(vr, 'ascii');
    const lenBuf = Buffer.alloc(6); // forma larga siempre — OB/OW ya lo son
    lenBuf.writeUInt32LE(EncapsulatedPixelData.UNDEFINED_LENGTH, 2); // longitud indefinida = "esto viene encapsulado"
    return Buffer.concat([tagBuf, vrBuf, lenBuf, valueBuf]);
  }

  let valueBuf;
  if (vr === 'SQ') {
    const items = (value || []).map((nestedDataset) => {
      const nestedBuf = encodeDataset(nestedDataset);
      const itemHeader = Buffer.alloc(8);
      itemHeader.writeUInt16LE(SQ_ITEM_TAG.group, 0);
      itemHeader.writeUInt16LE(SQ_ITEM_TAG.element, 2);
      itemHeader.writeUInt32LE(nestedBuf.length, 4);
      return Buffer.concat([itemHeader, nestedBuf]);
    });
    valueBuf = Buffer.concat(items);
  } else if (Buffer.isBuffer(value)) {
    valueBuf = value.length % 2 !== 0 ? Buffer.concat([value, Buffer.from([0x00])]) : value;
  } else if (vr === 'US') { valueBuf = Buffer.alloc(2); valueBuf.writeUInt16LE(Number(value), 0); }
  else if (vr === 'UL') { valueBuf = Buffer.alloc(4); valueBuf.writeUInt32LE(Number(value), 0); }
  else if (vr === 'SS') { valueBuf = Buffer.alloc(2); valueBuf.writeInt16LE(Number(value), 0); }
  else if (vr === 'SL') { valueBuf = Buffer.alloc(4); valueBuf.writeInt32LE(Number(value), 0); }
  else if (vr === 'FL') { valueBuf = Buffer.alloc(4); valueBuf.writeFloatLE(Number(value), 0); }
  else if (vr === 'FD') { valueBuf = Buffer.alloc(8); valueBuf.writeDoubleLE(Number(value), 0); }
  else {
    const valorString = value == null ? '' : String(value);
    VrLimits.validarLongitudVR(vr, valorString, `tag (${group.toString(16).padStart(4, '0')},${element.toString(16).padStart(4, '0')})`);
    valueBuf = Buffer.from(valorString, 'ascii');
    if (valueBuf.length % 2 !== 0) valueBuf = Buffer.concat([valueBuf, Buffer.from([0x20])]); // pad con espacio (convención para strings)
  }

  const tagBuf = Buffer.alloc(4);
  tagBuf.writeUInt16LE(group, 0);
  tagBuf.writeUInt16LE(element, 2);
  const vrBuf = Buffer.from(vr, 'ascii');

  let lenBuf;
  if (esFormaLarga(vr)) {
    lenBuf = Buffer.alloc(6); // 2 reservados (quedan en 0x0000) + 4 de longitud
    lenBuf.writeUInt32LE(valueBuf.length, 2);
  } else {
    lenBuf = Buffer.alloc(2);
    lenBuf.writeUInt16LE(valueBuf.length, 0);
  }
  return Buffer.concat([tagBuf, vrBuf, lenBuf, valueBuf]);
}

/**
 * dataset: array de { tag: "GGGGEEEE", vr: "UI"|"PN"|"DA"|"TM"|"US"|"SQ"|..., value }
 * Para "SQ", value es un array de datasets anidados (mismo formato, recursivo).
 */
function encodeDataset(dataset) {
  const parts = dataset
    .filter((el) => el.value !== undefined && el.value !== null)
    .map((el) => encodeElement(parseInt(el.tag.slice(0, 4), 16), parseInt(el.tag.slice(4, 8), 16), el.vr, el.value));
  return Buffer.concat(parts);
}

// ───────────────────────── DECODE ─────────────────────────

/** Decodifica UN elemento explicit-VR a partir del offset o. Devuelve { tag, vr, value, nextOffset }. */
function decodeElementAt(buf, o) {
  const group = buf.readUInt16LE(o);
  const element = buf.readUInt16LE(o + 2);
  const tag = group.toString(16).padStart(4, '0') + element.toString(16).padStart(4, '0');
  const vr = buf.slice(o + 4, o + 6).toString('ascii');

  let length, valueOffset;
  if (esFormaLarga(vr)) {
    length = buf.readUInt32LE(o + 8); // salta VR(2) + reservado(2)
    valueOffset = o + 12;
  } else {
    length = buf.readUInt16LE(o + 6); // salta VR(2)
    valueOffset = o + 8;
  }

  if (vr === 'SQ') {
    const { items, endOffset } = decodeSequenceValue(buf, valueOffset, length);
    return { tag, vr: 'SQ', value: items, nextOffset: endOffset };
  }

  if (length === UNDEFINED_LENGTH) {
    if (vr === 'OB' || vr === 'OW') {
      // Pixel Data (u otro OB/OW) encapsulado — Transfer Syntax comprimida.
      // Acá solo se lee el sobre (Basic Offset Table + fragmentos); qué
      // algoritmo comprimió cada fragmento (RLE, JPEG...) lo decide quien
      // llama, no este codec — 02-oct-2026, ver EncapsulatedPixelData.js.
      const { basicOffsetTable, fragmentos, nextOffset } = EncapsulatedPixelData.decodificarValorEncapsulado(buf, valueOffset);
      return { tag, vr, value: { encapsulado: true, basicOffsetTable, fragmentos }, nextOffset };
    }
    throw new Error(`Elemento (${tag}) VR=${vr} con longitud indefinida fuera de una secuencia — solo OB/OW pueden venir encapsulados, este VR no.`);
  }

  const valueBuf = buf.slice(valueOffset, valueOffset + length);
  let value;
  if (vr === 'OB' || vr === 'OW' || vr === 'OF' || vr === 'UN') {
    value = valueBuf; // binario crudo (ej. Pixel Data) — se entrega tal cual
  } else if (vr === 'US') {
    value = valueBuf.readUInt16LE(0);
  } else if (vr === 'UL') {
    value = valueBuf.readUInt32LE(0);
  } else if (vr === 'SS') {
    value = valueBuf.readInt16LE(0);
  } else if (vr === 'SL') {
    value = valueBuf.readInt32LE(0);
  } else if (vr === 'FL') {
    value = valueBuf.readFloatLE(0);
  } else if (vr === 'FD') {
    value = valueBuf.readDoubleLE(0);
  } else {
    value = valueBuf.toString('ascii').replace(/\s+$/, '');
  }
  return { tag, vr, value, nextOffset: valueOffset + length };
}

/** Decodifica el contenido de una secuencia (SQ): sus Items, con longitud definida o indefinida. */
function decodeSequenceValue(buf, offset, seqLength) {
  const items = [];
  let io = offset;
  const hardEnd = seqLength === UNDEFINED_LENGTH ? buf.length : offset + seqLength;

  while (io < hardEnd) {
    const itemGroup = buf.readUInt16LE(io);
    const itemElement = buf.readUInt16LE(io + 2);
    const itemLength = buf.readUInt32LE(io + 4);

    if (itemGroup === SQ_SEQ_DELIM_TAG.group && itemElement === SQ_SEQ_DELIM_TAG.element) {
      io += 8;
      break;
    }
    const itemContentStart = io + 8;
    let itemContentEnd;
    if (itemLength === UNDEFINED_LENGTH) {
      itemContentEnd = findItemDelimitation(buf, itemContentStart);
      io = itemContentEnd + 8; // más allá del propio Item Delimitation Item
    } else {
      itemContentEnd = itemContentStart + itemLength;
      io = itemContentEnd;
    }
    items.push(decodeDataset(buf.slice(itemContentStart, itemContentEnd)));
  }
  return { items, endOffset: seqLength === UNDEFINED_LENGTH ? io : offset + seqLength };
}

/** Encuentra dónde termina un Item de longitud indefinida recorriendo elementos reales
    (nunca adivinando por bytes sueltos) hasta toparse con el Item Delimitation Item. */
function findItemDelimitation(buf, offset) {
  let o = offset;
  while (o < buf.length) {
    const g = buf.readUInt16LE(o);
    const e = buf.readUInt16LE(o + 2);
    if (g === SQ_ITEM_DELIM_TAG.group && e === SQ_ITEM_DELIM_TAG.element) return o;
    ({ nextOffset: o } = decodeElementAt(buf, o));
  }
  return o;
}

function decodeDataset(buf) {
  const result = [];
  let o = 0;
  while (o < buf.length) {
    const { tag, vr, value, nextOffset } = decodeElementAt(buf, o);
    result.push({ tag, vr, value });
    o = nextOffset;
  }
  return result;
}

module.exports = { encodeElement, encodeDataset, decodeDataset, decodeElementAt, esFormaLarga, SQ_ITEM_TAG, UNDEFINED_LENGTH };
