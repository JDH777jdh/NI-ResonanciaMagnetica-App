'use strict';
/**
 * EncapsulatedPixelData.js — framing genérico de Pixel Data (u otro OB/OW)
 * encapsulado, PS3.5 Anexo A.4: Basic Offset Table + uno o más fragmentos,
 * terminado con Sequence Delimitation Item.
 *
 * Por qué existe (02-oct-2026, parte del trabajo de RLE end-to-end): hasta
 * hoy, ExplicitVrCodec.decodeElementAt rechazaba cualquier OB/OW con
 * longitud indefinida ("Transfer Syntax que este motor no soporta
 * todavía") — correcto mientras no había ningún codec comprimido, pero
 * ahora que RLE Lossless sí tiene uno (ver RleCodec.js), hace falta saber
 * leer/escribir el "sobre" que usa CUALQUIER Transfer Syntax comprimida
 * para Pixel Data.
 *
 * Separación de responsabilidades a propósito (mismo patrón que ya usa
 * todo el proyecto — PDU.js no sabe de DIMSE, DimseCommand.js no sabe de
 * PDU): este archivo NO sabe qué algoritmo comprimió cada fragmento. Solo
 * sabe partir/armar el sobre: dónde empieza y termina cada Item. Qué
 * significan los bytes de adentro (ej. descomprimir RLE con PackBits) es
 * trabajo de quien llama (RleCodec.js, o mañana un codec de JPEG/JPEG2000).
 *
 * Los tags de Item (FFFE,E000) y Sequence Delimitation (FFFE,E0DD) son los
 * MISMOS que ya usa ExplicitVrCodec.js para framing de secuencias (SQ) —
 * el estándar reutiliza literalmente la misma sintaxis de ítem para ambos
 * casos (PS3.5 §7.5 nota: el framing de Pixel Data encapsulado "follows
 * the Data Element structure of... Item"). No hace falta inventar tags
 * nuevos, son los de siempre.
 *
 * Alcance de esta versión (puerta etiquetada, no fingida): un frame = un
 * fragmento (sin fragmentar un frame grande en varios Items, algo común
 * en JPEG de alta resolución pero no necesario para las imágenes de un
 * solo corte que maneja hoy el motor). La Basic Offset Table se arma
 * siempre vacía (longitud 0) — válida por estándar para un objeto de un
 * solo frame (PS3.5 A.4), que es el único caso real hoy.
 */

const ITEM_TAG = { group: 0xfffe, element: 0xe000 };
const SEQ_DELIM_TAG = { group: 0xfffe, element: 0xe0dd };
const UNDEFINED_LENGTH = 0xffffffff;

function _itemHeader(longitud) {
  const h = Buffer.alloc(8);
  h.writeUInt16LE(ITEM_TAG.group, 0);
  h.writeUInt16LE(ITEM_TAG.element, 2);
  h.writeUInt32LE(longitud, 4);
  return h;
}

function _delimitadorHeader() {
  const h = Buffer.alloc(8);
  h.writeUInt16LE(SEQ_DELIM_TAG.group, 0);
  h.writeUInt16LE(SEQ_DELIM_TAG.element, 2);
  h.writeUInt32LE(0, 4); // longitud del delimitador siempre 0
  return h;
}

/**
 * Arma el VALOR completo (sin tag/VR/longitud del elemento en sí — eso lo
 * arma ExplicitVrCodec.encodeElement) de un OB/OW encapsulado: Basic
 * Offset Table vacía + un Item por fragmento + delimitador de secuencia.
 * @param {Buffer[]} fragmentos - uno por frame, en este alcance (§ arriba)
 */
function armarValorEncapsulado(fragmentos) {
  if (!Array.isArray(fragmentos) || fragmentos.length === 0) {
    throw new Error('armarValorEncapsulado: se necesita al menos 1 fragmento');
  }
  const bot = _itemHeader(0); // Basic Offset Table vacía — válida para un solo frame, PS3.5 A.4
  const partes = fragmentos.map((frag) => {
    const fragPar = frag.length % 2 !== 0 ? Buffer.concat([frag, Buffer.from([0x00])]) : frag; // cada Item debe tener longitud par
    return Buffer.concat([_itemHeader(fragPar.length), fragPar]);
  });
  return Buffer.concat([bot, ...partes, _delimitadorHeader()]);
}

/**
 * Decodifica el valor de un elemento OB/OW encapsulado a partir del offset
 * donde empieza el primer Item (la Basic Offset Table). Devuelve
 * { basicOffsetTable: Buffer, fragmentos: Buffer[], nextOffset }.
 */
function decodificarValorEncapsulado(buf, offset) {
  let o = offset;

  const botGroup = buf.readUInt16LE(o);
  const botElement = buf.readUInt16LE(o + 2);
  if (botGroup !== ITEM_TAG.group || botElement !== ITEM_TAG.element) {
    throw new Error(`Se esperaba un Item (Basic Offset Table) en offset ${o}, llegó (${botGroup.toString(16)},${botElement.toString(16)})`);
  }
  const botLen = buf.readUInt32LE(o + 4);
  const basicOffsetTable = buf.slice(o + 8, o + 8 + botLen);
  o += 8 + botLen;

  const fragmentos = [];
  while (true) {
    const g = buf.readUInt16LE(o);
    const e = buf.readUInt16LE(o + 2);
    if (g === SEQ_DELIM_TAG.group && e === SEQ_DELIM_TAG.element) {
      o += 8;
      break;
    }
    if (g !== ITEM_TAG.group || e !== ITEM_TAG.element) {
      throw new Error(`Se esperaba un Item de fragmento o el delimitador de secuencia en offset ${o}, llegó (${g.toString(16).padStart(4, '0')},${e.toString(16).padStart(4, '0')})`);
    }
    const len = buf.readUInt32LE(o + 4);
    fragmentos.push(buf.slice(o + 8, o + 8 + len));
    o += 8 + len;
  }
  return { basicOffsetTable, fragmentos, nextOffset: o };
}

module.exports = { armarValorEncapsulado, decodificarValorEncapsulado, ITEM_TAG, SEQ_DELIM_TAG, UNDEFINED_LENGTH };
