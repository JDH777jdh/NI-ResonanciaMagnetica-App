'use strict';
/**
 * PDU.js — DICOM Upper Layer Protocol (PS3.8), capa de framing binario.
 *
 * Esto es protocolo puro: cómo se arman y se leen los paquetes que viajan por
 * TCP entre nuestro motor y el equipo de imagen. No usa ninguna librería —
 * es donde de verdad estamos escribiendo "nuestro" DICOM, byte a byte.
 *
 * Todos los campos de longitud del PDU/Item van en BIG ENDIAN (network byte
 * order) — así lo exige PS3.8 sección 9.3, independiente de qué Transfer
 * Syntax se negocie después para el contenido clínico.
 *
 * Verificado contra DocBookDICOM2026c (PS3.8, secciones 9.3.2 a 9.3.8).
 */

const PDU_TYPE = {
  A_ASSOCIATE_RQ: 0x01,
  A_ASSOCIATE_AC: 0x02,
  A_ASSOCIATE_RJ: 0x03,
  P_DATA_TF: 0x04,
  A_RELEASE_RQ: 0x05,
  A_RELEASE_RP: 0x06,
  A_ABORT: 0x07,
};

const ITEM_TYPE = {
  APPLICATION_CONTEXT: 0x10,
  PRESENTATION_CONTEXT_RQ: 0x20,
  PRESENTATION_CONTEXT_AC: 0x21,
  ABSTRACT_SYNTAX: 0x30,
  TRANSFER_SYNTAX: 0x40,
  USER_INFORMATION: 0x50,
  MAX_PDU_LENGTH: 0x51,
  IMPLEMENTATION_CLASS_UID: 0x52,
  ASYNC_OPERATIONS: 0x53,
  IMPLEMENTATION_VERSION_NAME: 0x55,
};

const DICOM_APPLICATION_CONTEXT_UID = '1.2.840.10008.3.1.1.1';

/* ---------- helpers de bajo nivel (padding AE Title / UID) ---------- */

/** AE Title: exactamente 16 bytes, relleno con espacios (0x20) a la derecha. */
function padAE(title) {
  const t = String(title || '').trim().slice(0, 16);
  return Buffer.concat([Buffer.from(t, 'ascii'), Buffer.alloc(16 - t.length, 0x20)]);
}
function readAE(buf) {
  return buf.toString('ascii').replace(/\s+$/, '');
}

/** UID: ASCII, longitud par obligatoria — se rellena con UN byte NULL (0x00), nunca espacio. */
function encodeUID(uid) {
  let b = Buffer.from(uid, 'ascii');
  if (b.length % 2 !== 0) b = Buffer.concat([b, Buffer.from([0x00])]);
  return b;
}
function readUID(buf) {
  return buf.toString('ascii').replace(/\0+$/, '');
}

function itemHeader(type, length) {
  const h = Buffer.alloc(4);
  h.writeUInt8(type, 0);
  h.writeUInt8(0x00, 1); // reservado
  h.writeUInt16BE(length, 2);
  return h;
}

/* ---------- A-ASSOCIATE-RQ ---------- */
/**
 * opts.presentationContexts: [{ id, abstractSyntax, transferSyntaxes: [uid,...] }]
 * opts.maxPduLength: entero (ej. 16384)
 * opts.implementationClassUID / implementationVersionName: identifican a NUESTRO motor
 */
function encodeAssociateRQ(opts) {
  const items = [];

  // Application Context
  const acUid = encodeUID(DICOM_APPLICATION_CONTEXT_UID);
  items.push(itemHeader(ITEM_TYPE.APPLICATION_CONTEXT, acUid.length), acUid);

  // Presentation Contexts
  for (const pc of opts.presentationContexts) {
    const asUid = encodeUID(pc.abstractSyntax);
    const asItem = Buffer.concat([itemHeader(ITEM_TYPE.ABSTRACT_SYNTAX, asUid.length), asUid]);
    const tsItems = pc.transferSyntaxes.map((ts) => {
      const b = encodeUID(ts);
      return Buffer.concat([itemHeader(ITEM_TYPE.TRANSFER_SYNTAX, b.length), b]);
    });
    const pcBody = Buffer.concat([
      Buffer.from([pc.id, 0x00, 0x00, 0x00]), // Presentation Context ID + 3 bytes reservados
      asItem,
      ...tsItems,
    ]);
    items.push(itemHeader(ITEM_TYPE.PRESENTATION_CONTEXT_RQ, pcBody.length), pcBody);
  }

  // User Information (Max PDU Length + Implementation Class UID + Version Name)
  const maxLenBuf = Buffer.alloc(4);
  maxLenBuf.writeUInt32BE(opts.maxPduLength || 16384, 0);
  const maxLenItem = Buffer.concat([itemHeader(ITEM_TYPE.MAX_PDU_LENGTH, 4), maxLenBuf]);

  const implUid = encodeUID(opts.implementationClassUID);
  const implItem = Buffer.concat([itemHeader(ITEM_TYPE.IMPLEMENTATION_CLASS_UID, implUid.length), implUid]);

  const verName = Buffer.from((opts.implementationVersionName || 'AXON_RISPACS_1').slice(0, 16), 'ascii');
  const verItem = Buffer.concat([itemHeader(ITEM_TYPE.IMPLEMENTATION_VERSION_NAME, verName.length), verName]);

  const userInfoBody = Buffer.concat([maxLenItem, implItem, verItem]);
  items.push(itemHeader(ITEM_TYPE.USER_INFORMATION, userInfoBody.length), userInfoBody);

  const fixed = Buffer.concat([
    Buffer.from([0x00, 0x01]), // Protocol version 1
    Buffer.from([0x00, 0x00]), // reservado
    padAE(opts.calledAE),
    padAE(opts.callingAE),
    Buffer.alloc(32, 0x00), // reservado
  ]);

  const body = Buffer.concat([fixed, ...items]);
  const header = itemHeader(PDU_TYPE.A_ASSOCIATE_RQ, 0).fill(0); // placeholder, se corrige abajo
  const full = Buffer.alloc(6 + body.length);
  full.writeUInt8(PDU_TYPE.A_ASSOCIATE_RQ, 0);
  full.writeUInt8(0x00, 1);
  full.writeUInt32BE(body.length, 2);
  body.copy(full, 6);
  return full;
}

/** Decodifica un A-ASSOCIATE-RQ ya recibido — usado por el SCP para saber quién llama y qué pide. */
function decodeAssociateRQ(buf) {
  // buf incluye el header de 6 bytes (type,reserved,length) + body
  let o = 6;
  o += 2; // protocol version
  o += 2; // reservado
  const calledAE = readAE(buf.slice(o, o + 16)); o += 16;
  const callingAE = readAE(buf.slice(o, o + 16)); o += 16;
  o += 32; // reservado

  const presentationContexts = [];
  let userInfo = { maxPduLength: 16384, implementationClassUID: null };

  while (o < buf.length) {
    const itemType = buf.readUInt8(o);
    const itemLen = buf.readUInt16BE(o + 2);
    const itemBody = buf.slice(o + 4, o + 4 + itemLen);

    if (itemType === ITEM_TYPE.PRESENTATION_CONTEXT_RQ) {
      const pcId = itemBody.readUInt8(0);
      let io = 4;
      let abstractSyntax = null;
      const transferSyntaxes = [];
      while (io < itemBody.length) {
        const subType = itemBody.readUInt8(io);
        const subLen = itemBody.readUInt16BE(io + 2);
        const subVal = readUID(itemBody.slice(io + 4, io + 4 + subLen));
        if (subType === ITEM_TYPE.ABSTRACT_SYNTAX) abstractSyntax = subVal;
        if (subType === ITEM_TYPE.TRANSFER_SYNTAX) transferSyntaxes.push(subVal);
        io += 4 + subLen;
      }
      presentationContexts.push({ id: pcId, abstractSyntax, transferSyntaxes });
    } else if (itemType === ITEM_TYPE.USER_INFORMATION) {
      let io = 0;
      while (io < itemBody.length) {
        const subType = itemBody.readUInt8(io);
        const subLen = itemBody.readUInt16BE(io + 2);
        const subVal = itemBody.slice(io + 4, io + 4 + subLen);
        if (subType === ITEM_TYPE.MAX_PDU_LENGTH) userInfo.maxPduLength = subVal.readUInt32BE(0);
        if (subType === ITEM_TYPE.IMPLEMENTATION_CLASS_UID) userInfo.implementationClassUID = readUID(subVal);
        io += 4 + subLen;
      }
    }
    o += 4 + itemLen;
  }

  return { calledAE, callingAE, presentationContexts, userInfo };
}

/**
 * Arma la respuesta A-ASSOCIATE-AC. `results` es un array paralelo a los
 * presentationContexts recibidos: [{ id, accepted:boolean, transferSyntax }]
 */
function encodeAssociateAC({ calledAE, callingAE, results, maxPduLength, implementationClassUID }) {
  const items = [];
  const acUid = encodeUID(DICOM_APPLICATION_CONTEXT_UID);
  items.push(itemHeader(ITEM_TYPE.APPLICATION_CONTEXT, acUid.length), acUid);

  for (const r of results) {
    const tsUid = encodeUID(r.transferSyntax || '1.2.840.10008.1.2'); // Implicit VR LE por defecto
    const tsItem = Buffer.concat([itemHeader(ITEM_TYPE.TRANSFER_SYNTAX, tsUid.length), tsUid]);
    const pcBody = Buffer.concat([
      Buffer.from([r.id, 0x00, r.accepted ? 0x00 : 0x03, 0x00]), // result: 0=accepted, 3=abstract-syntax-not-supported
      tsItem,
    ]);
    items.push(itemHeader(ITEM_TYPE.PRESENTATION_CONTEXT_AC, pcBody.length), pcBody);
  }

  const maxLenBuf = Buffer.alloc(4);
  maxLenBuf.writeUInt32BE(maxPduLength || 16384, 0);
  const maxLenItem = Buffer.concat([itemHeader(ITEM_TYPE.MAX_PDU_LENGTH, 4), maxLenBuf]);
  const implUid = encodeUID(implementationClassUID || '1.2.840.114369.1.1.1');
  const implItem = Buffer.concat([itemHeader(ITEM_TYPE.IMPLEMENTATION_CLASS_UID, implUid.length), implUid]);
  const userInfoBody = Buffer.concat([maxLenItem, implItem]);
  items.push(itemHeader(ITEM_TYPE.USER_INFORMATION, userInfoBody.length), userInfoBody);

  const fixed = Buffer.concat([
    Buffer.from([0x00, 0x01, 0x00, 0x00]),
    padAE(calledAE),
    padAE(callingAE),
    Buffer.alloc(32, 0x00),
  ]);
  const body = Buffer.concat([fixed, ...items]);
  const full = Buffer.alloc(6 + body.length);
  full.writeUInt8(PDU_TYPE.A_ASSOCIATE_AC, 0);
  full.writeUInt32BE(body.length, 2);
  body.copy(full, 6);
  return full;
}

function encodeAssociateRJ({ result = 1, source = 1, reason = 1 }) {
  const full = Buffer.alloc(10);
  full.writeUInt8(PDU_TYPE.A_ASSOCIATE_RJ, 0);
  full.writeUInt32BE(4, 2);
  full.writeUInt8(0x00, 6); // reservado
  full.writeUInt8(result, 7);
  full.writeUInt8(source, 8);
  full.writeUInt8(reason, 9);
  return full;
}

/* ---------- P-DATA-TF (transporta comandos DIMSE y fragmentos del dataset) ---------- */

/** pdvs: [{ presentationContextId, isCommand: bool, isLast: bool, data: Buffer }] */
function encodePDataTF(pdvs) {
  const items = pdvs.map((pdv) => {
    const controlHeader = (pdv.isLast ? 0x02 : 0x00) | (pdv.isCommand ? 0x01 : 0x00);
    const itemBody = Buffer.concat([Buffer.from([pdv.presentationContextId, controlHeader]), pdv.data]);
    const lenBuf = Buffer.alloc(4);
    lenBuf.writeUInt32BE(itemBody.length, 0);
    return Buffer.concat([lenBuf, itemBody]);
  });
  const body = Buffer.concat(items);
  const full = Buffer.alloc(6 + body.length);
  full.writeUInt8(PDU_TYPE.P_DATA_TF, 0);
  full.writeUInt32BE(body.length, 2);
  body.copy(full, 6);
  return full;
}

function decodePDataTF(buf) {
  const pdvs = [];
  let o = 6;
  while (o < buf.length) {
    const itemLen = buf.readUInt32BE(o);
    const pcId = buf.readUInt8(o + 4);
    const controlHeader = buf.readUInt8(o + 5);
    const data = buf.slice(o + 6, o + 4 + itemLen);
    pdvs.push({
      presentationContextId: pcId,
      isCommand: !!(controlHeader & 0x01),
      isLast: !!(controlHeader & 0x02),
      data,
    });
    o += 4 + itemLen;
  }
  return pdvs;
}

function encodeReleaseRQ() {
  const full = Buffer.alloc(10);
  full.writeUInt8(PDU_TYPE.A_RELEASE_RQ, 0);
  full.writeUInt32BE(4, 2);
  return full;
}
function encodeReleaseRP() {
  const full = Buffer.alloc(10);
  full.writeUInt8(PDU_TYPE.A_RELEASE_RP, 0);
  full.writeUInt32BE(4, 2);
  return full;
}
function encodeAbort({ source = 0, reason = 0 } = {}) {
  const full = Buffer.alloc(10);
  full.writeUInt8(PDU_TYPE.A_ABORT, 0);
  full.writeUInt32BE(4, 2);
  full.writeUInt8(source, 8);
  full.writeUInt8(reason, 9);
  return full;
}

/** Lee el tipo y longitud total de un PDU a partir del buffer acumulado del socket. */
function peekPduHeader(buf) {
  if (buf.length < 6) return null;
  return { type: buf.readUInt8(0), length: buf.readUInt32BE(2), totalSize: 6 + buf.readUInt32BE(2) };
}

module.exports = {
  PDU_TYPE, ITEM_TYPE, DICOM_APPLICATION_CONTEXT_UID,
  padAE, readAE, encodeUID, readUID,
  encodeAssociateRQ, decodeAssociateRQ,
  encodeAssociateAC, encodeAssociateRJ,
  encodePDataTF, decodePDataTF,
  encodeReleaseRQ, encodeReleaseRP, encodeAbort,
  peekPduHeader,
};
