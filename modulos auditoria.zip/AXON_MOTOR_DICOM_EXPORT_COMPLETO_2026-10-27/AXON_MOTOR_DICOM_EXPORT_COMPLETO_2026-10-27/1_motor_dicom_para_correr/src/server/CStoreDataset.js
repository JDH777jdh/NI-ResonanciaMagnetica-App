'use strict';
/**
 * CStoreDataset.js — convierte lo que llega por C-STORE (solo el dataset,
 * sin envoltorio) en un archivo .dcm Part 10 válido, y usa `dcmjs` para
 * leer sus tags clínicos reales.
 *
 * Por qué hace falta el envoltorio: DIMSE nunca manda el preámbulo de 128
 * bytes ni el grupo File Meta (0002,xxxx) — eso es exclusivo de PS3.10
 * (archivos en disco/medios). Un C-STORE entrega solo el dataset. Para que
 * dcmjs (pensado para leer archivos completos) pueda leerlo, hay que
 * armar ese sobre nosotros mismos — es lo que realmente hace cualquier
 * PACS al guardar lo que le llega por red.
 *
 * dcmjs es la única dependencia externa real de todo el motor — se usa
 * solo para esto (parseo semántico del dataset clínico), nunca para la
 * red ni la lógica DIMSE, que es 100% nuestra (ver PDU.js / DimseCommand.js).
 */

/* File Meta Information (grupo 0002) va SIEMPRE en Explicit VR Little Endian,
   sin importar la Transfer Syntax del dataset clínico (PS3.10 §7.1). */
function encodeFileMetaElement(group, element, vr, value) {
  const isLongVR = vr === 'OB' || vr === 'OW' || vr === 'SQ' || vr === 'UN' || vr === 'UT';
  let valueBuf = Buffer.isBuffer(value) ? value : Buffer.from(String(value), 'ascii');
  if (valueBuf.length % 2 !== 0) valueBuf = Buffer.concat([valueBuf, Buffer.from([0x00])]);

  const tagBuf = Buffer.alloc(4);
  tagBuf.writeUInt16LE(group, 0);
  tagBuf.writeUInt16LE(element, 2);
  const vrBuf = Buffer.from(vr, 'ascii');

  if (isLongVR) {
    const lenBuf = Buffer.alloc(4);
    lenBuf.writeUInt32LE(valueBuf.length, 0);
    return Buffer.concat([tagBuf, vrBuf, Buffer.from([0x00, 0x00]), lenBuf, valueBuf]);
  }
  const lenBuf = Buffer.alloc(2);
  lenBuf.writeUInt16LE(valueBuf.length, 0);
  return Buffer.concat([tagBuf, vrBuf, lenBuf, valueBuf]);
}

function buildFileMetaGroup({ sopClassUID, sopInstanceUID, transferSyntaxUID, implementationClassUID }) {
  const elements = Buffer.concat([
    encodeFileMetaElement(0x0002, 0x0001, 'OB', Buffer.from([0x00, 0x01])),
    encodeFileMetaElement(0x0002, 0x0002, 'UI', sopClassUID),
    encodeFileMetaElement(0x0002, 0x0003, 'UI', sopInstanceUID),
    encodeFileMetaElement(0x0002, 0x0010, 'UI', transferSyntaxUID),
    encodeFileMetaElement(0x0002, 0x0012, 'UI', implementationClassUID),
    encodeFileMetaElement(0x0002, 0x0013, 'SH', 'AXON_RISPACS_1'),
  ]);
  const groupLength = encodeFileMetaElement(0x0002, 0x0000, 'UL', (() => {
    const b = Buffer.alloc(4); b.writeUInt32LE(elements.length, 0); return b;
  })());
  return Buffer.concat([groupLength, elements]);
}

/** Arma el archivo Part 10 completo: 128 bytes en 0x00 + "DICM" + File Meta + dataset recibido tal cual. */
function buildStoredFile({ sopClassUID, sopInstanceUID, transferSyntaxUID, implementationClassUID, datasetBuf }) {
  const preamble = Buffer.alloc(128, 0x00);
  const magic = Buffer.from('DICM', 'ascii');
  const fileMeta = buildFileMetaGroup({ sopClassUID, sopInstanceUID, transferSyntaxUID, implementationClassUID });
  return Buffer.concat([preamble, magic, fileMeta, datasetBuf || Buffer.alloc(0)]);
}

/**
 * Lee los tags clínicos reales con dcmjs. Requiere `npm install dcmjs` en el
 * servidor donde corra esto — acá se hace opcional y con fallback honesto:
 * si el paquete no está instalado, devuelve null en vez de romper el C-STORE.
 */
function extractTagsWithDcmjs(part10Buffer) {
  let dcmjs;
  try {
    dcmjs = require('dcmjs');
  } catch (e) {
    return { ok: false, motivo: 'dcmjs no está instalado — `npm install dcmjs` para activar el parseo real', dataset: null };
  }
  try {
    const arrayBuffer = part10Buffer.buffer.slice(part10Buffer.byteOffset, part10Buffer.byteOffset + part10Buffer.byteLength);
    const dicomDict = dcmjs.data.DicomMessage.readFile(arrayBuffer);
    const dataset = dcmjs.data.DicomMetaDictionary.naturalizeDataset(dicomDict.dict);
    return {
      ok: true,
      dataset: {
        patientName: dataset.PatientName,
        patientID: dataset.PatientID,
        studyInstanceUID: dataset.StudyInstanceUID,
        seriesInstanceUID: dataset.SeriesInstanceUID,
        sopInstanceUID: dataset.SOPInstanceUID,
        accessionNumber: dataset.AccessionNumber,
        modality: dataset.Modality,
      },
    };
  } catch (e) {
    return { ok: false, motivo: `dcmjs no pudo parsear el dataset: ${e.message}`, dataset: null };
  }
}

module.exports = { buildStoredFile, buildFileMetaGroup, extractTagsWithDcmjs };
