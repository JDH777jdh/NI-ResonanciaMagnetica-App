'use strict';
/**
 * WorklistApiServer.js — API HTTP mínima sobre WorklistStore.
 *
 * Por qué existe: WorklistStore.js (26-ago-2026) le dio a AssociationServer.js
 * un lugar real de dónde leer/escribir el Worklist — pero eso es un archivo
 * en disco, y `HIS-RIS-PACS.jsx` corre en el navegador. Un navegador no puede
 * hacer `require('fs')` — necesita hablar HTTP con algo que sí pueda tocar
 * el disco. Esto es ese "algo".
 *
 * A propósito NO es parte de DicomWebServer.js: ese archivo implementa
 * QIDO-RS/WADO-RS, que SON el estándar DICOMweb real (PS3.18) — mezclar
 * ahí una API propia de Worklist (que no es DICOMweb, es un CRUD interno
 * nuestro) confundiría cuál de las dos cosas es protocolo estándar y cuál
 * es invención propia de AXON. Se mantienen separados para que esa
 * distinción quede clara con solo mirar el nombre del archivo.
 *
 * Framework-agnostic, mismo estilo que DicomWebServer.js: sin Express ni
 * ninguna dependencia nueva, solo el módulo http nativo de Node.
 *
 * Endpoints:
 *   GET    /worklist            → lista todos los registros (?fase=worklist filtra)
 *   GET    /worklist/:id        → un registro puntual
 *   POST   /worklist            → crea un registro nuevo (body: JSON)
 *   PATCH  /worklist/:id        → modifica campos de un registro (body: JSON)
 *
 * CORS abierto (`*`) a propósito para desarrollo local — el navegador que
 * corre HIS-RIS-PACS.jsx normalmente vive en otro puerto/origen que este
 * servidor. Puerta etiquetada, no fingida: para producción, restringir a
 * los orígenes reales conocidos — queda anotado acá, no resuelto en silencio.
 */
const url = require('url');
const WorklistStore = require('../storage/WorklistStore');

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PATCH, PUT, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type',
};

function _leerBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', (chunk) => { data += chunk; });
    req.on('end', () => {
      if (!data) return resolve({});
      try { resolve(JSON.parse(data)); } catch (e) { reject(new Error('Body no es JSON válido: ' + e.message)); }
    });
    req.on('error', reject);
  });
}

function _enviarJson(res, status, body) {
  const buf = Buffer.from(JSON.stringify(body));
  res.writeHead(status, { 'Content-Type': 'application/json', 'Content-Length': buf.length, ...CORS_HEADERS });
  res.end(buf);
}
function _enviarError(res, status, mensaje) {
  res.writeHead(status, { 'Content-Type': 'application/json', ...CORS_HEADERS });
  res.end(JSON.stringify({ error: mensaje }));
}

/**
 * opts.storePath: ruta al JSON del WorklistStore — el MISMO archivo que lee
 * AssociationServer.js (normalmente `<almacenPath>/.worklist-store.json`),
 * para que el C-FIND real por DIMSE y esta API vean exactamente los mismos
 * datos, no dos copias que se puedan desincronizar.
 */
function crearHandler({ storePath }) {
  return async function handler(req, res) {
    if (req.method === 'OPTIONS') { res.writeHead(204, CORS_HEADERS); return res.end(); }

    const parsed = url.parse(req.url, true);
    const partes = parsed.pathname.split('/').filter(Boolean); // ["worklist"] o ["worklist", ":id"]

    try {
      if (partes[0] !== 'worklist' || partes.length > 2) {
        return _enviarError(res, 404, 'Ruta no reconocida — esta API solo sirve /worklist y /worklist/:id');
      }

      if (req.method === 'GET' && partes.length === 1) {
        const registros = parsed.query.fase
          ? WorklistStore.listarPorFase(parsed.query.fase, storePath)
          : WorklistStore.listar(storePath);
        return _enviarJson(res, 200, registros);
      }

      if (req.method === 'GET' && partes.length === 2) {
        const registro = WorklistStore.listar(storePath).find((r) => r.id === partes[1]);
        if (!registro) return _enviarError(res, 404, 'Registro no encontrado');
        return _enviarJson(res, 200, registro);
      }

      if (req.method === 'POST' && partes.length === 1) {
        const body = await _leerBody(req);
        if (!body.nombre || !body.modalidad) return _enviarError(res, 400, 'Faltan campos obligatorios (al menos nombre, modalidad)');
        const nuevo = WorklistStore.agregar(body, storePath);
        return _enviarJson(res, 201, nuevo);
      }

      if (req.method === 'PATCH' && partes.length === 2) {
        const body = await _leerBody(req);
        const actualizado = WorklistStore.actualizar(partes[1], body, storePath);
        if (!actualizado) return _enviarError(res, 404, 'Registro no encontrado');
        return _enviarJson(res, 200, actualizado);
      }

      // PUT /worklist/:id — upsert: inserta si el id no existe, reemplaza
      // completo si ya existe. Pensado para poblar/resetear datos de
      // semilla desde el cliente (HIS-RIS-PACS.jsx) sin duplicar.
      if (req.method === 'PUT' && partes.length === 2) {
        const body = await _leerBody(req);
        if (!body.nombre || !body.modalidad) return _enviarError(res, 400, 'Faltan campos obligatorios (al menos nombre, modalidad)');
        const { registro, creado } = WorklistStore.upsert({ ...body, id: partes[1] }, storePath);
        return _enviarJson(res, creado ? 201 : 200, registro);
      }

      return _enviarError(res, 405, `Método ${req.method} no soportado en esta ruta`);
    } catch (err) {
      return _enviarError(res, 500, err.message);
    }
  };
}

module.exports = { crearHandler };
