'use strict';
/**
 * AssociationServer.js — el motor en sí: escucha TCP (con TLS, perfil PS3.15),
 * negocia la asociación DICOM, y despacha C-STORE (recibir imágenes) y
 * C-FIND (responder Modality Worklist) según lo que pida el equipo.
 *
 * Puerta etiquetada real: agregar un equipo nuevo = una fila en AeRegistry
 * (o el panel de configuración), nunca tocar este archivo.
 */

const tls = require('tls');
const net = require('net');
const fs = require('fs');
const path = require('path');

const PDU = require('../pdu/PDU');
const DIMSE = require('../pdu/DimseCommand');
const TransferSyntaxRegistry = require('../pdu/TransferSyntaxRegistry');
const AeRegistry = require('../config/AeRegistry');
const { buildStoredFile, extractTagsWithDcmjs } = require('./CStoreDataset');
const StudyIndex = require('../storage/StudyIndex');
const WorklistStore = require('../storage/WorklistStore');

/* Nuestro motor se identifica con este SOP Class UID + versión (PS3.7/8, User Information). */
const IMPLEMENTATION_CLASS_UID = '1.2.840.114369.1.1.1'; // provisorio — se registra oficialmente antes de producción
const IMPLEMENTATION_VERSION = 'AXON_RISPACS_1';

/* SOP Classes que nuestro motor acepta como SCP (Storage) + el de Modality Worklist. */
const STORAGE_SOP_CLASSES = {
  '1.2.840.10008.5.1.4.1.1.1': 'CR',
  '1.2.840.10008.5.1.4.1.1.1.1': 'DX',
  '1.2.840.10008.5.1.4.1.1.1.2': 'MG',
  '1.2.840.10008.5.1.4.1.1.2': 'CT',
  '1.2.840.10008.5.1.4.1.1.4': 'MR',
  '1.2.840.10008.5.1.4.1.1.6.1': 'US',
  '1.2.840.10008.5.1.4.1.1.12.1': 'XA',
  '1.2.840.10008.5.1.4.1.1.20': 'NM',
  '1.2.840.10008.5.1.4.1.1.128': 'PT',
  '1.2.840.10008.5.1.4.1.1.7': 'OT', // Secondary Capture — capturas genéricas/derivadas, útil para test patterns y pantallazos
  '1.2.840.10008.5.1.4.1.1.104.1': 'DOC', // Encapsulated PDF — documentos no-imagen envueltos como DICOM (31-jul-2026, consentimiento informado y similares)
};
const MODALITY_WORKLIST_SOP_CLASS = '1.2.840.10008.5.1.4.31';
const VERIFICATION_SOP_CLASS = '1.2.840.10008.1.1'; // C-ECHO — el "ping" de DICOM, bueno para probar conectividad

/* ---------- Auditoría (PS3.15 §6.8) — mismo patrón EventBus del resto de AXON ---------- */
const EVENTS = { ASOCIACION_ACEPTADA: 'dicom.asociacion.aceptada', ASOCIACION_RECHAZADA: 'dicom.asociacion.rechazada', IMAGEN_RECIBIDA: 'dicom.imagen.recibida', WORKLIST_CONSULTADO: 'dicom.worklist.consultado' };
function publish(evento, payload) { console.log(`[Auditoría DICOM] ${evento}`, JSON.stringify(payload)); }

class AssociationHandler {
  constructor(socket, opts) {
    this.socket = socket;
    this.buffer = Buffer.alloc(0);
    this.presentationContexts = {}; // id -> { abstractSyntax, transferSyntax }
    this.pendingPdv = null; // reensamblado de fragmentos { presentationContextId, isCommand, chunks:[] }
    this.callingAE = null;
    this.almacenPath = opts.almacenPath;
    this.worklistProvider = opts.worklistProvider;
    // Mismo criterio que .study-index.json: si no se pasa una ruta explícita
    // (útil para aislar tests), el store del Worklist vive junto al almacén
    // de imágenes de esta misma instancia del motor.
    this.worklistStorePath = opts.worklistStorePath
      || (this.almacenPath ? path.join(this.almacenPath, '.worklist-store.json') : WorklistStore.DEFAULT_STORE_PATH);

    socket.on('data', (chunk) => this._onData(chunk));
    socket.on('error', (err) => console.error('[AssociationServer] socket error:', err.message));
    socket.on('close', () => { /* liberar recursos de esta asociación si quedó algo pendiente */ });
  }

  _onData(chunk) {
    this.buffer = Buffer.concat([this.buffer, chunk]);
    let header;
    while ((header = PDU.peekPduHeader(this.buffer)) && this.buffer.length >= header.totalSize) {
      const pdu = this.buffer.slice(0, header.totalSize);
      this.buffer = this.buffer.slice(header.totalSize);
      this._handlePdu(header.type, pdu);
    }
  }

  _handlePdu(type, pdu) {
    switch (type) {
      case PDU.PDU_TYPE.A_ASSOCIATE_RQ: return this._handleAssociateRQ(pdu);
      case PDU.PDU_TYPE.P_DATA_TF: return this._handlePData(pdu);
      case PDU.PDU_TYPE.A_RELEASE_RQ:
        this.socket.write(PDU.encodeReleaseRP());
        this.socket.end();
        return;
      case PDU.PDU_TYPE.A_ABORT:
        this.socket.destroy();
        return;
      default:
        console.warn('[AssociationServer] PDU no manejado, tipo', type);
    }
  }

  _handleAssociateRQ(pdu) {
    const req = PDU.decodeAssociateRQ(pdu);
    this.callingAE = req.callingAE;
    const equipo = AeRegistry.buscarPorAeTitle(req.callingAE);

    if (!equipo) {
      publish(EVENTS.ASOCIACION_RECHAZADA, { callingAE: req.callingAE, motivo: 'AE Title no registrado' });
      this.socket.write(PDU.encodeAssociateRJ({ result: 1, source: 1, reason: 7 })); // calling-AE-title-not-recognized
      this.socket.end();
      return;
    }

    const results = req.presentationContexts.map((pc) => {
      const esStorage = !!STORAGE_SOP_CLASSES[pc.abstractSyntax];
      const esMWL = pc.abstractSyntax === MODALITY_WORKLIST_SOP_CLASS;
      const esEcho = pc.abstractSyntax === VERIFICATION_SOP_CLASS;
      const permitido = (esStorage && equipo.scp) || (esMWL && equipo.mwl) || esEcho;
      const transferSyntax = pc.transferSyntaxes.find((ts) => AeRegistry.TRANSFER_SYNTAXES_ESTANDAR.includes(ts));
      const accepted = permitido && !!transferSyntax;
      if (accepted) this.presentationContexts[pc.id] = { abstractSyntax: pc.abstractSyntax, transferSyntax };
      return { id: pc.id, accepted, transferSyntax: transferSyntax || pc.transferSyntaxes[0] };
    });

    this.socket.write(PDU.encodeAssociateAC({
      calledAE: req.calledAE, callingAE: req.callingAE, results,
      maxPduLength: 16384, implementationClassUID: IMPLEMENTATION_CLASS_UID,
    }));
    publish(EVENTS.ASOCIACION_ACEPTADA, { callingAE: req.callingAE, equipo: equipo.nombre, contextosAceptados: results.filter((r) => r.accepted).length });
  }

  _handlePData(pdu) {
    const pdvs = PDU.decodePDataTF(pdu);
    for (const pdv of pdvs) {
      if (!this.presentationContexts[pdv.presentationContextId]) {
        console.warn(`[AssociationServer] PDV en presentation context ${pdv.presentationContextId} no aceptado en la asociación — se descarta (no debería llegar esto de un SCU conforme)`);
        continue;
      }
      this._acumularPdv(pdv);
    }
  }

  _acumularPdv(pdv) {
    const key = `${pdv.presentationContextId}:${pdv.isCommand ? 'cmd' : 'ds'}`;
    if (!this._fragmentos) this._fragmentos = {};
    if (!this._fragmentos[key]) this._fragmentos[key] = [];
    this._fragmentos[key].push(pdv.data);

    if (!pdv.isLast) return; // esperar más fragmentos

    const completo = Buffer.concat(this._fragmentos[key]);
    delete this._fragmentos[key];

    if (pdv.isCommand) {
      const comando = DIMSE.decodeCommandSet(completo);
      this._comandoActivo = { presentationContextId: pdv.presentationContextId, comando };
      // Si el propio comando indica "sin dataset" (0x0101), procesar de inmediato.
      if (comando['00000800'] === 0x0101) this._despacharComando(this._comandoActivo, null);
    } else if (this._comandoActivo) {
      this._despacharComando(this._comandoActivo, completo);
      this._comandoActivo = null;
    }
  }

  _despacharComando({ presentationContextId, comando }, datasetBuf) {
    const cf = comando['00000100'];
    if (cf === DIMSE.COMMAND_FIELD.C_STORE_RQ) return this._handleCStore(presentationContextId, comando, datasetBuf);
    if (cf === DIMSE.COMMAND_FIELD.C_FIND_RQ) return this._handleCFindWorklist(presentationContextId, comando, datasetBuf);
    if (cf === DIMSE.COMMAND_FIELD.C_ECHO_RQ) return this._handleCEcho(presentationContextId, comando);
    console.warn('[AssociationServer] Command Field no manejado:', cf?.toString(16));
  }

  _handleCEcho(pcId, comando) {
    const rsp = DIMSE.encodeCommandSet({
      '00000002': comando['00000002'],
      '00000100': DIMSE.COMMAND_FIELD.C_ECHO_RSP,
      '00000120': comando['00000110'],
      '00000800': 0x0101,
      '00000900': DIMSE.STATUS.SUCCESS,
    });
    this.socket.write(PDU.encodePDataTF([{ presentationContextId: pcId, isCommand: true, isLast: true, data: rsp }]));
  }

  /** Recibe la imagen y la guarda tal cual llegó — el parseo semántico completo (tags clínicos) es tarea de dcmjs, no de este archivo. */
  /** Guarda el archivo como Part 10 válido (preámbulo + File Meta + dataset) e intenta leer sus tags reales con dcmjs. */
  _handleCStore(pcId, comando, datasetBuf) {
    const sopInstanceUID = comando['00001000'] || `desconocido-${Date.now()}`;
    const sopClassUID = comando['00000002'] || '';
    const transferSyntaxUID = (this.presentationContexts[pcId] || {}).transferSyntax || '1.2.840.10008.1.2';

    const archivoCompleto = buildStoredFile({
      sopClassUID, sopInstanceUID, transferSyntaxUID,
      implementationClassUID: IMPLEMENTATION_CLASS_UID,
      datasetBuf: datasetBuf || Buffer.alloc(0),
    });

    const nombreArchivo = `${sopInstanceUID.replace(/[^0-9.]/g, '_')}.dcm`;
    fs.mkdirSync(this.almacenPath, { recursive: true });
    fs.writeFileSync(path.join(this.almacenPath, nombreArchivo), archivoCompleto);

    const lectura = extractTagsWithDcmjs(archivoCompleto);
    StudyIndex.indexarInstancia({ archivoRelativo: nombreArchivo, sopInstanceUID, tags: lectura.ok ? lectura.dataset : null }, path.join(this.almacenPath, '.study-index.json'));

    // Real desde el 26-ago-2026: si el dataset trae Accession Number (dcmjs
    // lo extrae junto con el resto de tagsReales) y coincide con un registro
    // real del Worklist, ESTO es lo que marca "Almacenado" — no un timer
    // simulado en la interfaz. Es el mismo mecanismo con el que un equipo
    // real amarra la imagen que manda con la orden que consultó por MWL
    // (PS3.4): copia el Accession Number que vio, no inventa uno nuevo.
    // Si dcmjs no está instalado, o el dataset no trae Accession Number, o
    // no hay ningún registro pendiente con ese número, se degrada honesto:
    // la imagen igual se guarda, solo no hay Worklist que actualizar.
    let worklistActualizado = null;
    if (lectura.ok && lectura.dataset.accessionNumber) {
      const registro = WorklistStore.buscarPorAcc(lectura.dataset.accessionNumber, this.worklistStorePath);
      if (registro && registro.fase === 'worklist') {
        worklistActualizado = WorklistStore.actualizar(registro.id, { fase: 'examenes', estado: 'almacenado' }, this.worklistStorePath);
      }
    }

    publish(EVENTS.IMAGEN_RECIBIDA, {
      callingAE: this.callingAE, sopInstanceUID, archivo: nombreArchivo, bytes: archivoCompleto.length,
      tagsReales: lectura.ok ? lectura.dataset : null,
      avisoParseo: lectura.ok ? null : lectura.motivo,
      worklistActualizado: worklistActualizado ? { id: worklistActualizado.id, acc: worklistActualizado.acc, estado: worklistActualizado.estado } : null,
    });

    const rsp = DIMSE.buildCStoreResponse(comando, DIMSE.STATUS.SUCCESS);
    this.socket.write(PDU.encodePDataTF([{ presentationContextId: pcId, isCommand: true, isLast: true, data: rsp }]));
  }

  /**
   * Responde el Modality Worklist con la anidación real: Scheduled Station
   * AE Title / fecha / hora / Modality / Descripción van DENTRO del item de
   * Scheduled Procedure Step Sequence (0040,0100), como exige PS3.4 Anexo K
   * — ya no van sueltos a nivel superior.
   */
  _handleCFindWorklist(pcId, comando) {
    const equipo = AeRegistry.buscarPorAeTitle(this.callingAE);
    // Si quien arrancó el servidor pasó su propio worklistProvider (como
    // hacen los 5 tests existentes, con arrays fijos para no depender de
    // disco), se respeta tal cual — no se cambia ningún comportamiento ya
    // probado. Si NO se pasó ninguno, el default deja de ser "array vacío"
    // y pasa a ser el WorklistStore real — acá es donde el motor empieza a
    // responder con lo que de verdad hay en la pestaña Worklist, no con
    // datos de prueba.
    const pendientes = this.worklistProvider
      ? this.worklistProvider(equipo)
      : WorklistStore.listarPorFase('worklist', this.worklistStorePath).map((r) => ({
          nombre: r.nombre, cup: r.cup, acc: r.acc, ot: r.ot,
          fechaAAAAMMDD: r.fechaAAAAMMDD, horaHHMM: r.horaHHMM,
          modalidad: r.modalidad, estudio: r.estudio,
        }));

    for (const item of pendientes) {
      const dataset = [
        { tag: '00100010', vr: 'PN', value: item.nombre },
        { tag: '00100020', vr: 'LO', value: item.cup },
        { tag: '00080050', vr: 'SH', value: item.acc },
        { tag: '00401001', vr: 'SH', value: item.ot },
        {
          tag: '00400100', vr: 'SQ', value: [[
            { tag: '00400001', vr: 'AE', value: (equipo && equipo.aeTitle) || this.callingAE },
            { tag: '00400002', vr: 'DA', value: item.fechaAAAAMMDD || '' },
            { tag: '00400003', vr: 'TM', value: item.horaHHMM || '' },
            { tag: '00080060', vr: 'CS', value: item.modalidad },
            { tag: '00400007', vr: 'LO', value: item.estudio || '' },
          ]],
        },
      ];
      // El MWL puede negociarse en Implicit o Explicit VR LE — se codifica con el
      // codec que corresponde al que de verdad se negoció para este Presentation
      // Context, no siempre Implicit (23-jul-2026, mismo motivo que AeRegistry
      // ahora vuelve a aceptar Explicit VR: ya está soportado de verdad).
      // El MWL puede negociarse en cualquier Transfer Syntax que el motor
      // realmente soporte — se codifica con el codec que corresponde según
      // el registro real (31-ago-2026: antes era un ternario hardcodeado
      // acá mismo, `? ExplicitVR : ImplicitVR`; agregar RLE/JPEG/etc. es
      // ahora una entrada en TransferSyntaxRegistry.js, no tocar este archivo).
      const transferSyntax = (this.presentationContexts[pcId] || {}).transferSyntax;
      const codec = TransferSyntaxRegistry.obtenerCodec(transferSyntax);
      const datasetBuf = codec.encodeDataset(dataset);
      const pendingCmd = DIMSE.buildCFindPendingResponse(comando);
      this.socket.write(PDU.encodePDataTF([
        { presentationContextId: pcId, isCommand: true, isLast: true, data: pendingCmd },
        { presentationContextId: pcId, isCommand: false, isLast: true, data: datasetBuf },
      ]));
    }

    const finalCmd = DIMSE.buildCFindFinalResponse(comando);
    this.socket.write(PDU.encodePDataTF([{ presentationContextId: pcId, isCommand: true, isLast: true, data: finalCmd }]));
    publish(EVENTS.WORKLIST_CONSULTADO, { callingAE: this.callingAE, resultados: pendientes.length });
  }
}

/**
 * Arranca el servidor. `tlsOptions` con key/cert es obligatorio en producción
 * (perfil PS3.15 Secure Transport Connection) — se deja opcional acá solo
 * para poder probar en texto plano contra un equipo de prueba sin certificado.
 */
function iniciarServidor({ port = 104, almacenPath, worklistProvider, worklistStorePath, tlsOptions = null }) {
  const onConnection = (socket) => new AssociationHandler(socket, { almacenPath, worklistProvider, worklistStorePath });
  const server = tlsOptions ? tls.createServer(tlsOptions, onConnection) : net.createServer(onConnection);
  server.listen(port, () => console.log(`[AssociationServer] escuchando en puerto ${port}${tlsOptions ? ' (TLS)' : ' (⚠ sin TLS — solo para pruebas locales)'}`));
  return server;
}

module.exports = { iniciarServidor, AssociationHandler, STORAGE_SOP_CLASSES, MODALITY_WORKLIST_SOP_CLASS, VERIFICATION_SOP_CLASS, IMPLEMENTATION_CLASS_UID };
