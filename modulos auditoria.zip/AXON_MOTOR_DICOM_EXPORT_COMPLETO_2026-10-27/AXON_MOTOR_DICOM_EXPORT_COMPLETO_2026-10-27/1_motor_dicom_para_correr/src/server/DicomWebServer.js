'use strict';
/**
 * DicomWebServer.js — QIDO-RS (buscar) y WADO-RS (recuperar), PS3.18.
 *
 * Es el mismo almacén y el mismo índice que llena AssociationServer.js por
 * DIMSE — el visor web nunca habla DIMSE, habla HTTP/JSON contra este mismo
 * archivo. Un solo motor, dos puertas: puerto 104 para equipos, este HTTP
 * para navegadores.
 *
 * Framework-agnóstico a propósito: expone `crearHandler(...)` que sirve
 * tanto para `http.createServer` puro como para adaptarlo a una función
 * serverless de Vercel (nuestro despliegue real del resto de AXON).
 *
 * Simplificado a propósito: WADO-RS de instancia devuelve `application/dicom`
 * de una sola parte en vez de `multipart/related` — válido para un cliente
 * que pida una sola instancia (la mayoría de los viewers lo aceptan así),
 * pero no es el multipart completo que exige el estándar para más de una.
 *
 * WADO-RS /rendered (20-jul-2026): entrega la instancia ya convertida a PNG
 * de 8 bits (ver rendering/RenderInstance.js) — para que un visor externo,
 * un <img>, o una miniatura no necesiten decodificar DICOM ellos mismos.
 * Solo escala de grises por ahora (ver el alcance documentado en ese
 * archivo); si la instancia es a color o viene comprimida, responde 422
 * con el motivo explícito, nunca una imagen incorrecta en silencio.
 */

const fs = require('fs');
const path = require('path');
const url = require('url');
const StudyIndex = require('../storage/StudyIndex');
const { renderizarInstanciaAPng } = require('../rendering/RenderInstance');

/** DICOM JSON Model (PS3.18 Anexo F): {tag: {vr, Value:[...]}} */
function _dicomJson(tag, vr, valor) {
  if (valor == null) return { [tag]: { vr } };
  return { [tag]: { vr, Value: Array.isArray(valor) ? valor : [valor] } };
}

function _estudioToDicomJson(estudio) {
  return {
    ..._dicomJson('0020000D', 'UI', estudio.studyInstanceUID),
    ..._dicomJson('00100010', 'PN', estudio.patientName ? [{ Alphabetic: estudio.patientName }] : undefined),
    ..._dicomJson('00100020', 'LO', estudio.patientID),
    ..._dicomJson('00080050', 'SH', estudio.accessionNumber),
    ..._dicomJson('00080061', 'CS', estudio.modalidades),
    ..._dicomJson('00201206', 'IS', String(Object.keys(estudio.series || {}).length)),
  };
}
function _serieToDicomJson(studyUID, serie) {
  return {
    ..._dicomJson('0020000D', 'UI', studyUID),
    ..._dicomJson('0020000E', 'UI', serie.seriesInstanceUID),
    ..._dicomJson('00080060', 'CS', serie.modalidad),
    ..._dicomJson('00201209', 'IS', String((serie.instancias || []).length)),
  };
}
function _instanciaToDicomJson(studyUID, seriesUID, inst) {
  return {
    ..._dicomJson('0020000D', 'UI', studyUID),
    ..._dicomJson('0020000E', 'UI', seriesUID),
    ..._dicomJson('00080018', 'UI', inst.sopInstanceUID),
  };
}

function _enviarJson(res, status, body) {
  const buf = Buffer.from(JSON.stringify(body));
  res.writeHead(status, { 'Content-Type': 'application/dicom+json', 'Content-Length': buf.length });
  res.end(buf);
}

/**
 * opts.almacenPath: mismo directorio donde AssociationServer.js guarda los .dcm
 * opts.indexFileName: nombre del índice dentro de ese almacén (por defecto '.study-index.json')
 */
function crearHandler({ almacenPath, indexFileName = '.study-index.json' }) {
  const rutaIndice = path.join(almacenPath, indexFileName);

  return function handler(req, res) {
    const parsed = url.parse(req.url, true);
    const partes = parsed.pathname.split('/').filter(Boolean); // ["studies", ":uid", "series", ...]

    try {
      // GET /studies  → QIDO-RS búsqueda de estudios
      if (partes[0] === 'studies' && partes.length === 1) {
        const estudios = StudyIndex.buscarEstudios(parsed.query, rutaIndice);
        return _enviarJson(res, 200, estudios.map(_estudioToDicomJson));
      }

      // GET /studies/{uid}/metadata → WADO-RS metadata
      if (partes[0] === 'studies' && partes[2] === 'metadata') {
        const studyUID = partes[1];
        const series = StudyIndex.buscarSeries(studyUID, rutaIndice);
        const metadata = series.flatMap((s) => s.instancias.map((i) => _instanciaToDicomJson(studyUID, s.seriesInstanceUID, i)));
        return _enviarJson(res, 200, metadata);
      }

      // GET /studies/{uid}/series → QIDO-RS series de un estudio
      if (partes[0] === 'studies' && partes[2] === 'series' && partes.length === 3) {
        const studyUID = partes[1];
        const series = StudyIndex.buscarSeries(studyUID, rutaIndice);
        return _enviarJson(res, 200, series.map((s) => _serieToDicomJson(studyUID, s)));
      }

      // GET /studies/{uid}/series/{uid}/instances → QIDO-RS instancias de una serie
      if (partes[0] === 'studies' && partes[2] === 'series' && partes[4] === 'instances' && partes.length === 5) {
        const [, studyUID, , seriesUID] = partes;
        const series = StudyIndex.buscarSeries(studyUID, rutaIndice);
        const serie = series.find((s) => s.seriesInstanceUID === seriesUID);
        const instancias = serie ? serie.instancias : [];
        return _enviarJson(res, 200, instancias.map((i) => _instanciaToDicomJson(studyUID, seriesUID, i)));
      }

      // GET /studies/{uid}/series/{uid}/instances/{uid} → WADO-RS recuperar instancia (single-part)
      if (partes[0] === 'studies' && partes[4] === 'instances' && partes.length === 6) {
        const sopInstanceUID = partes[5];
        const inst = StudyIndex.buscarInstancia(sopInstanceUID, rutaIndice);
        if (!inst) { res.writeHead(404); return res.end('Instancia no encontrada'); }
        const bytes = fs.readFileSync(path.join(almacenPath, inst.archivoRelativo));
        res.writeHead(200, { 'Content-Type': 'application/dicom', 'Content-Length': bytes.length });
        return res.end(bytes);
      }

      // GET /studies/{uid}/series/{uid}/instances/{uid}/rendered → WADO-RS /rendered (PNG 8 bits)
      if (partes[0] === 'studies' && partes[4] === 'instances' && partes[6] === 'rendered' && partes.length === 7) {
        const sopInstanceUID = partes[5];
        const inst = StudyIndex.buscarInstancia(sopInstanceUID, rutaIndice);
        if (!inst) { res.writeHead(404); return res.end('Instancia no encontrada'); }
        let png;
        try {
          png = renderizarInstanciaAPng(path.join(almacenPath, inst.archivoRelativo));
        } catch (errorDeRenderizado) {
          // Distinto de un 500: esto es "no soportado todavía" (color, sin Pixel Data, etc.),
          // no una falla inesperada — se dice el motivo, no se finge una imagen.
          res.writeHead(422, { 'Content-Type': 'application/dicom+json' });
          return res.end(JSON.stringify({ error: errorDeRenderizado.message }));
        }
        res.writeHead(200, { 'Content-Type': 'image/png', 'Content-Length': png.length, 'Cache-Control': 'no-store' });
        return res.end(png);
      }

      res.writeHead(404, { 'Content-Type': 'application/dicom+json' });
      res.end(JSON.stringify({ error: 'Ruta DICOMweb no reconocida' }));
    } catch (err) {
      res.writeHead(500, { 'Content-Type': 'application/dicom+json' });
      res.end(JSON.stringify({ error: err.message }));
    }
  };
}

module.exports = { crearHandler };
