'use strict';
/**
 * WorklistClient.js — capa de datos entre HIS-RIS-PACS.jsx y
 * WorklistApiServer.js (26-ago-2026).
 *
 * Funciones puras, sin ningún import de React — a propósito, para poder
 * probarlas aparte, sin montar el componente completo ni un navegador.
 * Solo usan `fetch`, nativo tanto en el navegador como en Node ≥18 (lo que
 * permite correr el test de este archivo con `node` directo).
 *
 * CommonJS (`module.exports`), igual que el resto del código Node del
 * motor — cuando esto se importe desde HIS-RIS-PACS.jsx (que usa `import`
 * porque lo empaqueta esbuild/Vite), el propio empaquetador resuelve la
 * interoperabilidad CJS→ESM sola; es un patrón común, no hace falta
 * duplicar el archivo en dos sintaxis.
 *
 * Ningún estado acá — cada función recibe `apiBase` explícito, nunca un
 * default hardcodeado, para que HIS-RIS-PACS.jsx decida la URL real según
 * dónde esté desplegado (dev, staging, producción).
 */

async function cargarWorklist(apiBase) {
  const res = await fetch(`${apiBase}/worklist`);
  if (!res.ok) throw new Error(`GET /worklist → ${res.status}`);
  return res.json();
}

async function crearRegistro(apiBase, registro) {
  const res = await fetch(`${apiBase}/worklist`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(registro),
  });
  if (!res.ok) throw new Error(`POST /worklist → ${res.status}`);
  return res.json();
}

async function actualizarRegistro(apiBase, id, cambios) {
  const res = await fetch(`${apiBase}/worklist/${id}`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(cambios),
  });
  if (!res.ok) throw new Error(`PATCH /worklist/${id} → ${res.status}`);
  return res.json();
}

/** Upsert de un registro con id explícito — usado para sembrar/resetear
    datos de demo sin duplicar (ver sembrarSiVacio/restablecerDemo abajo). */
async function ponerRegistro(apiBase, id, registro) {
  const res = await fetch(`${apiBase}/worklist/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(registro),
  });
  if (!res.ok) throw new Error(`PUT /worklist/${id} → ${res.status}`);
  return res.json();
}

/**
 * Si el store está vacío (primera vez que arranca contra un motor nuevo),
 * lo puebla con los datos de demo — mismo espíritu que el SEED hardcodeado
 * de antes, ahora contra la API real en vez de useState local. Si ya hay
 * datos (de esta demo o de uso real), NO los toca — nunca pisa trabajo real
 * por asumir que está vacío.
 */
async function sembrarSiVacio(apiBase, registrosSemilla) {
  const actuales = await cargarWorklist(apiBase);
  if (actuales.length > 0) return { sembrado: false, datos: actuales };
  for (const r of registrosSemilla) {
    await ponerRegistro(apiBase, String(r.id), r);
  }
  return { sembrado: true, datos: await cargarWorklist(apiBase) };
}

/**
 * "Restablecer demo": repone cada registro semilla a su valor original,
 * por id — usa upsert (PUT), así que NO borra registros que no sean parte
 * de la semilla (ej. uno creado con Ingreso manual durante la sesión).
 * Reset acotado a los ids conocidos, no un "borrar todo".
 */
async function restablecerDemo(apiBase, registrosSemilla) {
  for (const r of registrosSemilla) {
    await ponerRegistro(apiBase, String(r.id), r);
  }
  return cargarWorklist(apiBase);
}

module.exports = { cargarWorklist, crearRegistro, actualizarRegistro, ponerRegistro, sembrarSiVacio, restablecerDemo };
