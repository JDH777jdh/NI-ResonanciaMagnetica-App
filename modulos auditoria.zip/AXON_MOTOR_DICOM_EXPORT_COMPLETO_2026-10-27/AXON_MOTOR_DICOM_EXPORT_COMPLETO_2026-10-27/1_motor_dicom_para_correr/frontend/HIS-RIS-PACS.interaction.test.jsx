// @vitest-environment jsdom
/**
 * HIS-RIS-PACS.interaction.test.jsx — reescrito el 26-ago-2026, endurecido
 * contra flakiness el 31-ago-2026.
 *
 * La versión anterior de este archivo (Adenda 3, 21-jul-2026) probaba el
 * componente con `useState(SEED)` puramente local — 4 tests, sin red de
 * por medio, todo síncrono. Ya no aplica: desde el 26-ago-2026 el
 * componente habla con una WorklistApiServer real (fetch real, carga
 * asíncrona, polling). Los 3 escenarios de esa Adenda se preservan y se
 * adaptan acá (§9 fecha, §10 ingreso manual + match RUT, §11 tótem +
 * ciclo de bono) — más un test nuevo que no existía antes y que es, de
 * los 4, el que más importa: confirma que un C-STORE real, disparado por
 * FUERA de React (con el mismo cliente DIMSE crudo que usan los tests del
 * motor), hace que la UI se entere sola vía polling — sin ningún timer
 * falso, sin ningún mock.
 *
 * Endurecido el 31-ago-2026: con el polling real corriendo (200ms en
 * estos tests), una búsqueda instantánea (`getByText`) justo después de
 * un `fireEvent.click` puede caer en una foto intermedia — un poll se
 * re-renderiza en el medio y el elemento que se buscaba todavía no está
 * en el estado esperado. La solución (confirmada con Testing Library):
 * nunca separar "esperar a que algo exista" de "actuar sobre eso" en dos
 * pasos con una brecha síncrona entre medio — ver `clickResiliente()` más
 * abajo, que hace ambas cosas como una sola unidad reintentable. Se
 * confirmó con 10 corridas seguidas sin fallas después de este cambio.
 *
 * Cada test arranca su propia WorklistApiServer real, en un puerto
 * efímero, con un store JSON temporal aislado — nada se comparte entre
 * tests, nada queda pegado de una corrida a la siguiente.
 */
import { describe, test, expect, beforeEach, afterEach } from 'vitest';
import React from 'react';
import http from 'http';
import net from 'net';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { render, screen, within, fireEvent, waitFor, cleanup } from '@testing-library/react';
import HISRisPacsImaging from './HIS-RIS-PACS.jsx';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ENGINE_SRC = path.join(__dirname, '..', 'src');
const WorklistApiServer = require(path.join(ENGINE_SRC, 'server', 'WorklistApiServer'));
const { iniciarServidor, MODALITY_WORKLIST_SOP_CLASS } = require(path.join(ENGINE_SRC, 'server', 'AssociationServer'));
const PDU = require(path.join(ENGINE_SRC, 'pdu', 'PDU'));
const DIMSE = require(path.join(ENGINE_SRC, 'pdu', 'DimseCommand'));
const ImplicitVR = require(path.join(ENGINE_SRC, 'pdu', 'ImplicitVrCodec'));

const POLL_RAPIDO_MS = 200; // en producción son 4000ms — acá se acorta para no esperar segundos reales por test

let ALMACEN, API_SERVER, API, WORKDIR;

beforeEach(async () => {
  WORKDIR = fs.mkdtempSync(path.join(require('os').tmpdir(), 'his-ris-pacs-test-'));
  ALMACEN = path.join(WORKDIR, 'almacen');
  fs.mkdirSync(ALMACEN, { recursive: true });
  const storePath = path.join(ALMACEN, '.worklist-store.json');
  API_SERVER = http.createServer(WorklistApiServer.crearHandler({ storePath }));
  await new Promise((r) => API_SERVER.listen(0, r));
  API = `http://127.0.0.1:${API_SERVER.address().port}`;
});
afterEach(() => {
  cleanup();
  API_SERVER.close();
  fs.rmSync(WORKDIR, { recursive: true, force: true });
});

/** Espera a que desaparezca la pantalla de carga inicial — mismo punto de
    partida para todos los tests de este archivo. */
async function renderYEsperarCarga(props = {}) {
  render(<HISRisPacsImaging apiBaseUrl={API} pollIntervalMs={POLL_RAPIDO_MS} {...props} />);
  await waitFor(() => expect(screen.queryByText('Conectando con el motor DICOM…')).toBeNull(), { timeout: 5000 });
}

/**
 * Busca un elemento (con `buscar()`, evaluado de nuevo en cada intento) y
 * lo clickea, como una sola unidad reintentable — en vez de separar
 * "esperar a que exista" de "clickearlo" en dos pasos con una brecha
 * síncrona entre medio. Esa brecha es justo donde un poll (200ms en estos
 * tests) puede re-renderizar con una foto intermedia y hacer fallar un
 * `getByText` instantáneo que ya quedó viejo — el mismo patrón que
 * `findByText` resuelve para una búsqueda sola, pero acá hace falta
 * también para la ACCIÓN (el click), no solo para la búsqueda.
 * El click siempre es idempotente en este componente (seleccionar el
 * mismo id de nuevo, con los mismos datos), así que reintentarlo es
 * seguro — nunca duplica ni corrompe nada por ejecutarse más de una vez.
 */
async function clickResiliente(buscar, opts) {
  await waitFor(() => { fireEvent.click(buscar()); }, opts);
}

describe('HIS-RIS-PACS — cableado real (API + motor DICOM), no useState local', () => {
  test('el selector de fecha (§9) existe y responde a cambios', async () => {
    await renderYEsperarCarga();
    const inputFecha = document.querySelector('input[type="date"]');
    expect(inputFecha).toBeTruthy();
    fireEvent.change(inputFecha, { target: { value: '2026-08-26' } });
    expect(inputFecha.value).toBe('2026-08-26');
  });

  test('"Ingreso manual" solo vive en la pestaña Worklist (§10)', async () => {
    await renderYEsperarCarga();
    expect(screen.getByText('Ingreso manual')).toBeTruthy(); // activeFase por defecto es "worklist"
    fireEvent.click(screen.getByText('Agendados'));
    expect(screen.queryByText('Ingreso manual')).toBeNull();
  });

  test('autoatención por tótem: fast-track de Agendados a Worklist, sincronizado con la API real (§11b)', async () => {
    await renderYEsperarCarga();
    fireEvent.click(screen.getByText('Agendados'));
    await clickResiliente(() => screen.getByText('María Elena Rojas P.'));
    expect(await screen.findByText('Autoatención (tótem)')).toBeTruthy();

    await clickResiliente(() => screen.getByText('Autoatención (tótem)'));
    await waitFor(() => {
      expect(within(document.querySelector('table')).queryByText('María Elena Rojas P.')).toBeNull();
    });

    await clickResiliente(() => screen.getByLabelText('Cerrar panel'));
    fireEvent.click(screen.getByText('Worklist · RIS'));
    await waitFor(() => {
      expect(within(document.querySelector('table')).getByText('María Elena Rojas P.')).toBeTruthy();
    });

    // Confirmación real (no solo en la UI): el registro efectivamente quedó
    // persistido en el motor con fase "worklist" — se verifica leyendo la
    // API directo, no solo confiando en lo que muestra la pantalla.
    const enServidor = await (await fetch(`${API}/worklist?fase=worklist`)).json();
    expect(enServidor.some((r) => r.nombre === 'María Elena Rojas P.')).toBe(true);

    // Con estado "arribado" (no Almacenado todavía), no debe aparecer en Admisión
    fireEvent.click(screen.getByText('Admisión'));
    await waitFor(() => {
      expect(within(document.querySelector('table')).queryByText('María Elena Rojas P.')).toBeNull();
    });
  });

  test('ingreso manual (§10): match de RUT existente reutiliza el mismo CUP, y el bono presencial hace su ciclo completo hasta Validar (§11a/b.2/b.3)', async () => {
    await renderYEsperarCarga();

    fireEvent.click(screen.getByText('Ingreso manual'));
    expect(await screen.findByText('Ingreso manual de paciente')).toBeTruthy();

    const inputRut = screen.getByPlaceholderText('12.345.678-9');
    fireEvent.change(inputRut, { target: { value: '9.333.444-5' } }); // RUT de Isidora Vergara (SEED id 3)
    expect(await screen.findByText(/Ya existe: Isidora Vergara T\./)).toBeTruthy();

    fireEvent.change(screen.getByPlaceholderText('Nombre y apellidos'), { target: { value: 'Isidora Vergara T.' } });
    fireEvent.change(screen.getByPlaceholderText('Ej. TC tórax sin contraste'), { target: { value: 'RX tobillo derecho' } });

    const botonConfirmar = screen.getByText('Ingresar y enviar a Admisión');
    expect(botonConfirmar.disabled).toBe(false);
    fireEvent.click(botonConfirmar);
    // crearIngresoManual ahora es async (POST real a la API) — hay que
    // esperar a que resuelva antes de que el modal se cierre solo.
    await waitFor(() => expect(screen.queryByText('Ingreso manual de paciente')).toBeNull());
    expect(await screen.findByText('Isidora Vergara T.')).toBeTruthy();

    // El nuevo registro debe compartir el CUP real de Isidora (no uno nuevo) — verificado contra la API, no solo la UI.
    const enServidorTrasIngreso = await (await fetch(`${API}/worklist`)).json();
    const isidoraOriginal = enServidorTrasIngreso.find((r) => r.id === '3');
    const ingresoNuevo = enServidorTrasIngreso.find((r) => r.nombre === 'Isidora Vergara T.' && r.id !== '3');
    expect(ingresoNuevo).toBeTruthy();
    expect(ingresoNuevo.cup).toBe(isidoraOriginal.cup);

    // A partir de acá, cada fila se busca de nuevo en el momento de usarla
    // (nunca se guarda una referencia 'fila' capturada antes de renders
    // intermedios) — eso, junto con clickResiliente(), es lo que evita la
    // clase de falla intermitente encontrada hoy (ver dossier §16/§17).

    // §11a — ingresar el bono presencial
    await clickResiliente(() => within(screen.getByText('Isidora Vergara T.').closest('tr')).getByText('Ingresar bono'));
    const inputBono = await screen.findByPlaceholderText('N° de bono…');
    fireEvent.change(inputBono, { target: { value: 'BN-000123' } });
    await clickResiliente(() => screen.getByText('Guardar'));
    await waitFor(() => {
      const fila = screen.getByText('Isidora Vergara T.').closest('tr');
      expect(within(fila).getByText('BN-000123 · pendiente')).toBeTruthy();
    });

    // Avanzar hasta Almacenado: Completar admisión -> Worklist -> Guardar
    await clickResiliente(() => screen.getByText('Isidora Vergara T.'));
    await clickResiliente(() => screen.getByText('Completar admisión → Arribado'));
    await clickResiliente(() => screen.getByLabelText('Cerrar panel'));

    fireEvent.click(screen.getByText('Worklist · RIS'));
    await clickResiliente(() => within(document.querySelector('table')).getByText('Isidora Vergara T.'));
    await clickResiliente(() => screen.getByText('Guardar'));

    // Real desde hoy: acá NO hay setTimeout fingiendo el C-STORE. Hay que
    // mandar uno real por DIMSE — mismo mecanismo que usaría un equipo —
    // copiando el Accession Number que el registro tiene en el servidor.
    const registroParaCStore = (await (await fetch(`${API}/worklist?fase=worklist`)).json()).find((r) => r.nombre === 'Isidora Vergara T.');
    expect(registroParaCStore).toBeTruthy();

    const motor = iniciarServidor({ port: 0, almacenPath: ALMACEN, tlsOptions: null }); // mismo ALMACEN → mismo store que la API
    await new Promise((r) => motor.once('listening', r));
    await mandarCStoreReal(motor.address().port, registroParaCStore.acc, registroParaCStore.nombre);
    motor.close();

    // El polling (200ms en este test) debería recoger el cambio solo, sin más intervención.
    await waitFor(() => {
      const filaFinal = within(document.querySelector('table')).queryByText('Isidora Vergara T.');
      expect(filaFinal).toBeNull(); // ya no está en Worklist — pasó a Exámenes
    }, { timeout: 3000 });

    fireEvent.click(screen.getByText('Admisión'));
    await waitFor(() => {
      const filaConAlerta = within(document.querySelector('table')).getByText('Isidora Vergara T.').closest('tr');
      expect(within(filaConAlerta).getByText((t) => t.startsWith('Bono BN-000123'))).toBeTruthy();
    });

    // §11b.2/b.3 — la mini-ventana ofrece las 3 salidas
    await clickResiliente(() => {
      const filaConAlerta = within(document.querySelector('table')).getByText('Isidora Vergara T.').closest('tr');
      return within(filaConAlerta).getByText((t) => t.startsWith('Bono BN-000123'));
    });
    expect(await screen.findByText('Validar bono')).toBeTruthy();
    expect(screen.getByText('Anular bono')).toBeTruthy();
    expect(screen.getByText('Reagendar en su lugar')).toBeTruthy();

    fireEvent.click(screen.getByText('Validar bono'));
    await waitFor(() => {
      expect(within(document.querySelector('table')).queryByText('Isidora Vergara T.')).toBeNull();
    });
  });

  test('LA PRUEBA QUE IMPORTA: un C-STORE real, disparado por FUERA de React, hace que la UI lo muestre sola — sin mocks, sin timers falsos', async () => {
    await renderYEsperarCarga();

    // Tomamos un paciente real de la SEED que ya está en fase "worklist"
    // (Patricio Salgado H., id 12) — su Accession Number lo leemos de la
    // API real, no lo recalculamos a mano (evita duplicar la fórmula de
    // makeACC acá y depender de que no cambie).
    fireEvent.click(screen.getByText('Worklist · RIS'));
    await waitFor(() => expect(within(document.querySelector('table')).getByText('Patricio Salgado H.')).toBeTruthy());

    const registro = (await (await fetch(`${API}/worklist?fase=worklist`)).json()).find((r) => r.nombre === 'Patricio Salgado H.');
    expect(registro).toBeTruthy();
    expect(registro.estado).not.toBe('almacenado'); // todavía no, es el punto de partida

    // Arrancamos el motor DICOM real sobre el MISMO almacén que ya está
    // sirviendo esta instancia de la API — es la prueba de que ambos
    // comparten una sola fuente de verdad (§12 del dossier).
    const motor = iniciarServidor({ port: 0, almacenPath: ALMACEN, tlsOptions: null });
    await new Promise((r) => motor.once('listening', r));

    // Un equipo real (o el test-harness, es indistinguible para el motor)
    // manda C-STORE copiando el Accession Number que vio — PS3.4, el
    // mismo mecanismo con el que un escáner real amarra la imagen a la
    // orden. React no sabe que esto está pasando — nadie llama ninguna
    // función del componente.
    await mandarCStoreReal(motor.address().port, registro.acc, registro.nombre);
    motor.close();

    // La UI, que sigue montada y con su polling corriendo solo, tiene que
    // enterarse — sin que el test toque el componente para nada.
    await waitFor(() => {
      expect(within(document.querySelector('table')).queryByText('Patricio Salgado H.')).toBeNull(); // ya no en Worklist
    }, { timeout: 3000 });

    fireEvent.click(screen.getByText('Exámenes · PACS'));
    await waitFor(() => {
      const fila = within(document.querySelector('table')).getByText('Patricio Salgado H.').closest('tr');
      expect(within(fila).getByText('Almacenado')).toBeTruthy();
    });
  });
});

/** Cliente DIMSE crudo mínimo — mismo patrón que usan engine.e2e.test.js y
    worklist-store.e2e.test.js del motor, reutilizado acá para disparar un
    C-STORE real desde un test de React. No es un mock: es el mismo
    protocolo binario que hablaría un equipo real. */
function mandarCStoreReal(port, accessionNumber, nombrePaciente) {
  return new Promise((resolve, reject) => {
    const socket = net.connect(port, '127.0.0.1');
    let buffer = Buffer.alloc(0);
    const cola = []; const esperando = [];
    function siguientePdu(t = 3000) {
      return new Promise((res, rej) => {
        if (cola.length) return res(cola.shift());
        const tm = setTimeout(() => rej(new Error('timeout DIMSE')), t);
        esperando.push((p) => { clearTimeout(tm); res(p); });
      });
    }
    socket.on('data', (chunk) => {
      buffer = Buffer.concat([buffer, chunk]);
      let header;
      while ((header = PDU.peekPduHeader(buffer)) && buffer.length >= header.totalSize) {
        const pdu = buffer.slice(0, header.totalSize); buffer = buffer.slice(header.totalSize);
        if (esperando.length) esperando.shift()(pdu); else cola.push(pdu);
      }
    });
    socket.on('error', reject);
    socket.once('connect', async () => {
      try {
        socket.write(PDU.encodeAssociateRQ({
          calledAE: 'AXON_RIS', callingAE: 'CT_SALA1',
          presentationContexts: [
            { id: 1, abstractSyntax: MODALITY_WORKLIST_SOP_CLASS, transferSyntaxes: ['1.2.840.10008.1.2'] },
            { id: 5, abstractSyntax: '1.2.840.10008.5.1.4.1.1.2', transferSyntaxes: ['1.2.840.10008.1.2'] },
          ],
          maxPduLength: 16384, implementationClassUID: '1.2.840.99999.1.1',
        }));
        await siguientePdu(); // A-ASSOCIATE-AC (no se decodifica en detalle acá, ya se prueba aparte en el motor)

        const sopInstanceUID = `1.2.826.0.1.3680043.99999.${Date.now()}`;
        const dataset = ImplicitVR.encodeDataset([
          { tag: '00100010', vr: 'PN', value: nombrePaciente },
          { tag: '00080050', vr: 'SH', value: accessionNumber },
          { tag: '00080060', vr: 'CS', value: 'CT' },
          { tag: '0020000D', vr: 'UI', value: `1.2.826.0.1.3680043.99999.${Date.now()}.1` },
          { tag: '0020000E', vr: 'UI', value: `1.2.826.0.1.3680043.99999.${Date.now()}.2` },
          { tag: '7fe00010', vr: 'OW', value: Buffer.from([1, 2, 3, 4]) },
        ]);
        socket.write(PDU.encodePDataTF([
          { presentationContextId: 5, isCommand: true, isLast: true, data: DIMSE.encodeCommandSet({ '00000002': '1.2.840.10008.5.1.4.1.1.2', '00000100': DIMSE.COMMAND_FIELD.C_STORE_RQ, '00000110': 2, '00000700': 0, '00000800': 0x0102, '00001000': sopInstanceUID }) },
          { presentationContextId: 5, isCommand: false, isLast: true, data: dataset },
        ]));
        const rspPdu = await siguientePdu();
        const rsp = DIMSE.decodeCommandSet(PDU.decodePDataTF(rspPdu)[0].data);
        if (rsp['00000900'] !== DIMSE.STATUS.SUCCESS) return reject(new Error('C-STORE no fue SUCCESS: 0x' + (rsp['00000900'] || 0).toString(16)));

        socket.write(PDU.encodeReleaseRQ());
        await siguientePdu();
        socket.end();
        resolve();
      } catch (e) { reject(e); }
    });
  });
}
