# AXON Workforce — Respuestas para el equipo MAIN · v2
**Fecha:** 2026-10-14 · **Reemplaza a** la v1 del 2026-10-09. Este archivo es solo para transmitir: la parte interna de Workforce (antes «Parte B») se separó.
**Insumos nuevos:** (1) la revisión a la v1 (`Revision md de workforce para main (gpt).docx`); (2) el análisis y las respuestas con las precisiones del propietario sobre CUT, voluntariado y RADE, Ley Karin y Core Lite (`para WORKFORCE - UnitShell.docx`). Contraste propio contra la Especificación de Identificadores v1.0, el Documento Maestro de Workforce y la tabla de Líneas (09-sep).

**Leyenda:** ✅ verificado por Workforce · ⚠️ verificado con matiz o por confirmar · ❓ no verificable desde el proyecto de Workforce
**Límites.** (1) `MasterIdentifierService.js` y los documentos «Respuesta a MAIN UnitShell» no están en el proyecto de Workforce: lo que se dice de ellos viene del análisis, no de una lectura propia. (2) Verificación documental y normativa; no es asesoría legal.

## Qué cambió respecto de la v1
- **Voluntarios:** se corrigió el ejemplo «empleado + voluntario bajo el mismo CUT». El voluntariado no es relación de trabajador y no genera CUT (§2.2).
- **Core Lite:** la pregunta sobre colaboradores quedó resuelta: un solo profesional, sin personal a cargo. El Maestro §75-76 debe enmendarse (§2.3).
- **Identificadores:** hallazgos verificados contra la especificación y cinco puntos reportados sobre el generador (§5).
- **Nuevo:** estado de resolución, matriz de interfaces, taxonomía por ejes (propuesta) y relojes de la Ley Karin con sus fuentes en conflicto.
- **Ley 21.431:** pasa a manos del propietario y su abogado; el diseño no debe dar por cierta ninguna exclusión (§7).
- **Ley Karin, 15 días:** el plazo del art. 211-E queda respaldado como interpretación de la DT (días hábiles judiciales), con fuentes que difieren (§6.2).

---

## 1. Estado de resolución
| # | Tema | Estado | Quién cierra |
|---|---|---|---|
| 1 | CUT = registro de un worker por tenant o microtenant (no por contrato ni asignación) | Decidido (propietario) | MAIN: enmendar Maestro §11.2 |
| 2 | Código de tenant dentro del CUT: 8 letras elegidas por el usuario; mismo formato en Core y Core Lite | Decidido (propietario) | MAIN: generador y registro de tenants (§5) |
| 3 | Voluntarios: no son trabajadores, sin CUT | Decidido (propietario) | — |
| 4 | Identificador de voluntariado (CUV, nombre de trabajo) | Propuesto, sin aprobar | Propietario (nombre) y MAIN (§120-121 de la especificación) |
| 5 | Beneficios para voluntarios de RADE | Sin definir; el propietario los estudia | Propietario |
| 6 | Core Lite: un solo profesional, sin personal a cargo | Decidido (propietario) | MAIN: enmendar Maestro §75-76 |
| 7 | Colaboración entre profesionales (juntas médicas, derivación nominativa, marketplace administrado por AXON Health) | Principio decidido; flujo por afinar | Propietario y dominios clínico/agenda |
| 8 | Ley 21.431 aplicada a Core Lite y al marketplace | Abierto: dictamen de abogado laboral | Propietario |
| 9 | Límite de horas para Core Lite | Abierto: depende del punto 8 | Propietario |
| 10 | Gestión de casos laborales (Ley Karin y convivencia) para Core y Health | Alcance decidido; relojes por validar | Abogado y Workforce |
| 11 | Contrato MAIN ↔ Workforce ↔ UnitShell (Position, OrgNode, Assignment, Role) | Abierto (P0) | MAIN |
| 12 | Taxonomía de relaciones por ejes | Propuesta para revisión | MAIN y Workforce |
| 13 | Nombre «AXON HOLDING FAMILY'S» | Abierto: confirmar si es nombre comercial o razón social | Propietario |

---

## 2. Decisiones del propietario que MAIN debe incorporar

### 2.1 CUT
- Un CUT identifica el **registro de un trabajador en un ámbito** (tenant; en Core Lite, el microtenant). Una persona que trabaja en AXON Health, en una institución Core y además tiene su propio Core Lite tiene **tres CUT** y sigue siendo **una sola persona** en la identidad canónica de MAIN.
- El CUT no reemplaza los identificadores de relación (Engagement), contrato o acuerdo, y asignación: cada uno tiene ID técnico, estado y vigencia propios. Dos contratos, o un cambio de unidad dentro del mismo ámbito, no emiten otro CUT.
- Un tenant no ve los CUT que la persona tiene en otro. La correspondencia entre ámbitos solo la resuelve el servicio de identidad de MAIN, bajo autorización.
- **Código de tenant:** 8 letras A-Z elegidas por el usuario en el alta, sin relleno ni truncado. Se reserva en un registro central, es único por país + región + código **sin importar si el tenant es Core o Core Lite**, y no cambia una vez operativo.
- ✅ Coincide con la especificación: §36 (CUT del tenant; el estado contractual se guarda aparte), §114 (cambiar de rol no cambia el CUT), §117 (cambiar de tenant emite el CUT del tenant de destino), §119 (Core Lite es un tenant único con su propio CUT).
- ✅ La unicidad entre Core y Core Lite se justifica en el §6 de la especificación: ambos tipos comparten la misma estructura textual (`CUIT-{ISO2}-{REG}-{TENANT8}-{SEQ4}-{CHK2}`) y solo se distinguen por `identifier_type`, de modo que dos tenants de distinto tipo con el mismo código y secuencia producirían la misma cadena.

### 2.2 Voluntarios y RADE
- Los voluntarios **no son trabajadores**: no reciben CUT ni se registran como Employment. Tampoco se reutiliza el CUP, que identifica al paciente (especificación §2-3).
- **Flujo propuesto por el propietario (RADE como primer filtro):**
  1. RADE: postulación y preselección.
  2. MAIN: resolución de identidad y detección de duplicados. El expediente lleva un identificador temporal, sin CUT ni identificador definitivo.
  3. RADE: evaluación y admisión (aptitud médica o psicológica cuando proceda, competencias, aceptación de condiciones).
  4. MAIN: emisión del identificador de voluntariado una vez admitido.
  5. Workforce + Document Engine: registro de la relación de voluntariado, vigencia, competencias y asignaciones; acuerdo, cláusulas y firmas.
  6. RADE: disponibilidad operativa para misiones compatibles con su aptitud y autorización efectiva.
- **Datos de salud:** la aptitud la evalúan profesionales competentes según la función. Workforce recibe solo el estado (apto, no apto, apto con restricciones), su vigencia y los requisitos operativos; no el informe clínico. Los requisitos se definen por función, riesgo y jurisdicción: no hay un examen universal.
- **Naturaleza jurídica:** un acuerdo de voluntariado no debe usarse para encubrir una relación laboral. Workforce distingue acuerdo de voluntariado de contrato de trabajo; la calificación la valida un abogado laboral.
- **Beneficios y compensaciones:** los define el propietario (en estudio). Se registran como categoría separada de la naturaleza jurídica de la relación. Viáticos y reembolsos, seguros y coberturas, apoyo económico autorizado y remuneración por trabajo son conceptos distintos; Account Core reconoce los hechos financieros que correspondan.
- ✅ La tabla de Líneas (09-sep) ya ubica el voluntariado de RADE en Workforce, bajo condiciones de aceptación y requisitos.
- ⚠️ Hay tres poblaciones: voluntarios externos, trabajadores de Health/Core/Core Lite que se ofrecen, y personal propio de RADE (empleo remunerado, con el CUT del ámbito de su empleador). Un trabajador que además es voluntario conserva su CUT como trabajador y tiene un registro de participación voluntaria separado. Falta decidir si los internos reciben también el código de voluntariado.

### 2.3 Core Lite
- Un microtenant tiene **un profesional titular**, que es el único usuario y el único trabajador: sin secretarias, auxiliares ni personal a cargo. ✅ Coincide con la especificación (§6 fila 11, §7.2 y §119).
- ⚠️ **El Maestro lo contradice:** §75 lista para Core Lite «Assistants, Secretaries, Delegation» y §76 («Core Lite como clínica individual») prevé secretaria, asistente, colaborador y registro de colaboradores. Debe enmendarse; prevalece la especificación.
- **Colaboración entre profesionales (propuesta, flujo por afinar):** el profesional conserva su identidad y su ámbito; no recibe CUT nuevo por participar en una junta, aceptar una derivación o usar el marketplace.
  | Situación | Registro propuesto |
  |---|---|
  | Junta médica por videoconferencia con otro profesional (Core Lite o Health) | Reunión clínica con participantes identificados en su ámbito, permisos de acceso, finalidad y trazabilidad |
  | Derivación nominativa (p. ej. un médico Core Lite deriva curaciones a una enfermera Core Lite concreta) | Derivación con consentimiento del paciente cuando corresponda, aceptación de la receptora, prestación, documentación y seguimiento; abre un episodio con responsabilidad clínica propia |
  | Marketplace administrado por AXON Health (los independientes solo consumen sus datos) | Oferta, coordinación, eventos y transacciones; no crea relación laboral |
- Estos flujos pertenecen a los dominios clínico, agenda y marketplace. Workforce aporta identidad profesional, credenciales y la bitácora de autonomía.

---

## 3. Contrato Workforce ↔ MAIN ↔ UnitShell

### 3.1 La cadena del trabajador
| Capa | Contenido |
|---|---|
| MAIN — identidad y contexto | Person · TenantContext · LegalEntityContext |
| Workforce — relación y trayectoria | Worker · Engagement · Contract (cuando corresponda) |
| Workforce + UnitShell — ubicación organizacional | Position · Organizational Assignment · OrgNode |
| MAIN — autorización efectiva | Role Assignment · credenciales y competencias · atributos ABAC · evaluación PBAC |
| UnitShell + Dashboard Engine | Contexto, navegación, workspace, dashboard y acciones habilitadas |
| Motor de dominio | Ejecuta el proceso y conserva su propia trazabilidad |

Position, Assignment, Delegation y Acting ya están definidos en el Maestro (§18, §34-35); lo que falta es su implementación. Position es un objeto de primera clase, no un texto del trabajador ni un sinónimo de rol. ❓ Los documentos UnitShell originales no están en el proyecto de Workforce; esta cadena proviene del análisis de su contenido.

### 3.2 Matriz de interfaces
| Dominio | Responsabilidad |
|---|---|
| MAIN / Identity | Identidad canónica, resolución de identidad y contexto autorizado |
| Master Identifier Service | Emisión y validación de identificadores según el tipo y el ámbito aprobados |
| Workforce | Relaciones de trabajador, cargos, asignaciones y procesos laborales que correspondan |
| RADE | Admisión operativa del voluntariado, aptitud requerida, preparación y gestión de rescates |
| UnitShell | Composición del contexto organizacional y operativo a partir de fuentes autorizadas |
| Document Engine | Documentos, acuerdos, firmas, versiones y trazabilidad documental |
| Account Core | Registro y contabilización de los hechos financieros que reciba de los dominios de origen |

### 3.3 Lo que Workforce necesita de MAIN
| Prioridad | Entregable o decisión |
|---|---|
| P0 | Semántica definitiva del CUT y cardinalidad persona / worker / relaciones (propuesta en §2.1) |
| P0 | Voluntariado como participación propia, sin equipararlo a Employment (propuesta en §2.2) |
| P0 | Modelo explícito de Position, asignación organizacional y asignación operativa, alineado con UnitShell |
| P0 | Catálogos separados de relaciones, posiciones y roles, con reglas de compatibilidad |
| P1 | Contrato de eventos e interfaces entre MAIN, Workforce, UnitShell, Dashboard Engine y Account Core: identificadores, campos obligatorios, versiones, autorización, errores, idempotencia, vigencias y cambios retroactivos |
| P1 | Propiedad de los eventos de calendario: fechas y reglas comunes (MAIN); turnos, asistencia y ausencias (Workforce); agenda de pacientes (Scheduling); reuniones y acuerdos formales (gobernanza); capacitaciones (Workforce o el dominio que se defina) |
| P1 | Reglas jurisdiccionales versionadas, con validación legal de los flujos sensibles |
| P1 | Pruebas de concurrencia de relaciones, cambios efectivos, permisos y aislamiento entre tenants |

Principio: un cambio de unidad o de cargo debe reflejarse en las asignaciones y los permisos efectivos sin borrar el historial ni obligar a reconstruir el workspace a mano.

---

## 4. Taxonomía de relaciones — propuesta para revisión (no aprobada)
El Maestro §8 no incluye el voluntariado. Se propone ocho familias, cada una clasificada en ejes independientes antes de congelar el catálogo.

**Familias:** (1) empleo dependiente · (2) nombramiento estatutario público · (3) prestación independiente · (4) personal de terceros asignado · (5) voluntariado (participación, no relación laboral) · (6) estancia formativa · (7) profesional visitante o afiliado · (8) otras vinculaciones no laborales autorizadas.

| Eje | Ejemplos |
|---|---|
| Familia de relación | Empleo dependiente, prestación independiente, participación voluntaria |
| Régimen jurídico aplicable | Código del Trabajo, régimen estatutario público, otro que corresponda |
| Modalidad contractual o instrumento | Contrato laboral, acuerdo de prestación, acuerdo de voluntariado |
| Procedencia del personal | Directo, contratista, subcontratista, agencia, afiliado, externo |
| Modalidad de pago o beneficio | Remuneración, honorario, reembolso, viático, otra |
| Asignación | Cargo, unidad, servicio, ubicación, turno o misión |

- No mezclar la naturaleza de la relación con el régimen, la modalidad ni la procedencia: «honorario» no siempre equivale a «independiente» y «personal externo» describe una procedencia, no una naturaleza jurídica.
- El voluntariado comparte infraestructura (identidad, accesos, vigencias, auditoría) pero no las reglas laborales ni el flujo de empleo.
- Los catálogos de relaciones, posiciones y roles (`roles.config.js`) se mantienen separados y se cruzan por reglas de compatibilidad; no se fusionan.

---

## 5. Identificadores

### 5.1 Verificado por Workforce
- ✅ **CHK2:** los 14 ejemplos de la especificación con CHK2 calculable y los 2 vectores oficiales del §81 coinciden con SHA-256 → primer byte → letra + dígito (A0-Z5). Los ejemplos `…-N8` (§78, error intencional) y `…-89` (§88, hexadecimal legacy) no coinciden, como corresponde. Lista en el Anexo.
- ⚠️ **Ejemplo del §35:** `CUIT-CL-13-DRSMITH-0001-XX` tiene 7 letras y un CHK2 de relleno. Contradice la regla de 8 letras; el resto de los ejemplos de TENANT8 (`CLIMEDSA`, `UNINAMEX`) tienen 8. Corregir el ejemplo.
- ⚠️ **Capacidad de SEQ4:** el §72 fija 10.000 valores por secuencia y el §5 prohíbe reutilizar identificadores, incluso de trabajadores que ya salieron. En un tenant grande, o en AXON Health, el tope puede alcanzarse. Decidir qué ocurre al agotarlo (el §121 exige proceso de cambio) antes de emitir.
- ⚠️ **Maestro §11.2** llama al CUT «identificador interno de la relación de workforce», lo que puede leerse como un CUT por relación. Enmendar a «identificador del worker en el tenant».
- Nuestro CUT provisional difiere del real: SEQ8 en vez de SEQ4, hash hexadecimal en vez de CHK2, y el segmento `AXON` en todos los casos, aunque en Core y Core Lite debería ir el TENANT8 del tenant.

### 5.2 Reportado sobre `MasterIdentifierService.js` (❓ Workforce no tiene el archivo)
Se pide a MAIN confirmar y corregir:
1. `generarCUT()` rellena con `X` y trunca el código de tenant; debe rechazar lo que no sean exactamente 8 letras A-Z y decir por qué.
2. El validador acepta alfanuméricos en el segmento de tenant; deben ser solo letras.
3. `generarCUTAxon()` usa el segmento `AXON` (4 caracteres) y el validador genérico exige 8: ese CUT no pasa `validarCUT()` y por lo tanto falla `decodificarCUT()` y `revocarCUT()`. Resolver con validación específica de la familia, sin romper los identificadores ya emitidos.
4. `cutAFHIRIdentifier()` etiqueta todo CUT como «Employee Identifier»; el tipo debe salir de `identifier_type` (un honorario, contratista o voluntario no es «empleado»).
5. El generador recibe la secuencia de quien lo llama: unicidad, reserva de códigos de tenant, concurrencia e idempotencia deben quedar en el backend transaccional.

Se pide además pruebas de generación, validación, decodificación y revocación para todas las familias, incluidos los vectores del Anexo.

---

## 6. Casos laborales (Ley Karin y convivencia)
Capacidad transversal de Workforce para Core y Health, y para cualquier organización con trabajadores. Lo estructural (flujos, ramas, expediente) está decidido; los plazos requieren validación jurídica.

### 6.1 Flujo y ramas (propuesta del equipo de análisis)
**Flujo:** A. recepción y clasificación → B. protección inmediata y evaluación inicial → C. selección de procedimiento → D. investigación y antecedentes → E. conclusión y plan correctivo → F. seguimiento y cierre.

| Rama | Acciones que Workforce debe gestionar |
|---|---|
| Acoso sexual, acoso laboral o violencia en el trabajo (procedimiento legal) | Recepción formal, resguardo inmediato, investigador imparcial, citaciones, entrevistas, relatos, pruebas, conclusiones y trámite ante la autoridad |
| Violencia de terceros (paciente, usuario, proveedor) | Protección del trabajador, gestión del incidente de seguridad, preservación de evidencia y procedimiento laboral cuando proceda |
| Conflicto interpersonal o de convivencia sin denuncia legal | Evaluación preventiva, intervención, mediación opcional, medidas organizacionales y seguimiento, sin encubrir hechos que deban investigarse |
| Riesgo psicosocial u organizacional | Evaluación de carga, turnos, supervisión y formación; medidas preventivas |
| Riesgo físico, amenaza grave o posible delito | Seguridad y emergencias, protección inmediata y derivación a las autoridades sin esperar la investigación laboral |
| Denuncia que involucra a quien investiga o decide | Reasignación a una persona competente e imparcial, manejo del conflicto de interés y control de acceso |
| Institución pública | Derivación al procedimiento administrativo que corresponda (investigación sumaria o sumario), según su estatuto (⚠️ confirmar con abogado) |

**Principios:**
- La mediación no es una etapa previa obligatoria ni sustituye la investigación formal cuando esta es exigible.
- La atención psicológica temprana es una medida de resguardo; no equivale a una pericia psicológica dentro de la investigación. Las evaluaciones médicas o psicológicas no se activan automáticamente: deben ser pertinentes, tener fundamento y ser realizadas por profesionales competentes, con los informes clínicos separados del expediente laboral ordinario.
- Expediente reservado, con bitácora de acceso, custodia de evidencia, versiones, notificaciones, plazos y conflictos de interés. La IA puede organizar antecedentes o avisar vencimientos; no decide credibilidad, culpabilidad ni sanción.
- Cada tenant configura su reglamento, responsables, canales y medidas. En Core Lite corresponden mecanismos de incidentes y reclamos; la rama jurídica depende de la naturaleza real de la relación, no de la etiqueta «independiente».
- ✅ El CEAL-SM/SUSESO viene del Protocolo de Vigilancia de Riesgos Psicosociales (centros de trabajo con 10 o más trabajadores), no es una exigencia propia de la Ley Karin; conviene corregirlo donde se haya listado dentro de ella.

### 6.2 Relojes: lo que dicen las fuentes
| Reloj | Plazo según las fuentes | Estado |
|---|---|---|
| Medidas de resguardo cuando la denuncia entra por la DT | La DT instruye en 2 días hábiles (guía IST) | ✅ |
| Empleador: investigar internamente o derivar a la DT | 3 días (folleto de la DT, sin calificar); un diagrama no oficial dice 3 días corridos | ⚠️ tipo de día |
| Investigación interna | 30 días (folleto de la DT); un diagrama no oficial dice corridos desde la denuncia | ⚠️ tipo de día |
| Remisión del informe a la DT | 2 días (nota de prensa y diagrama) frente a 5 días (sentencia citada en pjud.cl) | ⚠️ conflicto |
| Pronunciamiento de la DT | 30 días (hábiles, según el diagrama); si no se pronuncia, se consideran válidas las conclusiones del informe del empleador (varias fuentes concordantes) | ✅ el plazo; ⚠️ el tipo de día |
| Medidas o sanciones del empleador | Art. 211-E: «quince días contados desde su recepción». La DT (folleto y dictamen citado por la prensa) los entiende como 15 días hábiles judiciales desde la notificación de la Inspección; otras fuentes dicen corridos | ✅ la interpretación de la DT; ⚠️ fuentes que difieren |

**Consecuencia de diseño:** cada plazo es una regla versionada con el evento que lo inicia, el actor obligado, el **tipo de día** (corrido, hábil, hábil judicial), la fuente y la vigencia. Los números de esta tabla no deben copiarse al código sin validación de un abogado. ❓ Una precisión de la DT de febrero de 2026 sobre denuncias inconsistentes (plazo razonable para complementarlas) viene del análisis y no se verificó.

---

## 7. Core Lite y Ley 21.431 — en manos del propietario y su abogado
La tabla de Líneas dice que Core Lite está «excluido de la Ley 21.431». El texto de la ley define a la empresa de plataforma por lo que hace y solo excluye a las que se limitan a publicar avisos de servicios (art. 152 quáter Q); no hay una exclusión expresa para profesionales de salud. Hasta el dictamen, el diseño no debe dar por cierta ninguna exclusión.

Lo que sí se puede decidir ya, sin esperar el dictamen:
- Mantener **cinco controles separados**, cada uno como regla versionada por régimen y vigencia: (1) tope interno de horas acumuladas (política de AXON); (2) bloque de desconexión continua de 12 horas dentro de 24 para independientes de plataforma, si aplica (art. 152 quáter Z); (3) tiempo máximo de conexión continua fijado en el contrato (art. 152 quáter X, letra f); (4) límite diario y semanal del dependiente, si la relación calificara como dependiente (la DT, en febrero de 2026, mantuvo 10 horas diarias para el dependiente de plataforma que distribuye libremente su jornada); (5) piso de honorarios por hora de servicio efectivo, condicionado a la aplicabilidad (art. 152 quáter Y).
- Validar en el backend, no solo en la interfaz, con ventana móvil de 24 horas y sin reiniciar contadores por cambio de fecha. Un tope de «12 horas de trabajo, no necesariamente continuas» no equivale al bloque de desconexión continua: son controles distintos.
- Registrar sesiones, disponibilidad, servicios ejecutados, desconexiones y cambios, distinguiendo horas de servicio efectivo de disponibilidad.
- Separar tres funciones: licencia del software, operación del marketplace (AXON Health, según el propietario) y prestación clínica independiente. La conclusión legal depende de qué entidad opera qué y bajo qué contratos.

---

## 8. Órganos y trasplantes (requisito futuro, fuera de Workforce)
El ciclo donante–extracción–receptor se modelaría con objetos separados: episodio del donante, identificador trazable del órgano o injerto, registro de extracción, cadena de custodia y transporte, episodio del receptor y vínculo de trazabilidad protegido, sin reemplazar el paciente asociado a un órgano por otro. Requiere su propia familia de identificadores (proceso §120-121). ⚠️ La base legal (Ley 19.451) no está verificada: la doctrina chilena menciona un principio de confidencialidad de los datos de donante y receptor, pero no se pudo confirmar el texto exacto de la prohibición que cita el análisis.

---

## 9. Preguntas para MAIN
1. ¿Adoptan las enmiendas al Maestro: §11.2 (CUT = worker por tenant) y §75-76 (Core Lite sin personal)?
2. Generador de identificadores: ¿pueden compartir el archivo vigente con los cinco puntos de §5.2 corregidos y las pruebas pedidas? Workforce lo necesita para reemplazar su CUT provisional.
3. Especificación: corregir el ejemplo del §35 (7 letras) y definir qué ocurre al agotarse SEQ4.
4. CUV: ¿alcance (solo voluntarios externos o también trabajadores que se ofrecen) y quién conduce el proceso del §120-121?
5. Contrato de Position, OrgNode, Assignment y Role (P0): ¿cuándo se comparte y en qué formato?
6. Reglas de compatibilidad entre los catálogos de relaciones, posiciones y roles.
7. Taxonomía por ejes: ¿pueden clasificar cada categoría de §4 en los seis ejes?
8. Propiedad de los eventos de calendario (turnos, agenda, reuniones, capacitaciones).
9. Reglas jurisdiccionales: ¿quién valida los relojes de la Ley Karin (§6.2) y cómo se versionan?
10. UnitShell: ¿pueden compartir los dos documentos originales, que no están en el proyecto de Workforce?

*El nombre «AXON HOLDING FAMILY'S» (fila 13 de §1) es decisión del propietario, no de MAIN.*

---

## Anexo — Vectores CHK2 verificados
Método: base = identificador sin el sufijo CHK2; SHA-256 sobre UTF-8; primer byte `b`; CHK2 = letra (A=0 … Z=25, índice `b ÷ 10`) + dígito (`b mod 10`).

`CUP-CL-13-2026-00000047-N7` (0x89) · `CUP-NN-CL-13-2026-00000001-W4` (0xE0) · `CUP-RN-CL-13-2026-00000001-N3` · `CUT-CL-13-AXON-0001-E9` · `CUT-AXON-ADM-CL-0001-F7` · `CUT-AXON-WLD-US-01-0001-J3` · `CUTG-AXON-WLD-US-01-0001-M9` · `CUT-AXON-CTRY-CL-13-0001-B2` · `CUTG-AXON-CTRY-CL-13-0001-L2` · `CUIT-CL-13-AXON-0001-B3` · `CUC-AXON-CL-13-UNINAMEX-2026-4722-G8` · `CUIT-CL-13-CLIMEDSA-0001-W7` · `CUT-CL-13-CLIMEDSA-0001-I0` · `CUC-CL-13-CLIMEDSA-2026-472-F0`

## Fuentes consultadas
- Ley 21.431 (Diario Oficial, 11-mar-2022): https://www.diariooficial.interior.gob.cl/publicaciones/2022/03/11/43200/01/2099107.pdf · art. 152 quáter Z: https://www.derechopedia.cl/Artículo_152_quáter_Z_del_Código_del_Trabajo
- DT, dictamen de febrero de 2026 sobre plataformas: https://dt.gob.cl/legislacion/1624/w3-article-128898.html — resumen: https://www.diarioconstitucional.cl/2026/02/27/aplicacion-de-la-ley-n21-561-jornada-laboral-y-remuneraciones-en-trabajadores-de-plataformas-digitales/
- Ley Karin — folleto de la DT: https://teleduc.uc.cl/wp-content/uploads/2024/07/DIPTICO-LEY-KARIN-TRABAJADORES-WEB.pdf · art. 211-E: https://www.derechopedia.cl/Artículo_211_E_del_Código_del_Trabajo · guía IST: https://ist.cl/wp-content/uploads/2024/06/Guia-para-el-desarrollo-de-reglamento-de-investigacion-y-sanciones.pdf
- Ley Karin — prensa y otras fuentes (plazos en conflicto): T13 https://www.t13.cl/noticia/nacional/amonestaciones-multas-incluso-despido-sanciones-impone-ley-karin-sobre-abuso-3-7-2024 · CNN Chile https://www.cnnchile.com/pais/contra-el-acoso-laboral-y-la-violencia-en-el-trabajo-como-funciona-y-que-establece-la-ley-karin/ · Poder Judicial https://www.pjud.cl/prensa-y-comunicaciones/getRulingNew/34124 · diagrama no oficial https://www.politecnicosanluis.cl/wp-content/uploads/2024/09/Diagrama-de-Denuncias-Ley-Karin.pdf
- CEAL-SM: SUSESO https://www.suseso.gob.cl/606/w3-propertyvalue-614691.html · ISL https://www.isl.gob.cl/protocolo-riesgos-psicosociales-ceal-sm-suseso/
- Trasplantes (doctrina chilena): https://micologia.uv.cl/index.php/rcs/article/download/211/194/426
