# AXON Workforce — Actualización para MAIN (v2.1)
**Fecha:** 2026-10-14 · **Acompaña a** `AXON_Workforce_Respuestas_para_MAIN_v2_2026-10-14.md` y sustituye las secciones que se indican. Recoge la revisión posterior a la v2 y los criterios del propietario. No repite lo que no cambia.

**Leyenda:** ✅ verificado por Workforce · ⚠️ propuesta o por confirmar · ❓ recibido del análisis, no verificado por Workforce

## Qué sustituye de la v2
| Sección de la v2 | Qué cambia |
|---|---|
| §1, fila 9 | El tope interno de horas de Core Lite pasa a decidido (§7 de este documento) |
| §2.2 | CUV: criterio de emisión para todo voluntario admitido (§1) |
| §2.3 | «Único usuario» se precisa como titular y operador; reglas para colaboradores externos (§3) |
| §3.1 y §3.2 | Propiedad por objeto del contrato MAIN–Workforce–UnitShell (§4) |
| §4 | La taxonomía sigue siendo propuesta; se separan participación y empleo (§5) |
| §5.2 y preguntas 2-4 de §9 | El propietario entregará el generador actualizado; ya no se pide el archivo (§2) |
| §6 | Se incorpora el ORD. N.º 146/13 de la DT, verificado (§6) |
| §7 | Divisor transitorio vigente del piso de honorarios (§7) |
| §9 | Las preguntas se reorganizan en decisiones, entregas, solicitudes técnicas y pendientes jurídicos (§8) |

---

## 1. Voluntariado y CUV (sustituye v2 §2.2)
Se mantiene la decisión: el CUT identifica el registro de trabajador dentro de su ámbito; el voluntariado no es relación de trabajador y no genera CUT.

**Criterio de emisión del CUV** (⚠️ propuesta de la revisión; el propietario confirma nombre y alcance):
- Se emite a **todo voluntario formalmente admitido en RADE**, incluso si ya tiene un CUT en otro ámbito. El CUV identifica su participación voluntaria en RADE; los CUT siguen identificando sus registros de trabajador.
- No se emite durante la postulación: primero se crea un expediente de candidatura con identificador temporal; el CUV se emite al completarse la admisión.
- El CUV no es un CUT con otra etiqueta, no reutiliza el CUP y no identifica cada rescate, turno ni asignación operativa.

| Persona y situación | Identificadores |
|---|---|
| Persona externa admitida como voluntaria de RADE | CUV |
| Profesional de Core Lite admitido como voluntario | CUT de su microtenant + CUV |
| Trabajador de AXON Health que también es voluntario de RADE | CUT de AXON Health + CUV |
| Personal remunerado de RADE que además participa como voluntario en otra función | CUT del ámbito del empleador + CUV, cuando se admita ese segundo vínculo |

La última fila exige cuidado: las funciones remuneradas y las voluntarias no deben confundirse en horarios, compensaciones, coberturas ni responsabilidades.

**Responsabilidades:** RADE decide la admisión operativa y conserva preparación, disponibilidad, asignación a misiones y gestión de rescates · MAIN resuelve la identidad y aplica las políticas de autorización · Master Identifier Service genera y valida el código · Workforce registra la participación como entidad separada de Worker/Employment y sus antecedentes · Document Engine gestiona acuerdos, cláusulas, versiones, aceptación, firmas y trazabilidad.

**Salud:** la aptitud médica o psicológica, cuando proceda, la evalúan profesionales competentes según función y riesgo. Workforce recibe solo el estado habilitante, sus restricciones y su vigencia, no los informes clínicos completos.

**Emisión bloqueada** hasta documentar y probar la familia (§2). La clasificación jurídica del voluntariado y de sus beneficios se valida antes de activar los flujos correspondientes.

---

## 2. Generador de identificadores y especificación (sustituye v2 §5.2 y preguntas 2-4 de §9)
El propietario entregará una versión actualizada de `MasterIdentifierService.js`, con el CUV y las correcciones, para revisión e integración. Workforce reemplazará su CUT provisional cuando la reciba.

**La versión actualizada debe cubrir:**
1. Código de tenant de exactamente 8 letras A-Z, sin relleno ni truncado.
2. Reserva transaccional y unicidad central para país + región + código, sin colisiones entre Core y Core Lite.
3. Consistencia entre generación, validación, decodificación y revocación de CUT, incluida la familia histórica de AXON Health, sin invalidar identificadores ya emitidos.
4. El tipo semántico (`identifier_type`) decide la representación externa; no todo CUT es un «Employee Identifier».
5. Secuencias, idempotencia y concurrencia con respaldo transaccional de backend.
6. Pruebas automatizadas de generación, validación, decodificación, revocación y unicidad para todas las familias, con los vectores del Anexo de la v2.
7. **Familia CUV** como familia propia, con formato, ámbito de unicidad, secuencia, verificador, validación, decodificación y revocación documentados y probados antes de emitir. ⚠️ Se propone el mismo enfoque estructural del motor y el código de tenant del ámbito de RADE, no el de Core Lite del voluntario; falta definir si RADE usa un ámbito global o regionales.

**Nomenclatura CUT / CUIT.** ✅ La v2 no los mezcla: CUIT identifica al tenant y CUT al trabajador (especificación §6, §34-36). Lo que sí es inconsistente está en la especificación: `CUT-AXON-WLD` y `CUT-AXON-CTRY` son tenants con prefijo CUT (§27 y §29; el §27 admite que hay que resolver por `identifier_type`), y los nombres de familia de la tabla del §6 (p. ej. «CUT-AXON») no coinciden literalmente con sus formatos. Se pide fijar qué prefijos se usan en nuevas emisiones y cuáles se mantienen por compatibilidad histórica, sin cambiar identificadores ya emitidos solo para uniformar ejemplos.

**Sin cambios respecto de la v2 §5.1:** corregir el ejemplo del §35 (7 letras) y definir el agotamiento de SEQ4 sin reutilizar identificadores, con la capacidad real y los valores reservados.

---

## 3. Core Lite: titular y colaboración (sustituye la primera viñeta de v2 §2.3)
- Un microtenant tiene **un profesional titular, operador de su instancia individual**; no incluye secretarias, auxiliares ni personal a cargo.
- Esa definición no impide la colaboración. Un profesional de otro tenant que participa en una junta médica, teleconsulta u otra actividad autorizada **ingresa con su propia identidad y recibe acceso limitado a esa reunión o prestación**. No es un usuario permanente ni un trabajador del microtenant receptor.
- Una colaboración, invitación, junta o derivación no crea por sí sola una relación laboral ni un CUT adicional.
- En las derivaciones nominativas se requiere trazabilidad de quién deriva, paciente y finalidad, profesional receptor, aceptación, prestación, documentación clínica y seguimiento, con los consentimientos que correspondan.
- La distinción debe quedar explícita en el contrato entre Workforce, MAIN, Telemedicine, Scheduling y el dominio clínico.
- El Maestro §75-76 debe corregirse: hoy permite leer que Core Lite tiene secretarias, asistentes o colaboradores como trabajadores internos.

---

## 4. Contrato MAIN–Workforce–UnitShell: propiedad por objeto (sustituye v2 §3.1 y §3.2)
UnitShell consume el contexto organizacional y operativo autorizado para componer el workspace; no crea la verdad laboral, organizacional, financiera ni de autorización. La asignación organizacional (p. ej. a Imagenología) no es el mismo objeto que la asignación operativa (un turno o una misión de rescate).

| Objeto | Fuente de verdad (⚠️ propuesta a validar con MAIN) | Lo consultan | Registra cambios |
|---|---|---|---|
| Person | MAIN / Identity | Workforce, RADE, UnitShell | MAIN |
| Worker (CUT) | Workforce; el Master Identifier Service emite el CUT | MAIN, UnitShell | Workforce |
| Engagement y participación voluntaria | Workforce; RADE para su proceso operativo | MAIN, UnitShell, Account Core (hechos financieros) | Workforce |
| Contract / Agreement | Workforce + Document Engine (instrumento y firmas) | MAIN, Account Core | Workforce, Document Engine |
| Position | Workforce (Maestro §18 y §34) | MAIN, UnitShell | Workforce |
| OrgNode | Fuente autorizada del árbol organizacional, a definir por MAIN | Workforce, UnitShell | Esa fuente |
| Organizational Assignment | Workforce (vincula Worker y Position con un OrgNode) | MAIN, UnitShell | Workforce |
| Operational Assignment | El dominio que administra la actividad: Workforce (turnos), RADE (misiones), Scheduling (agenda de pacientes) | UnitShell, MAIN | El dominio dueño |
| Role Assignment y autorización efectiva | MAIN (Policy Engine) | UnitShell, dominios | MAIN |

Se solicita definir para cada objeto: propiedad, cardinalidad, identificadores, vigencias y eventos. La propiedad del calendario sigue la misma regla: cada dominio es dueño de sus eventos; el calendario transversal los presenta sin apropiarse de ellos.

---

## 5. Taxonomía de relaciones (complementa v2 §4)
Las ocho familias siguen siendo **una propuesta para validar en conjunto, no un catálogo congelado**, con los seis ejes (familia, régimen jurídico, instrumento, procedencia, modalidad económica y asignación). Reglas:
- «Honorario» no es sinónimo universal de «independiente».
- «Contratista», «subcontratado» y «personal externo» no determinan por sí solos la naturaleza jurídica de la relación.
- Una persona puede tener varias relaciones concurrentes.
- Posición, rol y asignación son catálogos y objetos separados.
- El modelo general debe poder representar **vinculaciones y participaciones** humanas, pero el voluntariado, algunas estancias educativas y las afiliaciones profesionales no producen automáticamente un registro Worker/Employment. La participación voluntaria comparte infraestructura transversal (identidad, accesos, vigencias, auditoría), no el ciclo laboral por defecto.

---

## 6. Ley Karin (complementa v2 §6)
✅ **ORD. N.º 146/13 de la Dirección del Trabajo, 24-feb-2026** (verificado en dt.gob.cl). Establece que:
1. Ante una denuncia inconsistente, el empleador debe dar a la persona denunciante un plazo razonable para complementarla e iniciar la investigación con esos antecedentes; no puede prescindir de la denuncia ni omitirla.
2. Las denuncias dirigidas a personas comprendidas en el inciso 1.º del art. 4 del Código del Trabajo deben remitirse a la Dirección del Trabajo.
3. Para iniciar una investigación se requiere individualizar a la persona denunciante, sin perjuicio del deber del empleador del art. 184 del Código del Trabajo.

**Efecto en el diseño:** la etapa de recepción y clasificación incluye el estado «denuncia por complementar», con su plazo razonable, y el motor no permite archivar una denuncia por inconsistente. La rama «denuncia que involucra a quien decide» debe distinguir a las personas del art. 4, inc. 1.º, cuyas denuncias van a la DT. La individualización del denunciante es requisito de inicio, y el deber de protección del art. 184 se registra aparte.

Los relojes siguen como en la v2 §6.2: reglas versionadas con evento de inicio, responsable, tipo de día, fuente, vigencia y fecha de revisión. No se codifican plazos a partir de fuentes no oficiales cuando existen discrepancias; el abogado valida los cómputos antes de pasarlos a producción.

---

## 7. Core Lite y Ley 21.431 (sustituye v2 §1 fila 9 y ajusta v2 §7)
- **Decidido (propietario):** AXON aplica un **tope interno de 12 horas diarias de actividad** como política preventiva propia. Se modela por separado de los límites legales.
- Se mantienen cinco controles distintos: tope interno acumulado · desconexión continua de 12 horas si resulta legalmente aplicable · límite contractual de conexión continua · jornada del dependiente si correspondiera · piso mínimo de honorarios por hora de servicio efectivo (art. 152 quáter Y) cuando se aplique el régimen.
- **Piso de honorarios:** parámetro versionado por fecha. ⚠️ El divisor transitorio vigente en octubre de 2026 es **174 horas**; el valor final de **172** corresponde a abril de 2028 (coincide con la investigación previa de Workforce: 176 desde abril de 2024, 174 desde abril de 2026, 172 desde abril de 2028). Validar con el abogado.
- Sigue **pendiente el dictamen jurídico** sobre la aplicabilidad de la Ley 21.431 al marketplace y a la relación entre AXON, los profesionales independientes y los pacientes. No se convierte en regla definitiva del producto antes de ese dictamen.

---

## 8. Solicitudes y entregas (sustituye v2 §9)
**A. Decisiones del propietario que se comunican (no son consultas)**
- CUT por registro de trabajador y ámbito; código de tenant de 8 letras A-Z elegidas por el usuario.
- Core Lite con un único profesional titular, sin personal a cargo.
- Voluntariado sin CUT, con CUV propuesto y emisión bloqueada hasta cerrar su especificación.
- Tope interno de 12 horas diarias en Core Lite.
- «AXON HOLDING FAMILY'S» es una denominación que usó el propietario; falta confirmar si es nombre comercial o razón social. No requiere resolución de MAIN.

**B. Entregas del propietario**
1. Especificación de identificadores actualizada, con CUV como familia propia y las correcciones de validación y pruebas (junto con `MasterIdentifierService.js` actualizado).
2. Los dos documentos originales de UnitShell, para Workforce y MAIN.
3. La v2 y esta v2.1.

**C. Solicitudes técnicas a MAIN**
1. Enmendar el Maestro: CUT por registro de trabajador y ámbito (§11.2); Core Lite sin personal interno (§75-76).
2. Revisar y aprobar la familia CUV y su integración con el Master Identifier Service.
3. Entregar el contrato de datos e interfaces de Position, OrgNode, Organizational Assignment, Operational Assignment y Role Assignment (P0), con propiedad por objeto.
4. Publicar reglas de compatibilidad entre los catálogos de relaciones, posiciones y roles.
5. Definir la propiedad de los eventos de calendario entre Workforce, Scheduling, gobernanza y capacitación.
6. Establecer la estrategia de pruebas: compatibilidad histórica, concurrencia, idempotencia y aislamiento entre tenants.
7. Resolver las observaciones de la especificación: ejemplo del §35, agotamiento de SEQ4 y nomenclatura de prefijos.

**D. Pendientes jurídicos (no bloquean las decisiones de arquitectura)**
Aplicabilidad de la Ley 21.431 · cómputo exacto de los relojes de la Ley Karin · clasificación jurídica del voluntariado y de sus beneficios · base legal de trasplantes.

**Orden de entrega recomendado:** (1) especificación de identificadores con CUV; (2) documentos originales de UnitShell; (3) v2 junto con esta v2.1. El contrato MAIN–Workforce–UnitShell y los relojes jurídicos permanecen como pendientes explícitos sin detener lo ya definido.

## Fuentes
- Dirección del Trabajo, ORD. N.º 146/13 (24-feb-2026): https://dt.gob.cl/legislacion/1624/w3-article-129021.html
- Fuentes de la Ley 21.431 y de la Ley Karin: ver la v2.
