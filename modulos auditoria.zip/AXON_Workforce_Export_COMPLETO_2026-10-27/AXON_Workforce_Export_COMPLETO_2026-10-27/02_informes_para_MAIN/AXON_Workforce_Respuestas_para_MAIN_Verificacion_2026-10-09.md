# AXON Workforce — Verificación de respuestas para el equipo MAIN
**Fecha:** 2026-10-09 · **Insumos:** `AXON_MAIN_Workforce_Estado_Consolidado.md` (revisión de MAIN) y `para WORKFORCE - UnitShell.docx` (análisis y respuestas del equipo GPT de Workforce, incluida la consulta del propietario sobre voluntarios/RADE, Ley Karin y Core Lite).

**Leyenda:** ✅ verificado · ⚠️ verificado con matiz o por confirmar · ❓ no verificable con lo que hay en el proyecto

**Cómo se verificó.** Lectura de los dos archivos y cruce contra el Documento Maestro de Workforce, la Especificación de Identificadores Universales v1.0, la tabla de Líneas de AXON (versión del 09-sep-2026), el análisis del Modelo de 120 Familias y el Dossier de Workforce. Lo legal se contrastó con el texto de la Ley 21.431 (Diario Oficial, 11-mar-2022) y con fuentes de la DT, SUSESO, ISL, ChileAtiende y guías de mutualidades.
**Límites:** (1) los documentos "Respuesta a MAIN UnitShell" y "Continuación…" no están en el proyecto: lo que dicen no se pudo contrastar; (2) el sitio de la DT bloquea la lectura automática, se usaron resúmenes y otras fuentes; (3) el .docx del Documento Maestro no se pudo abrir desde disco, se usó el texto entregado en la conversación; (4) esto es verificación documental, no asesoría legal.

---

# PARTE A — Para transmitir a MAIN

## A1. Las tres consultas de MAIN

### A1.1 CUT y relaciones múltiples
**Respuesta de Workforce:** un CUT por *Worker* dentro de cada tenant. Si la misma persona tiene dos relaciones en el mismo tenant (p. ej. empleado y voluntario), se modelan como dos *Engagement* asociados al mismo CUT, cada uno con su propio ID técnico, vigencia y reglas. Persona (identidad), Worker (CUT), Engagement, Contract/acuerdo, Position y Assignment son entidades distintas.

- ✅ Coincide con la Especificación de Identificadores v1.0: el CUT representa la relación del trabajador con el ecosistema y no la identidad física (§32); el trabajador puede estar bajo una relación contractual o de prestación de servicios y el estado contractual se guarda aparte del texto del ID (§36); cambiar de rol no cambia el CUT (§114); cambiar de tenant puede emitir un CUT nuevo (§117).
- ⚠️ El Documento Maestro de Workforce §11.2 llama al CUT "identificador interno de la relación de workforce", que puede leerse como un CUT por relación. Proponemos enmendarlo a "identificador del worker en el tenant" para que ambos documentos digan lo mismo.
- ✅ El ajuste menor que señaló MAIN (etiqueta fija "Employee Identifier" en FHIR) es correcto: la especificación trata los identificadores como *business identifiers* cuyo tipo sale de `identifier_type` (§52, §55-56), y un honorario, contratista o voluntario no es "empleado".

### A1.2 Voluntarios y RADE
**Respuesta de Workforce:** incorporar el voluntariado al modelo común de relaciones como un tipo propio (VOLUNTEER), no como variante de Employment: sin nómina, liquidación ni finiquito; con identidad, vigencia, competencias, asignaciones, coberturas e historial auditable. RADE es dueño del proceso operativo (preselección, aptitud, admisión, disponibilidad para misiones); MAIN aplica identidad y políticas; el servicio de identificadores emite el código; Workforce registra la relación; Document Engine gestiona acuerdos, firmas y trazabilidad. De la evaluación médica o psicológica, Workforce solo recibe el resultado (apto / no apto / con restricciones) y su vigencia, no el informe clínico.

- ✅ La tabla de Líneas (actualizada el 09-sep) ya dice que RADE maneja voluntariado, que ese tema vive en Workforce y que se acepta "bajo condiciones de aceptación y requisitos".
- ⚠️ La tabla distingue dos orígenes de voluntarios: trabajadores de Health/Core/Core Lite que se ofrecen, y voluntarios externos. Además está el personal propio de RADE (central regional, pagos vía Workforce + Account Core). El código nuevo resuelve a los externos; falta decidir si los trabajadores internos reciben también código de voluntariado o solo una participación bajo su CUT.
- ❓ La compensación (viáticos, seguro) no está definida en ningún documento.
- **Identificador (propuesta, pendiente de aprobación nomenclatural del propietario): Código Único de Voluntariado (CUV).**
  - ✅ Es más coherente con la especificación que reutilizar o ampliar el CUP: §2-3 prohíben usar un mismo identificador para persona, trabajador y paciente, y el CUP es del paciente.
  - ⚠️ El catálogo es cerrado (15 tipos): crear una familia exige pasar el checklist del §120 y el proceso de cambio del §121 (cambio de arquitectura, versionado, plan de migración, revisión de seguridad, clínica y legal).

### A1.3 Nombre "AXON HOLDING FAMILY'S"
- ✅ En el texto del Documento Maestro de Workforce aparece una sola vez, en §1. MAIN lo ubica en "portada y §63": no coincide, §63 trata de Dominium y no menciona holding.
- ✅ No aparece en ningún otro documento del proyecto.
- ✅ El propio Documento Maestro (§84) dice que "AXON" debe reservarse para plataformas y nombres comerciales definidos oficialmente por el propietario.
- **Recomendación:** mantenerlo como denominación pendiente de confirmación formal (distinguir nombre comercial, razón social, plataforma y productos) y no propagarlo. La decisión es del propietario. ❓ El "contexto previo" en que, según GPT, el propietario lo usó no está en el proyecto.

### A1.4 Lo que MAIN dio por confirmado — contraste con el Documento Maestro
| Afirmación de MAIN | Dónde está en el Maestro | Estado |
|---|---|---|
| Revisión de 84 secciones | §1-84 | ✅ |
| Workforce calcula, Account Core registra el impacto financiero | §28-29, §56-58 | ✅ |
| FHIR complementa, no reemplaza el modelo propio | §14, §60 | ✅ |
| Autoridad de plataforma ≠ acceso indiscriminado a datos | §63 (y §64-65 para Country/World) | ✅ |
| NID Bridge no es producto de interoperabilidad de RRHH | §66 | ✅ |
| Calendario institucional integra turnos, vacaciones y capacitaciones | §51 | ✅ |
| Reglas jurisdiccionales como datos versionados | §19-22, §69 | ✅ |
| Falta "Voluntario" en el catálogo de relaciones | §8 no lo incluye | ✅ |

## A2. Verificación legal

### Core Lite y Ley 21.431 (consulta del propietario: tope de 12 horas diarias)
- ✅ La ley regula la desconexión como **12 horas continuas de desconexión dentro de un período de 24 horas** para el trabajador independiente (art. 152 quáter Z). Un tope de "12 horas de trabajo al día, no necesariamente continuas" no es equivalente: 6 h por la mañana y 6 h por la noche suman 12 h pero dejan bloques de desconexión de solo 6 h, lo que incumple la ley. Son dos controles: un tope acumulado (política interna) y el bloque continuo de desconexión (obligación legal).
- ✅ El contrato con el independiente debe fijar además los **tiempos máximos de conexión continua** y la obligación de desconexión (art. 152 quáter X, letra f). Ese máximo es un parámetro contractual: la ley no da el número.
- ✅ La DT, en un dictamen de febrero de 2026, mantiene el límite diario de 10 horas para el dependiente de plataforma que distribuye libremente su jornada, y las 12 horas continuas de desconexión para el independiente.
- ⚠️ Implementación recomendada (interpretación técnica, no texto legal): ventana móvil de 24 h, no día calendario, y validación en el backend, no solo en la interfaz.
- ⚠️ **Alcance.** La tabla de Líneas dice que Core Lite está "excluido de la Ley 21.431". La definición (art. 152 quáter Q) solo excluye a las plataformas que se limitan a publicar avisos de servicios y deja la lista de servicios abierta ("u otros"). No hay exclusión expresa para profesionales de salud, y una plataforma que coordina agenda, telemedicina y cobro difícilmente calza en la exclusión de avisos. Hace falta dictamen de un abogado laboral antes de dar la exclusión por cierta.
- ⚠️ Si la ley aplica, el art. 152 quáter Y fija un piso de honorarios por hora de servicio efectivo (ingreso mínimo proporcional más 20 %), lo que choca con "el profesional define sus precios" (Maestro §4).
- Nota: en el mensaje del propietario la ley figura como "21341"; la ley es la 21.431.

### Ley Karin (Ley 21.643)
- ✅ Plazos del empleador: investigar internamente o enviar los antecedentes a la DT **dentro de 3 días**; la investigación debe concluir **en 30 días**; ambas partes deben ser oídas; el procedimiento es escrito y con estricta reserva. Si la denuncia entra por la DT, esta instruye medidas de resguardo en 2 días hábiles.
- ⚠️ El texto distingue "2 días hábiles" de "3 días" sin calificar los segundos: antes de fijarlos en el motor de reglas hay que confirmar si son corridos u hábiles. El motor necesita guardar el tipo de cómputo por regla.
- ⚠️ Tras el informe, una guía de IST indica 15 días para que el empleador aplique medidas o sanciones; confirmar contra el texto legal.
- ✅ (GPT) La mediación no es una etapa previa obligatoria del empleador. Existe mediación dentro del procedimiento de la DT y se excluye en acoso sexual. La "conciliación" que describió el propietario puede existir como mecanismo opcional, pero no reemplaza ni retrasa la investigación.
- ✅ (GPT) La atención psicológica temprana figura entre las medidas de resguardo y no equivale a una pericia psicológica dentro de la investigación.
- ✅ (GPT) CEAL-SM: obligatorio para centros de trabajo con 10 o más trabajadores, pero proviene del Protocolo de Vigilancia de Riesgos Psicosociales del MINSAL (versión 2022, vigente desde 2023), no es una exigencia propia de la Ley Karin. MAIN lo presentó como parte del detalle de la Ley Karin; conviene corregirlo.

### Trasplantes (Ley 19.451)
- ⚠️ No verificado. La doctrina chilena menciona un principio de confidencialidad de los datos del donante y del receptor, pero no pude confirmar el texto exacto que cita GPT (prohibición de divulgar información que relacione extracción con trasplante). Las coincidencias textuales que aparecieron son de normas de Perú, Costa Rica y España. Revisar en la BCN antes de citar artículo.
- ❓ El modelo propuesto (identificador de injerto, cadena de custodia, vínculo protegido entre donante y receptor) es de arquitectura y queda para más adelante.

### Voluntariado
- ❓ No se investigó un marco legal específico. La advertencia de GPT de no usar un acuerdo de voluntariado para encubrir una relación laboral es un principio general; conviene que lo revise un abogado laboral.

## A3. Preguntas nuevas para MAIN (surgen del cruce)
1. **Colaboradores en Core Lite.** Identificadores §119 dice que el único trabajador de un tenant Core Lite es el profesional; el Maestro §75-76 prevé secretarias, asistentes y colaboradores. ¿Qué identificador reciben?
2. **Generador real de CUT.** ¿Pueden compartir `MasterIdentifierService.js` (CHK2-V1) para reemplazar el `makeCUT` provisional de Workforce? Diferencias hoy: SEQ8 vs SEQ4; checksum hexadecimal de 2 caracteres vs CHK2 (letra + dígito); el segmento AXON aparece en todos, aunque Core debería llevar el TENANT8 de su tenant y cada Core Lite el suyo.
3. **CUV.** ¿Se emite a todos los voluntarios o solo a los externos? ¿Quién aprueba la nueva familia según §120-121?
4. **Core Lite y Ley 21.431.** ¿Cuál es la postura oficial ("excluidos" en Líneas vs diseño de cumplimiento) y quién la valida legalmente?
5. **Cómputo de plazos.** ¿Corridos o hábiles? El motor de reglas necesita guardar el tipo de día por regla.
6. **UnitShell.** ¿Pueden compartir los documentos "Respuesta a MAIN UnitShell" y su continuación? No están en el proyecto.
7. **Nombre de la holding.** Decisión del propietario (ver A1.3).

---

# PARTE B — Internas de Workforce (no transmitir)

## B1. Qué respuestas encontramos para nuestros pendientes (Dossier, Parte 9)
| Pendiente | Qué aportan estos documentos |
|---|---|
| CUT formato real | MAIN confirma que el generador ya existe y que el formato es compatible. Pedir el archivo y reemplazar el provisional. Nuestro roster mock usa el segmento AXON también para los 3 empleados Core y los 10 honorarios Core Lite, que deberían llevar TENANT8. |
| Person / Employment separados | Modelo objetivo: Person → Worker (CUT por tenant) → Engagement → Contract; Position y Assignment aparte. Position, Assignment, Delegation y Acting ya están en el Maestro (§18, §34-35); lo que falta es el código. |
| Sección Organización / Posiciones / Subrogancias | Esperar el contrato de MAIN (OrgNode, Position, Role, Assignment) antes de construirla. Es el mismo bloqueo que ya tenía el dossier (modelo de 120 familias). |
| `roles.config.js` vs taxonomía de relaciones | Ambos documentos coinciden en no fusionar: tipos de relación, cargos (Position) y roles de autorización son catálogos distintos, con reglas de compatibilidad. |
| Voluntario | Nueva relación a modelar; el §8 del Maestro no la tiene. |

## B2. Huecos nuevos que no están en la Parte 10 del dossier
1. **Alta de trabajador, contratos y relaciones laborales** (Maestro §54). Hoy `WorkforcePersonas.jsx` es de solo lectura sobre datos mock.
2. **Core Lite — motor de jornada y conexión para independientes:** ventana móvil de 24 h, bloque de 12 h continuas de desconexión, tope contractual de conexión continua, validación en backend. Hoy "Turnos" solo modela dependientes. Falta también la bitácora de evidencia de autonomía (Maestro §7, §75).
3. **Gestión de casos (Ley Karin):** plazos de 2 días hábiles, 3 días, 30 días y 15 días, más reserva de acceso. Requiere tipo de cómputo (corridos/hábiles) por regla.
4. **Core Lite — colaboradores** (pregunta A3.1).
5. **Piso de honorarios por hora** en Core Lite, si la Ley 21.431 aplica.

## B3. Lo que no pudimos verificar
- Los documentos UnitShell y las afirmaciones del análisis GPT que se apoyan en ellos (p. ej. "Position como entidad maestra de primer nivel"; el Maestro §18 y §34 ya lo contemplan).
- El "contexto previo" en que se habría usado el nombre de la holding.

---

## Fuentes consultadas
- Ley 21.431, texto publicado en el Diario Oficial (11-mar-2022): https://www.diariooficial.interior.gob.cl/publicaciones/2022/03/11/43200/01/2099107.pdf
- Art. 152 quáter Z: https://www.derechopedia.cl/Artículo_152_quáter_Z_del_Código_del_Trabajo
- DT, dictamen de febrero de 2026 sobre plataformas: https://dt.gob.cl/legislacion/1624/w3-article-128898.html — resumen: https://www.diarioconstitucional.cl/2026/02/27/aplicacion-de-la-ley-n21-561-jornada-laboral-y-remuneraciones-en-trabajadores-de-plataformas-digitales/
- Ley Karin: guía IST https://ist.cl/wp-content/uploads/2024/06/Guia-para-el-desarrollo-de-reglamento-de-investigacion-y-sanciones.pdf · Az Abogados https://accionempresas.cl/content/uploads/Ley-Karin-Az-Abogados.pdf · Ministerio de la Mujer https://www.cnc.cl/wp-content/uploads/2024/07/11.07.24-Ley-Karin-Ministerio-de-la-Mujer-y-Equidad-de-Genero.pdf · ChileAtiende https://chileatiende.gob.cl/fichas/140078/1/pdf · La Tercera https://www.latercera.com/servicios/noticia/ley-karin-conoce-de-que-se-trata-y-cuales-son-las-modificaciones-que-plantea/UWWFNAZ7FNEUZEFXL3DEX5WKZI/
- CEAL-SM: SUSESO https://www.suseso.gob.cl/606/w3-propertyvalue-614691.html · ISL https://www.isl.gob.cl/protocolo-riesgos-psicosociales-ceal-sm-suseso/ · El Mostrador https://www.elmostrador.cl/noticias/opinion/columnas/2022/12/22/protocolo-de-vigilancia-de-riesgos-psicosociales-incoherencias-y-contradicciones/
- Trasplantes (doctrina chilena): https://micologia.uv.cl/index.php/rcs/article/download/211/194/426
