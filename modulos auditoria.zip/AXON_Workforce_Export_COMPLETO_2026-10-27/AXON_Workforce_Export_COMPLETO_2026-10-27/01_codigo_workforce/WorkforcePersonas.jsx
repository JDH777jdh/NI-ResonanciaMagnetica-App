import React, { useState, useMemo } from 'react';
import {
  Users, Search, Download, X, Eye, RotateCcw, Building2, UserRound,
  Briefcase, ShieldCheck, Landmark, Globe2, Info, IdCard,
} from 'lucide-react';

/* =========================================================================
   AXON WORKFORCE — Personas y Registro de Trabajador (CUT)
   Módulo de Recursos Humanos / Workforce · Sección: Personas / Registro (CUT)
   Ver Documento Maestro de Arquitectura Workforce §8-11 (Persona ≠
   Trabajador ≠ Empleado; modelo de relaciones múltiples; CUT).

   QUINTA SECCIÓN — pero la primera que debió ir de base. Las 4 anteriores
   (Remuneraciones, Honorarios, Turnos y Asistencia, Licencias Médicas)
   generaban CADA UNA su propio roster mock, sin relación entre sí — dos
   archivos con "wk_1000" tenían personas distintas. Este archivo es el
   REGISTRO CANÓNICO: mismo criterio de "fuente única" que ya usa
   Contabilidad con ContabilidadHelpersCompartidos.js — se copia 1:1 a los
   otros 4 archivos (no se importa, cada uno sigue standalone-
   previsualizable), y de ahora en adelante todos comparten las mismas
   personas, mismos CUT, mismos cargos.

   TAMBIÉN cierra el hallazgo pendiente del PDF de Monetización (Líneas de
   AXON): "esa gran diferencia" de trabajadores propios/de tenant/
   independientes que faltaba modelar. §9 del docx es explícito — una
   persona puede tener relaciones simultáneas; acá cada relación declara
   de qué LÍNEA AXON es (axonLinea) y, si es AXON Core, de qué tenant
   específico (tenantId) — porque el empleador real ahí es la institución,
   no AXON (confirmado en el archivo de Monetización: "NO son staff de
   AXON, solo usan nuestra tecnología").
   ========================================================================= */

/* DISEÑO — misma identidad violeta de Workforce, sin cambios. */
const C = {
  bg: '#F6F5FB', card: '#FFFFFF', border: '#E3DEF5', borderD: '#CBC0E8',
  ink: '#241A3D', sub: '#5F5580', mut: '#948AB5',
  pri: '#6D28D9', priD: '#5518B0', priL: '#F1EAFC',
  info: '#2563EB', infoL: '#EEF3FF',
  warn: '#B45309', warnL: '#FEF3E2',
  err: '#C62828', errL: '#FDECEC',
  gold: '#B7791F', goldL: '#FBF0DD',
  teal: '#0E7490', tealL: '#E3F6FA',
  r: 10, rSm: 7, rLg: 14,
  shadow: '0 1px 3px rgba(16,24,40,.06), 0 1px 2px rgba(16,24,40,.04)',
  font: "'Inter', -apple-system, 'Segoe UI', Roboto, sans-serif",
};

/* ---------------------------- catálogos base ------------------------------ */
// §8 docx: Empleado ≠ Independiente ≠ Honorario ≠ Contratista ≠ Externo.
// Acá modelamos los dos que ya tienen sección construida — el resto queda
// como categoría reconocida por el modelo, sin UI propia todavía.
const TIPOS_RELACION = {
  empleado: { label: 'Empleado', color: '#2563EB' },
  honorario: { label: 'Honorario', color: '#0E7490' },
};

// A qué LÍNEA AXON pertenece la relación — el hallazgo del PDF de
// Monetización. axon_health: trabajador propio de AXON. axon_core:
// trabajador del TENANT (institución cliente), no de AXON — Workforce es
// la tecnología, el empleador legal es la institución. axon_core_lite:
// profesional independiente, no depende de ninguna institución.
const LINEAS_AXON = {
  axon_health: { label: 'AXON Health (propio)', color: '#2E7D32', icon: ShieldCheck },
  axon_core: { label: 'AXON Core (tenant)', color: '#B45309', icon: Building2 },
  axon_core_lite: { label: 'AXON Core Lite (independiente)', color: '#6D28D9', icon: Globe2 },
};

const CARGOS = {
  medico: { label: 'Médico/a', icon: Briefcase, color: '#4338CA' },
  enfermeria: { label: 'Enfermera/o', icon: ShieldCheck, color: '#0E7490' },
  tens: { label: 'TENS', icon: Users, color: '#2E7D32' },
  kinesiologo: { label: 'Kinesiólogo/a', icon: Briefcase, color: '#B45309' },
  matrona: { label: 'Matrona/Matrón', icon: ShieldCheck, color: '#BE185D' },
  administrativo: { label: 'Administrativo/a', icon: Building2, color: '#5B6B85' },
  auxiliar: { label: 'Auxiliar de Servicio', icon: UserRound, color: '#94A3B8' },
};
const ESPECIALIDADES_HONORARIO = {
  medico_especialista: { label: 'Médico Especialista', color: '#4338CA' },
  psicologia: { label: 'Psicólogo/a', color: '#BE185D' },
  kinesiologia: { label: 'Kinesiólogo/a', color: '#B45309' },
  nutricion: { label: 'Nutricionista', color: '#2E7D32' },
  auditoria_clinica: { label: 'Auditoría Clínica Externa', color: '#5B6B85' },
};

/* ---------------------------- identificadores ----------------------------- */
// CUT — mismo formato PROVISIONAL que los otros 4 archivos. Este es AHORA
// el único lugar donde se genera — los otros 4 lo copian de acá.
const PAIS = 'CL', REGION = '13', CLINICA = 'AXON';
function hashLiviano(str) {
  let h = 0;
  for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) >>> 0;
  return h.toString(16).toUpperCase().padStart(2, '0').slice(-2);
}
function makeCUT(seq) {
  const s = String(seq).padStart(8, '0');
  return `CUT-${PAIS}-${REGION}-${CLINICA}-${s}-${hashLiviano(`CUT-${PAIS}-${REGION}-${CLINICA}-${s}`)}`;
}
function calcDV(rutBody) {
  let suma = 0, mult = 2;
  for (let i = rutBody.length - 1; i >= 0; i--) {
    suma += parseInt(rutBody[i], 10) * mult;
    mult = mult === 7 ? 2 : mult + 1;
  }
  const resto = 11 - (suma % 11);
  if (resto === 11) return '0';
  if (resto === 10) return 'K';
  return String(resto);
}
function fakeRUT(seed) {
  const body = String(9000000 + (seed * 7919) % 8900000);
  const dv = calcDV(body);
  return body.slice(0, 2) + '.' + body.slice(2, 5) + '.' + body.slice(5) + '-' + dv;
}

/* ═══════════════════════════════════════════════════════════════════════
   REGISTRO CANÓNICO — generarPersonasCanonico()
   ÚNICA fuente del roster mock de todo Workforce. Se copia 1:1 (mismo
   código, no import) a Remuneraciones/Honorarios/Turnos/Licencias — cada
   uno filtra por tipoRelacion y agrega SUS campos propios encima (ej.
   Remuneraciones agrega sueldoBase; Turnos agrega turnoId). Cambiar esto
   acá y no propagarlo a los otros 4 es exactamente el problema que esta
   sección viene a resolver — documentado a propósito, no automático.
   ═══════════════════════════════════════════════════════════════════════ */
const NOMBRES_CANONICO = ['María José', 'Pedro', 'Camila', 'Rodrigo', 'Fernanda', 'Ignacio', 'Valentina', 'Cristóbal', 'Antonia', 'Matías', 'Javiera', 'Sebastián', 'Catalina', 'Diego', 'Francisca', 'Tomás', 'Constanza', 'Felipe', 'Josefa', 'Nicolás'];
const APELLIDOS_CANONICO = ['González', 'Muñoz', 'Rojas', 'Díaz', 'Pérez', 'Soto', 'Contreras', 'Silva', 'Martínez', 'Sepúlveda', 'Morales', 'Rodríguez', 'López', 'Fuentes', 'Hernández', 'Torres'];
// CORREGIDO — antes CARGOS_LISTA/ESPECIALIDADES_LISTA se derivaban con
// Object.keys(CARGOS)/Object.keys(ESPECIALIDADES_HONORARIO). Funcionaba
// porque el orden coincidía por casualidad con el array fijo que copian
// los otros 4 archivos, pero era frágil: reordenar CARGOS acá (por
// legibilidad, por ejemplo) habría desincronizado el roster sin ningún
// error. Ahora es un array fijo, igual que en los otros 5 — encontrado al
// auditar consistencia entre archivos, no al construir originalmente.
const CARGOS_LISTA_CANONICO = ['medico', 'enfermeria', 'tens', 'kinesiologo', 'matrona', 'administrativo', 'auxiliar'];
const ESPECIALIDADES_LISTA_CANONICO = ['medico_especialista', 'psicologia', 'kinesiologia', 'nutricion', 'auditoria_clinica'];
const EMPRESAS_HONORARIO_CANONICO = ['Auditoría Clínica del Sur SpA', 'Diagnóstico Externo Ltda.'];

// Antigüedad — rango amplio a propósito (60 días a ~13,7 años) para poder
// probar en el mismo roster: menos de 1 año (feriado proporcional), justo
// 1 año (recién con derecho a feriado legal), y 10+ años (feriado
// progresivo, Art. 68 CT). Determinístico desde el seed, no aleatorio real.
function fechaIngresoDesdeSeed(seed) {
  const diasAtras = 60 + (seed % 5000);
  const hoy = new Date();
  const fecha = new Date(hoy);
  fecha.setDate(fecha.getDate() - diasAtras);
  return fecha.toISOString().slice(0, 10);
}

export function generarPersonasCanonico() {
  const personas = [];
  let seed = 100;
  // 20 personas — relación EMPLEADO. Últimas 3 son de un tenant AXON Core
  // (Workforce como tecnología, empleador real es el tenant, no AXON).
  //
  // Separación conceptual PERSONA vs RELACIÓN (§8-9 Documento Maestro,
  // reforzado por la auditoría de esta sesión): los campos id/cut/rut/
  // nombres son de la PERSONA (identidad, no cambia). tipoRelacion/
  // axonLinea/tenantId/cargoId/sector/fechaIngreso son de la RELACIÓN
  // (pueden cambiar si la persona cambia de tenant, cargo, etc.). Se
  // mantienen en un solo objeto plano a propósito — el roster mock no
  // necesita versionado temporal completo todavía (eso sí sería trabajo
  // real de backend, no de este archivo) — pero quedan agrupados así en
  // el comentario para que la distinción no se pierda al leer el código.
  //
  // `sector` (nuevo esta sesión): privado | publico — AXON Core puede ser
  // institución pública (Ley 19.664/Estatuto Administrativo tiene sus
  // propias reglas de jornada/indemnización, DISTINTAS del Código del
  // Trabajo que usan Remuneraciones/Vacaciones/Finiquito hoy). El campo
  // existe para poder ramificar más adelante — el motor de reglas del
  // sector público NO está construido, esto es la puerta etiquetada, no
  // la implementación. AXON Health es siempre privada (confirmado en el
  // archivo de Monetización); el tenant AXON Core demo se marca público
  // para tener al menos un caso de prueba real en el roster.
  for (let i = 0; i < 20; i++) {
    seed += 17;
    const esCore = i >= 17;
    personas.push({
      // --- Persona ---
      id: `per_${1000 + i}`, cut: makeCUT(1000 + i), rut: fakeRUT(seed),
      nombres: NOMBRES_CANONICO[seed % NOMBRES_CANONICO.length],
      apellidoPaterno: APELLIDOS_CANONICO[(seed * 2) % APELLIDOS_CANONICO.length],
      apellidoMaterno: APELLIDOS_CANONICO[(seed * 5) % APELLIDOS_CANONICO.length],
      // --- Relación (Employment) ---
      tipoRelacion: 'empleado',
      axonLinea: esCore ? 'axon_core' : 'axon_health',
      tenantId: esCore ? 'tenant_hospital_regional_demo' : null,
      sector: esCore ? 'publico' : 'privado',
      cargoId: CARGOS_LISTA_CANONICO[seed % CARGOS_LISTA_CANONICO.length],
      fechaIngreso: fechaIngresoDesdeSeed(seed),
    });
  }
  // 10 personas — relación HONORARIO. Últimas 2 son empresa (doble vía ya
  // establecida por Contabilidad), el resto persona natural. Todos
  // AXON Core Lite — independientes, sin institución de por medio.
  for (let i = 0; i < 10; i++) {
    seed += 23;
    const esEmpresa = i >= 8;
    personas.push({
      id: `per_${2000 + i}`, cut: makeCUT(2000 + i), rut: fakeRUT(seed),
      nombres: esEmpresa ? null : NOMBRES_CANONICO[seed % NOMBRES_CANONICO.length],
      apellidoPaterno: esEmpresa ? null : APELLIDOS_CANONICO[(seed * 2) % APELLIDOS_CANONICO.length],
      apellidoMaterno: esEmpresa ? null : APELLIDOS_CANONICO[(seed * 5) % APELLIDOS_CANONICO.length],
      razonSocial: esEmpresa ? EMPRESAS_HONORARIO_CANONICO[i - 8] : null,
      tipoRelacion: 'honorario',
      tipoPersonaHonorario: esEmpresa ? 'empresa' : 'natural',
      axonLinea: 'axon_core_lite', tenantId: null,
      especialidadId: esEmpresa ? 'auditoria_clinica' : ESPECIALIDADES_LISTA_CANONICO[seed % (ESPECIALIDADES_LISTA_CANONICO.length - 1)],
    });
  }
  return personas;
}

export function nombreCompletoPersona(p) {
  return p.razonSocial || `${p.nombres} ${p.apellidoPaterno} ${p.apellidoMaterno}`;
}

export function calcularKPIsPersonas(personas) {
  const empleados = personas.filter((p) => p.tipoRelacion === 'empleado').length;
  const honorarios = personas.filter((p) => p.tipoRelacion === 'honorario').length;
  const porLinea = Object.keys(LINEAS_AXON).map((k) => ({ linea: k, cantidad: personas.filter((p) => p.axonLinea === k).length }));
  const tenantsDistintos = new Set(personas.filter((p) => p.tenantId).map((p) => p.tenantId)).size;
  return { total: personas.length, empleados, honorarios, porLinea, tenantsDistintos };
}

/* ------------------------------- átomos ---------------------------------- */
const Badge = ({ color, bg, icon: Icon, children }) => (
  <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, padding: '3px 9px', borderRadius: 999, fontSize: 12, fontWeight: 600, color, background: bg, whiteSpace: 'nowrap' }}>
    {Icon && <Icon size={12} />}{children}
  </span>
);
const Btn = ({ variant = 'ghost', icon: Icon, children, onClick, style }) => {
  const base = { display: 'inline-flex', alignItems: 'center', gap: 7, padding: '9px 15px', borderRadius: C.rSm, fontSize: 13.5, fontWeight: 600, cursor: 'pointer', border: '1px solid transparent', fontFamily: C.font, transition: 'filter .12s ease' };
  const variants = {
    primary: { background: C.pri, color: '#fff' },
    outline: { background: '#fff', color: C.ink, border: `1px solid ${C.border}` },
    ghost: { background: 'transparent', color: C.sub },
  };
  return (
    <button type="button" onClick={onClick}
      onMouseEnter={(e) => (e.currentTarget.style.filter = 'brightness(0.96)')}
      onMouseLeave={(e) => (e.currentTarget.style.filter = 'none')}
      style={{ ...base, ...variants[variant], ...style }}>
      {Icon && <Icon size={15} />}{children}
    </button>
  );
};
const KPICard = ({ label, value, sub, icon: Icon, accent }) => (
  <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, padding: '16px 18px', boxShadow: C.shadow, flex: 1, minWidth: 0 }}>
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
      <span style={{ fontSize: 12.5, color: C.sub, fontWeight: 600 }}>{label}</span>
      <div style={{ width: 28, height: 28, borderRadius: 8, background: accent + '18', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <Icon size={14} style={{ color: accent }} />
      </div>
    </div>
    <div style={{ fontSize: 22, fontWeight: 700, color: C.ink, letterSpacing: -0.3 }}>{value}</div>
    {sub && <div style={{ fontSize: 12, color: C.mut, marginTop: 3 }}>{sub}</div>}
  </div>
);
const FieldLabel = ({ children }) => <label style={{ fontSize: 11.5, fontWeight: 600, color: C.sub, marginBottom: 5, display: 'block' }}>{children}</label>;
const inputStyle = { width: '100%', padding: '8px 10px', borderRadius: C.rSm, border: `1px solid ${C.border}`, fontSize: 13.5, fontFamily: C.font, color: C.ink, outline: 'none', boxSizing: 'border-box', background: '#fff' };

/* ------------------------------- detalle ---------------------------------- */
function DetailModal({ persona, onClose }) {
  if (!persona) return null;
  const tipo = TIPOS_RELACION[persona.tipoRelacion];
  const linea = LINEAS_AXON[persona.axonLinea];
  const cargo = persona.cargoId ? CARGOS[persona.cargoId] : null;
  const especialidad = persona.especialidadId ? ESPECIALIDADES_HONORARIO[persona.especialidadId] : null;

  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(16,24,40,.45)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100, padding: 20 }} onClick={onClose}>
      <div style={{ background: '#fff', borderRadius: C.rLg, width: 480, maxWidth: '100%', maxHeight: '90vh', overflowY: 'auto', boxShadow: '0 20px 50px rgba(16,24,40,.25)' }} onClick={(e) => e.stopPropagation()}>
        <div style={{ padding: '18px 22px', borderBottom: `1px solid ${C.border}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
            <div style={{ width: 34, height: 34, borderRadius: 9, background: (cargo?.color || linea.color) + '18', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              {cargo ? <cargo.icon size={16} style={{ color: cargo.color }} /> : <linea.icon size={16} style={{ color: linea.color }} />}
            </div>
            <div>
              <div style={{ fontSize: 15, fontWeight: 700, color: C.ink }}>{nombreCompletoPersona(persona)}</div>
              <div style={{ fontSize: 12, color: C.mut }}>{cargo?.label || especialidad?.label}</div>
            </div>
          </div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: C.mut, padding: 4 }}><X size={18} /></button>
        </div>
        <div style={{ padding: 22, display: 'flex', flexDirection: 'column', gap: 14 }}>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            <Badge color={tipo.color} bg={tipo.color + '18'}>{tipo.label}</Badge>
            <Badge color={linea.color} bg={linea.color + '18'} icon={linea.icon}>{linea.label}</Badge>
          </div>
          <div>
            <FieldLabel>CUT</FieldLabel>
            <div style={{ fontSize: 12, color: C.ink, fontFamily: 'monospace', background: C.bg, padding: '6px 10px', borderRadius: 6 }}>{persona.cut}</div>
          </div>
          <div>
            <FieldLabel>{persona.razonSocial ? 'RUT Empresa' : 'RUT'}</FieldLabel>
            <div style={{ fontSize: 13, color: C.ink }}>{persona.rut}</div>
          </div>
          {persona.tenantId && (
            <div style={{ display: 'flex', gap: 8, alignItems: 'flex-start', background: C.warnL, padding: '10px 12px', borderRadius: C.rSm, fontSize: 11.5, color: C.warn }}>
              <Info size={13} style={{ flexShrink: 0, marginTop: 1 }} />
              <span>Trabajador del tenant <strong>{persona.tenantId}</strong> — no es staff de AXON. Workforce es la tecnología que usa; el empleador legal es la institución.</span>
            </div>
          )}
          <div style={{ fontSize: 10.5, color: C.mut, display: 'flex', gap: 5, paddingTop: 8, borderTop: `1px solid ${C.border}` }}>
            <IdCard size={11} style={{ flexShrink: 0, marginTop: 1 }} />
            <span>Este ID/CUT es el mismo en Remuneraciones, Honorarios, Turnos y Asistencia, y Licencias Médicas — registro canónico compartido.</span>
          </div>
        </div>
      </div>
    </div>
  );
}

/* --------------------------------- vista principal ------------------------------------ */
export default function WorkforcePersonas() {
  const [data] = useState(generarPersonasCanonico);
  const [filtros, setFiltros] = useState({ tipoRelacion: 'todos', axonLinea: 'todas', q: '' });
  const [selected, setSelected] = useState(null);
  const [page, setPage] = useState(1);
  const perPage = 10;

  const filtered = useMemo(() => data.filter((p) => {
    if (filtros.tipoRelacion !== 'todos' && p.tipoRelacion !== filtros.tipoRelacion) return false;
    if (filtros.axonLinea !== 'todas' && p.axonLinea !== filtros.axonLinea) return false;
    if (filtros.q) {
      const q = filtros.q.toLowerCase();
      if (!nombreCompletoPersona(p).toLowerCase().includes(q) && !p.rut.includes(q) && !p.cut.toLowerCase().includes(q)) return false;
    }
    return true;
  }), [data, filtros]);

  const kpi = useMemo(() => calcularKPIsPersonas(filtered), [filtered]);
  const totalPages = Math.max(1, Math.ceil(filtered.length / perPage));
  const pageRows = filtered.slice((page - 1) * perPage, page * perPage);
  const limpiarFiltros = () => { setFiltros({ tipoRelacion: 'todos', axonLinea: 'todas', q: '' }); setPage(1); };

  const exportarCSV = () => {
    const header = ['CUT', 'RUT', 'Nombre', 'Tipo Relación', 'Línea AXON', 'Tenant', 'Cargo/Especialidad'];
    const lines = filtered.map((p) => [p.cut, p.rut, nombreCompletoPersona(p), TIPOS_RELACION[p.tipoRelacion].label, LINEAS_AXON[p.axonLinea].label, p.tenantId || '', (p.cargoId && CARGOS[p.cargoId]?.label) || (p.especialidadId && ESPECIALIDADES_HONORARIO[p.especialidadId]?.label) || ''].join(';'));
    const blob = new Blob([header.join(';') + '\n' + lines.join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'personas_registro.csv'; a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div style={{ fontFamily: C.font, background: C.bg, minHeight: '100%', padding: 22 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 18, flexWrap: 'wrap', gap: 12 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
          <div style={{ width: 34, height: 34, borderRadius: 9, background: C.priL, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <IdCard size={17} style={{ color: C.pri }} />
          </div>
          <div>
            <div style={{ fontSize: 18, fontWeight: 700, color: C.ink }}>Personas y Registro (CUT)</div>
            <div style={{ fontSize: 12.5, color: C.mut }}>Workforce · Registro canónico — Documento Maestro §8-11</div>
          </div>
        </div>
        <Btn variant="outline" icon={Download} onClick={exportarCSV}>Exportar CSV</Btn>
      </div>

      <div style={{ display: 'flex', gap: 14, marginBottom: 18, flexWrap: 'wrap' }}>
        <KPICard label="Total personas" value={kpi.total} sub={`${kpi.empleados} empleados · ${kpi.honorarios} honorarios`} icon={Users} accent={C.pri} />
        <KPICard label="AXON Health" value={kpi.porLinea.find((l) => l.linea === 'axon_health')?.cantidad || 0} sub="Propios de AXON" icon={ShieldCheck} accent={C.pri} />
        <KPICard label="AXON Core" value={kpi.porLinea.find((l) => l.linea === 'axon_core')?.cantidad || 0} sub={`${kpi.tenantsDistintos} tenant(s) — no son staff AXON`} icon={Building2} accent={C.warn} />
        <KPICard label="AXON Core Lite" value={kpi.porLinea.find((l) => l.linea === 'axon_core_lite')?.cantidad || 0} sub="Independientes" icon={Globe2} accent={C.teal} />
      </div>

      <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, padding: 16, boxShadow: C.shadow, marginBottom: 14 }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10, alignItems: 'end' }}>
          <div>
            <FieldLabel>Tipo de relación</FieldLabel>
            <select style={inputStyle} value={filtros.tipoRelacion} onChange={(e) => { setFiltros({ ...filtros, tipoRelacion: e.target.value }); setPage(1); }}>
              <option value="todos">Todos</option>
              {Object.entries(TIPOS_RELACION).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
            </select>
          </div>
          <div>
            <FieldLabel>Línea AXON</FieldLabel>
            <select style={inputStyle} value={filtros.axonLinea} onChange={(e) => { setFiltros({ ...filtros, axonLinea: e.target.value }); setPage(1); }}>
              <option value="todas">Todas</option>
              {Object.entries(LINEAS_AXON).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
            </select>
          </div>
          <div>
            <FieldLabel>Buscar</FieldLabel>
            <div style={{ position: 'relative' }}>
              <Search size={14} style={{ position: 'absolute', left: 9, top: 10, color: C.mut }} />
              <input style={{ ...inputStyle, paddingLeft: 28 }} placeholder="Nombre, RUT o CUT" value={filtros.q} onChange={(e) => { setFiltros({ ...filtros, q: e.target.value }); setPage(1); }} />
            </div>
          </div>
        </div>
        <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 12 }}>
          <button onClick={limpiarFiltros} style={{ display: 'flex', alignItems: 'center', gap: 5, background: 'none', border: 'none', cursor: 'pointer', color: C.sub, fontSize: 12.5, fontWeight: 600, padding: 0 }}>
            <RotateCcw size={13} /> Limpiar filtros
          </button>
        </div>
      </div>

      <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, boxShadow: C.shadow, overflow: 'hidden' }}>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
            <thead>
              <tr style={{ background: C.bg, textAlign: 'left' }}>
                {['CUT', 'Nombre', 'Relación', 'Línea AXON', 'Cargo/Especialidad', ''].map((h) => (
                  <th key={h} style={{ padding: '10px 14px', fontSize: 11.5, fontWeight: 700, color: C.sub, textTransform: 'uppercase', letterSpacing: 0.3, whiteSpace: 'nowrap' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {pageRows.map((p) => {
                const tipo = TIPOS_RELACION[p.tipoRelacion];
                const linea = LINEAS_AXON[p.axonLinea];
                const catLabel = (p.cargoId && CARGOS[p.cargoId]?.label) || (p.especialidadId && ESPECIALIDADES_HONORARIO[p.especialidadId]?.label) || '—';
                return (
                  <tr key={p.id} style={{ borderTop: `1px solid ${C.border}`, cursor: 'pointer' }} onClick={() => setSelected(p)}
                    onMouseEnter={(e) => (e.currentTarget.style.background = C.bg)} onMouseLeave={(e) => (e.currentTarget.style.background = 'transparent')}>
                    <td style={{ padding: '11px 14px', color: C.sub, fontFamily: 'monospace', fontSize: 11.5, whiteSpace: 'nowrap' }}>{p.cut}</td>
                    <td style={{ padding: '11px 14px', color: C.ink, fontWeight: 600 }}>{nombreCompletoPersona(p)}</td>
                    <td style={{ padding: '11px 14px' }}><Badge color={tipo.color} bg={tipo.color + '18'}>{tipo.label}</Badge></td>
                    <td style={{ padding: '11px 14px' }}><Badge color={linea.color} bg={linea.color + '18'} icon={linea.icon}>{linea.label}</Badge></td>
                    <td style={{ padding: '11px 14px', color: C.sub }}>{catLabel}</td>
                    <td style={{ padding: '11px 14px' }}><Eye size={15} style={{ color: C.mut }} /></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 16px', borderTop: `1px solid ${C.border}` }}>
          <span style={{ fontSize: 12, color: C.mut }}>{filtered.length} personas · página {page} de {totalPages}</span>
          <div style={{ display: 'flex', gap: 6 }}>
            <Btn variant="outline" onClick={() => setPage(Math.max(1, page - 1))} style={{ padding: '6px 12px', opacity: page === 1 ? 0.4 : 1 }}>Anterior</Btn>
            <Btn variant="outline" onClick={() => setPage(Math.min(totalPages, page + 1))} style={{ padding: '6px 12px', opacity: page === totalPages ? 0.4 : 1 }}>Siguiente</Btn>
          </div>
        </div>
      </div>

      {selected && <DetailModal persona={selected} onClose={() => setSelected(null)} />}
    </div>
  );
}
