import React, { useState, useMemo } from 'react';
import {
  CalendarClock, Search, Download, X, Users, Clock, Sun, Moon,
  CheckCircle2, AlertTriangle, Ban, Info, Eye, RotateCcw, Send,
  ShieldCheck, Briefcase, UserRound, Building2, Hourglass, ClipboardCheck,
} from 'lucide-react';

/* =========================================================================
   AXON WORKFORCE — Turnos y Asistencia
   Módulo de Recursos Humanos / Workforce · Sección: Turnos, Horarios y Asistencia
   Ver Documento Maestro de Arquitectura Workforce §26 (Motor de Tiempo y
   Asistencia), §27 (Horas extra).

   TERCERA SECCIÓN DE WORKFORCE — elegida sin pedirte confirmación esta vez
   (dijiste "continua sin ellos por ahora"): cierra un hueco real que dejé
   en Remuneraciones. Ahí, `horasExtraTrabajadas` es puro ruido mock
   (2 + seed%9) sin ningún motor de asistencia real detrás. Este archivo
   es esa fuente real — expone `construirInputHorasParaRemuneraciones(...)`
   con la MISMA forma que espera `calcularLiquidacion(...)` en
   WorkforceRemuneraciones.jsx.

   Standalone-previsualizable como los otros dos — no importa de
   WorkforceRemuneraciones.jsx ni viceversa todavía, mismo principio que
   ya usa Contabilidad (cada archivo se puede previsualizar solo; el
   import real ocurre al integrar a producción).
   ========================================================================= */

/* DISEÑO — misma identidad violeta de Workforce, sin cambios. */
const C = {
  bg: '#F6F5FB', card: '#FFFFFF', border: '#E3DEF5', borderD: '#CBC0E8',
  ink: '#241A3D', sub: '#5F5580', mut: '#948AB5',
  pri: '#6D28D9', priD: '#5518B0', priL: '#F1EAFC',
  info: '#2563EB', infoL: '#EEF3FF',
  warn: '#B45309', warnL: '#FEF3E2',
  err: '#C62828', errL: '#FDECEC',
  gold: '#B7791F', goldL: '#FBF0DD',
  teal: '#0E7490', tealL: '#E3F6FA',
  r: 10, rSm: 7, rLg: 14,
  shadow: '0 1px 3px rgba(16,24,40,.06), 0 1px 2px rgba(16,24,40,.04)',
  font: "'Inter', -apple-system, 'Segoe UI', Roboto, sans-serif",
};

/* ═══════════════════════════════════════════════════════════════════════
   PARÁMETROS LEGALES — verificados por búsqueda el 2026-09-09 (misma
   sesión que Remuneraciones, complementario). Hallazgo importante: NO
   todo lo que se asume sobre turnos es mandato legal — se marca explícito
   qué SÍ es Código del Trabajo y qué es política institucional.
   ═══════════════════════════════════════════════════════════════════════ */
const JORNADA_SEMANAL_MAXIMA = 42;  // Ley 21.561, vigente desde 26-abr-2026 — mismo valor que Remuneraciones
const RECARGO_HORA_EXTRA = 0.50;    // Art. 32 CT

// HALLAZGO — recargo por turno nocturno: buscado explícito esta sesión.
// NO existe un mandato único y general en el Código del Trabajo que fije
// un % de recargo nocturno para todo trabajador privado (a diferencia de
// las horas extra, que sí tienen el 50% fijo del Art. 32). El Art. 18 CT
// define "horario nocturno" (22:00–07:00) pero en el contexto de PROHIBIR
// el trabajo nocturno a menores de 18, no para fijar un recargo general.
// Regímenes con recargo nocturno legal específico existen para sectores
// acotados (función pública vía Estatuto Administrativo, vigilantes
// privados vía DL 3.607) que no aplican directo a un hospital privado.
// En la práctica, el recargo nocturno en salud es materia de REGLAMENTO
// INTERNO o convenio colectivo — por eso acá es un parámetro
// CONFIGURABLE por tenant, no una constante legal fija. Ver TURNOS abajo.
const RECARGO_NOCTURNO_INSTITUCIONAL_DEFAULT = 0; // 0 = sin recargo adicional salvo que la institución defina uno — deliberadamente NO se inventa un %

// Art. 38 CT: hospitales ("establecimientos de salud") están explícitamente
// dentro de las actividades exceptuadas del descanso dominical general —
// pueden operar domingo/festivos con descanso compensatorio, pero deben
// asegurar al menos 2 domingos libres al mes por trabajador (salvo
// contratos ≤30 días, jornada parcial ≤20h/semana, o contratados
// exclusivamente para fin de semana/festivos).
const DOMINGOS_LIBRES_MINIMOS_MES = 2;

// Patrones de turno MÁS ALLÁ de la distribución básica del Art. 38 (como
// rotativos 12x36) requieren "sistema excepcional de distribución de
// jornada y descansos" autorizado por resolución fundada del Director del
// Trabajo (vigencia máx. 3 años) — no es automático por definir el turno
// en el sistema. Se modela como flag informativo, no como bloqueo: la
// autorización real es un trámite fuera de este módulo.

/* ---------------------------- catálogo de turnos --------------------------- */
const TURNOS = {
  diurno_administrativo: { label: 'Diurno Administrativo', horasPorDia: 8.4, diasCiclo: 5, esNocturno: false, requiereSistemaExcepcional: false, color: '#2E7D32', icon: Sun },
  turno_12x36_diurno: { label: '12×36 Diurno', horasPorDia: 12, diasCiclo: 2, esNocturno: false, requiereSistemaExcepcional: true, color: '#B45309', icon: Sun },
  turno_12x36_nocturno: { label: '12×36 Nocturno', horasPorDia: 12, diasCiclo: 2, esNocturno: true, requiereSistemaExcepcional: true, color: '#4338CA', icon: Moon },
  turno_noche_fijo: { label: 'Noche Fijo (22:00–07:00)', horasPorDia: 9, diasCiclo: 5, esNocturno: true, requiereSistemaExcepcional: false, color: '#0E7490', icon: Moon },
};

// Catálogo ILUSTRATIVO — mismo criterio que Remuneraciones/Honorarios: el
// catálogo real de roles vive en roles.config.js de MAIN, no cruzado
// todavía con Workforce.
const CARGOS = {
  medico: { label: 'Médico/a', icon: Briefcase, color: '#4338CA' },
  enfermeria: { label: 'Enfermera/o', icon: ShieldCheck, color: '#0E7490' },
  tens: { label: 'TENS', icon: Users, color: '#2E7D32' },
  kinesiologo: { label: 'Kinesiólogo/a', icon: Briefcase, color: '#B45309' },
  matrona: { label: 'Matrona/Matrón', icon: ShieldCheck, color: '#BE185D' },
  administrativo: { label: 'Administrativo/a', icon: Building2, color: '#5B6B85' },
  auxiliar: { label: 'Auxiliar de Servicio', icon: UserRound, color: '#94A3B8' },
};
// Qué cargos usan qué turnos — clínico 24/7 rota, administrativo no.
const TURNOS_POR_CARGO = {
  medico: ['diurno_administrativo', 'turno_12x36_diurno', 'turno_12x36_nocturno'],
  enfermeria: ['turno_12x36_diurno', 'turno_12x36_nocturno', 'turno_noche_fijo'],
  tens: ['turno_12x36_diurno', 'turno_12x36_nocturno', 'turno_noche_fijo'],
  kinesiologo: ['diurno_administrativo', 'turno_12x36_diurno'],
  matrona: ['turno_12x36_diurno', 'turno_12x36_nocturno', 'turno_noche_fijo'],
  administrativo: ['diurno_administrativo'],
  auxiliar: ['diurno_administrativo', 'turno_noche_fijo'],
};

/* ---------------------------- identificadores ----------------------------- */
// Mismo formato PROVISIONAL de CUT que Remuneraciones/Honorarios.
const PAIS = 'CL', REGION = '13', CLINICA = 'AXON';
function hashLiviano(str) {
  let h = 0;
  for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) >>> 0;
  return h.toString(16).toUpperCase().padStart(2, '0').slice(-2);
}
function makeCUT(seq) {
  const s = String(seq).padStart(8, '0');
  return `CUT-${PAIS}-${REGION}-${CLINICA}-${s}-${hashLiviano(`CUT-${PAIS}-${REGION}-${CLINICA}-${s}`)}`;
}
function calcDV(rutBody) {
  let suma = 0, mult = 2;
  for (let i = rutBody.length - 1; i >= 0; i--) {
    suma += parseInt(rutBody[i], 10) * mult;
    mult = mult === 7 ? 2 : mult + 1;
  }
  const resto = 11 - (suma % 11);
  if (resto === 11) return '0';
  if (resto === 10) return 'K';
  return String(resto);
}
function fakeRUT(seed) {
  const body = String(9000000 + (seed * 7919) % 8900000);
  const dv = calcDV(body);
  return body.slice(0, 2) + '.' + body.slice(2, 5) + '.' + body.slice(5) + '-' + dv;
}
const clp = (n) => '$' + Math.round(n).toLocaleString('es-CL');

/* ═══════════════════════════════════════════════════════════════════════
   MOTOR — Turnos y Asistencia
   §26 del Documento Maestro. Calcula, por trabajador y período: horas
   programadas (según turno asignado y su ciclo), horas realmente
   asistidas, la diferencia (horas extra u horas de déficit), atrasos y
   cumplimiento del descanso dominical mínimo del Art. 38.
   ═══════════════════════════════════════════════════════════════════════ */

// Horas programadas en el mes según el ciclo del turno — ej. 12×36: de
// cada 2 días trabaja 1 (12h), descansa el resto del ciclo.
function horasProgramadasMes(turnoId, diasDelMes) {
  const turno = TURNOS[turnoId];
  const diasTrabajados = turno.diasCiclo === 5
    ? Math.round((diasDelMes * 5) / 7)       // administrativo: 5 de cada 7
    : Math.round(diasDelMes / turno.diasCiclo); // rotativo: 1 de cada N
  return Math.round(diasTrabajados * turno.horasPorDia * 10) / 10;
}

function diasEnMes(periodo) {
  const [anio, mes] = periodo.split('-').map(Number);
  return new Date(anio, mes, 0).getDate();
}

/* PUERTA ETIQUETADA — calcularAsistenciaPeriodo
   Función pura y exportable, mismo contrato que calcularLiquidacion de
   Remuneraciones: recibe trabajador + turno + registros de asistencia del
   período, devuelve horas ordinarias/extra/déficit y atrasos. */
export function calcularAsistenciaPeriodo(worker, periodo, registrosDiarios) {
  const horasProgramadas = horasProgramadasMes(worker.turnoId, diasEnMes(periodo));
  // Redondeo a 1 decimal — sumar muchos turnos de horasPorDia decimal (ej. 8.4)
  // acumula ruido de punto flotante (176.40000000000006) sin esto. Encontrado
  // y corregido al probar en Node antes de entregar (ver test_turnos.mjs).
  const horasAsistidas = Math.round(registrosDiarios.reduce((s, r) => s + r.horasTrabajadas, 0) * 10) / 10;
  const atrasosMin = registrosDiarios.reduce((s, r) => s + (r.atrasoMin || 0), 0);
  const ausencias = registrosDiarios.filter((r) => r.horasTrabajadas === 0 && !r.esDescansoProgramado).length;

  const diferencia = Math.round((horasAsistidas - horasProgramadas) * 10) / 10;
  // Tope conservador: no reconocer más de 2h extra por día trabajado (referencia operativa,
  // el máximo legal real depende del Motor de Reglas Jurisdiccionales §19, no construido aún)
  const diasConExceso = registrosDiarios.filter((r) => r.horasTrabajadas > 0).length;
  const horasExtra = diferencia > 0 ? Math.min(diferencia, diasConExceso * 2) : 0;
  const horasDeficit = diferencia < 0 ? Math.abs(diferencia) : 0;

  const turno = TURNOS[worker.turnoId];
  const recargoNocturnoAplicable = turno.esNocturno && RECARGO_NOCTURNO_INSTITUCIONAL_DEFAULT > 0;

  return {
    workerId: worker.id, periodo, turnoId: worker.turnoId,
    horasProgramadas, horasAsistidas, horasExtra, horasDeficit, atrasosMin, ausencias,
    recargoNocturnoAplicable, requiereSistemaExcepcional: turno.requiereSistemaExcepcional,
  };
}

/* PUERTA ETIQUETADA — hacia Remuneraciones
   Misma forma exacta que espera el 3er parámetro de calcularLiquidacion()
   en WorkforceRemuneraciones.jsx: { horasExtraTrabajadas, bonos,
   asignacionesNoImponibles }. Acá se entrega solo horasExtraTrabajadas —
   viene de asistencia REAL, no de ruido aleatorio. */
export function construirInputHorasParaRemuneraciones(asistencia) {
  return { horasExtraTrabajadas: asistencia.horasExtra };
}

export function calcularKPIsAsistencia(registros) {
  const sum = (fn) => registros.reduce((s, r) => s + fn(r), 0);
  const totalProgramadas = sum((r) => r.horasProgramadas);
  const totalAsistidas = sum((r) => r.horasAsistidas);
  const totalExtra = sum((r) => r.horasExtra);
  const totalDeficit = sum((r) => r.horasDeficit);
  const totalAtrasosMin = sum((r) => r.atrasosMin);
  const totalAusencias = sum((r) => r.ausencias);
  const conSistemaExcepcional = registros.filter((r) => r.requiereSistemaExcepcional).length;
  const cumplimiento = totalProgramadas ? Math.round((totalAsistidas / totalProgramadas) * 100) : 0;
  return {
    seccion: 'turnos_asistencia', trabajadores: registros.length,
    totalProgramadas, totalAsistidas, totalExtra, totalDeficit,
    totalAtrasosMin, totalAusencias, conSistemaExcepcional, cumplimiento,
  };
}

/* ═══════════════════════════════════════════════════════════════════════
   REGISTRO CANÓNICO — copiado 1:1 desde WorkforcePersonas.jsx. Antes este
   archivo generaba sus propios 16 trabajadores, sin relación con los de
   Remuneraciones/Honorarios/Licencias. Ahora comparte las mismas 30
   personas — acá se usan los 20 en relación de EMPLEADO.
   ═══════════════════════════════════════════════════════════════════════ */
const NOMBRES_CANONICO = ['María José', 'Pedro', 'Camila', 'Rodrigo', 'Fernanda', 'Ignacio', 'Valentina', 'Cristóbal', 'Antonia', 'Matías', 'Javiera', 'Sebastián', 'Catalina', 'Diego', 'Francisca', 'Tomás', 'Constanza', 'Felipe', 'Josefa', 'Nicolás'];
const APELLIDOS_CANONICO = ['González', 'Muñoz', 'Rojas', 'Díaz', 'Pérez', 'Soto', 'Contreras', 'Silva', 'Martínez', 'Sepúlveda', 'Morales', 'Rodríguez', 'López', 'Fuentes', 'Hernández', 'Torres'];
const CARGOS_LISTA_CANONICO = ['medico', 'enfermeria', 'tens', 'kinesiologo', 'matrona', 'administrativo', 'auxiliar'];
const ESPECIALIDADES_LISTA_CANONICO = ['medico_especialista', 'psicologia', 'kinesiologia', 'nutricion', 'auditoria_clinica'];
const EMPRESAS_HONORARIO_CANONICO = ['Auditoría Clínica del Sur SpA', 'Diagnóstico Externo Ltda.'];

// Antigüedad — mismo generador que WorkforcePersonas.jsx, copiado 1:1.
function fechaIngresoDesdeSeed(seed) {
  const diasAtras = 60 + (seed % 5000);
  const hoy = new Date();
  const fecha = new Date(hoy);
  fecha.setDate(fecha.getDate() - diasAtras);
  return fecha.toISOString().slice(0, 10);
}

function generarPersonasCanonico() {
  const personas = [];
  let seed = 100;
  // 20 personas — relación EMPLEADO. Últimas 3 son de un tenant AXON Core
  // (Workforce como tecnología, empleador real es el tenant, no AXON).
  for (let i = 0; i < 20; i++) {
    seed += 17;
    const esCore = i >= 17;
    personas.push({
      id: `per_${1000 + i}`, cut: makeCUT(1000 + i), rut: fakeRUT(seed),
      nombres: NOMBRES_CANONICO[seed % NOMBRES_CANONICO.length],
      apellidoPaterno: APELLIDOS_CANONICO[(seed * 2) % APELLIDOS_CANONICO.length],
      apellidoMaterno: APELLIDOS_CANONICO[(seed * 5) % APELLIDOS_CANONICO.length],
      tipoRelacion: 'empleado',
      axonLinea: esCore ? 'axon_core' : 'axon_health',
      tenantId: esCore ? 'tenant_hospital_regional_demo' : null,
      // sector (privado/publico) — ver WorkforcePersonas.jsx para la nota
      // completa. Ley 19.664/Estatuto Administrativo NO está implementada
      // todavía, este es solo el campo (puerta etiquetada).
      sector: esCore ? 'publico' : 'privado',
      cargoId: CARGOS_LISTA_CANONICO[seed % CARGOS_LISTA_CANONICO.length],
      fechaIngreso: fechaIngresoDesdeSeed(seed),
    });
  }
  // 10 personas — relación HONORARIO. Últimas 2 son empresa (doble vía ya
  // establecida por Contabilidad), el resto persona natural. Todos
  // AXON Core Lite — independientes, sin institución de por medio.
  for (let i = 0; i < 10; i++) {
    seed += 23;
    const esEmpresa = i >= 8;
    personas.push({
      id: `per_${2000 + i}`, cut: makeCUT(2000 + i), rut: fakeRUT(seed),
      nombres: esEmpresa ? null : NOMBRES_CANONICO[seed % NOMBRES_CANONICO.length],
      apellidoPaterno: esEmpresa ? null : APELLIDOS_CANONICO[(seed * 2) % APELLIDOS_CANONICO.length],
      apellidoMaterno: esEmpresa ? null : APELLIDOS_CANONICO[(seed * 5) % APELLIDOS_CANONICO.length],
      razonSocial: esEmpresa ? EMPRESAS_HONORARIO_CANONICO[i - 8] : null,
      tipoRelacion: 'honorario',
      tipoPersonaHonorario: esEmpresa ? 'empresa' : 'natural',
      axonLinea: 'axon_core_lite', tenantId: null,
      especialidadId: esEmpresa ? 'auditoria_clinica' : ESPECIALIDADES_LISTA_CANONICO[seed % (ESPECIALIDADES_LISTA_CANONICO.length - 1)],
    });
  }
  return personas;
}

// Turnos y Asistencia solo usa los EMPLEADOS del registro canónico, y les
// agrega ENCIMA el turnoId, que el registro canónico no conoce.
function genTrabajadores() {
  return generarPersonasCanonico()
    .filter((p) => p.tipoRelacion === 'empleado')
    .map((p) => {
      const seed = Number(p.id.split('_')[1]);
      const turnosDisponibles = TURNOS_POR_CARGO[p.cargoId];
      const turnoId = turnosDisponibles[seed % turnosDisponibles.length];
      return { ...p, turnoId };
    });
}
const nombreCompleto = (w) => w.razonSocial || `${w.nombres} ${w.apellidoPaterno} ${w.apellidoMaterno}`;

function mesesHastaHoy(cantidad) {
  const hoy = new Date();
  const out = [];
  for (let i = cantidad - 1; i >= 0; i--) {
    const d = new Date(hoy.getFullYear(), hoy.getMonth() - i, 1);
    out.push(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`);
  }
  return out;
}
const PERIODOS = mesesHastaHoy(3);

function genRegistrosDiarios(worker, periodo, seedBase) {
  const turno = TURNOS[worker.turnoId];
  const dias = diasEnMes(periodo);
  const diasTrabajaEsperados = turno.diasCiclo === 5 ? Math.round((dias * 5) / 7) : Math.round(dias / turno.diasCiclo);
  const registros = [];
  let seed = seedBase;
  for (let i = 0; i < diasTrabajaEsperados; i++) {
    seed += 7;
    const asistio = seed % 20 !== 0; // ~5% ausentismo
    const conExtra = seed % 6 === 0;
    const horasTrabajadas = !asistio ? 0 : conExtra ? turno.horasPorDia + 1 + (seed % 2) : turno.horasPorDia;
    const atrasoMin = asistio && seed % 8 === 0 ? 5 + (seed % 20) : 0;
    registros.push({ horasTrabajadas, atrasoMin, esDescansoProgramado: false });
  }
  return registros;
}

function genAsistencia(trabajadores) {
  const rows = [];
  let seed = 6;
  trabajadores.forEach((w) => {
    PERIODOS.forEach((periodo) => {
      seed += 23;
      const registros = genRegistrosDiarios(w, periodo, seed);
      const asistencia = calcularAsistenciaPeriodo(w, periodo, registros);
      const esUltimoPeriodo = periodo === PERIODOS[PERIODOS.length - 1];
      rows.push({ ...asistencia, id: `asist_${w.id}_${periodo}`, worker: w, estado: esUltimoPeriodo ? 'en_curso' : 'cerrado' });
    });
  });
  return rows.sort((a, b) => (a.periodo < b.periodo ? 1 : -1));
}

/* ------------------------------- átomos ---------------------------------- */
const Badge = ({ color, bg, icon: Icon, children }) => (
  <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, padding: '3px 9px', borderRadius: 999, fontSize: 12, fontWeight: 600, color, background: bg, whiteSpace: 'nowrap' }}>
    {Icon && <Icon size={12} />}{children}
  </span>
);
const Btn = ({ variant = 'ghost', icon: Icon, children, onClick, style }) => {
  const base = { display: 'inline-flex', alignItems: 'center', gap: 7, padding: '9px 15px', borderRadius: C.rSm, fontSize: 13.5, fontWeight: 600, cursor: 'pointer', border: '1px solid transparent', fontFamily: C.font, transition: 'filter .12s ease' };
  const variants = {
    primary: { background: C.pri, color: '#fff' },
    outline: { background: '#fff', color: C.ink, border: `1px solid ${C.border}` },
    ghost: { background: 'transparent', color: C.sub },
  };
  return (
    <button type="button" onClick={onClick}
      onMouseEnter={(e) => (e.currentTarget.style.filter = 'brightness(0.96)')}
      onMouseLeave={(e) => (e.currentTarget.style.filter = 'none')}
      style={{ ...base, ...variants[variant], ...style }}>
      {Icon && <Icon size={15} />}{children}
    </button>
  );
};
const KPICard = ({ label, value, sub, icon: Icon, accent }) => (
  <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, padding: '16px 18px', boxShadow: C.shadow, flex: 1, minWidth: 0 }}>
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
      <span style={{ fontSize: 12.5, color: C.sub, fontWeight: 600 }}>{label}</span>
      <div style={{ width: 28, height: 28, borderRadius: 8, background: accent + '18', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <Icon size={14} style={{ color: accent }} />
      </div>
    </div>
    <div style={{ fontSize: 22, fontWeight: 700, color: C.ink, letterSpacing: -0.3 }}>{value}</div>
    {sub && <div style={{ fontSize: 12, color: C.mut, marginTop: 3 }}>{sub}</div>}
  </div>
);
const FieldLabel = ({ children }) => <label style={{ fontSize: 11.5, fontWeight: 600, color: C.sub, marginBottom: 5, display: 'block' }}>{children}</label>;
const inputStyle = { width: '100%', padding: '8px 10px', borderRadius: C.rSm, border: `1px solid ${C.border}`, fontSize: 13.5, fontFamily: C.font, color: C.ink, outline: 'none', boxSizing: 'border-box', background: '#fff' };

/* ------------------------- detalle de asistencia -------------------------- */
function DetailModal({ asist, onClose }) {
  const [tab, setTab] = useState('asistencia');
  if (!asist) return null;
  const w = asist.worker;
  const cargo = CARGOS[w.cargoId];
  const turno = TURNOS[asist.turnoId];
  const inputRemu = construirInputHorasParaRemuneraciones(asist);

  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(16,24,40,.45)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100, padding: 20 }} onClick={onClose}>
      <div style={{ background: '#fff', borderRadius: C.rLg, width: 520, maxWidth: '100%', maxHeight: '90vh', overflowY: 'auto', boxShadow: '0 20px 50px rgba(16,24,40,.25)' }} onClick={(e) => e.stopPropagation()}>
        <div style={{ padding: '18px 22px', borderBottom: `1px solid ${C.border}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
            <div style={{ width: 34, height: 34, borderRadius: 9, background: cargo.color + '18', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <cargo.icon size={16} style={{ color: cargo.color }} />
            </div>
            <div>
              <div style={{ fontSize: 15, fontWeight: 700, color: C.ink }}>{nombreCompleto(w)}</div>
              <div style={{ fontSize: 12, color: C.mut }}>{cargo.label} · {asist.periodo}</div>
            </div>
          </div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: C.mut, padding: 4 }}><X size={18} /></button>
        </div>

        <div style={{ display: 'flex', borderBottom: `1px solid ${C.border}`, padding: '0 22px' }}>
          {[['asistencia', 'Asistencia'], ['remuneraciones', 'Hacia Remuneraciones']].map(([id, label]) => (
            <button key={id} onClick={() => setTab(id)} style={{ padding: '10px 4px', marginRight: 20, fontSize: 13, fontWeight: 600, color: tab === id ? C.pri : C.mut, background: 'none', border: 'none', borderBottom: `2px solid ${tab === id ? C.pri : 'transparent'}`, cursor: 'pointer' }}>
              {label}
            </button>
          ))}
        </div>

        {tab === 'asistencia' ? (
          <div style={{ padding: 22, display: 'flex', flexDirection: 'column', gap: 16 }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
              <div>
                <FieldLabel>CUT</FieldLabel>
                <div style={{ fontSize: 12, color: C.ink, fontFamily: 'monospace', background: C.bg, padding: '6px 10px', borderRadius: 6 }}>{w.cut}</div>
              </div>
              <div>
                <FieldLabel>Turno asignado</FieldLabel>
                <Badge color={turno.color} bg={turno.color + '18'} icon={turno.icon}>{turno.label}</Badge>
              </div>
            </div>

            {turno.requiereSistemaExcepcional && (
              <div style={{ display: 'flex', gap: 8, alignItems: 'flex-start', background: C.warnL, padding: '10px 12px', borderRadius: C.rSm, fontSize: 11.5, color: C.warn }}>
                <AlertTriangle size={13} style={{ flexShrink: 0, marginTop: 1 }} />
                <span>Este patrón de turno requiere sistema excepcional de distribución de jornada autorizado por resolución del Director del Trabajo (Art. 38 CT) — trámite administrativo fuera de este módulo, no bloquea el registro.</span>
              </div>
            )}

            <div style={{ background: C.bg, borderRadius: C.rSm, padding: 14 }}>
              {[
                ['Horas programadas', asist.horasProgramadas + ' h'],
                ['Horas asistidas', asist.horasAsistidas + ' h'],
                ['Atrasos acumulados', asist.atrasosMin + ' min'],
                ['Ausencias', asist.ausencias],
              ].map(([label, val]) => (
                <div key={label} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12.5, color: C.sub, marginBottom: 5 }}>
                  <span>{label}</span><span style={{ color: C.ink, fontWeight: 600 }}>{val}</span>
                </div>
              ))}
            </div>

            <div style={{ display: 'flex', gap: 10 }}>
              <div style={{ flex: 1, background: C.priL, borderRadius: C.rSm, padding: 12 }}>
                <div style={{ fontSize: 10, color: C.priD, fontWeight: 700 }}>HORAS EXTRA</div>
                <div style={{ fontSize: 17, fontWeight: 700, color: C.ink }}>{asist.horasExtra} h</div>
              </div>
              <div style={{ flex: 1, background: C.errL, borderRadius: C.rSm, padding: 12 }}>
                <div style={{ fontSize: 10, color: C.err, fontWeight: 700 }}>DÉFICIT</div>
                <div style={{ fontSize: 17, fontWeight: 700, color: C.ink }}>{asist.horasDeficit} h</div>
              </div>
            </div>
          </div>
        ) : (
          <div style={{ padding: 22, display: 'flex', flexDirection: 'column', gap: 14 }}>
            <div style={{ display: 'flex', gap: 8, alignItems: 'flex-start', background: C.infoL, padding: '10px 12px', borderRadius: C.rSm, fontSize: 12, color: '#1D4ED8' }}>
              <Send size={14} style={{ flexShrink: 0, marginTop: 1 }} />
              <span>Puerta etiquetada — esta es la forma exacta que recibiría el 3er parámetro de `calcularLiquidacion(worker, periodo, input)` en WorkforceRemuneraciones.jsx. Todavía sin conexión real entre los dos archivos (cada uno sigue siendo standalone-previsualizable).</span>
            </div>
            <div>
              <FieldLabel>Input hacia calcularLiquidacion(...)</FieldLabel>
              <pre style={{ fontSize: 11, background: C.ink, color: '#D4CBEF', padding: 14, borderRadius: C.rSm, overflowX: 'auto', margin: 0 }}>{JSON.stringify(inputRemu, null, 2)}</pre>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

/* --------------------------------- vista principal ------------------------------------ */
export default function WorkforceTurnosAsistencia({ addToast }) {
  const toast = addToast || ((msg) => console.log(msg));
  const [trabajadores] = useState(genTrabajadores);
  const [data] = useState(() => genAsistencia(trabajadores));
  const [filtros, setFiltros] = useState({ periodo: 'todos', cargo: 'todos', turno: 'todos', q: '' });
  const [selected, setSelected] = useState(null);
  const [page, setPage] = useState(1);
  const perPage = 8;

  const filtered = useMemo(() => data.filter((a) => {
    if (filtros.periodo !== 'todos' && a.periodo !== filtros.periodo) return false;
    if (filtros.cargo !== 'todos' && a.worker.cargoId !== filtros.cargo) return false;
    if (filtros.turno !== 'todos' && a.turnoId !== filtros.turno) return false;
    if (filtros.q) {
      const q = filtros.q.toLowerCase();
      if (!nombreCompleto(a.worker).toLowerCase().includes(q) && !a.worker.rut.includes(q) && !a.worker.cut.toLowerCase().includes(q)) return false;
    }
    return true;
  }), [data, filtros]);

  const kpi = useMemo(() => calcularKPIsAsistencia(filtered), [filtered]);
  const totalPages = Math.max(1, Math.ceil(filtered.length / perPage));
  const pageRows = filtered.slice((page - 1) * perPage, page * perPage);
  const limpiarFiltros = () => { setFiltros({ periodo: 'todos', cargo: 'todos', turno: 'todos', q: '' }); setPage(1); };

  const exportarCSV = () => {
    const header = ['Período', 'Trabajador', 'CUT', 'Cargo', 'Turno', 'Horas Programadas', 'Horas Asistidas', 'Horas Extra', 'Déficit', 'Atrasos (min)', 'Ausencias', 'Estado'];
    const lines = filtered.map((a) => [a.periodo, nombreCompleto(a.worker), a.worker.cut, CARGOS[a.worker.cargoId].label, TURNOS[a.turnoId].label, a.horasProgramadas, a.horasAsistidas, a.horasExtra, a.horasDeficit, a.atrasosMin, a.ausencias, a.estado].join(';'));
    const blob = new Blob([header.join(';') + '\n' + lines.join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a2 = document.createElement('a');
    a2.href = url; a2.download = `turnos_asistencia_${PERIODOS[0]}_a_${PERIODOS[PERIODOS.length - 1]}.csv`; a2.click();
    URL.revokeObjectURL(url);
    toast('Archivo CSV descargado');
  };

  return (
    <div style={{ fontFamily: C.font, background: C.bg, minHeight: '100%', padding: 22 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 18, flexWrap: 'wrap', gap: 12 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
          <div style={{ width: 34, height: 34, borderRadius: 9, background: C.priL, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <CalendarClock size={17} style={{ color: C.pri }} />
          </div>
          <div>
            <div style={{ fontSize: 18, fontWeight: 700, color: C.ink }}>Turnos y Asistencia</div>
            <div style={{ fontSize: 12.5, color: C.mut }}>Workforce · Motor de tiempo y asistencia — Documento Maestro §26, §27</div>
          </div>
        </div>
        <Btn variant="outline" icon={Download} onClick={exportarCSV}>Exportar CSV</Btn>
      </div>

      <div style={{ fontSize: 11.5, fontWeight: 700, color: C.mut, textTransform: 'uppercase', letterSpacing: 0.4, marginBottom: 8 }}>Período filtrado</div>
      <div style={{ display: 'flex', gap: 14, marginBottom: 18, flexWrap: 'wrap' }}>
        <KPICard label="Trabajadores" value={kpi.trabajadores} sub={`${PERIODOS.length} períodos cargados`} icon={Users} accent={C.pri} />
        <KPICard label="Cumplimiento" value={kpi.cumplimiento + '%'} sub="Asistidas / programadas" icon={ClipboardCheck} accent={C.info} />
        <KPICard label="Horas extra generadas" value={kpi.totalExtra + ' h'} sub="Fuente real para Remuneraciones" icon={Hourglass} accent={C.gold} />
        <KPICard label="Horas déficit" value={kpi.totalDeficit + ' h'} sub="Asistido bajo lo programado" icon={Ban} accent={C.err} />
      </div>
      <div style={{ display: 'flex', gap: 14, marginBottom: 18, flexWrap: 'wrap' }}>
        <KPICard label="Ausencias" value={kpi.totalAusencias} sub="Días sin asistencia, no programados" icon={AlertTriangle} accent={C.warn} />
        <KPICard label="Atrasos acumulados" value={kpi.totalAtrasosMin + ' min'} sub="Suma de todo el período filtrado" icon={Clock} accent={C.teal} />
        <KPICard label="Con sistema excepcional" value={kpi.conSistemaExcepcional} sub="Turnos que requieren resolución DT (Art. 38)" icon={ShieldCheck} accent={C.pri} />
      </div>

      <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, padding: 16, boxShadow: C.shadow, marginBottom: 14 }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 10, alignItems: 'end' }}>
          <div>
            <FieldLabel>Período</FieldLabel>
            <select style={inputStyle} value={filtros.periodo} onChange={(e) => { setFiltros({ ...filtros, periodo: e.target.value }); setPage(1); }}>
              <option value="todos">Todos</option>
              {PERIODOS.map((p) => <option key={p} value={p}>{p}</option>)}
            </select>
          </div>
          <div>
            <FieldLabel>Cargo</FieldLabel>
            <select style={inputStyle} value={filtros.cargo} onChange={(e) => { setFiltros({ ...filtros, cargo: e.target.value }); setPage(1); }}>
              <option value="todos">Todos</option>
              {Object.entries(CARGOS).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
            </select>
          </div>
          <div>
            <FieldLabel>Turno</FieldLabel>
            <select style={inputStyle} value={filtros.turno} onChange={(e) => { setFiltros({ ...filtros, turno: e.target.value }); setPage(1); }}>
              <option value="todos">Todos</option>
              {Object.entries(TURNOS).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
            </select>
          </div>
          <div style={{ gridColumn: 'span 2' }}>
            <FieldLabel>Buscar</FieldLabel>
            <div style={{ position: 'relative' }}>
              <Search size={14} style={{ position: 'absolute', left: 9, top: 10, color: C.mut }} />
              <input style={{ ...inputStyle, paddingLeft: 28 }} placeholder="Nombre, RUT o CUT" value={filtros.q} onChange={(e) => { setFiltros({ ...filtros, q: e.target.value }); setPage(1); }} />
            </div>
          </div>
        </div>
        <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 12 }}>
          <button onClick={limpiarFiltros} style={{ display: 'flex', alignItems: 'center', gap: 5, background: 'none', border: 'none', cursor: 'pointer', color: C.sub, fontSize: 12.5, fontWeight: 600, padding: 0 }}>
            <RotateCcw size={13} /> Limpiar filtros
          </button>
        </div>
      </div>

      <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, boxShadow: C.shadow, overflow: 'hidden' }}>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
            <thead>
              <tr style={{ background: C.bg, textAlign: 'left' }}>
                {['Período', 'Trabajador', 'Turno', 'Programadas', 'Asistidas', 'Extra', 'Déficit', 'Estado', ''].map((h) => (
                  <th key={h} style={{ padding: '10px 14px', fontSize: 11.5, fontWeight: 700, color: C.sub, textTransform: 'uppercase', letterSpacing: 0.3, whiteSpace: 'nowrap' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {pageRows.map((a) => {
                const turno = TURNOS[a.turnoId];
                return (
                  <tr key={a.id} style={{ borderTop: `1px solid ${C.border}`, cursor: 'pointer' }} onClick={() => setSelected(a)}
                    onMouseEnter={(e) => (e.currentTarget.style.background = C.bg)} onMouseLeave={(e) => (e.currentTarget.style.background = 'transparent')}>
                    <td style={{ padding: '11px 14px', color: C.sub, whiteSpace: 'nowrap' }}>{a.periodo}</td>
                    <td style={{ padding: '11px 14px' }}>
                      <div style={{ fontWeight: 600, color: C.ink }}>{nombreCompleto(a.worker)}</div>
                      <div style={{ fontSize: 11, color: C.mut }}>{CARGOS[a.worker.cargoId].label}</div>
                    </td>
                    <td style={{ padding: '11px 14px' }}><Badge color={turno.color} bg={turno.color + '18'} icon={turno.icon}>{turno.label}</Badge></td>
                    <td style={{ padding: '11px 14px', color: C.sub, whiteSpace: 'nowrap' }}>{a.horasProgramadas} h</td>
                    <td style={{ padding: '11px 14px', color: C.ink, whiteSpace: 'nowrap' }}>{a.horasAsistidas} h</td>
                    <td style={{ padding: '11px 14px', color: a.horasExtra > 0 ? C.gold : C.mut, whiteSpace: 'nowrap' }}>{a.horasExtra > 0 ? `+${a.horasExtra} h` : '—'}</td>
                    <td style={{ padding: '11px 14px', color: a.horasDeficit > 0 ? C.err : C.mut, whiteSpace: 'nowrap' }}>{a.horasDeficit > 0 ? `-${a.horasDeficit} h` : '—'}</td>
                    <td style={{ padding: '11px 14px' }}>
                      <Badge color={a.estado === 'cerrado' ? C.pri : C.warn} bg={(a.estado === 'cerrado' ? C.pri : C.warn) + '18'} icon={a.estado === 'cerrado' ? CheckCircle2 : Clock}>
                        {a.estado === 'cerrado' ? 'Cerrado' : 'En curso'}
                      </Badge>
                    </td>
                    <td style={{ padding: '11px 14px' }}><Eye size={15} style={{ color: C.mut }} /></td>
                  </tr>
                );
              })}
              {pageRows.length === 0 && (
                <tr><td colSpan={9} style={{ padding: '40px 14px', textAlign: 'center', color: C.mut, fontSize: 13 }}>
                  No hay registros que calcen con estos filtros. <button onClick={limpiarFiltros} style={{ color: C.info, background: 'none', border: 'none', cursor: 'pointer', fontSize: 13, textDecoration: 'underline', padding: 0 }}>Limpia los filtros</button>.
                </td></tr>
              )}
            </tbody>
          </table>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 16px', borderTop: `1px solid ${C.border}` }}>
          <span style={{ fontSize: 12, color: C.mut }}>{filtered.length} registros · página {page} de {totalPages}</span>
          <div style={{ display: 'flex', gap: 6 }}>
            <Btn variant="outline" onClick={() => setPage(Math.max(1, page - 1))} style={{ padding: '6px 12px', opacity: page === 1 ? 0.4 : 1 }}>Anterior</Btn>
            <Btn variant="outline" onClick={() => setPage(Math.min(totalPages, page + 1))} style={{ padding: '6px 12px', opacity: page === totalPages ? 0.4 : 1 }}>Siguiente</Btn>
          </div>
        </div>
      </div>

      {selected && <DetailModal asist={selected} onClose={() => setSelected(null)} />}
    </div>
  );
}

