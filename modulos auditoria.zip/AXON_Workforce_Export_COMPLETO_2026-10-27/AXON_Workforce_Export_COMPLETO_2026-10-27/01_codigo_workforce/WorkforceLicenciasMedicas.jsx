import React, { useState, useMemo } from 'react';
import {
  FileHeart, Search, Download, X, Users, Clock, CheckCircle2, XCircle,
  AlertTriangle, Ban, Info, Eye, RotateCcw, ShieldCheck, Briefcase,
  UserRound, Building2, CalendarX, Scale, Hourglass,
} from 'lucide-react';

/* =========================================================================
   AXON WORKFORCE — Licencias Médicas
   Módulo de Recursos Humanos / Workforce · Sección: Licencias Médicas
   Ver Documento Maestro de Arquitectura Workforce §23-25 (Licencias
   Médicas: dos flujos, Deadline Engine, Licencia ≠ Ausencia).

   CUARTA SECCIÓN DE WORKFORCE. El docx es explícito en §23: hay DOS
   flujos separados —
     Flujo 1 (emisión): del profesional sanitario autorizado. NO vive acá,
       vive en el sistema clínico (identidad profesional, habilitación).
     Flujo 2 (recepción): del trabajador/Workforce. SÍ vive acá —
       TRABAJADOR → LICENCIA → RECEPCIÓN → VALIDACIÓN → CÁLCULO DE PLAZO
       → PROCESAMIENTO → AUSENCIA → COBERTURA.
   Este archivo modela solo Flujo 2: consume una licencia YA EMITIDA
   (dato de entrada) y gestiona su recepción, plazos y estado.

   §25 del docx: Licencia médica (el documento) y Ausencia (el período sin
   disponibilidad) son cosas DISTINTAS — se modelan como dos campos
   relacionados, no uno solo.

   Reutiliza el listado de feriados 2026 ya verificado en
   AtencionAgendaImagenologia.jsx ("verificados por búsqueda") en vez de
   volver a buscarlo — mismo principio de una sola fuente de verdad legal
   por parámetro que ya usa Honorarios con la tasa de retención.
   ========================================================================= */

/* DISEÑO — misma identidad violeta de Workforce. */
const C = {
  bg: '#F6F5FB', card: '#FFFFFF', border: '#E3DEF5', borderD: '#CBC0E8',
  ink: '#241A3D', sub: '#5F5580', mut: '#948AB5',
  pri: '#6D28D9', priD: '#5518B0', priL: '#F1EAFC',
  info: '#2563EB', infoL: '#EEF3FF',
  warn: '#B45309', warnL: '#FEF3E2',
  err: '#C62828', errL: '#FDECEC',
  gold: '#B7791F', goldL: '#FBF0DD',
  teal: '#0E7490', tealL: '#E3F6FA',
  r: 10, rSm: 7, rLg: 14,
  shadow: '0 1px 3px rgba(16,24,40,.06), 0 1px 2px rgba(16,24,40,.04)',
  font: "'Inter', -apple-system, 'Segoe UI', Roboto, sans-serif",
};

/* ---------------------------- catálogos base ------------------------------ */
const TIPOS_LICENCIA = {
  // aplicaCarencia — CORREGIDO 2026-10-03 (antes la carencia se aplicaba a todos los tipos).
  // Los 3 días de carencia son del régimen SIL del DFL 44/1978 art. 14 (enfermedad o accidente
  // NO laboral). Accidente del trabajo, de trayecto y enfermedad profesional (Ley 16.744) se
  // pagan desde el día del accidente o del diagnóstico — fuente: SUSESO. Maternal: subsidio
  // propio que parte con el descanso; NO verificado contra fuente en esta sesión (hoy no cambia
  // nada: el mock genera maternales de 84/126 días, siempre sobre el umbral de 10).
  enfermedad_comun: { label: 'Enfermedad Común', color: '#2563EB', circuito: 'isapre_fonasa', aplicaCarencia: true },
  maternal: { label: 'Maternal (Pre/Postnatal)', color: '#BE185D', circuito: 'isapre_fonasa', aplicaCarencia: false },
  accidente_trabajo: { label: 'Accidente del Trabajo', color: '#B45309', circuito: 'mutual', aplicaCarencia: false },
  accidente_trayecto: { label: 'Accidente de Trayecto', color: '#B45309', circuito: 'mutual', aplicaCarencia: false },
  enfermedad_profesional: { label: 'Enfermedad Profesional', color: '#C62828', circuito: 'mutual', aplicaCarencia: false },
};

const CARGOS = {
  medico: { label: 'Médico/a', icon: Briefcase, color: '#4338CA' },
  enfermeria: { label: 'Enfermera/o', icon: ShieldCheck, color: '#0E7490' },
  tens: { label: 'TENS', icon: Users, color: '#2E7D32' },
  kinesiologo: { label: 'Kinesiólogo/a', icon: Briefcase, color: '#B45309' },
  matrona: { label: 'Matrona/Matrón', icon: ShieldCheck, color: '#BE185D' },
  administrativo: { label: 'Administrativo/a', icon: Building2, color: '#5B6B85' },
  auxiliar: { label: 'Auxiliar de Servicio', icon: UserRound, color: '#94A3B8' },
};

/* ═══════════════════════════════════════════════════════════════════════
   PARÁMETROS LEGALES — verificados por búsqueda el 2026-09-10, fuentes
   oficiales concordantes (DT, MINSAL, Superintendencia de Salud, SUSESO).
   ═══════════════════════════════════════════════════════════════════════ */
// Plazo TRABAJADOR → EMPLEADOR para entregar la licencia — cuenta desde el
// día hábil SIGUIENTE al inicio del reposo (DT.gob.cl, MINSAL, Superintendencia
// de Salud, SUSESO — 4 fuentes oficiales concordantes).
const PLAZO_TRABAJADOR_EMPLEADOR_DIAS_HABILES = { privado: 2, publico: 3 };
// Plazo EMPLEADOR → COMPIN/Isapre/CCAF — cuenta desde la recepción del
// formulario (MINSAL, SUSESO). Si el empleador se atrasa, debe pagar el
// subsidio de su propio bolsillo — hallazgo real, no una simplificación.
const PLAZO_EMPLEADOR_COMPIN_DIAS_HABILES = 3;
// Carencia SIL (Subsidio por Incapacidad Laboral): licencias de 1-10 días
// no pagan los primeros 3 días (ni empleador ni SIL); licencias de 11+
// días se pagan completas, sin carencia.
const CARENCIA_UMBRAL_DIAS = 10;
const CARENCIA_DIAS = 3;
// Apelación ante COMPIN si rechaza Isapre, luego SUSESO como última instancia.
const PLAZO_APELACION_COMPIN_DIAS_HABILES = 15;
const PLAZO_APELACION_SUSESO_DIAS_HABILES = 5;
// Plazo legal de pago del subsidio una vez presentada la licencia.
const PLAZO_PAGO_SUBSIDIO_DIAS_HABILES = 30;

// Feriados Chile 2026 — MISMA lista ya verificada en
// AtencionAgendaImagenologia.jsx (no se vuelve a buscar, una sola fuente
// de verdad por parámetro legal, mismo principio que la tasa de
// retención de Honorarios reutilizada desde Contabilidad).
const FERIADOS_CHILE_2026 = {
  '2026-01-01': 'Año Nuevo', '2026-04-03': 'Viernes Santo', '2026-04-04': 'Sábado Santo',
  '2026-05-01': 'Día Nacional del Trabajo', '2026-05-21': 'Glorias Navales',
  '2026-06-07': 'Asalto y Toma del Morro de Arica (regional)', '2026-06-29': 'San Pedro y San Pablo',
  '2026-07-16': 'Virgen del Carmen', '2026-08-15': 'Asunción de la Virgen',
  '2026-08-20': "Natalicio de O'Higgins (regional)", '2026-09-18': 'Fiestas Patrias',
  '2026-09-19': 'Glorias del Ejército', '2026-10-12': 'Encuentro de Dos Mundos',
  '2026-10-31': 'Iglesias Evangélicas y Protestantes', '2026-11-01': 'Todos los Santos',
  '2026-12-08': 'Inmaculada Concepción', '2026-12-25': 'Navidad',
};

/* ---------------------------- identificadores ----------------------------- */
const PAIS = 'CL', REGION = '13', CLINICA = 'AXON';
function hashLiviano(str) {
  let h = 0;
  for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) >>> 0;
  return h.toString(16).toUpperCase().padStart(2, '0').slice(-2);
}
function makeCUT(seq) {
  const s = String(seq).padStart(8, '0');
  return `CUT-${PAIS}-${REGION}-${CLINICA}-${s}-${hashLiviano(`CUT-${PAIS}-${REGION}-${CLINICA}-${s}`)}`;
}
function calcDV(rutBody) {
  let suma = 0, mult = 2;
  for (let i = rutBody.length - 1; i >= 0; i--) {
    suma += parseInt(rutBody[i], 10) * mult;
    mult = mult === 7 ? 2 : mult + 1;
  }
  const resto = 11 - (suma % 11);
  if (resto === 11) return '0';
  if (resto === 10) return 'K';
  return String(resto);
}
function fakeRUT(seed) {
  const body = String(9000000 + (seed * 7919) % 8900000);
  const dv = calcDV(body);
  return body.slice(0, 2) + '.' + body.slice(2, 5) + '.' + body.slice(5) + '-' + dv;
}

/* ------------------------------ fechas/días hábiles ------------------------------ */
// Aritmética en UTC puro (corregido 2026-10-03): con hora local, `toISOString` corría un día en zonas
// UTC+ y las restas de fechas perdían un día al cruzar un cambio de horario (incluido America/Santiago).
const aUTC = (iso) => { const [y, m, d] = iso.split('-').map(Number); return Date.UTC(y, m - 1, d); };
function sumarDias(fechaISO, n) {
  const dt = new Date(aUTC(fechaISO) + n * 86400000);
  return `${dt.getUTCFullYear()}-${String(dt.getUTCMonth() + 1).padStart(2, '0')}-${String(dt.getUTCDate()).padStart(2, '0')}`;
}
function esDiaHabil(fechaISO) {
  const dow = new Date(aUTC(fechaISO)).getUTCDay();
  if (dow === 0 || dow === 6) return false;
  if (FERIADOS_CHILE_2026[fechaISO]) return false;
  return true;
}
// Cuenta N días HÁBILES hacia adelante desde fechaISO (sin incluir fechaISO).
function sumarDiasHabiles(fechaISO, n) {
  let fecha = fechaISO, contados = 0;
  while (contados < n) {
    fecha = sumarDias(fecha, 1);
    if (esDiaHabil(fecha)) contados++;
  }
  return fecha;
}
function diffDias(isoA, isoB) {
  return Math.round((aUTC(isoB) - aUTC(isoA)) / 86400000);
}
const fmtDate = (iso) => new Date(iso + 'T00:00:00').toLocaleDateString('es-CL', { day: '2-digit', month: 'short', year: 'numeric' });
const clp = (n) => '$' + Math.round(n).toLocaleString('es-CL');

/* ═══════════════════════════════════════════════════════════════════════
   MOTOR — Licencias Médicas (Flujo 2: Recepción)
   §24: Medical Leave → Jurisdiction Rules → Deadline Engine. Acá se
   implementa el Deadline Engine para Chile; el resto del Motor de Reglas
   Jurisdiccionales (§19) todavía no existe como pieza genérica.
   ═══════════════════════════════════════════════════════════════════════ */
export function calcularLicencia(worker, licencia) {
  const { fechaInicioReposo, diasReposo, fechaRecepcionEmpleador, fechaEnvioCompin, sector = 'privado', fechaResolucion, fechaApelacion } = licencia;
  const fechaTermino = sumarDias(fechaInicioReposo, diasReposo - 1);

  // Plazo trabajador→empleador: se cuentan los días hábiles siguientes al inicio del reposo (corregido 2026-10-27: antes, si el reposo partía en día inhábil seguido de hábil —domingo, lunes feriado—, se contaba un día de más).
  const inicioConteo = fechaInicioReposo; // se cuenta desde el día siguiente; si el reposo parte en día inhábil, el primer día hábil que sigue es el día 1
  const plazoTrabajador = sumarDiasHabiles(inicioConteo, PLAZO_TRABAJADOR_EMPLEADOR_DIAS_HABILES[sector]);
  const trabajadorEnPlazo = fechaRecepcionEmpleador ? fechaRecepcionEmpleador <= plazoTrabajador : null;

  // Plazo empleador→COMPIN: cuenta desde la recepción real del formulario.
  const plazoEmpleador = fechaRecepcionEmpleador ? sumarDiasHabiles(fechaRecepcionEmpleador, PLAZO_EMPLEADOR_COMPIN_DIAS_HABILES) : null;
  const empleadorEnPlazo = fechaEnvioCompin && plazoEmpleador ? fechaEnvioCompin <= plazoEmpleador : null;
  // Consecuencia real si el empleador se atrasa: paga el subsidio de su
  // propio bolsillo (verificado, no es una simplificación de esta sesión).
  const empleadorAsumeSubsidio = empleadorEnPlazo === false;

  // Carencia SIL — primeros 3 días sin pago si la licencia es de 10 días o menos, solo en los
  // tipos con aplicaCarencia (ver TIPOS_LICENCIA).
  const aplicaCarencia = TIPOS_LICENCIA[licencia.tipoId].aplicaCarencia && diasReposo <= CARENCIA_UMBRAL_DIAS;
  const diasCarencia = aplicaCarencia ? Math.min(CARENCIA_DIAS, diasReposo) : 0;
  const diasPagadosSIL = diasReposo - diasCarencia;

  const circuito = TIPOS_LICENCIA[licencia.tipoId].circuito; // isapre_fonasa | mutual
  const estadoResolucion = licencia.estadoResolucion || 'pendiente';

  // Plazo de apelación — solo existe si la licencia fue rechazada Y ya se
  // conoce esa fecha. 15 días hábiles ante COMPIN (última instancia real:
  // 5 días hábiles ante SUSESO después, no modelado todavía — un nivel a
  // la vez, mismo criterio que el resto del archivo).
  const plazoApelacionCompin = estadoResolucion === 'rechazada' && fechaResolucion
    ? sumarDiasHabiles(fechaResolucion, PLAZO_APELACION_COMPIN_DIAS_HABILES)
    : null;
  const apelacionPresentadaEnPlazo = fechaApelacion && plazoApelacionCompin ? fechaApelacion <= plazoApelacionCompin : null;

  return {
    workerId: worker.id, licenciaId: licencia.id, tipoId: licencia.tipoId,
    fechaInicioReposo, fechaTermino, diasReposo, sector, circuito,
    fechaRecepcionEmpleador, plazoTrabajador, trabajadorEnPlazo,
    fechaEnvioCompin, plazoEmpleador, empleadorEnPlazo, empleadorAsumeSubsidio,
    aplicaCarencia, diasCarencia, diasPagadosSIL,
    estadoResolucion, fechaResolucion: fechaResolucion || null,
    plazoApelacionCompin, fechaApelacion: fechaApelacion || null, apelacionPresentadaEnPlazo,
  };
}

/* PUERTA ETIQUETADA — hacia Remuneraciones
   §25 del docx: la Licencia (documento) y la Ausencia (período sin
   disponibilidad) son cosas distintas — esto entrega la AUSENCIA derivada,
   en días calendario del período, para que Remuneraciones eventualmente
   la reste del mes completo que asume hoy. NO está conectado todavía —
   Remuneraciones sigue asumiendo mes completo para todos (gap conocido,
   documentado, no parchado a medias esta sesión). */
export function construirAusenciaParaRemuneraciones(licenciaCalculada) {
  return {
    workerId: licenciaCalculada.workerId,
    diasAusencia: licenciaCalculada.diasReposo,
    diasNoRemuneradosPorEmpleador: licenciaCalculada.diasReposo, // el empleador no paga sueldo durante licencia — paga el SIL, circuito aparte
    motivo: licenciaCalculada.tipoId,
  };
}

export function calcularKPIsLicencias(licencias) {
  const totalDias = licencias.reduce((s, l) => s + l.diasReposo, 0);
  const totalDiasCarencia = licencias.reduce((s, l) => s + l.diasCarencia, 0);
  const totalDiasPagadosSIL = licencias.reduce((s, l) => s + l.diasPagadosSIL, 0);
  const trabajadorFueraPlazo = licencias.filter((l) => l.trabajadorEnPlazo === false).length;
  const empleadorFueraPlazo = licencias.filter((l) => l.empleadorEnPlazo === false).length;
  const empleadorAsumeSubsidio = licencias.filter((l) => l.empleadorAsumeSubsidio).length;
  const porCircuitoMutual = licencias.filter((l) => l.circuito === 'mutual').length;
  const pendientes = licencias.filter((l) => l.estadoResolucion === 'pendiente').length;
  const rechazadas = licencias.filter((l) => l.estadoResolucion === 'rechazada').length;
  return {
    seccion: 'licencias_medicas', licencias: licencias.length,
    totalDias, totalDiasCarencia, totalDiasPagadosSIL,
    trabajadorFueraPlazo, empleadorFueraPlazo, empleadorAsumeSubsidio,
    porCircuitoMutual, pendientes, rechazadas,
  };
}

/* ═══════════════════════════════════════════════════════════════════════
   MOTOR DE ALERTAS — el hueco real: calcularLicencia() ya calcula el
   plazo, pero hasta acá todo el archivo era retrospectivo (mostraba si
   algo YA llegó tarde). Esto es lo que faltaba — cuántos días hábiles
   quedan HOY hasta el plazo empleador→COMPIN mientras siga sin enviarse,
   para poder avisar ANTES de que se venza, no auditar después.
   ═══════════════════════════════════════════════════════════════════════ */
function contarDiasHabilesEntre(fechaA, fechaB) {
  if (fechaB === fechaA) return 0;
  const signo = fechaB > fechaA ? 1 : -1;
  const [desde, hasta] = signo === 1 ? [fechaA, fechaB] : [fechaB, fechaA];
  let contados = 0, fecha = desde;
  while (fecha < hasta) {
    fecha = sumarDias(fecha, 1);
    if (esDiaHabil(fecha)) contados++;
  }
  return contados * signo;
}

/* PUERTA ETIQUETADA — Motor de Alertas
   Toma una licencia ya calculada + la fecha de hoy (parámetro explícito,
   no Date.now() interno, para que esto sea puro y probable con cualquier
   "hoy") y clasifica la urgencia del tramo empleador→COMPIN — el único
   tramo donde RRHH tiene control total sobre no atrasarse. Solo "aplica"
   si el trabajador YA entregó pero todavía NO se ha enviado a COMPIN —
   es exactamente la ventana de riesgo real. */
export function calcularUrgenciaEmpleador(licenciaCalculada, hoyISO) {
  if (!licenciaCalculada.fechaRecepcionEmpleador || licenciaCalculada.fechaEnvioCompin) {
    return { aplica: false, diasHabilesRestantes: null, nivel: null };
  }
  const diasHabilesRestantes = contarDiasHabilesEntre(hoyISO, licenciaCalculada.plazoEmpleador);
  const nivel = diasHabilesRestantes < 0 ? 'vencido' : diasHabilesRestantes <= 1 ? 'urgente' : diasHabilesRestantes <= 2 ? 'pronto' : 'ok';
  return { aplica: true, diasHabilesRestantes, nivel };
}

// Mismo patrón, para el OTRO plazo que también se puede perder: apelar un
// rechazo de COMPIN/Isapre dentro de 15 días hábiles. Antes solo aparecía
// como texto informativo en una tarjeta — no como algo que alertara.
export function calcularUrgenciaApelacion(licenciaCalculada, hoyISO) {
  if (!licenciaCalculada.plazoApelacionCompin || licenciaCalculada.fechaApelacion) {
    return { aplica: false, diasHabilesRestantes: null, nivel: null };
  }
  const diasHabilesRestantes = contarDiasHabilesEntre(hoyISO, licenciaCalculada.plazoApelacionCompin);
  const nivel = diasHabilesRestantes < 0 ? 'vencido' : diasHabilesRestantes <= 2 ? 'urgente' : diasHabilesRestantes <= 5 ? 'pronto' : 'ok';
  return { aplica: true, diasHabilesRestantes, nivel };
}

export function calcularAlertas(licencias, hoyISO) {
  return licencias
    .map((l) => ({ licencia: l, urgencia: calcularUrgenciaEmpleador(l, hoyISO), tipo: 'envio_compin' }))
    .filter((a) => a.urgencia.aplica)
    .sort((a, b) => a.urgencia.diasHabilesRestantes - b.urgencia.diasHabilesRestantes);
}

export function calcularAlertasApelacion(licencias, hoyISO) {
  return licencias
    .map((l) => ({ licencia: l, urgencia: calcularUrgenciaApelacion(l, hoyISO), tipo: 'apelacion' }))
    .filter((a) => a.urgencia.aplica)
    .sort((a, b) => a.urgencia.diasHabilesRestantes - b.urgencia.diasHabilesRestantes);
}

/* PUERTA ETIQUETADA — intake automático (IMED/Medipass)
   La DETECCIÓN de que una licencia existe (el correo/notificación
   electrónica llegando) es un punto de integración real — este archivo
   mock no escucha correos, igual que Facturación no emite DTE de verdad.
   Cuando exista la conexión real (webhook o polling contra IMED/
   Medipass, mencionados como la plataforma de cobro integrada en el
   archivo de Monetización), lo que llegaría tendría esta forma; y desde
   el momento en que llega, el Motor de Alertas de arriba ya puede
   contar sola — no hace falta que un humano note el correo para que el
   reloj empiece a correr. Antes de esa conexión real, el registro es
   manual: alguien en RRHH transcribe lo que llegó por correo, y ESE
   registro manual dispara lo mismo. */
export function construirIntakeDesdeNotificacionElectronica(notificacion) {
  return {
    tipoId: notificacion.tipoLicencia,
    fechaInicioReposo: notificacion.fechaInicioReposo,
    diasReposo: notificacion.diasReposo,
    fechaRecepcionEmpleador: notificacion.fechaNotificacion, // electrónica = la notificación misma cuenta como recepción
    fechaEnvioCompin: null,
    sector: notificacion.sector || 'privado',
    estadoResolucion: 'pendiente',
  };
}

/* ------------------------------ mock data -------------------------------- */
/* ═══════════════════════════════════════════════════════════════════════
   REGISTRO CANÓNICO — copiado 1:1 desde WorkforcePersonas.jsx. Antes este
   archivo generaba sus propios 14 trabajadores, sin relación con los de
   Remuneraciones/Honorarios/Turnos. Ahora comparte las mismas 30
   personas — acá se usan los 20 en relación de EMPLEADO.
   ═══════════════════════════════════════════════════════════════════════ */
const NOMBRES_CANONICO = ['María José', 'Pedro', 'Camila', 'Rodrigo', 'Fernanda', 'Ignacio', 'Valentina', 'Cristóbal', 'Antonia', 'Matías', 'Javiera', 'Sebastián', 'Catalina', 'Diego', 'Francisca', 'Tomás', 'Constanza', 'Felipe', 'Josefa', 'Nicolás'];
const APELLIDOS_CANONICO = ['González', 'Muñoz', 'Rojas', 'Díaz', 'Pérez', 'Soto', 'Contreras', 'Silva', 'Martínez', 'Sepúlveda', 'Morales', 'Rodríguez', 'López', 'Fuentes', 'Hernández', 'Torres'];
const CARGOS_LISTA_CANONICO = ['medico', 'enfermeria', 'tens', 'kinesiologo', 'matrona', 'administrativo', 'auxiliar'];
const ESPECIALIDADES_LISTA_CANONICO = ['medico_especialista', 'psicologia', 'kinesiologia', 'nutricion', 'auditoria_clinica'];
const EMPRESAS_HONORARIO_CANONICO = ['Auditoría Clínica del Sur SpA', 'Diagnóstico Externo Ltda.'];

// Antigüedad — mismo generador que WorkforcePersonas.jsx, copiado 1:1.
function fechaIngresoDesdeSeed(seed) {
  const diasAtras = 60 + (seed % 5000);
  const hoy = new Date();
  const fecha = new Date(hoy);
  fecha.setDate(fecha.getDate() - diasAtras);
  return fecha.toISOString().slice(0, 10);
}

function generarPersonasCanonico() {
  const personas = [];
  let seed = 100;
  // 20 personas — relación EMPLEADO. Últimas 3 son de un tenant AXON Core
  // (Workforce como tecnología, empleador real es el tenant, no AXON).
  for (let i = 0; i < 20; i++) {
    seed += 17;
    const esCore = i >= 17;
    personas.push({
      id: `per_${1000 + i}`, cut: makeCUT(1000 + i), rut: fakeRUT(seed),
      nombres: NOMBRES_CANONICO[seed % NOMBRES_CANONICO.length],
      apellidoPaterno: APELLIDOS_CANONICO[(seed * 2) % APELLIDOS_CANONICO.length],
      apellidoMaterno: APELLIDOS_CANONICO[(seed * 5) % APELLIDOS_CANONICO.length],
      tipoRelacion: 'empleado',
      axonLinea: esCore ? 'axon_core' : 'axon_health',
      tenantId: esCore ? 'tenant_hospital_regional_demo' : null,
      // sector (privado/publico) — ver WorkforcePersonas.jsx para la nota
      // completa. Ley 19.664/Estatuto Administrativo NO está implementada
      // todavía, este es solo el campo (puerta etiquetada).
      sector: esCore ? 'publico' : 'privado',
      cargoId: CARGOS_LISTA_CANONICO[seed % CARGOS_LISTA_CANONICO.length],
      fechaIngreso: fechaIngresoDesdeSeed(seed),
    });
  }
  // 10 personas — relación HONORARIO. Últimas 2 son empresa (doble vía ya
  // establecida por Contabilidad), el resto persona natural. Todos
  // AXON Core Lite — independientes, sin institución de por medio.
  for (let i = 0; i < 10; i++) {
    seed += 23;
    const esEmpresa = i >= 8;
    personas.push({
      id: `per_${2000 + i}`, cut: makeCUT(2000 + i), rut: fakeRUT(seed),
      nombres: esEmpresa ? null : NOMBRES_CANONICO[seed % NOMBRES_CANONICO.length],
      apellidoPaterno: esEmpresa ? null : APELLIDOS_CANONICO[(seed * 2) % APELLIDOS_CANONICO.length],
      apellidoMaterno: esEmpresa ? null : APELLIDOS_CANONICO[(seed * 5) % APELLIDOS_CANONICO.length],
      razonSocial: esEmpresa ? EMPRESAS_HONORARIO_CANONICO[i - 8] : null,
      tipoRelacion: 'honorario',
      tipoPersonaHonorario: esEmpresa ? 'empresa' : 'natural',
      axonLinea: 'axon_core_lite', tenantId: null,
      especialidadId: esEmpresa ? 'auditoria_clinica' : ESPECIALIDADES_LISTA_CANONICO[seed % (ESPECIALIDADES_LISTA_CANONICO.length - 1)],
    });
  }
  return personas;
}

// Licencias Médicas solo usa los EMPLEADOS del registro canónico —
// no necesita agregar campos propios encima, los usa tal cual.
function genTrabajadores() {
  return generarPersonasCanonico().filter((p) => p.tipoRelacion === 'empleado');
}
const nombreCompleto = (w) => `${w.nombres} ${w.apellidoPaterno} ${w.apellidoMaterno}`;

const HOY = (() => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; })(); // fecha LOCAL (toISOString daba la fecha UTC: de noche en Chile ya era mañana)
const tipos = Object.keys(TIPOS_LICENCIA);
const RESOLUCIONES = ['aprobada', 'aprobada', 'aprobada', 'pendiente', 'rechazada'];

function restarDiasHabiles(fechaISO, n) {
  let fecha = fechaISO, contados = 0;
  while (contados < n) {
    fecha = sumarDias(fecha, -1);
    if (esDiaHabil(fecha)) contados++;
  }
  return fecha;
}

function genLicencias(trabajadores) {
  const rows = [];
  let seed = 13;
  trabajadores.forEach((w, idx) => {
    const nLicencias = seed % 3 === 0 ? 2 : 1;
    for (let j = 0; j < nLicencias; j++) {
      seed += 29;
      const tipoId = tipos[seed % tipos.length];
      const diasReposo = tipoId === 'maternal' ? [126, 84][seed % 2] : 1 + (seed % 14); // maternal: 18 o 12 semanas aprox; resto 1-14 días
      const fechaInicioReposo = sumarDias(HOY, -(20 + (seed % 60)));
      const inicioConteo = fechaInicioReposo; // se cuenta desde el día siguiente; si el reposo parte en día inhábil, el primer día hábil que sigue es el día 1
      const sector = 'privado';
      const plazoTrabajador = sumarDiasHabiles(inicioConteo, PLAZO_TRABAJADOR_EMPLEADOR_DIAS_HABILES[sector]);
      const trabajadorATiempo = seed % 8 !== 0;
      const fechaRecepcionEmpleador = trabajadorATiempo ? plazoTrabajador : sumarDias(plazoTrabajador, 2);
      const plazoEmpleador = sumarDiasHabiles(fechaRecepcionEmpleador, PLAZO_EMPLEADOR_COMPIN_DIAS_HABILES);
      const empleadorATiempo = seed % 11 !== 0;
      const fechaEnvioCompin = empleadorATiempo ? plazoEmpleador : sumarDias(plazoEmpleador, 3);
      const estadoResolucion = RESOLUCIONES[seed % RESOLUCIONES.length];

      const licenciaRaw = {
        id: `lic_${w.id}_${j}`, tipoId, fechaInicioReposo, diasReposo,
        fechaRecepcionEmpleador, fechaEnvioCompin, sector, estadoResolucion,
      };
      rows.push({ ...calcularLicencia(w, licenciaRaw), worker: w, id: licenciaRaw.id });
    }
  });

  // 4 casos DELIBERADOS recién recibidos del trabajador, todavía SIN enviar
  // a COMPIN — sin esto la vista de Alertas quedaría vacía en el mock.
  // Cubren los 4 niveles de urgencia para que se vean todos al menos una vez.
  const casosAlerta = [
    { offsetDiasHabiles: 0, motivoDemo: 'recién llegada — margen completo' },
    { offsetDiasHabiles: 1, motivoDemo: 'un día hábil ya corrido' },
    { offsetDiasHabiles: 2, motivoDemo: 'queda poco margen' },
    { offsetDiasHabiles: 4, motivoDemo: 'ya venció el plazo empleador→COMPIN' },
  ];
  casosAlerta.forEach((caso, i) => {
    const w = trabajadores[i % trabajadores.length];
    const fechaRecepcionEmpleador = restarDiasHabiles(HOY, caso.offsetDiasHabiles);
    const fechaInicioReposo = sumarDias(fechaRecepcionEmpleador, -3);
    const licenciaRaw = {
      id: `lic_alerta_${i}`, tipoId: 'enfermedad_comun', fechaInicioReposo, diasReposo: 4 + i,
      fechaRecepcionEmpleador, fechaEnvioCompin: null, sector: 'privado', estadoResolucion: 'pendiente',
    };
    rows.push({ ...calcularLicencia(w, licenciaRaw), worker: w, id: licenciaRaw.id });
  });

  // 1 caso rechazado con plazo de apelación corriendo — sin fecha de
  // apelación registrada todavía, para que la alerta de apelación tenga
  // algo que mostrar en el mock.
  const wApelacion = trabajadores[trabajadores.length - 1];
  const fechaResolucionApelacion = restarDiasHabiles(HOY, 12); // quedan ~3 días hábiles de los 15
  const fechaRecepcionApelacion = sumarDias(fechaResolucionApelacion, -6);
  const licenciaApelacionRaw = {
    id: 'lic_apelacion_demo', tipoId: 'enfermedad_comun', fechaInicioReposo: sumarDias(fechaRecepcionApelacion, -3), diasReposo: 6,
    fechaRecepcionEmpleador: fechaRecepcionApelacion, fechaEnvioCompin: sumarDias(fechaRecepcionApelacion, 1),
    sector: 'privado', estadoResolucion: 'rechazada', fechaResolucion: fechaResolucionApelacion,
  };
  rows.push({ ...calcularLicencia(wApelacion, licenciaApelacionRaw), worker: wApelacion, id: licenciaApelacionRaw.id });
  return rows.sort((a, b) => (a.fechaInicioReposo < b.fechaInicioReposo ? 1 : -1));
}

/* ------------------------------- átomos ---------------------------------- */
const Badge = ({ color, bg, icon: Icon, children }) => (
  <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, padding: '3px 9px', borderRadius: 999, fontSize: 12, fontWeight: 600, color, background: bg, whiteSpace: 'nowrap' }}>
    {Icon && <Icon size={12} />}{children}
  </span>
);
const Btn = ({ variant = 'ghost', icon: Icon, children, onClick, style }) => {
  const base = { display: 'inline-flex', alignItems: 'center', gap: 7, padding: '9px 15px', borderRadius: C.rSm, fontSize: 13.5, fontWeight: 600, cursor: 'pointer', border: '1px solid transparent', fontFamily: C.font, transition: 'filter .12s ease' };
  const variants = {
    primary: { background: C.pri, color: '#fff' },
    outline: { background: '#fff', color: C.ink, border: `1px solid ${C.border}` },
    ghost: { background: 'transparent', color: C.sub },
  };
  return (
    <button type="button" onClick={onClick}
      onMouseEnter={(e) => (e.currentTarget.style.filter = 'brightness(0.96)')}
      onMouseLeave={(e) => (e.currentTarget.style.filter = 'none')}
      style={{ ...base, ...variants[variant], ...style }}>
      {Icon && <Icon size={15} />}{children}
    </button>
  );
};
const KPICard = ({ label, value, sub, icon: Icon, accent }) => (
  <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, padding: '16px 18px', boxShadow: C.shadow, flex: 1, minWidth: 0 }}>
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
      <span style={{ fontSize: 12.5, color: C.sub, fontWeight: 600 }}>{label}</span>
      <div style={{ width: 28, height: 28, borderRadius: 8, background: accent + '18', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <Icon size={14} style={{ color: accent }} />
      </div>
    </div>
    <div style={{ fontSize: 22, fontWeight: 700, color: C.ink, letterSpacing: -0.3 }}>{value}</div>
    {sub && <div style={{ fontSize: 12, color: C.mut, marginTop: 3 }}>{sub}</div>}
  </div>
);
const FieldLabel = ({ children }) => <label style={{ fontSize: 11.5, fontWeight: 600, color: C.sub, marginBottom: 5, display: 'block' }}>{children}</label>;
const inputStyle = { width: '100%', padding: '8px 10px', borderRadius: C.rSm, border: `1px solid ${C.border}`, fontSize: 13.5, fontFamily: C.font, color: C.ink, outline: 'none', boxSizing: 'border-box', background: '#fff' };

const ESTADOS_RESOLUCION = {
  aprobada: { label: 'Aprobada', color: C.pri, icon: CheckCircle2 },
  pendiente: { label: 'Pendiente', color: C.warn, icon: Clock },
  rechazada: { label: 'Rechazada', color: C.err, icon: XCircle },
};

const NIVELES_URGENCIA = {
  vencido: { label: 'Vencido', color: C.err, bg: C.errL },
  urgente: { label: 'Urgente', color: '#C2410C', bg: '#FFEDD5' },
  pronto: { label: 'Pronto', color: C.warn, bg: C.warnL },
  ok: { label: 'Con margen', color: C.pri, bg: C.priL },
};

/* ------------------------- detalle de licencia -------------------------- */
function DetailModal({ lic, onClose }) {
  if (!lic) return null;
  const w = lic.worker;
  const cargo = CARGOS[w.cargoId];
  const tipo = TIPOS_LICENCIA[lic.tipoId];
  const res = ESTADOS_RESOLUCION[lic.estadoResolucion];

  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(16,24,40,.45)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100, padding: 20 }} onClick={onClose}>
      <div style={{ background: '#fff', borderRadius: C.rLg, width: 540, maxWidth: '100%', maxHeight: '90vh', overflowY: 'auto', boxShadow: '0 20px 50px rgba(16,24,40,.25)' }} onClick={(e) => e.stopPropagation()}>
        <div style={{ padding: '18px 22px', borderBottom: `1px solid ${C.border}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
            <div style={{ width: 34, height: 34, borderRadius: 9, background: cargo.color + '18', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <cargo.icon size={16} style={{ color: cargo.color }} />
            </div>
            <div>
              <div style={{ fontSize: 15, fontWeight: 700, color: C.ink }}>{nombreCompleto(w)}</div>
              <div style={{ fontSize: 12, color: C.mut }}>{cargo.label} · {fmtDate(lic.fechaInicioReposo)}</div>
            </div>
          </div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: C.mut, padding: 4 }}><X size={18} /></button>
        </div>

        <div style={{ padding: 22, display: 'flex', flexDirection: 'column', gap: 16 }}>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            <Badge color={tipo.color} bg={tipo.color + '18'}>{tipo.label}</Badge>
            <Badge color={res.color} bg={res.color + '18'} icon={res.icon}>{res.label}</Badge>
            <Badge color={C.sub} bg={C.bg}>{lic.circuito === 'mutual' ? 'Circuito Mutual (Ley 16.744)' : 'Circuito Isapre/Fonasa'}</Badge>
          </div>

          <div style={{ background: C.bg, borderRadius: C.rSm, padding: 14 }}>
            <div style={{ fontSize: 11.5, fontWeight: 700, color: C.sub, textTransform: 'uppercase', marginBottom: 8 }}>Reposo</div>
            {[['Inicio', fmtDate(lic.fechaInicioReposo)], ['Término', fmtDate(lic.fechaTermino)], ['Días de reposo', lic.diasReposo]].map(([label, val]) => (
              <div key={label} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12.5, color: C.sub, marginBottom: 5 }}>
                <span>{label}</span><span style={{ color: C.ink, fontWeight: 600 }}>{val}</span>
              </div>
            ))}
          </div>

          <div style={{ display: 'flex', gap: 10 }}>
            <div style={{ flex: 1, background: lic.trabajadorEnPlazo === false ? C.errL : C.priL, borderRadius: C.rSm, padding: 12 }}>
              <div style={{ fontSize: 10, color: lic.trabajadorEnPlazo === false ? C.err : C.priD, fontWeight: 700 }}>TRABAJADOR → EMPLEADOR</div>
              <div style={{ fontSize: 12, color: C.ink, marginTop: 3 }}>Plazo: {fmtDate(lic.plazoTrabajador)}</div>
              <div style={{ fontSize: 11.5, color: C.sub }}>Recibida: {lic.fechaRecepcionEmpleador ? fmtDate(lic.fechaRecepcionEmpleador) : '—'}</div>
              <Badge color={lic.trabajadorEnPlazo === false ? C.err : C.pri} bg={(lic.trabajadorEnPlazo === false ? C.err : C.pri) + '18'}>{lic.trabajadorEnPlazo === false ? 'Fuera de plazo' : 'En plazo'}</Badge>
            </div>
            <div style={{ flex: 1, background: lic.empleadorEnPlazo === false ? C.errL : C.priL, borderRadius: C.rSm, padding: 12 }}>
              <div style={{ fontSize: 10, color: lic.empleadorEnPlazo === false ? C.err : C.priD, fontWeight: 700 }}>EMPLEADOR → COMPIN</div>
              <div style={{ fontSize: 12, color: C.ink, marginTop: 3 }}>Plazo: {lic.plazoEmpleador ? fmtDate(lic.plazoEmpleador) : '—'}</div>
              <div style={{ fontSize: 11.5, color: C.sub }}>Enviada: {lic.fechaEnvioCompin ? fmtDate(lic.fechaEnvioCompin) : '—'}</div>
              <Badge color={lic.empleadorEnPlazo === false ? C.err : C.pri} bg={(lic.empleadorEnPlazo === false ? C.err : C.pri) + '18'}>{lic.empleadorEnPlazo === false ? 'Fuera de plazo' : 'En plazo'}</Badge>
            </div>
          </div>

          {lic.empleadorAsumeSubsidio && (
            <div style={{ display: 'flex', gap: 8, alignItems: 'flex-start', background: C.errL, padding: '10px 12px', borderRadius: C.rSm, fontSize: 11.5, color: C.err }}>
              <AlertTriangle size={13} style={{ flexShrink: 0, marginTop: 1 }} />
              <span>El empleador se atrasó enviando la licencia a COMPIN/Isapre — por norma, debe asumir el pago del subsidio de su propio bolsillo. No es una multa aparte, es la consecuencia directa del incumplimiento del plazo.</span>
            </div>
          )}

          <div style={{ background: C.goldL, borderRadius: C.rSm, padding: 14 }}>
            <div style={{ fontSize: 11.5, fontWeight: 700, color: C.gold, textTransform: 'uppercase', marginBottom: 8 }}>Subsidio por Incapacidad Laboral (SIL)</div>
            {[['Días de carencia (sin pago)', lic.diasCarencia], ['Días pagados por SIL', lic.diasPagadosSIL]].map(([label, val]) => (
              <div key={label} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12.5, color: C.sub, marginBottom: 5 }}>
                <span>{label}</span><span style={{ color: C.ink, fontWeight: 600 }}>{val} días</span>
              </div>
            ))}
            <div style={{ fontSize: 10.5, color: C.mut, marginTop: 6 }}>
              {lic.aplicaCarencia ? `Licencia ≤${CARENCIA_UMBRAL_DIAS} días: aplica carencia de ${CARENCIA_DIAS} días (ni empleador ni SIL pagan esos días).` : !TIPOS_LICENCIA[lic.tipoId].aplicaCarencia ? 'Este tipo de licencia no tiene carencia: el subsidio se paga desde el primer día.' : `Licencia >${CARENCIA_UMBRAL_DIAS} días: sin carencia, se paga el total autorizado.`} El empleador no paga el sueldo habitual durante la licencia — paga el {lic.circuito === 'mutual' ? 'Mutual de Seguridad' : 'SIL vía Isapre/Fonasa (COMPIN)'}.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* --------------------------------- vista principal ------------------------------------ */
export default function WorkforceLicenciasMedicas({ addToast }) {
  const toast = addToast || ((msg) => console.log(msg));
  const [trabajadores] = useState(genTrabajadores);
  const [data, setData] = useState(() => genLicencias(trabajadores));
  const [filtros, setFiltros] = useState({ tipo: 'todos', estado: 'todos', cargo: 'todos', q: '' });
  const [selected, setSelected] = useState(null);
  const [page, setPage] = useState(1);
  const perPage = 8;

  // Acción real que responde a "cómo evitamos que se nos pase" — marca el
  // envío a COMPIN HOY y recalcula esa licencia con el motor real
  // (calcularLicencia), no solo cambia un campo suelto. Sin backend
  // todavía: vive en memoria de sesión, mismo límite honesto de siempre.
  const marcarEnviadoCompin = (licenciaId) => {
    setData((prev) => prev.map((l) => {
      if (l.id !== licenciaId) return l;
      const recalculada = calcularLicencia(l.worker, { ...l, fechaEnvioCompin: HOY });
      return { ...recalculada, worker: l.worker, id: l.id };
    }));
    toast('Marcado como enviado a COMPIN/Isapre hoy');
  };

  // Misma idea que marcarEnviadoCompin, para el otro plazo que también se
  // puede perder — registrar que la apelación a un rechazo YA se presentó.
  const marcarApelacionPresentada = (licenciaId) => {
    setData((prev) => prev.map((l) => {
      if (l.id !== licenciaId) return l;
      const recalculada = calcularLicencia(l.worker, { ...l, fechaApelacion: HOY });
      return { ...recalculada, worker: l.worker, id: l.id };
    }));
    toast('Apelación marcada como presentada hoy');
  };

  const alertasCompin = useMemo(() => calcularAlertas(data, HOY), [data]);
  const alertasApelacion = useMemo(() => calcularAlertasApelacion(data, HOY), [data]);
  const alertas = useMemo(
    () => [...alertasCompin, ...alertasApelacion].sort((a, b) => a.urgencia.diasHabilesRestantes - b.urgencia.diasHabilesRestantes),
    [alertasCompin, alertasApelacion]
  );

  const filtered = useMemo(() => data.filter((l) => {
    if (filtros.tipo !== 'todos' && l.tipoId !== filtros.tipo) return false;
    if (filtros.estado !== 'todos' && l.estadoResolucion !== filtros.estado) return false;
    if (filtros.cargo !== 'todos' && l.worker.cargoId !== filtros.cargo) return false;
    if (filtros.q) {
      const q = filtros.q.toLowerCase();
      if (!nombreCompleto(l.worker).toLowerCase().includes(q) && !l.worker.rut.includes(q) && !l.worker.cut.toLowerCase().includes(q)) return false;
    }
    return true;
  }), [data, filtros]);

  const kpi = useMemo(() => calcularKPIsLicencias(filtered), [filtered]);
  const totalPages = Math.max(1, Math.ceil(filtered.length / perPage));
  const pageRows = filtered.slice((page - 1) * perPage, page * perPage);
  const limpiarFiltros = () => { setFiltros({ tipo: 'todos', estado: 'todos', cargo: 'todos', q: '' }); setPage(1); };

  const exportarCSV = () => {
    const header = ['Trabajador', 'CUT', 'Tipo', 'Inicio', 'Días', 'Recibida Empleador', 'En Plazo Trabajador', 'Enviada COMPIN', 'En Plazo Empleador', 'Carencia', 'Días SIL', 'Estado'];
    const lines = filtered.map((l) => [nombreCompleto(l.worker), l.worker.cut, TIPOS_LICENCIA[l.tipoId].label, l.fechaInicioReposo, l.diasReposo, l.fechaRecepcionEmpleador || '', l.trabajadorEnPlazo, l.fechaEnvioCompin || '', l.empleadorEnPlazo, l.diasCarencia, l.diasPagadosSIL, l.estadoResolucion].join(';'));
    const blob = new Blob([header.join(';') + '\n' + lines.join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `licencias_medicas.csv`; a.click();
    URL.revokeObjectURL(url);
    toast('Archivo CSV descargado');
  };

  return (
    <div style={{ fontFamily: C.font, background: C.bg, minHeight: '100%', padding: 22 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 18, flexWrap: 'wrap', gap: 12 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
          <div style={{ width: 34, height: 34, borderRadius: 9, background: C.priL, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <FileHeart size={17} style={{ color: C.pri }} />
          </div>
          <div>
            <div style={{ fontSize: 18, fontWeight: 700, color: C.ink }}>Licencias Médicas</div>
            <div style={{ fontSize: 12.5, color: C.mut }}>Workforce · Recepción (Flujo 2) — Documento Maestro §23-25</div>
          </div>
        </div>
        <Btn variant="outline" icon={Download} onClick={exportarCSV}>Exportar CSV</Btn>
      </div>

      {/* ALERTAS — la vista que faltaba: no auditoría de lo que ya pasó,
          sino lo que necesita acción AHORA para no perder dos plazos
          reales: envío a COMPIN/Isapre, y apelación si ya rechazaron.
          Va primero, antes del resumen retrospectivo. */}
      <div style={{ marginBottom: 20 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
          <AlertTriangle size={15} style={{ color: C.warn }} />
          <span style={{ fontSize: 13, fontWeight: 700, color: C.ink }}>Alertas — plazos activos</span>
          <Badge color={alertas.length ? C.warn : C.mut} bg={alertas.length ? C.warnL : C.bg}>{alertas.length}</Badge>
        </div>
        {alertas.length === 0 ? (
          <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, padding: 16, fontSize: 12.5, color: C.mut }}>
            Nada pendiente de enviar a COMPIN/Isapre ni apelaciones por presentar en este momento.
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {alertas.map(({ licencia: l, urgencia, tipo }) => {
              const cargo = CARGOS[l.worker.cargoId];
              const niv = NIVELES_URGENCIA[urgencia.nivel];
              const texto = urgencia.diasHabilesRestantes < 0
                ? `Venció hace ${Math.abs(urgencia.diasHabilesRestantes)} día(s) hábil(es)`
                : urgencia.diasHabilesRestantes === 0 ? 'Vence HOY' : `Quedan ${urgencia.diasHabilesRestantes} día(s) hábil(es)`;
              const esApelacion = tipo === 'apelacion';
              return (
                <div key={`${tipo}_${l.id}`} style={{ background: niv.bg, border: `1px solid ${niv.color}30`, borderRadius: C.rSm, padding: '10px 14px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 10, flexWrap: 'wrap' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10, minWidth: 0 }}>
                    <cargo.icon size={15} style={{ color: cargo.color, flexShrink: 0 }} />
                    <div style={{ minWidth: 0 }}>
                      <div style={{ fontSize: 12.5, fontWeight: 600, color: C.ink }}>
                        {nombreCompleto(l.worker)} <span style={{ fontWeight: 400, color: C.sub }}>· {TIPOS_LICENCIA[l.tipoId].label}</span>
                        <span style={{ marginLeft: 6, fontSize: 9.5, fontWeight: 700, color: C.sub, background: '#fff', padding: '2px 6px', borderRadius: 999, border: `1px solid ${C.border}` }}>{esApelacion ? 'APELACIÓN' : 'ENVÍO COMPIN'}</span>
                      </div>
                      <div style={{ fontSize: 11, color: C.sub }}>
                        {esApelacion ? `Rechazada ${fmtDate(l.fechaResolucion)} · Plazo apelación ${fmtDate(l.plazoApelacionCompin)}` : `Recibida ${fmtDate(l.fechaRecepcionEmpleador)} · Plazo ${fmtDate(l.plazoEmpleador)}`}
                      </div>
                    </div>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexShrink: 0 }}>
                    <Badge color={niv.color} bg="#fff">{niv.label} · {texto}</Badge>
                    <Btn variant="primary" onClick={() => (esApelacion ? marcarApelacionPresentada(l.id) : marcarEnviadoCompin(l.id))} style={{ padding: '6px 12px', fontSize: 12, background: niv.color }}>{esApelacion ? 'Marcar apelación presentada' : 'Marcar enviado'}</Btn>
                  </div>
                </div>
              );
            })}
          </div>
        )}
        <div style={{ fontSize: 10.5, color: C.mut, marginTop: 8, display: 'flex', gap: 5 }}>
          <Info size={11} style={{ flexShrink: 0, marginTop: 1 }} />
          <span>Esta lista se arma sola en cuanto una licencia queda registrada con recepción del trabajador pero sin envío a COMPIN — la detección automática del correo/notificación (IMED/Medipass) es integración real, puerta etiquetada (ver `construirIntakeDesdeNotificacionElectronica`); mientras no exista, el registro es manual y dispara lo mismo.</span>
        </div>
      </div>

      <div style={{ fontSize: 11.5, fontWeight: 700, color: C.mut, textTransform: 'uppercase', letterSpacing: 0.4, marginBottom: 8 }}>Resumen</div>
      <div style={{ display: 'flex', gap: 14, marginBottom: 18, flexWrap: 'wrap' }}>
        <KPICard label="Licencias" value={kpi.licencias} sub={`${kpi.totalDias} días de reposo en total`} icon={FileHeart} accent={C.pri} />
        <KPICard label="Días pagados por SIL" value={kpi.totalDiasPagadosSIL} sub={`${kpi.totalDiasCarencia} días de carencia sin pago`} icon={Scale} accent={C.gold} />
        <KPICard label="Trabajador fuera de plazo" value={kpi.trabajadorFueraPlazo} sub="Riesgo de rechazo por extemporánea" icon={CalendarX} accent={C.err} />
        <KPICard label="Empleador fuera de plazo" value={kpi.empleadorFueraPlazo} sub={`${kpi.empleadorAsumeSubsidio} casos donde AXON asume el subsidio`} icon={AlertTriangle} accent={C.err} />
      </div>
      <div style={{ display: 'flex', gap: 14, marginBottom: 18, flexWrap: 'wrap' }}>
        <KPICard label="Circuito Mutual" value={kpi.porCircuitoMutual} sub="Accidentes/enfermedad profesional, Ley 16.744" icon={ShieldCheck} accent={C.teal} />
        <KPICard label="Pendientes de resolución" value={kpi.pendientes} sub="Esperando COMPIN/Isapre" icon={Hourglass} accent={C.warn} />
        <KPICard label="Rechazadas" value={kpi.rechazadas} sub={`Apelación: 15 días hábiles ante COMPIN, luego 5 ante SUSESO`} icon={XCircle} accent={C.err} />
      </div>

      <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, padding: 16, boxShadow: C.shadow, marginBottom: 14 }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10, alignItems: 'end' }}>
          <div>
            <FieldLabel>Tipo</FieldLabel>
            <select style={inputStyle} value={filtros.tipo} onChange={(e) => { setFiltros({ ...filtros, tipo: e.target.value }); setPage(1); }}>
              <option value="todos">Todos</option>
              {Object.entries(TIPOS_LICENCIA).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
            </select>
          </div>
          <div>
            <FieldLabel>Estado</FieldLabel>
            <select style={inputStyle} value={filtros.estado} onChange={(e) => { setFiltros({ ...filtros, estado: e.target.value }); setPage(1); }}>
              <option value="todos">Todos</option>
              {Object.entries(ESTADOS_RESOLUCION).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
            </select>
          </div>
          <div>
            <FieldLabel>Cargo</FieldLabel>
            <select style={inputStyle} value={filtros.cargo} onChange={(e) => { setFiltros({ ...filtros, cargo: e.target.value }); setPage(1); }}>
              <option value="todos">Todos</option>
              {Object.entries(CARGOS).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
            </select>
          </div>
          <div>
            <FieldLabel>Buscar</FieldLabel>
            <div style={{ position: 'relative' }}>
              <Search size={14} style={{ position: 'absolute', left: 9, top: 10, color: C.mut }} />
              <input style={{ ...inputStyle, paddingLeft: 28 }} placeholder="Nombre, RUT o CUT" value={filtros.q} onChange={(e) => { setFiltros({ ...filtros, q: e.target.value }); setPage(1); }} />
            </div>
          </div>
        </div>
        <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 12 }}>
          <button onClick={limpiarFiltros} style={{ display: 'flex', alignItems: 'center', gap: 5, background: 'none', border: 'none', cursor: 'pointer', color: C.sub, fontSize: 12.5, fontWeight: 600, padding: 0 }}>
            <RotateCcw size={13} /> Limpiar filtros
          </button>
        </div>
      </div>

      <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, boxShadow: C.shadow, overflow: 'hidden' }}>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
            <thead>
              <tr style={{ background: C.bg, textAlign: 'left' }}>
                {['Trabajador', 'Tipo', 'Inicio', 'Días', 'Plazo Trab.', 'Plazo Empl.', 'Estado', ''].map((h) => (
                  <th key={h} style={{ padding: '10px 14px', fontSize: 11.5, fontWeight: 700, color: C.sub, textTransform: 'uppercase', letterSpacing: 0.3, whiteSpace: 'nowrap' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {pageRows.map((l) => {
                const cargo = CARGOS[l.worker.cargoId];
                const tipo = TIPOS_LICENCIA[l.tipoId];
                const res = ESTADOS_RESOLUCION[l.estadoResolucion];
                return (
                  <tr key={l.id} style={{ borderTop: `1px solid ${C.border}`, cursor: 'pointer' }} onClick={() => setSelected(l)}
                    onMouseEnter={(e) => (e.currentTarget.style.background = C.bg)} onMouseLeave={(e) => (e.currentTarget.style.background = 'transparent')}>
                    <td style={{ padding: '11px 14px' }}>
                      <div style={{ fontWeight: 600, color: C.ink }}>{nombreCompleto(l.worker)}</div>
                      <div style={{ fontSize: 11, color: C.mut }}>{cargo.label}</div>
                    </td>
                    <td style={{ padding: '11px 14px' }}><Badge color={tipo.color} bg={tipo.color + '18'}>{tipo.label}</Badge></td>
                    <td style={{ padding: '11px 14px', color: C.sub, whiteSpace: 'nowrap' }}>{fmtDate(l.fechaInicioReposo)}</td>
                    <td style={{ padding: '11px 14px', color: C.ink, whiteSpace: 'nowrap' }}>{l.diasReposo}</td>
                    <td style={{ padding: '11px 14px' }}>{l.trabajadorEnPlazo === false ? <Badge color={C.err} bg={C.errL} icon={CalendarX}>Fuera</Badge> : <Badge color={C.pri} bg={C.priL} icon={CheckCircle2}>OK</Badge>}</td>
                    <td style={{ padding: '11px 14px' }}>{l.empleadorEnPlazo === false ? <Badge color={C.err} bg={C.errL} icon={CalendarX}>Fuera</Badge> : <Badge color={C.pri} bg={C.priL} icon={CheckCircle2}>OK</Badge>}</td>
                    <td style={{ padding: '11px 14px' }}><Badge color={res.color} bg={res.color + '18'} icon={res.icon}>{res.label}</Badge></td>
                    <td style={{ padding: '11px 14px' }}><Eye size={15} style={{ color: C.mut }} /></td>
                  </tr>
                );
              })}
              {pageRows.length === 0 && (
                <tr><td colSpan={8} style={{ padding: '40px 14px', textAlign: 'center', color: C.mut, fontSize: 13 }}>
                  No hay licencias que calcen con estos filtros. <button onClick={limpiarFiltros} style={{ color: C.info, background: 'none', border: 'none', cursor: 'pointer', fontSize: 13, textDecoration: 'underline', padding: 0 }}>Limpia los filtros</button>.
                </td></tr>
              )}
            </tbody>
          </table>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 16px', borderTop: `1px solid ${C.border}` }}>
          <span style={{ fontSize: 12, color: C.mut }}>{filtered.length} licencias · página {page} de {totalPages}</span>
          <div style={{ display: 'flex', gap: 6 }}>
            <Btn variant="outline" onClick={() => setPage(Math.max(1, page - 1))} style={{ padding: '6px 12px', opacity: page === 1 ? 0.4 : 1 }}>Anterior</Btn>
            <Btn variant="outline" onClick={() => setPage(Math.min(totalPages, page + 1))} style={{ padding: '6px 12px', opacity: page === totalPages ? 0.4 : 1 }}>Siguiente</Btn>
          </div>
        </div>
      </div>

      {selected && <DetailModal lic={selected} onClose={() => setSelected(null)} />}
    </div>
  );
}
