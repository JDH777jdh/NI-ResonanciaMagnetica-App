import React, { useState, useMemo } from 'react';
import {
  Receipt, Search, Download, X, Users, Building2, UserRound, Eye,
  RotateCcw, CheckCircle2, Clock, Ban, Info, Briefcase, TrendingUp,
  FileText, Send, Percent, Stethoscope, Brain, Activity, HeartPulse,
} from 'lucide-react';

/* =========================================================================
   AXON WORKFORCE — Honorarios
   Módulo de Recursos Humanos / Workforce · Sección: Honorarios
   Ver Documento Maestro de Arquitectura Workforce §31 (Honorarios) y §75
   (AXON Core Lite — "Financial/Honorarium Integration").

   SEGUNDA SECCIÓN DE WORKFORCE, después de Remuneraciones. Flujo distinto
   al de Empleados, a propósito — §31 es explícito: "No debe mezclarse con
   la nómina laboral." Professional → Service → Honorarium → Financial
   Event → Account Core (mismo diagrama del docx).

   NO DUPLICA lo que Contabilidad ya construyó y verificó en
   ContabilidadHonorariosMedicos.jsx / ContabilidadHonorariosExternos.jsx
   (retención BHE 15,25%, IVA Factura 19%, doble vía Persona Natural /
   Empresa) — esos archivos son quienes CONTABILIZAN y declaran. Este
   archivo es Workforce: registra la relación profesional + el servicio
   prestado, calcula el honorario, y EMITE el evento hacia Account Core.
   La tasa de retención se REUTILIZA tal cual la dejó Contabilidad
   verificada (Dossier Técnico, 2.3: "verificado 2026-08-28 contra
   comunicado oficial del SII — correcto para 2026"), no se vuelve a
   buscar acá para no correr el riesgo de que los dos módulos terminen
   con dos números distintos para el mismo parámetro legal.

   CUT: mismo formato provisional que Remuneraciones — un profesional en
   relación de honorario también tiene CUT (§11.2: "identificador interno
   de la relación de workforce", no exclusivo de empleados — §9 del docx
   muestra una misma persona con varias relaciones simultáneas).
   ========================================================================= */

/* DISEÑO — misma identidad violeta de Workforce que Remuneraciones (es la
   misma línea del ecosistema, no una sección nueva con color propio).
   Provisional, mismo criterio "Opción D" del Sistema de Diseño de Temas. */
const C = {
  bg: '#F6F5FB', card: '#FFFFFF', border: '#E3DEF5', borderD: '#CBC0E8',
  ink: '#241A3D', sub: '#5F5580', mut: '#948AB5',
  pri: '#6D28D9', priD: '#5518B0', priL: '#F1EAFC',
  info: '#2563EB', infoL: '#EEF3FF',
  warn: '#B45309', warnL: '#FEF3E2',
  err: '#C62828', errL: '#FDECEC',
  gold: '#B7791F', goldL: '#FBF0DD',
  teal: '#0E7490', tealL: '#E3F6FA',
  r: 10, rSm: 7, rLg: 14,
  shadow: '0 1px 3px rgba(16,24,40,.06), 0 1px 2px rgba(16,24,40,.04)',
  font: "'Inter', -apple-system, 'Segoe UI', Roboto, sans-serif",
};

/* ---------------------------- catálogos base ------------------------------ */
// §8/§9 del Documento Maestro: Independiente/Honorario/Contratista/Externo
// son relaciones DISTINTAS entre sí — acá modelamos específicamente
// "Honorario" (Professional → Service → Honorarium), no las otras.
const TIPOS_PERSONA = {
  natural: { label: 'Persona Natural', color: '#0E7490', doc: 'BHE' },
  empresa: { label: 'Empresa', color: '#5B6B85', doc: 'Factura' },
};

// Catálogo ILUSTRATIVO — igual que en Remuneraciones, el catálogo real de
// roles vive en roles.config.js de MAIN, no cruzado todavía con Workforce.
const ESPECIALIDADES = {
  medico_especialista: { label: 'Médico Especialista', icon: Stethoscope, color: '#4338CA' },
  psicologia: { label: 'Psicólogo/a', icon: Brain, color: '#BE185D' },
  kinesiologia: { label: 'Kinesiólogo/a', icon: Activity, color: '#B45309' },
  nutricion: { label: 'Nutricionista', icon: HeartPulse, color: '#2E7D32' },
  auditoria_clinica: { label: 'Auditoría Clínica Externa', icon: Briefcase, color: '#5B6B85' },
};

/* ═══════════════════════════════════════════════════════════════════════
   PARÁMETROS — reutilizados de Contabilidad (no re-verificados acá, a
   propósito, para no tener dos fuentes de verdad distintas del mismo
   número legal).
   ═══════════════════════════════════════════════════════════════════════ */
const TASA_RETENCION_HONORARIOS = 0.1525; // Persona Natural / BHE — ver ContabilidadHonorariosMedicos.jsx, verificado 2026-08-28 vs. comunicado SII dic-2025. Escala legislada hasta 17% en 2028 (Ley 21.133) — parámetro versionado, no constante fija.
const TASA_IVA = 0.19;                    // Empresa / Factura — estable, no requirió búsqueda dedicada esta sesión (a diferencia de la retención, que sí es un parámetro que sube por ley)

// AFC (Seguro de Cesantía) e Impuesto Único de Segunda Categoría NO
// aplican acá — "los trabajadores a honorarios no tienen este beneficio"
// (AFC Chile, verificado en la sesión de Remuneraciones). El profesional
// independiente sí tiene una obligación PROPIA de cotizar AFP/salud sobre
// sus honorarios anuales (Ley 21.133, vía su Operación Renta) — pero esa
// cotización no la retiene AXON al pagar, la resuelve el profesional en
// su declaración anual. No se modela acá para no inventar un mecanismo
// de retención que no corresponde a este flujo.

/* ---------------------------- identificadores ----------------------------- */
// Mismo formato PROVISIONAL de CUT que Remuneraciones — ver esa nota ahí,
// pendiente el formato oficial.
const PAIS = 'CL', REGION = '13', CLINICA = 'AXON';
function hashLiviano(str) {
  let h = 0;
  for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) >>> 0;
  return h.toString(16).toUpperCase().padStart(2, '0').slice(-2);
}
function makeCUT(seq) {
  const s = String(seq).padStart(8, '0');
  return `CUT-${PAIS}-${REGION}-${CLINICA}-${s}-${hashLiviano(`CUT-${PAIS}-${REGION}-${CLINICA}-${s}`)}`;
}
function calcDV(rutBody) {
  let suma = 0, mult = 2;
  for (let i = rutBody.length - 1; i >= 0; i--) {
    suma += parseInt(rutBody[i], 10) * mult;
    mult = mult === 7 ? 2 : mult + 1;
  }
  const resto = 11 - (suma % 11);
  if (resto === 11) return '0';
  if (resto === 10) return 'K';
  return String(resto);
}
function fakeRUT(seed) {
  const body = String(9000000 + (seed * 7919) % 8900000);
  const dv = calcDV(body);
  return body.slice(0, 2) + '.' + body.slice(2, 5) + '.' + body.slice(5) + '-' + dv;
}

const clp = (n) => '$' + Math.round(n).toLocaleString('es-CL');

/* ═══════════════════════════════════════════════════════════════════════
   MOTOR DE CÁLCULO — Honorarios
   Professional → Service → Honorarium (§31). Workforce calcula el
   honorario bruto y aplica la doble vía ya definida por Contabilidad;
   NO emite BHE ni Factura (eso es documento tributario real, propiedad
   de Facturación/Contabilidad) — solo calcula el monto y lo etiqueta.
   ═══════════════════════════════════════════════════════════════════════ */
export function calcularHonorario(professional, periodo, servicios) {
  const montoBruto = servicios.reduce((s, srv) => s + srv.cantidad * srv.tarifa, 0);

  if (professional.tipoPersona === 'natural') {
    const retencion = Math.round(montoBruto * TASA_RETENCION_HONORARIOS);
    const liquidoAPago = montoBruto - retencion;
    return {
      professionalId: professional.id, periodo, servicios, montoBruto,
      tipoPersona: 'natural', documento: 'BHE',
      retencion, tasaRetencion: TASA_RETENCION_HONORARIOS, iva: 0,
      liquidoAPago, totalAPagarAXON: liquidoAPago,
    };
  }
  // Empresa: Factura + IVA — AXON paga el bruto + IVA, sin retención;
  // la empresa declara su propio IVA/PPM (doble vía de Contabilidad).
  const iva = Math.round(montoBruto * TASA_IVA);
  const totalAPagarAXON = montoBruto + iva;
  return {
    professionalId: professional.id, periodo, servicios, montoBruto,
    tipoPersona: 'empresa', documento: 'Factura',
    retencion: 0, tasaRetencion: 0, iva, tasaIva: TASA_IVA,
    liquidoAPago: montoBruto, totalAPagarAXON,
  };
}

/* PUERTA ETIQUETADA — hacia Account Core / Contabilidad
   §31/§56 del Documento Maestro. HonorariumCalculated es el evento de
   dominio; el payload de abajo se arma en la MISMA forma que ya usan
   calcularKPIsHonorariosExternos/Médicos de Contabilidad (montoBruto,
   retención o IVA, según doble vía) para que no haya que traducir nada
   al conectar de verdad — reconstruido desde el Dossier Técnico, igual
   caveat que en Remuneraciones: falta calzar contra el archivo real. */
export function construirHonorariumCalculatedEvent(honorario) {
  return {
    tipo: 'HonorariumCalculated',
    dominioOrigen: 'workforce',
    professionalId: honorario.professionalId,
    periodo: honorario.periodo,
    tipoPersona: honorario.tipoPersona,
    documento: honorario.documento,
    montoBruto: honorario.montoBruto,
    retencion: honorario.retencion,
    iva: honorario.iva,
    totalAPagarAXON: honorario.totalAPagarAXON,
    emitidoEn: new Date().toISOString(),
  };
}

export function calcularKPIsHonorarios(honorarios) {
  const sum = (fn) => honorarios.reduce((s, h) => s + fn(h), 0);
  const totalBruto = sum((h) => h.montoBruto);
  const totalRetencion = sum((h) => h.retencion);
  const totalIva = sum((h) => h.iva);
  const totalPagadoAXON = sum((h) => h.totalAPagarAXON);
  const conBHE = honorarios.filter((h) => h.documento === 'BHE').length;
  const conFactura = honorarios.filter((h) => h.documento === 'Factura').length;
  return {
    seccion: 'honorarios', profesionales: honorarios.length,
    totalBruto, totalRetencion, totalIva, totalPagadoAXON,
    conBHE, conFactura,
  };
}

/* ------------------------------ mock data -------------------------------- */
/* ═══════════════════════════════════════════════════════════════════════
   REGISTRO CANÓNICO — copiado 1:1 desde WorkforcePersonas.jsx. Antes este
   archivo generaba sus propios 10 profesionales, sin relación con los
   trabajadores de Remuneraciones/Turnos/Licencias. Ahora comparte
   exactamente las mismas 30 personas del registro — acá se usan solo las
   10 en relación de HONORARIO.
   ═══════════════════════════════════════════════════════════════════════ */
const NOMBRES_CANONICO = ['María José', 'Pedro', 'Camila', 'Rodrigo', 'Fernanda', 'Ignacio', 'Valentina', 'Cristóbal', 'Antonia', 'Matías', 'Javiera', 'Sebastián', 'Catalina', 'Diego', 'Francisca', 'Tomás', 'Constanza', 'Felipe', 'Josefa', 'Nicolás'];
const APELLIDOS_CANONICO = ['González', 'Muñoz', 'Rojas', 'Díaz', 'Pérez', 'Soto', 'Contreras', 'Silva', 'Martínez', 'Sepúlveda', 'Morales', 'Rodríguez', 'López', 'Fuentes', 'Hernández', 'Torres'];
const CARGOS_LISTA_CANONICO = ['medico', 'enfermeria', 'tens', 'kinesiologo', 'matrona', 'administrativo', 'auxiliar'];
const ESPECIALIDADES_LISTA_CANONICO = ['medico_especialista', 'psicologia', 'kinesiologia', 'nutricion', 'auditoria_clinica'];
const EMPRESAS_HONORARIO_CANONICO = ['Auditoría Clínica del Sur SpA', 'Diagnóstico Externo Ltda.'];

// Antigüedad — mismo generador que WorkforcePersonas.jsx, copiado 1:1.
function fechaIngresoDesdeSeed(seed) {
  const diasAtras = 60 + (seed % 5000);
  const hoy = new Date();
  const fecha = new Date(hoy);
  fecha.setDate(fecha.getDate() - diasAtras);
  return fecha.toISOString().slice(0, 10);
}

function generarPersonasCanonico() {
  const personas = [];
  let seed = 100;
  // 20 personas — relación EMPLEADO. Últimas 3 son de un tenant AXON Core
  // (Workforce como tecnología, empleador real es el tenant, no AXON).
  for (let i = 0; i < 20; i++) {
    seed += 17;
    const esCore = i >= 17;
    personas.push({
      id: `per_${1000 + i}`, cut: makeCUT(1000 + i), rut: fakeRUT(seed),
      nombres: NOMBRES_CANONICO[seed % NOMBRES_CANONICO.length],
      apellidoPaterno: APELLIDOS_CANONICO[(seed * 2) % APELLIDOS_CANONICO.length],
      apellidoMaterno: APELLIDOS_CANONICO[(seed * 5) % APELLIDOS_CANONICO.length],
      tipoRelacion: 'empleado',
      axonLinea: esCore ? 'axon_core' : 'axon_health',
      tenantId: esCore ? 'tenant_hospital_regional_demo' : null,
      // sector (privado/publico) — ver WorkforcePersonas.jsx para la nota
      // completa. Ley 19.664/Estatuto Administrativo NO está implementada
      // todavía, este es solo el campo (puerta etiquetada).
      sector: esCore ? 'publico' : 'privado',
      cargoId: CARGOS_LISTA_CANONICO[seed % CARGOS_LISTA_CANONICO.length],
      fechaIngreso: fechaIngresoDesdeSeed(seed),
    });
  }
  // 10 personas — relación HONORARIO. Últimas 2 son empresa (doble vía ya
  // establecida por Contabilidad), el resto persona natural. Todos
  // AXON Core Lite — independientes, sin institución de por medio.
  for (let i = 0; i < 10; i++) {
    seed += 23;
    const esEmpresa = i >= 8;
    personas.push({
      id: `per_${2000 + i}`, cut: makeCUT(2000 + i), rut: fakeRUT(seed),
      nombres: esEmpresa ? null : NOMBRES_CANONICO[seed % NOMBRES_CANONICO.length],
      apellidoPaterno: esEmpresa ? null : APELLIDOS_CANONICO[(seed * 2) % APELLIDOS_CANONICO.length],
      apellidoMaterno: esEmpresa ? null : APELLIDOS_CANONICO[(seed * 5) % APELLIDOS_CANONICO.length],
      razonSocial: esEmpresa ? EMPRESAS_HONORARIO_CANONICO[i - 8] : null,
      tipoRelacion: 'honorario',
      tipoPersonaHonorario: esEmpresa ? 'empresa' : 'natural',
      axonLinea: 'axon_core_lite', tenantId: null,
      especialidadId: esEmpresa ? 'auditoria_clinica' : ESPECIALIDADES_LISTA_CANONICO[seed % (ESPECIALIDADES_LISTA_CANONICO.length - 1)],
    });
  }
  return personas;
}

// Honorarios solo usa las personas en relación HONORARIO del registro
// canónico (empleados viven en Remuneraciones/Turnos/Licencias) — y les
// agrega ENCIMA la tarifa, que el registro canónico no conoce.
function genProfesionales() {
  const tarifasBase = { medico_especialista: 55000, psicologia: 32000, kinesiologia: 28000, nutricion: 26000, auditoria_clinica: 450000 };
  return generarPersonasCanonico()
    .filter((p) => p.tipoRelacion === 'honorario')
    .map((p) => {
      const seed = Number(p.id.split('_')[1]);
      const tarifa = Math.round((tarifasBase[p.especialidadId] * (1 + ((seed % 20) - 10) / 100)) / 1000) * 1000;
      return { ...p, tipoPersona: p.tipoPersonaHonorario, nombre: p.razonSocial || `${p.nombres} ${p.apellidoPaterno} ${p.apellidoMaterno}`, tarifa };
    });
}
const nombreProfesional = (p) => p.nombre;


function mesesHastaHoy(cantidad) {
  const hoy = new Date();
  const out = [];
  for (let i = cantidad - 1; i >= 0; i--) {
    const d = new Date(hoy.getFullYear(), hoy.getMonth() - i, 1);
    out.push(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`);
  }
  return out;
}
const PERIODOS = mesesHastaHoy(4);

function genHonorarios(profesionales) {
  const rows = [];
  let seed = 9;
  profesionales.forEach((p) => {
    PERIODOS.forEach((periodo) => {
      seed += 17;
      const esAuditoria = p.especialidadId === 'auditoria_clinica';
      const cantidad = esAuditoria ? 1 : 4 + (seed % 10); // auditoría: 1 informe/mes; resto: sesiones/consultas
      const servicios = [{ tipo: esAuditoria ? 'Informe mensual' : 'Sesión/consulta', cantidad, tarifa: p.tarifa }];
      const honorario = calcularHonorario(p, periodo, servicios);
      const esUltimoPeriodo = periodo === PERIODOS[PERIODOS.length - 1];
      rows.push({ ...honorario, id: `hon_${p.id}_${periodo}`, professional: p, estado: esUltimoPeriodo ? 'calculado' : 'pagado' });
    });
  });
  return rows.sort((a, b) => (a.periodo < b.periodo ? 1 : -1));
}

/* ------------------------------- átomos ---------------------------------- */
const Badge = ({ color, bg, icon: Icon, children }) => (
  <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, padding: '3px 9px', borderRadius: 999, fontSize: 12, fontWeight: 600, color, background: bg, whiteSpace: 'nowrap' }}>
    {Icon && <Icon size={12} />}{children}
  </span>
);
const Btn = ({ variant = 'ghost', icon: Icon, children, onClick, style }) => {
  const base = { display: 'inline-flex', alignItems: 'center', gap: 7, padding: '9px 15px', borderRadius: C.rSm, fontSize: 13.5, fontWeight: 600, cursor: 'pointer', border: '1px solid transparent', fontFamily: C.font, transition: 'filter .12s ease' };
  const variants = {
    primary: { background: C.pri, color: '#fff' },
    outline: { background: '#fff', color: C.ink, border: `1px solid ${C.border}` },
    ghost: { background: 'transparent', color: C.sub },
  };
  return (
    <button type="button" onClick={onClick}
      onMouseEnter={(e) => (e.currentTarget.style.filter = 'brightness(0.96)')}
      onMouseLeave={(e) => (e.currentTarget.style.filter = 'none')}
      style={{ ...base, ...variants[variant], ...style }}>
      {Icon && <Icon size={15} />}{children}
    </button>
  );
};
const KPICard = ({ label, value, sub, icon: Icon, accent }) => (
  <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, padding: '16px 18px', boxShadow: C.shadow, flex: 1, minWidth: 0 }}>
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
      <span style={{ fontSize: 12.5, color: C.sub, fontWeight: 600 }}>{label}</span>
      <div style={{ width: 28, height: 28, borderRadius: 8, background: accent + '18', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <Icon size={14} style={{ color: accent }} />
      </div>
    </div>
    <div style={{ fontSize: 22, fontWeight: 700, color: C.ink, letterSpacing: -0.3 }}>{value}</div>
    {sub && <div style={{ fontSize: 12, color: C.mut, marginTop: 3 }}>{sub}</div>}
  </div>
);
const FieldLabel = ({ children }) => <label style={{ fontSize: 11.5, fontWeight: 600, color: C.sub, marginBottom: 5, display: 'block' }}>{children}</label>;
const inputStyle = { width: '100%', padding: '8px 10px', borderRadius: C.rSm, border: `1px solid ${C.border}`, fontSize: 13.5, fontFamily: C.font, color: C.ink, outline: 'none', boxSizing: 'border-box', background: '#fff' };

/* ------------------------- detalle de honorario -------------------------- */
function DetailModal({ hon, onClose }) {
  const [tab, setTab] = useState('honorario');
  if (!hon) return null;
  const p = hon.professional;
  const esp = ESPECIALIDADES[p.especialidadId];
  const tipo = TIPOS_PERSONA[p.tipoPersona];
  const evento = construirHonorariumCalculatedEvent(hon);

  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(16,24,40,.45)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100, padding: 20 }} onClick={onClose}>
      <div style={{ background: '#fff', borderRadius: C.rLg, width: 540, maxWidth: '100%', maxHeight: '90vh', overflowY: 'auto', boxShadow: '0 20px 50px rgba(16,24,40,.25)' }} onClick={(e) => e.stopPropagation()}>
        <div style={{ padding: '18px 22px', borderBottom: `1px solid ${C.border}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
            <div style={{ width: 34, height: 34, borderRadius: 9, background: (esp?.color || C.pri) + '18', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              {esp ? <esp.icon size={16} style={{ color: esp.color }} /> : <Building2 size={16} style={{ color: C.pri }} />}
            </div>
            <div>
              <div style={{ fontSize: 15, fontWeight: 700, color: C.ink }}>{nombreProfesional(p)}</div>
              <div style={{ fontSize: 12, color: C.mut }}>{esp?.label || 'Servicio externo'} · {hon.periodo}</div>
            </div>
          </div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: C.mut, padding: 4 }}><X size={18} /></button>
        </div>

        <div style={{ display: 'flex', borderBottom: `1px solid ${C.border}`, padding: '0 22px' }}>
          {[['honorario', 'Honorario'], ['evento', 'Evento hacia Account Core']].map(([id, label]) => (
            <button key={id} onClick={() => setTab(id)} style={{ padding: '10px 4px', marginRight: 20, fontSize: 13, fontWeight: 600, color: tab === id ? C.pri : C.mut, background: 'none', border: 'none', borderBottom: `2px solid ${tab === id ? C.pri : 'transparent'}`, cursor: 'pointer' }}>
              {label}
            </button>
          ))}
        </div>

        {tab === 'honorario' ? (
          <div style={{ padding: 22, display: 'flex', flexDirection: 'column', gap: 16 }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
              <div>
                <FieldLabel>CUT</FieldLabel>
                <div style={{ fontSize: 12, color: C.ink, fontFamily: 'monospace', background: C.bg, padding: '6px 10px', borderRadius: 6 }}>{p.cut}</div>
              </div>
              <div>
                <FieldLabel>Tipo</FieldLabel>
                <Badge color={tipo.color} bg={tipo.color + '18'}>{tipo.label} · {tipo.doc}</Badge>
              </div>
            </div>

            <div style={{ background: C.bg, borderRadius: C.rSm, padding: 14 }}>
              <div style={{ fontSize: 11.5, fontWeight: 700, color: C.sub, textTransform: 'uppercase', marginBottom: 8 }}>Servicios del período</div>
              {hon.servicios.map((s, i) => (
                <div key={i} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12.5, color: C.sub, marginBottom: 5 }}>
                  <span>{s.tipo} — {s.cantidad} × {clp(s.tarifa)}</span><span style={{ color: C.ink, fontWeight: 600 }}>{clp(s.cantidad * s.tarifa)}</span>
                </div>
              ))}
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13.5, paddingTop: 8, marginTop: 4, borderTop: `1px dashed ${C.borderD}` }}>
                <span style={{ fontWeight: 700, color: C.ink }}>Monto bruto</span><span style={{ fontWeight: 700, color: C.ink }}>{clp(hon.montoBruto)}</span>
              </div>
            </div>

            {hon.tipoPersona === 'natural' ? (
              <div style={{ background: C.errL, borderRadius: C.rSm, padding: 14 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12.5, color: C.sub, marginBottom: 5 }}>
                  <span>Retención BHE ({(hon.tasaRetencion * 100).toFixed(2)}%)</span><span style={{ color: C.ink, fontWeight: 600 }}>-{clp(hon.retencion)}</span>
                </div>
                <div style={{ fontSize: 11, color: C.mut, marginTop: 6 }}>Boleta de Honorarios Electrónica — el profesional declara este monto y la retención en su Operación Renta anual.</div>
              </div>
            ) : (
              <div style={{ background: C.infoL, borderRadius: C.rSm, padding: 14 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12.5, color: C.sub, marginBottom: 5 }}>
                  <span>IVA Factura ({(hon.tasaIva * 100).toFixed(0)}%)</span><span style={{ color: C.ink, fontWeight: 600 }}>+{clp(hon.iva)}</span>
                </div>
                <div style={{ fontSize: 11, color: C.mut, marginTop: 6 }}>Factura afecta — la empresa declara su propio IVA/PPM, sin retención de AXON.</div>
              </div>
            )}

            <div style={{ background: C.priL, borderRadius: C.rSm, padding: 14, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontSize: 14, fontWeight: 700, color: C.ink }}>{hon.tipoPersona === 'natural' ? 'Líquido a pago' : 'Total a pagar (con IVA)'}</span>
              <span style={{ fontSize: 19, fontWeight: 700, color: C.priD }}>{clp(hon.totalAPagarAXON)}</span>
            </div>
          </div>
        ) : (
          <div style={{ padding: 22, display: 'flex', flexDirection: 'column', gap: 14 }}>
            <div style={{ display: 'flex', gap: 8, alignItems: 'flex-start', background: C.infoL, padding: '10px 12px', borderRadius: C.rSm, fontSize: 12, color: '#1D4ED8' }}>
              <Send size={14} style={{ flexShrink: 0, marginTop: 1 }} />
              <span>Puerta etiquetada — lo que Workforce emitiría hacia Account Core. No emite BHE ni Factura real: eso sigue siendo de Facturación/Contabilidad, este evento solo entrega el monto ya calculado.</span>
            </div>
            <div>
              <FieldLabel>Evento de dominio — HonorariumCalculated</FieldLabel>
              <pre style={{ fontSize: 11, background: C.ink, color: '#D4CBEF', padding: 14, borderRadius: C.rSm, overflowX: 'auto', margin: 0 }}>{JSON.stringify(evento, null, 2)}</pre>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

/* --------------------------------- vista principal ------------------------------------ */
export default function WorkforceHonorarios({ addToast }) {
  const toast = addToast || ((msg) => console.log(msg));
  const [profesionales] = useState(genProfesionales);
  const [data] = useState(() => genHonorarios(profesionales));
  const [filtros, setFiltros] = useState({ periodo: 'todos', tipoPersona: 'todos', especialidad: 'todas', q: '' });
  const [selected, setSelected] = useState(null);
  const [page, setPage] = useState(1);
  const perPage = 8;

  const filtered = useMemo(() => data.filter((h) => {
    if (filtros.periodo !== 'todos' && h.periodo !== filtros.periodo) return false;
    if (filtros.tipoPersona !== 'todos' && h.tipoPersona !== filtros.tipoPersona) return false;
    if (filtros.especialidad !== 'todas' && h.professional.especialidadId !== filtros.especialidad) return false;
    if (filtros.q) {
      const q = filtros.q.toLowerCase();
      if (!nombreProfesional(h.professional).toLowerCase().includes(q) && !h.professional.rut.includes(q) && !h.professional.cut.toLowerCase().includes(q)) return false;
    }
    return true;
  }), [data, filtros]);

  const kpi = useMemo(() => calcularKPIsHonorarios(filtered), [filtered]);
  const totalPages = Math.max(1, Math.ceil(filtered.length / perPage));
  const pageRows = filtered.slice((page - 1) * perPage, page * perPage);

  const limpiarFiltros = () => { setFiltros({ periodo: 'todos', tipoPersona: 'todos', especialidad: 'todas', q: '' }); setPage(1); };

  const exportarCSV = () => {
    const header = ['Período', 'Profesional', 'CUT', 'RUT', 'Tipo', 'Documento', 'Monto Bruto', 'Retención', 'IVA', 'Total AXON', 'Estado'];
    const lines = filtered.map((h) => [h.periodo, nombreProfesional(h.professional), h.professional.cut, h.professional.rut, TIPOS_PERSONA[h.tipoPersona].label, h.documento, h.montoBruto, h.retencion, h.iva, h.totalAPagarAXON, h.estado].join(';'));
    const blob = new Blob([header.join(';') + '\n' + lines.join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `honorarios_${PERIODOS[0]}_a_${PERIODOS[PERIODOS.length - 1]}.csv`; a.click();
    URL.revokeObjectURL(url);
    toast('Archivo CSV descargado');
  };

  return (
    <div style={{ fontFamily: C.font, background: C.bg, minHeight: '100%', padding: 22 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 18, flexWrap: 'wrap', gap: 12 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
          <div style={{ width: 34, height: 34, borderRadius: 9, background: C.priL, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Receipt size={17} style={{ color: C.pri }} />
          </div>
          <div>
            <div style={{ fontSize: 18, fontWeight: 700, color: C.ink }}>Honorarios</div>
            <div style={{ fontSize: 12.5, color: C.mut }}>Workforce · Profesionales y empresas en relación de servicio — Documento Maestro §31</div>
          </div>
        </div>
        <Btn variant="outline" icon={Download} onClick={exportarCSV}>Exportar CSV</Btn>
      </div>

      <div style={{ fontSize: 11.5, fontWeight: 700, color: C.mut, textTransform: 'uppercase', letterSpacing: 0.4, marginBottom: 8 }}>Período filtrado</div>
      <div style={{ display: 'flex', gap: 14, marginBottom: 18, flexWrap: 'wrap' }}>
        <KPICard label="Profesionales/empresas" value={kpi.profesionales} sub={`${kpi.conBHE} con BHE · ${kpi.conFactura} con Factura`} icon={Users} accent={C.pri} />
        <KPICard label="Monto bruto total" value={clp(kpi.totalBruto)} sub="Antes de retención/IVA" icon={TrendingUp} accent={C.info} />
        <KPICard label="Retención BHE (15,25%)" value={clp(kpi.totalRetencion)} sub="Solo persona natural" icon={Ban} accent={C.err} />
        <KPICard label="IVA Factura (19%)" value={clp(kpi.totalIva)} sub="Solo empresa" icon={Percent} accent={C.gold} />
      </div>
      <div style={{ display: 'flex', gap: 14, marginBottom: 18, flexWrap: 'wrap' }}>
        <KPICard label="Total a pagar (AXON)" value={clp(kpi.totalPagadoAXON)} sub="Líquido BHE + Factura con IVA" icon={Receipt} accent={C.priD} />
      </div>

      <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, padding: 16, boxShadow: C.shadow, marginBottom: 14 }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 10, alignItems: 'end' }}>
          <div>
            <FieldLabel>Período</FieldLabel>
            <select style={inputStyle} value={filtros.periodo} onChange={(e) => { setFiltros({ ...filtros, periodo: e.target.value }); setPage(1); }}>
              <option value="todos">Todos</option>
              {PERIODOS.map((p) => <option key={p} value={p}>{p}</option>)}
            </select>
          </div>
          <div>
            <FieldLabel>Tipo</FieldLabel>
            <select style={inputStyle} value={filtros.tipoPersona} onChange={(e) => { setFiltros({ ...filtros, tipoPersona: e.target.value }); setPage(1); }}>
              <option value="todos">Todos</option>
              {Object.entries(TIPOS_PERSONA).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
            </select>
          </div>
          <div>
            <FieldLabel>Especialidad</FieldLabel>
            <select style={inputStyle} value={filtros.especialidad} onChange={(e) => { setFiltros({ ...filtros, especialidad: e.target.value }); setPage(1); }}>
              <option value="todas">Todas</option>
              {Object.entries(ESPECIALIDADES).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
            </select>
          </div>
          <div style={{ gridColumn: 'span 2' }}>
            <FieldLabel>Buscar</FieldLabel>
            <div style={{ position: 'relative' }}>
              <Search size={14} style={{ position: 'absolute', left: 9, top: 10, color: C.mut }} />
              <input style={{ ...inputStyle, paddingLeft: 28 }} placeholder="Nombre, RUT o CUT" value={filtros.q} onChange={(e) => { setFiltros({ ...filtros, q: e.target.value }); setPage(1); }} />
            </div>
          </div>
        </div>
        <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 12 }}>
          <button onClick={limpiarFiltros} style={{ display: 'flex', alignItems: 'center', gap: 5, background: 'none', border: 'none', cursor: 'pointer', color: C.sub, fontSize: 12.5, fontWeight: 600, padding: 0 }}>
            <RotateCcw size={13} /> Limpiar filtros
          </button>
        </div>
      </div>

      <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, boxShadow: C.shadow, overflow: 'hidden' }}>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
            <thead>
              <tr style={{ background: C.bg, textAlign: 'left' }}>
                {['Período', 'Profesional / Empresa', 'Tipo', 'Documento', 'Monto Bruto', 'Ret./IVA', 'Total AXON', 'Estado', ''].map((h) => (
                  <th key={h} style={{ padding: '10px 14px', fontSize: 11.5, fontWeight: 700, color: C.sub, textTransform: 'uppercase', letterSpacing: 0.3, whiteSpace: 'nowrap' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {pageRows.map((h) => {
                const tipo = TIPOS_PERSONA[h.tipoPersona];
                const esp = ESPECIALIDADES[h.professional.especialidadId];
                return (
                  <tr key={h.id} style={{ borderTop: `1px solid ${C.border}`, cursor: 'pointer' }} onClick={() => setSelected(h)}
                    onMouseEnter={(e) => (e.currentTarget.style.background = C.bg)} onMouseLeave={(e) => (e.currentTarget.style.background = 'transparent')}>
                    <td style={{ padding: '11px 14px', color: C.sub, whiteSpace: 'nowrap' }}>{h.periodo}</td>
                    <td style={{ padding: '11px 14px' }}>
                      <div style={{ fontWeight: 600, color: C.ink }}>{nombreProfesional(h.professional)}</div>
                      <div style={{ fontSize: 11, color: C.mut }}>{esp?.label}</div>
                    </td>
                    <td style={{ padding: '11px 14px' }}><Badge color={tipo.color} bg={tipo.color + '18'} icon={h.tipoPersona === 'empresa' ? Building2 : UserRound}>{tipo.label}</Badge></td>
                    <td style={{ padding: '11px 14px' }}><Badge color={C.sub} bg={C.bg} icon={FileText}>{h.documento}</Badge></td>
                    <td style={{ padding: '11px 14px', color: C.ink, whiteSpace: 'nowrap' }}>{clp(h.montoBruto)}</td>
                    <td style={{ padding: '11px 14px', whiteSpace: 'nowrap', color: h.tipoPersona === 'natural' ? C.err : C.info }}>{h.tipoPersona === 'natural' ? `-${clp(h.retencion)}` : `+${clp(h.iva)}`}</td>
                    <td style={{ padding: '11px 14px', fontWeight: 700, color: C.ink, whiteSpace: 'nowrap' }}>{clp(h.totalAPagarAXON)}</td>
                    <td style={{ padding: '11px 14px' }}>
                      <Badge color={h.estado === 'pagado' ? C.pri : C.warn} bg={(h.estado === 'pagado' ? C.pri : C.warn) + '18'} icon={h.estado === 'pagado' ? CheckCircle2 : Clock}>
                        {h.estado === 'pagado' ? 'Pagado' : 'Calculado'}
                      </Badge>
                    </td>
                    <td style={{ padding: '11px 14px' }}><Eye size={15} style={{ color: C.mut }} /></td>
                  </tr>
                );
              })}
              {pageRows.length === 0 && (
                <tr><td colSpan={9} style={{ padding: '40px 14px', textAlign: 'center', color: C.mut, fontSize: 13 }}>
                  No hay honorarios que calcen con estos filtros. <button onClick={limpiarFiltros} style={{ color: C.info, background: 'none', border: 'none', cursor: 'pointer', fontSize: 13, textDecoration: 'underline', padding: 0 }}>Limpia los filtros</button>.
                </td></tr>
              )}
            </tbody>
          </table>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 16px', borderTop: `1px solid ${C.border}` }}>
          <span style={{ fontSize: 12, color: C.mut }}>{filtered.length} registros · página {page} de {totalPages}</span>
          <div style={{ display: 'flex', gap: 6 }}>
            <Btn variant="outline" onClick={() => setPage(Math.max(1, page - 1))} style={{ padding: '6px 12px', opacity: page === 1 ? 0.4 : 1 }}>Anterior</Btn>
            <Btn variant="outline" onClick={() => setPage(Math.min(totalPages, page + 1))} style={{ padding: '6px 12px', opacity: page === totalPages ? 0.4 : 1 }}>Siguiente</Btn>
          </div>
        </div>
      </div>

      {selected && <DetailModal hon={selected} onClose={() => setSelected(null)} />}
    </div>
  );
}
