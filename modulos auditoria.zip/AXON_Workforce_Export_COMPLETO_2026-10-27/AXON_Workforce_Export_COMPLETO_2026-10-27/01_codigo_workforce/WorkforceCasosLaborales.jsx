import React, { useState, useMemo } from 'react';
import {
  Scale, Search, Download, X, Clock, CheckCircle2, XCircle, AlertTriangle, Info, Eye,
  RotateCcw, ShieldAlert, ShieldCheck, Lock, Send, History, Hourglass, Users, FileText,
} from 'lucide-react';

/* =========================================================================
   AXON WORKFORCE — Casos laborales (Ley Karin y convivencia)
   Documento Maestro §40-45 (gestión de casos, investigaciones, auditoría) y §72
   (nunca sobrescribir la historia). Flujo A-F, ramas, relojes y reserva según
   AXON_Workforce_Respuestas_para_MAIN_v2 §6 y v2.1 §6.

   NOVENA SECCIÓN. UI deliberadamente mínima: el foco es el motor.

   DECISIONES DE DISEÑO (para no volver a discutirlas):
   1. Los PLAZOS SON DATOS, no constantes: viven en un paquete de reglas versionado
      (PAQUETE_REGLAS_CL_BORRADOR) con evento de inicio, actor, tipo de día, fuente y
      vigencia. El paquete incluido es un BORRADOR NO VALIDADO por abogado: varias fuentes
      discrepan en el tipo de día, el número de días o el evento de inicio.
   2. Si una regla es ambigua, el motor calcula TODAS las variantes y alerta por la más
      temprana (vencimiento operativo), mostrando también la más tardía (máximo).
   3. Nada decide por una persona: el motor registra decisiones de personas con rol
      (clasificar, resguardar, seleccionar procedimiento, concluir, sancionar). No evalúa
      credibilidad, culpabilidad ni sanción.
   4. Reserva por caso: los roles son del caso (receptor, investigador, responsable,
      denunciante, denunciado), no del cargo. Quien no tiene rol en el caso no accede.
   5. Versionado inmutable (§72) con auditoría (§45): cada operación devuelve un caso nuevo
      y una entrada con quién, cuándo, valor anterior y nuevo, y motivo. Nada se muta.
   6. Relatos e informes se guardan como REFERENCIAS, nunca como contenido; los informes
      clínicos quedan fuera del expediente laboral.
   7. Fechas con aritmética UTC pura. Calendario de feriados cargado solo para 2026: fuera de
      ese año el motor avisa en vez de contar mal.
   8. CUT provisional (lo inyecta MAIN). Registro canónico copiado, no importado.
   9. Régimen jurídico por caso, no por sector del tenant: una institución pública puede tener personal bajo el Código del Trabajo y
      otro bajo estatuto. Se declara al clasificar; solo en tenants privados se asume Código del Trabajo, marcado como inferido.
  10. Una decisión NO es un cumplimiento: «decision_sin_medidas» y «medidas_correctivas_aplicadas» son hechos distintos y el plazo
      del art. 211-E solo se da por cumplido con medidas realmente aplicadas.
  11. Medidas de resguardo: propuesta → ordenada (quien decide) → implementada (con evidencia). Una propuesta no es una medida aplicada.
  12. Estados: TRANSICIONES es la única máquina de estados y la hace cumplir `aplicar`. Eventos con contrato común (envelope).
  13. Todo lo de acceso (rol del caso, tenant, relación vigente, bitácora) es DEMOSTRACIÓN del contrato: lo aplica el backend.
   ========================================================================= */

const C = {
  bg: '#F6F5FB', card: '#FFFFFF', border: '#E3DEF5', borderD: '#CBC0E8',
  ink: '#241A3D', sub: '#5F5580', mut: '#948AB5',
  pri: '#6D28D9', priD: '#5518B0', priL: '#F1EAFC',
  info: '#2563EB', infoL: '#EEF3FF', warn: '#B45309', warnL: '#FEF3E2',
  err: '#C62828', errL: '#FDECEC', teal: '#0E7490',
  r: 10, rSm: 7, rLg: 14, shadow: '0 1px 3px rgba(16,24,40,.06), 0 1px 2px rgba(16,24,40,.04)',
  font: "'Inter', -apple-system, 'Segoe UI', Roboto, sans-serif",
};

/* ═══════════════════════════════════════════════════════════════════════
   CATÁLOGOS
   ═══════════════════════════════════════════════════════════════════════ */
export const ETAPAS = {
  A: 'Recepción y clasificación', B: 'Protección y evaluación inicial', C: 'Selección de procedimiento',
  D: 'Investigación y antecedentes', E: 'Conclusión y plan correctivo', F: 'Seguimiento y cierre',
};
export const ESTADOS = {
  recibida: { label: 'Recibida', etapa: 'A' },
  por_complementar: { label: 'Denuncia por complementar', etapa: 'A' },
  clasificada: { label: 'Clasificada', etapa: 'A' },
  evaluacion_inicial: { label: 'Evaluación inicial y resguardo', etapa: 'B' },
  procedimiento_seleccionado: { label: 'Procedimiento seleccionado', etapa: 'C' },
  en_investigacion: { label: 'En investigación', etapa: 'D' },
  derivado_dt: { label: 'Derivado a la DT', etapa: 'D' },
  conclusiones: { label: 'Conclusiones y decisión', etapa: 'E' },
  en_seguimiento: { label: 'En seguimiento', etapa: 'F' },
  cerrado: { label: 'Cerrado', etapa: 'F' },
};
// Documentación de las transiciones posibles (la validación real está en cada operación).
export const TRANSICIONES = {
  recibida: ['por_complementar', 'clasificada'],
  por_complementar: ['recibida', 'clasificada'],
  clasificada: ['por_complementar', 'evaluacion_inicial', 'cerrado'],
  evaluacion_inicial: ['evaluacion_inicial', 'procedimiento_seleccionado', 'cerrado'],
  procedimiento_seleccionado: ['procedimiento_seleccionado', 'en_investigacion', 'derivado_dt', 'conclusiones', 'cerrado'],
  en_investigacion: ['conclusiones'],
  derivado_dt: ['conclusiones'],
  conclusiones: ['en_seguimiento', 'cerrado'],
  en_seguimiento: ['cerrado'],
  cerrado: [],
};
export const EVENTOS = [
  'denuncia_recibida', 'investigacion_iniciada', 'derivado_a_dt', 'investigacion_concluida',
  'informe_remitido_dt', 'conclusiones_dt_notificadas',
  'medidas_correctivas_aplicadas', // solo con medidas realmente aplicadas
  'decision_sin_medidas', // decisión fundamentada de NO aplicar medidas: otro hecho, con otro criterio de cumplimiento
];
export const REGIMENES = {
  codigo_trabajo: { label: 'Código del Trabajo' },
  estatutario_publico: { label: 'Régimen estatutario público (investigación sumaria o sumario)' },
  por_determinar: { label: 'Por determinar' },
};
export const PROCEDIMIENTOS = {
  investigacion_interna: { label: 'Investigación interna', legal: true },
  derivacion_dt: { label: 'Derivación a la Dirección del Trabajo', legal: true },
  procedimiento_administrativo: { label: 'Procedimiento administrativo (investigación sumaria o sumario)', legal: true, sinRelojesModelados: true },
  gestion_incidente_seguridad: { label: 'Gestión del incidente de seguridad', legal: false },
  intervencion_preventiva: { label: 'Intervención preventiva', legal: false },
  mediacion_opcional: { label: 'Mediación (opcional)', legal: false },
  evaluacion_condiciones_trabajo: { label: 'Evaluación de condiciones de trabajo', legal: false },
  activacion_seguridad_emergencias: { label: 'Activación de seguridad y emergencias', legal: false },
  derivacion_autoridades: { label: 'Derivación a las autoridades', legal: false },
};
export const RAMAS = {
  acoso_violencia_legal: { label: 'Acoso sexual, acoso laboral o violencia en el trabajo', legalPorDefecto: true, procedimientos: ['investigacion_interna', 'derivacion_dt'], imparcial: true },
  violencia_terceros: { label: 'Violencia de terceros (paciente, usuario, proveedor)', legalPorDefecto: false, procedimientos: ['gestion_incidente_seguridad'], procedimientosSiLegal: ['investigacion_interna', 'derivacion_dt'], imparcial: true },
  convivencia: { label: 'Conflicto interpersonal o de convivencia', legalPorDefecto: false, procedimientos: ['intervencion_preventiva', 'mediacion_opcional'], imparcial: false },
  riesgo_psicosocial: { label: 'Riesgo psicosocial u organizacional', legalPorDefecto: false, procedimientos: ['evaluacion_condiciones_trabajo'], imparcial: false },
  riesgo_fisico_delito: { label: 'Riesgo físico, amenaza grave o posible delito', legalPorDefecto: false, procedimientos: ['activacion_seguridad_emergencias', 'derivacion_autoridades'], inmediata: true, imparcial: false },
};
export const TIPOS_MEDIDA_RESGUARDO = {
  separacion_espacios_fisicos: { label: 'Separación de espacios físicos' },
  redistribucion_jornada: { label: 'Redistribución de la jornada' },
  atencion_psicologica_temprana: { label: 'Atención psicológica temprana' },
  otra_legalmente_procedente: { label: 'Otra medida legalmente procedente' },
};
export const TIPOS_ACTUACION = {
  citacion: { label: 'Citación' }, entrevista: { label: 'Entrevista' }, declaracion: { label: 'Declaración' },
  recepcion_prueba: { label: 'Recepción de prueba' }, analisis_entorno: { label: 'Análisis del entorno de trabajo' },
  notificacion: { label: 'Notificación' }, derivacion: { label: 'Derivación' }, otra: { label: 'Otra actuación' },
};
export const TIPOS_EVALUACION_PROFESIONAL = { psicologica: { label: 'Evaluación psicológica' }, medica: { label: 'Evaluación médica' } };
// ILUSTRATIVOS: cada tenant y su abogado definen los resultados y las medidas válidas (reglamento interno).
export const RESULTADOS_ILUSTRATIVOS = {
  hechos_acreditados: { label: 'Hechos acreditados' }, hechos_no_acreditados: { label: 'Hechos no acreditados' },
  antecedentes_insuficientes: { label: 'Antecedentes insuficientes' }, acuerdo_o_plan_de_accion: { label: 'Acuerdo o plan de acción (sin investigación)' },
};
export const TIPOS_MEDIDA_CORRECTIVA = {
  amonestacion_verbal: { label: 'Amonestación verbal' }, amonestacion_escrita: { label: 'Amonestación escrita' }, multa: { label: 'Multa (según reglamento interno)' },
  capacitacion: { label: 'Capacitación' }, cambio_unidad_o_jornada: { label: 'Cambio de unidad o jornada' },
  reorganizacion_trabajo: { label: 'Reorganización del trabajo' }, apoyo_psicosocial: { label: 'Apoyo psicosocial' },
  terminacion_contrato: { label: 'Término de contrato' }, otra: { label: 'Otra medida' },
};
export const MOTIVOS_CIERRE = {
  medidas_aplicadas: { label: 'Medidas aplicadas' }, sin_medidas_fundamentado: { label: 'Sin medidas, fundamentado' },
  derivado_a_autoridad: { label: 'Derivado a la autoridad competente' }, acuerdo_cumplido: { label: 'Acuerdo cumplido' }, otro: { label: 'Otro motivo fundamentado' },
};
export const RIESGOS = ['bajo', 'medio', 'alto', 'inmediato'];
export const TIPOS_DENUNCIANTE = ['trabajador', 'tercero', 'no_individualizado'];
export const TIPOS_DENUNCIADO = ['trabajador', 'tercero', 'desconocido'];
export const RELACIONES_DENUNCIADO = ['trabajador', 'art4_inc1', 'tercero', 'desconocido'];

/* ═══════════════════════════════════════════════════════════════════════
   FECHAS — aritmética UTC pura; el resultado no depende de la zona horaria
   ═══════════════════════════════════════════════════════════════════════ */
const pad2 = (n) => String(n).padStart(2, '0');
const aUTC = (iso) => { const [y, m, d] = iso.split('-').map(Number); return Date.UTC(y, m - 1, d); };
const deUTC = (ms) => { const dt = new Date(ms); return `${dt.getUTCFullYear()}-${pad2(dt.getUTCMonth() + 1)}-${pad2(dt.getUTCDate())}`; };
export const diferenciaDias = (a, b) => Math.round((aUTC(b) - aUTC(a)) / 86400000);
export const sumarDias = (iso, n) => deUTC(aUTC(iso) + n * 86400000);
const diaSemana = (iso) => new Date(aUTC(iso)).getUTCDay(); // 0 = domingo
const fechaValida = (f) => typeof f === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(f) && deUTC(aUTC(f)) === f;

// Misma lista de feriados 2026 ya verificada en Licencias Médicas (una sola fuente por parámetro legal).
export const FERIADOS_CHILE_2026 = {
  '2026-01-01': 'Año Nuevo', '2026-04-03': 'Viernes Santo', '2026-04-04': 'Sábado Santo',
  '2026-05-01': 'Día Nacional del Trabajo', '2026-05-21': 'Glorias Navales',
  '2026-06-07': 'Asalto y Toma del Morro de Arica (regional)', '2026-06-29': 'San Pedro y San Pablo',
  '2026-07-16': 'Virgen del Carmen', '2026-08-15': 'Asunción de la Virgen',
  '2026-08-20': "Natalicio de O'Higgins (regional)", '2026-09-18': 'Fiestas Patrias',
  '2026-09-19': 'Glorias del Ejército', '2026-10-12': 'Encuentro de Dos Mundos',
  '2026-10-31': 'Iglesias Evangélicas y Protestantes', '2026-11-01': 'Todos los Santos',
  '2026-12-08': 'Inmaculada Concepción', '2026-12-25': 'Navidad',
};
export const CALENDARIO_CL = { feriados: FERIADOS_CHILE_2026, anios: [2026] };

// «habil_judicial»: SUPUESTO sin validar (todos los días menos domingos y feriados). Lo valida el abogado.
export const TIPOS_DIA = {
  corrido: { label: 'corridos' },
  habil: { label: 'hábiles (lun-vie, sin feriados)' },
  habil_judicial: { label: 'hábiles judiciales (supuesto: todos menos domingos y feriados)' },
};
export function esDiaDeConteo(iso, tipoDia, cal = CALENDARIO_CL) {
  if (tipoDia === 'corrido') return true;
  if (cal.feriados[iso]) return false;
  const dow = diaSemana(iso);
  if (tipoDia === 'habil') return dow !== 0 && dow !== 6;
  if (tipoDia === 'habil_judicial') return dow !== 0;
  throw new Error(`tipoDia desconocido: ${tipoDia}`);
}
function avisosCalendario(desde, hasta, cal) {
  const out = [];
  for (let y = Number(desde.slice(0, 4)); y <= Number(hasta.slice(0, 4)); y++) if (!cal.anios.includes(y)) out.push(`feriados_no_cargados_${y}`);
  return out;
}
// Cuenta desde el día SIGUIENTE a `iso` (el día de inicio no cuenta). Devuelve fecha y advertencias.
export function sumarDiasTipo(iso, n, tipoDia, cal = CALENDARIO_CL, prorrogaSiInhabil = false) {
  let f = iso, c = 0;
  while (c < n) { f = sumarDias(f, 1); if (esDiaDeConteo(f, tipoDia, cal)) c++; }
  if (prorrogaSiInhabil) while (!esDiaDeConteo(f, 'habil', cal)) f = sumarDias(f, 1);
  const advertencias = (tipoDia !== 'corrido' || prorrogaSiInhabil) ? avisosCalendario(iso, f, cal) : [];
  return { fecha: f, advertencias };
}
// Días de conteo entre dos fechas: positivo si `hasta` es posterior; 0 si coinciden.
export function contarDiasTipo(desde, hasta, tipoDia, cal = CALENDARIO_CL) {
  if (hasta === desde) return 0;
  const signo = hasta > desde ? 1 : -1;
  const [a, b] = signo === 1 ? [desde, hasta] : [hasta, desde];
  let c = 0, f = a;
  while (f < b) { f = sumarDias(f, 1); if (esDiaDeConteo(f, tipoDia, cal)) c++; }
  return c * signo;
}

/* ═══════════════════════════════════════════════════════════════════════
   PAQUETE DE REGLAS DE PLAZO — BORRADOR NO VALIDADO (ver decisión 1 y 2)
   Cada regla: evento(s) de inicio, plazo(s), tipo(s) de día candidatos, evento(s) que la
   cumplen, fuente y estado de validación. Con varias variantes el motor alerta por la más
   temprana. Los números reflejan lo que dicen las fuentes consultadas el 2026-10-14, sin
   resolver sus discrepancias: NO copiar a producción sin validación jurídica.
   ═══════════════════════════════════════════════════════════════════════ */
const R = (o) => ({ validada: false, informativa: false, prorrogaSiInhabil: false, canal: null, aplicaSi: {}, cumpleCon: [], resuelveSinCumplir: [], umbrales: { urgente: 1, pronto: 2 }, version: 1, vigenteDesde: '2024-08-01', vigenteHasta: null, revisadoEn: '2026-10-14', ...o });
export const PAQUETE_REGLAS_CL_BORRADOR = {
  id: 'CL-KARIN-BORRADOR', jurisdiccion: 'CL', version: 1, revisadoEn: '2026-10-14', validadoPorAbogado: false,
  aviso: 'Borrador de trabajo con plazos de fuentes oficiales y no oficiales. NO validado jurídicamente: no usar en producción.',
  reglas: [
    R({ id: 'K0_RESGUARDO_DT', nombre: 'La DT instruye medidas de resguardo (denuncia presentada ante la DT)', actor: 'dt', informativa: true, canal: ['dt'], inicios: ['denuncia_recibida'], plazos: [2], tiposDia: ['habil'], nivelFuente: 'secundaria', fuente: 'Guía IST: la DT instruye medidas de resguardo en 2 días hábiles.' }),
    R({ id: 'K1_DECISION_EMPLEADOR', nombre: 'Decidir: investigar internamente o derivar a la DT', actor: 'empleador', canal: ['empleador'], aplicaSi: { legalOSinClasificar: true }, inicios: ['denuncia_recibida'], plazos: [3], tiposDia: ['corrido', 'habil'], cumpleCon: ['investigacion_iniciada', 'derivado_a_dt'], nivelFuente: 'oficial_parcial', fuente: 'Folleto de la DT: «dentro de tres días», sin calificar. Un diagrama no oficial dice 3 días corridos.' }),
    R({ id: 'K2_INVESTIGACION_INTERNA', nombre: 'Concluir la investigación interna', actor: 'empleador', canal: ['empleador'], aplicaSi: { procedimientoLegal: true, procedimiento: ['investigacion_interna'] }, inicios: ['denuncia_recibida', 'investigacion_iniciada'], plazos: [30], tiposDia: ['corrido', 'habil'], cumpleCon: ['investigacion_concluida'], umbrales: { urgente: 3, pronto: 7 }, nivelFuente: 'oficial_parcial', fuente: 'Folleto de la DT: «30 días». Diagrama no oficial: corridos desde la denuncia. El inicio del cómputo (denuncia o inicio de la investigación) no está confirmado.' }),
    R({ id: 'K3_REMISION_INFORME_DT', nombre: 'Remitir el informe de la investigación a la DT', actor: 'empleador', aplicaSi: { procedimientoLegal: true, procedimiento: ['investigacion_interna'] }, inicios: ['investigacion_concluida'], plazos: [2, 5], tiposDia: ['corrido', 'habil'], cumpleCon: ['informe_remitido_dt'], nivelFuente: 'conflicto', fuente: 'Nota de prensa y diagrama no oficial: 2 días. Sentencia citada en pjud.cl: 5 días.' }),
    R({ id: 'K4_MEDIDAS_EMPLEADOR', nombre: 'Disponer y aplicar las medidas o sanciones', actor: 'empleador', aplicaSi: { procedimientoLegal: true }, inicios: ['conclusiones_dt_notificadas'], plazos: [15], tiposDia: ['habil_judicial', 'corrido'], cumpleCon: ['medidas_correctivas_aplicadas'], resuelveSinCumplir: ['decision_sin_medidas'], umbrales: { urgente: 3, pronto: 5 }, nivelFuente: 'oficial_parcial', fuente: 'Art. 211-E CT: «quince días contados desde su recepción». La DT (folleto y dictamen citado por la prensa): 15 días hábiles judiciales desde la notificación de la Inspección. Otras fuentes dicen corridos.' }),
    R({ id: 'K5_PRONUNCIAMIENTO_DT', nombre: 'La DT se pronuncia sobre el informe', actor: 'dt', informativa: true, aplicaSi: { procedimientoLegal: true, procedimiento: ['investigacion_interna'] }, inicios: ['informe_remitido_dt'], plazos: [30], tiposDia: ['habil'], cumpleCon: ['conclusiones_dt_notificadas'], nivelFuente: 'secundaria', fuente: 'Diagrama no oficial: 30 días hábiles. Si la DT no se pronuncia, rigen las conclusiones del informe del empleador (varias fuentes).' }),
  ],
};
export function validarPaqueteReglas(pack) {
  const errores = [], ids = new Set();
  for (const r of pack.reglas) {
    if (!r.id || ids.has(r.id)) errores.push(`id duplicado o vacío: ${r.id}`);
    ids.add(r.id);
    if (!r.inicios?.length || r.inicios.some((e) => !EVENTOS.includes(e))) errores.push(`${r.id}: eventos de inicio inválidos`);
    if ((r.cumpleCon || []).some((e) => !EVENTOS.includes(e))) errores.push(`${r.id}: eventos de cumplimiento inválidos`);
    if ((r.resuelveSinCumplir || []).some((e) => !EVENTOS.includes(e))) errores.push(`${r.id}: eventos de resolución sin cumplimiento inválidos`);
    if (!r.plazos?.length || r.plazos.some((n) => !Number.isInteger(n) || n < 1)) errores.push(`${r.id}: plazos inválidos`);
    if (!r.tiposDia?.length || r.tiposDia.some((t) => !TIPOS_DIA[t])) errores.push(`${r.id}: tipos de día inválidos`);
    if (!['empleador', 'dt'].includes(r.actor)) errores.push(`${r.id}: actor inválido`);
  }
  return {
    valido: errores.length === 0, errores,
    sinValidar: pack.reglas.filter((r) => !r.validada).map((r) => r.id),
    ambiguas: pack.reglas.filter((r) => r.inicios.length * r.plazos.length * r.tiposDia.length > 1).map((r) => r.id),
    listoParaProduccion: errores.length === 0 && pack.validadoPorAbogado === true && pack.reglas.every((r) => r.validada),
  };
}

/* ═══════════════════════════════════════════════════════════════════════
   ACCESO — reserva por caso (decisión 4)
   ═══════════════════════════════════════════════════════════════════════ */
export const PERMISOS_POR_ROL = {
  receptor: { registrar: true, investigar: false, decidir: false, leer_expediente: true, leer_vista_parte: true },
  investigador: { registrar: false, investigar: true, decidir: false, leer_expediente: true, leer_vista_parte: true },
  responsable: { registrar: true, investigar: false, decidir: true, leer_expediente: true, leer_vista_parte: true },
  denunciante: { registrar: false, investigar: false, decidir: false, leer_expediente: false, leer_vista_parte: true },
  denunciado: { registrar: false, investigar: false, decidir: false, leer_expediente: false, leer_vista_parte: true },
};
export function rolesEnCaso(caso, personaId) {
  if (!personaId) return [];
  const r = [];
  if (caso.asignaciones.receptores.includes(personaId)) r.push('receptor');
  if (caso.asignaciones.investigadorId === personaId) r.push('investigador');
  if (caso.asignaciones.responsableId === personaId) r.push('responsable');
  if (caso.denunciante.ref === personaId) r.push('denunciante');
  if (caso.denunciado.ref === personaId) r.push('denunciado');
  return r;
}
export function evaluarAcceso(caso, actor, permiso) {
  const pid = actor?.personaId;
  const deny = (motivo, roles = []) => ({ permitido: false, motivo, roles });
  if (!pid) return deny('Actor no identificado');
  // Contexto institucional y relación vigente. DEMOSTRACIÓN: en producción los resuelve el backend (MAIN), nunca el cliente.
  if (caso.tenantId && actor.tenantId !== caso.tenantId) return deny('Aislamiento por tenant: el actor no pertenece al tenant del caso');
  if (actor.relacionVigente !== true) return deny('Sin relación vigente con el tenant: el acceso se evalúa con la relación activa, no con el historial');
  if (caso.conflictos.some((c) => c.personaId === pid)) return deny('Persona con conflicto de interés declarado en este caso');
  const roles = rolesEnCaso(caso, pid);
  if (!roles.length) return deny('Sin rol asignado en el caso: expediente reservado', roles);
  const ok = roles.some((r) => PERMISOS_POR_ROL[r]?.[permiso]);
  return { permitido: ok, motivo: ok ? null : `El rol (${roles.join(', ')}) no permite «${permiso}»`, roles };
}
function exigir(caso, actor, permisos) {
  const ev = permisos.map((p) => evaluarAcceso(caso, actor, p));
  if (ev.some((x) => x.permitido)) return null;
  return { error: `Sin permiso: ${ev[0].motivo}`, sinPermiso: true };
}
export function proyectarCaso(caso, actor) {
  const completo = evaluarAcceso(caso, actor, 'leer_expediente');
  if (completo.permitido) return { nivel: 'completo', caso };
  const parte = evaluarAcceso(caso, actor, 'leer_vista_parte');
  if (parte.permitido) {
    const ref = actor.personaId;
    return {
      nivel: 'parte', roles: parte.roles,
      vista: {
        id: caso.id, estado: caso.estado, etapa: ESTADOS[caso.estado].etapa, ramaId: caso.ramaId, procedimiento: caso.procedimiento,
        recibidaEn: caso.eventos.denuncia_recibida,
        actuacionesPropias: caso.actuaciones.filter((a) => a.participantes.includes(ref)).map((a) => ({ id: a.id, tipo: a.tipo, fecha: a.fecha })),
        medidasQueLeAplican: caso.medidasResguardo.filter((m) => m.destinatarioId === ref && ['ordenada', 'implementada'].includes(m.estado)).map((m) => ({ id: m.id, tipo: m.tipo, estado: m.estado, ordenadaEn: m.ordenadaEn, implementadaEn: m.implementadaEn })),
        conclusiones: caso.conclusiones ? { fecha: caso.conclusiones.fecha, resultado: caso.conclusiones.resultado } : null,
        cierre: caso.cierre ? { en: caso.cierre.en, motivoCierre: caso.cierre.motivoCierre } : null,
      },
    };
  }
  return { nivel: null, motivo: completo.motivo, roles: completo.roles };
}
// Bitácora de acceso: queda registrado también lo denegado. No altera la versión del caso.
export function registrarAcceso(caso, actor, permiso, hoyISO) {
  const ev = evaluarAcceso(caso, actor, permiso);
  const reg = { id: `x${caso.bitacoraAcceso.length + 1}`, en: hoyISO, personaId: actor?.personaId || null, permiso, permitido: ev.permitido, motivo: ev.motivo };
  return { caso: { ...caso, bitacoraAcceso: [...caso.bitacoraAcceso, reg] }, acceso: ev };
}

/* ═══════════════════════════════════════════════════════════════════════
   OPERACIONES — no destructivas (§72) con auditoría (§45)
   Reciben el caso y devuelven { caso, auditoria, ... } con un caso NUEVO, o { error }.
   `hoyISO` es la fecha de registro (parámetro, no Date.now(), para poder probarlo).
   ═══════════════════════════════════════════════════════════════════════ */
const err = (m, extra = {}) => ({ error: m, ...extra });
const esReferencia = (x) => typeof x === 'string' && x.trim().length > 0 && x.length <= 80 && !/[\r\n]/.test(x);
const noCerrado = (caso) => (caso.estado === 'cerrado' ? err('El caso está cerrado.') : null);
function entrada(caso, { accion, actor, hoyISO, anterior = null, nuevo = null, motivo = null, origen = null }) {
  return { id: `h${caso.historial.length + 1}`, en: hoyISO, actor: { personaId: actor?.personaId || null, roles: actor?.personaId ? rolesEnCaso(caso, actor.personaId) : [] }, accion, valorAnterior: anterior, valorNuevo: nuevo, motivo, origen };
}
export const puedeTransicionar = (desde, hacia) => desde === hacia || (TRANSICIONES[desde] || []).includes(hacia);
function aplicar(caso, cambios, meta) {
  if (cambios.estado !== undefined && !puedeTransicionar(caso.estado, cambios.estado)) return err(`Transición no permitida: ${caso.estado} → ${cambios.estado}`, { transicionInvalida: true });
  const e = entrada(caso, meta);
  return { caso: { ...caso, ...cambios, version: caso.version + 1, historial: [...caso.historial, e] }, auditoria: e };
}
const maxFecha = (fs) => fs.reduce((a, b) => (a > b ? a : b));

export function evaluarEnrutamiento(caso) {
  const rama = RAMAS[caso.ramaId];
  if (!rama) return { error: 'El caso no está clasificado.' };
  let permitidos = [...rama.procedimientos];
  if (caso.procedimientoLegal && rama.procedimientosSiLegal) permitidos = [...new Set([...permitidos, ...rama.procedimientosSiLegal])];
  let obligatorio = null;
  const motivos = [], acciones = [];
  if (rama.inmediata || caso.evaluacionInicial?.riesgo === 'inmediato') acciones.push('activar_seguridad_y_emergencias', 'derivar_a_autoridades_sin_esperar_la_investigacion_laboral');
  if (caso.procedimientoLegal) {
    // La ruta depende del RÉGIMEN jurídico de las partes, que se determina caso a caso: el sector del tenant no decide.
    if (caso.regimenJuridico === 'estatutario_publico') {
      obligatorio = 'procedimiento_administrativo'; permitidos = ['procedimiento_administrativo'];
      motivos.push('Régimen estatutario público: corresponde el procedimiento administrativo de su estatuto (investigación sumaria o sumario), con plazos propios que este paquete no modela. Confirmar con abogado.');
    } else if (caso.denunciado?.relacion === 'art4_inc1') {
      obligatorio = 'derivacion_dt'; permitidos = ['derivacion_dt'];
      motivos.push('La denuncia se dirige a una persona del art. 4, inc. 1.º del Código del Trabajo: debe remitirse a la Dirección del Trabajo (ORD. N.º 146/13, 24-feb-2026).');
    }
  }
  return { ramaId: caso.ramaId, regimenJuridico: caso.regimenJuridico, permitidos, obligatorio, motivos, acciones, requiereInvestigadorImparcial: !!rama.imparcial && permitidos.includes('investigacion_interna') };
}

export function crearCaso(d, hoyISO) {
  const { id, tenantId = null, sectorTenant = 'privado', canalIngreso = 'empleador', recibidaEn = hoyISO, denunciante, denunciado, relatoRef = null, receptorId, responsableId = null, actor } = d;
  if (!id) return err('El caso requiere un identificador.');
  if (!actor?.personaId) return err('Se requiere el actor: quién registra el caso.');
  if (!['privado', 'publico'].includes(sectorTenant)) return err('sectorTenant debe ser privado o publico.');
  if (!['empleador', 'dt'].includes(canalIngreso)) return err('canalIngreso debe ser empleador o dt.');
  if (!fechaValida(recibidaEn) || !fechaValida(hoyISO)) return err('Fechas inválidas.');
  if (recibidaEn > hoyISO) return err('La fecha de recepción no puede ser posterior a la fecha de registro.');
  if (!denunciante || !TIPOS_DENUNCIANTE.includes(denunciante.tipo)) return err('Denunciante: tipo inválido.');
  if (!denunciado || !TIPOS_DENUNCIADO.includes(denunciado.tipo)) return err('Denunciado: tipo inválido.');
  const relacion = denunciado.relacion || (denunciado.tipo === 'trabajador' ? 'trabajador' : denunciado.tipo);
  if (!RELACIONES_DENUNCIADO.includes(relacion)) return err('Denunciado: relación inválida.');
  if (relacion === 'art4_inc1' && denunciado.tipo !== 'trabajador') return err('La relación art4_inc1 solo aplica a trabajadores.');
  const refDenunciante = denunciante.tipo === 'no_individualizado' ? null : (denunciante.personaId || denunciante.ref || null);
  const refDenunciado = denunciado.tipo === 'desconocido' ? null : (denunciado.personaId || denunciado.ref || null);
  if (denunciante.tipo !== 'no_individualizado' && !refDenunciante) return err('El denunciante individualizado requiere una referencia (personaId o ref).');
  if (denunciado.tipo !== 'desconocido' && !refDenunciado) return err('El denunciado identificado requiere una referencia (personaId o ref).');
  if (relatoRef !== null && !esReferencia(relatoRef)) return err('El relato se guarda solo como referencia (máx. 80 caracteres), no como contenido.');
  const receptor = receptorId || actor.personaId;
  const partes = [refDenunciante, refDenunciado].filter(Boolean);
  if (partes.includes(receptor) || (responsableId && partes.includes(responsableId))) return err('Una de las partes no puede ser receptor ni responsable del caso (imparcialidad).');
  const caso = {
    id, tenantId, sectorTenant, canalIngreso, estado: 'recibida', estadoPrevio: null,
    ramaId: null, procedimientoLegal: false, procedimiento: null, regimenJuridico: 'por_determinar', regimenInferido: false,
    denunciante: { tipo: denunciante.tipo, ref: refDenunciante, individualizado: denunciante.tipo !== 'no_individualizado' },
    denunciado: { tipo: denunciado.tipo, ref: refDenunciado, relacion },
    relatoRef, eventos: { denuncia_recibida: recibidaEn },
    clasificaciones: [], evaluaciones: [], evaluacionInicial: null, medidasResguardo: [], actuaciones: [], evaluacionesProfesionales: [],
    conflictos: [], asignaciones: { receptores: [receptor], investigadorId: null, responsableId },
    complemento: null, conclusiones: null, medidasCorrectivas: [], sinMedidas: null, seguimientos: [], cierre: null,
    historial: [], bitacoraAcceso: [], version: 0,
  };
  const e = entrada(caso, { accion: 'crear_caso', actor, hoyISO, nuevo: { canalIngreso, recibidaEn } });
  return { caso: { ...caso, version: 1, historial: [e] }, auditoria: e };
}

export function clasificarCaso(caso, { ramaId, activaProcedimientoLegal, regimenJuridico, motivo, actor }, hoyISO) {
  const e = noCerrado(caso) || exigir(caso, actor, ['registrar']);
  if (e) return e;
  if (caso.estado === 'por_complementar') return err('La denuncia está por complementar: registre el complemento o continúe sin él antes de clasificar.');
  const rama = RAMAS[ramaId];
  if (!rama) return err('Rama desconocida.');
  if (!motivo) return err('La clasificación requiere motivo (queda en el historial).');
  const legal = activaProcedimientoLegal === undefined ? !!rama.legalPorDefecto : !!activaProcedimientoLegal;
  if (legal && !rama.legalPorDefecto && !rama.procedimientosSiLegal) return err('Esta rama no activa el procedimiento legal: reclasifique a la rama que corresponda.');
  if (!legal && rama.legalPorDefecto) return err('La rama de acoso o violencia legal requiere el procedimiento legal; si los hechos no lo configuran, reclasifique.');
  if (regimenJuridico !== undefined && !['codigo_trabajo', 'estatutario_publico'].includes(regimenJuridico)) return err('Régimen jurídico inválido (codigo_trabajo o estatutario_publico).');
  // Régimen: se declara; solo se asume Código del Trabajo en tenants privados, y queda marcado como inferido.
  let regimen = regimenJuridico || (caso.regimenJuridico !== 'por_determinar' ? caso.regimenJuridico : null);
  let inferido = regimenJuridico ? false : caso.regimenInferido;
  if (!regimen && legal) {
    if (caso.sectorTenant === 'publico') return err('Institución pública: determine expresamente el régimen jurídico aplicable (estatutario público o Código del Trabajo); el sector del tenant por sí solo no decide la ruta.');
    regimen = 'codigo_trabajo'; inferido = true;
  }
  regimen = regimen || 'por_determinar';
  const enr = evaluarEnrutamiento({ ...caso, ramaId, procedimientoLegal: legal, regimenJuridico: regimen });
  const advertencias = [];
  if (caso.procedimiento && !enr.permitidos.includes(caso.procedimiento)) advertencias.push('El procedimiento ya seleccionado no está permitido con la nueva clasificación: revisar.');
  if (inferido) advertencias.push('Régimen jurídico asumido como Código del Trabajo por tratarse de un tenant privado: confirmar.');
  const clas = { version: caso.clasificaciones.length + 1, ramaId, procedimientoLegal: legal, regimenJuridico: regimen, regimenInferido: inferido, motivo, por: actor.personaId, en: hoyISO };
  const r = aplicar(caso, { ramaId, procedimientoLegal: legal, regimenJuridico: regimen, regimenInferido: inferido, clasificaciones: [...caso.clasificaciones, clas], estado: caso.estado === 'recibida' ? 'clasificada' : caso.estado },
    { accion: 'clasificar_caso', actor, hoyISO, anterior: { ramaId: caso.ramaId, procedimientoLegal: caso.procedimientoLegal, regimenJuridico: caso.regimenJuridico }, nuevo: { ramaId, procedimientoLegal: legal, regimenJuridico: regimen }, motivo });
  return { ...r, advertencias, enrutamiento: enr };
}

// ORD. N.º 146/13 (DT, 24-feb-2026): una denuncia inconsistente se complementa en un plazo razonable; no se archiva.
export function solicitarComplemento(caso, { plazoDias, tipoDia = 'corrido', fundamento, actor }, hoyISO, cal = CALENDARIO_CL) {
  const e = noCerrado(caso) || exigir(caso, actor, ['registrar']);
  if (e) return e;
  if (!['recibida', 'clasificada'].includes(caso.estado)) return err('El complemento solo puede solicitarse en la etapa de recepción y clasificación.');
  if (caso.complemento?.estado === 'pendiente') return err('Ya hay un complemento pendiente.');
  if (!Number.isInteger(plazoDias) || plazoDias < 1) return err('Fije un plazo razonable en días (entero, al menos 1).');
  if (!TIPOS_DIA[tipoDia]) return err('Tipo de día inválido.');
  if (!fundamento) return err('Indique por qué el plazo es razonable (queda en el historial).');
  const v = sumarDiasTipo(hoyISO, plazoDias, tipoDia, cal);
  const complemento = { solicitadoEn: hoyISO, plazoDias, tipoDia, venceEn: v.fecha, estado: 'pendiente', fundamento, advertencias: v.advertencias };
  return aplicar(caso, { estado: 'por_complementar', estadoPrevio: caso.estado, complemento },
    { accion: 'solicitar_complemento', actor, hoyISO, anterior: { estado: caso.estado }, nuevo: { venceEn: v.fecha, plazoDias, tipoDia }, motivo: fundamento });
}
export function recibirComplemento(caso, { referencia, actor }, hoyISO) {
  const e = exigir(caso, actor, ['registrar']);
  if (e) return e;
  if (caso.estado !== 'por_complementar') return err('El caso no está por complementar.');
  if (!esReferencia(referencia)) return err('Indique solo una referencia al documento recibido, no su contenido.');
  const complemento = { ...caso.complemento, estado: 'recibido', recibidoEn: hoyISO, referencia, dentroDePlazo: hoyISO <= caso.complemento.venceEn };
  return aplicar(caso, { estado: caso.estadoPrevio, estadoPrevio: null, complemento },
    { accion: 'recibir_complemento', actor, hoyISO, anterior: { estado: 'por_complementar' }, nuevo: { estado: caso.estadoPrevio, referencia } });
}
export function continuarSinComplemento(caso, { fundamento, actor }, hoyISO) {
  const e = exigir(caso, actor, ['registrar']);
  if (e) return e;
  if (caso.estado !== 'por_complementar') return err('El caso no está por complementar.');
  if (hoyISO <= caso.complemento.venceEn) return err(`El plazo razonable aún no vence (${caso.complemento.venceEn}): no se puede continuar sin el complemento.`);
  if (!fundamento) return err('Indique el fundamento.');
  const complemento = { ...caso.complemento, estado: 'vencido_sin_complemento', cerradoEn: hoyISO };
  const r = aplicar(caso, { estado: caso.estadoPrevio, estadoPrevio: null, complemento },
    { accion: 'continuar_sin_complemento', actor, hoyISO, anterior: { estado: 'por_complementar' }, nuevo: { estado: caso.estadoPrevio }, motivo: fundamento });
  return { ...r, nota: 'La denuncia no se archiva por inconsistente (ORD. N.º 146/13): continúa con los antecedentes disponibles.' };
}

export const ESTADOS_MEDIDA_RESGUARDO = {
  propuesta: { label: 'Propuesta' }, ordenada: { label: 'Ordenada' }, implementada: { label: 'Implementada' }, descartada: { label: 'Descartada' },
};
const buscarMedidaResguardo = (caso, id) => caso.medidasResguardo.find((m) => m.id === id);
const cambiarMedidaResguardo = (caso, id, patch) => caso.medidasResguardo.map((m) => (m.id === id ? { ...m, ...patch } : m));
// Una propuesta NO es una medida aplicada: solo la ordena quien decide, y solo cuenta como aplicada cuando hay implementación con evidencia.
export function proponerMedidaResguardo(caso, { tipo, destinatarioId, fundamento, actor }, hoyISO) {
  const e = noCerrado(caso) || exigir(caso, actor, ['registrar']);
  if (e) return e;
  if (!TIPOS_MEDIDA_RESGUARDO[tipo]) return err('Tipo de medida de resguardo inválido.');
  if (!destinatarioId) return err('Indique a quién se aplicaría la medida.');
  if (!fundamento) return err('Indique el fundamento de la medida.');
  const medida = { id: `r${caso.medidasResguardo.length + 1}`, tipo, destinatarioId, fundamento, estado: 'propuesta', propuestaEn: hoyISO, propuestaPor: actor.personaId, ordenadaEn: null, ordenadaPor: null, implementadaEn: null, evidenciaRef: null };
  const r = aplicar(caso, { medidasResguardo: [...caso.medidasResguardo, medida] }, { accion: 'proponer_medida_resguardo', actor, hoyISO, nuevo: { id: medida.id, tipo, destinatarioId }, motivo: fundamento });
  return { ...r, medidaId: medida.id };
}
export function ordenarMedidaResguardo(caso, { medidaId, actor }, hoyISO) {
  const e = noCerrado(caso) || exigir(caso, actor, ['decidir']);
  if (e) return e;
  const m = buscarMedidaResguardo(caso, medidaId);
  if (!m) return err('Medida de resguardo no encontrada.');
  if (m.estado !== 'propuesta') return err(`Solo se ordena una medida propuesta (estado actual: ${m.estado}).`);
  return aplicar(caso, { medidasResguardo: cambiarMedidaResguardo(caso, medidaId, { estado: 'ordenada', ordenadaEn: hoyISO, ordenadaPor: actor.personaId }) },
    { accion: 'ordenar_medida_resguardo', actor, hoyISO, anterior: { estado: 'propuesta' }, nuevo: { id: medidaId, estado: 'ordenada' } });
}
export function implementarMedidaResguardo(caso, { medidaId, fecha, evidenciaRef, actor }, hoyISO) {
  const e = noCerrado(caso) || exigir(caso, actor, ['registrar', 'decidir']);
  if (e) return e;
  const m = buscarMedidaResguardo(caso, medidaId);
  if (!m) return err('Medida de resguardo no encontrada.');
  if (m.estado !== 'ordenada') return err('Solo se implementa una medida ordenada: una propuesta no equivale a una medida aplicada.');
  if (!esReferencia(evidenciaRef)) return err('Indique solo una referencia a la evidencia de implementación.');
  const f = fecha || hoyISO;
  if (!fechaValida(f) || f > hoyISO || f < m.ordenadaEn) return err('Fecha de implementación inválida.');
  return aplicar(caso, { medidasResguardo: cambiarMedidaResguardo(caso, medidaId, { estado: 'implementada', implementadaEn: f, evidenciaRef }) },
    { accion: 'implementar_medida_resguardo', actor, hoyISO, anterior: { estado: 'ordenada' }, nuevo: { id: medidaId, estado: 'implementada', implementadaEn: f } });
}
export function descartarMedidaResguardo(caso, { medidaId, fundamento, actor }, hoyISO) {
  const e = noCerrado(caso) || exigir(caso, actor, ['decidir']);
  if (e) return e;
  const m = buscarMedidaResguardo(caso, medidaId);
  if (!m) return err('Medida de resguardo no encontrada.');
  if (!['propuesta', 'ordenada'].includes(m.estado)) return err(`No se puede descartar una medida ${m.estado}.`);
  if (!fundamento) return err('Indique el fundamento del descarte.');
  return aplicar(caso, { medidasResguardo: cambiarMedidaResguardo(caso, medidaId, { estado: 'descartada' }) },
    { accion: 'descartar_medida_resguardo', actor, hoyISO, anterior: { estado: m.estado }, nuevo: { id: medidaId, estado: 'descartada' }, motivo: fundamento });
}
export function registrarEvaluacionInicial(caso, { riesgo, urgenciaProteccion = false, riesgoRepresalias = false, decisionMedidas, fundamentoNoMedidas, actor }, hoyISO) {
  const e = noCerrado(caso) || exigir(caso, actor, ['registrar']);
  if (e) return e;
  if (!['clasificada', 'evaluacion_inicial'].includes(caso.estado)) return err('La evaluación inicial se registra después de clasificar el caso.');
  if (!RIESGOS.includes(riesgo)) return err('Riesgo inválido.');
  if (!['aplicadas', 'no_requeridas'].includes(decisionMedidas)) return err('Documente la decisión sobre las medidas de resguardo (aplicadas o no requeridas).');
  if (decisionMedidas === 'no_requeridas' && !fundamentoNoMedidas) return err('Si no se aplican medidas de resguardo, fundamente la decisión.');
  if (decisionMedidas === 'no_requeridas' && riesgo === 'inmediato') return err('Con riesgo inmediato no puede declararse que no se requieren medidas.');
  const vigentes = caso.medidasResguardo.filter((m) => ['ordenada', 'implementada'].includes(m.estado));
  if (decisionMedidas === 'aplicadas' && !vigentes.length) return err('Se indicó que hay medidas de resguardo, pero ninguna está ordenada o implementada (una propuesta no basta).');
  if (decisionMedidas === 'aplicadas' && riesgo === 'inmediato' && !vigentes.some((m) => m.estado === 'implementada')) return err('Con riesgo inmediato debe haber al menos una medida de resguardo implementada.');
  const ev = { version: caso.evaluaciones.length + 1, riesgo, urgenciaProteccion, riesgoRepresalias, decisionMedidas, fundamentoNoMedidas: fundamentoNoMedidas || null, en: hoyISO, por: actor.personaId };
  return aplicar(caso, { estado: 'evaluacion_inicial', evaluaciones: [...caso.evaluaciones, ev], evaluacionInicial: ev },
    { accion: 'registrar_evaluacion_inicial', actor, hoyISO, anterior: caso.evaluacionInicial ? { riesgo: caso.evaluacionInicial.riesgo } : null, nuevo: { riesgo, decisionMedidas } });
}

export function asignarRol(caso, { personaId, rol, actor }, hoyISO) {
  const e = noCerrado(caso) || exigir(caso, actor, ['registrar']);
  if (e) return e;
  if (!['receptor', 'investigador', 'responsable'].includes(rol)) return err('Rol inválido.');
  if (!personaId) return err('Indique la persona.');
  if ([caso.denunciante.ref, caso.denunciado.ref].includes(personaId)) return err('Una de las partes no puede ejercer un rol en el procedimiento (imparcialidad).');
  if (caso.conflictos.some((c) => c.personaId === personaId)) return err('La persona tiene un conflicto de interés declarado en este caso.');
  const a = { ...caso.asignaciones };
  const anterior = rol === 'receptor' ? a.receptores : rol === 'investigador' ? a.investigadorId : a.responsableId;
  if (rol === 'receptor') a.receptores = [...new Set([...a.receptores, personaId])];
  if (rol === 'investigador') a.investigadorId = personaId;
  if (rol === 'responsable') a.responsableId = personaId;
  return aplicar(caso, { asignaciones: a }, { accion: 'asignar_rol', actor, hoyISO, anterior: { rol, valor: anterior }, nuevo: { rol, personaId } });
}
export function declararConflictoInteres(caso, { personaId, motivo, actor }, hoyISO) {
  const e = noCerrado(caso) || exigir(caso, actor, ['registrar', 'investigar']);
  if (e) return e;
  if (!personaId || !motivo) return err('Indique la persona y el motivo.');
  if (caso.conflictos.some((c) => c.personaId === personaId)) return err('Ya hay un conflicto declarado para esa persona.');
  const a = caso.asignaciones;
  const retiradoDe = [];
  if (a.receptores.includes(personaId)) retiradoDe.push('receptor');
  if (a.investigadorId === personaId) retiradoDe.push('investigador');
  if (a.responsableId === personaId) retiradoDe.push('responsable');
  const asignaciones = { receptores: a.receptores.filter((x) => x !== personaId), investigadorId: a.investigadorId === personaId ? null : a.investigadorId, responsableId: a.responsableId === personaId ? null : a.responsableId };
  return aplicar(caso, { conflictos: [...caso.conflictos, { personaId, motivo, declaradoEn: hoyISO, por: actor.personaId }], asignaciones },
    { accion: 'declarar_conflicto_interes', actor, hoyISO, nuevo: { personaId, retiradoDe }, motivo });
}

export function seleccionarProcedimiento(caso, { procedimiento, fundamento, actor }, hoyISO) {
  const e = noCerrado(caso) || exigir(caso, actor, ['decidir']);
  if (e) return e;
  if (!['evaluacion_inicial', 'procedimiento_seleccionado'].includes(caso.estado)) return err('Primero registre la evaluación inicial y el resguardo (etapa B).');
  if (!PROCEDIMIENTOS[procedimiento]) return err('Procedimiento desconocido.');
  const enr = evaluarEnrutamiento(caso);
  if (!enr.permitidos.includes(procedimiento)) return err(`El procedimiento no está permitido para este caso. Permitidos: ${enr.permitidos.join(', ')}.${enr.motivos.length ? ' ' + enr.motivos.join(' ') : ''}`, { enrutamiento: enr });
  if (!fundamento) return err('Documente por qué se elige ese procedimiento.');
  // ORD. N.º 146/13: individualizar a quien denuncia es requisito para investigar, también cuando el caso se deriva a la DT.
  if (['investigacion_interna', 'derivacion_dt'].includes(procedimiento) && !caso.denunciante.individualizado) {
    return err('Para iniciar una investigación o derivarla a la DT se requiere individualizar a la persona denunciante (ORD. N.º 146/13): solicite el complemento y mantenga medidas generales de resguardo (deber de protección del art. 184).');
  }
  if (procedimiento === 'investigacion_interna' && !caso.asignaciones.investigadorId) return err('Asigne un investigador imparcial antes de seleccionar la investigación interna.');
  return aplicar(caso, { procedimiento, estado: 'procedimiento_seleccionado' },
    { accion: 'seleccionar_procedimiento', actor, hoyISO, anterior: { procedimiento: caso.procedimiento }, nuevo: { procedimiento }, motivo: fundamento });
}
export function iniciarInvestigacion(caso, { fecha, actor }, hoyISO) {
  const e = noCerrado(caso) || exigir(caso, actor, ['registrar', 'investigar']);
  if (e) return e;
  if (caso.estado !== 'procedimiento_seleccionado' || caso.procedimiento !== 'investigacion_interna') return err('Solo se inicia la investigación cuando está seleccionada la investigación interna.');
  if (!caso.asignaciones.investigadorId) return err('No hay investigador asignado.');
  const f = fecha || hoyISO;
  if (!fechaValida(f) || f > hoyISO || f < caso.eventos.denuncia_recibida) return err('Fecha de inicio inválida.');
  return aplicar(caso, { estado: 'en_investigacion', eventos: { ...caso.eventos, investigacion_iniciada: f } },
    { accion: 'iniciar_investigacion', actor, hoyISO, anterior: { estado: caso.estado }, nuevo: { investigacion_iniciada: f } });
}
export function derivarADT(caso, { fecha, referencia, actor }, hoyISO) {
  const e = noCerrado(caso) || exigir(caso, actor, ['decidir']);
  if (e) return e;
  if (caso.estado !== 'procedimiento_seleccionado' || caso.procedimiento !== 'derivacion_dt') return err('Solo se deriva a la DT cuando está seleccionada la derivación.');
  if (!esReferencia(referencia)) return err('Indique solo una referencia a la derivación, no su contenido.');
  const f = fecha || hoyISO;
  if (!fechaValida(f) || f > hoyISO || f < caso.eventos.denuncia_recibida) return err('Fecha de derivación inválida.');
  return aplicar(caso, { estado: 'derivado_dt', eventos: { ...caso.eventos, derivado_a_dt: f } },
    { accion: 'derivar_a_dt', actor, hoyISO, anterior: { estado: caso.estado }, nuevo: { derivado_a_dt: f, referencia } });
}

export function registrarActuacion(caso, { tipo, fecha, participantes = [], resultado = null, referencia = null, actor }, hoyISO) {
  const interno = caso.procedimiento === 'investigacion_interna';
  const e = noCerrado(caso) || exigir(caso, actor, interno ? ['investigar'] : ['registrar', 'investigar']);
  if (e) return e;
  if (!TIPOS_ACTUACION[tipo]) return err('Tipo de actuación inválido.');
  const f = fecha || hoyISO;
  if (!fechaValida(f) || f > hoyISO) return err('Fecha de la actuación inválida.');
  if (['citacion', 'entrevista', 'declaracion'].includes(tipo) && !participantes.length) return err('Indique a quién se cita, entrevista o toma declaración.');
  if (tipo === 'citacion' && resultado !== null && !['comparecio', 'no_comparecio'].includes(resultado)) return err('Resultado de la citación inválido.');
  if (referencia !== null && !esReferencia(referencia)) return err('Guarde solo una referencia, no el contenido.');
  const act = { id: `a${caso.actuaciones.length + 1}`, tipo, fecha: f, participantes, resultado, referencia, reservado: true, registradaEn: hoyISO, por: actor.personaId };
  const r = aplicar(caso, { actuaciones: [...caso.actuaciones, act] }, { accion: 'registrar_actuacion', actor, hoyISO, nuevo: { id: act.id, tipo, fecha: f } });
  return { ...r, actuacionId: act.id };
}
// Debido proceso: ambas partes oídas (declaración o entrevista) o con oportunidad otorgada (citación sin comparecencia).
export function estadoAudienciaPartes(caso) {
  const out = {};
  for (const [rol, parte] of [['denunciante', caso.denunciante], ['denunciado', caso.denunciado]]) {
    if (!parte.ref) { out[rol] = rol === 'denunciante' ? 'no_individualizado' : 'sin_identificar'; continue; }
    const mias = caso.actuaciones.filter((a) => a.participantes.includes(parte.ref));
    out[rol] = mias.some((a) => ['declaracion', 'entrevista'].includes(a.tipo)) ? 'oida'
      : mias.some((a) => a.tipo === 'citacion' && a.resultado === 'no_comparecio') ? 'oportunidad_otorgada' : 'pendiente';
  }
  return out;
}
// Evaluaciones médicas o psicológicas: no son automáticas; requieren fundamento y base. El informe vive fuera del expediente.
export function solicitarEvaluacionProfesional(caso, { tipo, fundamento, baseJuridica, consentimientoDeId, profesionalRef, actor }, hoyISO) {
  const e = noCerrado(caso) || exigir(caso, actor, ['decidir', 'investigar']);
  if (e) return e;
  if (!TIPOS_EVALUACION_PROFESIONAL[tipo]) return err('Tipo de evaluación inválido.');
  if (!fundamento) return err('La evaluación requiere fundamento: no se activa automáticamente.');
  if (!baseJuridica && !consentimientoDeId) return err('Indique la base jurídica o el consentimiento de la persona evaluada.');
  if (!esReferencia(profesionalRef)) return err('Indique la referencia del profesional que evalúa.');
  const ev = { id: `ev${caso.evaluacionesProfesionales.length + 1}`, tipo, fundamento, baseJuridica: baseJuridica || null, consentimientoDeId: consentimientoDeId || null, profesionalRef, estado: 'solicitada', referenciaInforme: null, solicitadaEn: hoyISO, por: actor.personaId, informeFueraDelExpediente: true };
  const r = aplicar(caso, { evaluacionesProfesionales: [...caso.evaluacionesProfesionales, ev] }, { accion: 'solicitar_evaluacion_profesional', actor, hoyISO, nuevo: { id: ev.id, tipo }, motivo: fundamento });
  return { ...r, evaluacionId: ev.id };
}
export function registrarResultadoEvaluacion(caso, { evaluacionId, referenciaInforme, actor }, hoyISO) {
  const e = noCerrado(caso) || exigir(caso, actor, ['decidir', 'investigar']);
  if (e) return e;
  const ev = caso.evaluacionesProfesionales.find((x) => x.id === evaluacionId);
  if (!ev) return err('Evaluación no encontrada.');
  if (ev.estado === 'informada') return err('La evaluación ya tiene informe registrado.');
  if (!esReferencia(referenciaInforme)) return err('Guarde solo la referencia al informe (máx. 80 caracteres): el informe clínico queda fuera del expediente laboral.');
  const lista = caso.evaluacionesProfesionales.map((x) => (x.id === evaluacionId ? { ...x, estado: 'informada', referenciaInforme, informadaEn: hoyISO } : x));
  return aplicar(caso, { evaluacionesProfesionales: lista }, { accion: 'registrar_resultado_evaluacion', actor, hoyISO, anterior: { estado: ev.estado }, nuevo: { estado: 'informada', referenciaInforme } });
}

export function registrarConclusiones(caso, { resultado, referenciaInforme, fecha, actor }, hoyISO) {
  const interno = caso.procedimiento === 'investigacion_interna';
  const e = noCerrado(caso) || exigir(caso, actor, interno ? ['investigar'] : ['registrar', 'decidir']);
  if (e) return e;
  const noInvestigativo = !!caso.procedimiento && !['investigacion_interna', 'derivacion_dt', 'derivacion_autoridades', 'activacion_seguridad_emergencias'].includes(caso.procedimiento);
  const estadoOk = interno ? caso.estado === 'en_investigacion' : (caso.estado === 'procedimiento_seleccionado' && noInvestigativo);
  if (!estadoOk) return err(interno ? 'Las conclusiones se registran durante la investigación interna.' : 'Las conclusiones directas solo aplican a procedimientos no investigativos ya seleccionados (en la derivación a la DT se registran sus conclusiones).');
  if (!RESULTADOS_ILUSTRATIVOS[resultado]) return err('Resultado inválido.');
  if (!esReferencia(referenciaInforme)) return err('Indique solo una referencia al informe, no su contenido.');
  if (interno) {
    const aud = estadoAudienciaPartes(caso);
    const pend = Object.entries(aud).filter(([, v]) => !['oida', 'oportunidad_otorgada'].includes(v)).map(([k]) => k);
    if (pend.length) return err(`Falta oír a las partes (debido proceso): ${pend.join(', ')}.`);
  }
  const f = fecha || hoyISO;
  if (!fechaValida(f) || f > hoyISO || f < caso.eventos.denuncia_recibida) return err('Fecha de las conclusiones inválida.');
  const conclusiones = { origen: interno ? 'empleador' : 'procedimiento_no_investigativo', resultado, referenciaInforme, fecha: f, por: actor.personaId };
  return aplicar(caso, { estado: 'conclusiones', conclusiones, eventos: interno ? { ...caso.eventos, investigacion_concluida: f } : caso.eventos },
    { accion: 'registrar_conclusiones', actor, hoyISO, anterior: { estado: caso.estado }, nuevo: { resultado, referenciaInforme, fecha: f } });
}
export function remitirInformeADT(caso, { fecha, referencia, actor }, hoyISO) {
  const e = noCerrado(caso) || exigir(caso, actor, ['decidir']);
  if (e) return e;
  if (caso.estado !== 'conclusiones' || caso.procedimiento !== 'investigacion_interna' || !caso.procedimientoLegal) return err('El informe se remite a la DT al concluir la investigación interna de un caso con procedimiento legal.');
  if (caso.eventos.informe_remitido_dt) return err('El informe ya fue remitido.');
  if (!esReferencia(referencia)) return err('Indique solo una referencia al envío, no su contenido.');
  const f = fecha || hoyISO;
  if (!fechaValida(f) || f > hoyISO || f < caso.eventos.investigacion_concluida) return err('Fecha de remisión inválida.');
  return aplicar(caso, { eventos: { ...caso.eventos, informe_remitido_dt: f } }, { accion: 'remitir_informe_a_dt', actor, hoyISO, nuevo: { informe_remitido_dt: f, referencia } });
}
export function registrarConclusionesDT(caso, { fecha, referencia, actor }, hoyISO) {
  const e = noCerrado(caso) || exigir(caso, actor, ['registrar', 'decidir']);
  if (e) return e;
  if (caso.eventos.conclusiones_dt_notificadas) return err('Ya se registraron las conclusiones de la DT.');
  const viaDerivacion = caso.estado === 'derivado_dt';
  const viaInforme = caso.estado === 'conclusiones' && caso.procedimiento === 'investigacion_interna' && !!caso.eventos.informe_remitido_dt;
  if (!viaDerivacion && !viaInforme) return err('Las conclusiones de la DT se registran tras derivar el caso o tras remitir el informe de la investigación.');
  if (!esReferencia(referencia)) return err('Indique solo una referencia a la notificación de la DT, no su contenido.');
  const f = fecha || hoyISO;
  const minimo = viaDerivacion ? caso.eventos.derivado_a_dt : caso.eventos.informe_remitido_dt;
  if (!fechaValida(f) || f > hoyISO || f < minimo) return err('Fecha de notificación inválida.');
  return aplicar(caso, {
    estado: 'conclusiones', eventos: { ...caso.eventos, conclusiones_dt_notificadas: f },
    conclusiones: caso.conclusiones || { origen: 'dt', resultado: null, referenciaInforme: referencia, fecha: f, por: actor.personaId },
  }, { accion: 'registrar_conclusiones_dt', actor, hoyISO, anterior: { estado: caso.estado }, nuevo: { conclusiones_dt_notificadas: f, referencia } });
}

function exigirDecision(caso) {
  if (!['conclusiones', 'en_seguimiento'].includes(caso.estado)) return err('Las medidas se disponen después de las conclusiones (etapa E).');
  if (caso.procedimientoLegal && !caso.eventos.conclusiones_dt_notificadas) return err('En el procedimiento legal las medidas se disponen una vez notificadas las conclusiones de la DT.');
  return null;
}
export function registrarMedidaCorrectiva(caso, { tipo, destinatarioId, fundamento, actor }, hoyISO) {
  const e = noCerrado(caso) || exigir(caso, actor, ['decidir']) || exigirDecision(caso);
  if (e) return e;
  if (caso.sinMedidas) return err('El caso se declaró sin medidas.');
  if (!TIPOS_MEDIDA_CORRECTIVA[tipo]) return err('Tipo de medida inválido.');
  if (!destinatarioId || !fundamento) return err('Indique destinatario y fundamento (decide una persona, no el sistema).');
  const m = { id: `c${caso.medidasCorrectivas.length + 1}`, tipo, destinatarioId, fundamento, estado: 'dispuesta', dispuestaEn: hoyISO, aplicadaEn: null, evidenciaRef: null, decididaPor: actor.personaId };
  const r = aplicar(caso, { medidasCorrectivas: [...caso.medidasCorrectivas, m] }, { accion: 'registrar_medida_correctiva', actor, hoyISO, nuevo: { id: m.id, tipo, destinatarioId }, motivo: fundamento });
  return { ...r, medidaId: m.id };
}
export function marcarMedidaAplicada(caso, { medidaId, fecha, evidenciaRef, actor }, hoyISO) {
  const e = noCerrado(caso) || exigir(caso, actor, ['decidir', 'registrar']);
  if (e) return e;
  const m = caso.medidasCorrectivas.find((x) => x.id === medidaId);
  if (!m) return err('Medida no encontrada.');
  if (m.estado === 'aplicada') return err('La medida ya está aplicada.');
  if (!esReferencia(evidenciaRef)) return err('Indique solo una referencia a la evidencia de cumplimiento.');
  const f = fecha || hoyISO;
  if (!fechaValida(f) || f > hoyISO || f < m.dispuestaEn) return err('Fecha de aplicación inválida.');
  const medidas = caso.medidasCorrectivas.map((x) => (x.id === medidaId ? { ...x, estado: 'aplicada', aplicadaEn: f, evidenciaRef } : x));
  const cambios = { medidasCorrectivas: medidas };
  if (medidas.every((x) => x.estado === 'aplicada')) { cambios.eventos = { ...caso.eventos, medidas_correctivas_aplicadas: maxFecha(medidas.map((x) => x.aplicadaEn)) }; cambios.estado = 'en_seguimiento'; }
  return aplicar(caso, cambios, { accion: 'marcar_medida_aplicada', actor, hoyISO, anterior: { estado: 'dispuesta' }, nuevo: { id: medidaId, estado: 'aplicada', aplicadaEn: f } });
}
export function declararSinMedidas(caso, { fundamento, actor }, hoyISO) {
  const e = noCerrado(caso) || exigir(caso, actor, ['decidir']) || exigirDecision(caso);
  if (e) return e;
  if (caso.estado !== 'conclusiones') return err('Solo corresponde justo después de las conclusiones.');
  if (caso.medidasCorrectivas.length) return err('Ya hay medidas dispuestas.');
  if (!fundamento) return err('La decisión de no aplicar medidas debe fundamentarse.');
  return aplicar(caso, { sinMedidas: { fundamento, en: hoyISO, por: actor.personaId }, eventos: { ...caso.eventos, decision_sin_medidas: hoyISO }, estado: 'en_seguimiento' },
    { accion: 'declarar_sin_medidas', actor, hoyISO, nuevo: { sinMedidas: true }, motivo: fundamento });
}
export function registrarSeguimiento(caso, { medidaId = null, resultado, fecha, actor }, hoyISO) {
  const e = noCerrado(caso) || exigir(caso, actor, ['decidir', 'registrar']);
  if (e) return e;
  if (caso.estado !== 'en_seguimiento') return err('El seguimiento se registra en la etapa F.');
  if (!['cumplida', 'parcial', 'incumplida'].includes(resultado)) return err('Resultado de seguimiento inválido.');
  if (medidaId && !caso.medidasCorrectivas.some((m) => m.id === medidaId)) return err('Medida no encontrada.');
  const f = fecha || hoyISO;
  if (!fechaValida(f) || f > hoyISO) return err('Fecha de seguimiento inválida.');
  const s = { id: `s${caso.seguimientos.length + 1}`, medidaId, resultado, fecha: f, por: actor.personaId };
  return aplicar(caso, { seguimientos: [...caso.seguimientos, s] }, { accion: 'registrar_seguimiento', actor, hoyISO, nuevo: { medidaId, resultado, fecha: f } });
}

export function verificarCierre(caso, motivoCierre, hoyISO, pack = PAQUETE_REGLAS_CL_BORRADOR, cal = CALENDARIO_CL) {
  const b = [], adv = [];
  if (caso.estado === 'cerrado') return { puedeCerrar: false, bloqueantes: ['El caso ya está cerrado.'], advertencias: [] };
  if (caso.estado === 'por_complementar' || caso.complemento?.estado === 'pendiente') b.push('Hay un complemento de denuncia pendiente: no puede cerrarse por inconsistente (ORD. N.º 146/13).');
  const derivable = motivoCierre === 'derivado_a_autoridad';
  const etapaOk = caso.estado === 'en_seguimiento'
    || (caso.estado === 'conclusiones' && !caso.procedimientoLegal)
    || (derivable && ['clasificada', 'evaluacion_inicial', 'procedimiento_seleccionado'].includes(caso.estado));
  if (!etapaOk && caso.estado !== 'por_complementar') b.push(`El caso está en «${ESTADOS[caso.estado].label}»: no corresponde cerrar todavía.`);
  if (caso.medidasCorrectivas.some((m) => m.estado !== 'aplicada')) b.push('Hay medidas correctivas dispuestas sin aplicar.');
  for (const r of calcularRelojes(caso, hoyISO, pack, cal)) {
    if (r.estado === 'corriendo' && !r.informativa) b.push(`Plazo pendiente: ${r.nombre}.`);
    if (r.estado === 'decidido_sin_medidas') adv.push('Se decidió no aplicar medidas: el plazo para disponer y aplicar medidas no se da por cumplido; confirmar con abogado que corresponde.');
  }
  return { puedeCerrar: b.length === 0, bloqueantes: b, advertencias: adv };
}
export function cerrarCaso(caso, { motivoCierre, fundamento, actor }, hoyISO, pack = PAQUETE_REGLAS_CL_BORRADOR, cal = CALENDARIO_CL) {
  const e = exigir(caso, actor, ['decidir']);
  if (e) return e;
  if (!MOTIVOS_CIERRE[motivoCierre]) return err('Motivo de cierre inválido.');
  if (!fundamento) return err('El cierre requiere fundamento.');
  const v = verificarCierre(caso, motivoCierre, hoyISO, pack, cal);
  if (!v.puedeCerrar) return err(`No se puede cerrar: ${v.bloqueantes.join(' ')}`, { bloqueantes: v.bloqueantes });
  return aplicar(caso, { estado: 'cerrado', cierre: { motivoCierre, fundamento, en: hoyISO, por: actor.personaId } },
    { accion: 'cerrar_caso', actor, hoyISO, anterior: { estado: caso.estado }, nuevo: { estado: 'cerrado', motivoCierre }, motivo: fundamento });
}

/* ═══════════════════════════════════════════════════════════════════════
   RELOJES, ALERTAS, KPIs Y EVENTOS
   ═══════════════════════════════════════════════════════════════════════ */
function aplicaRegla(r, caso) {
  if (caso.regimenJuridico === 'estatutario_publico') return false; // otro estatuto: este paquete no lo modela
  if (r.canal && !r.canal.includes(caso.canalIngreso)) return false;
  const a = r.aplicaSi || {};
  if (a.legalOSinClasificar && !(caso.procedimientoLegal || caso.ramaId === null)) return false;
  if (a.procedimientoLegal !== undefined && caso.procedimientoLegal !== a.procedimientoLegal) return false;
  if (a.procedimiento && !a.procedimiento.includes(caso.procedimiento)) return false;
  return true;
}
function candidatos(r, caso, cal) {
  const out = [];
  for (const ev of r.inicios) {
    const inicio = caso.eventos[ev];
    if (!inicio) continue;
    for (const dias of r.plazos) for (const td of r.tiposDia) {
      const x = sumarDiasTipo(inicio, dias, td, cal, r.prorrogaSiInhabil);
      out.push({ inicioEvento: ev, inicio, dias, tipoDia: td, vence: x.fecha, advertencias: x.advertencias });
    }
  }
  return out;
}
const nivelDe = (dr, u) => (dr < 0 ? 'vencido' : dr <= u.urgente ? 'urgente' : dr <= u.pronto ? 'pronto' : 'ok');
export function calcularRelojes(caso, hoyISO, pack = PAQUETE_REGLAS_CL_BORRADOR, cal = CALENDARIO_CL) {
  const out = [];
  for (const r of pack.reglas) {
    if (!aplicaRegla(r, caso)) continue;
    const cands = candidatos(r, caso, cal);
    if (!cands.length) continue;
    cands.sort((a, b) => (a.vence < b.vence ? -1 : a.vence > b.vence ? 1 : 0));
    const op = cands[0], mx = cands[cands.length - 1];
    const primero = (evs) => (evs || []).map((e) => caso.eventos[e]).filter(Boolean).sort()[0] || null;
    const cumplidoEn = primero(r.cumpleCon), sinMedidasEn = primero(r.resuelveSinCumplir);
    const base = {
      reglaId: r.id, nombre: r.nombre, actor: r.actor, informativa: !!r.informativa, validada: !!r.validada, ambigua: cands.length > 1, variantes: cands.length,
      provisional: caso.ramaId === null && !!(r.aplicaSi || {}).legalOSinClasificar,
      inicioEvento: op.inicioEvento, inicio: op.inicio, plazoDias: op.dias, tipoDia: op.tipoDia,
      vencimientoOperativo: op.vence, vencimientoMaximo: mx.vence, advertencias: [...new Set(cands.flatMap((c) => c.advertencias))],
    };
    if (cumplidoEn) { out.push({ ...base, estado: 'cumplido', cumplidoEn, cumplidoDentroOperativo: cumplidoEn <= op.vence, cumplidoDentroMaximo: cumplidoEn <= mx.vence, nivel: null, diasRestantes: null }); continue; }
    // Una decisión fundamentada de NO aplicar medidas no cumple la obligación: deja de correr, pero queda marcada para revisión.
    if (sinMedidasEn) { out.push({ ...base, estado: 'decidido_sin_medidas', decididoEn: sinMedidasEn, requiereRevision: true, nivel: null, diasRestantes: null }); continue; }
    const dr = contarDiasTipo(hoyISO, op.vence, op.tipoDia, cal);
    out.push({ ...base, estado: 'corriendo', nivel: nivelDe(dr, r.umbrales), diasRestantes: dr });
  }
  if (caso.complemento?.estado === 'pendiente') {
    const c = caso.complemento, dr = contarDiasTipo(hoyISO, c.venceEn, c.tipoDia, cal);
    out.push({ reglaId: 'complemento_denuncia', nombre: 'Plazo razonable para complementar la denuncia (ORD. N.º 146/13)', actor: 'empleador', informativa: false, validada: null, ambigua: false, variantes: 1, provisional: false, inicioEvento: 'complemento_solicitado', inicio: c.solicitadoEn, plazoDias: c.plazoDias, tipoDia: c.tipoDia, vencimientoOperativo: c.venceEn, vencimientoMaximo: c.venceEn, advertencias: c.advertencias || [], estado: 'corriendo', nivel: nivelDe(dr, { urgente: 1, pronto: 2 }), diasRestantes: dr });
  }
  return out;
}
export function calcularAlertasCasos(casos, hoyISO, pack = PAQUETE_REGLAS_CL_BORRADOR, cal = CALENDARIO_CL) {
  const al = [];
  for (const c of casos) {
    if (c.estado === 'cerrado') continue;
    for (const r of calcularRelojes(c, hoyISO, pack, cal)) if (r.estado === 'corriendo' && !r.informativa) al.push({ casoId: c.id, caso: c, reloj: r });
  }
  return al.sort((a, b) => (a.reloj.vencimientoOperativo < b.reloj.vencimientoOperativo ? -1 : a.reloj.vencimientoOperativo > b.reloj.vencimientoOperativo ? 1 : 0));
}
export function calcularKPIsCasos(casos, hoyISO, pack = PAQUETE_REGLAS_CL_BORRADOR, cal = CALENDARIO_CL, { umbralSupresion = 0 } = {}) {
  const abiertos = casos.filter((c) => c.estado !== 'cerrado');
  const cuenta = (arr, f) => arr.filter(f).length;
  const relojes = abiertos.flatMap((c) => calcularRelojes(c, hoyISO, pack, cal)).filter((r) => r.estado === 'corriendo' && !r.informativa);
  // Indicadores agregados para niveles superiores (Country/World): se suprimen cantidades pequeñas para no reconstruir casos.
  const sup = (items) => (umbralSupresion > 0 ? items.map((i) => (i.cantidad > 0 && i.cantidad < umbralSupresion ? { ...i, cantidad: null, suprimido: true } : i)) : items);
  return {
    seccion: 'casos_laborales', casos: casos.length, abiertos: abiertos.length, cerrados: casos.length - abiertos.length,
    sinClasificar: cuenta(casos, (c) => !c.ramaId), porComplementar: cuenta(casos, (c) => c.estado === 'por_complementar'),
    derivadosDT: cuenta(abiertos, (c) => c.estado === 'derivado_dt'),
    relojesVencidos: cuenta(relojes, (r) => r.nivel === 'vencido'), relojesUrgentes: cuenta(relojes, (r) => r.nivel === 'urgente'), relojesPronto: cuenta(relojes, (r) => r.nivel === 'pronto'),
    medidasResguardoActivas: abiertos.reduce((s, c) => s + c.medidasResguardo.filter((m) => m.estado === 'implementada').length, 0), medidasResguardoPendientes: abiertos.reduce((s, c) => s + c.medidasResguardo.filter((m) => ['propuesta', 'ordenada'].includes(m.estado)).length, 0),
    porRama: sup(Object.keys(RAMAS).map((id) => ({ id, cantidad: cuenta(casos, (c) => c.ramaId === id) }))),
    porEtapa: sup(Object.keys(ETAPAS).map((id) => ({ id, cantidad: cuenta(abiertos, (c) => ESTADOS[c.estado].etapa === id) }))),
  };
}
// Eventos de dominio (§57) — puerta etiquetada. Contrato común (P0 de la revisión del 17-oct-2026): identificador de evento,
// clave de idempotencia determinística (reintentar no duplica), versión de esquema, tenant, entidad jurídica, actor, tiempo EFECTIVO
// (cuándo ocurrió el hecho, distinto de cuándo se emite), correlación y carga. La carga lleva SOLO identificadores opacos: nunca
// nombres, relatos, hechos ni las partes del caso. La auditoría persistente (§45) vive en `historial`; el bus real no existe todavía.
export const SCHEMA_EVENTOS_CASOS = '1.0';
export function crearEnvelopeEvento({ tipo, caso, actor = null, ocurridoEn, clave, payload = {}, emitidoEn = new Date().toISOString() }) {
  return {
    eventId: `evt:${tipo}:${caso.id}:${clave}`, idempotencyKey: `${tipo}|${caso.id}|${clave}`, schemaVersion: SCHEMA_EVENTOS_CASOS,
    tipo, dominioOrigen: 'workforce', tenantId: caso.tenantId, legalEntityId: caso.legalEntityId ?? null,
    actorRef: actor?.personaId || null, ocurridoEn, emitidoEn, correlationId: caso.id, versionCaso: caso.version, payload,
  };
}
export function construirCaseOpenedEvent(caso, emitidoEn) {
  return crearEnvelopeEvento({ tipo: 'CaseOpened', caso, actor: caso.historial[0]?.actor, ocurridoEn: caso.eventos.denuncia_recibida, clave: 'abierto', payload: { canalIngreso: caso.canalIngreso }, emitidoEn });
}
export function construirInvestigationStartedEvent(caso, emitidoEn) {
  if (!caso.eventos.investigacion_iniciada) return null;
  return crearEnvelopeEvento({ tipo: 'InvestigationStarted', caso, ocurridoEn: caso.eventos.investigacion_iniciada, clave: 'iniciada', emitidoEn });
}
export function construirInvestigationClosedEvent(caso, emitidoEn) {
  if (!caso.eventos.investigacion_concluida) return null;
  return crearEnvelopeEvento({ tipo: 'InvestigationClosed', caso, ocurridoEn: caso.eventos.investigacion_concluida, clave: 'concluida', emitidoEn });
}
export function construirCaseClosedEvent(caso, emitidoEn) {
  if (!caso.cierre) return null;
  return crearEnvelopeEvento({ tipo: 'CaseClosed', caso, ocurridoEn: caso.cierre.en, clave: 'cerrado', payload: { motivoCierre: caso.cierre.motivoCierre }, emitidoEn });
}

/* ---------------------------- identificadores (CUT provisional, lo inyecta MAIN) ----------------------------- */
const PAIS = 'CL', REGION = '13', CLINICA = 'AXON';
function hashLiviano(str) { let h = 0; for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) >>> 0; return h.toString(16).toUpperCase().padStart(2, '0').slice(-2); }
function makeCUT(seq) { const s = String(seq).padStart(8, '0'); return `CUT-${PAIS}-${REGION}-${CLINICA}-${s}-${hashLiviano(`CUT-${PAIS}-${REGION}-${CLINICA}-${s}`)}`; }
function calcDV(rutBody) { let suma = 0, mult = 2; for (let i = rutBody.length - 1; i >= 0; i--) { suma += parseInt(rutBody[i], 10) * mult; mult = mult === 7 ? 2 : mult + 1; } const resto = 11 - (suma % 11); if (resto === 11) return '0'; if (resto === 10) return 'K'; return String(resto); }
function fakeRUT(seed) { const body = String(9000000 + (seed * 7919) % 8900000); return body.slice(0, 2) + '.' + body.slice(2, 5) + '.' + body.slice(5) + '-' + calcDV(body); }

/* ═══════════════════════════════════════════════════════════════════════
   REGISTRO CANÓNICO — copiado desde WorkforcePersonas.jsx (misma versión
   compacta de Finiquito). test_roster.mjs verifica que se comporta igual
   en todos los archivos.
   ═══════════════════════════════════════════════════════════════════════ */
const NOMBRES_CANONICO = ['María José', 'Pedro', 'Camila', 'Rodrigo', 'Fernanda', 'Ignacio', 'Valentina', 'Cristóbal', 'Antonia', 'Matías', 'Javiera', 'Sebastián', 'Catalina', 'Diego', 'Francisca', 'Tomás', 'Constanza', 'Felipe', 'Josefa', 'Nicolás'];
const APELLIDOS_CANONICO = ['González', 'Muñoz', 'Rojas', 'Díaz', 'Pérez', 'Soto', 'Contreras', 'Silva', 'Martínez', 'Sepúlveda', 'Morales', 'Rodríguez', 'López', 'Fuentes', 'Hernández', 'Torres'];
const CARGOS_LISTA_CANONICO = ['medico', 'enfermeria', 'tens', 'kinesiologo', 'matrona', 'administrativo', 'auxiliar'];
const ESPECIALIDADES_LISTA_CANONICO = ['medico_especialista', 'psicologia', 'kinesiologia', 'nutricion', 'auditoria_clinica'];
const EMPRESAS_HONORARIO_CANONICO = ['Auditoría Clínica del Sur SpA', 'Diagnóstico Externo Ltda.'];
function fechaIngresoDesdeSeed(seed) { const d = 60 + (seed % 5000); const f = new Date(); f.setDate(f.getDate() - d); return f.toISOString().slice(0, 10); }
export function generarPersonasCanonico() {
  const personas = []; let seed = 100;
  for (let i = 0; i < 20; i++) {
    seed += 17; const esCore = i >= 17;
    personas.push({ id: `per_${1000 + i}`, cut: makeCUT(1000 + i), rut: fakeRUT(seed), nombres: NOMBRES_CANONICO[seed % NOMBRES_CANONICO.length], apellidoPaterno: APELLIDOS_CANONICO[(seed * 2) % APELLIDOS_CANONICO.length], apellidoMaterno: APELLIDOS_CANONICO[(seed * 5) % APELLIDOS_CANONICO.length], tipoRelacion: 'empleado', axonLinea: esCore ? 'axon_core' : 'axon_health', tenantId: esCore ? 'tenant_hospital_regional_demo' : null, sector: esCore ? 'publico' : 'privado', cargoId: CARGOS_LISTA_CANONICO[seed % CARGOS_LISTA_CANONICO.length], fechaIngreso: fechaIngresoDesdeSeed(seed) });
  }
  for (let i = 0; i < 10; i++) {
    seed += 23; const esEmpresa = i >= 8;
    personas.push({ id: `per_${2000 + i}`, cut: makeCUT(2000 + i), rut: fakeRUT(seed), nombres: esEmpresa ? null : NOMBRES_CANONICO[seed % NOMBRES_CANONICO.length], apellidoPaterno: esEmpresa ? null : APELLIDOS_CANONICO[(seed * 2) % APELLIDOS_CANONICO.length], apellidoMaterno: esEmpresa ? null : APELLIDOS_CANONICO[(seed * 5) % APELLIDOS_CANONICO.length], razonSocial: esEmpresa ? EMPRESAS_HONORARIO_CANONICO[i - 8] : null, tipoRelacion: 'honorario', tipoPersonaHonorario: esEmpresa ? 'empresa' : 'natural', axonLinea: 'axon_core_lite', tenantId: null, especialidadId: esEmpresa ? 'auditoria_clinica' : ESPECIALIDADES_LISTA_CANONICO[seed % (ESPECIALIDADES_LISTA_CANONICO.length - 1)] });
  }
  return personas;
}

/* ═══════════════════════════════════════════════════════════════════════
   MOCK — determinístico respecto de `hoyISO`. Se construye con las MISMAS operaciones del
   motor (así también las ejercita), usando como fecha de registro la fecha histórica de cada
   paso. Cubre: todas las etapas, las 5 ramas, canal DT, régimen estatutario público y Código
   del Trabajo dentro de una institución pública, art. 4 inc. 1, complemento, relojes en todos
   los niveles, una decisión sin medidas y un caso cerrado de punta a punta.
   ═══════════════════════════════════════════════════════════════════════ */
export const ACTOR_GENERAL_ID = 'per_1009'; // persona de RR.HH. sin rol en ningún caso
export const TENANT_DEMO_HEALTH = 'AXON-HEALTH', TENANT_DEMO_PUBLICO = 'HOSPITAL-REGIONAL-DEMO';
// DEMOSTRACIÓN: el tenant y la relación vigente del actor los resuelve el backend (MAIN); acá se fabrican para poder probar el aislamiento.
export function actorDemo(personaId, tenantId) { return { personaId, tenantId, relacionVigente: true }; }
export function generarCasosMock(personas, hoyISO) {
  const emp = personas.filter((p) => p.tipoRelacion === 'empleado');
  const id = (i) => emp[i].id;
  const rec = (c) => actorDemo(id(5), c.tenantId), resp = (c) => actorDemo(id(1), c.tenantId), inv = (c) => actorDemo(id(2), c.tenantId);
  const d = (n) => sumarDias(hoyISO, -n);
  const ok = (r) => { if (r.error) throw new Error(`mock: ${r.error}`); return r.caso; };
  let seq = 0;
  const nuevo = (o, fecha) => {
    seq++;
    const tenantId = o.tenantId || TENANT_DEMO_HEALTH;
    return ok(crearCaso({ id: `CL-2026-${String(seq).padStart(4, '0')}`, tenantId, sectorTenant: o.sector || 'privado', canalIngreso: o.canal || 'empleador', recibidaEn: fecha, denunciante: o.denunciante || { tipo: 'trabajador', personaId: id(10) }, denunciado: o.denunciado || { tipo: 'trabajador', personaId: id(15) }, relatoRef: `RELATO-${seq}`, responsableId: id(1), receptorId: id(5), actor: actorDemo(id(5), tenantId) }, fecha));
  };
  const clasif = (c, f, ramaId = 'acoso_violencia_legal', extra = {}) => ok(clasificarCaso(c, { ramaId, motivo: 'Hechos descritos en la denuncia', actor: rec(c), ...extra }, f));
  const resguardar = (c, f, tipo = 'separacion_espacios_fisicos') => {
    c = ok(proponerMedidaResguardo(c, { tipo, destinatarioId: c.denunciante.ref, fundamento: 'Resguardo inicial', actor: rec(c) }, f));
    const mid = c.medidasResguardo[c.medidasResguardo.length - 1].id;
    c = ok(ordenarMedidaResguardo(c, { medidaId: mid, actor: resp(c) }, f));
    return ok(implementarMedidaResguardo(c, { medidaId: mid, fecha: f, evidenciaRef: `EVID-RESG-${mid}`, actor: rec(c) }, f));
  };
  const evaluar = (c, f, riesgo = 'medio', tipo) => { c = resguardar(c, f, tipo); return ok(registrarEvaluacionInicial(c, { riesgo, decisionMedidas: 'aplicadas', actor: rec(c) }, f)); };
  const seleccionar = (c, f, procedimiento, fundamento) => ok(seleccionarProcedimiento(c, { procedimiento, fundamento, actor: resp(c) }, f));
  const investigar = (c, fAsig, fSel, fIni) => {
    c = ok(asignarRol(c, { personaId: id(2), rol: 'investigador', actor: rec(c) }, fAsig));
    c = seleccionar(c, fSel, 'investigacion_interna', 'Corresponde investigación interna');
    return ok(iniciarInvestigacion(c, { fecha: fIni, actor: rec(c) }, fIni));
  };
  const oirPartes = (c, f1, f2) => {
    c = ok(registrarActuacion(c, { tipo: 'declaracion', fecha: f1, participantes: [c.denunciante.ref], actor: inv(c) }, f1));
    return ok(registrarActuacion(c, { tipo: 'declaracion', fecha: f2, participantes: [c.denunciado.ref], actor: inv(c) }, f2));
  };
  const hastaConclusionesDT = (c, fConcl, fRem, fDT) => {
    c = ok(registrarConclusiones(c, { resultado: 'hechos_acreditados', referenciaInforme: `INF-${c.id.slice(-2)}`, fecha: fConcl, actor: inv(c) }, fConcl));
    c = ok(remitirInformeADT(c, { fecha: fRem, referencia: `ENVIO-${c.id.slice(-2)}`, actor: resp(c) }, fRem));
    return ok(registrarConclusionesDT(c, { fecha: fDT, referencia: `DT-NOT-${c.id.slice(-2)}`, actor: rec(c) }, fDT));
  };
  const casos = [];
  // 1-3: recién recibidas, sin decisión del empleador (reloj K1 con margen, urgente y vencido)
  casos.push(clasif(nuevo({}, d(0)), d(0)));
  casos.push(clasif(nuevo({}, d(2)), d(2)));
  casos.push(clasif(nuevo({}, d(5)), d(4)));
  // 4: investigación en curso, K2 «pronto»
  casos.push(investigar(evaluar(clasif(nuevo({}, d(25)), d(25)), d(24)), d(24), d(24), d(24)));
  // 5: investigación con K2 vencido
  let c5 = investigar(evaluar(clasif(nuevo({}, d(40)), d(40)), d(39)), d(39), d(39), d(38));
  c5 = ok(registrarActuacion(c5, { tipo: 'citacion', fecha: d(30), participantes: [c5.denunciante.ref], resultado: 'comparecio', actor: inv(c5) }, d(30)));
  casos.push(c5);
  // 6: investigación concluida, informe sin remitir (K3 urgente)
  let c6 = investigar(evaluar(clasif(nuevo({}, d(12)), d(12)), d(11)), d(11), d(11), d(10));
  c6 = oirPartes(c6, d(8), d(7));
  casos.push(ok(registrarConclusiones(c6, { resultado: 'hechos_acreditados', referenciaInforme: 'INF-006', fecha: d(1), actor: inv(c6) }, d(1))));
  // 7: denuncia contra persona del art. 4 inc. 1: derivación obligatoria a la DT
  let c7 = evaluar(clasif(nuevo({ denunciado: { tipo: 'trabajador', personaId: id(16), relacion: 'art4_inc1' } }, d(4)), d(4)), d(3));
  c7 = seleccionar(c7, d(3), 'derivacion_dt', 'Denuncia contra persona del art. 4 inc. 1');
  casos.push(ok(derivarADT(c7, { fecha: d(3), referencia: 'DT-DERIV-007', actor: resp(c7) }, d(3))));
  // 8: denuncia por complementar (ORD. 146/13)
  const c8 = nuevo({}, d(3));
  casos.push(ok(solicitarComplemento(c8, { plazoDias: 5, tipoDia: 'habil', fundamento: 'Faltan fechas y personas involucradas', actor: rec(c8) }, d(3))));
  // 9: convivencia, mediación opcional (sin relojes legales)
  let c9 = evaluar(clasif(nuevo({}, d(6)), d(6), 'convivencia'), d(5), 'bajo', 'redistribucion_jornada');
  casos.push(seleccionar(c9, d(5), 'mediacion_opcional', 'Conflicto interpersonal sin denuncia legal'));
  // 10: violencia de un paciente contra una TENS (sin procedimiento legal activado)
  let c10 = clasif(nuevo({ denunciante: { tipo: 'trabajador', personaId: id(12) }, denunciado: { tipo: 'tercero', ref: 'tercero:paciente-A' } }, d(2)), d(2), 'violencia_terceros');
  c10 = evaluar(c10, d(2), 'alto', 'atencion_psicologica_temprana');
  casos.push(seleccionar(c10, d(1), 'gestion_incidente_seguridad', 'Registrar el incidente y preservar evidencia'));
  // 11: caso cerrado de punta a punta (procedimiento legal completo)
  let c11 = investigar(evaluar(clasif(nuevo({}, d(80)), d(80)), d(79)), d(79), d(79), d(78));
  c11 = hastaConclusionesDT(oirPartes(c11, d(70), d(65)), d(55), d(54), d(30));
  c11 = ok(registrarMedidaCorrectiva(c11, { tipo: 'capacitacion', destinatarioId: c11.denunciado.ref, fundamento: 'Conforme al reglamento interno', actor: resp(c11) }, d(25)));
  c11 = ok(marcarMedidaAplicada(c11, { medidaId: 'c1', fecha: d(20), evidenciaRef: 'EVID-011', actor: resp(c11) }, d(20)));
  c11 = ok(registrarSeguimiento(c11, { medidaId: 'c1', resultado: 'cumplida', fecha: d(10), actor: resp(c11) }, d(10)));
  casos.push(ok(cerrarCaso(c11, { motivoCierre: 'medidas_aplicadas', fundamento: 'Medidas aplicadas y verificadas', actor: resp(c11) }, d(5))));
  // 12: amenaza grave: seguridad y derivación inmediata a autoridades
  let c12 = evaluar(clasif(nuevo({ denunciado: { tipo: 'tercero', ref: 'tercero:visitante-B' } }, d(1)), d(1), 'riesgo_fisico_delito'), d(1), 'inmediato');
  casos.push(seleccionar(c12, d(1), 'derivacion_autoridades', 'Riesgo inmediato: no se espera la investigación laboral'));
  // 13: institución pública con régimen estatutario declarado: procedimiento administrativo
  let c13 = evaluar(clasif(nuevo({ sector: 'publico', tenantId: TENANT_DEMO_PUBLICO }, d(10)), d(10), 'acoso_violencia_legal', { regimenJuridico: 'estatutario_publico' }), d(9));
  casos.push(seleccionar(c13, d(9), 'procedimiento_administrativo', 'Régimen estatutario público'));
  // 14: denuncia presentada ante la DT (reloj informativo)
  casos.push(clasif(nuevo({ canal: 'dt' }, d(1)), d(1)));
  // 15: recibida y sin clasificar (reloj K1 provisional)
  casos.push(nuevo({}, d(1)));
  // 16: institución pública con personal bajo el Código del Trabajo: aplica la ruta común (el sector no decide)
  casos.push(clasif(nuevo({ sector: 'publico', tenantId: TENANT_DEMO_PUBLICO }, d(2)), d(2), 'acoso_violencia_legal', { regimenJuridico: 'codigo_trabajo' }));
  // 17: etapa B: evaluación inicial hecha, sin procedimiento
  casos.push(evaluar(clasif(nuevo({}, d(3)), d(3)), d(2)));
  // 18: etapa F: conclusiones de la DT y decisión fundamentada de NO aplicar medidas (no cumple el plazo: queda para revisión)
  let c18 = investigar(evaluar(clasif(nuevo({}, d(60)), d(60)), d(59)), d(59), d(59), d(58));
  c18 = hastaConclusionesDT(oirPartes(c18, d(50), d(48)), d(40), d(39), d(20));
  casos.push(ok(declararSinMedidas(c18, { fundamento: 'Hechos no acreditados según las conclusiones', actor: resp(c18) }, d(15))));
  // 19: riesgo psicosocial u organizacional: evaluación de condiciones de trabajo (sin vía legal)
  let c19 = evaluar(clasif(nuevo({ denunciado: { tipo: 'desconocido' } }, d(7)), d(7), 'riesgo_psicosocial'), d(6), 'bajo', 'redistribucion_jornada');
  casos.push(seleccionar(c19, d(6), 'evaluacion_condiciones_trabajo', 'Carga y turnos del servicio'));
  return casos;
}

/* ═══════════════════════════ UI mínima ═══════════════════════════ */
const HOY = (() => { const d = new Date(); return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`; })();
const fmtDate = (iso) => (iso ? new Date(iso + 'T00:00:00').toLocaleDateString('es-CL', { day: '2-digit', month: 'short', year: 'numeric' }) : '—');
const NIVELES = {
  vencido: { label: 'Vencido', color: C.err, bg: C.errL }, urgente: { label: 'Urgente', color: '#C2410C', bg: '#FFEDD5' },
  pronto: { label: 'Pronto', color: C.warn, bg: C.warnL }, ok: { label: 'Con margen', color: C.pri, bg: C.priL },
};
const VISTAS = [
  ['receptor', 'Unidad de Casos'], ['responsable', 'Responsable (decide)'], ['investigador', 'Investigador/a'],
  ['denunciante', 'Denunciante'], ['denunciado', 'Denunciado/a'], ['general', 'RR.HH. sin rol en el caso'],
];
function actorDeVista(caso, vista) {
  const a = caso.asignaciones;
  const m = { receptor: a.receptores[0], responsable: a.responsableId, investigador: a.investigadorId, denunciante: caso.denunciante.ref, denunciado: caso.denunciado.ref, general: ACTOR_GENERAL_ID };
  return actorDemo(m[vista] || null, caso.tenantId);
}

const Badge = ({ color, bg, icon: Icon, children }) => (<span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, padding: '3px 9px', borderRadius: 999, fontSize: 12, fontWeight: 600, color, background: bg || color + '18', whiteSpace: 'nowrap' }}>{Icon && <Icon size={12} />}{children}</span>);
const Btn = ({ variant = 'ghost', icon: Icon, children, onClick, style, title }) => {
  const base = { display: 'inline-flex', alignItems: 'center', gap: 7, padding: '9px 15px', borderRadius: C.rSm, fontSize: 13.5, fontWeight: 600, cursor: 'pointer', border: '1px solid transparent', fontFamily: C.font };
  const variants = { primary: { background: C.pri, color: '#fff' }, outline: { background: '#fff', color: C.ink, border: `1px solid ${C.border}` }, ghost: { background: 'transparent', color: C.sub } };
  return (<button type="button" title={title} onClick={onClick} style={{ ...base, ...variants[variant], ...style }}>{Icon && <Icon size={15} />}{children}</button>);
};
const KPICard = ({ label, value, sub, icon: Icon, accent }) => (<div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, padding: '14px 16px', boxShadow: C.shadow, flex: 1, minWidth: 170 }}><div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}><span style={{ fontSize: 12, color: C.sub, fontWeight: 600 }}>{label}</span><Icon size={14} style={{ color: accent }} /></div><div style={{ fontSize: 20, fontWeight: 700, color: C.ink }}>{value}</div>{sub && <div style={{ fontSize: 11.5, color: C.mut, marginTop: 2 }}>{sub}</div>}</div>);
const FieldLabel = ({ children }) => <label style={{ fontSize: 11.5, fontWeight: 600, color: C.sub, marginBottom: 5, display: 'block' }}>{children}</label>;
const inputStyle = { width: '100%', padding: '8px 10px', borderRadius: C.rSm, border: `1px solid ${C.border}`, fontSize: 13.5, fontFamily: C.font, color: C.ink, outline: 'none', boxSizing: 'border-box', background: '#fff' };
const thStyle = { padding: '9px 12px', fontSize: 11, fontWeight: 700, color: C.sub, textTransform: 'uppercase' };
const Overlay = ({ onClose, width, children }) => (
  <div style={{ position: 'fixed', inset: 0, background: 'rgba(16,24,40,.45)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100, padding: 20 }} onClick={onClose}>
    <div style={{ background: '#fff', borderRadius: C.rLg, width, maxWidth: '100%', maxHeight: '90vh', overflowY: 'auto', boxShadow: '0 20px 50px rgba(16,24,40,.25)' }} onClick={(ev) => ev.stopPropagation()}>{children}</div>
  </div>
);
const ModalHead = ({ title, sub, onClose }) => (
  <div style={{ padding: '16px 20px', borderBottom: `1px solid ${C.border}`, display: 'flex', justifyContent: 'space-between' }}>
    <div><div style={{ fontSize: 14, fontWeight: 700, color: C.ink }}>{title}</div><div style={{ fontSize: 11.5, color: C.mut }}>{sub}</div></div>
    <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: C.mut }}><X size={18} /></button>
  </div>
);
const fila = (l, v) => (<div key={l} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12.5, color: C.sub, marginBottom: 4, gap: 10 }}><span>{l}</span><span style={{ color: C.ink, fontWeight: 600, textAlign: 'right' }}>{v}</span></div>);
function textoReloj(r) {
  const u = TIPOS_DIA[r.tipoDia].label.split(' ')[0];
  if (r.estado === 'cumplido') return `Cumplido el ${fmtDate(r.cumplidoEn)}`;
  if (r.estado === 'decidido_sin_medidas') return `Decisión de no aplicar medidas el ${fmtDate(r.decididoEn)}`;
  if (r.diasRestantes < 0) return `Venció hace ${-r.diasRestantes} día(s) ${u}`;
  return r.diasRestantes === 0 ? 'Vence HOY' : `Quedan ${r.diasRestantes} día(s) ${u}`;
}

function DetailModal({ caso, personas, onClose }) {
  const [vista, setVista] = useState('receptor');
  const actor = actorDeVista(caso, vista);
  const proy = proyectarCaso(caso, actor);
  const relojes = proy.nivel === 'completo' ? calcularRelojes(caso, HOY) : [];
  const enr = caso.ramaId && proy.nivel === 'completo' ? evaluarEnrutamiento(caso) : null;
  const est = ESTADOS[caso.estado];
  return (
    <Overlay onClose={onClose} width={620}>
      <ModalHead title={`Caso ${caso.id}`} sub={`${caso.ramaId ? RAMAS[caso.ramaId].label : 'Sin clasificar'} · ${est.label}`} onClose={onClose} />
      <div style={{ padding: 20, display: 'flex', flexDirection: 'column', gap: 14 }}>
        <div>
          <FieldLabel>Ver como — DEMOSTRACIÓN: en producción la reserva, el aislamiento por tenant y la relación vigente los aplica el backend, no esta pantalla</FieldLabel>
          <select style={inputStyle} value={vista} onChange={(ev) => setVista(ev.target.value)}>{VISTAS.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</select>
        </div>
        {proy.nivel === null && (<div style={{ display: 'flex', gap: 8, background: C.errL, padding: 12, borderRadius: C.rSm, fontSize: 12.5, color: C.err }}><Lock size={14} style={{ flexShrink: 0, marginTop: 1 }} /><span>Expediente reservado. {proy.motivo}.</span></div>)}
        {proy.nivel === 'parte' && (
          <div style={{ background: C.bg, borderRadius: C.rSm, padding: 12 }}>
            <div style={{ fontSize: 11.5, fontWeight: 700, color: C.sub, textTransform: 'uppercase', marginBottom: 8 }}>Vista de parte ({proy.roles.join(', ')})</div>
            {fila('Etapa', `${proy.vista.etapa} · ${ETAPAS[proy.vista.etapa]}`)}
            {fila('Estado', ESTADOS[proy.vista.estado].label)}
            {fila('Procedimiento', proy.vista.procedimiento ? PROCEDIMIENTOS[proy.vista.procedimiento].label : '—')}
            {fila('Actuaciones en que participó', proy.vista.actuacionesPropias.length)}
            {fila('Medidas de resguardo que le aplican', proy.vista.medidasQueLeAplican.length)}
            {fila('Conclusiones', proy.vista.conclusiones ? fmtDate(proy.vista.conclusiones.fecha) : 'Aún no')}
            <div style={{ fontSize: 11, color: C.mut, marginTop: 6 }}>No ve declaraciones ni pruebas de la otra parte, notas del investigador, conflictos ni el historial interno.</div>
          </div>
        )}
        {proy.nivel === 'completo' && (<>
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
            {Object.entries(ETAPAS).map(([k, l]) => (<Badge key={k} color={est.etapa === k ? C.pri : C.mut} bg={est.etapa === k ? C.priL : C.bg}>{k} · {l}</Badge>))}
          </div>
          {caso.regimenJuridico === 'estatutario_publico' && <div style={{ fontSize: 12, color: C.warn, background: C.warnL, padding: 10, borderRadius: C.rSm }}>Régimen estatutario público: no aplican los relojes del paquete del Código del Trabajo; los plazos del estatuto no están modelados.</div>}
          <div style={{ background: C.bg, borderRadius: C.rSm, padding: 12 }}>
            <div style={{ fontSize: 11.5, fontWeight: 700, color: C.sub, textTransform: 'uppercase', marginBottom: 8 }}>Relojes</div>
            {relojes.length === 0 && <div style={{ fontSize: 12, color: C.mut }}>Sin relojes activos en este caso.</div>}
            {relojes.map((r) => { const niv = r.nivel ? NIVELES[r.nivel] : null; return (
              <div key={r.reglaId} style={{ padding: '6px 0', borderBottom: `1px solid ${C.border}` }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', gap: 8, alignItems: 'center' }}>
                  <span style={{ fontSize: 12.5, color: C.ink, fontWeight: 600 }}>{r.nombre}{r.informativa ? ' (informativo: obligación de la DT)' : ''}{r.provisional ? ' (provisional: sin clasificar)' : ''}</span>
                  {niv ? <Badge color={niv.color} bg={niv.bg}>{niv.label}</Badge> : r.estado === 'decidido_sin_medidas' ? <Badge color={C.warn} bg={C.warnL}>Sin medidas: revisar</Badge> : <Badge color={C.pri}>Cumplido</Badge>}
                </div>
                <div style={{ fontSize: 11.5, color: C.sub }}>{textoReloj(r)} · vence {fmtDate(r.vencimientoOperativo)}{r.ambigua ? ` (máx. ${fmtDate(r.vencimientoMaximo)}, ${r.variantes} variantes)` : ''}{r.validada === false ? ' · regla no validada' : ''}</div>
                {r.advertencias.length > 0 && <div style={{ fontSize: 11, color: C.warn }}>Aviso: {r.advertencias.join(', ')}</div>}
              </div>); })}
          </div>
          {enr && (<div style={{ background: C.bg, borderRadius: C.rSm, padding: 12 }}>
            <div style={{ fontSize: 11.5, fontWeight: 700, color: C.sub, textTransform: 'uppercase', marginBottom: 8 }}>Enrutamiento</div>
            {fila('Procedimientos permitidos', enr.permitidos.map((p) => PROCEDIMIENTOS[p].label).join(' · '))}
            {fila('Procedimiento elegido', caso.procedimiento ? PROCEDIMIENTOS[caso.procedimiento].label : 'Aún no')}
            {enr.motivos.map((m, i) => <div key={i} style={{ fontSize: 11.5, color: C.warn, marginTop: 4 }}>{m}</div>)}
            {enr.acciones.length > 0 && <div style={{ fontSize: 11.5, color: C.err, marginTop: 4 }}>Acciones inmediatas: {enr.acciones.join(', ').replace(/_/g, ' ')}.</div>}
          </div>)}
          <div style={{ background: C.bg, borderRadius: C.rSm, padding: 12 }}>
            {fila('Medidas de resguardo (implementadas / total)', `${caso.medidasResguardo.filter((m) => m.estado === 'implementada').length} / ${caso.medidasResguardo.length}`)}
            {fila('Actuaciones (reservadas)', caso.actuaciones.length)}
            {fila('Evaluaciones profesionales (informe fuera del expediente)', caso.evaluacionesProfesionales.length)}
            {fila('Medidas correctivas', `${caso.medidasCorrectivas.filter((m) => m.estado === 'aplicada').length} / ${caso.medidasCorrectivas.length} aplicadas`)}
            {fila('Entradas de historial', caso.historial.length)}
          </div>
          <div style={{ display: 'flex', gap: 6, alignItems: 'flex-start', fontSize: 11, color: C.mut }}><Send size={12} style={{ flexShrink: 0, marginTop: 1 }} /><span>Evento CaseOpened — puerta etiquetada hacia el bus (§57); solo identificadores opacos, sin nombres ni hechos.</span></div>
          <pre style={{ fontSize: 10, background: C.ink, color: '#D4CBEF', padding: 10, borderRadius: C.rSm, overflowX: 'auto', margin: 0 }}>{JSON.stringify(construirCaseOpenedEvent(caso), null, 2)}</pre>
        </>)}
      </div>
    </Overlay>
  );
}

export default function WorkforceCasosLaborales({ addToast }) {
  const toast = addToast || ((m) => console.log(m));
  const [personas] = useState(generarPersonasCanonico);
  const [casos] = useState(() => generarCasosMock(personas, HOY));
  const [tab, setTab] = useState('casos');
  const [filtros, setFiltros] = useState({ estado: 'todos', rama: 'todas', q: '' });
  const [selId, setSelId] = useState(null);
  const [page, setPage] = useState(1);
  const perPage = 8;

  const kpi = useMemo(() => calcularKPIsCasos(casos, HOY), [casos]);
  const alertas = useMemo(() => calcularAlertasCasos(casos, HOY), [casos]);
  const proximo = useMemo(() => { const m = {}; alertas.forEach((a) => { if (!m[a.casoId]) m[a.casoId] = a.reloj; }); return m; }, [alertas]);
  const filas = useMemo(() => casos.filter((c) => {
    if (filtros.estado !== 'todos' && c.estado !== filtros.estado) return false;
    if (filtros.rama !== 'todas' && (c.ramaId || 'sin') !== filtros.rama) return false;
    if (filtros.q && !c.id.toLowerCase().includes(filtros.q.toLowerCase())) return false;
    return true;
  }), [casos, filtros]);
  const totalPages = Math.max(1, Math.ceil(filas.length / perPage));
  const pageRows = filas.slice((page - 1) * perPage, page * perPage);
  const setFiltro = (k, v) => { setFiltros({ ...filtros, [k]: v }); setPage(1); };
  const sel = selId ? casos.find((c) => c.id === selId) : null;
  const validacion = useMemo(() => validarPaqueteReglas(PAQUETE_REGLAS_CL_BORRADOR), []);

  const exportarCSV = () => {
    const header = ['Caso', 'Rama', 'Etapa', 'Estado', 'Procedimiento', 'Recibida', 'Reloj más próximo', 'Vence'];
    const lines = filas.map((c) => { const r = proximo[c.id]; return [c.id, c.ramaId ? RAMAS[c.ramaId].label : 'Sin clasificar', ESTADOS[c.estado].etapa, ESTADOS[c.estado].label, c.procedimiento ? PROCEDIMIENTOS[c.procedimiento].label : '', c.eventos.denuncia_recibida, r ? r.nombre : '', r ? r.vencimientoOperativo : ''].join(';'); });
    const blob = new Blob([header.join(';') + '\n' + lines.join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = 'casos_laborales.csv'; a.click(); URL.revokeObjectURL(url); toast('CSV descargado (sin nombres ni relatos)');
  };

  return (
    <div style={{ fontFamily: C.font, background: C.bg, minHeight: '100%', padding: 22 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 16, flexWrap: 'wrap', gap: 10 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
          <div style={{ width: 32, height: 32, borderRadius: 8, background: C.priL, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Scale size={16} style={{ color: C.pri }} /></div>
          <div><div style={{ fontSize: 17, fontWeight: 700, color: C.ink }}>Casos laborales</div><div style={{ fontSize: 12, color: C.mut }}>Workforce · Ley Karin y convivencia: flujo A-F, ramas, relojes y reserva — Documento Maestro §40-45</div></div>
        </div>
        <Btn variant="outline" icon={Download} onClick={exportarCSV}>Exportar CSV</Btn>
      </div>

      <div style={{ display: 'flex', gap: 8, alignItems: 'flex-start', background: C.warnL, border: `1px solid ${C.warn}30`, borderRadius: C.rSm, padding: '10px 14px', marginBottom: 14, fontSize: 12, color: C.warn }}>
        <AlertTriangle size={14} style={{ flexShrink: 0, marginTop: 1 }} />
        <span>{PAQUETE_REGLAS_CL_BORRADOR.aviso} {validacion.ambiguas.length} de {PAQUETE_REGLAS_CL_BORRADOR.reglas.length} reglas son ambiguas: el motor alerta por la variante más temprana.</span>
      </div>

      <div style={{ display: 'flex', gap: 12, marginBottom: 16, flexWrap: 'wrap' }}>
        <KPICard label="Casos abiertos" value={kpi.abiertos} sub={`${kpi.cerrados} cerrados · ${kpi.sinClasificar} sin clasificar`} icon={FileText} accent={C.pri} />
        <KPICard label="Relojes vencidos" value={kpi.relojesVencidos} sub={`${kpi.relojesUrgentes} urgentes · ${kpi.relojesPronto} pronto`} icon={Hourglass} accent={C.err} />
        <KPICard label="Denuncias por complementar" value={kpi.porComplementar} sub="ORD. N.º 146/13: no se archivan" icon={Clock} accent={C.warn} />
        <KPICard label="Derivados a la DT" value={kpi.derivadosDT} sub={`${kpi.medidasResguardoActivas} medidas de resguardo activas`} icon={ShieldCheck} accent={C.teal} />
      </div>

      <div style={{ marginBottom: 16 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}><AlertTriangle size={15} style={{ color: C.warn }} /><span style={{ fontSize: 13, fontWeight: 700, color: C.ink }}>Alertas — plazos del empleador</span><Badge color={alertas.length ? C.warn : C.mut} bg={alertas.length ? C.warnL : C.bg}>{alertas.length}</Badge></div>
        {alertas.slice(0, 6).map((a) => { const niv = NIVELES[a.reloj.nivel]; return (
          <div key={a.casoId + a.reloj.reglaId} style={{ background: niv.bg, border: `1px solid ${niv.color}30`, borderRadius: C.rSm, padding: '9px 14px', marginBottom: 6, display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 10, flexWrap: 'wrap' }}>
            <div style={{ fontSize: 12.5, color: C.ink }}><b>{a.casoId}</b> · {a.reloj.nombre}{a.reloj.provisional ? ' (provisional)' : ''}</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}><Badge color={niv.color} bg="#fff">{niv.label} · {textoReloj(a.reloj)}</Badge><Btn variant="outline" icon={Eye} onClick={() => setSelId(a.casoId)} style={{ padding: '5px 10px', fontSize: 12 }}>Ver</Btn></div>
          </div>); })}
      </div>

      <div style={{ display: 'flex', gap: 6, marginBottom: 12 }}>
        {[['casos', 'Casos'], ['reglas', 'Reglas de plazo (borrador)']].map(([k, l]) => <Btn key={k} variant={tab === k ? 'primary' : 'outline'} onClick={() => setTab(k)}>{l}</Btn>)}
      </div>

      {tab === 'casos' ? (<>
        <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, padding: 14, boxShadow: C.shadow, marginBottom: 12, display: 'flex', gap: 10, flexWrap: 'wrap', alignItems: 'end' }}>
          <div style={{ minWidth: 170 }}><FieldLabel>Estado</FieldLabel><select style={inputStyle} value={filtros.estado} onChange={(ev) => setFiltro('estado', ev.target.value)}><option value="todos">Todos</option>{Object.entries(ESTADOS).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}</select></div>
          <div style={{ minWidth: 200 }}><FieldLabel>Rama</FieldLabel><select style={inputStyle} value={filtros.rama} onChange={(ev) => setFiltro('rama', ev.target.value)}><option value="todas">Todas</option><option value="sin">Sin clasificar</option>{Object.entries(RAMAS).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}</select></div>
          <div style={{ position: 'relative', flex: 1, minWidth: 160 }}><Search size={13} style={{ position: 'absolute', left: 8, top: 11, color: C.mut }} /><input placeholder="Buscar por número de caso" value={filtros.q} onChange={(ev) => setFiltro('q', ev.target.value)} style={{ ...inputStyle, paddingLeft: 26 }} /></div>
          <Btn variant="ghost" icon={RotateCcw} onClick={() => { setFiltros({ estado: 'todos', rama: 'todas', q: '' }); setPage(1); }}>Limpiar</Btn>
        </div>
        <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, boxShadow: C.shadow, overflow: 'hidden' }}>
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
              <thead><tr style={{ background: C.bg, textAlign: 'left' }}>{['Caso', 'Rama', 'Etapa · Estado', 'Procedimiento', 'Reloj más próximo', ''].map((h) => <th key={h} style={thStyle}>{h}</th>)}</tr></thead>
              <tbody>
                {pageRows.map((c) => { const r = proximo[c.id], niv = r ? NIVELES[r.nivel] : null; return (
                  <tr key={c.id} style={{ borderTop: `1px solid ${C.border}`, cursor: 'pointer' }} onClick={() => setSelId(c.id)}>
                    <td style={{ padding: '10px 12px', fontWeight: 600, color: C.ink, whiteSpace: 'nowrap' }}><Lock size={11} style={{ color: C.mut, marginRight: 5 }} />{c.id}</td>
                    <td style={{ padding: '10px 12px', color: C.sub }}>{c.ramaId ? RAMAS[c.ramaId].label : 'Sin clasificar'}</td>
                    <td style={{ padding: '10px 12px' }}><Badge color={C.pri} bg={C.priL}>{ESTADOS[c.estado].etapa}</Badge> <span style={{ color: C.sub, fontSize: 12.5 }}>{ESTADOS[c.estado].label}</span></td>
                    <td style={{ padding: '10px 12px', color: C.sub, fontSize: 12.5 }}>{c.procedimiento ? PROCEDIMIENTOS[c.procedimiento].label : '—'}</td>
                    <td style={{ padding: '10px 12px' }}>{niv ? <Badge color={niv.color} bg={niv.bg}>{niv.label} · {textoReloj(r)}</Badge> : <span style={{ color: C.mut, fontSize: 12 }}>—</span>}</td>
                    <td style={{ padding: '10px 12px' }}><Eye size={14} style={{ color: C.mut }} /></td>
                  </tr>); })}
                {pageRows.length === 0 && <tr><td colSpan={6} style={{ padding: '36px 12px', textAlign: 'center', color: C.mut, fontSize: 13 }}>No hay casos con estos filtros.</td></tr>}
              </tbody>
            </table>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 14px', borderTop: `1px solid ${C.border}` }}>
            <span style={{ fontSize: 12, color: C.mut }}>{filas.length} casos · página {page} de {totalPages}</span>
            <div style={{ display: 'flex', gap: 6 }}>
              <Btn variant="outline" onClick={() => setPage(Math.max(1, page - 1))} style={{ padding: '6px 12px', opacity: page === 1 ? 0.4 : 1 }}>Anterior</Btn>
              <Btn variant="outline" onClick={() => setPage(Math.min(totalPages, page + 1))} style={{ padding: '6px 12px', opacity: page === totalPages ? 0.4 : 1 }}>Siguiente</Btn>
            </div>
          </div>
        </div>
      </>) : (
        <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, boxShadow: C.shadow, overflow: 'hidden' }}>
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
              <thead><tr style={{ background: C.bg, textAlign: 'left' }}>{['Regla', 'Actor', 'Plazos', 'Tipos de día', 'Inicia con', 'Fuente', 'Estado'].map((h) => <th key={h} style={thStyle}>{h}</th>)}</tr></thead>
              <tbody>
                {PAQUETE_REGLAS_CL_BORRADOR.reglas.map((r) => (
                  <tr key={r.id} style={{ borderTop: `1px solid ${C.border}`, verticalAlign: 'top' }}>
                    <td style={{ padding: '10px 12px', color: C.ink, fontWeight: 600 }}>{r.nombre}<div style={{ fontSize: 10.5, color: C.mut, fontWeight: 400 }}>{r.id}</div></td>
                    <td style={{ padding: '10px 12px', color: C.sub }}>{r.actor === 'dt' ? 'DT' : 'Empleador'}{r.informativa ? ' (informativa)' : ''}</td>
                    <td style={{ padding: '10px 12px', color: C.sub }}>{r.plazos.join(' / ')}</td>
                    <td style={{ padding: '10px 12px', color: C.sub, fontSize: 12 }}>{r.tiposDia.map((t) => TIPOS_DIA[t].label.split(' ')[0]).join(' / ')}</td>
                    <td style={{ padding: '10px 12px', color: C.sub, fontSize: 12 }}>{r.inicios.join(' / ').replace(/_/g, ' ')}</td>
                    <td style={{ padding: '10px 12px', color: C.sub, fontSize: 11.5, maxWidth: 260 }}>{r.fuente}</td>
                    <td style={{ padding: '10px 12px' }}><Badge color={C.warn} bg={C.warnL}>No validada</Badge></td>
                  </tr>))}
              </tbody>
            </table>
          </div>
          <div style={{ padding: '10px 14px', borderTop: `1px solid ${C.border}`, fontSize: 11.5, color: C.mut, display: 'flex', gap: 6 }}><Info size={12} style={{ flexShrink: 0, marginTop: 1 }} /><span>Cuando una regla tiene varias variantes de plazo, tipo de día o inicio, las alertas usan la fecha más temprana y se muestra también la más tardía. Hasta que el abogado valide cada regla, este paquete no es apto para producción.</span></div>
        </div>
      )}

      {sel && <DetailModal caso={sel} personas={personas} onClose={() => setSelId(null)} />}
    </div>
  );
}
