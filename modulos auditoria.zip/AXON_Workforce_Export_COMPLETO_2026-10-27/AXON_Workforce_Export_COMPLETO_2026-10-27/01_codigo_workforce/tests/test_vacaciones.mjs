import { calcularAntiguedad, calcularDerechoFeriadoAnual, calcularSaldoFeriado, calcularPermisoEspecial, construirAusenciaParaRemuneraciones, calcularKPIsVacacionesPermisos } from './bundles/Vacaciones.mjs';

let fallas = 0;
function check(n, c, d) { if (!c) { fallas++; console.log(`❌ ${n} — ${d || ''}`); } else console.log(`✅ ${n}`); }

const a1 = calcularAntiguedad('2024-09-11', '2026-09-11');
check('2 años calendario exactos → aniosCompletos = 2 (bug de 365.25 corregido)', a1.aniosCompletos === 2, `fue ${a1.aniosCompletos}`);
const a2 = calcularAntiguedad('2026-06-11', '2026-09-11');
check('3 meses → aniosCompletos = 0, mesesCompletos = 3', a2.aniosCompletos === 0 && a2.mesesCompletos === 3);
check('diffDias exacto en calendario aunque cruce un cambio de horario (11-jun → 11-sep = 92)', a2.diffDias === 92, `fue ${a2.diffDias}`);
check('diffDias exacto cruzando el cambio de abril (1-feb → 1-may = 89)', calcularAntiguedad('2026-02-01', '2026-05-01').diffDias === 89);

check('9 años: sin progresivo, 15 días', calcularDerechoFeriadoAnual(9).diasPorAnio === 15);
check('10 años exactos: todavía sin progresivo', calcularDerechoFeriadoAnual(10).diasPorAnio === 15);
check('13 años: +1 día (16)', calcularDerechoFeriadoAnual(13).diasPorAnio === 16);
check('16 años: +2 días (17)', calcularDerechoFeriadoAnual(16).diasPorAnio === 17);
check('22 años: +4 días (19)', calcularDerechoFeriadoAnual(22).diasPorAnio === 19);

const wProp = { fechaIngreso: '2026-06-11' };
const sProp = calcularSaldoFeriado(wProp, 0, '2026-09-11');
check('menos de 1 año: proporcional', sProp.tipo === 'proporcional');
check('proporcional: 3 meses×1,25=3,75→redondeado 3,8', sProp.diasDerechoAcumulado === 3.8);

const wUnAnio = { fechaIngreso: '2024-09-11' };
const sUnAnio = calcularSaldoFeriado(wUnAnio, 0, '2026-09-11');
check('2 años sin tomar: derecho = 15×2 = 30', sUnAnio.diasDerechoAcumulado === 30);
check('2 años sin tomar: disponible = 30', sUnAnio.diasDisponibles === 30);
const sConTomados = calcularSaldoFeriado(wUnAnio, 20, '2026-09-11');
check('2 años, tomó 20: disponible = 10', sConTomados.diasDisponibles === 10);

const wMuchos = { fechaIngreso: '2019-09-11' };
const sAcumulado = calcularSaldoFeriado(wMuchos, 0, '2026-09-11');
check('7 años sin tomar: excede tope de 2 períodos', sAcumulado.excedeAcumulacion === true);
check('2 años sin tomar: NO excede el tope (justo el límite)', sUnAnio.excedeAcumulacion === false);

const pMatrimonio = calcularPermisoEspecial('matrimonio_auc', '2026-06-15');
check('matrimonio: 5 días hábiles', pMatrimonio.dias === 5 && pMatrimonio.tipoConteo === 'habiles');
const pNacimiento = calcularPermisoEspecial('nacimiento_hijo', '2026-06-15');
check('nacimiento: 5 días corridos, término = inicio+4', pNacimiento.fechaTermino === '2026-06-19');
const pDueloHijo = calcularPermisoEspecial('duelo_hijo', '2026-06-15');
check('duelo hijo: 10 días corridos', pDueloHijo.dias === 10 && pDueloHijo.tipoConteo === 'corridos');
const pDueloConyuge = calcularPermisoEspecial('duelo_conyuge', '2026-06-15');
check('duelo cónyuge: 7 días corridos', pDueloConyuge.dias === 7 && pDueloConyuge.tipoConteo === 'corridos');
const pDueloGestacion = calcularPermisoEspecial('duelo_hijo_gestacion', '2026-06-15');
check('duelo hijo en gestación: 7 días HÁBILES', pDueloGestacion.dias === 7 && pDueloGestacion.tipoConteo === 'habiles');
const pDueloFamiliar = calcularPermisoEspecial('duelo_hermano_padre_madre', '2026-06-15');
check('duelo hermano/padre/madre: 4 días hábiles', pDueloFamiliar.dias === 4 && pDueloFamiliar.tipoConteo === 'habiles');

const ausencia = construirAusenciaParaRemuneraciones({ workerId: 'w1', dias: 15, tipoId: 'feriado_legal' });
check('feriado: 0 días no remunerados (mismo campo que Licencias)', ausencia.diasNoRemuneradosPorEmpleador === 0);

const kpis = calcularKPIsVacacionesPermisos([{ tipoId: 'feriado_legal', dias: 15, estado: 'aprobada' }, { tipoId: 'feriado_legal', dias: 10, estado: 'pendiente' }, { tipoId: 'matrimonio_auc', dias: 5, estado: 'aprobada' }]);
check('feriadoLegal=2, permisosEspeciales=1', kpis.feriadoLegal === 2 && kpis.permisosEspeciales === 1);
check('totalDiasFeriadoSolicitados = 25', kpis.totalDiasFeriadoSolicitados === 25);

console.log(`\n${fallas === 0 ? '✅ TODO OK' : `❌ ${fallas} FALLA(S)`} — Vacaciones y Permisos`);
process.exit(fallas === 0 ? 0 : 1);
