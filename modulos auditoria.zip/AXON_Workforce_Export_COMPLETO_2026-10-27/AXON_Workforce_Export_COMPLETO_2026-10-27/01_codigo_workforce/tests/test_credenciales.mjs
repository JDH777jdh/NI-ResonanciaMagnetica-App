import {
  diferenciaDias, sumarDias, sumarMeses, calcularVigenteHasta, calcularEstadoCredencial,
  elegirCredencialActual, evaluarAptitud, calcularAlertasCredenciales, renovarCredencial,
  suspenderCredencial, levantarSuspension, revocarCredencial, construirCredentialIssuedEvent,
  construirCredentialExpiredEvent, calcularKPIsCredenciales, calcularKPIsAptitud,
  generarCredencialesMock, generarPersonasCanonico,
} from './bundles/Credenciales.mjs';

let fallas = 0;
function check(n, c, d) { if (!c) { fallas++; console.log(`❌ ${n} — ${d || ''}`); } else console.log(`✅ ${n}`); }

const HOY = '2026-10-03';
const cred = (o) => ({ id: 'c1', personaId: 'p1', tipoId: 'rcp_bls', version: 1, reemplazaA: null, reemplazadaPorId: null, reemplazadaDesde: null, motivoCierre: null, emitidaEn: '2026-01-01', vigenteDesde: '2026-01-01', vigenteHasta: '2027-12-31', nivel: null, suspensiones: [], revocacion: null, ...o });
const estado = (o, hoy = HOY) => calcularEstadoCredencial(cred(o), hoy);
const susp = (o) => ({ desde: '2026-09-01', hasta: null, motivo: 'm', actor: 'a', registradaEn: '2026-09-01', levantadaEn: null, ...o });
const revoc = { en: '2026-09-01', motivo: 'm', actor: 'a' };

// ── Fechas (UTC puro) ──
check('diferenciaDias: 28-feb → 1-mar (año normal) = 1', diferenciaDias('2026-02-28', '2026-03-01') === 1);
check('diferenciaDias: 28-feb → 1-mar (año bisiesto) = 2', diferenciaDias('2028-02-28', '2028-03-01') === 2);
check('diferenciaDias negativa', diferenciaDias('2026-10-03', '2026-10-01') === -2);
check('sumarDias cruza el año', sumarDias('2026-12-31', 1) === '2027-01-01');
check('sumarMeses ajusta fin de mes (31-ene +1 = 28-feb)', sumarMeses('2026-01-31', 1) === '2026-02-28');
check('sumarMeses en bisiesto (31-ene-2028 +1 = 29-feb)', sumarMeses('2028-01-31', 1) === '2028-02-29');
check('sumarMeses cruza el año', sumarMeses('2026-11-15', 3) === '2027-02-15');
check('vigencia 24 meses desde 15-ene-2026 termina 14-ene-2028', calcularVigenteHasta('2026-01-15', 24) === '2028-01-14');
check('sin meses por defecto → sin vencimiento', calcularVigenteHasta('2026-01-15', null) === null);

// ── Estado derivado ──
const eV = estado({});
check('vigente con vencimiento lejano: urgencia ok', eV.estado === 'vigente' && eV.urgencia === 'ok');
check('diasParaVencer = 454 (3-oct-2026 → 31-dic-2027)', eV.diasParaVencer === 454, `fue ${eV.diasParaVencer}`);
const eHoy = estado({ vigenteHasta: HOY });
check('vence HOY: sigue vigente (límite inclusivo), 0 días, urgente', eHoy.estado === 'vigente' && eHoy.diasParaVencer === 0 && eHoy.urgencia === 'urgente');
const eAyer = estado({ vigenteHasta: '2026-10-02' });
check('venció ayer: vencida, -1 día, nivel vencido', eAyer.estado === 'vencida' && eAyer.diasParaVencer === -1 && eAyer.urgencia === 'vencido');
check('vigenteDesde en el futuro: aún no rige', estado({ vigenteDesde: '2026-10-08' }).estado === 'emitida');
const eSin = estado({ vigenteHasta: null });
check('sin vencimiento: vigente, sin días ni urgencia', eSin.estado === 'vigente' && eSin.diasParaVencer === null && eSin.urgencia === null);
check('umbral: 30 días = urgente', estado({ vigenteHasta: sumarDias(HOY, 30) }).urgencia === 'urgente');
check('umbral: 31 días = pronto', estado({ vigenteHasta: sumarDias(HOY, 31) }).urgencia === 'pronto');
check('umbral: 60 días = pronto', estado({ vigenteHasta: sumarDias(HOY, 60) }).urgencia === 'pronto');
check('umbral: 61 días = con margen', estado({ vigenteHasta: sumarDias(HOY, 61) }).urgencia === 'ok');
check('suspensión abierta y activa → suspendida', estado({ suspensiones: [susp()] }).estado === 'suspendida');
check('suspensión con término ya pasado → vuelve a vigente', estado({ suspensiones: [susp({ hasta: '2026-09-30' })] }).estado === 'vigente');
check('suspensión futura todavía no aplica', estado({ suspensiones: [susp({ desde: '2026-10-10' })] }).estado === 'vigente');
check('suspensión levantada hoy ya no rige', estado({ suspensiones: [susp({ levantadaEn: HOY })] }).estado === 'vigente');
check('suspensión levantada mañana todavía rige hoy', estado({ suspensiones: [susp({ levantadaEn: '2026-10-04' })] }).estado === 'suspendida');
check('revocación fechada en el futuro todavía no aplica', estado({ revocacion: { ...revoc, en: '2026-10-10' } }).estado === 'vigente');
check('revocación vigente → revocada', estado({ revocacion: { ...revoc, en: HOY } }).estado === 'revocada');
check('sucesora que rige desde el futuro: hoy sigue vigente', estado({ reemplazadaPorId: 'c2', reemplazadaDesde: '2026-10-10', motivoCierre: 'renovacion' }).estado === 'vigente');
check('sucesora que ya rige → renovada', estado({ reemplazadaPorId: 'c2', reemplazadaDesde: HOY, motivoCierre: 'renovacion' }).estado === 'renovada');
check('cierre por corrección → reemplazada', estado({ reemplazadaPorId: 'c2', reemplazadaDesde: HOY, motivoCierre: 'correccion' }).estado === 'reemplazada');
check('precedencia: revocada gana sobre renovada', estado({ revocacion: revoc, reemplazadaPorId: 'c2', reemplazadaDesde: '2026-09-01', motivoCierre: 'renovacion' }).estado === 'revocada');

// ── Operaciones no destructivas (§72) con auditoría (§45) ──
const orig = cred({});
const snap = JSON.stringify(orig);
const r = renovarCredencial(orig, { id: 'c2', vigenteDesde: '2028-01-01', vigenteHasta: '2029-12-31', numeroDocumento: 'DOC-2', actor: 'RRHH' }, HOY);
check('renovar: sin error', !r.error, r.error);
check('renovar: no muta el registro original', JSON.stringify(orig) === snap);
check('renovar: la nueva es v2 y enlaza a la anterior', r.nueva.version === 2 && r.nueva.reemplazaA === 'c1');
check('renovar: la anterior apunta a la nueva desde su inicio de vigencia', r.anterior.reemplazadaPorId === 'c2' && r.anterior.reemplazadaDesde === '2028-01-01');
check('renovar: la anterior conserva sus fechas originales', r.anterior.vigenteDesde === '2026-01-01' && r.anterior.vigenteHasta === '2027-12-31');
check('renovar: hoy la anterior sigue vigente y la nueva aún no rige', calcularEstadoCredencial(r.anterior, HOY).estado === 'vigente' && calcularEstadoCredencial(r.nueva, HOY).estado === 'emitida');
check('renovar: el 1-ene-2028 la anterior pasa a renovada y la nueva a vigente', calcularEstadoCredencial(r.anterior, '2028-01-01').estado === 'renovada' && calcularEstadoCredencial(r.nueva, '2028-01-01').estado === 'vigente');
check('renovar: auditoría con quién, qué, cuándo, antes y después', r.auditoria.actor === 'RRHH' && r.auditoria.credencialId === 'c1' && r.auditoria.en === HOY && r.auditoria.valorAnterior.version === 1 && r.auditoria.valorNuevo.version === 2 && r.auditoria.motivo === 'renovacion');
check('renovar sin actor → error', !!renovarCredencial(orig, { id: 'c2', vigenteDesde: '2028-01-01' }, HOY).error);
check('renovar una versión ya reemplazada → error', !!renovarCredencial(r.anterior, { id: 'c3', vigenteDesde: '2028-06-01', actor: 'RRHH' }, HOY).error);
check('renovar con vigenteHasta anterior a vigenteDesde → error', !!renovarCredencial(orig, { id: 'c9', vigenteDesde: '2028-01-01', vigenteHasta: '2027-01-01', actor: 'RRHH' }, HOY).error);
check('renovar una credencial revocada → error', !!renovarCredencial(cred({ revocacion: revoc }), { id: 'c9', vigenteDesde: '2028-01-01', actor: 'RRHH' }, HOY).error);
check('renovar con inicio anterior a la versión previa → error', !!renovarCredencial(orig, { id: 'c9', vigenteDesde: '2025-01-01', actor: 'RRHH' }, HOY).error);
check('corregir sin motivo → error', !!renovarCredencial(orig, { id: 'c9', vigenteDesde: HOY, motivoCierre: 'correccion', actor: 'RRHH' }, HOY).error);
const corr = renovarCredencial(orig, { id: 'c9', vigenteDesde: HOY, motivoCierre: 'correccion', motivo: 'Fecha mal digitada', actor: 'RRHH' }, HOY);
check('corregir con motivo: la anterior queda "reemplazada" y el motivo en auditoría', !corr.error && calcularEstadoCredencial(corr.anterior, HOY).estado === 'reemplazada' && corr.auditoria.motivo === 'Fecha mal digitada');

check('suspender sin motivo → error', !!suspenderCredencial(orig, { desde: '2026-10-01', actor: 'a' }, HOY).error);
const sp = suspenderCredencial(orig, { desde: '2026-10-01', motivo: 'Sumario', actor: 'RRHH' }, HOY);
check('suspender: queda suspendida y el original no cambia', calcularEstadoCredencial(sp.credencial, HOY).estado === 'suspendida' && JSON.stringify(orig) === snap);
check('suspender: auditoría con motivo y actor', sp.auditoria.motivo === 'Sumario' && sp.auditoria.actor === 'RRHH');
const lv = levantarSuspension(sp.credencial, { en: '2026-10-05', motivo: 'Sobreseído', actor: 'RRHH' }, '2026-10-05');
check('levantar: el día anterior sigue suspendida', calcularEstadoCredencial(lv.credencial, '2026-10-04').estado === 'suspendida');
check('levantar: el día indicado vuelve a vigente (y la suspensión queda en el historial)', calcularEstadoCredencial(lv.credencial, '2026-10-05').estado === 'vigente' && lv.credencial.suspensiones.length === 1);
check('levantar sin suspensión abierta → error', !!levantarSuspension(orig, { en: HOY, actor: 'a' }, HOY).error);
check('revocar sin motivo → error', !!revocarCredencial(orig, { actor: 'a' }, HOY).error);
const rv = revocarCredencial(orig, { en: '2026-10-01', motivo: 'Falsedad documental', actor: 'RRHH' }, HOY);
check('revocar: queda revocada', calcularEstadoCredencial(rv.credencial, HOY).estado === 'revocada');
check('revocar dos veces → error', !!revocarCredencial(rv.credencial, { motivo: 'x', actor: 'a' }, HOY).error);
check('no se suspende una credencial revocada', !!suspenderCredencial(rv.credencial, { desde: HOY, motivo: 'x', actor: 'a' }, HOY).error);

// ── Credencial actual de una persona ──
const credsSel = [
  cred({ id: 'a1', emitidaEn: '2024-01-01', vigenteDesde: '2024-01-01', vigenteHasta: '2025-12-31', revocacion: { ...revoc, en: '2025-06-01' } }),
  cred({ id: 'b1', emitidaEn: '2026-02-01', vigenteDesde: '2026-02-01', vigenteHasta: '2028-01-31' }),
];
check('actual: prefiere la vigente a una revocada antigua', elegirCredencialActual(credsSel, 'p1', 'rcp_bls', HOY).credencial.id === 'b1');
check('actual: si solo hay una revocada, esa es la actual y está revocada', elegirCredencialActual([credsSel[0]], 'p1', 'rcp_bls', HOY).estado === 'revocada');
check('actual: sin registros → null', elegirCredencialActual([], 'p1', 'rcp_bls', HOY) === null);
check('actual: no mezcla personas ni tipos', elegirCredencialActual(credsSel, 'p2', 'rcp_bls', HOY) === null && elegirCredencialActual(credsSel, 'p1', 'acls', HOY) === null);
const ren = renovarCredencial(cred({ vigenteHasta: '2026-10-10' }), { id: 'c2', vigenteDesde: '2026-10-11', vigenteHasta: '2028-10-10', actor: 'RRHH' }, HOY);
const cadena = [ren.anterior, ren.nueva];
check('renovación anticipada: hoy la actual es la anterior (sin hueco de cobertura)', elegirCredencialActual(cadena, 'p1', 'rcp_bls', HOY).credencial.id === 'c1');
check('renovación anticipada: desde el día siguiente es la nueva', elegirCredencialActual(cadena, 'p1', 'rcp_bls', '2026-10-11').credencial.id === 'c2');

// ── Aptitud para la función (§48, §61) ──
const REQ = { fx: [{ tipoId: 'titulo_profesional', obligatorio: true }, { tipoId: 'rcp_bls', obligatorio: true }, { tipoId: 'especialidad', obligatorio: false }], vacia: [] };
const titulo = cred({ id: 't1', tipoId: 'titulo_profesional', vigenteHasta: null });
const ev = (creds, funcion = 'fx', req = REQ) => evaluarAptitud('p1', funcion, creds, HOY, req);
const a1 = ev([titulo, cred({ id: 'r1' })]);
check('aptitud: todo vigente → apta, 100%', a1.apto && a1.cumplimientoPct === 100 && a1.bloqueantes.length === 0 && a1.advertencias.length === 0);
check('aptitud: un opcional faltante no bloquea', a1.detalle.find((d) => d.tipoId === 'especialidad').resultado === 'faltante' && a1.apto);
const a2 = ev([titulo]);
check('aptitud: falta un obligatorio → no apta, 50%', !a2.apto && a2.bloqueantes[0].resultado === 'faltante' && a2.cumplimientoPct === 50);
check('aptitud: obligatorio vencido bloquea', ev([titulo, cred({ id: 'r2', vigenteHasta: '2026-09-01' })]).bloqueantes[0].resultado === 'vencida');
const a3 = ev([titulo, cred({ id: 'r3', vigenteHasta: sumarDias(HOY, 10) })]);
check('aptitud: por vencer NO bloquea, solo advierte', a3.apto && a3.advertencias.length === 1 && a3.advertencias[0].resultado === 'por_vencer');
check('aptitud: revocada bloquea', ev([titulo, cred({ id: 'r4', revocacion: revoc })]).bloqueantes[0].resultado === 'revocada');
check('aptitud: suspendida bloquea', ev([titulo, cred({ id: 'r5', suspensiones: [susp()] })]).bloqueantes[0].resultado === 'suspendida');
check('aptitud: aún no rige bloquea', ev([titulo, cred({ id: 'r6', vigenteDesde: '2026-10-20' })]).bloqueantes[0].resultado === 'emitida');
const REQN = { fx: [{ tipoId: 'rcp_bls', obligatorio: true, nivelMinimo: 2 }] };
check('aptitud: nivel por debajo del mínimo bloquea', ev([cred({ nivel: 1 })], 'fx', REQN).bloqueantes[0].resultado === 'nivel_insuficiente');
check('aptitud: nivel igual al mínimo cumple', ev([cred({ nivel: 2 })], 'fx', REQN).apto);
check('aptitud: nivel sin registrar cuenta como 0', !ev([cred({ nivel: null })], 'fx', REQN).apto);
check('aptitud: función sin requisitos → apta, 100%', ev([], 'vacia').apto && ev([], 'vacia').cumplimientoPct === 100 && ev([], 'desconocida').apto);
check('aptitud: catálogo por defecto — médico sin nada registrado tiene 3 bloqueantes', evaluarAptitud('p1', 'medico', [], HOY).bloqueantes.length === 3);
check('aptitud: catálogo por defecto — administrativo siempre apto', evaluarAptitud('p1', 'administrativo', [], HOY).apto);

// ── Alertas ──
const L = [
  cred({ id: 'x1', personaId: 'p1', vigenteHasta: sumarDias(HOY, 10) }),
  cred({ id: 'x2', personaId: 'p2', vigenteHasta: sumarDias(HOY, -5) }),
  cred({ id: 'x3', personaId: 'p3', vigenteHasta: sumarDias(HOY, 400) }),
  cred({ id: 'x4', personaId: 'p4', vigenteHasta: sumarDias(HOY, 50) }),
  cred({ id: 'x5', personaId: 'p5', vigenteHasta: sumarDias(HOY, 5), reemplazadaPorId: 'x5b', reemplazadaDesde: sumarDias(HOY, 6), motivoCierre: 'renovacion' }),
  cred({ id: 'x6', personaId: 'p6', tipoId: 'titulo_profesional', vigenteHasta: null }),
];
const al = calcularAlertasCredenciales(L, HOY);
check('alertas: solo vencida, urgente y pronto (3 de 6; no la renovada ni la lejana ni la sin vencimiento)', al.length === 3, `fue ${al.length}`);
check('alertas: ordenadas por días, la vencida primero', al.map((a) => a.credencial.id).join() === 'x2,x1,x4');
check('alertas: niveles vencido, urgente, pronto', al.map((a) => a.nivel).join() === 'vencido,urgente,pronto');
check('alertas: respeta esRequerida', calcularAlertasCredenciales(L, HOY, (pid) => pid !== 'p2').length === 2);
check('alertas: sin credenciales no hay alertas', calcularAlertasCredenciales([], HOY).length === 0);

// ── Eventos (§57) ──
const evI = construirCredentialIssuedEvent(cred({}));
check('evento CredentialIssued: tipo, origen y versión', evI.tipo === 'CredentialIssued' && evI.dominioOrigen === 'workforce' && evI.version === 1);
const evE = construirCredentialExpiredEvent(cred({ vigenteHasta: sumarDias(HOY, -5) }), HOY);
check('evento CredentialExpired: 5 días vencida, desde el día siguiente al fin', evE.tipo === 'CredentialExpired' && evE.diasVencida === 5 && evE.vencidaDesde === sumarDias(HOY, -4));
check('CredentialExpired no se emite si está vigente', construirCredentialExpiredEvent(cred({}), HOY) === null);

// ── KPIs ──
const K = [cred({ id: 'k1' }), cred({ id: 'k2', vigenteHasta: sumarDias(HOY, 10) }), cred({ id: 'k3', vigenteHasta: '2026-09-01' }), cred({ id: 'k4', suspensiones: [susp()] }), cred({ id: 'k5', revocacion: revoc }), cred({ id: 'k6', reemplazadaPorId: 'k1', reemplazadaDesde: '2026-09-01', motivoCierre: 'renovacion' })];
const kk = calcularKPIsCredenciales(K, HOY);
check('KPI: 6 registros, 1 en historial', kk.credenciales === 6 && kk.versionesHistoricas === 1);
check('KPI: 2 vigentes, 1 por vencer', kk.vigentes === 2 && kk.porVencer === 1);
check('KPI: 1 vencida, 1 suspendida, 1 revocada', kk.vencidas === 1 && kk.suspendidas === 1 && kk.revocadas === 1);
const ka = calcularKPIsAptitud([{ apto: true, advertencias: [], cumplimientoPct: 100 }, { apto: true, advertencias: [{}], cumplimientoPct: 100 }, { apto: false, advertencias: [], cumplimientoPct: 50 }]);
check('KPI aptitud: 2 aptas, 1 no apta, 1 con advertencias, promedio 83%', ka.aptas === 2 && ka.noAptas === 1 && ka.conAdvertencias === 1 && ka.cumplimientoPromedio === 83);
check('KPI aptitud: lista vacía no divide por cero', calcularKPIsAptitud([]).cumplimientoPromedio === 0);

// ── Mock (también ejercita las operaciones del motor) ──
const personas = generarPersonasCanonico();
const g1 = generarCredencialesMock(personas, HOY), g2 = generarCredencialesMock(personas, HOY);
check('mock: determinístico', JSON.stringify(g1) === JSON.stringify(g2));
check('mock: al menos 30 credenciales', g1.credenciales.length >= 30, `fue ${g1.credenciales.length}`);
check('mock: 4 entradas de auditoría (suspender, revocar, 2 renovaciones)', g1.auditoria.length === 4, `fue ${g1.auditoria.length}`);
check('mock: ids únicos', new Set(g1.credenciales.map((c) => c.id)).size === g1.credenciales.length);
const est = g1.credenciales.map((c) => calcularEstadoCredencial(c, HOY));
[['vigente', (e) => e.estado === 'vigente'], ['por vencer (urgente)', (e) => e.urgencia === 'urgente'], ['por vencer (pronto)', (e) => e.urgencia === 'pronto'], ['vencida', (e) => e.estado === 'vencida'], ['suspendida', (e) => e.estado === 'suspendida'], ['revocada', (e) => e.estado === 'revocada'], ['renovada (historial)', (e) => e.estado === 'renovada'], ['aún no rige (renovación anticipada)', (e) => e.estado === 'emitida']]
  .forEach(([n, f]) => check(`mock cubre: ${n}`, est.some(f)));
const porId = Object.fromEntries(personas.map((p) => [p.id, p]));
check('mock: todas las credenciales son de personas del registro', g1.credenciales.every((c) => porId[c.personaId]));
check('mock: las empresas no llevan credenciales', g1.credenciales.every((c) => !porId[c.personaId].razonSocial));
const evs = personas.filter((p) => !p.razonSocial).map((p) => evaluarAptitud(p.id, p.cargoId || p.especialidadId, g1.credenciales, HOY));
check('mock: hay personas aptas y no aptas', evs.some((x) => x.apto) && evs.some((x) => !x.apto));
check('mock: hay un bloqueo por requisito faltante y otro por vencido', evs.some((x) => x.bloqueantes.some((b) => b.resultado === 'faltante')) && evs.some((x) => x.bloqueantes.some((b) => b.resultado === 'vencida')));
const alM = calcularAlertasCredenciales(g1.credenciales, HOY);
check('mock: ninguna alerta sobre una credencial ya renovada', alM.length > 0 && alM.every((a) => !a.credencial.reemplazadaPorId));
check('mock: alertas ordenadas por días', alM.every((a, i) => i === 0 || alM[i - 1].diasParaVencer <= a.diasParaVencer));

console.log(`\n${fallas === 0 ? '✅ TODO OK' : `❌ ${fallas} FALLA(S)`} — Credenciales y Competencias`);
process.exit(fallas === 0 ? 0 : 1);
