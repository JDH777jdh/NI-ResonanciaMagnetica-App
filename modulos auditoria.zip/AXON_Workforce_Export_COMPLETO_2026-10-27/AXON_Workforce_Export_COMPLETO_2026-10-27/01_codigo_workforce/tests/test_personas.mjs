import { generarPersonasCanonico, nombreCompletoPersona, calcularKPIsPersonas } from './bundles/Personas.mjs';

let fallas = 0;
function check(n, c, d) { if (!c) { fallas++; console.log(`❌ ${n} — ${d || ''}`); } else console.log(`✅ ${n}`); }

const personas = generarPersonasCanonico();
check('total = 30 (20 empleados + 10 honorarios)', personas.length === 30, `fue ${personas.length}`);

const empleados = personas.filter((p) => p.tipoRelacion === 'empleado');
const honorarios = personas.filter((p) => p.tipoRelacion === 'honorario');
check('20 empleados', empleados.length === 20);
check('10 honorarios', honorarios.length === 10);

const axonHealth = empleados.filter((p) => p.axonLinea === 'axon_health');
const axonCore = empleados.filter((p) => p.axonLinea === 'axon_core');
check('17 empleados AXON Health (propios)', axonHealth.length === 17, `fue ${axonHealth.length}`);
check('3 empleados AXON Core (tenant)', axonCore.length === 3, `fue ${axonCore.length}`);
check('todos los AXON Health sin tenantId', axonHealth.every((p) => p.tenantId === null));
check('todos los AXON Core CON tenantId', axonCore.every((p) => p.tenantId !== null));
check('AXON Health = sector privado', axonHealth.every((p) => p.sector === 'privado'));
check('AXON Core = sector publico', axonCore.every((p) => p.sector === 'publico'));

const honorariosNaturales = honorarios.filter((p) => p.tipoPersonaHonorario === 'natural');
const honorariosEmpresa = honorarios.filter((p) => p.tipoPersonaHonorario === 'empresa');
check('8 honorarios persona natural, 2 empresa', honorariosNaturales.length === 8 && honorariosEmpresa.length === 2);
check('todos los honorarios son AXON Core Lite', honorarios.every((p) => p.axonLinea === 'axon_core_lite'));

const personas2 = generarPersonasCanonico();
check('determinístico: dos llamadas dan resultados idénticos', JSON.stringify(personas) === JSON.stringify(personas2));

const idsUnicos = new Set(personas.map((p) => p.id));
const cutsUnicos = new Set(personas.map((p) => p.cut));
check('sin IDs duplicados', idsUnicos.size === personas.length);
check('sin CUTs duplicados', cutsUnicos.size === personas.length);
check('formato CUT correcto (CUT-CL-13-AXON-########-XX)', /^CUT-CL-13-AXON-\d{8}-[0-9A-Z]{2}$/.test(personas[0].cut), personas[0].cut);

check('nombreCompletoPersona funciona para persona natural', nombreCompletoPersona(honorariosNaturales[0]).split(' ').length >= 3);
check('nombreCompletoPersona usa razón social para empresa', nombreCompletoPersona(honorariosEmpresa[0]) === honorariosEmpresa[0].razonSocial);

const kpis = calcularKPIsPersonas(personas);
check('KPI tenantsDistintos = 1', kpis.tenantsDistintos === 1);

console.log(`\n${fallas === 0 ? '✅ TODO OK' : `❌ ${fallas} FALLA(S)`} — Personas`);
process.exit(fallas === 0 ? 0 : 1);
