#!/usr/bin/env bash
# Reconstruye el entorno de pruebas de Workforce y corre todo.
#   bash run_all.sh [dir ...]        (por defecto: /mnt/project)
# Cada dir aporta Workforce*.jsx, test_*.mjs y build_all.mjs (en el dir o en dir/tests);
# los dirs posteriores pisan a los anteriores (útil para probar cambios sobre lo ya subido):
#   bash run_all.sh /mnt/project /mnt/user-data/outputs/workforce
# Otra zona horaria:  TZ=Pacific/Auckland bash run_all.sh
DIRS=("$@"); [ ${#DIRS[@]} -eq 0 ] && DIRS=(/mnt/project)
W=/home/claude/verify; rm -rf "$W"; mkdir -p "$W/wf" "$W/bundles"; cd "$W" || exit 1
for D in "${DIRS[@]}"; do
  cp "$D"/Workforce*.jsx wf/ 2>/dev/null
  cp "$D"/test_*.mjs "$D"/build_all.mjs . 2>/dev/null
  cp "$D"/tests/test_*.mjs "$D"/tests/build_all.mjs . 2>/dev/null
done
echo '{"name":"verify","private":true}' > package.json
npm install esbuild --silent --no-audit --no-fund 2>&1 | tail -n 3
# Stubs ESM de react y lucide-react: los íconos se leen de los imports reales de los .jsx.
mkdir -p node_modules/react node_modules/lucide-react
echo '{"name":"react","version":"0.0.0","type":"module","main":"index.js"}' > node_modules/react/package.json
cat > node_modules/react/index.js <<'EOF'
export function useState(v){ return [v, ()=>{}]; }
export function useMemo(fn){ return fn(); }
export function createElement(){ return null; }
export const Fragment = 'Fragment';
export default { useState, useMemo, createElement, Fragment };
EOF
echo '{"name":"lucide-react","version":"0.0.0","type":"module","main":"index.js"}' > node_modules/lucide-react/package.json
cat > gen_icons.cjs <<'EOF'
const fs = require('fs'), names = new Set();
for (const f of fs.readdirSync('wf')) {
  const s = fs.readFileSync('wf/' + f, 'utf8'), re = /import\s*\{([^}]*)\}\s*from\s*'lucide-react'/g; let m;
  while ((m = re.exec(s))) m[1].split(',').map((x) => x.trim()).filter(Boolean).forEach((n) => names.add(n));
}
fs.writeFileSync('node_modules/lucide-react/index.js', [...names].map((n) => `export const ${n} = () => null;`).join('\n') + '\n');
console.log('iconos stub:', names.size);
EOF
node gen_icons.cjs
WF_DIR=wf node build_all.mjs 2>&1 | tail -n 12
echo '--- suites ---'
tot=0
for f in test_*.mjs; do
  out=$(node "$f" 2>&1); code=$?
  pass=$(printf '%s\n' "$out" | grep '^✅' | grep -vc 'TODO OK')
  fail=$(printf '%s\n' "$out" | grep -c '^❌')
  tot=$((tot + pass))
  echo "${f%.mjs}: ok=$pass fallas=$fail exit=$code"
  printf '%s\n' "$out" | grep '^❌' | head -3
done
echo "TOTAL checks ok: $tot"
# Segunda y tercera pasada en otras zonas horarias: America/Santiago es la real (con cambio de horario) y
# Pacific/Auckland es UTC+ (donde `toISOString` sobre hora local corre un día). Ambas destaparon bugs reales.
for tz in America/Santiago Pacific/Auckland; do
  ok=0; malas=""
  for f in test_*.mjs; do
    out=$(TZ=$tz node "$f" 2>&1); code=$?
    ok=$((ok + $(printf '%s\n' "$out" | grep '^✅' | grep -vc 'TODO OK')))
    [ $code -ne 0 ] && malas="$malas ${f%.mjs}"
  done
  echo "TZ=$tz: checks ok=$ok · suites con falla:${malas:- ninguna}"
done
