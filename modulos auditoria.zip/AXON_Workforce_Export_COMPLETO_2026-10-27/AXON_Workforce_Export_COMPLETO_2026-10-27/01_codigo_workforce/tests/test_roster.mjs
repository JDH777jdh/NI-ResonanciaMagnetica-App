import * as esbuild from 'esbuild';
import fs from 'fs';
import crypto from 'crypto';

let fallas = 0;
function check(n, c, d) { if (!c) { fallas++; console.log(`❌ ${n} — ${d || ''}`); } else console.log(`✅ ${n}`); }

// El registro canónico de personas se COPIA (no se importa) en cada Workforce*.jsx. Esta prueba compara
// COMPORTAMIENTO, no bytes: un archivo puede tener el bloque compactado o con comentarios y seguir siendo
// el mismo registro. Se agrega un export temporal para poder invocar generarPersonasCanonico() de cada uno.
const DIR = process.env.WF_DIR || 'wf';
const files = fs.readdirSync(DIR)
  .filter((f) => f.endsWith('.jsx') && /function generarPersonasCanonico/.test(fs.readFileSync(`${DIR}/${f}`, 'utf8')))
  .sort();

const hashes = {};
for (const f of files) {
  const out = 'bundles/_roster_' + f.replace('.jsx', '.mjs');
  await esbuild.build({
    stdin: { contents: fs.readFileSync(`${DIR}/${f}`, 'utf8') + '\nexport { generarPersonasCanonico as __gen };\n', loader: 'jsx', resolveDir: process.cwd() + '/' + DIR, sourcefile: f },
    bundle: true, write: true, format: 'esm', platform: 'node', outfile: out,
    jsx: 'transform', jsxFactory: 'React.createElement', jsxFragment: 'React.Fragment',
    external: ['react', 'lucide-react'], logLevel: 'error',
  });
  const personas = (await import('./' + out)).__gen();
  hashes[f] = { n: personas.length, h: crypto.createHash('md5').update(JSON.stringify(personas)).digest('hex').slice(0, 10) };
}

const distintos = new Set(Object.values(hashes).map((x) => x.h));
check(`hay al menos 8 archivos con registro canónico (hay ${files.length})`, files.length >= 8);
check('todos generan 30 personas', Object.values(hashes).every((x) => x.n === 30));
check(`el registro canónico es idéntico en los ${files.length} archivos`, distintos.size === 1, JSON.stringify(hashes));

console.log(`\n${fallas === 0 ? '✅ TODO OK' : `❌ ${fallas} FALLA(S)`} — Registro canónico`);
process.exit(fallas === 0 ? 0 : 1);
