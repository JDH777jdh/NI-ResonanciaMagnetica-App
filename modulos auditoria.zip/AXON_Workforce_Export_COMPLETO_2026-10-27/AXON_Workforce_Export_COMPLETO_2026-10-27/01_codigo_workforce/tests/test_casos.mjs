import * as K from './bundles/Casos.mjs';

let fallas = 0, total = 0;
function check(n, c, d) { total++; if (!c) { fallas++; console.log(`❌ ${n} — ${d || ''}`); } else console.log(`✅ ${n}`); }
const snap = (x) => JSON.stringify(x);
const lanza = (f) => { try { f(); return false; } catch { return true; } };

const personas = K.generarPersonasCanonico();
const emp = personas.filter((p) => p.tipoRelacion === 'empleado');
const id = (i) => emp[i].id;
const T = 'AXON-HEALTH';
const A = (c, i) => K.actorDemo(id(i), c.tenantId);
const rec = (c) => A(c, 5), resp = (c) => A(c, 1), inv = (c) => A(c, 2);
const ok = (r, etiqueta = '') => { if (r.error) throw new Error(`${etiqueta} ${r.error}`); return r.caso; };

function base(o = {}) {
  return ok(K.crearCaso({ id: o.id || 'CL-T-1', tenantId: o.tenantId || T, sectorTenant: o.sector || 'privado', canalIngreso: o.canal || 'empleador', recibidaEn: o.recibidaEn || '2026-09-01', denunciante: o.denunciante || { tipo: 'trabajador', personaId: id(10) }, denunciado: o.denunciado || { tipo: 'trabajador', personaId: id(15) }, relatoRef: 'RELATO-1', responsableId: id(1), receptorId: id(5), actor: K.actorDemo(id(5), o.tenantId || T) }, o.recibidaEn || '2026-09-01'), 'crear');
}
const clasif = (c, f = '2026-09-01', extra = {}) => ok(K.clasificarCaso(c, { ramaId: 'acoso_violencia_legal', motivo: 'Hechos descritos', actor: rec(c), ...extra }, f), 'clasificar');
function resguardar(c, f = '2026-09-02', tipo = 'separacion_espacios_fisicos') {
  c = ok(K.proponerMedidaResguardo(c, { tipo, destinatarioId: c.denunciante.ref || 'unidad:servicio-demo', fundamento: 'Resguardo inicial', actor: rec(c) }, f), 'proponer');
  const mid = c.medidasResguardo[c.medidasResguardo.length - 1].id;
  c = ok(K.ordenarMedidaResguardo(c, { medidaId: mid, actor: resp(c) }, f), 'ordenar');
  return ok(K.implementarMedidaResguardo(c, { medidaId: mid, fecha: f, evidenciaRef: 'EVID-1', actor: rec(c) }, f), 'implementar');
}
const evaluada = (c, f = '2026-09-02', riesgo = 'medio') => { c = resguardar(c, f); return ok(K.registrarEvaluacionInicial(c, { riesgo, decisionMedidas: 'aplicadas', actor: rec(c) }, f), 'evaluar'); };
function enInvestigacion(c) {
  c = ok(K.asignarRol(c, { personaId: id(2), rol: 'investigador', actor: rec(c) }, '2026-09-02'), 'rol');
  c = ok(K.seleccionarProcedimiento(c, { procedimiento: 'investigacion_interna', fundamento: 'Corresponde', actor: resp(c) }, '2026-09-02'), 'sel');
  return ok(K.iniciarInvestigacion(c, { fecha: '2026-09-03', actor: rec(c) }, '2026-09-03'), 'iniciar');
}
function oidas(c) {
  c = ok(K.registrarActuacion(c, { tipo: 'declaracion', fecha: '2026-09-10', participantes: [c.denunciante.ref], actor: inv(c) }, '2026-09-10'), 'decl1');
  return ok(K.registrarActuacion(c, { tipo: 'declaracion', fecha: '2026-09-12', participantes: [c.denunciado.ref], actor: inv(c) }, '2026-09-12'), 'decl2');
}
const concluida = (c) => ok(K.registrarConclusiones(oidas(c), { resultado: 'hechos_acreditados', referenciaInforme: 'INF-1', fecha: '2026-09-20', actor: inv(c) }, '2026-09-20'), 'concl');
const remitida = (c) => ok(K.remitirInformeADT(c, { fecha: '2026-09-21', referencia: 'ENVIO-1', actor: resp(c) }, '2026-09-21'), 'remitir');
const conclDT = (c) => ok(K.registrarConclusionesDT(c, { fecha: '2026-10-05', referencia: 'DT-1', actor: rec(c) }, '2026-10-05'), 'dt');
const hastaDT = () => conclDT(remitida(concluida(enInvestigacion(evaluada(clasif(base()))))));

// ═══ A · Calendario y fechas ═══
check('sumarDias cruza el año', K.sumarDias('2026-12-31', 1) === '2027-01-01');
check('diferenciaDias en año bisiesto', K.diferenciaDias('2028-02-28', '2028-03-01') === 2);
check('2026-10-17 es sábado: corridos cuenta, hábiles no, judiciales sí', K.esDiaDeConteo('2026-10-17', 'corrido') && !K.esDiaDeConteo('2026-10-17', 'habil') && K.esDiaDeConteo('2026-10-17', 'habil_judicial'));
check('domingo no cuenta como hábil ni como judicial', !K.esDiaDeConteo('2026-10-18', 'habil') && !K.esDiaDeConteo('2026-10-18', 'habil_judicial'));
check('feriado (2026-10-12) no cuenta como hábil ni judicial', !K.esDiaDeConteo('2026-10-12', 'habil') && !K.esDiaDeConteo('2026-10-12', 'habil_judicial'));
check('lunes 2026-10-19 cuenta como hábil', K.esDiaDeConteo('2026-10-19', 'habil'));
check('1 día hábil desde viernes 26-jun salta el feriado del 29', K.sumarDiasTipo('2026-06-26', 1, 'habil').fecha === '2026-06-30');
check('cruzar a 2027 con días hábiles avisa que faltan feriados', K.sumarDiasTipo('2026-12-30', 3, 'habil').advertencias.includes('feriados_no_cargados_2027'));
check('días corridos no necesitan feriados: sin aviso', K.sumarDiasTipo('2026-12-30', 3, 'corrido').advertencias.length === 0);
check('prórroga al próximo hábil si el vencimiento cae en inhábil', K.sumarDiasTipo('2026-06-23', 5, 'corrido', K.CALENDARIO_CL, true).fecha === '2026-06-30');
check('contarDiasTipo: misma fecha = 0 y signo negativo hacia atrás', K.contarDiasTipo('2026-10-20', '2026-10-20', 'corrido') === 0 && K.contarDiasTipo('2026-10-20', '2026-10-16', 'corrido') === -4);
check('tipo de día desconocido lanza error', lanza(() => K.esDiaDeConteo('2026-10-20', 'raro')));

// ═══ B · Paquete de reglas (datos versionados) ═══
const PAQ = K.PAQUETE_REGLAS_CL_BORRADOR, vp = K.validarPaqueteReglas(PAQ);
check('el paquete borrador es estructuralmente válido', vp.valido, vp.errores.join('|'));
check('ninguna de las 6 reglas está validada y el paquete no es apto para producción', vp.sinValidar.length === 6 && vp.listoParaProduccion === false && PAQ.validadoPorAbogado === false);
check('K1-K4 son ambiguas (varias variantes); K0 y K5 no', ['K1_DECISION_EMPLEADOR', 'K2_INVESTIGACION_INTERNA', 'K3_REMISION_INFORME_DT', 'K4_MEDIDAS_EMPLEADOR'].every((x) => vp.ambiguas.includes(x)) && !vp.ambiguas.includes('K0_RESGUARDO_DT') && !vp.ambiguas.includes('K5_PRONUNCIAMIENTO_DT'));
const paqMal = (mod) => ({ ...PAQ, reglas: [mod(PAQ.reglas[1]), ...PAQ.reglas.slice(1)] });
check('paquete con evento de inicio inexistente es inválido', !K.validarPaqueteReglas(paqMal((r) => ({ ...r, inicios: ['evento_inventado'] }))).valido);
check('paquete con plazo 0 o decimal es inválido', !K.validarPaqueteReglas(paqMal((r) => ({ ...r, plazos: [0] }))).valido && !K.validarPaqueteReglas(paqMal((r) => ({ ...r, plazos: [2.5] }))).valido);
check('paquete con id duplicado es inválido', !K.validarPaqueteReglas(paqMal((r) => ({ ...r }))).valido);
check('paquete con evento de resolución inexistente es inválido', !K.validarPaqueteReglas(paqMal((r) => ({ ...r, id: 'ZZ', resuelveSinCumplir: ['nada'] }))).valido);

// ═══ C · Creación del caso ═══
const c0 = base();
check('caso nuevo: versión 1, un solo registro de historial, estado «recibida», régimen por determinar', c0.version === 1 && c0.historial.length === 1 && c0.estado === 'recibida' && c0.regimenJuridico === 'por_determinar');
const crear = (o) => K.crearCaso({ id: 'X', tenantId: T, sectorTenant: 'privado', canalIngreso: 'empleador', recibidaEn: '2026-09-01', denunciante: { tipo: 'trabajador', personaId: id(10) }, denunciado: { tipo: 'trabajador', personaId: id(15) }, relatoRef: 'R-1', responsableId: id(1), receptorId: id(5), actor: K.actorDemo(id(5), T), ...o }, '2026-09-10');
check('sin actor identificado no se crea', !!crear({ actor: null }).error);
check('fecha de recepción futura no se acepta', !!crear({ recibidaEn: '2026-12-01' }).error);
check('tipo de denunciante inválido', !!crear({ denunciante: { tipo: 'otro' } }).error);
check('el relato se guarda como referencia: no acepta texto largo ni saltos de línea', !!crear({ relatoRef: 'x'.repeat(81) }).error && !!crear({ relatoRef: 'línea1\nlínea2' }).error);
check('una parte no puede ser receptora ni responsable (imparcialidad)', !!crear({ receptorId: id(10) }).error && !!crear({ responsableId: id(15) }).error);
check('art. 4 inc. 1 solo aplica a trabajadores', !!crear({ denunciado: { tipo: 'tercero', ref: 't:1', relacion: 'art4_inc1' } }).error);
check('denunciante no individualizado es válido y queda marcado', crear({ denunciante: { tipo: 'no_individualizado' } }).caso.denunciante.individualizado === false);

// ═══ D · Clasificación y régimen jurídico ═══
const snapC0 = snap(c0);
check('clasificar sin motivo se rechaza', !!K.clasificarCaso(c0, { ramaId: 'acoso_violencia_legal', actor: rec(c0) }, '2026-09-01').error);
check('rama desconocida se rechaza', !!K.clasificarCaso(c0, { ramaId: 'otra', motivo: 'm', actor: rec(c0) }, '2026-09-01').error);
const r1 = K.clasificarCaso(c0, { ramaId: 'acoso_violencia_legal', motivo: 'Hechos descritos', actor: rec(c0) }, '2026-09-01');
check('tenant privado: se asume Código del Trabajo, marcado como INFERIDO y con aviso', r1.caso.regimenJuridico === 'codigo_trabajo' && r1.caso.regimenInferido === true && r1.advertencias.some((x) => x.includes('confirmar')));
check('clasificar no muta el caso original (inmutabilidad §72)', snap(c0) === snapC0 && r1.caso.version === 2 && r1.caso.estado === 'clasificada');
const r2 = K.clasificarCaso(r1.caso, { ramaId: 'convivencia', motivo: 'Reclasificado tras entrevista inicial', actor: rec(r1.caso) }, '2026-09-02');
check('reclasificar crea una nueva versión y conserva la anterior', r2.caso.clasificaciones.length === 2 && r2.caso.clasificaciones[0].ramaId === 'acoso_violencia_legal');
const pub = base({ sector: 'publico', tenantId: 'HOSPITAL-REGIONAL-DEMO' });
check('institución pública: el sector NO decide, exige declarar el régimen', !!K.clasificarCaso(pub, { ramaId: 'acoso_violencia_legal', motivo: 'm', actor: rec(pub) }, '2026-09-01').error);
const pubE = K.clasificarCaso(pub, { ramaId: 'acoso_violencia_legal', motivo: 'm', regimenJuridico: 'estatutario_publico', actor: rec(pub) }, '2026-09-01');
check('régimen estatutario: la única ruta permitida es el procedimiento administrativo', pubE.enrutamiento.obligatorio === 'procedimiento_administrativo' && pubE.enrutamiento.permitidos.length === 1 && pubE.caso.regimenInferido === false);
const pubC = K.clasificarCaso(pub, { ramaId: 'acoso_violencia_legal', motivo: 'm', regimenJuridico: 'codigo_trabajo', actor: rec(pub) }, '2026-09-01');
check('institución pública con personal bajo el Código del Trabajo: ruta común, no se fuerza lo administrativo', pubC.enrutamiento.permitidos.includes('investigacion_interna') && pubC.enrutamiento.permitidos.includes('derivacion_dt') && pubC.enrutamiento.obligatorio === null);
check('régimen inválido se rechaza', !!K.clasificarCaso(pub, { ramaId: 'acoso_violencia_legal', motivo: 'm', regimenJuridico: 'otro', actor: rec(pub) }, '2026-09-01').error);
check('convivencia no activa procedimiento legal; acoso legal no puede desactivarlo', !!K.clasificarCaso(c0, { ramaId: 'convivencia', activaProcedimientoLegal: true, motivo: 'm', actor: rec(c0) }, '2026-09-01').error && !!K.clasificarCaso(c0, { ramaId: 'acoso_violencia_legal', activaProcedimientoLegal: false, motivo: 'm', actor: rec(c0) }, '2026-09-01').error);
check('violencia de terceros puede activar la vía legal y entonces habilita la investigación', K.clasificarCaso(c0, { ramaId: 'violencia_terceros', activaProcedimientoLegal: true, motivo: 'm', actor: rec(c0) }, '2026-09-01').enrutamiento.permitidos.includes('investigacion_interna'));

// ═══ E · Denuncia inconsistente: ORD. N.º 146/13 ═══
const cC = clasif(base());
check('complemento sin plazo o sin fundamento se rechaza', !!K.solicitarComplemento(cC, { plazoDias: 0, fundamento: 'f', actor: rec(cC) }, '2026-09-01').error && !!K.solicitarComplemento(cC, { plazoDias: 5, actor: rec(cC) }, '2026-09-01').error);
const sc = K.solicitarComplemento(cC, { plazoDias: 5, tipoDia: 'habil', fundamento: 'Faltan fechas y personas', actor: rec(cC) }, '2026-09-01');
check('solicitar complemento: queda por complementar con vencimiento en 5 días hábiles', sc.caso.estado === 'por_complementar' && sc.caso.complemento.venceEn === '2026-09-08' && sc.caso.estadoPrevio === 'clasificada');
check('no se duplica la solicitud ni se clasifica mientras está pendiente', !!K.solicitarComplemento(sc.caso, { plazoDias: 5, fundamento: 'f', actor: rec(cC) }, '2026-09-02').error && !!K.clasificarCaso(sc.caso, { ramaId: 'convivencia', motivo: 'm', actor: rec(cC) }, '2026-09-02').error);
const cierreMal = K.cerrarCaso(sc.caso, { motivoCierre: 'otro', fundamento: 'Inconsistente', actor: resp(cC) }, '2026-09-02');
check('no se puede cerrar una denuncia por inconsistente (se complementa, no se archiva)', !!cierreMal.error && cierreMal.error.includes('ORD'));
check('continuar sin complemento antes del vencimiento se rechaza', !!K.continuarSinComplemento(sc.caso, { fundamento: 'f', actor: rec(cC) }, '2026-09-04').error);
const cs = K.continuarSinComplemento(sc.caso, { fundamento: 'Venció el plazo razonable', actor: rec(cC) }, '2026-09-10');
check('vencido el plazo, el caso continúa con los antecedentes disponibles (no se archiva)', !cs.error && cs.caso.estado === 'clasificada' && cs.nota.includes('no se archiva') && cs.caso.complemento.estado === 'vencido_sin_complemento');
const rc = K.recibirComplemento(sc.caso, { referencia: 'COMPL-1', actor: rec(cC) }, '2026-09-05');
check('recibir complemento en plazo: vuelve al estado previo y registra que fue en plazo', !rc.error && rc.caso.estado === 'clasificada' && rc.caso.complemento.dentroDePlazo === true);
check('el complemento exige solo una referencia', !!K.recibirComplemento(sc.caso, { referencia: '', actor: rec(cC) }, '2026-09-05').error);
check('mientras está pendiente corre su propio reloj', K.calcularRelojes(sc.caso, '2026-09-03').some((r) => r.reglaId === 'complemento_denuncia' && r.estado === 'corriendo'));

// ═══ F · Reserva y acceso por caso ═══
const cF = clasif(base());
const sinRol = { personaId: ACTOR_X(), tenantId: T, relacionVigente: true };
function ACTOR_X() { return id(9); }
check('sin rol en el caso el expediente está reservado', K.evaluarAcceso(cF, sinRol, 'leer_expediente').permitido === false);
check('el receptor lee el expediente pero no decide', K.evaluarAcceso(cF, rec(cF), 'leer_expediente').permitido && !K.evaluarAcceso(cF, rec(cF), 'decidir').permitido);
check('el responsable decide', K.evaluarAcceso(cF, resp(cF), 'decidir').permitido);
const denunte = K.actorDemo(cF.denunciante.ref, T);
check('el denunciante solo accede a la vista de parte', !K.evaluarAcceso(cF, denunte, 'leer_expediente').permitido && K.evaluarAcceso(cF, denunte, 'leer_vista_parte').permitido);
check('aislamiento por tenant: otro tenant queda fuera aunque tenga rol', K.evaluarAcceso(cF, { ...rec(cF), tenantId: 'OTRO-TENANT' }, 'leer_expediente').motivo.includes('tenant'));
check('relación no vigente: acceso denegado', !K.evaluarAcceso(cF, { ...rec(cF), relacionVigente: false }, 'leer_expediente').permitido);
const cConf = ok(K.declararConflictoInteres(ok(K.asignarRol(cF, { personaId: id(2), rol: 'investigador', actor: rec(cF) }, '2026-09-02')), { personaId: id(2), motivo: 'Amistad cercana con el denunciado', actor: rec(cF) }, '2026-09-03'));
check('conflicto de interés: la persona sale del rol y pierde el acceso', cConf.asignaciones.investigadorId === null && !K.evaluarAcceso(cConf, inv(cConf), 'leer_expediente').permitido);
check('quien tiene un conflicto declarado no puede volver a asignarse', !!K.asignarRol(cConf, { personaId: id(2), rol: 'investigador', actor: rec(cConf) }, '2026-09-04').error);
check('una parte no puede ejercer un rol del procedimiento', !!K.asignarRol(cF, { personaId: cF.denunciado.ref, rol: 'investigador', actor: rec(cF) }, '2026-09-02').error);
const reg = K.registrarAcceso(cF, sinRol, 'leer_expediente', '2026-09-05');
check('la bitácora de acceso registra también lo denegado, sin cambiar la versión del caso', reg.caso.bitacoraAcceso.length === 1 && reg.caso.bitacoraAcceso[0].permitido === false && reg.caso.version === cF.version);
check('proyección: completa, de parte y reservada según el rol', K.proyectarCaso(cF, rec(cF)).nivel === 'completo' && K.proyectarCaso(cF, denunte).nivel === 'parte' && K.proyectarCaso(cF, sinRol).nivel === null);
const vistaParte = JSON.stringify(K.proyectarCaso(cF, denunte).vista);
check('la vista de parte no expone historial, conflictos ni a la otra parte', !vistaParte.includes('historial') && !vistaParte.includes('conflictos') && !vistaParte.includes(cF.denunciado.ref));

// ═══ G · Medidas de resguardo: propuesta → ordenada → implementada ═══
let cG = clasif(base());
cG = ok(K.proponerMedidaResguardo(cG, { tipo: 'separacion_espacios_fisicos', destinatarioId: cG.denunciante.ref, fundamento: 'Evitar contacto', actor: rec(cG) }, '2026-09-02'));
check('una medida nueva nace «propuesta»', cG.medidasResguardo[0].estado === 'propuesta');
check('quien recibe no puede ordenar: solo quien decide', K.ordenarMedidaResguardo(cG, { medidaId: 'r1', actor: rec(cG) }, '2026-09-02').sinPermiso === true);
check('una propuesta no se puede implementar', !!K.implementarMedidaResguardo(cG, { medidaId: 'r1', evidenciaRef: 'E-1', actor: rec(cG) }, '2026-09-02').error);
check('la vista de parte no muestra propuestas', K.proyectarCaso(cG, K.actorDemo(cG.denunciante.ref, T)).vista.medidasQueLeAplican.length === 0);
const evalSoloPropuesta = K.registrarEvaluacionInicial(cG, { riesgo: 'medio', decisionMedidas: 'aplicadas', actor: rec(cG) }, '2026-09-02');
check('«hay medidas» con solo una propuesta se rechaza', !!evalSoloPropuesta.error);
cG = ok(K.ordenarMedidaResguardo(cG, { medidaId: 'r1', actor: resp(cG) }, '2026-09-02'));
check('ordenada: ya cuenta y la vista de parte la muestra', !K.registrarEvaluacionInicial(cG, { riesgo: 'medio', decisionMedidas: 'aplicadas', actor: rec(cG) }, '2026-09-02').error && K.proyectarCaso(cG, K.actorDemo(cG.denunciante.ref, T)).vista.medidasQueLeAplican.length === 1);
check('riesgo inmediato exige una medida implementada, no solo ordenada', !!K.registrarEvaluacionInicial(cG, { riesgo: 'inmediato', decisionMedidas: 'aplicadas', actor: rec(cG) }, '2026-09-02').error);
check('implementar exige evidencia y fecha válidas', !!K.implementarMedidaResguardo(cG, { medidaId: 'r1', evidenciaRef: '', actor: rec(cG) }, '2026-09-03').error && !!K.implementarMedidaResguardo(cG, { medidaId: 'r1', fecha: '2026-09-01', evidenciaRef: 'E-1', actor: rec(cG) }, '2026-09-03').error);
cG = ok(K.implementarMedidaResguardo(cG, { medidaId: 'r1', fecha: '2026-09-03', evidenciaRef: 'E-1', actor: rec(cG) }, '2026-09-03'));
check('implementada con evidencia: ahora sí permite el riesgo inmediato', !K.registrarEvaluacionInicial(cG, { riesgo: 'inmediato', decisionMedidas: 'aplicadas', actor: rec(cG) }, '2026-09-03').error);
check('«no requeridas» exige fundamento y no se admite con riesgo inmediato', !!K.registrarEvaluacionInicial(clasif(base()), { riesgo: 'bajo', decisionMedidas: 'no_requeridas', actor: rec(cG) }, '2026-09-02').error && !!K.registrarEvaluacionInicial(clasif(base()), { riesgo: 'inmediato', decisionMedidas: 'no_requeridas', fundamentoNoMedidas: 'x', actor: rec(cG) }, '2026-09-02').error);
const cDesc = ok(K.proponerMedidaResguardo(clasif(base()), { tipo: 'redistribucion_jornada', destinatarioId: id(10), fundamento: 'f', actor: rec(cF) }, '2026-09-02'));
check('descartar exige fundamento y solo aplica a propuestas u ordenadas', !!K.descartarMedidaResguardo(cDesc, { medidaId: 'r1', actor: resp(cDesc) }, '2026-09-02').error && K.descartarMedidaResguardo(cDesc, { medidaId: 'r1', fundamento: 'Ya no procede', actor: resp(cDesc) }, '2026-09-02').caso.medidasResguardo[0].estado === 'descartada' && !!K.descartarMedidaResguardo(cG, { medidaId: 'r1', fundamento: 'x', actor: resp(cG) }, '2026-09-04').error);

// ═══ H · Procedimiento, investigación y debido proceso ═══
const cH = clasif(base());
check('no se selecciona procedimiento antes de la evaluación inicial', !!K.seleccionarProcedimiento(cH, { procedimiento: 'investigacion_interna', fundamento: 'f', actor: resp(cH) }, '2026-09-02').error);
const cHe = evaluada(cH);
const selMal = K.seleccionarProcedimiento(cHe, { procedimiento: 'mediacion_opcional', fundamento: 'f', actor: resp(cHe) }, '2026-09-02');
check('un procedimiento no permitido para la rama se rechaza e informa los permitidos', !!selMal.error && selMal.error.includes('Permitidos'));
check('investigación interna sin investigador se rechaza', !!K.seleccionarProcedimiento(cHe, { procedimiento: 'investigacion_interna', fundamento: 'f', actor: resp(cHe) }, '2026-09-02').error);
const noIdent = evaluada(clasif(base({ denunciante: { tipo: 'no_individualizado' } })));
const noIdentInv = ok(K.asignarRol(noIdent, { personaId: id(2), rol: 'investigador', actor: rec(noIdent) }, '2026-09-02'));
check('denunciante no individualizado: no se investiga (ORD. 146/13)…', !!K.seleccionarProcedimiento(noIdentInv, { procedimiento: 'investigacion_interna', fundamento: 'f', actor: resp(noIdentInv) }, '2026-09-02').error);
check('…y tampoco se deriva a la DT: individualizar es requisito en toda ruta legal', !!K.seleccionarProcedimiento(noIdentInv, { procedimiento: 'derivacion_dt', fundamento: 'f', actor: resp(noIdentInv) }, '2026-09-02').error);
const art4 = evaluada(clasif(base({ denunciado: { tipo: 'trabajador', personaId: id(16), relacion: 'art4_inc1' } })));
check('denunciado del art. 4 inc. 1: solo derivación a la DT', !!K.seleccionarProcedimiento(ok(K.asignarRol(art4, { personaId: id(2), rol: 'investigador', actor: rec(art4) }, '2026-09-02')), { procedimiento: 'investigacion_interna', fundamento: 'f', actor: resp(art4) }, '2026-09-02').error);
const art4s = ok(K.seleccionarProcedimiento(art4, { procedimiento: 'derivacion_dt', fundamento: 'art. 4 inc. 1', actor: resp(art4) }, '2026-09-02'));
const art4d = ok(K.derivarADT(art4s, { fecha: '2026-09-02', referencia: 'DT-DERIV-1', actor: resp(art4s) }, '2026-09-02'));
check('derivar a la DT: estado «derivado_dt» y evento derivado_a_dt', art4d.estado === 'derivado_dt' && art4d.eventos.derivado_a_dt === '2026-09-02');
check('derivar sin haber seleccionado la derivación se rechaza', !!K.derivarADT(cHe, { referencia: 'X-1', actor: resp(cHe) }, '2026-09-02').error);
const cI = enInvestigacion(cHe);
check('iniciar la investigación: estado «en_investigacion» con su fecha', cI.estado === 'en_investigacion' && cI.eventos.investigacion_iniciada === '2026-09-03');
check('no se inicia una investigación antes de la recepción de la denuncia', !!K.iniciarInvestigacion(ok(K.seleccionarProcedimiento(ok(K.asignarRol(cHe, { personaId: id(2), rol: 'investigador', actor: rec(cHe) }, '2026-09-02')), { procedimiento: 'investigacion_interna', fundamento: 'f', actor: resp(cHe) }, '2026-09-02')), { fecha: '2026-08-01', actor: rec(cHe) }, '2026-09-02').error);
check('en la investigación interna solo el investigador registra actuaciones', K.registrarActuacion(cI, { tipo: 'entrevista', participantes: [id(11)], actor: rec(cI) }, '2026-09-04').sinPermiso === true && !K.registrarActuacion(cI, { tipo: 'entrevista', participantes: [id(11)], actor: inv(cI) }, '2026-09-04').error);
check('citar o entrevistar exige indicar a quién; tipo y referencia válidos', !!K.registrarActuacion(cI, { tipo: 'citacion', actor: inv(cI) }, '2026-09-04').error && !!K.registrarActuacion(cI, { tipo: 'inventada', actor: inv(cI) }, '2026-09-04').error && !!K.registrarActuacion(cI, { tipo: 'recepcion_prueba', referencia: 'a\nb', actor: inv(cI) }, '2026-09-04').error);
check('debido proceso: partes pendientes → oídas o con oportunidad otorgada', K.estadoAudienciaPartes(cI).denunciante === 'pendiente' && K.estadoAudienciaPartes(oidas(cI)).denunciado === 'oida' && K.estadoAudienciaPartes(ok(K.registrarActuacion(cI, { tipo: 'citacion', participantes: [cI.denunciado.ref], resultado: 'no_comparecio', actor: inv(cI) }, '2026-09-05'))).denunciado === 'oportunidad_otorgada');
const sinOir = K.registrarConclusiones(cI, { resultado: 'hechos_acreditados', referenciaInforme: 'INF-1', actor: inv(cI) }, '2026-09-20');
check('no se concluye sin oír a ambas partes', !!sinOir.error && sinOir.error.includes('oír'));
const cConcl = concluida(cI);
check('conclusiones: estado «conclusiones» y evento investigacion_concluida', cConcl.estado === 'conclusiones' && cConcl.eventos.investigacion_concluida === '2026-09-20');
check('las evaluaciones médicas o psicológicas no son automáticas: exigen fundamento y base', !!K.solicitarEvaluacionProfesional(cI, { tipo: 'psicologica', profesionalRef: 'PROF-1', actor: resp(cI) }, '2026-09-04').error && !!K.solicitarEvaluacionProfesional(cI, { tipo: 'psicologica', fundamento: 'f', profesionalRef: 'PROF-1', actor: resp(cI) }, '2026-09-04').error);
const ev1 = K.solicitarEvaluacionProfesional(cI, { tipo: 'psicologica', fundamento: 'Pertinente al caso', baseJuridica: 'Art. aplicable', profesionalRef: 'PROF-1', actor: resp(cI) }, '2026-09-04');
const ev2 = K.registrarResultadoEvaluacion(ev1.caso, { evaluacionId: ev1.evaluacionId, referenciaInforme: 'INF-PSI-1', actor: resp(cI) }, '2026-09-06');
check('el informe clínico queda fuera del expediente laboral: solo su referencia, y una sola vez', ev1.caso.evaluacionesProfesionales[0].informeFueraDelExpediente === true && ev2.caso.evaluacionesProfesionales[0].estado === 'informada' && !!K.registrarResultadoEvaluacion(ev2.caso, { evaluacionId: ev1.evaluacionId, referenciaInforme: 'OTRO', actor: resp(cI) }, '2026-09-07').error);

// ═══ I · Flujo legal completo, decisión ≠ cumplimiento y cierre ═══
check('no se remite el informe a la DT antes de concluir; después sí; una sola vez', !!K.remitirInformeADT(cI, { referencia: 'E-1', actor: resp(cI) }, '2026-09-21').error && !K.remitirInformeADT(cConcl, { fecha: '2026-09-21', referencia: 'E-1', actor: resp(cConcl) }, '2026-09-21').error && !!K.remitirInformeADT(remitida(cConcl), { referencia: 'E-2', actor: resp(cConcl) }, '2026-09-22').error);
check('las conclusiones de la DT solo tras remitir el informe', !!K.registrarConclusionesDT(cConcl, { referencia: 'DT-1', actor: rec(cConcl) }, '2026-10-01').error && conclDT(remitida(cConcl)).eventos.conclusiones_dt_notificadas === '2026-10-05');
const cDT = hastaDT();
check('en el procedimiento legal no se disponen medidas antes de las conclusiones de la DT', !!K.registrarMedidaCorrectiva(remitida(cConcl), { tipo: 'capacitacion', destinatarioId: id(15), fundamento: 'f', actor: resp(cConcl) }, '2026-09-25').error);
check('quien recibe no dispone medidas; el responsable sí, con destinatario y fundamento', K.registrarMedidaCorrectiva(cDT, { tipo: 'capacitacion', destinatarioId: id(15), fundamento: 'f', actor: rec(cDT) }, '2026-10-06').sinPermiso === true && !!K.registrarMedidaCorrectiva(cDT, { tipo: 'capacitacion', fundamento: 'f', actor: resp(cDT) }, '2026-10-06').error && !K.registrarMedidaCorrectiva(cDT, { tipo: 'capacitacion', destinatarioId: id(15), fundamento: 'Reglamento interno', actor: resp(cDT) }, '2026-10-06').error);
const cM = ok(K.registrarMedidaCorrectiva(cDT, { tipo: 'capacitacion', destinatarioId: id(15), fundamento: 'Reglamento interno', actor: resp(cDT) }, '2026-10-06'));
const cMA = ok(K.marcarMedidaAplicada(cM, { medidaId: 'c1', fecha: '2026-10-08', evidenciaRef: 'EVID-C1', actor: resp(cM) }, '2026-10-08'));
check('medidas realmente aplicadas: evento medidas_correctivas_aplicadas y NO la decisión de no aplicar', cMA.estado === 'en_seguimiento' && cMA.eventos.medidas_correctivas_aplicadas === '2026-10-08' && cMA.eventos.decision_sin_medidas === undefined);
check('el reloj de medidas (K4) queda CUMPLIDO solo con medidas aplicadas', K.calcularRelojes(cMA, '2026-10-09').find((r) => r.reglaId === 'K4_MEDIDAS_EMPLEADOR').estado === 'cumplido');
const cSM = ok(K.declararSinMedidas(cDT, { fundamento: 'Hechos no acreditados', actor: resp(cDT) }, '2026-10-06'));
check('decidir no aplicar medidas registra OTRO hecho: decision_sin_medidas, no medidas aplicadas', cSM.eventos.decision_sin_medidas === '2026-10-06' && cSM.eventos.medidas_correctivas_aplicadas === undefined && cSM.estado === 'en_seguimiento');
const k4 = K.calcularRelojes(cSM, '2026-10-07').find((r) => r.reglaId === 'K4_MEDIDAS_EMPLEADOR');
check('el plazo de medidas NO se da por cumplido con la decisión: queda «decidido sin medidas» para revisión', k4.estado === 'decidido_sin_medidas' && k4.requiereRevision === true && !K.calcularAlertasCasos([cSM], '2026-10-07').some((a) => a.reloj.reglaId === 'K4_MEDIDAS_EMPLEADOR'));
check('sin medidas exige fundamento; y es incompatible con medidas ya dispuestas', !!K.declararSinMedidas(cDT, { actor: resp(cDT) }, '2026-10-06').error && !!K.declararSinMedidas(cM, { fundamento: 'x', actor: resp(cM) }, '2026-10-07').error && !!K.registrarMedidaCorrectiva(cSM, { tipo: 'capacitacion', destinatarioId: id(15), fundamento: 'f', actor: resp(cSM) }, '2026-10-07').error);
check('cerrar con la decisión sin medidas advierte que el plazo no se cumplió', K.verificarCierre(cSM, 'sin_medidas_fundamentado', '2026-10-07').advertencias.length >= 1);
check('no se cierra con medidas dispuestas sin aplicar', !K.verificarCierre(cM, 'medidas_aplicadas', '2026-10-07').puedeCerrar && K.verificarCierre(cM, 'medidas_aplicadas', '2026-10-07').bloqueantes.some((x) => x.includes('sin aplicar')));
check('seguimiento: resultado inválido se rechaza', !!K.registrarSeguimiento(cMA, { medidaId: 'c1', resultado: 'raro', actor: resp(cMA) }, '2026-10-09').error);
check('cerrar exige motivo válido y fundamento', !!K.cerrarCaso(cMA, { motivoCierre: 'inventado', fundamento: 'f', actor: resp(cMA) }, '2026-10-20').error && !!K.cerrarCaso(cMA, { motivoCierre: 'medidas_aplicadas', actor: resp(cMA) }, '2026-10-20').error);
const cCerr = ok(K.cerrarCaso(cMA, { motivoCierre: 'medidas_aplicadas', fundamento: 'Medidas verificadas', actor: resp(cMA) }, '2026-10-20'));
check('caso cerrado: ninguna operación posterior lo modifica', cCerr.estado === 'cerrado' && !!K.proponerMedidaResguardo(cCerr, { tipo: 'redistribucion_jornada', destinatarioId: id(10), fundamento: 'f', actor: rec(cCerr) }, '2026-10-21').error && !!K.registrarActuacion(cCerr, { tipo: 'otra', actor: inv(cCerr) }, '2026-10-21').error);

// ═══ J · Relojes ═══
const cJ = clasif(base({ recibidaEn: '2026-10-17' }), '2026-10-17');
const k1 = (hoy) => K.calcularRelojes(cJ, hoy).find((r) => r.reglaId === 'K1_DECISION_EMPLEADOR');
check('K1: ambigua con 2 variantes; alerta por la más temprana y muestra la más tardía', k1('2026-10-17').variantes === 2 && k1('2026-10-17').vencimientoOperativo === '2026-10-20' && k1('2026-10-17').vencimientoMaximo === '2026-10-21' && k1('2026-10-17').validada === false);
check('K1 con margen, urgente y vencido según la fecha de hoy', k1('2026-10-17').nivel === 'ok' && k1('2026-10-19').nivel === 'urgente' && k1('2026-10-22').nivel === 'vencido' && k1('2026-10-22').diasRestantes < 0);
check('sin clasificar, K1 se muestra como provisional', K.calcularRelojes(base({ recibidaEn: '2026-10-17' }), '2026-10-17').find((r) => r.reglaId === 'K1_DECISION_EMPLEADOR').provisional === true);
check('cruzar de año con días hábiles deja una advertencia de calendario', K.calcularRelojes(clasif(base({ recibidaEn: '2026-12-30' }), '2026-12-30'), '2026-12-30').find((r) => r.reglaId === 'K1_DECISION_EMPLEADOR').advertencias.includes('feriados_no_cargados_2027'));
const cDTcanal = clasif(base({ canal: 'dt' }));
check('denuncia presentada ante la DT: K1 no aplica; su reloj es informativo y no genera alertas', !K.calcularRelojes(cDTcanal, '2026-09-02').some((r) => r.reglaId === 'K1_DECISION_EMPLEADOR') && K.calcularRelojes(cDTcanal, '2026-09-02').find((r) => r.reglaId === 'K0_RESGUARDO_DT').informativa === true && K.calcularAlertasCasos([cDTcanal], '2026-09-02').length === 0);
check('régimen estatutario: este paquete no genera relojes', K.calcularRelojes(pubE.caso, '2026-09-02').length === 0);
check('el cumplimiento se registra con el evento y se compara con ambos vencimientos', (() => { const r = K.calcularRelojes(cI, '2026-09-04').find((x) => x.reglaId === 'K1_DECISION_EMPLEADOR'); return r.estado === 'cumplido' && r.cumplidoEn === '2026-09-03' && r.cumplidoDentroOperativo === true; })());

// ═══ K · Máquina de estados (propiedad: ninguna secuencia viola TRANSICIONES) ═══
check('toda transición declarada apunta a un estado que existe', Object.entries(K.TRANSICIONES).every(([d, hs]) => K.ESTADOS[d] && hs.every((h) => K.ESTADOS[h])));
check('puedeTransicionar: permitida, prohibida e idempotente', K.puedeTransicionar('clasificada', 'evaluacion_inicial') && !K.puedeTransicionar('recibida', 'cerrado') && K.puedeTransicionar('recibida', 'recibida') && K.TRANSICIONES.cerrado.length === 0);
function prng(seed) { let a = seed >>> 0; return () => { a = (a + 0x6D2B79F5) >>> 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
let transiciones = 0, errores = 0, mutaciones = 0, saltosIlegales = 0, cierres = 0, llegoAEtapa = new Set();
for (let s = 1; s <= 60; s++) {
  const rnd = prng(s * 7919), pick = (arr) => arr[Math.floor(rnd() * arr.length)];
  let c = base({ id: `F-${s}`, recibidaEn: '2026-09-01' });
  const RAM = Object.keys(K.RAMAS), PROC = Object.keys(K.PROCEDIMIENTOS), MOT = Object.keys(K.MOTIVOS_CIERRE ?? { medidas_aplicadas: 1 });
  const ops = [
    (c, a) => K.clasificarCaso(c, { ramaId: pick(RAM), motivo: 'fuzz', regimenJuridico: pick(['codigo_trabajo', 'estatutario_publico', undefined]), actor: a }, '2026-09-02'),
    (c, a) => K.solicitarComplemento(c, { plazoDias: 2, tipoDia: 'corrido', fundamento: 'f', actor: a }, '2026-09-02'),
    (c, a) => K.recibirComplemento(c, { referencia: 'C-1', actor: a }, '2026-09-03'),
    (c, a) => K.continuarSinComplemento(c, { fundamento: 'f', actor: a }, '2026-09-30'),
    (c, a) => K.proponerMedidaResguardo(c, { tipo: 'redistribucion_jornada', destinatarioId: c.denunciante.ref, fundamento: 'f', actor: a }, '2026-09-02'),
    (c, a) => K.ordenarMedidaResguardo(c, { medidaId: pick(['r1', 'r2']), actor: a }, '2026-09-02'),
    (c, a) => K.implementarMedidaResguardo(c, { medidaId: pick(['r1', 'r2']), fecha: '2026-09-02', evidenciaRef: 'E-1', actor: a }, '2026-09-02'),
    (c, a) => K.registrarEvaluacionInicial(c, { riesgo: pick(K.RIESGOS), decisionMedidas: pick(['aplicadas', 'no_requeridas']), fundamentoNoMedidas: 'f', actor: a }, '2026-09-02'),
    (c, a) => K.asignarRol(c, { personaId: id(2), rol: 'investigador', actor: a }, '2026-09-02'),
    (c, a) => K.seleccionarProcedimiento(c, { procedimiento: pick(PROC), fundamento: 'f', actor: a }, '2026-09-02'),
    (c, a) => K.iniciarInvestigacion(c, { fecha: '2026-09-03', actor: a }, '2026-09-03'),
    (c, a) => K.derivarADT(c, { fecha: '2026-09-03', referencia: 'D-1', actor: a }, '2026-09-03'),
    (c, a) => K.registrarActuacion(c, { tipo: 'declaracion', fecha: '2026-09-10', participantes: [pick([c.denunciante.ref, c.denunciado.ref].filter(Boolean))], actor: a }, '2026-09-10'),
    (c, a) => K.registrarConclusiones(c, { resultado: 'hechos_acreditados', referenciaInforme: 'I-1', fecha: '2026-09-20', actor: a }, '2026-09-20'),
    (c, a) => K.remitirInformeADT(c, { fecha: '2026-09-21', referencia: 'R-1', actor: a }, '2026-09-21'),
    (c, a) => K.registrarConclusionesDT(c, { fecha: '2026-10-05', referencia: 'DT-1', actor: a }, '2026-10-05'),
    (c, a) => K.registrarMedidaCorrectiva(c, { tipo: 'capacitacion', destinatarioId: id(15), fundamento: 'f', actor: a }, '2026-10-06'),
    (c, a) => K.marcarMedidaAplicada(c, { medidaId: 'c1', fecha: '2026-10-08', evidenciaRef: 'E-C1', actor: a }, '2026-10-08'),
    (c, a) => K.declararSinMedidas(c, { fundamento: 'f', actor: a }, '2026-10-06'),
    (c, a) => K.registrarSeguimiento(c, { resultado: 'cumplida', fecha: '2026-10-09', actor: a }, '2026-10-09'),
    (c, a) => K.cerrarCaso(c, { motivoCierre: pick(MOT), fundamento: 'f', actor: a }, '2026-10-20'),
  ];
  for (let paso = 0; paso < 60; paso++) {
    const antes = snap(c), act = pick([rec(c), resp(c), inv(c), rec(c), resp(c)]);
    const r = pick(ops)(c, act);
    if (r.error) { errores++; if (snap(c) !== antes) mutaciones++; continue; }
    const n = r.caso;
    if (!K.puedeTransicionar(c.estado, n.estado)) saltosIlegales++;
    if (n.version !== c.version + 1 || n.historial.length !== c.historial.length + 1 || snap(c) !== antes) mutaciones++;
    if (n.estado !== c.estado) transiciones++;
    if (n.estado === 'cerrado') cierres++;
    llegoAEtapa.add(n.estado); c = n;
  }
}
check(`fuzz (60 secuencias × 60 pasos): ${transiciones} transiciones, ${errores} rechazos, ninguna ilegal`, saltosIlegales === 0 && transiciones > 100, `ilegales=${saltosIlegales} transiciones=${transiciones}`);
check('fuzz: cada operación exitosa suma una versión y un registro de historial, y ninguna muta el caso anterior', mutaciones === 0, `mutaciones=${mutaciones}`);
check(`fuzz: la exploración llegó a ${llegoAEtapa.size} estados distintos (≥ 6)`, llegoAEtapa.size >= 6, [...llegoAEtapa].join(','));

// ═══ L · Eventos, KPIs y mock ═══
const EM = '2026-10-17T12:00:00.000Z';
const ev = K.construirCaseOpenedEvent(cI, EM), ev2b = K.construirCaseOpenedEvent(cI, EM);
check('evento: contrato común completo (id, idempotencia, versión de esquema, tenant, actor, tiempo efectivo, correlación)', ['eventId', 'idempotencyKey', 'schemaVersion', 'tipo', 'dominioOrigen', 'tenantId', 'legalEntityId', 'actorRef', 'ocurridoEn', 'emitidoEn', 'correlationId', 'payload'].every((k) => k in ev) && ev.dominioOrigen === 'workforce' && ev.schemaVersion === K.SCHEMA_EVENTOS_CASOS);
check('evento: tiempo efectivo ≠ tiempo de emisión, y la clave de idempotencia es determinística', ev.ocurridoEn === cI.eventos.denuncia_recibida && ev.emitidoEn === EM && ev.idempotencyKey === ev2b.idempotencyKey && ev.eventId === ev2b.eventId && ev.correlationId === cI.id);
const evTxt = JSON.stringify([ev, K.construirInvestigationStartedEvent(cI, EM), K.construirInvestigationClosedEvent(cConcl, EM), K.construirCaseClosedEvent(cCerr, EM)]);
check('eventos: solo identificadores opacos; no filtran las partes ni el relato', !evTxt.includes(cI.denunciante.ref) && !evTxt.includes(cI.denunciado.ref) && !evTxt.includes('RELATO'));
check('eventos condicionados: sin hecho no se emiten', K.construirInvestigationStartedEvent(cF, EM) === null && K.construirInvestigationClosedEvent(cI, EM) === null && K.construirCaseClosedEvent(cMA, EM) === null && K.construirCaseClosedEvent(cCerr, EM).payload.motivoCierre === 'medidas_aplicadas');
const HOY = '2026-10-17';
const mock = K.generarCasosMock(personas, HOY);
check('mock: determinístico (dos corridas idénticas) y con 19 casos de ids únicos', snap(mock) === snap(K.generarCasosMock(personas, HOY)) && mock.length === 19 && new Set(mock.map((c) => c.id)).size === 19);
check('mock: cubre las 6 etapas del flujo A-F', Object.keys(K.ETAPAS).every((e) => mock.some((c) => K.ESTADOS[c.estado].etapa === e)));
check('mock: cubre las 5 ramas y el caso sin clasificar', Object.keys(K.RAMAS).every((r) => mock.some((c) => c.ramaId === r)) && mock.some((c) => c.ramaId === null));
check('mock: cubre canal DT, art. 4 inc. 1, régimen estatutario, Código del Trabajo en institución pública y complemento', mock.some((c) => c.canalIngreso === 'dt') && mock.some((c) => c.denunciado.relacion === 'art4_inc1') && mock.some((c) => c.regimenJuridico === 'estatutario_publico') && mock.some((c) => c.sectorTenant === 'publico' && c.regimenJuridico === 'codigo_trabajo') && mock.some((c) => c.estado === 'por_complementar'));
const rel = mock.flatMap((c) => K.calcularRelojes(c, HOY)).filter((r) => r.estado === 'corriendo' && !r.informativa);
check('mock: relojes en los cuatro niveles (con margen, pronto, urgente, vencido)', ['ok', 'pronto', 'urgente', 'vencido'].every((n) => rel.some((r) => r.nivel === n)));
check('mock: hay una decisión sin medidas y un caso cerrado de punta a punta', mock.some((c) => K.calcularRelojes(c, HOY).some((r) => r.estado === 'decidido_sin_medidas')) && mock.filter((c) => c.estado === 'cerrado').length === 1);
check('mock: la institución pública con Código del Trabajo tiene reloj; la estatutaria no', K.calcularRelojes(mock.find((c) => c.sectorTenant === 'publico' && c.regimenJuridico === 'codigo_trabajo'), HOY).length > 0 && K.calcularRelojes(mock.find((c) => c.regimenJuridico === 'estatutario_publico'), HOY).length === 0);
const al = K.calcularAlertasCasos(mock, HOY);
check('alertas: ordenadas por vencimiento, sin casos cerrados ni relojes informativos', al.length > 0 && al.every((a, i) => i === 0 || al[i - 1].reloj.vencimientoOperativo <= a.reloj.vencimientoOperativo) && al.every((a) => a.caso.estado !== 'cerrado' && !a.reloj.informativa));
const kp = K.calcularKPIsCasos(mock, HOY);
check('KPIs: abiertos + cerrados = total; vencidos y resguardo implementado cuentan', kp.abiertos + kp.cerrados === 19 && kp.cerrados === 1 && kp.relojesVencidos >= 1 && kp.medidasResguardoActivas >= 5 && kp.sinClasificar === 2 && kp.porComplementar === 1);
const kpS = K.calcularKPIsCasos(mock, HOY, K.PAQUETE_REGLAS_CL_BORRADOR, K.CALENDARIO_CL, { umbralSupresion: 3 });
check('indicadores agregados para niveles superiores: se suprimen cantidades pequeñas', kpS.porRama.filter((x) => x.cantidad === null).every((x) => x.suprimido === true) && kpS.porRama.some((x) => x.suprimido) && kp.porRama.every((x) => x.cantidad !== null));

console.log(`\n${fallas === 0 ? '✅ TODO OK' : `❌ ${fallas} FALLA(S)`} — Casos laborales (${total} checks)`);
process.exit(fallas === 0 ? 0 : 1);
