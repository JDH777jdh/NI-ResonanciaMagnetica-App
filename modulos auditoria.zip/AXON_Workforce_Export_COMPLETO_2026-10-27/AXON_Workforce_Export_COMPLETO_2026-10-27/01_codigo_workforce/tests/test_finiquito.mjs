import { calcularFiniquito, calcularAntiguedad, construirTerminationCalculatedEvent, calcularKPIsFiniquitos } from './bundles/Finiquito.mjs';

let fallas = 0;
function check(n, c, d) { if (!c) { fallas++; console.log(`❌ ${n} — ${d || ''}`); } else console.log(`✅ ${n}`); }
const UF = 40885.63;

const w5anios = { id: 'w1', fechaIngreso: '2021-09-11' };
const f1 = calcularFiniquito(w5anios, 'necesidades_empresa', 1000000, '2026-09-11', true, 10);
check('IAS = sueldo × 5 años = 5.000.000', f1.indemnizacionAnios === 5000000);
check('sustitutiva = 0 (con aviso previo)', f1.indemnizacionSustitutiva === 0);
check('especial obra = 0 (causal no es conclusión de obra)', f1.indemnizacionEspecialObra === 0);

const topeEsperado = Math.round(90 * UF * 5);
const f2 = calcularFiniquito(w5anios, 'necesidades_empresa', 6000000, '2026-09-11', true, 0);
check('IAS se topa a 90 UF por año', f2.indemnizacionAnios === topeEsperado, `fue ${f2.indemnizacionAnios} esperado ${topeEsperado}`);

const w20anios = { id: 'w2', fechaIngreso: '2006-09-11' };
const f3 = calcularFiniquito(w20anios, 'necesidades_empresa', 1000000, '2026-09-11', true, 0);
check('IAS se topa a 11 años aunque tenga 20', f3.aniosUsadosIAS === 11);
check('IAS con tope = sueldo × 11', f3.indemnizacionAnios === 11000000);

const f4 = calcularFiniquito(w5anios, 'necesidades_empresa', 1000000, '2026-09-11', false, 0);
check('sustitutiva = 1 mes sin aviso previo', f4.indemnizacionSustitutiva === 1000000);

const f5 = calcularFiniquito(w20anios, 'renuncia_voluntaria', 1000000, '2026-09-11', false, 8);
check('renuncia: IAS = 0 (aunque tenga 20 años)', f5.indemnizacionAnios === 0);
check('renuncia: sustitutiva = 0', f5.indemnizacionSustitutiva === 0);
check('renuncia: SÍ paga vacaciones pendientes', f5.pagoVacacionesPendientes > 0);

const w15meses = { id: 'w3', fechaIngreso: '2025-06-11' };
const f6 = calcularFiniquito(w15meses, 'conclusion_obra', 900000, '2026-09-11', false, 3);
const mesesEsperados = calcularAntiguedad('2025-06-11', '2026-09-11').mesesCompletos;
check('especial obra = (sueldo/30×2,5) × meses', f6.indemnizacionEspecialObra === Math.round((900000 / 30) * 2.5 * mesesEsperados));
check('especial obra NO usa tope de 11 años (concepto distinto de IAS)', f6.indemnizacionAnios === 0);

const w8y7m = { id: 'w4', fechaIngreso: '2018-02-01' };
const f7 = calcularFiniquito(w8y7m, 'necesidades_empresa', 1000000, '2026-09-11', true, 0);
check('8 años y >6 meses de fracción → 9 años para IAS', f7.aniosUsadosIAS === 9, `fue ${f7.aniosUsadosIAS}`);
check('antigüedad exacta en días aunque cruce un cambio de horario (11-jun → 11-sep = 92)', calcularAntiguedad('2026-06-11', '2026-09-11').diffDias === 92);
const fDst = calcularFiniquito({ id: 'w5', fechaIngreso: '2020-05-15' }, 'necesidades_empresa', 1000000, '2025-11-14', true, 0);
check('fracción de 183 días (>182) cuenta como año completo aunque cruce un cambio de horario', fDst.aniosUsadosIAS === 6, `fue ${fDst.aniosUsadosIAS}`);

const evento = construirTerminationCalculatedEvent(f1);
check('evento.tipo = TerminationCalculated', evento.tipo === 'TerminationCalculated');
const kpis = calcularKPIsFiniquitos([f1, f4, f5, f6]);
check('conIAS = 2 (f1 y f4 comparten causal necesidades_empresa)', kpis.conIAS === 2);
check('conEspecialObra = 1', kpis.conEspecialObra === 1);

console.log(`\n${fallas === 0 ? '✅ TODO OK' : `❌ ${fallas} FALLA(S)`} — Egreso y Finiquito`);
process.exit(fallas === 0 ? 0 : 1);
