import { calcularLiquidacion, calcularKPIsRemuneraciones, construirPayrollCalculatedEvent, construirPayloadLiquidacionRRHH } from './bundles/Remuneraciones.mjs';

const clp = (n) => '$' + Math.round(n).toLocaleString('es-CL');
let fallas = 0;
function check(n, c, d) { if (!c) { fallas++; console.log(`❌ ${n} — ${d || ''}`); } else console.log(`✅ ${n}`); }
function w(o) { return { id: 'w1', sueldoBase: 1500000, tipoContrato: 'indefinido', afpId: 'habitat', sistemaSalud: 'fonasa', planIsaprePct: null, ...o }; }

const l1 = calcularLiquidacion(w({ sueldoBase: 1500000 }), '2026-09', { horasExtraTrabajadas: 0, bonos: 0, asignacionesNoImponibles: 45000 });
check('total haberes = imponible + no imponible', l1.haberes.totalHaberes === l1.haberes.totalImponible + l1.haberes.asignacionesNoImponibles);
check('líquido = haberes - descuentos', l1.liquidoAPago === l1.haberes.totalHaberes - l1.descuentos.totalDescuentos);
check('AFP > 0', l1.descuentos.afp > 0);
check('Salud = 7% de imponible (Fonasa)', Math.abs(l1.descuentos.salud - Math.round(l1.haberes.totalImponible * 0.07)) <= 1);
check('Cesantía = 0,6% (indefinido)', Math.abs(l1.descuentos.cesantia - Math.round(l1.haberes.totalImponible * 0.006)) <= 1);
const grat25 = Math.round(l1.haberes.sueldoBase * 0.25), topeGrat = Math.round((553553 * 4.75) / 12);
check('gratificación = min(25%, tope mensual)', l1.haberes.gratificacion === Math.min(grat25, topeGrat));

const l2 = calcularLiquidacion(w({ sueldoBase: 620000 }), '2026-09', { horasExtraTrabajadas: 0, bonos: 0, asignacionesNoImponibles: 45000 });
check('impuesto único = 0 bajo 13,5 UTM', l2.descuentos.impuestoUnico === 0);

const l3 = calcularLiquidacion(w({ sueldoBase: 4000000 }), '2026-09', { horasExtraTrabajadas: 0, bonos: 0, asignacionesNoImponibles: 45000 });
check('impuesto único > 0 sobre el tramo exento', l3.descuentos.impuestoUnico > 0);
check('líquido razonable (55%-85% del bruto)', l3.liquidoAPago > l3.haberes.totalHaberes * 0.55 && l3.liquidoAPago < l3.haberes.totalHaberes * 0.85);

const l4 = calcularLiquidacion(w({ sueldoBase: 1500000, tipoContrato: 'plazo_fijo' }), '2026-09', { horasExtraTrabajadas: 0, bonos: 0, asignacionesNoImponibles: 45000 });
check('cesantía trabajador = 0 en plazo fijo', l4.descuentos.cesantia === 0);

const UF = 40885.63, topePesos = Math.round(89.9 * UF);
const l5b = calcularLiquidacion(w({ sueldoBase: topePesos + 2000000 }), '2026-09', { horasExtraTrabajadas: 0, bonos: 0, asignacionesNoImponibles: 0 });
check('salud topada ≈ 7% del tope de 89,9 UF', Math.abs(l5b.descuentos.salud - Math.round(topePesos * 0.07)) < 3000);

const l6 = calcularLiquidacion(w({ sueldoBase: 1800000 }), '2026-09', { horasExtraTrabajadas: 10, bonos: 0, asignacionesNoImponibles: 0 });
const valorHoraExtraEsperado = Math.round((1800000 / 180) * 1.5);
check('valor hora extra = 1,5x hora ordinaria (piso 50%)', l6.haberes.valorHoraExtra === valorHoraExtraEsperado);

const kpis = calcularKPIsRemuneraciones([l1, l2, l3, l4]);
check('totalLiquido = suma de líquidos', kpis.totalLiquido === l1.liquidoAPago + l2.liquidoAPago + l3.liquidoAPago + l4.liquidoAPago);

const evento = construirPayrollCalculatedEvent(l1), payload = construirPayloadLiquidacionRRHH(l1);
check('evento.tipo = PayrollCalculated', evento.tipo === 'PayrollCalculated');
check('payload.sueldoBruto = totalHaberes', payload.sueldoBruto === l1.haberes.totalHaberes);

// Recargo pactado — corrección real de esta sesión (Parte 6.2 del dossier)
const l7a = calcularLiquidacion(w({ sueldoBase: 1800000, recargoHoraExtraPactado: 0.75 }), '2026-09', { horasExtraTrabajadas: 10, bonos: 0, asignacionesNoImponibles: 0 });
const l7b = calcularLiquidacion(w({ sueldoBase: 1800000, recargoHoraExtraPactado: 0.50 }), '2026-09', { horasExtraTrabajadas: 10, bonos: 0, asignacionesNoImponibles: 0 });
const l7c = calcularLiquidacion(w({ sueldoBase: 1800000, recargoHoraExtraPactado: 0.20 }), '2026-09', { horasExtraTrabajadas: 10, bonos: 0, asignacionesNoImponibles: 0 });
check('recargo pactado 75% se aplica', l7a.haberes.recargoAplicado === 0.75);
check('75% > 50% en valor hora extra', l7a.haberes.valorHoraExtra > l7b.haberes.valorHoraExtra);
check('NUNCA se puede pactar bajo el piso legal (20%→50%)', l7c.haberes.recargoAplicado === 0.50);
check('sin recargoHoraExtraPactado definido, cae al piso (no rompe)', l1.haberes.recargoAplicado === 0.50);

console.log(`\n${fallas === 0 ? '✅ TODO OK' : `❌ ${fallas} FALLA(S)`} — Remuneraciones`);
process.exit(fallas === 0 ? 0 : 1);
