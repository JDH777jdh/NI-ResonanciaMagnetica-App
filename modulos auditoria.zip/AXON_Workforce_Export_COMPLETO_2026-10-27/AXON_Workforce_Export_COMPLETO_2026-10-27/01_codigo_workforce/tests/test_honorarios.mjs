import { calcularHonorario, construirHonorariumCalculatedEvent, calcularKPIsHonorarios } from './bundles/Honorarios.mjs';

let fallas = 0;
function check(n, c, d) { if (!c) { fallas++; console.log(`❌ ${n} — ${d || ''}`); } else console.log(`✅ ${n}`); }

const profNatural = { id: 'p1', tipoPersona: 'natural' };
const h1 = calcularHonorario(profNatural, '2026-09', [{ tipo: 'Sesión', cantidad: 8, tarifa: 32000 }]);
check('montoBruto = cantidad × tarifa', h1.montoBruto === 8 * 32000);
check('documento = BHE para persona natural', h1.documento === 'BHE');
check('retención = 15,25%', h1.retencion === Math.round(h1.montoBruto * 0.1525));
check('líquido a pago = bruto - retención', h1.liquidoAPago === h1.montoBruto - h1.retencion);
check('sin IVA para persona natural', h1.iva === 0);
check('totalAPagarAXON = líquido (natural)', h1.totalAPagarAXON === h1.liquidoAPago);

const profEmpresa = { id: 'p2', tipoPersona: 'empresa' };
const h2 = calcularHonorario(profEmpresa, '2026-09', [{ tipo: 'Informe', cantidad: 1, tarifa: 450000 }]);
check('documento = Factura para empresa', h2.documento === 'Factura');
check('sin retención para empresa', h2.retencion === 0);
check('IVA = 19% del bruto', h2.iva === Math.round(h2.montoBruto * 0.19));
check('totalAPagarAXON = bruto + IVA (empresa)', h2.totalAPagarAXON === h2.montoBruto + h2.iva);

const h3 = calcularHonorario(profNatural, '2026-09', [{ tipo: 'Sesión', cantidad: 5, tarifa: 30000 }, { tipo: 'Extra', cantidad: 1, tarifa: 20000 }]);
check('montoBruto suma varios servicios', h3.montoBruto === 5 * 30000 + 1 * 20000);

const evento = construirHonorariumCalculatedEvent(h1);
check('evento.tipo = HonorariumCalculated', evento.tipo === 'HonorariumCalculated');

const kpis = calcularKPIsHonorarios([h1, h2, h3]);
check('profesionales = 3', kpis.profesionales === 3);
check('conBHE = 2, conFactura = 1', kpis.conBHE === 2 && kpis.conFactura === 1);

console.log(`\n${fallas === 0 ? '✅ TODO OK' : `❌ ${fallas} FALLA(S)`} — Honorarios`);
process.exit(fallas === 0 ? 0 : 1);
