import * as esbuild from 'esbuild';
import fs from 'fs';

// Carpeta con los .jsx. run_all.sh los deja en ./wf; para otra ubicación: WF_DIR=/ruta node build_all.mjs
const DIR = process.env.WF_DIR || 'wf';

// Agregar acá cada sección nueva: [nombre del bundle, archivo].
const archivos = [
  ['Personas', 'WorkforcePersonas.jsx'],
  ['Remuneraciones', 'WorkforceRemuneraciones.jsx'],
  ['Honorarios', 'WorkforceHonorarios.jsx'],
  ['Turnos', 'WorkforceTurnosAsistencia.jsx'],
  ['Licencias', 'WorkforceLicenciasMedicas.jsx'],
  ['Vacaciones', 'WorkforceVacacionesPermisos.jsx'],
  ['Finiquito', 'WorkforceEgresoFiniquito.jsx'],
  ['Credenciales', 'WorkforceCredenciales.jsx'],
  ['Casos', 'WorkforceCasosLaborales.jsx'],
];

fs.mkdirSync('bundles', { recursive: true });

for (const [nombre, archivo] of archivos) {
  // 1. chequeo de sintaxis puro
  try {
    await esbuild.build({
      entryPoints: [`${DIR}/${archivo}`],
      bundle: false, write: false, format: 'esm', jsx: 'automatic',
      loader: { '.jsx': 'jsx' },
    });
  } catch (e) {
    console.error(`❌ SYNTAX ERROR en ${archivo}:`, e.message);
    process.exit(1);
  }
  // 2. bundle real para poder importar las funciones puras
  await esbuild.build({
    entryPoints: [`${DIR}/${archivo}`],
    bundle: true, write: true, format: 'esm', jsx: 'transform',
    jsxFactory: 'React.createElement', jsxFragment: 'React.Fragment',
    outfile: `bundles/${nombre}.mjs`,
    external: ['react', 'lucide-react'],
    loader: { '.jsx': 'jsx' }, platform: 'node',
  });
  console.log(`✅ ${nombre} — sintaxis OK, bundle listo`);
}
