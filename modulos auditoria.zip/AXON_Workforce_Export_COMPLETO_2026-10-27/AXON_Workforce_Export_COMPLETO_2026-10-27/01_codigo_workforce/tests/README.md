# Pruebas de Workforce — cómo correrlas

Un solo comando reconstruye el entorno y corre todo:

    bash run_all.sh [dir ...]        # por defecto /mnt/project

Hace: instala esbuild, genera stubs ESM de `react` y `lucide-react` (los íconos se leen de los
imports reales de los `.jsx`), bundlea cada `Workforce*.jsx` a `bundles/*.mjs` con `build_all.mjs`
y corre todos los `test_*.mjs`, mostrando checks ok / fallas por suite.

- Acepta layout plano (todo en una carpeta) o con subcarpeta `tests/`. Con varios dirs, los últimos
  pisan a los primeros: `bash run_all.sh /mnt/project /mnt/user-data/outputs/workforce` prueba los
  cambios nuevos sobre lo ya subido.
- Además de la pasada normal (UTC), corre toda la batería bajo `America/Santiago` (cambio de horario) y `Pacific/Auckland` (UTC+). Las dos destaparon bugs reales de fechas el 2026-10-03; si agregas lógica con fechas, mira esas dos líneas `TZ=...` del final.
- `build_all.mjs`: lista de archivos a bundlear. Agregar ahí cada sección nueva.
- `test_roster.mjs`: verifica que el registro canónico de personas (copiado, no importado, en cada
  `.jsx`) se comporta igual en todos. Compara comportamiento, no bytes: el MD5 del bloque fallaba
  apenas un archivo lo compactaba (Finiquito).
- Un `test_<sección>.mjs` por sección; importan de `./bundles/<Nombre>.mjs`.
- El conteo de checks lo da la salida de `run_all.sh`. Las cifras de 136 (README anterior) y 149
  (dossier) venían de contar con `grep "check("`, que incluye la línea `function check(` de cada archivo.
