import { calcularLicencia, construirAusenciaParaRemuneraciones, calcularKPIsLicencias, calcularUrgenciaEmpleador, calcularAlertas, calcularUrgenciaApelacion, calcularAlertasApelacion, construirIntakeDesdeNotificacionElectronica } from './bundles/Licencias.mjs';

let fallas = 0;
function check(n, c, d) { if (!c) { fallas++; console.log(`❌ ${n} — ${d || ''}`); } else console.log(`✅ ${n}`); }
function diaSemana(iso) { return new Date(iso + 'T00:00:00').toLocaleDateString('es-CL', { weekday: 'long' }); }
function esFinde(iso) { const d = new Date(iso + 'T00:00:00').getDay(); return d === 0 || d === 6; }
const FERIADOS_2026 = new Set(['2026-01-01','2026-04-03','2026-04-04','2026-05-01','2026-05-21','2026-06-07','2026-06-29','2026-07-16','2026-08-15','2026-08-20','2026-09-18','2026-09-19','2026-10-12','2026-10-31','2026-11-01','2026-12-08','2026-12-25']);
function worker(o) { return { id: 'w1', ...o }; }

const inicio1 = '2026-06-15';
const l1raw = { id: 'l1', tipoId: 'enfermedad_comun', fechaInicioReposo: inicio1, diasReposo: 5, fechaRecepcionEmpleador: null, fechaEnvioCompin: null, sector: 'privado', estadoResolucion: 'pendiente' };
const l1 = calcularLicencia(worker(), l1raw);
check('plazo trabajador cae en día hábil', !esFinde(l1.plazoTrabajador) && !FERIADOS_2026.has(l1.plazoTrabajador));
check('plazo trabajador posterior al inicio', l1.plazoTrabajador > l1.fechaInicioReposo);
check('licencia 5 días SÍ aplica carencia', l1.aplicaCarencia === true);
check('carencia = 3 días', l1.diasCarencia === 3);
check('días pagados SIL = 5-3 = 2', l1.diasPagadosSIL === 2);
check('sin fecha recepción, trabajadorEnPlazo = null', l1.trabajadorEnPlazo === null);
check('plazo trabajador exacto: lunes 15-jun + 2 días hábiles = miércoles 17-jun', l1.plazoTrabajador === '2026-06-17', `fue ${l1.plazoTrabajador}`);
check('plazo empleador exacto: recepción 17-jun + 3 días hábiles = lunes 22-jun', calcularLicencia(worker(), { ...l1raw, id: 'lpz', fechaRecepcionEmpleador: '2026-06-17' }).plazoEmpleador === '2026-06-22');

const l2 = calcularLicencia(worker(), { ...l1raw, id: 'l2', diasReposo: 15 });
check('licencia >10 días NO aplica carencia', l2.aplicaCarencia === false);
check('sin carencia, días pagados = total', l2.diasPagadosSIL === 15);

const l3 = calcularLicencia(worker(), { ...l1raw, id: 'l3', fechaRecepcionEmpleador: l1.plazoTrabajador });
check('entregar en la fecha límite = EN PLAZO', l3.trabajadorEnPlazo === true);

const fechaTarde = new Date(l1.plazoTrabajador + 'T00:00:00'); fechaTarde.setDate(fechaTarde.getDate() + 5);
const l4 = calcularLicencia(worker(), { ...l1raw, id: 'l4', fechaRecepcionEmpleador: fechaTarde.toISOString().slice(0, 10) });
check('entregar tarde = FUERA de plazo', l4.trabajadorEnPlazo === false);

const l5base = calcularLicencia(worker(), { ...l1raw, id: 'l5', fechaRecepcionEmpleador: inicio1 });
const fechaEnvioTarde = new Date(l5base.plazoEmpleador + 'T00:00:00'); fechaEnvioTarde.setDate(fechaEnvioTarde.getDate() + 5);
const l5 = calcularLicencia(worker(), { ...l1raw, id: 'l5', fechaRecepcionEmpleador: inicio1, fechaEnvioCompin: fechaEnvioTarde.toISOString().slice(0, 10) });
check('empleadorEnPlazo = false cuando envía tarde', l5.empleadorEnPlazo === false);
check('empleadorAsumeSubsidio = true', l5.empleadorAsumeSubsidio === true);

const l6 = calcularLicencia(worker(), { ...l1raw, id: 'l6', tipoId: 'accidente_trabajo' });
check('accidente del trabajo usa circuito mutual', l6.circuito === 'mutual');

const ausencia = construirAusenciaParaRemuneraciones(l2);
check('diasAusencia = diasReposo', ausencia.diasAusencia === 15);
check('diasNoRemuneradosPorEmpleador = diasReposo', ausencia.diasNoRemuneradosPorEmpleador === 15);

const kpis = calcularKPIsLicencias([l1, l2, l3, l4, l5, l6]);
check('licencias = 6', kpis.licencias === 6);
check('porCircuitoMutual = 1', kpis.porCircuitoMutual === 1);
check('empleadorAsumeSubsidio = 1', kpis.empleadorAsumeSubsidio === 1);

// Motor de alertas — empleador→COMPIN
const HOY_TEST = '2026-06-24';
const sinRecepcion = calcularLicencia(worker(), { ...l1raw, fechaRecepcionEmpleador: null });
check('sin recepción, alerta NO aplica', calcularUrgenciaEmpleador(sinRecepcion, HOY_TEST).aplica === false);
const yaEnviado = calcularLicencia(worker(), { ...l1raw, fechaRecepcionEmpleador: HOY_TEST, fechaEnvioCompin: HOY_TEST });
check('ya enviado, alerta NO aplica', calcularUrgenciaEmpleador(yaEnviado, HOY_TEST).aplica === false);
const recienLlegada = calcularLicencia(worker(), { ...l1raw, fechaRecepcionEmpleador: HOY_TEST, fechaEnvioCompin: null });
const uHoy = calcularUrgenciaEmpleador(recienLlegada, HOY_TEST);
check('recibida hoy: aplica y nivel ok', uHoy.aplica === true && uHoy.nivel === 'ok');
const fechaVieja = new Date(HOY_TEST + 'T00:00:00'); fechaVieja.setDate(fechaVieja.getDate() - 10);
const vencida = calcularLicencia(worker(), { ...l1raw, fechaRecepcionEmpleador: fechaVieja.toISOString().slice(0, 10), fechaEnvioCompin: null });
const uVencida = calcularUrgenciaEmpleador(vencida, HOY_TEST);
check('10 días sin enviar: nivel vencido, días negativos', uVencida.nivel === 'vencido' && uVencida.diasHabilesRestantes < 0);
const listaAlertas = calcularAlertas([sinRecepcion, yaEnviado, recienLlegada, vencida], HOY_TEST);
check('calcularAlertas filtra (2 de 4 aplican)', listaAlertas.length === 2);
check('calcularAlertas ordena más urgente primero', listaAlertas[0].urgencia.diasHabilesRestantes <= listaAlertas[1].urgencia.diasHabilesRestantes);

const intake = construirIntakeDesdeNotificacionElectronica({ tipoLicencia: 'enfermedad_comun', fechaInicioReposo: '2026-06-20', diasReposo: 5, fechaNotificacion: '2026-06-20', sector: 'privado' });
check('intake: fechaRecepcionEmpleador = fecha notificación', intake.fechaRecepcionEmpleador === '2026-06-20');
check('intake: fechaEnvioCompin arranca null', intake.fechaEnvioCompin === null);
check('licencia desde intake es procesable', typeof calcularLicencia(worker(), { id: 'li', ...intake }).plazoEmpleador === 'string');

// Carencia SOLO para enfermedad común (DFL 44 art. 14) — corrección 2026-10-03
const lAcc = calcularLicencia(worker(), { ...l1raw, id: 'lacc', tipoId: 'accidente_trabajo', diasReposo: 5 });
check('accidente del trabajo 5 días: SIN carencia', lAcc.aplicaCarencia === false && lAcc.diasCarencia === 0);
check('accidente del trabajo 5 días: se pagan los 5', lAcc.diasPagadosSIL === 5);
const lProf = calcularLicencia(worker(), { ...l1raw, id: 'lprof', tipoId: 'enfermedad_profesional', diasReposo: 3 });
check('enfermedad profesional 3 días: SIN carencia', lProf.diasCarencia === 0 && lProf.diasPagadosSIL === 3);
const lTray = calcularLicencia(worker(), { ...l1raw, id: 'ltray', tipoId: 'accidente_trayecto', diasReposo: 8 });
check('accidente de trayecto 8 días: SIN carencia', lTray.aplicaCarencia === false);
check('enfermedad común 10 días SÍ aplica carencia (límite)', calcularLicencia(worker(), { ...l1raw, id: 'l10', diasReposo: 10 }).diasCarencia === 3);
check('enfermedad común 11 días NO aplica carencia (límite)', calcularLicencia(worker(), { ...l1raw, id: 'l11', diasReposo: 11 }).aplicaCarencia === false);
check('KPI: los accidentes no suman días de carencia', calcularKPIsLicencias([lAcc, lProf, lTray]).totalDiasCarencia === 0);

// Regresión (2026-10-27): el inicio en día inhábil no debe sumar un día de más al plazo del trabajador
const pl = (ini) => calcularLicencia(worker(), { ...l1raw, id: 'reg', fechaInicioReposo: ini }).plazoTrabajador;
check('inicio en sábado y en domingo dan el MISMO plazo (martes)', pl('2026-06-13') === '2026-06-16' && pl('2026-06-14') === '2026-06-16', `sáb=${pl('2026-06-13')} dom=${pl('2026-06-14')}`);
check('inicio en lunes hábil: plazo el miércoles', pl('2026-06-15') === '2026-06-17');
check('inicio en lunes feriado (12-oct): plazo el miércoles 14, no el jueves', pl('2026-10-12') === '2026-10-14', pl('2026-10-12'));
check('inicio en viernes: plazo el martes (salta el fin de semana)', pl('2026-06-19') === '2026-06-23');

// Motor de alertas — apelación
const aprobadaSinApelar = calcularLicencia(worker(), { ...l1raw, estadoResolucion: 'aprobada', fechaResolucion: HOY_TEST });
check('aprobada: alerta apelación NO aplica', calcularUrgenciaApelacion(aprobadaSinApelar, HOY_TEST).aplica === false);
const rechazadaSinFecha = calcularLicencia(worker(), { ...l1raw, estadoResolucion: 'rechazada', fechaResolucion: null });
check('rechazada sin fecha: no aplica', calcularUrgenciaApelacion(rechazadaSinFecha, HOY_TEST).aplica === false);
const rechazadaPendiente = calcularLicencia(worker(), { ...l1raw, estadoResolucion: 'rechazada', fechaResolucion: HOY_TEST, fechaApelacion: null });
const uApelacion = calcularUrgenciaApelacion(rechazadaPendiente, HOY_TEST);
check('rechazada recién notificada: aplica, nivel ok', uApelacion.aplica === true && uApelacion.nivel === 'ok');
const rechazadaYaApelada = calcularLicencia(worker(), { ...l1raw, estadoResolucion: 'rechazada', fechaResolucion: HOY_TEST, fechaApelacion: HOY_TEST });
check('ya apelada: deja de aplicar', calcularUrgenciaApelacion(rechazadaYaApelada, HOY_TEST).aplica === false);
const fechaRechazoVieja = new Date(HOY_TEST + 'T00:00:00'); fechaRechazoVieja.setDate(fechaRechazoVieja.getDate() - 25);
const rechazadaVencida = calcularLicencia(worker(), { ...l1raw, estadoResolucion: 'rechazada', fechaResolucion: fechaRechazoVieja.toISOString().slice(0, 10), fechaApelacion: null });
check('rechazada hace 25 días sin apelar: vencido', calcularUrgenciaApelacion(rechazadaVencida, HOY_TEST).nivel === 'vencido');
const listaApelaciones = calcularAlertasApelacion([aprobadaSinApelar, rechazadaSinFecha, rechazadaPendiente, rechazadaYaApelada, rechazadaVencida], HOY_TEST);
check('calcularAlertasApelacion filtra (2 de 5 aplican)', listaApelaciones.length === 2);
check('calcularAlertasApelacion ordena más urgente primero', listaApelaciones[0].urgencia.diasHabilesRestantes <= listaApelaciones[1].urgencia.diasHabilesRestantes);

console.log(`\n${fallas === 0 ? '✅ TODO OK' : `❌ ${fallas} FALLA(S)`} — Licencias Médicas`);
process.exit(fallas === 0 ? 0 : 1);
