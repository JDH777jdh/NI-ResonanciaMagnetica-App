import { calcularAsistenciaPeriodo, construirInputHorasParaRemuneraciones, calcularKPIsAsistencia } from './bundles/Turnos.mjs';

let fallas = 0;
function check(n, c, d) { if (!c) { fallas++; console.log(`❌ ${n} — ${d || ''}`); } else console.log(`✅ ${n}`); }
function worker(o) { return { id: 'w1', turnoId: 'diurno_administrativo', cargoId: 'administrativo', ...o }; }

// 2026-09 tiene 30 días. diasTrabajaEsperados = round(30*5/7) = 21 días × 8.4h = 176.4h
const w1 = worker({ turnoId: 'diurno_administrativo' });
const registros1 = Array.from({ length: 21 }, () => ({ horasTrabajadas: 8.4, atrasoMin: 0, esDescansoProgramado: false }));
const a1 = calcularAsistenciaPeriodo(w1, '2026-09', registros1);
check('horas programadas = 21×8.4 = 176.4h (sin ruido de punto flotante)', a1.horasProgramadas === 176.4);
check('horas asistidas = horas programadas', a1.horasAsistidas === a1.horasProgramadas, `fue ${a1.horasAsistidas}`);
check('sin horas extra cuando asiste exacto', a1.horasExtra === 0);
check('sin déficit cuando asiste exacto', a1.horasDeficit === 0);
check('diurno_administrativo NO requiere sistema excepcional', a1.requiereSistemaExcepcional === false);

const w2 = worker({ turnoId: 'turno_12x36_diurno' });
const registros2 = Array.from({ length: 15 }, (_, i) => ({ horasTrabajadas: i % 3 === 0 ? 14 : 12, atrasoMin: 0, esDescansoProgramado: false }));
const a2 = calcularAsistenciaPeriodo(w2, '2026-09', registros2);
check('horas programadas 12x36 = 15×12 = 180h', a2.horasProgramadas === 180);
check('horas extra > 0 cuando asiste más', a2.horasExtra > 0);
check('12x36 SÍ requiere sistema excepcional (Art. 38)', a2.requiereSistemaExcepcional === true);

const w3 = worker({ turnoId: 'diurno_administrativo' });
const registros3 = [...Array.from({ length: 18 }, () => ({ horasTrabajadas: 8.4, atrasoMin: 0, esDescansoProgramado: false })), ...Array.from({ length: 3 }, () => ({ horasTrabajadas: 0, atrasoMin: 0, esDescansoProgramado: false }))];
const a3 = calcularAsistenciaPeriodo(w3, '2026-09', registros3);
check('3 ausencias detectadas', a3.ausencias === 3);
check('déficit > 0 con ausencias', a3.horasDeficit > 0);
check('extra = 0 cuando hay déficit', a3.horasExtra === 0);

const w4 = worker({ turnoId: 'turno_noche_fijo' });
const a4 = calcularAsistenciaPeriodo(w4, '2026-09', Array.from({ length: 21 }, () => ({ horasTrabajadas: 9, atrasoMin: 0, esDescansoProgramado: false })));
check('recargo nocturno NO se aplica por defecto (política institucional, no ley)', a4.recargoNocturnoAplicable === false);
check('noche_fijo NO requiere sistema excepcional', a4.requiereSistemaExcepcional === false);

const inputRemu = construirInputHorasParaRemuneraciones(a2);
check('shape = { horasExtraTrabajadas }', Object.keys(inputRemu).length === 1 && 'horasExtraTrabajadas' in inputRemu);
check('horasExtraTrabajadas = asistencia.horasExtra', inputRemu.horasExtraTrabajadas === a2.horasExtra);

const kpis = calcularKPIsAsistencia([a1, a2, a3, a4]);
check('trabajadores = 4', kpis.trabajadores === 4);
check('conSistemaExcepcional = 1', kpis.conSistemaExcepcional === 1);
check('cumplimiento entre 0 y 100', kpis.cumplimiento >= 0 && kpis.cumplimiento <= 100);

console.log(`\n${fallas === 0 ? '✅ TODO OK' : `❌ ${fallas} FALLA(S)`} — Turnos y Asistencia`);
process.exit(fallas === 0 ? 0 : 1);
