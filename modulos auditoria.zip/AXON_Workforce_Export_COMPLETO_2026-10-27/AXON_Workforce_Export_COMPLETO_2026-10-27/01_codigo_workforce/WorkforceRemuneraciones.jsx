import React, { useState, useMemo } from 'react';
import {
  Wallet, Search, Download, X, Landmark, ShieldCheck, Users,
  Calculator, Eye, RotateCcw, CheckCircle2, Clock, Ban, Info,
  Building2, UserRound, Briefcase, TrendingUp, Percent, Send, Hourglass,
} from 'lucide-react';

/* =========================================================================
   AXON WORKFORCE — Remuneraciones
   Módulo de Recursos Humanos / Workforce · Sección: Remuneraciones (Empleados)
   Ver Documento Maestro de Arquitectura Workforce §30 (Remuneraciones),
   §27 (Horas extra), §56/§58 (Eventos financieros / relación con Account Core).

   PRIMERA SECCIÓN DE WORKFORCE — elegida por acoplar directo con Account
   Core: ContabilidadEgresos.jsx ya tiene construida y verificada la puerta
   `recibirLiquidacionRRHH({...}, idBase)` esperando exactamente esto
   (Dossier Técnico Contabilidad, Parte 2.2 y Parte 12, pendiente #2).

   Cubre solo EMPLEADOS (relación laboral dependiente). Honorarios queda
   fuera a propósito — el docx (§31) es explícito: "No debe mezclarse con
   la nómina laboral." Va en un archivo propio, WorkforceHonorarios.jsx
   (siguiente paso natural después de este).

   CUT: formato PROVISIONAL, adoptado 1:1 de AtencionAgendaImagenologia.jsx
   (makeCUT, ya usado ahí para USUARIOS_DEMO y médicos origen:"axon") para
   no inventar uno nuevo — pendiente que definas el formato oficial.
   ========================================================================= */

/* DISEÑO — identidad de color propia para Workforce (violeta), distinta de
   Contabilidad (verde) e Imagenología (azul marino/navy). Provisional,
   mismo criterio "Opción D" del Sistema de Diseño de Temas: color oficial
   final cuando corresponda. Copiado aquí solo para previsualización
   independiente — reemplazar por el sistema de diseño real al integrar. */
const C = {
  bg: '#F6F5FB', card: '#FFFFFF', border: '#E3DEF5', borderD: '#CBC0E8',
  ink: '#241A3D', sub: '#5F5580', mut: '#948AB5',
  pri: '#6D28D9', priD: '#5518B0', priL: '#F1EAFC',
  info: '#2563EB', infoL: '#EEF3FF',
  warn: '#B45309', warnL: '#FEF3E2',
  err: '#C62828', errL: '#FDECEC',
  gold: '#B7791F', goldL: '#FBF0DD',
  teal: '#0E7490', tealL: '#E3F6FA',
  r: 10, rSm: 7, rLg: 14,
  shadow: '0 1px 3px rgba(16,24,40,.06), 0 1px 2px rgba(16,24,40,.04)',
  font: "'Inter', -apple-system, 'Segoe UI', Roboto, sans-serif",
};

/* ---------------------------- catálogos base ------------------------------ */
// Para la LIQUIDACIÓN MENSUAL (este archivo) los 3 tipos corren casi
// idénticos — AFP, Salud, Impuesto Único y Horas Extra no distinguen tipo
// de contrato. La única diferencia real acá es AFC (ver
// AFC_TASA_TRABAJADOR/EMPLEADOR más abajo). Donde SÍ difieren fuerte es en
// el TÉRMINO del contrato (Egreso y Finiquito, sección futura, no
// construida todavía): Por Obra o Faena tiene una indemnización ESPECIAL
// propia (Art. 163 bis CT, Ley 21.122, vigente desde 2019) — 2,5 días de
// remuneración por mes trabajado, que ni Indefinido ni Plazo Fijo tienen
// de esa forma al término normal. Verificado por búsqueda 2026-09-09,
// pendiente de modelar cuando se construya esa sección.
const TIPOS_CONTRATO = {
  indefinido: { label: 'Indefinido', color: '#2E7D32' },
  plazo_fijo: { label: 'Plazo Fijo', color: '#B45309' },
  por_obra: { label: 'Por Obra o Faena', color: '#0E7490' },
};

// Comisiones aproximadas — verificar tabla vigente en spensiones.cl antes de
// producción (cada AFP puede ajustarla). AFP Uno es obligatoria para nuevos
// afiliados desde el 1-oct-2025 por tener la comisión más baja del sistema.
const AFPS = [
  { id: 'capital', nombre: 'Capital', comision: 0.0144 },
  { id: 'cuprum', nombre: 'Cuprum', comision: 0.0144 },
  { id: 'habitat', nombre: 'Habitat', comision: 0.0127 },
  { id: 'modelo', nombre: 'Modelo', comision: 0.0058 },
  { id: 'planvital', nombre: 'PlanVital', comision: 0.0116 },
  { id: 'provida', nombre: 'ProVida', comision: 0.0145 },
  { id: 'uno', nombre: 'Uno', comision: 0.0046 },
];

// Catálogo ILUSTRATIVO de cargos — el catálogo real de 169 roles vive en
// roles.config.js de MAIN, todavía no cruzado con Workforce (mismo hallazgo
// que ya tenía Contabilidad para Honorarios Médicos — Dossier Técnico,
// pendiente #3). No tratar estos nombres como si fueran el catálogo oficial.
const CARGOS = {
  medico: { label: 'Médico/a', icon: Briefcase, color: '#4338CA', rango: [2500000, 4600000] },
  enfermeria: { label: 'Enfermera/o', icon: ShieldCheck, color: '#0E7490', rango: [1250000, 1850000] },
  tens: { label: 'TENS', icon: Users, color: '#2E7D32', rango: [620000, 850000] },
  kinesiologo: { label: 'Kinesiólogo/a', icon: Briefcase, color: '#B45309', rango: [1050000, 1600000] },
  matrona: { label: 'Matrona/Matrón', icon: ShieldCheck, color: '#BE185D', rango: [1350000, 1900000] },
  administrativo: { label: 'Administrativo/a', icon: Building2, color: '#5B6B85', rango: [650000, 1100000] },
  auxiliar: { label: 'Auxiliar de Servicio', icon: UserRound, color: '#94A3B8', rango: [560000, 640000] },
};

/* ═══════════════════════════════════════════════════════════════════════
   PARÁMETROS LEGALES VIGENTES — verificados por búsqueda el 2026-09-09.
   Mismo principio que ya usa Contabilidad (Dossier Técnico, Parte 11):
   cada valor es un dato versionado con fecha de vigencia y fuente, nunca
   una constante permanente. Varios de estos parámetros están en medio de
   reformas activas — se anota explícito dónde.
   ═══════════════════════════════════════════════════════════════════════ */
const UF_REFERENCIAL = 40885.63;    // Banco Central de Chile, 09-sep-2026
const UTM_REFERENCIAL = 71721;      // Circular N°32 SII (10-ago-2026), valor sept-2026 — cambia mensual, verificar

const AFP_TASA_OBLIGATORIA = 0.10;  // DL 3.500, estable
const AFP_SALUD_TOPE_UF = 89.9;     // Res. Ex. N°237 Superintendencia de Pensiones, vigente desde 01-feb-2026 (subió de 87.8 UF)
const SALUD_TASA_MINIMA = 0.07;     // Fonasa obligatorio / piso legal Isapre — mismo tope que AFP

const AFC_TOPE_UF = 135.2;          // Ley 19.728, AFC Chile
const AFC_TASA_TRABAJADOR = { indefinido: 0.006, plazo_fijo: 0, por_obra: 0 };
const AFC_TASA_EMPLEADOR = { indefinido: 0.024, plazo_fijo: 0.03, por_obra: 0.03 };
// DT.gob.cl + AFC.cl, ambos verificados 2026-09: indefinido 0,6% trabajador + 2,4%
// empleador (1,6% CIC + 0,8% FCS). Plazo fijo/por obra: 0% trabajador + 3% empleador
// (2,8% CIC + 0,2% FCS). No aplica a Honorarios — "los trabajadores a honorarios no
// tienen este beneficio" (AFC Chile), por eso no está en AFC_TASA_TRABAJADOR.

const IMM_ACTUAL = 553553;          // Ley N°21.830 (22-jun-2026), vigente desde 01-may-2026 — 2° ajuste del año (antes $539.000 desde 01-ene-2026, Ley 21.751)
const GRATIFICACION_PCT = 0.25;     // Art. 50 Código del Trabajo
const GRATIFICACION_TOPE_IMM_ANUAL = 4.75; // tope es ANUAL (IMM al 31-dic); acá se prorratea mensual (÷12) como referencia de flujo de caja, no como el cálculo anual real de cierre

// Ley 21.561 ("Ley de 40 horas"): jornada semanal máxima en reducción
// gradual — 45h hasta abr-2024, 44h abr2024-abr2026, 42h desde el
// 26-abr-2026 (VIGENTE HOY), 40h desde abr-2028. Horas mensuales =
// semanales × 30/7, conversión habitual para valor-hora en liquidaciones.
const JORNADA_SEMANAL_MAXIMA = 42;
const HORAS_ORDINARIAS_MES = Math.round((JORNADA_SEMANAL_MAXIMA * 30) / 7); // 180
// CORREGIDO — antes esto se aplicaba como 50% FIJO a todos los trabajadores.
// Art. 32 Código del Trabajo fija 50% como PISO LEGAL, no como valor único:
// "las partes también pueden acordar que se paguen las horas extra a un
// valor mayor" (ya lo había encontrado en la búsqueda original, pero no lo
// apliqué al motor — encontrado al preguntar directo si dejamos algo fijo).
// En la práctica real: algunos trabajadores/convenios calculan automático
// al piso legal, otros pactan más alto (frecuente en convenios colectivos
// de salud). Por eso el recargo real vive en `worker.recargoHoraExtraPactado`
// (ver genTrabajadores) — esta constante es solo el PISO que nunca se puede
// pactar por debajo.
const RECARGO_HORA_EXTRA_MINIMO = 0.50; // Art. 32 Código del Trabajo — piso legal, no valor fijo

// Tabla Impuesto Único de Segunda Categoría — 8 tramos en UTM (Art. 43 N°1
// LIR). La estructura en UTM es estable en el tiempo; solo cambia su
// equivalente en pesos según la UTM del mes (Circular SII mensual).
// Rebaja en UTM verificada contra un ejemplo real encontrado en la
// búsqueda: renta $3.000.000 (UTM jul-2026 $71.506) → tramo 8%, rebaja
// $124.420,44 ≈ 1,74 UTM — calza exacto con el tramo 3 de esta tabla.
const TRAMOS_IMPUESTO_UNICO = [
  { hastaUTM: 13.5, tasa: 0, rebajaUTM: 0 },
  { hastaUTM: 30, tasa: 0.04, rebajaUTM: 0.54 },
  { hastaUTM: 50, tasa: 0.08, rebajaUTM: 1.74 },
  { hastaUTM: 70, tasa: 0.135, rebajaUTM: 4.49 },
  { hastaUTM: 90, tasa: 0.23, rebajaUTM: 11.14 },
  { hastaUTM: 120, tasa: 0.304, rebajaUTM: 17.80 },
  { hastaUTM: 150, tasa: 0.355, rebajaUTM: 24.11 },
  { hastaUTM: Infinity, tasa: 0.40, rebajaUTM: 30.86 },
];

// Reforma Previsional (Ley 21.735) — aporte NUEVO de cargo empleador,
// implementación gradual por 9 años, NO es descuento del trabajador (no
// afecta el líquido a pago). Se muestra aparte como "costo empresa".
// Ago2025-jul2026: 1% (0,1% cuenta individual + 0,9% FAPP).
// Ago2026-jul2027 (VIGENTE HOY): 3,5% (0,1% cuenta individual + resto FAPP,
// incluye financiamiento del SIS).
const REFORMA_PREVISIONAL_EMPLEADOR_PCT = 0.035;

/* ---------------------------- identificadores ----------------------------- */
// CUT — Registro de Trabajador (§11.2 Documento Maestro). Formato
// PROVISIONAL, adoptado 1:1 del que ya usa AtencionAgendaImagenologia.jsx
// (USUARIOS_DEMO y médicos referentes origen:"axon") para no inventar uno
// nuevo antes de que confirmes el formato oficial. Cuando lo hagas, este
// es el único bloque a reemplazar.
const PAIS = 'CL', REGION = '13', CLINICA = 'AXON';
function hashLiviano(str) {
  let h = 0;
  for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) >>> 0;
  return h.toString(16).toUpperCase().padStart(2, '0').slice(-2);
}
function makeCUT(seq) {
  const s = String(seq).padStart(8, '0');
  return `CUT-${PAIS}-${REGION}-${CLINICA}-${s}-${hashLiviano(`CUT-${PAIS}-${REGION}-${CLINICA}-${s}`)}`;
}

// Ver ContabilidadHelpersCompartidos.js — misma versión canónica de
// calcDV/fakeRUT (base 9000000/mult 7919) que ya usan Ingresos y Agenda de
// Imagenología, para no sumar un tercer criterio distinto de RUT falso.
function calcDV(rutBody) {
  let suma = 0, mult = 2;
  for (let i = rutBody.length - 1; i >= 0; i--) {
    suma += parseInt(rutBody[i], 10) * mult;
    mult = mult === 7 ? 2 : mult + 1;
  }
  const resto = 11 - (suma % 11);
  if (resto === 11) return '0';
  if (resto === 10) return 'K';
  return String(resto);
}
function fakeRUT(seed) {
  const body = String(9000000 + (seed * 7919) % 8900000);
  const dv = calcDV(body);
  return body.slice(0, 2) + '.' + body.slice(2, 5) + '.' + body.slice(5) + '-' + dv;
}

const clp = (n) => '$' + Math.round(n).toLocaleString('es-CL');

/* ═══════════════════════════════════════════════════════════════════════
   MOTOR DE CÁLCULO — Remuneraciones
   Implementa §27 (horas extra) y §30 (remuneraciones) del Documento
   Maestro. Workforce CALCULA la realidad laboral — nunca declara
   impuestos ni contabiliza: eso es Account Core (§28, §58).
   ═══════════════════════════════════════════════════════════════════════ */

// §27 — Horas extra: recargo 50% sobre el valor de la hora ordinaria
// (Art. 32 CT). El motor completo de §27 también considera jurisdicción +
// contrato + política institucional + convenio + turno real — acá se
// implementa el cálculo base; el resto llega con el Motor de Reglas
// Jurisdiccionales (§19 del Documento Maestro), todavía no construido.
// §27 — Horas extra: recargo sobre el valor de la hora ordinaria (Art. 32
// CT). `recargoPactado` viene del trabajador (worker.recargoHoraExtraPactado)
// — nunca puede aplicarse bajo el piso legal, de ahí el Math.max. El motor
// completo de §27 también considera jurisdicción + política institucional +
// turno real — acá se implementa el cálculo base; el resto llega con el
// Motor de Reglas Jurisdiccionales (§19 del Documento Maestro), todavía no
// construido.
function calcularHorasExtra(sueldoBase, horasExtraTrabajadas, recargoPactado) {
  const recargoAplicado = Math.max(recargoPactado ?? RECARGO_HORA_EXTRA_MINIMO, RECARGO_HORA_EXTRA_MINIMO);
  const valorHoraOrdinaria = sueldoBase / HORAS_ORDINARIAS_MES;
  const valorHoraExtra = Math.round(valorHoraOrdinaria * (1 + recargoAplicado));
  const montoHorasExtra = Math.round(valorHoraExtra * horasExtraTrabajadas);
  return { valorHoraOrdinaria: Math.round(valorHoraOrdinaria), valorHoraExtra, montoHorasExtra, recargoAplicado };
}

// Art. 50 CT — 25% de lo devengado, tope 4,75 IMM. El tope legal es ANUAL
// (IMM vigente al 31-dic); acá se prorratea mensual (÷12) como referencia
// de gestión, no como sustituto del cálculo anual real de fin de ejercicio.
function calcularGratificacionLegal(totalHaberesImponiblesMes) {
  const calculada = Math.round(totalHaberesImponiblesMes * GRATIFICACION_PCT);
  const topeMensualReferencial = Math.round((IMM_ACTUAL * GRATIFICACION_TOPE_IMM_ANUAL) / 12);
  return Math.min(calculada, topeMensualReferencial);
}

function aplicarTope(monto, topeUF) {
  return Math.min(monto, Math.round(topeUF * UF_REFERENCIAL));
}

function calcularDescuentosPrevisionales(totalImponible, worker) {
  const afp = AFPS.find((a) => a.id === worker.afpId) || AFPS[0];
  const baseAfpSalud = aplicarTope(totalImponible, AFP_SALUD_TOPE_UF);
  const baseAfc = aplicarTope(totalImponible, AFC_TOPE_UF);

  const montoAFP = Math.round(baseAfpSalud * (AFP_TASA_OBLIGATORIA + afp.comision));
  const pctSalud = worker.sistemaSalud === 'isapre' && worker.planIsaprePct ? worker.planIsaprePct : SALUD_TASA_MINIMA;
  const montoSalud = Math.round(baseAfpSalud * pctSalud);
  const montoCesantia = Math.round(baseAfc * AFC_TASA_TRABAJADOR[worker.tipoContrato]);

  return { montoAFP, afpNombre: afp.nombre, afpComision: afp.comision, montoSalud, pctSalud, montoCesantia };
}

function calcularImpuestoUnico(baseTributariaMensual) {
  if (baseTributariaMensual <= 0) return { impuesto: 0, tasaMarginal: 0 };
  const baseUTM = baseTributariaMensual / UTM_REFERENCIAL;
  const tramo = TRAMOS_IMPUESTO_UNICO.find((t) => baseUTM <= t.hastaUTM);
  const impuesto = Math.max(0, Math.round(baseTributariaMensual * tramo.tasa - tramo.rebajaUTM * UTM_REFERENCIAL));
  return { impuesto, tasaMarginal: tramo.tasa };
}

/* PUERTA ETIQUETADA — calcularLiquidacion
   Función pura y exportable: recibe el trabajador + los datos del período
   y devuelve la liquidación completa. Mismo contrato que ya usa
   Contabilidad (calcularKPIsIngresos, etc.): solo números, nada de JSX. */
export function calcularLiquidacion(worker, periodo, input) {
  const { horasExtraTrabajadas = 0, bonos = 0, asignacionesNoImponibles = 0 } = input;
  const { montoHorasExtra, valorHoraExtra, recargoAplicado } = calcularHorasExtra(worker.sueldoBase, horasExtraTrabajadas, worker.recargoHoraExtraPactado);

  const totalHaberesImponibles = worker.sueldoBase + montoHorasExtra + bonos;
  const gratificacion = calcularGratificacionLegal(totalHaberesImponibles);
  const totalImponible = totalHaberesImponibles + gratificacion;

  const { montoAFP, afpNombre, afpComision, montoSalud, pctSalud, montoCesantia } = calcularDescuentosPrevisionales(totalImponible, worker);
  const baseTributaria = totalImponible - montoAFP - montoSalud - montoCesantia;
  const { impuesto, tasaMarginal } = calcularImpuestoUnico(baseTributaria);

  const totalHaberes = totalImponible + asignacionesNoImponibles;
  const totalDescuentos = montoAFP + montoSalud + montoCesantia + impuesto;
  const liquidoAPago = totalHaberes - totalDescuentos;

  const costoEmpresaAdicional = Math.round(totalImponible * (AFC_TASA_EMPLEADOR[worker.tipoContrato] + REFORMA_PREVISIONAL_EMPLEADOR_PCT));

  return {
    workerId: worker.id, periodo,
    haberes: {
      sueldoBase: worker.sueldoBase, valorHoraExtra, horasExtraTrabajadas, recargoAplicado,
      horasExtra: montoHorasExtra, bonos, gratificacion, asignacionesNoImponibles,
      totalImponible, totalHaberes,
    },
    descuentos: { afp: montoAFP, afpNombre, afpComision, salud: montoSalud, pctSalud, cesantia: montoCesantia, impuestoUnico: impuesto, tasaMarginal, totalDescuentos },
    liquidoAPago, baseTributaria, costoEmpresaAdicional,
  };
}

/* ═══════════════════════════════════════════════════════════════════════
   PUERTA ETIQUETADA — hacia Account Core / Contabilidad
   §56/§58 del Documento Maestro: Workforce calcula, emite un evento;
   Account Core registra el impacto financiero. Nunca al revés.

   HONESTIDAD: no tengo el código fuente real de ContabilidadEgresos.jsx en
   este chat, solo la descripción de su contrato en el Dossier Técnico
   ("Recibe sueldo bruto + desglose de descuentos AFP/Fonasa-Isapre/
   Cesantía/Mutualidad"). Los nombres de campo de abajo son mi mejor
   reconstrucción de esa descripción — falta calzarlos contra el archivo
   real antes de integrar. Mutualidad (Ley 16.744) queda en null: es 100%
   de cargo del empleador, no aparece como descuento en la liquidación del
   trabajador, así que no la invento acá.
   ═══════════════════════════════════════════════════════════════════════ */
export function construirPayrollCalculatedEvent(liquidacion) {
  return {
    tipo: 'PayrollCalculated',
    dominioOrigen: 'workforce',
    workerId: liquidacion.workerId,
    periodo: liquidacion.periodo,
    haberes: liquidacion.haberes,
    descuentos: liquidacion.descuentos,
    liquidoAPago: liquidacion.liquidoAPago,
    costoEmpresaAdicional: liquidacion.costoEmpresaAdicional,
    emitidoEn: new Date().toISOString(),
  };
}

export function construirPayloadLiquidacionRRHH(liquidacion) {
  return {
    sueldoBruto: liquidacion.haberes.totalHaberes,
    descuentos: {
      afp: liquidacion.descuentos.afp,
      fonasaIsapre: liquidacion.descuentos.salud,
      cesantia: liquidacion.descuentos.cesantia,
      mutualidad: null, // 100% empleador — ver nota arriba
    },
    // idBase se pasa como segundo argumento al llamar recibirLiquidacionRRHH(payload, idBase) real
  };
}

/* PUERTA ETIQUETADA — calcularKPIsRemuneraciones
   Mismo contrato que calcularKPIsIngresos de Contabilidad: números puros,
   listo para que Alta Dirección lo consuma cuando exista. */
export function calcularKPIsRemuneraciones(liquidaciones) {
  const sum = (fn) => liquidaciones.reduce((s, l) => s + fn(l), 0);
  const totalNomina = sum((l) => l.haberes.totalHaberes);
  const totalLiquido = sum((l) => l.liquidoAPago);
  const totalDescuentos = sum((l) => l.descuentos.totalDescuentos);
  const totalAFP = sum((l) => l.descuentos.afp);
  const totalSalud = sum((l) => l.descuentos.salud);
  const totalCesantia = sum((l) => l.descuentos.cesantia);
  const totalImpuesto = sum((l) => l.descuentos.impuestoUnico);
  const totalHorasExtraMonto = sum((l) => l.haberes.horasExtra);
  const totalCostoEmpresaAdicional = sum((l) => l.costoEmpresaAdicional);
  const promedioLiquido = liquidaciones.length ? Math.round(totalLiquido / liquidaciones.length) : 0;
  const conImpuesto = liquidaciones.filter((l) => l.descuentos.impuestoUnico > 0).length;
  return {
    seccion: 'remuneraciones', trabajadores: liquidaciones.length,
    totalNomina, totalLiquido, totalDescuentos, promedioLiquido,
    totalAFP, totalSalud, totalCesantia, totalImpuesto, totalHorasExtraMonto,
    totalCostoEmpresaAdicional, conImpuesto,
  };
}

/* ------------------------------ mock data -------------------------------- */
/* ═══════════════════════════════════════════════════════════════════════
   REGISTRO CANÓNICO — copiado 1:1 desde WorkforcePersonas.jsx (fuente de
   verdad). Antes este archivo generaba su propio roster, distinto del de
   Honorarios/Turnos/Licencias — "wk_1000" no era la misma persona en
   ningún otro archivo. Ahora los 5 archivos comparten exactamente estas
   30 personas. Cambiar esto acá y no en los otros 4 es el problema que
   esto vino a resolver — mismo principio que ContabilidadHelpersCompartidos.js:
   se copia, no se importa, cada archivo sigue standalone-previsualizable.
   ═══════════════════════════════════════════════════════════════════════ */
const NOMBRES_CANONICO = ['María José', 'Pedro', 'Camila', 'Rodrigo', 'Fernanda', 'Ignacio', 'Valentina', 'Cristóbal', 'Antonia', 'Matías', 'Javiera', 'Sebastián', 'Catalina', 'Diego', 'Francisca', 'Tomás', 'Constanza', 'Felipe', 'Josefa', 'Nicolás'];
const APELLIDOS_CANONICO = ['González', 'Muñoz', 'Rojas', 'Díaz', 'Pérez', 'Soto', 'Contreras', 'Silva', 'Martínez', 'Sepúlveda', 'Morales', 'Rodríguez', 'López', 'Fuentes', 'Hernández', 'Torres'];
const CARGOS_LISTA_CANONICO = ['medico', 'enfermeria', 'tens', 'kinesiologo', 'matrona', 'administrativo', 'auxiliar'];
const ESPECIALIDADES_LISTA_CANONICO = ['medico_especialista', 'psicologia', 'kinesiologia', 'nutricion', 'auditoria_clinica'];
const EMPRESAS_HONORARIO_CANONICO = ['Auditoría Clínica del Sur SpA', 'Diagnóstico Externo Ltda.'];

// Antigüedad — mismo generador que WorkforcePersonas.jsx, copiado 1:1.
function fechaIngresoDesdeSeed(seed) {
  const diasAtras = 60 + (seed % 5000);
  const hoy = new Date();
  const fecha = new Date(hoy);
  fecha.setDate(fecha.getDate() - diasAtras);
  return fecha.toISOString().slice(0, 10);
}

function generarPersonasCanonico() {
  const personas = [];
  let seed = 100;
  // 20 personas — relación EMPLEADO. Últimas 3 son de un tenant AXON Core
  // (Workforce como tecnología, empleador real es el tenant, no AXON).
  for (let i = 0; i < 20; i++) {
    seed += 17;
    const esCore = i >= 17;
    personas.push({
      id: `per_${1000 + i}`, cut: makeCUT(1000 + i), rut: fakeRUT(seed),
      nombres: NOMBRES_CANONICO[seed % NOMBRES_CANONICO.length],
      apellidoPaterno: APELLIDOS_CANONICO[(seed * 2) % APELLIDOS_CANONICO.length],
      apellidoMaterno: APELLIDOS_CANONICO[(seed * 5) % APELLIDOS_CANONICO.length],
      tipoRelacion: 'empleado',
      axonLinea: esCore ? 'axon_core' : 'axon_health',
      tenantId: esCore ? 'tenant_hospital_regional_demo' : null,
      // sector (privado/publico) — ver WorkforcePersonas.jsx para la nota
      // completa. Ley 19.664/Estatuto Administrativo NO está implementada
      // todavía, este es solo el campo (puerta etiquetada).
      sector: esCore ? 'publico' : 'privado',
      cargoId: CARGOS_LISTA_CANONICO[seed % CARGOS_LISTA_CANONICO.length],
      fechaIngreso: fechaIngresoDesdeSeed(seed),
    });
  }
  // 10 personas — relación HONORARIO. Últimas 2 son empresa (doble vía ya
  // establecida por Contabilidad), el resto persona natural. Todos
  // AXON Core Lite — independientes, sin institución de por medio.
  for (let i = 0; i < 10; i++) {
    seed += 23;
    const esEmpresa = i >= 8;
    personas.push({
      id: `per_${2000 + i}`, cut: makeCUT(2000 + i), rut: fakeRUT(seed),
      nombres: esEmpresa ? null : NOMBRES_CANONICO[seed % NOMBRES_CANONICO.length],
      apellidoPaterno: esEmpresa ? null : APELLIDOS_CANONICO[(seed * 2) % APELLIDOS_CANONICO.length],
      apellidoMaterno: esEmpresa ? null : APELLIDOS_CANONICO[(seed * 5) % APELLIDOS_CANONICO.length],
      razonSocial: esEmpresa ? EMPRESAS_HONORARIO_CANONICO[i - 8] : null,
      tipoRelacion: 'honorario',
      tipoPersonaHonorario: esEmpresa ? 'empresa' : 'natural',
      axonLinea: 'axon_core_lite', tenantId: null,
      especialidadId: esEmpresa ? 'auditoria_clinica' : ESPECIALIDADES_LISTA_CANONICO[seed % (ESPECIALIDADES_LISTA_CANONICO.length - 1)],
    });
  }
  return personas;
}

// Remuneraciones solo usa los EMPLEADOS del registro canónico (los
// honorarios viven en WorkforceHonorarios.jsx) — y les agrega ENCIMA los
// campos propios de esta sección (sueldoBase, contrato, AFP, etc.), que
// el registro canónico no conoce ni debe conocer.
function genTrabajadores() {
  const contratos = ['indefinido', 'indefinido', 'indefinido', 'plazo_fijo', 'por_obra'];
  return generarPersonasCanonico()
    .filter((p) => p.tipoRelacion === 'empleado')
    .map((p) => {
      const seed = Number(p.id.split('_')[1]); // seed determinístico derivado del id canónico, no un nuevo azar
      const [min, max] = CARGOS[p.cargoId].rango;
      const sueldoBase = Math.round((min + ((seed * 29) % (max - min))) / 10000) * 10000;
      const tipoContrato = contratos[seed % contratos.length];
      const sistemaSalud = seed % 3 === 0 ? 'isapre' : 'fonasa';
      return {
        ...p, sueldoBase, tipoContrato,
        afpId: AFPS[seed % AFPS.length].id,
        sistemaSalud,
        planIsaprePct: sistemaSalud === 'isapre' ? SALUD_TASA_MINIMA + (seed % 4) * 0.005 : null,
        // Recargo de horas extra PACTADO — Art. 32 CT es un piso (50%), no un
        // valor único (corrección aplicada en esta misma sesión). La mayoría
        // queda en el piso legal; cargos con más probabilidad de convenio
        // colectivo (médico, enfermería) a veces pactan más alto.
        recargoHoraExtraPactado: (p.cargoId === 'medico' || p.cargoId === 'enfermeria') && seed % 3 === 0
          ? 0.75
          : seed % 4 === 0 ? 0.60 : RECARGO_HORA_EXTRA_MINIMO,
      };
    });
}
const nombreCompleto = (w) => w.razonSocial || `${w.nombres} ${w.apellidoPaterno} ${w.apellidoMaterno}`;


function mesesHastaHoy(cantidad) {
  const hoy = new Date();
  const out = [];
  for (let i = cantidad - 1; i >= 0; i--) {
    const d = new Date(hoy.getFullYear(), hoy.getMonth() - i, 1);
    out.push(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`);
  }
  return out;
}
const PERIODOS = mesesHastaHoy(4);

function genLiquidaciones(trabajadores) {
  const rows = [];
  let seed = 5;
  trabajadores.forEach((w) => {
    PERIODOS.forEach((periodo) => {
      seed += 11;
      const horasExtraTrabajadas = seed % 4 === 0 ? 0 : 2 + (seed % 9); // referencia — el motor real de §27 topa esto contra el máx. legal de 2h/día vía el Motor de Reglas Jurisdiccionales
      const bonos = seed % 5 === 0 ? Math.round((w.sueldoBase * 0.05) / 1000) * 1000 : 0;
      const asignacionesNoImponibles = 45000; // colación + movilización, monto de referencia ilustrativo
      const liquidacion = calcularLiquidacion(w, periodo, { horasExtraTrabajadas, bonos, asignacionesNoImponibles });
      const esUltimoPeriodo = periodo === PERIODOS[PERIODOS.length - 1];
      rows.push({ ...liquidacion, id: `liq_${w.id}_${periodo}`, worker: w, estado: esUltimoPeriodo ? 'calculada' : 'pagada' });
    });
  });
  return rows.sort((a, b) => (a.periodo < b.periodo ? 1 : -1));
}

/* ------------------------------- átomos ---------------------------------- */
const Badge = ({ color, bg, icon: Icon, children }) => (
  <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, padding: '3px 9px', borderRadius: 999, fontSize: 12, fontWeight: 600, color, background: bg, whiteSpace: 'nowrap' }}>
    {Icon && <Icon size={12} />}{children}
  </span>
);

const Btn = ({ variant = 'ghost', icon: Icon, children, onClick, style, type = 'button' }) => {
  const base = { display: 'inline-flex', alignItems: 'center', gap: 7, padding: '9px 15px', borderRadius: C.rSm, fontSize: 13.5, fontWeight: 600, cursor: 'pointer', border: '1px solid transparent', fontFamily: C.font, transition: 'filter .12s ease' };
  const variants = {
    primary: { background: C.pri, color: '#fff' },
    outline: { background: '#fff', color: C.ink, border: `1px solid ${C.border}` },
    ghost: { background: 'transparent', color: C.sub },
  };
  return (
    <button type={type} onClick={onClick}
      onMouseEnter={(e) => (e.currentTarget.style.filter = 'brightness(0.96)')}
      onMouseLeave={(e) => (e.currentTarget.style.filter = 'none')}
      style={{ ...base, ...variants[variant], ...style }}>
      {Icon && <Icon size={15} />}{children}
    </button>
  );
};

const KPICard = ({ label, value, sub, icon: Icon, accent }) => (
  <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, padding: '16px 18px', boxShadow: C.shadow, flex: 1, minWidth: 0 }}>
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
      <span style={{ fontSize: 12.5, color: C.sub, fontWeight: 600 }}>{label}</span>
      <div style={{ width: 28, height: 28, borderRadius: 8, background: accent + '18', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <Icon size={14} style={{ color: accent }} />
      </div>
    </div>
    <div style={{ fontSize: 22, fontWeight: 700, color: C.ink, letterSpacing: -0.3 }}>{value}</div>
    {sub && <div style={{ fontSize: 12, color: C.mut, marginTop: 3 }}>{sub}</div>}
  </div>
);

const FieldLabel = ({ children }) => <label style={{ fontSize: 11.5, fontWeight: 600, color: C.sub, marginBottom: 5, display: 'block' }}>{children}</label>;
const inputStyle = { width: '100%', padding: '8px 10px', borderRadius: C.rSm, border: `1px solid ${C.border}`, fontSize: 13.5, fontFamily: C.font, color: C.ink, outline: 'none', boxSizing: 'border-box', background: '#fff' };

function BreakdownCard({ title, items, total }) {
  return (
    <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, padding: 18, boxShadow: C.shadow, flex: 1, minWidth: 0 }}>
      <div style={{ fontSize: 13, fontWeight: 700, color: C.ink, marginBottom: 14 }}>{title}</div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 11 }}>
        {items.map(([key, label, color, monto]) => {
          const pct = total ? Math.round((monto / total) * 100) : 0;
          return (
            <div key={key}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12.5, marginBottom: 4 }}>
                <span style={{ color: C.ink, fontWeight: 500 }}>{label}</span>
                <span style={{ color: C.sub, fontWeight: 600 }}>{clp(monto)} <span style={{ color: C.mut, fontWeight: 400 }}>({pct}%)</span></span>
              </div>
              <div style={{ height: 6, borderRadius: 4, background: C.bg, overflow: 'hidden' }}>
                <div style={{ height: '100%', width: pct + '%', background: color, borderRadius: 4 }} />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ------------------------- detalle de liquidación -------------------------- */
function DetailModal({ liq, onClose }) {
  const [tab, setTab] = useState('liquidacion');
  if (!liq) return null;
  const w = liq.worker;
  const cargo = CARGOS[w.cargoId];
  const tipoContrato = TIPOS_CONTRATO[w.tipoContrato];
  const evento = construirPayrollCalculatedEvent(liq);
  const payloadRRHH = construirPayloadLiquidacionRRHH(liq);

  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(16,24,40,.45)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100, padding: 20 }} onClick={onClose}>
      <div style={{ background: '#fff', borderRadius: C.rLg, width: 560, maxWidth: '100%', maxHeight: '90vh', overflowY: 'auto', boxShadow: '0 20px 50px rgba(16,24,40,.25)' }} onClick={(e) => e.stopPropagation()}>
        <div style={{ padding: '18px 22px', borderBottom: `1px solid ${C.border}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
            <div style={{ width: 34, height: 34, borderRadius: 9, background: cargo.color + '18', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <cargo.icon size={16} style={{ color: cargo.color }} />
            </div>
            <div>
              <div style={{ fontSize: 15, fontWeight: 700, color: C.ink }}>{nombreCompleto(w)}</div>
              <div style={{ fontSize: 12, color: C.mut }}>{cargo.label} · {liq.periodo}</div>
            </div>
          </div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: C.mut, padding: 4 }}><X size={18} /></button>
        </div>

        <div style={{ display: 'flex', borderBottom: `1px solid ${C.border}`, padding: '0 22px' }}>
          {[['liquidacion', 'Liquidación'], ['evento', 'Evento hacia Account Core']].map(([id, label]) => (
            <button key={id} onClick={() => setTab(id)} style={{ padding: '10px 4px', marginRight: 20, fontSize: 13, fontWeight: 600, color: tab === id ? C.pri : C.mut, background: 'none', border: 'none', borderBottom: `2px solid ${tab === id ? C.pri : 'transparent'}`, cursor: 'pointer' }}>
              {label}
            </button>
          ))}
        </div>

        {tab === 'liquidacion' ? (
          <div style={{ padding: 22, display: 'flex', flexDirection: 'column', gap: 16 }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
              <div>
                <FieldLabel>CUT</FieldLabel>
                <div style={{ fontSize: 12, color: C.ink, fontFamily: 'monospace', background: C.bg, padding: '6px 10px', borderRadius: 6 }}>{w.cut}</div>
              </div>
              <div>
                <FieldLabel>Tipo de contrato</FieldLabel>
                <Badge color={tipoContrato.color} bg={tipoContrato.color + '18'}>{tipoContrato.label}</Badge>
              </div>
            </div>

            <div style={{ background: C.bg, borderRadius: C.rSm, padding: 14 }}>
              <div style={{ fontSize: 11.5, fontWeight: 700, color: C.sub, textTransform: 'uppercase', marginBottom: 8 }}>Haberes</div>
              {[
                ['Sueldo base', liq.haberes.sueldoBase],
                [`Horas extra (${liq.haberes.horasExtraTrabajadas}h × ${clp(liq.haberes.valorHoraExtra)}, recargo ${(liq.haberes.recargoAplicado * 100).toFixed(0)}%${liq.haberes.recargoAplicado > RECARGO_HORA_EXTRA_MINIMO ? ' pactado' : ' piso legal'})`, liq.haberes.horasExtra],
                ['Bonos', liq.haberes.bonos],
                ['Gratificación legal (Art. 50 CT)', liq.haberes.gratificacion],
                ['Asignaciones no imponibles', liq.haberes.asignacionesNoImponibles],
              ].map(([label, monto]) => (
                <div key={label} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12.5, color: C.sub, marginBottom: 5 }}>
                  <span>{label}</span><span style={{ color: C.ink, fontWeight: 600 }}>{clp(monto)}</span>
                </div>
              ))}
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13.5, paddingTop: 8, marginTop: 4, borderTop: `1px dashed ${C.borderD}` }}>
                <span style={{ fontWeight: 700, color: C.ink }}>Total haberes</span><span style={{ fontWeight: 700, color: C.ink }}>{clp(liq.haberes.totalHaberes)}</span>
              </div>
            </div>

            <div style={{ background: C.errL, borderRadius: C.rSm, padding: 14 }}>
              <div style={{ fontSize: 11.5, fontWeight: 700, color: C.err, textTransform: 'uppercase', marginBottom: 8 }}>Descuentos</div>
              {[
                [`AFP (${liq.descuentos.afpNombre}, ${((AFP_TASA_OBLIGATORIA + liq.descuentos.afpComision) * 100).toFixed(2)}%)`, liq.descuentos.afp],
                [`Salud (${(liq.descuentos.pctSalud * 100).toFixed(1)}%)`, liq.descuentos.salud],
                ['Seguro Cesantía (AFC)', liq.descuentos.cesantia],
                [`Impuesto Único (tramo ${(liq.descuentos.tasaMarginal * 100).toFixed(1)}%)`, liq.descuentos.impuestoUnico],
              ].map(([label, monto]) => (
                <div key={label} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12.5, color: C.sub, marginBottom: 5 }}>
                  <span>{label}</span><span style={{ color: C.ink, fontWeight: 600 }}>-{clp(monto)}</span>
                </div>
              ))}
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13.5, paddingTop: 8, marginTop: 4, borderTop: `1px dashed ${C.err}40` }}>
                <span style={{ fontWeight: 700, color: C.ink }}>Total descuentos</span><span style={{ fontWeight: 700, color: C.ink }}>-{clp(liq.descuentos.totalDescuentos)}</span>
              </div>
            </div>

            <div style={{ background: C.priL, borderRadius: C.rSm, padding: 14, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontSize: 14, fontWeight: 700, color: C.ink }}>Líquido a pago</span>
              <span style={{ fontSize: 19, fontWeight: 700, color: C.priD }}>{clp(liq.liquidoAPago)}</span>
            </div>

            <div style={{ fontSize: 11, color: C.mut, display: 'flex', gap: 6, alignItems: 'flex-start' }}>
              <Info size={12} style={{ flexShrink: 0, marginTop: 1 }} />
              <span>Costo empresa adicional (no descontado al trabajador): {clp(liq.costoEmpresaAdicional)} — AFC empleador + aporte gradual Ley 21.735. Mutualidad (Ley 16.744) no incluida: 100% empleador, fuera del alcance de esta liquidación.</span>
            </div>
          </div>
        ) : (
          <div style={{ padding: 22, display: 'flex', flexDirection: 'column', gap: 14 }}>
            <div style={{ display: 'flex', gap: 8, alignItems: 'flex-start', background: C.infoL, padding: '10px 12px', borderRadius: C.rSm, fontSize: 12, color: '#1D4ED8' }}>
              <Send size={14} style={{ flexShrink: 0, marginTop: 1 }} />
              <span>Puerta etiquetada — esto es lo que Workforce emitiría hacia Account Core. Todavía no hay bus de eventos real (§2 del addendum de Mapa de Dominios sigue abierto); esta vista es la forma del contrato, no una llamada real.</span>
            </div>
            <div>
              <FieldLabel>Evento de dominio — PayrollCalculated</FieldLabel>
              <pre style={{ fontSize: 11, background: C.ink, color: '#D4CBEF', padding: 14, borderRadius: C.rSm, overflowX: 'auto', margin: 0 }}>{JSON.stringify(evento, null, 2)}</pre>
            </div>
            <div>
              <FieldLabel>Payload compatible con recibirLiquidacionRRHH(...) de ContabilidadEgresos.jsx</FieldLabel>
              <pre style={{ fontSize: 11, background: C.ink, color: '#D4CBEF', padding: 14, borderRadius: C.rSm, overflowX: 'auto', margin: 0 }}>{JSON.stringify(payloadRRHH, null, 2)}</pre>
              <div style={{ fontSize: 10.5, color: C.mut, marginTop: 6 }}>Reconstruido desde la descripción del Dossier Técnico de Contabilidad — verificar nombres de campo contra el archivo real antes de integrar.</div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

/* ------------------------- calculadora interactiva ------------------------- */
function CalculadoraModal({ trabajadores, onClose }) {
  const [workerId, setWorkerId] = useState(trabajadores[0].id);
  const [horasExtraTrabajadas, setHorasExtraTrabajadas] = useState(0);
  const [bonos, setBonos] = useState(0);
  const worker = trabajadores.find((w) => w.id === workerId);
  const preview = useMemo(
    () => calcularLiquidacion(worker, PERIODOS[PERIODOS.length - 1], { horasExtraTrabajadas: Number(horasExtraTrabajadas) || 0, bonos: Number(bonos) || 0, asignacionesNoImponibles: 45000 }),
    [worker, horasExtraTrabajadas, bonos]
  );

  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(16,24,40,.45)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100, padding: 20 }} onClick={onClose}>
      <div style={{ background: '#fff', borderRadius: C.rLg, width: 460, maxWidth: '100%', boxShadow: '0 20px 50px rgba(16,24,40,.25)' }} onClick={(e) => e.stopPropagation()}>
        <div style={{ padding: '18px 22px', borderBottom: `1px solid ${C.border}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ fontSize: 15, fontWeight: 700, color: C.ink }}>Calculadora de liquidación</div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: C.mut }}><X size={18} /></button>
        </div>
        <div style={{ padding: 22, display: 'flex', flexDirection: 'column', gap: 13 }}>
          <div>
            <FieldLabel>Trabajador</FieldLabel>
            <select style={inputStyle} value={workerId} onChange={(e) => setWorkerId(e.target.value)}>
              {trabajadores.map((w) => <option key={w.id} value={w.id}>{nombreCompleto(w)} — {CARGOS[w.cargoId].label}</option>)}
            </select>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <div>
              <FieldLabel>Horas extra del mes</FieldLabel>
              <input style={inputStyle} type="number" min="0" value={horasExtraTrabajadas} onChange={(e) => setHorasExtraTrabajadas(e.target.value)} />
            </div>
            <div>
              <FieldLabel>Bonos (CLP)</FieldLabel>
              <input style={inputStyle} type="number" min="0" value={bonos} onChange={(e) => setBonos(e.target.value)} />
            </div>
          </div>
          <div style={{ background: C.bg, borderRadius: C.rSm, padding: 14 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12.5, color: C.sub, marginBottom: 5 }}><span>Total haberes</span><span style={{ color: C.ink, fontWeight: 600 }}>{clp(preview.haberes.totalHaberes)}</span></div>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12.5, color: C.sub, marginBottom: 5 }}><span>Total descuentos</span><span style={{ color: C.ink, fontWeight: 600 }}>-{clp(preview.descuentos.totalDescuentos)}</span></div>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 14.5, paddingTop: 8, borderTop: `1px dashed ${C.borderD}`, marginTop: 4 }}>
              <span style={{ fontWeight: 700, color: C.ink }}>Líquido a pago</span><span style={{ fontWeight: 700, color: C.priD }}>{clp(preview.liquidoAPago)}</span>
            </div>
          </div>
          <div style={{ fontSize: 11, color: C.mut, display: 'flex', gap: 6 }}>
            <Info size={12} style={{ flexShrink: 0, marginTop: 1 }} />
            <span>Recalcula en vivo con el mismo motor que genera las liquidaciones de la tabla — base {HORAS_ORDINARIAS_MES}h/mes ({JORNADA_SEMANAL_MAXIMA}h semanales, Ley 21.561 vigente desde 26-abr-2026).</span>
          </div>
        </div>
      </div>
    </div>
  );
}

/* --------------------------------- vista principal ------------------------------------ */
export default function WorkforceRemuneraciones({ addToast }) {
  const toast = addToast || ((msg) => console.log(msg));
  const [trabajadores] = useState(genTrabajadores);
  const [data] = useState(() => genLiquidaciones(trabajadores));
  const [filtros, setFiltros] = useState({ periodo: 'todos', cargo: 'todos', contrato: 'todos', q: '' });
  const [selected, setSelected] = useState(null);
  const [showCalc, setShowCalc] = useState(false);
  const [page, setPage] = useState(1);
  const perPage = 8;

  const filtered = useMemo(() => data.filter((l) => {
    if (filtros.periodo !== 'todos' && l.periodo !== filtros.periodo) return false;
    if (filtros.cargo !== 'todos' && l.worker.cargoId !== filtros.cargo) return false;
    if (filtros.contrato !== 'todos' && l.worker.tipoContrato !== filtros.contrato) return false;
    if (filtros.q) {
      const q = filtros.q.toLowerCase();
      if (!nombreCompleto(l.worker).toLowerCase().includes(q) && !l.worker.rut.includes(q) && !l.worker.cut.toLowerCase().includes(q)) return false;
    }
    return true;
  }), [data, filtros]);

  const kpi = useMemo(() => calcularKPIsRemuneraciones(filtered), [filtered]);
  const totalPages = Math.max(1, Math.ceil(filtered.length / perPage));
  const pageRows = filtered.slice((page - 1) * perPage, page * perPage);

  const descuentosBreakdown = [
    ['afp', 'AFP', C.pri, kpi.totalAFP],
    ['salud', 'Salud', C.teal, kpi.totalSalud],
    ['cesantia', 'Cesantía (AFC)', C.warn, kpi.totalCesantia],
    ['impuesto', 'Impuesto Único', C.err, kpi.totalImpuesto],
  ];
  const porCargo = Object.keys(CARGOS)
    .map((id) => [id, CARGOS[id].label, CARGOS[id].color, filtered.filter((l) => l.worker.cargoId === id).reduce((s, l) => s + l.haberes.totalHaberes, 0)])
    .filter((r) => r[3] > 0)
    .sort((a, b) => b[3] - a[3]);

  const limpiarFiltros = () => { setFiltros({ periodo: 'todos', cargo: 'todos', contrato: 'todos', q: '' }); setPage(1); };

  const exportarCSV = () => {
    const header = ['Período', 'Trabajador', 'CUT', 'RUT', 'Cargo', 'Contrato', 'Total Haberes', 'AFP', 'Salud', 'Cesantía', 'Impuesto Único', 'Líquido a Pago', 'Estado'];
    const lines = filtered.map((l) => [l.periodo, nombreCompleto(l.worker), l.worker.cut, l.worker.rut, CARGOS[l.worker.cargoId].label, TIPOS_CONTRATO[l.worker.tipoContrato].label, l.haberes.totalHaberes, l.descuentos.afp, l.descuentos.salud, l.descuentos.cesantia, l.descuentos.impuestoUnico, l.liquidoAPago, l.estado].join(';'));
    const blob = new Blob([header.join(';') + '\n' + lines.join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `remuneraciones_${PERIODOS[0]}_a_${PERIODOS[PERIODOS.length - 1]}.csv`; a.click();
    URL.revokeObjectURL(url);
    toast('Archivo CSV descargado');
  };

  return (
    <div style={{ fontFamily: C.font, background: C.bg, minHeight: '100%', padding: 22 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 18, flexWrap: 'wrap', gap: 12 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
          <div style={{ width: 34, height: 34, borderRadius: 9, background: C.priL, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Wallet size={17} style={{ color: C.pri }} />
          </div>
          <div>
            <div style={{ fontSize: 18, fontWeight: 700, color: C.ink }}>Remuneraciones</div>
            <div style={{ fontSize: 12.5, color: C.mut }}>Workforce · Motor de liquidaciones para empleados — Documento Maestro §27, §30</div>
          </div>
        </div>
        <div style={{ display: 'flex', gap: 9 }}>
          <Btn variant="outline" icon={Calculator} onClick={() => setShowCalc(true)}>Calculadora</Btn>
          <Btn variant="outline" icon={Download} onClick={exportarCSV}>Exportar CSV</Btn>
        </div>
      </div>

      <div style={{ fontSize: 11.5, fontWeight: 700, color: C.mut, textTransform: 'uppercase', letterSpacing: 0.4, marginBottom: 8 }}>Nómina del período filtrado</div>
      <div style={{ display: 'flex', gap: 14, marginBottom: 18, flexWrap: 'wrap' }}>
        <KPICard label="Trabajadores" value={kpi.trabajadores} sub={`${PERIODOS.length} períodos cargados`} icon={Users} accent={C.pri} />
        <KPICard label="Total haberes" value={clp(kpi.totalNomina)} sub="Bruto, antes de descuentos" icon={TrendingUp} accent={C.info} />
        <KPICard label="Total descuentos" value={clp(kpi.totalDescuentos)} sub="AFP + Salud + Cesantía + Impuesto" icon={Ban} accent={C.err} />
        <KPICard label="Líquido a pago" value={clp(kpi.totalLiquido)} sub={`Promedio ${clp(kpi.promedioLiquido)}/trabajador`} icon={Wallet} accent={C.priD} />
      </div>
      <div style={{ display: 'flex', gap: 14, marginBottom: 18, flexWrap: 'wrap' }}>
        <KPICard label="Horas extra pagadas" value={clp(kpi.totalHorasExtraMonto)} sub="Recargo 50%, Art. 32 CT" icon={Hourglass} accent={C.gold} />
        <KPICard label="Costo empresa adicional" value={clp(kpi.totalCostoEmpresaAdicional)} sub="AFC empleador + Ley 21.735 (no es descuento del trabajador)" icon={Landmark} accent={C.teal} />
        <KPICard label="Con Impuesto Único" value={kpi.conImpuesto} sub={`De ${kpi.trabajadores} liquidaciones — sobre 13,5 UTM`} icon={Percent} accent={C.warn} />
      </div>

      <div style={{ display: 'flex', gap: 14, marginBottom: 14, flexWrap: 'wrap' }}>
        <BreakdownCard title="Descuentos por tipo" items={descuentosBreakdown} total={kpi.totalDescuentos} />
        <BreakdownCard title="Haberes por cargo" items={porCargo} total={kpi.totalNomina} />
      </div>

      <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, padding: 16, boxShadow: C.shadow, marginBottom: 14 }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 10, alignItems: 'end' }}>
          <div>
            <FieldLabel>Período</FieldLabel>
            <select style={inputStyle} value={filtros.periodo} onChange={(e) => { setFiltros({ ...filtros, periodo: e.target.value }); setPage(1); }}>
              <option value="todos">Todos</option>
              {PERIODOS.map((p) => <option key={p} value={p}>{p}</option>)}
            </select>
          </div>
          <div>
            <FieldLabel>Cargo</FieldLabel>
            <select style={inputStyle} value={filtros.cargo} onChange={(e) => { setFiltros({ ...filtros, cargo: e.target.value }); setPage(1); }}>
              <option value="todos">Todos</option>
              {Object.entries(CARGOS).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
            </select>
          </div>
          <div>
            <FieldLabel>Contrato</FieldLabel>
            <select style={inputStyle} value={filtros.contrato} onChange={(e) => { setFiltros({ ...filtros, contrato: e.target.value }); setPage(1); }}>
              <option value="todos">Todos</option>
              {Object.entries(TIPOS_CONTRATO).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
            </select>
          </div>
          <div style={{ gridColumn: 'span 2' }}>
            <FieldLabel>Buscar</FieldLabel>
            <div style={{ position: 'relative' }}>
              <Search size={14} style={{ position: 'absolute', left: 9, top: 10, color: C.mut }} />
              <input style={{ ...inputStyle, paddingLeft: 28 }} placeholder="Nombre, RUT o CUT" value={filtros.q} onChange={(e) => { setFiltros({ ...filtros, q: e.target.value }); setPage(1); }} />
            </div>
          </div>
        </div>
        <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 12 }}>
          <button onClick={limpiarFiltros} style={{ display: 'flex', alignItems: 'center', gap: 5, background: 'none', border: 'none', cursor: 'pointer', color: C.sub, fontSize: 12.5, fontWeight: 600, padding: 0 }}>
            <RotateCcw size={13} /> Limpiar filtros
          </button>
        </div>
      </div>

      <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, boxShadow: C.shadow, overflow: 'hidden' }}>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
            <thead>
              <tr style={{ background: C.bg, textAlign: 'left' }}>
                {['Período', 'Trabajador', 'Cargo', 'Contrato', 'Total Haberes', 'Descuentos', 'Líquido a Pago', 'Estado', ''].map((h) => (
                  <th key={h} style={{ padding: '10px 14px', fontSize: 11.5, fontWeight: 700, color: C.sub, textTransform: 'uppercase', letterSpacing: 0.3, whiteSpace: 'nowrap' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {pageRows.map((l) => {
                const cargo = CARGOS[l.worker.cargoId];
                const contrato = TIPOS_CONTRATO[l.worker.tipoContrato];
                return (
                  <tr key={l.id} style={{ borderTop: `1px solid ${C.border}`, cursor: 'pointer' }} onClick={() => setSelected(l)}
                    onMouseEnter={(e) => (e.currentTarget.style.background = C.bg)} onMouseLeave={(e) => (e.currentTarget.style.background = 'transparent')}>
                    <td style={{ padding: '11px 14px', color: C.sub, whiteSpace: 'nowrap' }}>{l.periodo}</td>
                    <td style={{ padding: '11px 14px' }}>
                      <div style={{ fontWeight: 600, color: C.ink }}>{nombreCompleto(l.worker)}</div>
                      <div style={{ fontSize: 11, color: C.mut, fontFamily: 'monospace' }}>{l.worker.cut}</div>
                    </td>
                    <td style={{ padding: '11px 14px' }}><Badge color={cargo.color} bg={cargo.color + '18'}>{cargo.label}</Badge></td>
                    <td style={{ padding: '11px 14px' }}><Badge color={contrato.color} bg={contrato.color + '18'}>{contrato.label}</Badge></td>
                    <td style={{ padding: '11px 14px', color: C.ink, whiteSpace: 'nowrap' }}>{clp(l.haberes.totalHaberes)}</td>
                    <td style={{ padding: '11px 14px', color: C.err, whiteSpace: 'nowrap' }}>-{clp(l.descuentos.totalDescuentos)}</td>
                    <td style={{ padding: '11px 14px', fontWeight: 700, color: C.ink, whiteSpace: 'nowrap' }}>{clp(l.liquidoAPago)}</td>
                    <td style={{ padding: '11px 14px' }}>
                      <Badge color={l.estado === 'pagada' ? C.pri : C.warn} bg={(l.estado === 'pagada' ? C.pri : C.warn) + '18'} icon={l.estado === 'pagada' ? CheckCircle2 : Clock}>
                        {l.estado === 'pagada' ? 'Pagada' : 'Calculada'}
                      </Badge>
                    </td>
                    <td style={{ padding: '11px 14px' }}><Eye size={15} style={{ color: C.mut }} /></td>
                  </tr>
                );
              })}
              {pageRows.length === 0 && (
                <tr><td colSpan={9} style={{ padding: '40px 14px', textAlign: 'center', color: C.mut, fontSize: 13 }}>
                  No hay liquidaciones que calcen con estos filtros. <button onClick={limpiarFiltros} style={{ color: C.info, background: 'none', border: 'none', cursor: 'pointer', fontSize: 13, textDecoration: 'underline', padding: 0 }}>Limpia los filtros</button>.
                </td></tr>
              )}
            </tbody>
          </table>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 16px', borderTop: `1px solid ${C.border}` }}>
          <span style={{ fontSize: 12, color: C.mut }}>{filtered.length} liquidaciones · página {page} de {totalPages}</span>
          <div style={{ display: 'flex', gap: 6 }}>
            <Btn variant="outline" onClick={() => setPage(Math.max(1, page - 1))} style={{ padding: '6px 12px', opacity: page === 1 ? 0.4 : 1 }}>Anterior</Btn>
            <Btn variant="outline" onClick={() => setPage(Math.min(totalPages, page + 1))} style={{ padding: '6px 12px', opacity: page === totalPages ? 0.4 : 1 }}>Siguiente</Btn>
          </div>
        </div>
      </div>

      {selected && <DetailModal liq={selected} onClose={() => setSelected(null)} />}
      {showCalc && <CalculadoraModal trabajadores={trabajadores} onClose={() => setShowCalc(false)} />}
    </div>
  );
}
