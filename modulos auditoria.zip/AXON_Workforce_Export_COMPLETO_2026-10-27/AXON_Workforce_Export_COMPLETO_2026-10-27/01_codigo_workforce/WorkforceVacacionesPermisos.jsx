import React, { useState, useMemo } from 'react';
import {
  Palmtree, Search, Download, X, Users, CheckCircle2, XCircle, Clock,
  AlertTriangle, Info, Eye, RotateCcw, ShieldCheck, Briefcase, UserRound,
  Building2, Heart, Baby, Ribbon, TrendingUp,
} from 'lucide-react';

/* =========================================================================
   AXON WORKFORCE — Vacaciones y Permisos
   Módulo de Recursos Humanos / Workforce · Sección: Vacaciones y Permisos
   Ver Documento Maestro de Arquitectura Workforce §36 (Vacaciones y
   Permisos: solicitud, aprobación, saldo, historial, reglas configurables
   por jurisdicción y tenant).

   SEXTA SECCIÓN. Reutiliza el motor de días hábiles/feriados ya construido
   y verificado en WorkforceLicenciasMedicas.jsx (mismo FERIADOS_CHILE_2026,
   misma esDiaHabil/sumarDiasHabiles) — Feriado Legal cuenta días hábiles
   con el sábado SIEMPRE inhábil (Art. 69 CT), que resulta ser exactamente
   el mismo criterio Lunes-Viernes que ya usaba Licencias, así que no hace
   falta un motor de fechas distinto.

   Usa `fechaIngreso` del registro canónico (agregado en esta misma sesión,
   propagado a los 5 archivos) para calcular antigüedad, saldo de feriado y
   feriado progresivo — el primer archivo que necesita ese campo.
   ========================================================================= */

/* DISEÑO — misma identidad violeta de Workforce. */
const C = {
  bg: '#F6F5FB', card: '#FFFFFF', border: '#E3DEF5', borderD: '#CBC0E8',
  ink: '#241A3D', sub: '#5F5580', mut: '#948AB5',
  pri: '#6D28D9', priD: '#5518B0', priL: '#F1EAFC',
  info: '#2563EB', infoL: '#EEF3FF',
  warn: '#B45309', warnL: '#FEF3E2',
  err: '#C62828', errL: '#FDECEC',
  gold: '#B7791F', goldL: '#FBF0DD',
  teal: '#0E7490', tealL: '#E3F6FA',
  r: 10, rSm: 7, rLg: 14,
  shadow: '0 1px 3px rgba(16,24,40,.06), 0 1px 2px rgba(16,24,40,.04)',
  font: "'Inter', -apple-system, 'Segoe UI', Roboto, sans-serif",
};

/* ---------------------------- catálogos base ------------------------------ */
const CARGOS = {
  medico: { label: 'Médico/a', icon: Briefcase, color: '#4338CA' },
  enfermeria: { label: 'Enfermera/o', icon: ShieldCheck, color: '#0E7490' },
  tens: { label: 'TENS', icon: Users, color: '#2E7D32' },
  kinesiologo: { label: 'Kinesiólogo/a', icon: Briefcase, color: '#B45309' },
  matrona: { label: 'Matrona/Matrón', icon: ShieldCheck, color: '#BE185D' },
  administrativo: { label: 'Administrativo/a', icon: Building2, color: '#5B6B85' },
  auxiliar: { label: 'Auxiliar de Servicio', icon: UserRound, color: '#94A3B8' },
};

// Permisos especiales — eventos puntuales, NO saldo acumulable (distinto
// del Feriado Legal). tipoConteo decide si los días son corridos
// (incluyen fin de semana) o hábiles (Lun-Vie, feriados excluidos).
const TIPOS_PERMISO_ESPECIAL = {
  matrimonio_auc: { label: 'Matrimonio / AUC', dias: 5, tipoConteo: 'habiles', color: '#BE185D', icon: Heart, fuente: 'Art. 207 bis CT' },
  nacimiento_hijo: { label: 'Nacimiento de Hijo/a (Padre)', dias: 5, tipoConteo: 'corridos', color: '#2563EB', icon: Baby, fuente: 'Art. 195 CT' },
  duelo_hijo: { label: 'Duelo — Hijo/a', dias: 10, tipoConteo: 'corridos', color: '#5B6B85', icon: Ribbon, fuente: 'Art. 66 CT — ⚠️ ver nota de incertidumbre' },
  duelo_conyuge: { label: 'Duelo — Cónyuge/Conviviente Civil', dias: 7, tipoConteo: 'corridos', color: '#5B6B85', icon: Ribbon, fuente: 'Art. 66 CT' },
  duelo_hijo_gestacion: { label: 'Duelo — Hijo/a en Gestación', dias: 7, tipoConteo: 'habiles', color: '#5B6B85', icon: Ribbon, fuente: 'Art. 66 CT' },
  duelo_hermano_padre_madre: { label: 'Duelo — Hermano/a, Padre o Madre', dias: 4, tipoConteo: 'habiles', color: '#5B6B85', icon: Ribbon, fuente: 'Art. 66 CT (ampliado de 3 a 4, Ley 21.441 de 2022)' },
};

/* ═══════════════════════════════════════════════════════════════════════
   PARÁMETROS LEGALES — verificados por búsqueda el 2026-09-11. Fuentes
   oficiales concordantes (DT en consulta directa, SUSESO) para Feriado
   Legal. Para Permisos Especiales (Art. 66), hay UNA discrepancia real
   entre fuentes que no pude resolver con certeza total — documentada
   explícita más abajo, no escondida.
   ═══════════════════════════════════════════════════════════════════════ */
const FERIADO_DIAS_BASE_ANUAL = 15; // Art. 67 CT — días hábiles por año completo de servicio
const FERIADO_PROPORCIONAL_FACTOR = 1.25; // días hábiles por mes trabajado, si aún no cumple 1 año (o al finiquito) — Art. 73
const FERIADO_PROGRESIVO_UMBRAL_ANIOS = 10; // Art. 68 CT
const FERIADO_PROGRESIVO_CADA_ANIOS = 3; // +1 día por cada 3 años adicionales sobre el umbral
const FERIADO_ACUMULACION_MAX_PERIODOS = 2; // Art. 70 — tope de períodos acumulables sin tomar

// HALLAZGO — Art. 66 CT (duelo) tiene una discrepancia real entre fuentes
// que la búsqueda no logró resolver con certeza total: SUSESO y
// DerechoPedia citan "muerte de hijo ASÍ COMO muerte de cónyuge" bajo el
// MISMO plazo de 7 días corridos (redacción que parece más antigua);
// fuentes más recientes (leyes-cl.com, leydirecta.cl, ambas fechadas 2026)
// separan muerte de hijo en 10 días corridos, distinto de cónyuge en 7.
// Se usa 10 acá por ser la versión más reciente encontrada, pero queda
// marcado — verificar contra el texto vigente en LeyChile antes de
// producción, mismo criterio de honestidad que el resto del proyecto.

// Feriados Chile 2026 — MISMA lista ya verificada en
// AtencionAgendaImagenologia.jsx y reutilizada en Licencias Médicas.
const FERIADOS_CHILE_2026 = {
  '2026-01-01': 'Año Nuevo', '2026-04-03': 'Viernes Santo', '2026-04-04': 'Sábado Santo',
  '2026-05-01': 'Día Nacional del Trabajo', '2026-05-21': 'Glorias Navales',
  '2026-06-07': 'Asalto y Toma del Morro de Arica (regional)', '2026-06-29': 'San Pedro y San Pablo',
  '2026-07-16': 'Virgen del Carmen', '2026-08-15': 'Asunción de la Virgen',
  '2026-08-20': "Natalicio de O'Higgins (regional)", '2026-09-18': 'Fiestas Patrias',
  '2026-09-19': 'Glorias del Ejército', '2026-10-12': 'Encuentro de Dos Mundos',
  '2026-10-31': 'Iglesias Evangélicas y Protestantes', '2026-11-01': 'Todos los Santos',
  '2026-12-08': 'Inmaculada Concepción', '2026-12-25': 'Navidad',
};

/* ---------------------------- identificadores ----------------------------- */
const PAIS = 'CL', REGION = '13', CLINICA = 'AXON';
function hashLiviano(str) {
  let h = 0;
  for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) >>> 0;
  return h.toString(16).toUpperCase().padStart(2, '0').slice(-2);
}
function makeCUT(seq) {
  const s = String(seq).padStart(8, '0');
  return `CUT-${PAIS}-${REGION}-${CLINICA}-${s}-${hashLiviano(`CUT-${PAIS}-${REGION}-${CLINICA}-${s}`)}`;
}
function calcDV(rutBody) {
  let suma = 0, mult = 2;
  for (let i = rutBody.length - 1; i >= 0; i--) {
    suma += parseInt(rutBody[i], 10) * mult;
    mult = mult === 7 ? 2 : mult + 1;
  }
  const resto = 11 - (suma % 11);
  if (resto === 11) return '0';
  if (resto === 10) return 'K';
  return String(resto);
}
function fakeRUT(seed) {
  const body = String(9000000 + (seed * 7919) % 8900000);
  const dv = calcDV(body);
  return body.slice(0, 2) + '.' + body.slice(2, 5) + '.' + body.slice(5) + '-' + dv;
}

/* ------------------------------ fechas/días hábiles ------------------------------ */
// Aritmética en UTC puro (corregido 2026-10-03): con hora local, `toISOString` corría un día en zonas
// UTC+ y las restas de fechas perdían un día al cruzar un cambio de horario (incluido America/Santiago).
const aUTC = (iso) => { const [y, m, d] = iso.split('-').map(Number); return Date.UTC(y, m - 1, d); };
function sumarDias(fechaISO, n) {
  const dt = new Date(aUTC(fechaISO) + n * 86400000);
  return `${dt.getUTCFullYear()}-${String(dt.getUTCMonth() + 1).padStart(2, '0')}-${String(dt.getUTCDate()).padStart(2, '0')}`;
}
// Sábado SIEMPRE inhábil para feriado (Art. 69 CT) — mismo criterio que
// "día hábil" general (excluye Sáb+Dom+feriados), así que reutilizamos
// la misma función sin necesitar una variante especial para vacaciones.
function esDiaHabil(fechaISO) {
  const dow = new Date(aUTC(fechaISO)).getUTCDay();
  if (dow === 0 || dow === 6) return false;
  if (FERIADOS_CHILE_2026[fechaISO]) return false;
  return true;
}
function sumarDiasHabiles(fechaISO, n) {
  let fecha = fechaISO, contados = 0;
  while (contados < n) {
    fecha = sumarDias(fecha, 1);
    if (esDiaHabil(fecha)) contados++;
  }
  return fecha;
}
const fmtDate = (iso) => new Date(iso + 'T00:00:00').toLocaleDateString('es-CL', { day: '2-digit', month: 'short', year: 'numeric' });
const HOY = (() => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; })(); // fecha LOCAL (toISOString daba la fecha UTC: de noche en Chile ya era mañana)

/* ═══════════════════════════════════════════════════════════════════════
   MOTOR — Feriado Legal (Vacaciones)
   §67-70, §73 CT. Workforce calcula el DERECHO y el SALDO — la resolución
   de la solicitud (aprobar/rechazar) es un flujo de estado simple, no un
   motor de reglas jurisdiccionales completo (§19, no construido aún).
   ═══════════════════════════════════════════════════════════════════════ */
export function calcularAntiguedad(fechaIngreso, fechaReferencia) {
  const ingreso = new Date(fechaIngreso + 'T00:00:00');
  const ref = new Date(fechaReferencia + 'T00:00:00');
  const diffDias = Math.round((aUTC(fechaReferencia) - aUTC(fechaIngreso)) / 86400000); // en UTC: con hora local el cambio de horario le quitaba un día
  // CORREGIDO — antes usaba diffDias/365,25 para sacar años completos, lo
  // que SUBESTIMA a alguien que lleva exactamente N años calendario (730
  // días reales ÷ 365,25 = 1,998 → floor da 1, no 2, porque no siempre hay
  // suficiente fracción de año bisiesto acumulada). Encontrado al probar
  // en Node contra una fecha de exactamente 2 años. Se usa aritmética de
  // calendario real: diferencia de año, ajustada si el mes/día aniversario
  // todavía no ha ocurrido este año — sin depender de ningún promedio.
  let aniosCompletos = ref.getFullYear() - ingreso.getFullYear();
  const aunNoCumpleAniversarioEsteAnio = (ref.getMonth() < ingreso.getMonth()) || (ref.getMonth() === ingreso.getMonth() && ref.getDate() < ingreso.getDate());
  if (aunNoCumpleAniversarioEsteAnio) aniosCompletos--;
  const mesesCompletos = Math.floor(diffDias / 30.44);
  return { diffDias, aniosCompletos, mesesCompletos };
}

// Derecho ANUAL vigente hoy (incluye progresivo si corresponde). No es el
// saldo acumulado — es la tasa a la que se está generando feriado AHORA.
export function calcularDerechoFeriadoAnual(aniosCompletos) {
  const progresivo = aniosCompletos > FERIADO_PROGRESIVO_UMBRAL_ANIOS
    ? Math.floor((aniosCompletos - FERIADO_PROGRESIVO_UMBRAL_ANIOS) / FERIADO_PROGRESIVO_CADA_ANIOS)
    : 0;
  return { diasPorAnio: FERIADO_DIAS_BASE_ANUAL + progresivo, diasProgresivoExtra: progresivo };
}

/* PUERTA ETIQUETADA — calcularSaldoFeriado
   SIMPLIFICACIÓN DOCUMENTADA: el saldo acumulado usa la tasa ANUAL VIGENTE
   HOY multiplicada por los años completos, no una integral año-por-año de
   cómo fue subiendo la tasa progresiva en el tiempo — para alguien con
   feriado progresivo, esto sobreestima levemente los años previos al
   progresivo. Aceptable para un mock/vista de saldo; un motor de cierre
   real necesitaría el historial completo de tasas por período. */
export function calcularSaldoFeriado(worker, diasTomadosHistorico, fechaReferencia = HOY) {
  const { aniosCompletos, mesesCompletos } = calcularAntiguedad(worker.fechaIngreso, fechaReferencia);

  if (aniosCompletos < 1) {
    const diasDerecho = Math.round(mesesCompletos * FERIADO_PROPORCIONAL_FACTOR * 10) / 10;
    const diasDisponibles = Math.max(0, Math.round((diasDerecho - diasTomadosHistorico) * 10) / 10);
    return { tipo: 'proporcional', aniosCompletos, diasPorAnio: null, diasProgresivoExtra: 0, diasDerechoAcumulado: diasDerecho, diasTomadosHistorico, diasDisponibles, periodosAcumulados: 0, excedeAcumulacion: false };
  }

  const { diasPorAnio, diasProgresivoExtra } = calcularDerechoFeriadoAnual(aniosCompletos);
  const diasDerechoAcumulado = diasPorAnio * aniosCompletos;
  const diasDisponibles = Math.max(0, diasDerechoAcumulado - diasTomadosHistorico);
  const periodosAcumulados = Math.floor(diasDisponibles / diasPorAnio);
  const excedeAcumulacion = periodosAcumulados > FERIADO_ACUMULACION_MAX_PERIODOS;

  return { tipo: 'legal', aniosCompletos, diasPorAnio, diasProgresivoExtra, diasDerechoAcumulado, diasTomadosHistorico, diasDisponibles, periodosAcumulados, excedeAcumulacion };
}

/* MOTOR — Permisos Especiales (eventos puntuales, Art. 66/195/207 bis CT).
   Sin saldo — cada evento genera su propio derecho fijo de días. */
export function calcularPermisoEspecial(tipoId, fechaInicio) {
  const tipo = TIPOS_PERMISO_ESPECIAL[tipoId];
  const fechaTermino = tipo.tipoConteo === 'habiles'
    ? sumarDiasHabiles(fechaInicio, tipo.dias - 1)
    : sumarDias(fechaInicio, tipo.dias - 1);
  return { tipoId, fechaInicio, fechaTermino, dias: tipo.dias, tipoConteo: tipo.tipoConteo };
}

/* PUERTA ETIQUETADA — hacia Remuneraciones
   Misma FORMA que construirAusenciaParaRemuneraciones de Licencias
   Médicas a propósito — corregido tras auditar consistencia entre
   archivos (antes esta función devolvía `pagaEmpleador: true`, un
   booleano, mientras Licencias devuelve `diasNoRemuneradosPorEmpleador`,
   un número — dos formas distintas para el mismo concepto habrían
   obligado a Remuneraciones a manejar dos lógicas cuando conecte ambas).
   El feriado SÍ lo paga íntegro el empleador, por eso queda en 0 — a
   diferencia de licencia médica, donde son los diasReposo completos. */
export function construirAusenciaParaRemuneraciones(solicitud) {
  return {
    workerId: solicitud.workerId,
    diasAusencia: solicitud.dias,
    diasNoRemuneradosPorEmpleador: 0,
    motivo: solicitud.tipoId,
  };
}

export function calcularKPIsVacacionesPermisos(solicitudes) {
  const feriadoLegal = solicitudes.filter((s) => s.tipoId === 'feriado_legal');
  const permisosEspeciales = solicitudes.filter((s) => s.tipoId !== 'feriado_legal');
  const pendientes = solicitudes.filter((s) => s.estado === 'pendiente').length;
  const aprobadas = solicitudes.filter((s) => s.estado === 'aprobada').length;
  const rechazadas = solicitudes.filter((s) => s.estado === 'rechazada').length;
  const totalDiasFeriadoSolicitados = feriadoLegal.reduce((s, x) => s + x.dias, 0);
  const totalDiasPermisosEspeciales = permisosEspeciales.reduce((s, x) => s + x.dias, 0);
  return {
    seccion: 'vacaciones_permisos', solicitudes: solicitudes.length,
    feriadoLegal: feriadoLegal.length, permisosEspeciales: permisosEspeciales.length,
    pendientes, aprobadas, rechazadas,
    totalDiasFeriadoSolicitados, totalDiasPermisosEspeciales,
  };
}

/* ═══════════════════════════════════════════════════════════════════════
   REGISTRO CANÓNICO — copiado 1:1 desde WorkforcePersonas.jsx, mismo
   principio que los otros 4 archivos. Usa fechaIngreso (agregado en esta
   sesión) para antigüedad — el primer archivo que realmente lo necesita.
   ═══════════════════════════════════════════════════════════════════════ */
const NOMBRES_CANONICO = ['María José', 'Pedro', 'Camila', 'Rodrigo', 'Fernanda', 'Ignacio', 'Valentina', 'Cristóbal', 'Antonia', 'Matías', 'Javiera', 'Sebastián', 'Catalina', 'Diego', 'Francisca', 'Tomás', 'Constanza', 'Felipe', 'Josefa', 'Nicolás'];
const APELLIDOS_CANONICO = ['González', 'Muñoz', 'Rojas', 'Díaz', 'Pérez', 'Soto', 'Contreras', 'Silva', 'Martínez', 'Sepúlveda', 'Morales', 'Rodríguez', 'López', 'Fuentes', 'Hernández', 'Torres'];
const CARGOS_LISTA_CANONICO = ['medico', 'enfermeria', 'tens', 'kinesiologo', 'matrona', 'administrativo', 'auxiliar'];
const ESPECIALIDADES_LISTA_CANONICO = ['medico_especialista', 'psicologia', 'kinesiologia', 'nutricion', 'auditoria_clinica'];
const EMPRESAS_HONORARIO_CANONICO = ['Auditoría Clínica del Sur SpA', 'Diagnóstico Externo Ltda.'];

function fechaIngresoDesdeSeed(seed) {
  const diasAtras = 60 + (seed % 5000);
  const hoy = new Date();
  const fecha = new Date(hoy);
  fecha.setDate(fecha.getDate() - diasAtras);
  return fecha.toISOString().slice(0, 10);
}

function generarPersonasCanonico() {
  const personas = [];
  let seed = 100;
  // 20 personas — relación EMPLEADO. Últimas 3 son de un tenant AXON Core
  // (Workforce como tecnología, empleador real es el tenant, no AXON).
  for (let i = 0; i < 20; i++) {
    seed += 17;
    const esCore = i >= 17;
    personas.push({
      id: `per_${1000 + i}`, cut: makeCUT(1000 + i), rut: fakeRUT(seed),
      nombres: NOMBRES_CANONICO[seed % NOMBRES_CANONICO.length],
      apellidoPaterno: APELLIDOS_CANONICO[(seed * 2) % APELLIDOS_CANONICO.length],
      apellidoMaterno: APELLIDOS_CANONICO[(seed * 5) % APELLIDOS_CANONICO.length],
      tipoRelacion: 'empleado',
      axonLinea: esCore ? 'axon_core' : 'axon_health',
      tenantId: esCore ? 'tenant_hospital_regional_demo' : null,
      // sector (privado/publico) — ver WorkforcePersonas.jsx para la nota
      // completa. Ley 19.664/Estatuto Administrativo NO está implementada
      // todavía, este es solo el campo (puerta etiquetada).
      sector: esCore ? 'publico' : 'privado',
      cargoId: CARGOS_LISTA_CANONICO[seed % CARGOS_LISTA_CANONICO.length],
      fechaIngreso: fechaIngresoDesdeSeed(seed),
    });
  }
  // 10 personas — relación HONORARIO. Últimas 2 son empresa (doble vía ya
  // establecida por Contabilidad), el resto persona natural. Todos
  // AXON Core Lite — independientes, sin institución de por medio.
  for (let i = 0; i < 10; i++) {
    seed += 23;
    const esEmpresa = i >= 8;
    personas.push({
      id: `per_${2000 + i}`, cut: makeCUT(2000 + i), rut: fakeRUT(seed),
      nombres: esEmpresa ? null : NOMBRES_CANONICO[seed % NOMBRES_CANONICO.length],
      apellidoPaterno: esEmpresa ? null : APELLIDOS_CANONICO[(seed * 2) % APELLIDOS_CANONICO.length],
      apellidoMaterno: esEmpresa ? null : APELLIDOS_CANONICO[(seed * 5) % APELLIDOS_CANONICO.length],
      razonSocial: esEmpresa ? EMPRESAS_HONORARIO_CANONICO[i - 8] : null,
      tipoRelacion: 'honorario',
      tipoPersonaHonorario: esEmpresa ? 'empresa' : 'natural',
      axonLinea: 'axon_core_lite', tenantId: null,
      especialidadId: esEmpresa ? 'auditoria_clinica' : ESPECIALIDADES_LISTA_CANONICO[seed % (ESPECIALIDADES_LISTA_CANONICO.length - 1)],
    });
  }
  return personas;
}

// Vacaciones y Permisos solo usa los EMPLEADOS del registro canónico
// (honorarios no tienen feriado legal — son prestadores de servicio, no
// dependientes, ver §75 del Documento Maestro).
function genTrabajadores() {
  return generarPersonasCanonico().filter((p) => p.tipoRelacion === 'empleado');
}
const nombreCompleto = (w) => `${w.nombres} ${w.apellidoPaterno} ${w.apellidoMaterno}`;

/* ------------------------------ mock data -------------------------------- */
const TIPOS_ESPECIALES_LISTA = Object.keys(TIPOS_PERMISO_ESPECIAL);
const ESTADOS_POOL = ['aprobada', 'aprobada', 'aprobada', 'pendiente', 'rechazada'];

// Historial simulado de días de feriado ya tomados — determinístico, no
// afecta el cálculo real (calcularSaldoFeriado), es solo el insumo mock.
function genDiasTomadosHistorico(worker, seed) {
  const { aniosCompletos } = calcularAntiguedad(worker.fechaIngreso, HOY);
  if (aniosCompletos < 1) return 0;
  const { diasPorAnio } = calcularDerechoFeriadoAnual(aniosCompletos);
  // Simula que ya tomó entre 0 y ~1.5 períodos anuales — deja algo de saldo
  // disponible en la mayoría de los casos, y alguno cerca del tope de acumulación.
  return Math.round(diasPorAnio * ((seed % 15) / 10));
}

function genSolicitudes(trabajadores) {
  const rows = [];
  let seed = 31;

  trabajadores.forEach((w) => {
    seed += 19;
    const diasTomadosHistorico = genDiasTomadosHistorico(w, seed);
    const saldo = calcularSaldoFeriado(w, diasTomadosHistorico);

    // Cada trabajador tiene una solicitud de FERIADO LEGAL en curso o
    // reciente, siempre que tenga saldo disponible.
    if (saldo.diasDisponibles > 0) {
      seed += 7;
      const diasSolicitados = Math.min(saldo.diasDisponibles, 5 + (seed % 10));
      const fechaInicio = sumarDias(HOY, -(10 + (seed % 40)));
      const fechaTermino = sumarDiasHabiles(fechaInicio, diasSolicitados - 1);
      rows.push({
        id: `vac_${w.id}`, workerId: w.id, worker: w, tipoId: 'feriado_legal',
        fechaInicio, fechaTermino, dias: diasSolicitados,
        estado: ESTADOS_POOL[seed % ESTADOS_POOL.length],
        saldo,
      });
    } else {
      rows.push({ id: `vac_saldo_${w.id}`, workerId: w.id, worker: w, tipoId: 'feriado_legal', soloSaldo: true, saldo, dias: 0, estado: null });
    }

    // ~1 de cada 4 trabajadores tiene además un permiso especial reciente.
    if (seed % 4 === 0) {
      seed += 11;
      const tipoId = TIPOS_ESPECIALES_LISTA[seed % TIPOS_ESPECIALES_LISTA.length];
      const fechaInicio = sumarDias(HOY, -(3 + (seed % 25)));
      const calculado = calcularPermisoEspecial(tipoId, fechaInicio);
      rows.push({
        id: `perm_${w.id}`, workerId: w.id, worker: w, tipoId,
        fechaInicio: calculado.fechaInicio, fechaTermino: calculado.fechaTermino, dias: calculado.dias,
        estado: ESTADOS_POOL[seed % ESTADOS_POOL.length],
      });
    }
  });

  return rows.sort((a, b) => (a.fechaInicio < b.fechaInicio ? 1 : -1));
}

/* ------------------------------- átomos ---------------------------------- */
const Badge = ({ color, bg, icon: Icon, children }) => (
  <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, padding: '3px 9px', borderRadius: 999, fontSize: 12, fontWeight: 600, color, background: bg, whiteSpace: 'nowrap' }}>
    {Icon && <Icon size={12} />}{children}
  </span>
);
const Btn = ({ variant = 'ghost', icon: Icon, children, onClick, style }) => {
  const base = { display: 'inline-flex', alignItems: 'center', gap: 7, padding: '9px 15px', borderRadius: C.rSm, fontSize: 13.5, fontWeight: 600, cursor: 'pointer', border: '1px solid transparent', fontFamily: C.font, transition: 'filter .12s ease' };
  const variants = {
    primary: { background: C.pri, color: '#fff' },
    outline: { background: '#fff', color: C.ink, border: `1px solid ${C.border}` },
    ghost: { background: 'transparent', color: C.sub },
  };
  return (
    <button type="button" onClick={onClick}
      onMouseEnter={(e) => (e.currentTarget.style.filter = 'brightness(0.96)')}
      onMouseLeave={(e) => (e.currentTarget.style.filter = 'none')}
      style={{ ...base, ...variants[variant], ...style }}>
      {Icon && <Icon size={15} />}{children}
    </button>
  );
};
const KPICard = ({ label, value, sub, icon: Icon, accent }) => (
  <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, padding: '16px 18px', boxShadow: C.shadow, flex: 1, minWidth: 0 }}>
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
      <span style={{ fontSize: 12.5, color: C.sub, fontWeight: 600 }}>{label}</span>
      <div style={{ width: 28, height: 28, borderRadius: 8, background: accent + '18', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <Icon size={14} style={{ color: accent }} />
      </div>
    </div>
    <div style={{ fontSize: 22, fontWeight: 700, color: C.ink, letterSpacing: -0.3 }}>{value}</div>
    {sub && <div style={{ fontSize: 12, color: C.mut, marginTop: 3 }}>{sub}</div>}
  </div>
);
const FieldLabel = ({ children }) => <label style={{ fontSize: 11.5, fontWeight: 600, color: C.sub, marginBottom: 5, display: 'block' }}>{children}</label>;
const inputStyle = { width: '100%', padding: '8px 10px', borderRadius: C.rSm, border: `1px solid ${C.border}`, fontSize: 13.5, fontFamily: C.font, color: C.ink, outline: 'none', boxSizing: 'border-box', background: '#fff' };

const ESTADOS_SOLICITUD = {
  aprobada: { label: 'Aprobada', color: C.pri, icon: CheckCircle2 },
  pendiente: { label: 'Pendiente', color: C.warn, icon: Clock },
  rechazada: { label: 'Rechazada', color: C.err, icon: XCircle },
};

/* ------------------------- detalle de solicitud -------------------------- */
function DetailModal({ sol, onClose }) {
  if (!sol) return null;
  const w = sol.worker;
  const cargo = CARGOS[w.cargoId];
  const esFeriado = sol.tipoId === 'feriado_legal';
  const tipoEspecial = !esFeriado ? TIPOS_PERMISO_ESPECIAL[sol.tipoId] : null;
  const saldo = sol.saldo || (esFeriado ? calcularSaldoFeriado(w, 0) : null);
  const { aniosCompletos } = calcularAntiguedad(w.fechaIngreso, HOY);

  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(16,24,40,.45)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100, padding: 20 }} onClick={onClose}>
      <div style={{ background: '#fff', borderRadius: C.rLg, width: 520, maxWidth: '100%', maxHeight: '90vh', overflowY: 'auto', boxShadow: '0 20px 50px rgba(16,24,40,.25)' }} onClick={(e) => e.stopPropagation()}>
        <div style={{ padding: '18px 22px', borderBottom: `1px solid ${C.border}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
            <div style={{ width: 34, height: 34, borderRadius: 9, background: cargo.color + '18', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <cargo.icon size={16} style={{ color: cargo.color }} />
            </div>
            <div>
              <div style={{ fontSize: 15, fontWeight: 700, color: C.ink }}>{nombreCompleto(w)}</div>
              <div style={{ fontSize: 12, color: C.mut }}>{cargo.label} · {aniosCompletos} año(s) de antigüedad</div>
            </div>
          </div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: C.mut, padding: 4 }}><X size={18} /></button>
        </div>

        <div style={{ padding: 22, display: 'flex', flexDirection: 'column', gap: 16 }}>
          {esFeriado ? (
            <div style={{ background: C.priL, borderRadius: C.rSm, padding: 14 }}>
              <div style={{ fontSize: 11.5, fontWeight: 700, color: C.priD, textTransform: 'uppercase', marginBottom: 8 }}>Saldo de Feriado Legal</div>
              {saldo.tipo === 'proporcional' ? (
                <div style={{ fontSize: 12, color: C.sub, marginBottom: 6 }}>Menos de 1 año de servicio — feriado proporcional (1,25 días hábiles/mes).</div>
              ) : (
                <div style={{ fontSize: 12, color: C.sub, marginBottom: 6 }}>
                  {saldo.diasPorAnio} días hábiles/año{saldo.diasProgresivoExtra > 0 ? ` (incluye +${saldo.diasProgresivoExtra} por feriado progresivo, Art. 68 CT)` : ''}.
                </div>
              )}
              {[['Días con derecho acumulado', saldo.diasDerechoAcumulado], ['Días ya tomados', saldo.diasTomadosHistorico], ['Días disponibles', saldo.diasDisponibles]].map(([label, val]) => (
                <div key={label} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12.5, color: C.sub, marginBottom: 4 }}>
                  <span>{label}</span><span style={{ color: C.ink, fontWeight: 600 }}>{val} días</span>
                </div>
              ))}
              {saldo.excedeAcumulacion && (
                <div style={{ display: 'flex', gap: 6, alignItems: 'flex-start', marginTop: 8, fontSize: 11, color: C.warn }}>
                  <AlertTriangle size={12} style={{ flexShrink: 0, marginTop: 1 }} />
                  <span>Supera el tope de {FERIADO_ACUMULACION_MAX_PERIODOS} períodos acumulados (Art. 70 CT) — el empleador debe otorgar los días pendientes.</span>
                </div>
              )}
            </div>
          ) : (
            <div style={{ background: tipoEspecial.color + '12', borderRadius: C.rSm, padding: 14 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
                <tipoEspecial.icon size={15} style={{ color: tipoEspecial.color }} />
                <span style={{ fontSize: 13, fontWeight: 700, color: C.ink }}>{tipoEspecial.label}</span>
              </div>
              <div style={{ fontSize: 11, color: C.mut }}>{tipoEspecial.fuente} · {tipoEspecial.tipoConteo === 'habiles' ? 'días hábiles' : 'días corridos'}</div>
            </div>
          )}

          {!sol.soloSaldo && (
            <div style={{ background: C.bg, borderRadius: C.rSm, padding: 14 }}>
              {[['Inicio', fmtDate(sol.fechaInicio)], ['Término', fmtDate(sol.fechaTermino)], ['Días', sol.dias]].map(([label, val]) => (
                <div key={label} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12.5, color: C.sub, marginBottom: 5 }}>
                  <span>{label}</span><span style={{ color: C.ink, fontWeight: 600 }}>{val}</span>
                </div>
              ))}
              <div style={{ marginTop: 8 }}><Badge color={ESTADOS_SOLICITUD[sol.estado].color} bg={ESTADOS_SOLICITUD[sol.estado].color + '18'} icon={ESTADOS_SOLICITUD[sol.estado].icon}>{ESTADOS_SOLICITUD[sol.estado].label}</Badge></div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

/* --------------------------------- vista principal ------------------------------------ */
export default function WorkforceVacacionesPermisos({ addToast }) {
  const toast = addToast || ((msg) => console.log(msg));
  const [trabajadores] = useState(genTrabajadores);
  const [data] = useState(() => genSolicitudes(trabajadores));
  const [filtros, setFiltros] = useState({ tipo: 'todos', estado: 'todos', cargo: 'todos', q: '' });
  const [selected, setSelected] = useState(null);
  const [page, setPage] = useState(1);
  const perPage = 8;

  const solicitudesReales = useMemo(() => data.filter((s) => !s.soloSaldo), [data]);

  const filtered = useMemo(() => solicitudesReales.filter((s) => {
    if (filtros.tipo === 'feriado' && s.tipoId !== 'feriado_legal') return false;
    if (filtros.tipo === 'especiales' && s.tipoId === 'feriado_legal') return false;
    if (filtros.estado !== 'todos' && s.estado !== filtros.estado) return false;
    if (filtros.cargo !== 'todos' && s.worker.cargoId !== filtros.cargo) return false;
    if (filtros.q) {
      const q = filtros.q.toLowerCase();
      if (!nombreCompleto(s.worker).toLowerCase().includes(q) && !s.worker.rut.includes(q) && !s.worker.cut.toLowerCase().includes(q)) return false;
    }
    return true;
  }), [solicitudesReales, filtros]);

  const kpi = useMemo(() => calcularKPIsVacacionesPermisos(solicitudesReales), [solicitudesReales]);
  const saldoAgregado = useMemo(() => data.reduce((s, x) => s + (x.saldo?.diasDisponibles || 0), 0), [data]);
  const conAcumulacionExcedida = useMemo(() => data.filter((x) => x.saldo?.excedeAcumulacion).length, [data]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / perPage));
  const pageRows = filtered.slice((page - 1) * perPage, page * perPage);
  const limpiarFiltros = () => { setFiltros({ tipo: 'todos', estado: 'todos', cargo: 'todos', q: '' }); setPage(1); };

  const exportarCSV = () => {
    const header = ['Trabajador', 'CUT', 'Tipo', 'Inicio', 'Término', 'Días', 'Estado'];
    const lines = filtered.map((s) => [nombreCompleto(s.worker), s.worker.cut, s.tipoId === 'feriado_legal' ? 'Feriado Legal' : TIPOS_PERMISO_ESPECIAL[s.tipoId].label, s.fechaInicio, s.fechaTermino, s.dias, s.estado].join(';'));
    const blob = new Blob([header.join(';') + '\n' + lines.join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'vacaciones_permisos.csv'; a.click();
    URL.revokeObjectURL(url);
    toast('Archivo CSV descargado');
  };

  return (
    <div style={{ fontFamily: C.font, background: C.bg, minHeight: '100%', padding: 22 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 18, flexWrap: 'wrap', gap: 12 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
          <div style={{ width: 34, height: 34, borderRadius: 9, background: C.priL, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Palmtree size={17} style={{ color: C.pri }} />
          </div>
          <div>
            <div style={{ fontSize: 18, fontWeight: 700, color: C.ink }}>Vacaciones y Permisos</div>
            <div style={{ fontSize: 12.5, color: C.mut }}>Workforce · Feriado Legal y permisos especiales — Documento Maestro §36</div>
          </div>
        </div>
        <Btn variant="outline" icon={Download} onClick={exportarCSV}>Exportar CSV</Btn>
      </div>

      <div style={{ display: 'flex', gap: 14, marginBottom: 18, flexWrap: 'wrap' }}>
        <KPICard label="Solicitudes" value={kpi.solicitudes} sub={`${kpi.feriadoLegal} feriado · ${kpi.permisosEspeciales} especiales`} icon={Users} accent={C.pri} />
        <KPICard label="Días de feriado disponibles (total)" value={saldoAgregado} sub="Suma del saldo de todos los trabajadores" icon={TrendingUp} accent={C.info} />
        <KPICard label="Pendientes de aprobar" value={kpi.pendientes} sub={`${kpi.aprobadas} aprobadas · ${kpi.rechazadas} rechazadas`} icon={Clock} accent={C.warn} />
        <KPICard label="Sobre tope de acumulación" value={conAcumulacionExcedida} sub="Art. 70 CT — más de 2 períodos sin tomar" icon={AlertTriangle} accent={C.err} />
      </div>

      <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, padding: 16, boxShadow: C.shadow, marginBottom: 14 }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10, alignItems: 'end' }}>
          <div>
            <FieldLabel>Tipo</FieldLabel>
            <select style={inputStyle} value={filtros.tipo} onChange={(e) => { setFiltros({ ...filtros, tipo: e.target.value }); setPage(1); }}>
              <option value="todos">Todos</option>
              <option value="feriado">Feriado Legal</option>
              <option value="especiales">Permisos Especiales</option>
            </select>
          </div>
          <div>
            <FieldLabel>Estado</FieldLabel>
            <select style={inputStyle} value={filtros.estado} onChange={(e) => { setFiltros({ ...filtros, estado: e.target.value }); setPage(1); }}>
              <option value="todos">Todos</option>
              {Object.entries(ESTADOS_SOLICITUD).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
            </select>
          </div>
          <div>
            <FieldLabel>Cargo</FieldLabel>
            <select style={inputStyle} value={filtros.cargo} onChange={(e) => { setFiltros({ ...filtros, cargo: e.target.value }); setPage(1); }}>
              <option value="todos">Todos</option>
              {Object.entries(CARGOS).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
            </select>
          </div>
          <div>
            <FieldLabel>Buscar</FieldLabel>
            <div style={{ position: 'relative' }}>
              <Search size={14} style={{ position: 'absolute', left: 9, top: 10, color: C.mut }} />
              <input style={{ ...inputStyle, paddingLeft: 28 }} placeholder="Nombre, RUT o CUT" value={filtros.q} onChange={(e) => { setFiltros({ ...filtros, q: e.target.value }); setPage(1); }} />
            </div>
          </div>
        </div>
        <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 12 }}>
          <button onClick={limpiarFiltros} style={{ display: 'flex', alignItems: 'center', gap: 5, background: 'none', border: 'none', cursor: 'pointer', color: C.sub, fontSize: 12.5, fontWeight: 600, padding: 0 }}>
            <RotateCcw size={13} /> Limpiar filtros
          </button>
        </div>
      </div>

      <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, boxShadow: C.shadow, overflow: 'hidden' }}>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
            <thead>
              <tr style={{ background: C.bg, textAlign: 'left' }}>
                {['Trabajador', 'Tipo', 'Inicio', 'Término', 'Días', 'Estado', ''].map((h) => (
                  <th key={h} style={{ padding: '10px 14px', fontSize: 11.5, fontWeight: 700, color: C.sub, textTransform: 'uppercase', letterSpacing: 0.3, whiteSpace: 'nowrap' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {pageRows.map((s) => {
                const cargo = CARGOS[s.worker.cargoId];
                const esFeriado = s.tipoId === 'feriado_legal';
                const tipo = esFeriado ? { label: 'Feriado Legal', color: C.pri, icon: Palmtree } : TIPOS_PERMISO_ESPECIAL[s.tipoId];
                const est = ESTADOS_SOLICITUD[s.estado];
                return (
                  <tr key={s.id} style={{ borderTop: `1px solid ${C.border}`, cursor: 'pointer' }} onClick={() => setSelected(s)}
                    onMouseEnter={(e) => (e.currentTarget.style.background = C.bg)} onMouseLeave={(e) => (e.currentTarget.style.background = 'transparent')}>
                    <td style={{ padding: '11px 14px' }}>
                      <div style={{ fontWeight: 600, color: C.ink }}>{nombreCompleto(s.worker)}</div>
                      <div style={{ fontSize: 11, color: C.mut }}>{cargo.label}</div>
                    </td>
                    <td style={{ padding: '11px 14px' }}><Badge color={tipo.color} bg={tipo.color + '18'} icon={tipo.icon}>{tipo.label}</Badge></td>
                    <td style={{ padding: '11px 14px', color: C.sub, whiteSpace: 'nowrap' }}>{fmtDate(s.fechaInicio)}</td>
                    <td style={{ padding: '11px 14px', color: C.sub, whiteSpace: 'nowrap' }}>{fmtDate(s.fechaTermino)}</td>
                    <td style={{ padding: '11px 14px', color: C.ink }}>{s.dias}</td>
                    <td style={{ padding: '11px 14px' }}><Badge color={est.color} bg={est.color + '18'} icon={est.icon}>{est.label}</Badge></td>
                    <td style={{ padding: '11px 14px' }}><Eye size={15} style={{ color: C.mut }} /></td>
                  </tr>
                );
              })}
              {pageRows.length === 0 && (
                <tr><td colSpan={7} style={{ padding: '40px 14px', textAlign: 'center', color: C.mut, fontSize: 13 }}>
                  No hay solicitudes que calcen con estos filtros. <button onClick={limpiarFiltros} style={{ color: C.info, background: 'none', border: 'none', cursor: 'pointer', fontSize: 13, textDecoration: 'underline', padding: 0 }}>Limpia los filtros</button>.
                </td></tr>
              )}
            </tbody>
          </table>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 16px', borderTop: `1px solid ${C.border}` }}>
          <span style={{ fontSize: 12, color: C.mut }}>{filtered.length} solicitudes · página {page} de {totalPages}</span>
          <div style={{ display: 'flex', gap: 6 }}>
            <Btn variant="outline" onClick={() => setPage(Math.max(1, page - 1))} style={{ padding: '6px 12px', opacity: page === 1 ? 0.4 : 1 }}>Anterior</Btn>
            <Btn variant="outline" onClick={() => setPage(Math.min(totalPages, page + 1))} style={{ padding: '6px 12px', opacity: page === totalPages ? 0.4 : 1 }}>Siguiente</Btn>
          </div>
        </div>
      </div>

      {selected && <DetailModal sol={selected} onClose={() => setSelected(null)} />}
    </div>
  );
}

