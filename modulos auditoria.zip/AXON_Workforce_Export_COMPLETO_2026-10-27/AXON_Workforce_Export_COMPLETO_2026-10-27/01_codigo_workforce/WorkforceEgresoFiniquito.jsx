import React, { useState, useMemo } from 'react';
import {
  LogOut, Search, Download, X, Users, CheckCircle2, Clock, AlertTriangle,
  Info, Eye, RotateCcw, ShieldCheck, Briefcase, UserRound, Building2, Send,
} from 'lucide-react';

/* =========================================================================
   AXON WORKFORCE — Egreso y Finiquito
   §46 Documento Maestro: Workforce → Termination Calculation → Financial
   Event → Account Core. Séptima sección — foco en el MOTOR de cálculo
   (pedido explícito: "avanza con la estructura, afinamos frontend
   después, optimizamos tokens"), UI deliberadamente más simple que las
   secciones anteriores.

   Reutiliza calcularAntiguedad de VacacionesPermisos (ya corregido el bug
   de 365,25) — el cálculo de años para indemnización lo necesita también.
   CUT: queda con el formato provisional a propósito — el real lo inyecta
   MAIN, no se toca acá (instrucción de esta sesión).
   ========================================================================= */

const C = {
  bg: '#F6F5FB', card: '#FFFFFF', border: '#E3DEF5', borderD: '#CBC0E8',
  ink: '#241A3D', sub: '#5F5580', mut: '#948AB5',
  pri: '#6D28D9', priD: '#5518B0', priL: '#F1EAFC',
  info: '#2563EB', infoL: '#EEF3FF', warn: '#B45309', warnL: '#FEF3E2',
  err: '#C62828', errL: '#FDECEC', gold: '#B7791F', teal: '#0E7490',
  r: 10, rSm: 7, rLg: 14, shadow: '0 1px 3px rgba(16,24,40,.06), 0 1px 2px rgba(16,24,40,.04)',
  font: "'Inter', -apple-system, 'Segoe UI', Roboto, sans-serif",
};

const CARGOS = {
  medico: { label: 'Médico/a', icon: Briefcase, color: '#4338CA' },
  enfermeria: { label: 'Enfermera/o', icon: ShieldCheck, color: '#0E7490' },
  tens: { label: 'TENS', icon: Users, color: '#2E7D32' },
  kinesiologo: { label: 'Kinesiólogo/a', icon: Briefcase, color: '#B45309' },
  matrona: { label: 'Matrona/Matrón', icon: ShieldCheck, color: '#BE185D' },
  administrativo: { label: 'Administrativo/a', icon: Building2, color: '#5B6B85' },
  auxiliar: { label: 'Auxiliar de Servicio', icon: UserRound, color: '#94A3B8' },
};

// Causales — no exhaustivo (el CT tiene más), cubre las que aplican a los
// 3 tipos de contrato que ya modela Remuneraciones/Vacaciones.
const CAUSALES_TERMINO = {
  renuncia_voluntaria: { label: 'Renuncia Voluntaria', generaIAS: false, generaSustitutiva: false, generaEspecialObra: false },
  mutuo_acuerdo: { label: 'Mutuo Acuerdo', generaIAS: false, generaSustitutiva: false, generaEspecialObra: false },
  necesidades_empresa: { label: 'Necesidades de la Empresa (Art. 161)', generaIAS: true, generaSustitutiva: true, generaEspecialObra: false },
  vencimiento_plazo: { label: 'Vencimiento de Plazo Fijo', generaIAS: false, generaSustitutiva: false, generaEspecialObra: false },
  conclusion_obra: { label: 'Conclusión de Obra o Faena (Art. 163 bis)', generaIAS: false, generaSustitutiva: false, generaEspecialObra: true },
  despido_causa_grave: { label: 'Despido con Causa Grave (Art. 160)', generaIAS: false, generaSustitutiva: false, generaEspecialObra: false },
};

/* ═══════════════════════════════════════════════════════════════════════
   PARÁMETROS — verificados por búsqueda 2026-09-11, 5 fuentes concordantes
   incluyendo DT directo (ord. 60600). Reutiliza UF_REFERENCIAL/gratificación
   del mismo criterio de Remuneraciones — no se re-busca acá.
   ═══════════════════════════════════════════════════════════════════════ */
const UF_REFERENCIAL = 40885.63; // mismo valor verificado en Remuneraciones
const IAS_DIAS_POR_ANIO = 30;       // Art. 163 CT
const IAS_TOPE_ANIOS = 11;          // Art. 163 CT — 330 días máximo
const IAS_TOPE_BASE_UF = 90;        // Art. 163 CT
const SUSTITUTIVA_DIAS = 30;        // Art. 162 CT — 1 mes si no hubo aviso de 30 días
const ESPECIAL_OBRA_DIAS_POR_MES = 2.5; // Art. 163 bis CT — SIN tope de años (a diferencia del 163 general), confirmado esta sesión

/* ---------------------------- identificadores ----------------------------- */
const PAIS = 'CL', REGION = '13', CLINICA = 'AXON';
function hashLiviano(str) { let h = 0; for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) >>> 0; return h.toString(16).toUpperCase().padStart(2, '0').slice(-2); }
function makeCUT(seq) { const s = String(seq).padStart(8, '0'); return `CUT-${PAIS}-${REGION}-${CLINICA}-${s}-${hashLiviano(`CUT-${PAIS}-${REGION}-${CLINICA}-${s}`)}`; }
function calcDV(rutBody) { let suma = 0, mult = 2; for (let i = rutBody.length - 1; i >= 0; i--) { suma += parseInt(rutBody[i], 10) * mult; mult = mult === 7 ? 2 : mult + 1; } const resto = 11 - (suma % 11); if (resto === 11) return '0'; if (resto === 10) return 'K'; return String(resto); }
function fakeRUT(seed) { const body = String(9000000 + (seed * 7919) % 8900000); return body.slice(0, 2) + '.' + body.slice(2, 5) + '.' + body.slice(5) + '-' + calcDV(body); }
const clp = (n) => '$' + Math.round(n).toLocaleString('es-CL');
const fmtDate = (iso) => new Date(iso + 'T00:00:00').toLocaleDateString('es-CL', { day: '2-digit', month: 'short', year: 'numeric' });
const HOY = (() => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; })(); // fecha LOCAL (toISOString daba la fecha UTC: de noche en Chile ya era mañana)

/* ═══════════════════════════════════════════════════════════════════════
   MOTOR — mismo calcularAntiguedad ya corregido en VacacionesPermisos
   (calendario real, no días/365.25 — ver esa sesión para el bug que
   corrigió). Copiado, no importado, mismo criterio de siempre.
   ═══════════════════════════════════════════════════════════════════════ */
// UTC puro (corregido 2026-10-03): la resta de fechas con hora local perdía un día al cruzar un cambio de horario.
const aUTC = (iso) => { const [y, m, d] = iso.split('-').map(Number); return Date.UTC(y, m - 1, d); };
export function calcularAntiguedad(fechaIngreso, fechaReferencia) {
  const ingreso = new Date(fechaIngreso + 'T00:00:00');
  const ref = new Date(fechaReferencia + 'T00:00:00');
  const diffDias = Math.round((aUTC(fechaReferencia) - aUTC(fechaIngreso)) / 86400000);
  let aniosCompletos = ref.getFullYear() - ingreso.getFullYear();
  const aunNoCumpleAniversarioEsteAnio = (ref.getMonth() < ingreso.getMonth()) || (ref.getMonth() === ingreso.getMonth() && ref.getDate() < ingreso.getDate());
  if (aunNoCumpleAniversarioEsteAnio) aniosCompletos--;
  const mesesCompletos = Math.floor(diffDias / 30.44);
  return { diffDias, aniosCompletos, mesesCompletos };
}

// Años para IAS: fracción >6 meses sobre el último aniversario cuenta
// como año completo (hallazgo de la búsqueda: "8 años y 7 meses = 9 años").
function aniosParaIndemnizacion(fechaIngreso, fechaTermino) {
  const { aniosCompletos } = calcularAntiguedad(fechaIngreso, fechaTermino);
  const ingreso = new Date(fechaIngreso + 'T00:00:00');
  const ultimoAniversario = new Date(ingreso.getFullYear() + aniosCompletos, ingreso.getMonth(), ingreso.getDate());
  const termino = new Date(fechaTermino + 'T00:00:00');
  const diasFraccion = Math.round((aUTC(fechaTermino) - Date.UTC(ultimoAniversario.getFullYear(), ultimoAniversario.getMonth(), ultimoAniversario.getDate())) / 86400000);
  return diasFraccion > 182 ? aniosCompletos + 1 : aniosCompletos; // >6 meses ≈ >182 días
}

/* PUERTA ETIQUETADA — calcularFiniquito
   Mismo contrato que calcularLiquidacion de Remuneraciones: función pura,
   recibe trabajador+causal+datos, devuelve el desglose completo. */
export function calcularFiniquito(worker, causalId, sueldoBase, fechaTermino, avisoPrevioDado, diasVacacionesPendientes) {
  const causal = CAUSALES_TERMINO[causalId];
  const { aniosCompletos } = calcularAntiguedad(worker.fechaIngreso, fechaTermino);

  let indemnizacionAnios = 0, aniosUsadosIAS = 0;
  if (causal.generaIAS && aniosCompletos >= 1) {
    aniosUsadosIAS = Math.min(aniosParaIndemnizacion(worker.fechaIngreso, fechaTermino), IAS_TOPE_ANIOS);
    const topeBasePesos = IAS_TOPE_BASE_UF * UF_REFERENCIAL;
    const baseTopeada = Math.min(sueldoBase, topeBasePesos);
    indemnizacionAnios = Math.round(baseTopeada * aniosUsadosIAS);
  }

  const indemnizacionSustitutiva = (causal.generaSustitutiva && !avisoPrevioDado)
    ? Math.round(sueldoBase * (SUSTITUTIVA_DIAS / 30))
    : 0;

  const indemnizacionEspecialObra = causal.generaEspecialObra
    ? Math.round((sueldoBase / 30) * ESPECIAL_OBRA_DIAS_POR_MES * calcularAntiguedad(worker.fechaIngreso, fechaTermino).mesesCompletos)
    : 0;

  // Vacaciones proporcionales pendientes — SIEMPRE se pagan al término,
  // sin importar la causal (a diferencia de IAS/sustitutiva).
  const valorDiaVacaciones = Math.round(sueldoBase / 30);
  const pagoVacacionesPendientes = Math.round(valorDiaVacaciones * diasVacacionesPendientes);

  const totalIndemnizaciones = indemnizacionAnios + indemnizacionSustitutiva + indemnizacionEspecialObra;
  const totalFiniquito = totalIndemnizaciones + pagoVacacionesPendientes;

  return {
    workerId: worker.id, causalId, fechaTermino, sueldoBase, avisoPrevioDado,
    aniosCompletos, aniosUsadosIAS,
    indemnizacionAnios, indemnizacionSustitutiva, indemnizacionEspecialObra,
    diasVacacionesPendientes, pagoVacacionesPendientes,
    totalIndemnizaciones, totalFiniquito,
  };
}

/* PUERTA ETIQUETADA — hacia Account Core (§56: TerminationCalculated) */
export function construirTerminationCalculatedEvent(finiquito) {
  return {
    tipo: 'TerminationCalculated', dominioOrigen: 'workforce',
    workerId: finiquito.workerId, causalId: finiquito.causalId, fechaTermino: finiquito.fechaTermino,
    indemnizacionAnios: finiquito.indemnizacionAnios,
    indemnizacionSustitutiva: finiquito.indemnizacionSustitutiva,
    indemnizacionEspecialObra: finiquito.indemnizacionEspecialObra,
    pagoVacacionesPendientes: finiquito.pagoVacacionesPendientes,
    totalFiniquito: finiquito.totalFiniquito,
    emitidoEn: new Date().toISOString(),
  };
}

export function calcularKPIsFiniquitos(finiquitos) {
  const sum = (fn) => finiquitos.reduce((s, f) => s + fn(f), 0);
  const conIAS = finiquitos.filter((f) => f.indemnizacionAnios > 0).length;
  const conEspecialObra = finiquitos.filter((f) => f.indemnizacionEspecialObra > 0).length;
  return {
    finiquitos: finiquitos.length,
    totalPagado: sum((f) => f.totalFiniquito),
    totalIAS: sum((f) => f.indemnizacionAnios),
    totalSustitutiva: sum((f) => f.indemnizacionSustitutiva),
    totalEspecialObra: sum((f) => f.indemnizacionEspecialObra),
    conIAS, conEspecialObra,
  };
}

/* ═══════════════════════════════════════════════════════════════════════
   REGISTRO CANÓNICO — copiado 1:1, mismo patrón que los otros 6 archivos.
   ═══════════════════════════════════════════════════════════════════════ */
const NOMBRES_CANONICO = ['María José', 'Pedro', 'Camila', 'Rodrigo', 'Fernanda', 'Ignacio', 'Valentina', 'Cristóbal', 'Antonia', 'Matías', 'Javiera', 'Sebastián', 'Catalina', 'Diego', 'Francisca', 'Tomás', 'Constanza', 'Felipe', 'Josefa', 'Nicolás'];
const APELLIDOS_CANONICO = ['González', 'Muñoz', 'Rojas', 'Díaz', 'Pérez', 'Soto', 'Contreras', 'Silva', 'Martínez', 'Sepúlveda', 'Morales', 'Rodríguez', 'López', 'Fuentes', 'Hernández', 'Torres'];
const CARGOS_LISTA_CANONICO = ['medico', 'enfermeria', 'tens', 'kinesiologo', 'matrona', 'administrativo', 'auxiliar'];
const ESPECIALIDADES_LISTA_CANONICO = ['medico_especialista', 'psicologia', 'kinesiologia', 'nutricion', 'auditoria_clinica'];
const EMPRESAS_HONORARIO_CANONICO = ['Auditoría Clínica del Sur SpA', 'Diagnóstico Externo Ltda.'];
function fechaIngresoDesdeSeed(seed) { const d = 60 + (seed % 5000); const f = new Date(); f.setDate(f.getDate() - d); return f.toISOString().slice(0, 10); }
function generarPersonasCanonico() {
  const personas = []; let seed = 100;
  for (let i = 0; i < 20; i++) {
    seed += 17; const esCore = i >= 17;
    // sector: ver WorkforcePersonas.jsx (puerta etiquetada, Ley 19.664 no implementada)
    personas.push({ id: `per_${1000 + i}`, cut: makeCUT(1000 + i), rut: fakeRUT(seed), nombres: NOMBRES_CANONICO[seed % NOMBRES_CANONICO.length], apellidoPaterno: APELLIDOS_CANONICO[(seed * 2) % APELLIDOS_CANONICO.length], apellidoMaterno: APELLIDOS_CANONICO[(seed * 5) % APELLIDOS_CANONICO.length], tipoRelacion: 'empleado', axonLinea: esCore ? 'axon_core' : 'axon_health', tenantId: esCore ? 'tenant_hospital_regional_demo' : null, sector: esCore ? 'publico' : 'privado', cargoId: CARGOS_LISTA_CANONICO[seed % CARGOS_LISTA_CANONICO.length], fechaIngreso: fechaIngresoDesdeSeed(seed) });
  }
  for (let i = 0; i < 10; i++) {
    seed += 23; const esEmpresa = i >= 8;
    personas.push({ id: `per_${2000 + i}`, cut: makeCUT(2000 + i), rut: fakeRUT(seed), nombres: esEmpresa ? null : NOMBRES_CANONICO[seed % NOMBRES_CANONICO.length], apellidoPaterno: esEmpresa ? null : APELLIDOS_CANONICO[(seed * 2) % APELLIDOS_CANONICO.length], apellidoMaterno: esEmpresa ? null : APELLIDOS_CANONICO[(seed * 5) % APELLIDOS_CANONICO.length], razonSocial: esEmpresa ? EMPRESAS_HONORARIO_CANONICO[i - 8] : null, tipoRelacion: 'honorario', tipoPersonaHonorario: esEmpresa ? 'empresa' : 'natural', axonLinea: 'axon_core_lite', tenantId: null, especialidadId: esEmpresa ? 'auditoria_clinica' : ESPECIALIDADES_LISTA_CANONICO[seed % (ESPECIALIDADES_LISTA_CANONICO.length - 1)] });
  }
  return personas;
}
function genTrabajadores() { return generarPersonasCanonico().filter((p) => p.tipoRelacion === 'empleado'); }
const nombreCompleto = (w) => `${w.nombres} ${w.apellidoPaterno} ${w.apellidoMaterno}`;

/* ------------------------------ mock data -------------------------------- */
const CAUSALES_LISTA = Object.keys(CAUSALES_TERMINO);
const SUELDOS_POR_CARGO = { medico: 3500000, enfermeria: 1500000, tens: 750000, kinesiologo: 1300000, matrona: 1600000, administrativo: 850000, auxiliar: 600000 };

function genFiniquitos(trabajadores) {
  let seed = 41;
  // Solo una porción de la dotación egresa — el resto sigue activo.
  return trabajadores.filter((_, i) => i % 3 === 0).map((w) => {
    seed += 19;
    const causalId = CAUSALES_LISTA[seed % CAUSALES_LISTA.length];
    const fechaTermino = new Date(HOY); fechaTermino.setDate(fechaTermino.getDate() - (seed % 90));
    const fechaTerminoIso = fechaTermino.toISOString().slice(0, 10);
    const sueldoBase = SUELDOS_POR_CARGO[w.cargoId];
    const avisoPrevioDado = seed % 3 !== 0;
    const diasVacacionesPendientes = 2 + (seed % 12);
    const finiquito = calcularFiniquito(w, causalId, sueldoBase, fechaTerminoIso, avisoPrevioDado, diasVacacionesPendientes);
    return { ...finiquito, id: `fin_${w.id}`, worker: w, estado: seed % 5 === 0 ? 'pendiente_pago' : 'pagado' };
  }).sort((a, b) => (a.fechaTermino < b.fechaTermino ? 1 : -1));
}

/* ------------------------------- átomos (mínimos, mismo set reutilizado) ---------------------------------- */
const Badge = ({ color, bg, icon: Icon, children }) => (<span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, padding: '3px 9px', borderRadius: 999, fontSize: 12, fontWeight: 600, color, background: bg, whiteSpace: 'nowrap' }}>{Icon && <Icon size={12} />}{children}</span>);
const Btn = ({ variant = 'ghost', icon: Icon, children, onClick, style }) => { const base = { display: 'inline-flex', alignItems: 'center', gap: 7, padding: '9px 15px', borderRadius: C.rSm, fontSize: 13.5, fontWeight: 600, cursor: 'pointer', border: '1px solid transparent', fontFamily: C.font }; const variants = { primary: { background: C.pri, color: '#fff' }, outline: { background: '#fff', color: C.ink, border: `1px solid ${C.border}` }, ghost: { background: 'transparent', color: C.sub } }; return (<button type="button" onClick={onClick} style={{ ...base, ...variants[variant], ...style }}>{Icon && <Icon size={15} />}{children}</button>); };
const KPICard = ({ label, value, sub, icon: Icon, accent }) => (<div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, padding: '14px 16px', boxShadow: C.shadow, flex: 1, minWidth: 0 }}><div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}><span style={{ fontSize: 12, color: C.sub, fontWeight: 600 }}>{label}</span><Icon size={14} style={{ color: accent }} /></div><div style={{ fontSize: 20, fontWeight: 700, color: C.ink }}>{value}</div>{sub && <div style={{ fontSize: 11.5, color: C.mut, marginTop: 2 }}>{sub}</div>}</div>);
const ESTADOS = { pagado: { label: 'Pagado', color: C.pri, icon: CheckCircle2 }, pendiente_pago: { label: 'Pendiente de Pago', color: C.warn, icon: Clock } };

function DetailModal({ f, onClose }) {
  if (!f) return null;
  const w = f.worker, cargo = CARGOS[w.cargoId], causal = CAUSALES_TERMINO[f.causalId];
  const evento = construirTerminationCalculatedEvent(f);
  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(16,24,40,.45)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100, padding: 20 }} onClick={onClose}>
      <div style={{ background: '#fff', borderRadius: C.rLg, width: 480, maxWidth: '100%', maxHeight: '90vh', overflowY: 'auto', boxShadow: '0 20px 50px rgba(16,24,40,.25)' }} onClick={(e) => e.stopPropagation()}>
        <div style={{ padding: '16px 20px', borderBottom: `1px solid ${C.border}`, display: 'flex', justifyContent: 'space-between' }}>
          <div><div style={{ fontSize: 14, fontWeight: 700, color: C.ink }}>{nombreCompleto(w)}</div><div style={{ fontSize: 11.5, color: C.mut }}>{cargo.label} · {causal.label}</div></div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: C.mut }}><X size={18} /></button>
        </div>
        <div style={{ padding: 20, display: 'flex', flexDirection: 'column', gap: 12 }}>
          <div style={{ fontSize: 12, color: C.sub }}>Antigüedad: {f.aniosCompletos} año(s) · Años usados en IAS: {f.aniosUsadosIAS}</div>
          <div style={{ background: C.bg, borderRadius: C.rSm, padding: 12 }}>
            {[['Indemnización años de servicio', f.indemnizacionAnios], ['Sustitutiva aviso previo', f.indemnizacionSustitutiva], ['Especial obra/faena (163 bis)', f.indemnizacionEspecialObra], ['Vacaciones pendientes', f.pagoVacacionesPendientes]].map(([l, v]) => (
              <div key={l} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, color: C.sub, marginBottom: 4 }}><span>{l}</span><span style={{ color: C.ink, fontWeight: 600 }}>{clp(v)}</span></div>
            ))}
          </div>
          <div style={{ background: C.priL, borderRadius: C.rSm, padding: 12, display: 'flex', justifyContent: 'space-between' }}>
            <span style={{ fontWeight: 700, color: C.ink }}>Total Finiquito</span><span style={{ fontWeight: 700, color: C.priD, fontSize: 16 }}>{clp(f.totalFiniquito)}</span>
          </div>
          <div style={{ display: 'flex', gap: 6, alignItems: 'flex-start', fontSize: 11, color: C.mut }}><Send size={12} style={{ flexShrink: 0, marginTop: 1 }} /><span>Evento TerminationCalculated — puerta etiquetada hacia Account Core, no conectada todavía.</span></div>
          <pre style={{ fontSize: 10, background: C.ink, color: '#D4CBEF', padding: 10, borderRadius: C.rSm, overflowX: 'auto', margin: 0 }}>{JSON.stringify(evento, null, 2)}</pre>
        </div>
      </div>
    </div>
  );
}

export default function WorkforceEgresoFiniquito({ addToast }) {
  const toast = addToast || ((m) => console.log(m));
  const [trabajadores] = useState(genTrabajadores);
  const [data] = useState(() => genFiniquitos(trabajadores));
  const [filtros, setFiltros] = useState({ causal: 'todas', q: '' });
  const [selected, setSelected] = useState(null);

  const filtered = useMemo(() => data.filter((f) => {
    if (filtros.causal !== 'todas' && f.causalId !== filtros.causal) return false;
    if (filtros.q && !nombreCompleto(f.worker).toLowerCase().includes(filtros.q.toLowerCase())) return false;
    return true;
  }), [data, filtros]);
  const kpi = useMemo(() => calcularKPIsFiniquitos(filtered), [filtered]);

  const exportarCSV = () => {
    const header = ['Trabajador', 'CUT', 'Causal', 'Fecha Término', 'IAS', 'Sustitutiva', 'Especial Obra', 'Vacaciones', 'Total', 'Estado'];
    const lines = filtered.map((f) => [nombreCompleto(f.worker), f.worker.cut, CAUSALES_TERMINO[f.causalId].label, f.fechaTermino, f.indemnizacionAnios, f.indemnizacionSustitutiva, f.indemnizacionEspecialObra, f.pagoVacacionesPendientes, f.totalFiniquito, f.estado].join(';'));
    const blob = new Blob([header.join(';') + '\n' + lines.join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = 'finiquitos.csv'; a.click(); URL.revokeObjectURL(url); toast('CSV descargado');
  };

  return (
    <div style={{ fontFamily: C.font, background: C.bg, minHeight: '100%', padding: 22 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 16, flexWrap: 'wrap', gap: 10 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
          <div style={{ width: 32, height: 32, borderRadius: 8, background: C.priL, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><LogOut size={16} style={{ color: C.pri }} /></div>
          <div><div style={{ fontSize: 17, fontWeight: 700, color: C.ink }}>Egreso y Finiquito</div><div style={{ fontSize: 12, color: C.mut }}>Workforce · IAS Art. 163, sustitutiva, especial obra Art. 163 bis</div></div>
        </div>
        <Btn variant="outline" icon={Download} onClick={exportarCSV}>Exportar CSV</Btn>
      </div>

      <div style={{ display: 'flex', gap: 12, marginBottom: 16, flexWrap: 'wrap' }}>
        <KPICard label="Finiquitos" value={kpi.finiquitos} sub={`${kpi.conIAS} con IAS · ${kpi.conEspecialObra} con especial obra`} icon={Users} accent={C.pri} />
        <KPICard label="Total pagado" value={clp(kpi.totalPagado)} icon={CheckCircle2} accent={C.priD} />
        <KPICard label="Indemnización años servicio" value={clp(kpi.totalIAS)} sub="Solo necesidades de la empresa" icon={ShieldCheck} accent={C.teal} />
        <KPICard label="Especial obra/faena" value={clp(kpi.totalEspecialObra)} sub="Art. 163 bis — sin tope de años" icon={AlertTriangle} accent={C.gold} />
      </div>

      <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, padding: 14, boxShadow: C.shadow, marginBottom: 12, display: 'flex', gap: 10, flexWrap: 'wrap' }}>
        <select value={filtros.causal} onChange={(e) => setFiltros({ ...filtros, causal: e.target.value })} style={{ padding: '7px 10px', borderRadius: C.rSm, border: `1px solid ${C.border}`, fontSize: 13 }}>
          <option value="todas">Todas las causales</option>
          {Object.entries(CAUSALES_TERMINO).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
        </select>
        <div style={{ position: 'relative', flex: 1, minWidth: 180 }}>
          <Search size={13} style={{ position: 'absolute', left: 8, top: 9, color: C.mut }} />
          <input placeholder="Buscar trabajador" value={filtros.q} onChange={(e) => setFiltros({ ...filtros, q: e.target.value })} style={{ width: '100%', padding: '7px 10px 7px 26px', borderRadius: C.rSm, border: `1px solid ${C.border}`, fontSize: 13, boxSizing: 'border-box' }} />
        </div>
      </div>

      <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, boxShadow: C.shadow, overflow: 'hidden' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
          <thead><tr style={{ background: C.bg, textAlign: 'left' }}>{['Trabajador', 'Causal', 'Término', 'Total Finiquito', 'Estado', ''].map((h) => <th key={h} style={{ padding: '9px 12px', fontSize: 11, fontWeight: 700, color: C.sub, textTransform: 'uppercase' }}>{h}</th>)}</tr></thead>
          <tbody>
            {filtered.map((f) => {
              const est = ESTADOS[f.estado];
              return (
                <tr key={f.id} style={{ borderTop: `1px solid ${C.border}`, cursor: 'pointer' }} onClick={() => setSelected(f)}>
                  <td style={{ padding: '10px 12px', fontWeight: 600, color: C.ink }}>{nombreCompleto(f.worker)}</td>
                  <td style={{ padding: '10px 12px', color: C.sub }}>{CAUSALES_TERMINO[f.causalId].label}</td>
                  <td style={{ padding: '10px 12px', color: C.sub, whiteSpace: 'nowrap' }}>{fmtDate(f.fechaTermino)}</td>
                  <td style={{ padding: '10px 12px', fontWeight: 700, color: C.ink }}>{clp(f.totalFiniquito)}</td>
                  <td style={{ padding: '10px 12px' }}><Badge color={est.color} bg={est.color + '18'} icon={est.icon}>{est.label}</Badge></td>
                  <td style={{ padding: '10px 12px' }}><Eye size={14} style={{ color: C.mut }} /></td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      {selected && <DetailModal f={selected} onClose={() => setSelected(null)} />}
    </div>
  );
}
