import React, { useState, useMemo } from 'react';
import {
  Award, Search, Download, X, Clock, CheckCircle2, XCircle, AlertTriangle, Ban, Info,
  Eye, RotateCcw, ShieldAlert, ShieldCheck, Send, History, Hourglass,
} from 'lucide-react';

/* =========================================================================
   AXON WORKFORCE — Credenciales y Competencias
   Documento Maestro §12 (documentación, vencimientos, historial), §13
   (credenciales), §48 (competencias: requerida/adquirida/nivel/vencimiento),
   §57 (CredentialIssued / CredentialExpired), §72 (nunca sobrescribir la
   historia), §45 (auditoría: quién, qué, cuándo, valor anterior/nuevo, motivo)
   y §61 (Scheduling consulta aptitud antes de asignar).

   OCTAVA SECCIÓN — primer pendiente de la Parte 10 del dossier y la que no
   depende de la decisión sobre el modelo de 120 familias (Organización sí).
   UI deliberadamente mínima: el foco es el motor (instrucción de la sesión
   anterior: motor primero, frontend después).

   DECISIONES DE DISEÑO (para no volver a discutirlas):
   1. La fecha de vencimiento la dicta el DOCUMENTO (vigenteHasta), no una
      regla del código. `vigenciaMesesDefault` solo sugiere un valor al
      registrar. Los catálogos de abajo son ILUSTRATIVOS (igual que CARGOS en
      Remuneraciones): cada tenant define sus tipos y requisitos — dato
      configurable, no ley. Los umbrales de alerta (30/60 días) son política
      institucional, no mandato legal.
   2. Versionado inmutable: renovar o corregir NO edita la versión anterior
      (§72) — crea una nueva y enlaza ambas. La anterior pasa a "renovada"
      recién cuando la nueva empieza a regir (`reemplazadaDesde`), así una
      renovación anticipada no deja un hueco de cobertura.
   3. Las credenciales son de la PERSONA, no de la relación (§8-9): un médico
      con contrato en AXON Health y honorarios en Core Lite tiene un solo
      conjunto de credenciales.
   4. Fechas con aritmética UTC pura: el resultado no depende de la zona
      horaria del equipo.
   5. CUT sigue provisional — lo inyecta MAIN. Registro canónico copiado, no
      importado (mismo patrón de los otros 7 archivos).
   ========================================================================= */

const C = {
  bg: '#F6F5FB', card: '#FFFFFF', border: '#E3DEF5', borderD: '#CBC0E8',
  ink: '#241A3D', sub: '#5F5580', mut: '#948AB5',
  pri: '#6D28D9', priD: '#5518B0', priL: '#F1EAFC',
  info: '#2563EB', infoL: '#EEF3FF', warn: '#B45309', warnL: '#FEF3E2',
  err: '#C62828', errL: '#FDECEC', teal: '#0E7490',
  r: 10, rSm: 7, rLg: 14, shadow: '0 1px 3px rgba(16,24,40,.06), 0 1px 2px rgba(16,24,40,.04)',
  font: "'Inter', -apple-system, 'Segoe UI', Roboto, sans-serif",
};

// Función = lo que la persona hace: cargoId (empleados) o especialidadId (honorarios).
const FUNCIONES = {
  medico: 'Médico/a', enfermeria: 'Enfermera/o', tens: 'TENS', kinesiologo: 'Kinesiólogo/a', matrona: 'Matrona/Matrón',
  administrativo: 'Administrativo/a', auxiliar: 'Auxiliar de Servicio',
  medico_especialista: 'Médico Especialista (honorario)', psicologia: 'Psicólogo/a (honorario)', kinesiologia: 'Kinesiólogo/a (honorario)',
  nutricion: 'Nutricionista (honorario)', auditoria_clinica: 'Auditoría Clínica (honorario)',
};
const funcionDe = (p) => p.cargoId || p.especialidadId;

/* ---------------------------- catálogos (ILUSTRATIVOS) ----------------------------
   vigenciaMesesDefault: sugerencia al registrar (null = sin vencimiento por defecto).
   vigenciaVariable: el vencimiento hay que tomarlo del documento (no hay default fiable).
   Pendiente de MAIN/tenant: catálogo real de tipos y requisitos por cargo. */
export const TIPOS_CREDENCIAL = {
  titulo_profesional: { label: 'Título profesional / técnico', vigenciaMesesDefault: null, vigenciaVariable: false },
  inscripcion_rnpi: { label: 'Inscripción en Registro de Prestadores Individuales', vigenciaMesesDefault: null, vigenciaVariable: false },
  especialidad: { label: 'Certificación de especialidad', vigenciaMesesDefault: null, vigenciaVariable: true },
  rcp_bls: { label: 'Certificación RCP / BLS', vigenciaMesesDefault: 24, vigenciaVariable: false },
  acls: { label: 'Certificación ACLS', vigenciaMesesDefault: 24, vigenciaVariable: false },
};
const TITULO = { tipoId: 'titulo_profesional', obligatorio: true };
const RNPI = { tipoId: 'inscripcion_rnpi', obligatorio: true };
const RCP = { tipoId: 'rcp_bls', obligatorio: true };
export const REQUISITOS_POR_FUNCION = {
  medico: [TITULO, RNPI, RCP, { tipoId: 'especialidad', obligatorio: false }],
  enfermeria: [TITULO, RNPI, RCP, { tipoId: 'acls', obligatorio: false }],
  tens: [TITULO, RNPI, RCP],
  kinesiologo: [TITULO, RNPI],
  matrona: [TITULO, RNPI, RCP],
  administrativo: [],
  auxiliar: [],
  medico_especialista: [TITULO, RNPI, { tipoId: 'especialidad', obligatorio: true }],
  psicologia: [TITULO, RNPI],
  kinesiologia: [TITULO, RNPI],
  nutricion: [TITULO, RNPI],
  auditoria_clinica: [],
};

/* ═══════════════════════════════════════════════════════════════════════
   MOTOR — fechas con aritmética UTC pura (no dependen de la zona horaria)
   ═══════════════════════════════════════════════════════════════════════ */
const pad2 = (n) => String(n).padStart(2, '0');
const aUTC = (iso) => { const [y, m, d] = iso.split('-').map(Number); return Date.UTC(y, m - 1, d); };
const deUTC = (ms) => { const dt = new Date(ms); return `${dt.getUTCFullYear()}-${pad2(dt.getUTCMonth() + 1)}-${pad2(dt.getUTCDate())}`; };
export const diferenciaDias = (isoA, isoB) => Math.round((aUTC(isoB) - aUTC(isoA)) / 86400000);
export const sumarDias = (iso, n) => deUTC(aUTC(iso) + n * 86400000);
export function sumarMeses(iso, n) {
  const [y, m, d] = iso.split('-').map(Number);
  const total = y * 12 + (m - 1) + n;
  const ny = Math.floor(total / 12), nm = total % 12;
  const ultimoDia = new Date(Date.UTC(ny, nm + 1, 0)).getUTCDate();
  return `${ny}-${pad2(nm + 1)}-${pad2(Math.min(d, ultimoDia))}`;
}
// Sugerencia por defecto al registrar: último día de vigencia = día anterior al aniversario.
export const calcularVigenteHasta = (desdeISO, meses) => (meses == null ? null : sumarDias(sumarMeses(desdeISO, meses), -1));

/* ═══════════════════════════════════════════════════════════════════════
   MOTOR — estado de una credencial en una fecha (§12)
   Estado derivado, nunca guardado: revocada > renovada/reemplazada >
   suspendida > emitida (aún no rige) > vencida > vigente. El día de
   `vigenteHasta` todavía es vigente (límite inclusivo).
   ═══════════════════════════════════════════════════════════════════════ */
const UMBRAL_URGENTE_DIAS = 30, UMBRAL_PRONTO_DIAS = 60; // política institucional configurable, no mandato legal

export function calcularEstadoCredencial(cred, hoyISO) {
  let estado;
  if (cred.revocacion && cred.revocacion.en <= hoyISO) estado = 'revocada';
  else if (cred.reemplazadaPorId && cred.reemplazadaDesde <= hoyISO) estado = cred.motivoCierre === 'correccion' ? 'reemplazada' : 'renovada';
  else if ((cred.suspensiones || []).some((s) => s.desde <= hoyISO && (!s.hasta || hoyISO <= s.hasta) && (!s.levantadaEn || hoyISO < s.levantadaEn))) estado = 'suspendida';
  else if (cred.vigenteDesde > hoyISO) estado = 'emitida';
  else if (cred.vigenteHasta && cred.vigenteHasta < hoyISO) estado = 'vencida';
  else estado = 'vigente';
  const mide = cred.vigenteHasta && ['vigente', 'suspendida', 'emitida', 'vencida'].includes(estado);
  const diasParaVencer = mide ? diferenciaDias(hoyISO, cred.vigenteHasta) : null;
  let urgencia = null;
  if (estado === 'vencida') urgencia = 'vencido';
  else if (estado === 'vigente' && diasParaVencer !== null) urgencia = diasParaVencer <= UMBRAL_URGENTE_DIAS ? 'urgente' : diasParaVencer <= UMBRAL_PRONTO_DIAS ? 'pronto' : 'ok';
  return { estado, diasParaVencer, urgencia };
}

/* La credencial "actual" de una persona para un tipo: ignora las versiones ya
   cerradas por una sucesora y prefiere la que rige hoy (vigente > suspendida >
   aún no rige > vencida > revocada); a igualdad, la emitida más reciente. */
const RANGO_ESTADO = { vigente: 0, suspendida: 1, emitida: 2, vencida: 3, revocada: 4 };
export function elegirCredencialActual(creds, personaId, tipoId, hoyISO) {
  const candidatas = creds
    .filter((c) => c.personaId === personaId && c.tipoId === tipoId)
    .map((c) => ({ c, e: calcularEstadoCredencial(c, hoyISO) }))
    .filter((x) => x.e.estado in RANGO_ESTADO);
  if (!candidatas.length) return null;
  candidatas.sort((a, b) => RANGO_ESTADO[a.e.estado] - RANGO_ESTADO[b.e.estado]
    || (a.c.emitidaEn < b.c.emitidaEn ? 1 : a.c.emitidaEn > b.c.emitidaEn ? -1 : b.c.version - a.c.version));
  return { ...candidatas[0].e, credencial: candidatas[0].c };
}

/* §48/§61 — ¿puede esta persona ocupar esta función hoy? Un requisito obligatorio
   bloquea si falta, está vencido, suspendido, revocado, aún no rige o no alcanza el
   nivel mínimo. "Por vencer" NO bloquea: solo avisa. Los opcionales nunca bloquean. */
export function evaluarAptitud(personaId, funcionId, creds, hoyISO, requisitos = REQUISITOS_POR_FUNCION) {
  const detalle = (requisitos[funcionId] || []).map((r) => {
    const act = elegirCredencialActual(creds, personaId, r.tipoId, hoyISO);
    if (!act) return { ...r, resultado: 'faltante', credencialId: null, diasParaVencer: null };
    let resultado = act.estado === 'vigente' ? (act.urgencia === 'urgente' || act.urgencia === 'pronto' ? 'por_vencer' : 'cumple') : act.estado;
    if ((resultado === 'cumple' || resultado === 'por_vencer') && r.nivelMinimo && (act.credencial.nivel || 0) < r.nivelMinimo) resultado = 'nivel_insuficiente';
    return { ...r, resultado, credencialId: act.credencial.id, diasParaVencer: act.diasParaVencer };
  });
  const valido = (d) => d.resultado === 'cumple' || d.resultado === 'por_vencer';
  const obligatorios = detalle.filter((d) => d.obligatorio);
  const bloqueantes = obligatorios.filter((d) => !valido(d));
  const advertencias = detalle.filter((d) => d.resultado === 'por_vencer');
  const cumplimientoPct = obligatorios.length ? Math.round((obligatorios.filter(valido).length / obligatorios.length) * 100) : 100;
  return { personaId, funcionId, apto: bloqueantes.length === 0, bloqueantes, advertencias, cumplimientoPct, detalle };
}

/* Alertas (mismo patrón que Licencias, pero en días corridos: la vigencia es de calendario).
   Una por (persona, tipo): vence pronto o ya venció SIN renovación registrada. `esRequerida`
   evita alertar por credenciales que la función de la persona no necesita. */
export function calcularAlertasCredenciales(creds, hoyISO, esRequerida = () => true) {
  const claves = [...new Set(creds.map((c) => `${c.personaId}|${c.tipoId}`))];
  return claves
    .map((k) => { const [personaId, tipoId] = k.split('|'); return elegirCredencialActual(creds, personaId, tipoId, hoyISO); })
    .filter((a) => a && !a.credencial.reemplazadaPorId && esRequerida(a.credencial.personaId, a.credencial.tipoId)
      && (a.estado === 'vencida' || (a.estado === 'vigente' && (a.urgencia === 'urgente' || a.urgencia === 'pronto'))))
    .map((a) => ({ credencial: a.credencial, estado: a.estado, diasParaVencer: a.diasParaVencer, nivel: a.urgencia }))
    .sort((x, y) => x.diasParaVencer - y.diasParaVencer);
}

/* ═══════════════════════════════════════════════════════════════════════
   MOTOR — operaciones NO destructivas (§72) con auditoría (§45)
   Reciben el registro y devuelven registros nuevos + una entrada de auditoría;
   nunca mutan el original. `hoyISO` es la fecha de registro (parámetro, no
   Date.now(), para poder probarlo). Error → { error }.
   ═══════════════════════════════════════════════════════════════════════ */
const auditar = (accion, actor, en, credencialId, valorAnterior, valorNuevo, motivo) => ({ accion, actor, en, credencialId, valorAnterior, valorNuevo, motivo: motivo || null });

export function renovarCredencial(cred, datos, hoyISO) {
  const { id, vigenteDesde, vigenteHasta = null, numeroDocumento = null, emisor = cred.emisor, nivel = cred.nivel, evidencia = null, emitidaEn = hoyISO, motivoCierre = 'renovacion', motivo = null, actor } = datos;
  if (!actor) return { error: 'Se requiere el actor: quién registra el cambio.' };
  if (!id || !vigenteDesde) return { error: 'La nueva versión requiere id y vigenteDesde.' };
  if (!['renovacion', 'correccion'].includes(motivoCierre)) return { error: 'motivoCierre debe ser renovacion o correccion.' };
  if (motivoCierre === 'correccion' && !motivo) return { error: 'Corregir una credencial requiere indicar el motivo.' };
  if (cred.reemplazadaPorId) return { error: 'La credencial ya fue reemplazada por otra versión.' };
  if (cred.revocacion) return { error: 'Una credencial revocada no se renueva: corresponde registrar una nueva.' };
  if (vigenteHasta && vigenteHasta < vigenteDesde) return { error: 'vigenteHasta no puede ser anterior a vigenteDesde.' };
  if (vigenteDesde < cred.vigenteDesde) return { error: 'La nueva versión no puede comenzar antes que la anterior.' };
  const nueva = { ...cred, id, version: cred.version + 1, reemplazaA: cred.id, reemplazadaPorId: null, reemplazadaDesde: null, motivoCierre: null, emitidaEn, registradaEn: hoyISO, vigenteDesde, vigenteHasta, numeroDocumento, emisor, nivel, evidencia, suspensiones: [], revocacion: null };
  const anterior = { ...cred, reemplazadaPorId: id, reemplazadaDesde: vigenteDesde, motivoCierre };
  return { anterior, nueva, auditoria: auditar('renovar_credencial', actor, hoyISO, cred.id, { version: cred.version, vigenteHasta: cred.vigenteHasta }, { version: nueva.version, id, vigenteDesde, vigenteHasta }, motivo || motivoCierre) };
}

export function suspenderCredencial(cred, { desde, hasta = null, motivo, actor }, hoyISO) {
  if (!actor) return { error: 'Se requiere el actor: quién registra el cambio.' };
  if (!motivo) return { error: 'La suspensión requiere motivo.' };
  if (!desde) return { error: 'La suspensión requiere fecha de inicio.' };
  if (hasta && hasta < desde) return { error: 'El término de la suspensión no puede ser anterior a su inicio.' };
  if (cred.revocacion) return { error: 'La credencial ya está revocada.' };
  const suspension = { desde, hasta, motivo, actor, registradaEn: hoyISO, levantadaEn: null };
  return { credencial: { ...cred, suspensiones: [...(cred.suspensiones || []), suspension] }, auditoria: auditar('suspender_credencial', actor, hoyISO, cred.id, null, { desde, hasta }, motivo) };
}

export function levantarSuspension(cred, { en, motivo, actor }, hoyISO) {
  if (!actor) return { error: 'Se requiere el actor: quién registra el cambio.' };
  const susp = cred.suspensiones || [];
  const idx = susp.findIndex((s) => !s.levantadaEn && (!s.hasta || s.hasta >= en));
  if (idx < 0) return { error: 'No hay una suspensión vigente que levantar.' };
  const suspensiones = susp.map((s, i) => (i === idx ? { ...s, levantadaEn: en } : s));
  return { credencial: { ...cred, suspensiones }, auditoria: auditar('levantar_suspension', actor, hoyISO, cred.id, { levantadaEn: null }, { levantadaEn: en }, motivo) };
}

export function revocarCredencial(cred, { en, motivo, actor }, hoyISO) {
  if (!actor) return { error: 'Se requiere el actor: quién registra el cambio.' };
  if (!motivo) return { error: 'La revocación requiere motivo.' };
  if (cred.revocacion) return { error: 'La credencial ya está revocada.' };
  const revocacion = { en: en || hoyISO, motivo, actor, registradaEn: hoyISO };
  return { credencial: { ...cred, revocacion }, auditoria: auditar('revocar_credencial', actor, hoyISO, cred.id, null, { en: revocacion.en }, motivo) };
}

/* §57 — eventos de dominio (puerta etiquetada: no hay bus todavía) */
export function construirCredentialIssuedEvent(cred) {
  return { tipo: 'CredentialIssued', dominioOrigen: 'workforce', credencialId: cred.id, personaId: cred.personaId, tipoCredencial: cred.tipoId, version: cred.version, vigenteDesde: cred.vigenteDesde, vigenteHasta: cred.vigenteHasta, emitidoEn: new Date().toISOString() };
}
export function construirCredentialExpiredEvent(cred, hoyISO) {
  const e = calcularEstadoCredencial(cred, hoyISO);
  if (e.estado !== 'vencida') return null;
  return { tipo: 'CredentialExpired', dominioOrigen: 'workforce', credencialId: cred.id, personaId: cred.personaId, tipoCredencial: cred.tipoId, vencidaDesde: sumarDias(cred.vigenteHasta, 1), diasVencida: -e.diasParaVencer, emitidoEn: new Date().toISOString() };
}

export function calcularKPIsCredenciales(creds, hoyISO) {
  const vistas = creds.map((c) => calcularEstadoCredencial(c, hoyISO));
  const abiertas = vistas.filter((e) => e.estado !== 'renovada' && e.estado !== 'reemplazada');
  const cuenta = (est) => abiertas.filter((e) => e.estado === est).length;
  return {
    seccion: 'credenciales', credenciales: creds.length, vigentes: cuenta('vigente'), vencidas: cuenta('vencida'),
    suspendidas: cuenta('suspendida'), revocadas: cuenta('revocada'), emitidasPendientes: cuenta('emitida'),
    porVencer: abiertas.filter((e) => e.estado === 'vigente' && (e.urgencia === 'urgente' || e.urgencia === 'pronto')).length,
    versionesHistoricas: vistas.length - abiertas.length,
  };
}

export function calcularKPIsAptitud(evaluaciones) {
  const aptas = evaluaciones.filter((e) => e.apto).length;
  return {
    personas: evaluaciones.length, aptas, noAptas: evaluaciones.length - aptas,
    conAdvertencias: evaluaciones.filter((e) => e.apto && e.advertencias.length > 0).length,
    cumplimientoPromedio: evaluaciones.length ? Math.round(evaluaciones.reduce((s, e) => s + e.cumplimientoPct, 0) / evaluaciones.length) : 0,
  };
}

/* ---------------------------- identificadores (CUT provisional, lo inyecta MAIN) ----------------------------- */
const PAIS = 'CL', REGION = '13', CLINICA = 'AXON';
function hashLiviano(str) { let h = 0; for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) >>> 0; return h.toString(16).toUpperCase().padStart(2, '0').slice(-2); }
function makeCUT(seq) { const s = String(seq).padStart(8, '0'); return `CUT-${PAIS}-${REGION}-${CLINICA}-${s}-${hashLiviano(`CUT-${PAIS}-${REGION}-${CLINICA}-${s}`)}`; }
function calcDV(rutBody) { let suma = 0, mult = 2; for (let i = rutBody.length - 1; i >= 0; i--) { suma += parseInt(rutBody[i], 10) * mult; mult = mult === 7 ? 2 : mult + 1; } const resto = 11 - (suma % 11); if (resto === 11) return '0'; if (resto === 10) return 'K'; return String(resto); }
function fakeRUT(seed) { const body = String(9000000 + (seed * 7919) % 8900000); return body.slice(0, 2) + '.' + body.slice(2, 5) + '.' + body.slice(5) + '-' + calcDV(body); }

/* ═══════════════════════════════════════════════════════════════════════
   REGISTRO CANÓNICO — copiado desde WorkforcePersonas.jsx (misma versión
   compacta de Finiquito). test_roster.mjs verifica que se comporta igual
   en todos los archivos.
   ═══════════════════════════════════════════════════════════════════════ */
const NOMBRES_CANONICO = ['María José', 'Pedro', 'Camila', 'Rodrigo', 'Fernanda', 'Ignacio', 'Valentina', 'Cristóbal', 'Antonia', 'Matías', 'Javiera', 'Sebastián', 'Catalina', 'Diego', 'Francisca', 'Tomás', 'Constanza', 'Felipe', 'Josefa', 'Nicolás'];
const APELLIDOS_CANONICO = ['González', 'Muñoz', 'Rojas', 'Díaz', 'Pérez', 'Soto', 'Contreras', 'Silva', 'Martínez', 'Sepúlveda', 'Morales', 'Rodríguez', 'López', 'Fuentes', 'Hernández', 'Torres'];
const CARGOS_LISTA_CANONICO = ['medico', 'enfermeria', 'tens', 'kinesiologo', 'matrona', 'administrativo', 'auxiliar'];
const ESPECIALIDADES_LISTA_CANONICO = ['medico_especialista', 'psicologia', 'kinesiologia', 'nutricion', 'auditoria_clinica'];
const EMPRESAS_HONORARIO_CANONICO = ['Auditoría Clínica del Sur SpA', 'Diagnóstico Externo Ltda.'];
function fechaIngresoDesdeSeed(seed) { const d = 60 + (seed % 5000); const f = new Date(); f.setDate(f.getDate() - d); return f.toISOString().slice(0, 10); }
export function generarPersonasCanonico() {
  const personas = []; let seed = 100;
  for (let i = 0; i < 20; i++) {
    seed += 17; const esCore = i >= 17;
    personas.push({ id: `per_${1000 + i}`, cut: makeCUT(1000 + i), rut: fakeRUT(seed), nombres: NOMBRES_CANONICO[seed % NOMBRES_CANONICO.length], apellidoPaterno: APELLIDOS_CANONICO[(seed * 2) % APELLIDOS_CANONICO.length], apellidoMaterno: APELLIDOS_CANONICO[(seed * 5) % APELLIDOS_CANONICO.length], tipoRelacion: 'empleado', axonLinea: esCore ? 'axon_core' : 'axon_health', tenantId: esCore ? 'tenant_hospital_regional_demo' : null, sector: esCore ? 'publico' : 'privado', cargoId: CARGOS_LISTA_CANONICO[seed % CARGOS_LISTA_CANONICO.length], fechaIngreso: fechaIngresoDesdeSeed(seed) });
  }
  for (let i = 0; i < 10; i++) {
    seed += 23; const esEmpresa = i >= 8;
    personas.push({ id: `per_${2000 + i}`, cut: makeCUT(2000 + i), rut: fakeRUT(seed), nombres: esEmpresa ? null : NOMBRES_CANONICO[seed % NOMBRES_CANONICO.length], apellidoPaterno: esEmpresa ? null : APELLIDOS_CANONICO[(seed * 2) % APELLIDOS_CANONICO.length], apellidoMaterno: esEmpresa ? null : APELLIDOS_CANONICO[(seed * 5) % APELLIDOS_CANONICO.length], razonSocial: esEmpresa ? EMPRESAS_HONORARIO_CANONICO[i - 8] : null, tipoRelacion: 'honorario', tipoPersonaHonorario: esEmpresa ? 'empresa' : 'natural', axonLinea: 'axon_core_lite', tenantId: null, especialidadId: esEmpresa ? 'auditoria_clinica' : ESPECIALIDADES_LISTA_CANONICO[seed % (ESPECIALIDADES_LISTA_CANONICO.length - 1)] });
  }
  return personas;
}

/* ═══════════════════════════════════════════════════════════════════════
   MOCK — determinístico respecto de `hoyISO`. Parte con todo vigente y luego
   fuerza los casos que hay que poder ver, usando las MISMAS operaciones del
   motor (así el mock también las ejercita): por vencer, vencida, suspendida,
   revocada, renovación anticipada, renovación ya vigente, y un faltante.
   Las personas jurídicas (empresas a honorarios) no llevan credenciales.
   ═══════════════════════════════════════════════════════════════════════ */
export function generarCredencialesMock(personas, hoyISO) {
  const creds = [], auditoria = [], oblig = new Set();
  let n = 0;
  personas.forEach((p, idx) => {
    if (p.razonSocial) return;
    (REQUISITOS_POR_FUNCION[funcionDe(p)] || []).forEach((r, j) => {
      const seed = idx * 13 + j * 7 + 5;
      if (!r.obligatorio && seed % 2) return; // los opcionales los tiene ~la mitad
      const t = TIPOS_CREDENCIAL[r.tipoId];
      const desde = sumarDias(hoyISO, -(t.vigenciaMesesDefault ? 40 + (seed * 37) % 600 : 800 + (seed * 53) % 3500));
      const hasta = t.vigenciaMesesDefault ? calcularVigenteHasta(desde, t.vigenciaMesesDefault) : t.vigenciaVariable ? sumarDias(hoyISO, 120 + (seed * 29) % 1500) : null;
      n++;
      const id = `cred_${String(n).padStart(3, '0')}`;
      if (r.obligatorio) oblig.add(id);
      creds.push({ id, personaId: p.id, tipoId: r.tipoId, numeroDocumento: `DOC-${1000 + n * 7}`, emisor: 'Entidad emisora (mock)', emitidaEn: desde, registradaEn: desde, vigenteDesde: desde, vigenteHasta: hasta, nivel: null, evidencia: null, version: 1, reemplazaA: null, reemplazadaPorId: null, reemplazadaDesde: null, motivoCierre: null, suspensiones: [], revocacion: null });
    });
  });
  const vence = (i) => { const t = TIPOS_CREDENCIAL[creds[i].tipoId]; return !!(t.vigenciaMesesDefault || t.vigenciaVariable); };
  const conVigencia = creds.map((c, i) => i).filter((i) => vence(i) && oblig.has(creds[i].id)); // escenarios de vencimiento sobre requisitos obligatorios, para que se vea el bloqueo
  const sinVigencia = creds.map((c, i) => i).filter((i) => !vence(i));
  const actor = 'RRHH (demo)';
  const aplicar = (r) => { if (r.error) throw new Error(`mock: ${r.error}`); auditoria.push(r.auditoria); return r; };

  creds[conVigencia[0]] = { ...creds[conVigencia[0]], vigenteHasta: sumarDias(hoyISO, 12) };   // urgente
  creds[conVigencia[2]] = { ...creds[conVigencia[2]], vigenteHasta: sumarDias(hoyISO, 41) };   // pronto
  creds[conVigencia[4]] = { ...creds[conVigencia[4]], vigenteHasta: sumarDias(hoyISO, -19) };  // vencida, sin renovar

  const s = sinVigencia[3];
  creds[s] = aplicar(suspenderCredencial(creds[s], { desde: sumarDias(hoyISO, -6), motivo: 'Sumario administrativo en curso', actor }, sumarDias(hoyISO, -6))).credencial;
  const rv = sinVigencia[6];
  creds[rv] = aplicar(revocarCredencial(creds[rv], { en: sumarDias(hoyISO, -30), motivo: 'Revocada por la entidad emisora', actor }, sumarDias(hoyISO, -30))).credencial;

  // Renovación anticipada: la versión anterior sigue vigente 8 días más; la nueva rige desde el día siguiente.
  const a = conVigencia[6];
  creds[a] = { ...creds[a], vigenteHasta: sumarDias(hoyISO, 8) };
  let r = aplicar(renovarCredencial(creds[a], { id: `${creds[a].id}_v2`, vigenteDesde: sumarDias(hoyISO, 9), vigenteHasta: calcularVigenteHasta(sumarDias(hoyISO, 9), 24), numeroDocumento: 'DOC-RENOV-1', actor }, hoyISO));
  creds[a] = r.anterior; creds.push(r.nueva);
  // Renovación que ya entró en vigor: la versión anterior quedó en el historial.
  const b = conVigencia[8];
  creds[b] = { ...creds[b], vigenteHasta: sumarDias(hoyISO, -40) };
  r = aplicar(renovarCredencial(creds[b], { id: `${creds[b].id}_v2`, vigenteDesde: sumarDias(hoyISO, -39), vigenteHasta: calcularVigenteHasta(sumarDias(hoyISO, -39), 24), numeroDocumento: 'DOC-RENOV-2', actor }, sumarDias(hoyISO, -39)));
  creds[b] = r.anterior; creds.push(r.nueva);

  creds.splice(sinVigencia[10], 1); // un requisito obligatorio que simplemente no está registrado
  return { credenciales: creds, auditoria };
}

/* ═══════════════════════════ UI mínima ═══════════════════════════ */
const HOY = (() => { const d = new Date(); return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`; })();
const fmtDate = (iso) => (iso ? new Date(iso + 'T00:00:00').toLocaleDateString('es-CL', { day: '2-digit', month: 'short', year: 'numeric' }) : '—');
const nombreCompleto = (p) => p.razonSocial || `${p.nombres} ${p.apellidoPaterno} ${p.apellidoMaterno}`;

const ESTADOS = {
  vigente: { label: 'Vigente', color: C.pri, icon: CheckCircle2 },
  emitida: { label: 'Aún no rige', color: C.info, icon: Clock },
  vencida: { label: 'Vencida', color: C.err, icon: XCircle },
  suspendida: { label: 'Suspendida', color: C.warn, icon: AlertTriangle },
  revocada: { label: 'Revocada', color: C.err, icon: Ban },
  renovada: { label: 'Renovada', color: C.mut, icon: History },
  reemplazada: { label: 'Reemplazada', color: C.mut, icon: History },
};
const NIVELES = {
  vencido: { label: 'Vencida', color: C.err, bg: C.errL },
  urgente: { label: 'Urgente', color: '#C2410C', bg: '#FFEDD5' },
  pronto: { label: 'Pronto', color: C.warn, bg: C.warnL },
  ok: { label: 'Con margen', color: C.pri, bg: C.priL },
};
const RESULTADOS = {
  cumple: { label: 'Cumple', color: C.pri }, por_vencer: { label: 'Por vencer', color: C.warn }, faltante: { label: 'Falta', color: C.err },
  vencida: { label: 'Vencida', color: C.err }, suspendida: { label: 'Suspendida', color: C.warn }, revocada: { label: 'Revocada', color: C.err },
  emitida: { label: 'Aún no rige', color: C.info }, nivel_insuficiente: { label: 'Nivel insuficiente', color: C.err },
};

const Badge = ({ color, bg, icon: Icon, children }) => (<span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, padding: '3px 9px', borderRadius: 999, fontSize: 12, fontWeight: 600, color, background: bg || color + '18', whiteSpace: 'nowrap' }}>{Icon && <Icon size={12} />}{children}</span>);
const Btn = ({ variant = 'ghost', icon: Icon, children, onClick, style, title }) => {
  const base = { display: 'inline-flex', alignItems: 'center', gap: 7, padding: '9px 15px', borderRadius: C.rSm, fontSize: 13.5, fontWeight: 600, cursor: 'pointer', border: '1px solid transparent', fontFamily: C.font };
  const variants = { primary: { background: C.pri, color: '#fff' }, outline: { background: '#fff', color: C.ink, border: `1px solid ${C.border}` }, ghost: { background: 'transparent', color: C.sub } };
  return (<button type="button" title={title} onClick={onClick} style={{ ...base, ...variants[variant], ...style }}>{Icon && <Icon size={15} />}{children}</button>);
};
const KPICard = ({ label, value, sub, icon: Icon, accent }) => (<div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, padding: '14px 16px', boxShadow: C.shadow, flex: 1, minWidth: 180 }}><div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}><span style={{ fontSize: 12, color: C.sub, fontWeight: 600 }}>{label}</span><Icon size={14} style={{ color: accent }} /></div><div style={{ fontSize: 20, fontWeight: 700, color: C.ink }}>{value}</div>{sub && <div style={{ fontSize: 11.5, color: C.mut, marginTop: 2 }}>{sub}</div>}</div>);
const FieldLabel = ({ children }) => <label style={{ fontSize: 11.5, fontWeight: 600, color: C.sub, marginBottom: 5, display: 'block' }}>{children}</label>;
const inputStyle = { width: '100%', padding: '8px 10px', borderRadius: C.rSm, border: `1px solid ${C.border}`, fontSize: 13.5, fontFamily: C.font, color: C.ink, outline: 'none', boxSizing: 'border-box', background: '#fff' };
const thStyle = { padding: '9px 12px', fontSize: 11, fontWeight: 700, color: C.sub, textTransform: 'uppercase' };

const Overlay = ({ onClose, width, children }) => (
  <div style={{ position: 'fixed', inset: 0, background: 'rgba(16,24,40,.45)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100, padding: 20 }} onClick={onClose}>
    <div style={{ background: '#fff', borderRadius: C.rLg, width, maxWidth: '100%', maxHeight: '90vh', overflowY: 'auto', boxShadow: '0 20px 50px rgba(16,24,40,.25)' }} onClick={(ev) => ev.stopPropagation()}>{children}</div>
  </div>
);
const ModalHead = ({ title, sub, onClose }) => (
  <div style={{ padding: '16px 20px', borderBottom: `1px solid ${C.border}`, display: 'flex', justifyContent: 'space-between' }}>
    <div><div style={{ fontSize: 14, fontWeight: 700, color: C.ink }}>{title}</div><div style={{ fontSize: 11.5, color: C.mut }}>{sub}</div></div>
    <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: C.mut }}><X size={18} /></button>
  </div>
);

function DetailModal({ cred, persona, cadena, auditoria, onRenovar, onClose }) {
  const e = calcularEstadoCredencial(cred, HOY);
  const est = ESTADOS[e.estado], niv = e.urgencia ? NIVELES[e.urgencia] : null;
  const evento = construirCredentialExpiredEvent(cred, HOY) || construirCredentialIssuedEvent(cred);
  const puedeRenovar = !cred.reemplazadaPorId && !cred.revocacion && !!cred.vigenteHasta;
  const ids = new Set(cadena.map((x) => x.id));
  const audit = auditoria.filter((a) => ids.has(a.credencialId));
  const fila = (l, v) => (<div key={l} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12.5, color: C.sub, marginBottom: 4 }}><span>{l}</span><span style={{ color: C.ink, fontWeight: 600 }}>{v}</span></div>);
  return (
    <Overlay onClose={onClose} width={540}>
      <ModalHead title={nombreCompleto(persona)} sub={`${TIPOS_CREDENCIAL[cred.tipoId].label} · ${FUNCIONES[funcionDe(persona)]}`} onClose={onClose} />
      <div style={{ padding: 20, display: 'flex', flexDirection: 'column', gap: 14 }}>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          <Badge color={est.color} icon={est.icon}>{est.label}</Badge>
          {niv && <Badge color={niv.color} bg={niv.bg}>{niv.label}{e.estado === 'vigente' ? ` · ${e.diasParaVencer} día(s)` : ''}</Badge>}
        </div>
        <div style={{ background: C.bg, borderRadius: C.rSm, padding: 12 }}>
          {fila('Versión', `v${cred.version}`)}
          {fila('N° de documento', cred.numeroDocumento || '—')}
          {fila('Emisor', cred.emisor || '—')}
          {fila('Vigente desde', fmtDate(cred.vigenteDesde))}
          {fila('Vigente hasta', cred.vigenteHasta ? fmtDate(cred.vigenteHasta) : 'Sin vencimiento')}
        </div>
        <div>
          <FieldLabel>Versiones — el historial nunca se sobrescribe</FieldLabel>
          {cadena.map((x) => { const ex = calcularEstadoCredencial(x, HOY), es = ESTADOS[ex.estado]; return (
            <div key={x.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: 12, color: C.sub, padding: '5px 0', borderBottom: `1px solid ${C.border}` }}>
              <span>v{x.version} · {fmtDate(x.vigenteDesde)} → {x.vigenteHasta ? fmtDate(x.vigenteHasta) : 'sin vencimiento'}{x.id === cred.id ? ' (esta)' : ''}</span>
              <Badge color={es.color} icon={es.icon}>{es.label}</Badge>
            </div>); })}
        </div>
        {(cred.suspensiones || []).map((s, i) => (<div key={i} style={{ fontSize: 11.5, color: C.warn }}>Suspensión desde {fmtDate(s.desde)}{s.hasta ? ` hasta ${fmtDate(s.hasta)}` : ' (sin término)'}{s.levantadaEn ? ` · levantada ${fmtDate(s.levantadaEn)}` : ''} — {s.motivo}</div>))}
        {cred.revocacion && <div style={{ fontSize: 11.5, color: C.err }}>Revocada el {fmtDate(cred.revocacion.en)} — {cred.revocacion.motivo}</div>}
        {audit.length > 0 && (<div><FieldLabel>Auditoría</FieldLabel>{audit.map((a, i) => (<div key={i} style={{ fontSize: 11.5, color: C.sub, marginBottom: 3 }}>{fmtDate(a.en)} · {a.accion} · {a.actor}{a.motivo ? ` · ${a.motivo}` : ''}</div>))}</div>)}
        <div style={{ display: 'flex', gap: 6, alignItems: 'flex-start', fontSize: 11, color: C.mut }}><Send size={12} style={{ flexShrink: 0, marginTop: 1 }} /><span>Evento {evento.tipo} — puerta etiquetada hacia el bus de eventos (§57), no conectada todavía.</span></div>
        <pre style={{ fontSize: 10, background: C.ink, color: '#D4CBEF', padding: 10, borderRadius: C.rSm, overflowX: 'auto', margin: 0 }}>{JSON.stringify(evento, null, 2)}</pre>
        {puedeRenovar && <Btn variant="primary" icon={History} onClick={onRenovar} title="Demo: crea la versión siguiente con la vigencia por defecto del tipo (o 24 meses) y deja la anterior en el historial">Registrar renovación</Btn>}
      </div>
    </Overlay>
  );
}

function AptitudModal({ item, onClose }) {
  const { p, ev } = item;
  return (
    <Overlay onClose={onClose} width={500}>
      <ModalHead title={nombreCompleto(p)} sub={FUNCIONES[funcionDe(p)]} onClose={onClose} />
      <div style={{ padding: 20, display: 'flex', flexDirection: 'column', gap: 12 }}>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          <Badge color={ev.apto ? C.pri : C.err} icon={ev.apto ? ShieldCheck : ShieldAlert}>{ev.apto ? 'Apta para su función' : 'No apta: falta algo obligatorio'}</Badge>
          <Badge color={C.sub} bg={C.bg}>{ev.cumplimientoPct}% de requisitos obligatorios</Badge>
        </div>
        {ev.detalle.length === 0 && <div style={{ fontSize: 12.5, color: C.mut }}>Esta función no tiene credenciales requeridas.</div>}
        {ev.detalle.map((d) => { const r = RESULTADOS[d.resultado]; return (
          <div key={d.tipoId} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: 12.5, color: C.ink, padding: '6px 0', borderBottom: `1px solid ${C.border}` }}>
            <span>{TIPOS_CREDENCIAL[d.tipoId].label}{d.obligatorio ? '' : ' (opcional)'}</span>
            <Badge color={r.color}>{r.label}{d.resultado === 'por_vencer' ? ` · ${d.diasParaVencer} d` : ''}</Badge>
          </div>); })}
        <div style={{ display: 'flex', gap: 6, fontSize: 11, color: C.mut }}><Info size={12} style={{ flexShrink: 0, marginTop: 1 }} /><span>Esta es la evaluación que consultaría Scheduling (§61) antes de asignar a la persona a una función. "Por vencer" sigue siendo apta: solo avisa.</span></div>
      </div>
    </Overlay>
  );
}

export default function WorkforceCredenciales({ addToast }) {
  const toast = addToast || ((m) => console.log(m));
  const [personas] = useState(generarPersonasCanonico);
  const [store, setStore] = useState(() => { const g = generarCredencialesMock(personas, HOY); return { creds: g.credenciales, auditoria: g.auditoria }; });
  const [tab, setTab] = useState('credenciales');
  const [filtros, setFiltros] = useState({ estado: 'todos', funcion: 'todas', q: '' });
  const [selId, setSelId] = useState(null);
  const [selApt, setSelApt] = useState(null);
  const [page, setPage] = useState(1);
  const perPage = 10;

  const porId = useMemo(() => Object.fromEntries(personas.map((p) => [p.id, p])), [personas]);
  const coincide = (p) => { if (!filtros.q) return true; const q = filtros.q.toLowerCase(); return nombreCompleto(p).toLowerCase().includes(q) || p.rut.includes(q) || p.cut.toLowerCase().includes(q); };
  const setFiltro = (k, v) => { setFiltros({ ...filtros, [k]: v }); setPage(1); };

  const filas = useMemo(() => store.creds
    .map((c) => ({ c, p: porId[c.personaId], e: calcularEstadoCredencial(c, HOY) }))
    .filter(({ p, e }) => {
      const hist = e.estado === 'renovada' || e.estado === 'reemplazada';
      if (filtros.estado === 'todos' ? hist : filtros.estado === 'historial' ? !hist : e.estado !== filtros.estado) return false;
      if (filtros.funcion !== 'todas' && funcionDe(p) !== filtros.funcion) return false;
      return coincide(p);
    })
    .sort((a, b) => (a.e.diasParaVencer ?? 1e9) - (b.e.diasParaVencer ?? 1e9)), [store, porId, filtros]);

  const evaluaciones = useMemo(() => personas.filter((p) => !p.razonSocial).map((p) => ({ p, ev: evaluarAptitud(p.id, funcionDe(p), store.creds, HOY) })), [personas, store]);
  const evFiltradas = evaluaciones
    .filter(({ p }) => (filtros.funcion === 'todas' || funcionDe(p) === filtros.funcion) && coincide(p))
    .sort((a, b) => a.ev.apto - b.ev.apto || a.ev.cumplimientoPct - b.ev.cumplimientoPct);
  const kc = useMemo(() => calcularKPIsCredenciales(store.creds, HOY), [store]);
  const ka = useMemo(() => calcularKPIsAptitud(evaluaciones.map((x) => x.ev)), [evaluaciones]);
  const alertas = useMemo(() => calcularAlertasCredenciales(store.creds, HOY, (pid, tid) => (REQUISITOS_POR_FUNCION[funcionDe(porId[pid])] || []).some((r) => r.tipoId === tid)), [store, porId]);

  const totalPages = Math.max(1, Math.ceil(filas.length / perPage));
  const pageRows = filas.slice((page - 1) * perPage, page * perPage);
  const selCred = selId ? store.creds.find((c) => c.id === selId) : null;
  const selAptItem = selApt ? evaluaciones.find((x) => x.p.id === selApt) : null;

  const renovar = (c) => {
    const t = TIPOS_CREDENCIAL[c.tipoId];
    const desde = c.vigenteHasta && c.vigenteHasta >= HOY ? sumarDias(c.vigenteHasta, 1) : HOY;
    const r = renovarCredencial(c, { id: `${c.id}_v${c.version + 1}`, vigenteDesde: desde, vigenteHasta: calcularVigenteHasta(desde, t.vigenciaMesesDefault || 24), numeroDocumento: `DOC-RENOV-${c.version + 1}`, actor: 'Usuario (demo)' }, HOY);
    if (r.error) { toast(r.error); return; }
    setStore((s) => ({ creds: [...s.creds.map((x) => (x.id === c.id ? r.anterior : x)), r.nueva], auditoria: [r.auditoria, ...s.auditoria] }));
    setSelId(r.nueva.id);
    toast('Renovación registrada — la versión anterior queda en el historial');
  };

  const exportarCSV = () => {
    const header = ['Persona', 'CUT', 'Función', 'Credencial', 'N° documento', 'Vigente desde', 'Vigente hasta', 'Estado', 'Días para vencer', 'Versión'];
    const lines = filas.map(({ c, p, e }) => [nombreCompleto(p), p.cut, FUNCIONES[funcionDe(p)], TIPOS_CREDENCIAL[c.tipoId].label, c.numeroDocumento || '', c.vigenteDesde, c.vigenteHasta || '', ESTADOS[e.estado].label, e.diasParaVencer ?? '', c.version].join(';'));
    const blob = new Blob([header.join(';') + '\n' + lines.join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = 'credenciales.csv'; a.click(); URL.revokeObjectURL(url); toast('CSV descargado');
  };

  return (
    <div style={{ fontFamily: C.font, background: C.bg, minHeight: '100%', padding: 22 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 16, flexWrap: 'wrap', gap: 10 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
          <div style={{ width: 32, height: 32, borderRadius: 8, background: C.priL, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Award size={16} style={{ color: C.pri }} /></div>
          <div><div style={{ fontSize: 17, fontWeight: 700, color: C.ink }}>Credenciales y Competencias</div><div style={{ fontSize: 12, color: C.mut }}>Workforce · vigencia, historial versionado y aptitud para la función — Documento Maestro §12-13, §48</div></div>
        </div>
        <Btn variant="outline" icon={Download} onClick={exportarCSV}>Exportar CSV</Btn>
      </div>

      <div style={{ display: 'flex', gap: 12, marginBottom: 16, flexWrap: 'wrap' }}>
        <KPICard label="Credenciales vigentes" value={kc.vigentes} sub={`${kc.credenciales} versiones registradas · ${kc.versionesHistoricas} en historial`} icon={CheckCircle2} accent={C.pri} />
        <KPICard label="Por vencer" value={kc.porVencer} sub={`Dentro de ${UMBRAL_PRONTO_DIAS} días — política institucional`} icon={Hourglass} accent={C.warn} />
        <KPICard label="Vencidas o revocadas" value={kc.vencidas + kc.revocadas} sub={`${kc.suspendidas} suspendida(s) aparte`} icon={XCircle} accent={C.err} />
        <KPICard label="Personas no aptas" value={ka.noAptas} sub={`De ${ka.personas} · cumplimiento promedio ${ka.cumplimientoPromedio}%`} icon={ShieldAlert} accent={C.err} />
      </div>

      <div style={{ marginBottom: 16 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
          <AlertTriangle size={15} style={{ color: C.warn }} />
          <span style={{ fontSize: 13, fontWeight: 700, color: C.ink }}>Alertas — vencimientos que requieren acción</span>
          <Badge color={alertas.length ? C.warn : C.mut} bg={alertas.length ? C.warnL : C.bg}>{alertas.length}</Badge>
        </div>
        {alertas.length === 0 ? (
          <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, padding: 14, fontSize: 12.5, color: C.mut }}>Nada por vencer ni vencido sin renovar entre las credenciales que la función requiere.</div>
        ) : alertas.slice(0, 5).map((a) => {
          const niv = NIVELES[a.nivel], p = porId[a.credencial.personaId];
          const texto = a.diasParaVencer < 0 ? `Venció hace ${-a.diasParaVencer} día(s)` : a.diasParaVencer === 0 ? 'Vence HOY' : `Vence en ${a.diasParaVencer} día(s)`;
          return (
            <div key={a.credencial.id} style={{ background: niv.bg, border: `1px solid ${niv.color}30`, borderRadius: C.rSm, padding: '9px 14px', marginBottom: 6, display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 10, flexWrap: 'wrap' }}>
              <div style={{ fontSize: 12.5, fontWeight: 600, color: C.ink }}>{nombreCompleto(p)} <span style={{ fontWeight: 400, color: C.sub }}>· {TIPOS_CREDENCIAL[a.credencial.tipoId].label}</span></div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <Badge color={niv.color} bg="#fff">{niv.label} · {texto}</Badge>
                <Btn variant="outline" icon={Eye} onClick={() => setSelId(a.credencial.id)} style={{ padding: '5px 10px', fontSize: 12 }}>Ver</Btn>
              </div>
            </div>
          );
        })}
        <div style={{ fontSize: 10.5, color: C.mut, marginTop: 6, display: 'flex', gap: 5 }}><Info size={11} style={{ flexShrink: 0, marginTop: 1 }} /><span>Las alertas consideran solo credenciales que la función de la persona exige. La lectura automática de documentos y la verificación en registros oficiales son integraciones reales — puerta etiquetada.</span></div>
      </div>

      <div style={{ display: 'flex', gap: 6, marginBottom: 12 }}>
        {[['credenciales', 'Credenciales'], ['aptitud', 'Aptitud por persona']].map(([id, label]) => (
          <Btn key={id} variant={tab === id ? 'primary' : 'outline'} onClick={() => setTab(id)}>{label}</Btn>
        ))}
      </div>

      <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, padding: 14, boxShadow: C.shadow, marginBottom: 12, display: 'flex', gap: 10, flexWrap: 'wrap', alignItems: 'end' }}>
        {tab === 'credenciales' && (
          <div style={{ minWidth: 150 }}>
            <FieldLabel>Estado</FieldLabel>
            <select style={inputStyle} value={filtros.estado} onChange={(ev) => setFiltro('estado', ev.target.value)}>
              <option value="todos">Todos (versiones actuales)</option>
              {['vigente', 'vencida', 'suspendida', 'revocada', 'emitida'].map((k) => <option key={k} value={k}>{ESTADOS[k].label}</option>)}
              <option value="historial">Historial (renovadas)</option>
            </select>
          </div>
        )}
        <div style={{ minWidth: 190 }}>
          <FieldLabel>Función</FieldLabel>
          <select style={inputStyle} value={filtros.funcion} onChange={(ev) => setFiltro('funcion', ev.target.value)}>
            <option value="todas">Todas</option>
            {Object.entries(FUNCIONES).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
          </select>
        </div>
        <div style={{ position: 'relative', flex: 1, minWidth: 180 }}>
          <Search size={13} style={{ position: 'absolute', left: 8, top: 11, color: C.mut }} />
          <input placeholder="Buscar por nombre, RUT o CUT" value={filtros.q} onChange={(ev) => setFiltro('q', ev.target.value)} style={{ ...inputStyle, paddingLeft: 26 }} />
        </div>
        <Btn variant="ghost" icon={RotateCcw} onClick={() => { setFiltros({ estado: 'todos', funcion: 'todas', q: '' }); setPage(1); }}>Limpiar</Btn>
      </div>

      {tab === 'credenciales' ? (
        <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, boxShadow: C.shadow, overflow: 'hidden' }}>
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
              <thead><tr style={{ background: C.bg, textAlign: 'left' }}>{['Persona', 'Credencial', 'Vigencia', 'Estado', ''].map((h) => <th key={h} style={thStyle}>{h}</th>)}</tr></thead>
              <tbody>
                {pageRows.map(({ c, p, e }) => {
                  const est = ESTADOS[e.estado], niv = e.urgencia && e.urgencia !== 'ok' ? NIVELES[e.urgencia] : null;
                  return (
                    <tr key={c.id} style={{ borderTop: `1px solid ${C.border}`, cursor: 'pointer' }} onClick={() => setSelId(c.id)}>
                      <td style={{ padding: '10px 12px' }}><div style={{ fontWeight: 600, color: C.ink }}>{nombreCompleto(p)}</div><div style={{ fontSize: 11, color: C.mut }}>{FUNCIONES[funcionDe(p)]}</div></td>
                      <td style={{ padding: '10px 12px', color: C.sub }}>{TIPOS_CREDENCIAL[c.tipoId].label}<div style={{ fontSize: 11, color: C.mut }}>v{c.version}{c.numeroDocumento ? ` · ${c.numeroDocumento}` : ''}</div></td>
                      <td style={{ padding: '10px 12px', color: C.sub, whiteSpace: 'nowrap' }}>{fmtDate(c.vigenteDesde)} → {c.vigenteHasta ? fmtDate(c.vigenteHasta) : 'sin vencimiento'}</td>
                      <td style={{ padding: '10px 12px' }}><Badge color={est.color} icon={est.icon}>{est.label}</Badge>{niv && <span style={{ marginLeft: 6 }}><Badge color={niv.color} bg={niv.bg}>{e.estado === 'vencida' ? `hace ${-e.diasParaVencer} d` : `${e.diasParaVencer} d`}</Badge></span>}</td>
                      <td style={{ padding: '10px 12px' }}><Eye size={14} style={{ color: C.mut }} /></td>
                    </tr>
                  );
                })}
                {pageRows.length === 0 && (<tr><td colSpan={5} style={{ padding: '36px 12px', textAlign: 'center', color: C.mut, fontSize: 13 }}>No hay credenciales con estos filtros.</td></tr>)}
              </tbody>
            </table>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 14px', borderTop: `1px solid ${C.border}` }}>
            <span style={{ fontSize: 12, color: C.mut }}>{filas.length} registros · página {page} de {totalPages}</span>
            <div style={{ display: 'flex', gap: 6 }}>
              <Btn variant="outline" onClick={() => setPage(Math.max(1, page - 1))} style={{ padding: '6px 12px', opacity: page === 1 ? 0.4 : 1 }}>Anterior</Btn>
              <Btn variant="outline" onClick={() => setPage(Math.min(totalPages, page + 1))} style={{ padding: '6px 12px', opacity: page === totalPages ? 0.4 : 1 }}>Siguiente</Btn>
            </div>
          </div>
        </div>
      ) : (
        <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, boxShadow: C.shadow, overflow: 'hidden' }}>
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
              <thead><tr style={{ background: C.bg, textAlign: 'left' }}>{['Persona', 'Función', 'Aptitud', 'Requisitos', 'Observaciones'].map((h) => <th key={h} style={thStyle}>{h}</th>)}</tr></thead>
              <tbody>
                {evFiltradas.map(({ p, ev }) => (
                  <tr key={p.id} style={{ borderTop: `1px solid ${C.border}`, cursor: 'pointer' }} onClick={() => setSelApt(p.id)}>
                    <td style={{ padding: '10px 12px', fontWeight: 600, color: C.ink }}>{nombreCompleto(p)}</td>
                    <td style={{ padding: '10px 12px', color: C.sub }}>{FUNCIONES[funcionDe(p)]}</td>
                    <td style={{ padding: '10px 12px' }}><Badge color={ev.apto ? C.pri : C.err} icon={ev.apto ? ShieldCheck : ShieldAlert}>{ev.apto ? 'Apta' : 'No apta'}</Badge></td>
                    <td style={{ padding: '10px 12px', color: C.sub }}>{ev.cumplimientoPct}%</td>
                    <td style={{ padding: '10px 12px', color: C.sub, fontSize: 12 }}>{ev.bloqueantes.length ? ev.bloqueantes.map((b) => `${TIPOS_CREDENCIAL[b.tipoId].label}: ${RESULTADOS[b.resultado].label}`).join(' · ') : ev.advertencias.length ? `${ev.advertencias.length} por vencer` : '—'}</td>
                  </tr>
                ))}
                {evFiltradas.length === 0 && (<tr><td colSpan={5} style={{ padding: '36px 12px', textAlign: 'center', color: C.mut, fontSize: 13 }}>No hay personas con estos filtros.</td></tr>)}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {selCred && (
        <DetailModal
          cred={selCred} persona={porId[selCred.personaId]} auditoria={store.auditoria} onClose={() => setSelId(null)} onRenovar={() => renovar(selCred)}
          cadena={store.creds.filter((x) => x.personaId === selCred.personaId && x.tipoId === selCred.tipoId).sort((a, b) => a.version - b.version)}
        />
      )}
      {selAptItem && <AptitudModal item={selAptItem} onClose={() => setSelApt(null)} />}
    </div>
  );
}
