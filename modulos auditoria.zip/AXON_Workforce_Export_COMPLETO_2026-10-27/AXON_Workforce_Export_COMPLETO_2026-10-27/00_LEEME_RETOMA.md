# AXON — Módulo Workforce (RRHH)
## Dossier técnico y retoma de sesión · v2
**Fecha:** 2026-10-27 · **Motivo:** las sesiones se acortan; este documento permite continuar en un chat nuevo del mismo proyecto sin perder nada.
**Relación con el dossier anterior:** `AXON_Workforce_Dossier_Tecnico_y_Retoma_Sesion.md` (2026-09-11) **sigue vigente** para sus Partes 2, 3, 6, 7 y 11 (inventario de las 7 primeras secciones, patrones, bugs históricos, tabla de parámetros legales y verificación técnica). **Este v2 reemplaza** sus Partes 8, 9 y 10 (revisión externa, pendientes, secciones sin construir) y agrega todo lo ocurrido después.

---

## PARTE 0 · Cómo retomar (léelo primero)

**Prompt sugerido para el chat nuevo (pegar tal cual):**
> Retomamos AXON Workforce. Lee `AXON_Workforce_Dossier_Tecnico_y_Retoma_Sesion_v2_2026-10-27.md` completo y luego `AXON_MAIN_Workforce_Estado_Consolidado` (la versión más reciente, del 23-10-2026). Antes de tocar nada, corre la suite de pruebas (README de `01_codigo_workforce/tests/`) y confirma **395 checks en verde en las tres zonas horarias**. Después ejecuta los pendientes de la Parte 8 en orden de prioridad. No generes documentos para descargar salvo que te lo pida; las respuestas de análisis van en el chat. Cuando haya que exportar, entrega **todo en un único zip ordenado** (nunca archivo por archivo ni por partes).

**Qué debe estar en el Proyecto** (subir antes de abrir el chat nuevo):
1. Los 9 `Workforce*.jsx` y todo `01_codigo_workforce/tests/` (actualizan lo que ya hay en el proyecto: **Casos laborales es nuevo; Licencias cambió**).
2. Este dossier + el dossier del 2026-09-11.
3. `04_documentos_de_referencia/workforce/AXON_MAIN_Workforce_Estado_Consolidado__2026-10-23_VIGENTE.md` (documento vivo de MAIN, 23-10) — es la fuente de verdad del lado MAIN; no lo resumo en lugar de leerlo.
4. Los informes enviados a MAIN: v2 y v2.1 (carpeta `02_informes_para_MAIN/`).
5. Ya están en el proyecto y siguen siendo la base: `Documento_Maestro_de_Arquitectura_Workforce.docx`, `AXON_Identificadores_Universales_v1_0.docx`, `para_WORKFORCE_-_UnitShell.docx`, `Informe_Tecnico_UnitShell_Guia_MAIN_v1.docx`, `AXON_-_Investigacion__simulación_y_docencia.docx`, `Para_workforce_respuestsa_17-10.docx`, `Respuesta_para_workforce_de_MAIN__GPT_sin_ClaudeD_.docx`, `Revision_md_de_workforce_para_main__gpt_.docx`.

**Trampas de entorno ya vividas** (ahorran tiempo):
- Varios `.docx` del proyecto son **texto plano UTF-8**, no Word real: `file X.docx` antes de abrir. Leerlos con `sed -n` o Python.
- `cut -c` corta caracteres multibyte y rompe la salida (UTF-8 inválido): **truncar con Python**, no con `cut`.
- Un texto pegado desde un chat puede traer separadores (`------`) que rompen el JS al extraerlo; limpiar antes de compilar.
- `time` no existe en `/bin/sh` del contenedor.
- `create_file` falla si la ruta existe; para modificar usar parches con Python (`assert count == 1`) o `str_replace`.
- El contenedor se reinicia entre tareas: **lo que no está en `outputs/` o en el Proyecto se pierde**.

---

## PARTE 1 · Estado en una mirada

**Nueve secciones construidas y verificadas** (todas standalone-previsualizables; el registro canónico de personas se **copia**, no se importa):

| # | Archivo | Qué hace | Checks |
|---|---|---|---|
| 1 | `WorkforcePersonas.jsx` | Registro canónico (30 personas: 20 empleados + 10 honorarios) | 18 |
| 2 | `WorkforceRemuneraciones.jsx` | Liquidaciones (AFP, salud, AFC, impuesto único, gratificación, horas extra pactables) | 19 |
| 3 | `WorkforceHonorarios.jsx` | Honorarios: BHE (retención 15,25 %) / Factura + IVA | 14 |
| 4 | `WorkforceTurnosAsistencia.jsx` | Turnos, horas extra/déficit, flag de sistema excepcional | 18 |
| 5 | `WorkforceLicenciasMedicas.jsx` | Licencias (Flujo 2: recepción), plazos, alertas, apelación | 47 |
| 6 | `WorkforceVacacionesPermisos.jsx` | Feriado legal, progresivo, permisos especiales | 25 |
| 7 | `WorkforceEgresoFiniquito.jsx` | IAS (Art. 163), sustitutiva, especial obra (163 bis) | 18 |
| 8 | `WorkforceCredenciales.jsx` | Credenciales versionadas, aptitud para la función, alertas | 106 |
| 9 | **`WorkforceCasosLaborales.jsx`** *(nuevo)* | Casos laborales: Ley Karin y convivencia (flujo A-F, ramas, relojes, reserva) | 127 |
| — | `test_roster.mjs` | El registro canónico se comporta igual en los 9 archivos | 3 |

**Total: 395 checks, 0 fallas, en UTC, `America/Santiago` y `Pacific/Auckland`.** Comando: `bash 01_codigo_workforce/tests/run_all.sh 01_codigo_workforce` (ver `01_codigo_workforce/tests/README.md`).

**Cambios hechos desde el dossier del 2026-09-11:** sección 8 (Credenciales) y 9 (Casos) construidas · Licencias: la carencia de 3 días solo aplica a enfermedad común (2026-10-03) y el plazo del trabajador ya no suma un día de más cuando el reposo parte en día inhábil (2026-10-27, ver Parte 5) · el roster compacto de Finiquito pasó a ser el estándar (verificado por comportamiento, no por bytes) · `build_all.mjs` registra las 9 secciones.

**Lo que NO existe todavía** (no asumirlo): backend de ningún tipo (todo es mock en memoria); conexión real entre archivos (las «puertas etiquetadas» declaran la forma, no llaman a nadie); bus de eventos; `roles.config.js` cruzado con los cargos (los 7 cargos son ilustrativos); formulario de alta de trabajadores/contrato; motor de reglas jurisdiccionales genérico (§19 del Maestro: hoy son parámetros versionados dentro de cada archivo).

---

## PARTE 2 · Decisiones del propietario vigentes (no volver a discutirlas)

**Identificadores**
- **CUT:** un CUT por registro de trabajador **por tenant o microtenant** (no por contrato ni relación). Código de tenant embebido = **exactamente 8 letras A-Z** elegidas por el usuario (Core y Core Lite usan el mismo formato; un microtenant es un tenant individual), único por país+región+código. Quien trabaja en AXON Health + una institución Core + su propio Core Lite tiene **tres CUT** y una sola identidad canónica en MAIN. Los identificadores de relación, contrato y asignación son **distintos** del CUT.
- **Voluntarios NO son trabajadores → no reciben CUT; no se reutiliza el CUP.** Se identifican con el **CUV — «Código Único Voluntario»** (nombre oficial decidido, D-1; ojo: no «de Voluntariado»).
- **Formato CUV autorizado por el propietario:** `CUV-{ISO2}-{REG}-{AXONRADE}-{SEQ6}-{CHK2}` (ver Parte 3 y 5).
- **CUT provisional de Workforce** (`CUT-CL-13-AXON-{seq8}-{hash}`) sigue siendo **solo de demostración**: lo inyecta MAIN con `MasterIdentifierService`.

**Voluntariado y RADE**
- Cualquier tenant (Health, Core, Core Lite) puede registrar voluntarios (autorregistro, colegas, pacientes, familiares); **cada tenant mantiene su lista**; el equipo de AXON Health a cargo de RADE **administra todas las listas**.
- AXON Health se instalará **en cada región**; RADE parte con alcance **nacional en Chile**, luego se replica por país y a nivel mundial, con **un AXON RADE por región de cada país**, administrado desde la primera capa administrativa de AXON Health. Cada línea de AXON parte en Chile y se abre a otros países con la misma estrategia.
- Flujo: RADE (postulación, aptitud, admisión) → MAIN (identidad, autorización) → MasterIdentifierService (emite el CUV **solo tras la admisión**) → Workforce (registra la **participación voluntaria como entidad separada de Worker/Employment**) → Document Engine (acuerdos, firmas) → RADE (disponibilidad para misiones). A Workforce solo llega el **estado de aptitud** (apto / no apto / con restricciones + vigencia), nunca informes clínicos.
- Un acuerdo de voluntariado **no debe disfrazar** una relación laboral: Workforce distingue ambos.
- Beneficios de los voluntarios: **no definidos** (el propietario los estudia): capacitación, equipo de protección, seguros, alimentación, alojamiento, transporte, reembolsos — separar viáticos/reembolsos, seguros y remuneración.
- **Equipos RADE (propuesta del propietario):** Team RADE (evaluación y coordinación) · UNDAC (enlace con la ONU) · USAR (estándar INSARAG; en Chile coordinado por el SNO) · SAR · EMT (OMS) · HAZMAT/QBRN · GERSA (subacuático) · BRE (logística y maquinaria pesada) · WSFF (incendios forestales y estructurales). Cautelas acordadas con la revisión: **no afirmar que RADE es parte oficial de UNDAC/INSARAG/OMS** sin acreditación; «BRE» es denominación interna; una persona puede tener varias capacidades certificadas; los equipos son **nodos organizacionales internos**, no segmentos del identificador.
- Estructura administrativa propuesta (a decidir por el propietario): Dirección General · Administrativa · Personas y Voluntariado · Preparación y Acreditación · Logística y Recursos · Seguridad, Salud y Protección · Cooperación Internacional · Tecnología y Comunicaciones · Calidad y Aprendizaje Operacional · Dirección Operativa/Gestión de Incidentes → fuerzas de tarea desplegables.

**Core Lite**
- **Un solo profesional titular por microtenant; sin secretarias, auxiliares ni personal a cargo** (el Maestro §75-76 debe corregirse). La colaboración (junta médica, telemedicina, derivación nominativa) se registra en su dominio clínico con la identidad de cada participante; **no crea CUT ni relación laboral**.
- Ley 21.431: según MAIN §9.2, el propietario confirmó (11-oct) que **Core Lite está dentro del alcance** (obligación legal y política adoptada). La validación del abogado sobre el modelo efectivo del marketplace y quién opera cada función sigue pendiente. **Cinco controles separados** en el motor: tope interno de actividad (política preventiva, 12 h diarias; falta definir qué se mide) · desconexión continua de 12 h en ventana móvil de 24 h (el trabajador elige la hora) · máximo contractual de conexión continua · jornada dependiente si correspondiera (10 h) · piso de honorarios por hora efectiva (ingreso mínimo × 1,2 ÷ **174 h** hasta abril-2028, luego 172 h; ≈ $3.818 con IMM $553.553). Reglas **versionadas por fecha**, validadas **en backend**.

**Ley Karin / convivencia (alcance de Workforce)**
- Motor transversal de casos para AXON Core y Health (y toda organización con más de un trabajador): recepción y clasificación → protección y evaluación inicial → selección de procedimiento → investigación → conclusión y plan correctivo → seguimiento y cierre. La mediación **no** es etapa previa obligatoria ni sustituye la investigación formal exigible; las evaluaciones médicas/psicológicas **no** son automáticas; **la IA no decide credibilidad, culpabilidad ni sanción**.

**Principios congelados (Maestro §79) y los de esta etapa:** un solo motor · modelo propio (FHIR/ISO son referencia) · legislación desacoplada (reglas = datos versionados) · separación financiera (Workforce calcula, Account Core registra; vía eventos) · separación de relaciones. Además: Workforce **no absorbe CR/CC** (los referencia); catálogos de **relaciones, posiciones y roles separados** (con reglas de compatibilidad); el calendario transversal presenta eventos, **cada dominio es dueño de los suyos**; autoridad de plataforma ≠ acceso indiscriminado a datos (Country/World reciben **agregados**).

**Nomenclatura:** «AXON HOLDING FAMILY'S» lo usó el propietario como identidad de holding; falta confirmar si es nombre comercial o razón social (ver MAIN §8). Nada con prefijo «AXON» se adopta sin confirmación del propietario.

---

## PARTE 3 · Estado del trabajo con MAIN (documento vivo del 23-10-2026)

Fuente: `04_documentos_de_referencia/workforce/AXON_MAIN_Workforce_Estado_Consolidado__2026-10-23_VIGENTE.md` — **leerlo completo**; abajo, solo lo que condiciona a Workforce.
- **CUV integrado** en el servicio único de identificadores; decisiones del propietario cerradas **D-1 a D-5**: (D-1) nombre «Código Único Voluntario»; (D-2) **un CUV por persona y ámbito RADE**, estable aunque se retire y vuelva; un CUV revocado **nunca se reactiva** (reingreso → CUV nuevo); (D-3) **un solo código de ámbito `AXONRADE`** para todo RADE; unidades regionales y los 9 equipos son nodos internos (OrgNode); (D-4) formato **A: SEQ6 con REG**, congelado al emitir el primer CUV; (D-5) el identificador temporal de candidatura es **interno de RADE/Workforce** y nunca se muestra como CUV.
- Validación MAIN: `^CUV-([A-Z]{2})-([A-Z0-9]{1,3})-([A-Z]{8})-(\d{6})-([A-Z]\d)$` + SEQ ≠ 000000; la lista de ámbitos válidos es **configuración** (hoy `AXONRADE`). Vector de MAIN: `CUV-CL-13-AXONRADE-000001-P8` — **coincide con mi implementación independiente** (Parte 5).
- **Emisión de CUV bloqueada** hasta: spec v1.1 aprobada + registro/contador transaccional en backend. Hitos: G1 (spec v1.1 borrador) entregado · G2 hecho · **G3 = revisión con Workforce y RADE (9 puntos)** · G4 entrega a Workforce · G5-G6 backend. Propuesta FHIR de MAIN para G3: `type.code = CUV` en un CodeSystem AXON; recurso destino a decidir (propuesta: Practitioner + PractitionerRole de la organización RADE).
- MAIN resolvió el CUT de AXON Health: se mantiene `AXON` (4 caracteres) con validador propio (`validarCUTAxon`); corrige las observaciones A-D de la revisión (relleno silencioso, validación de 8 letras, CUT de Health que no pasaba el validador genérico, etiqueta FHIR «Employee Identifier»).
- Pendiente de MAIN sobre la v2.1 de Workforce (su §10): contrato Position/OrgNode/Assignment/Role Assignment, reglas de compatibilidad entre catálogos, propiedad de eventos de calendario, estrategia de pruebas (concurrencia, idempotencia, aislamiento entre tenants), enmiendas al Maestro (§11.2, §75-76).
- **Lo que le toca al propietario/Workforce:** entregar la versión final de `MasterIdentifierService` al equipo; compartir los dos documentos originales de UnitShell; confirmar nomenclatura; abogado para los relojes y la 21.431.

---

## PARTE 4 · Revisión externa del 17-oct (GPT sobre tres JSX) — estado punto por punto

Cada afirmación fue **contrastada ejecutando código** (Parte 5). Estado: ✅ hecho · ⏳ pendiente (especificación completa en Parte 8).

| Observación de la revisión | Veredicto | Estado |
|---|---|---|
| **Casos:** marcador `/*@@ROSTER@@*/` sin resolver (línea 767; uso en 975) | **Cierto**: yo lo había dejado a medias | ✅ resuelto; `generarPersonasCanonico` incluido y verificado por `test_roster` |
| **Casos:** `declararSinMedidas()` registraba `medidas_aplicadas` | **Cierto** | ✅ separado: `decision_sin_medidas` ≠ `medidas_correctivas_aplicadas`; la decisión **no** cumple el plazo del art. 211-E (queda «decidido sin medidas», para revisión) |
| **Casos:** individualización del denunciante solo al investigar | **Cierto** | ✅ ahora también al **derivar a la DT** (ORD. N.º 146/13) |
| **Casos:** `sectorTenant` público fuerza ruta administrativa | **Cierto** | ✅ la ruta depende del **régimen jurídico declarado por caso**; en tenant privado se asume Código del Trabajo marcado como *inferido* |
| **Casos:** `TRANSICIONES` definida pero no usada | **Cierto** | ✅ `aplicar()` hace cumplir la máquina de estados; prueba de propiedad (60 secuencias aleatorias × 60 pasos) |
| **Casos:** medidas de resguardo propuestas/ordenadas/implementadas | Mejora válida | ✅ `propuesta → ordenada (quien decide) → implementada (con evidencia)` |
| **Casos:** controles de acceso solo demostración; usar tenant y relación vigente | Cierto | ✅ el motor evalúa rol del caso + **tenant + relación vigente + conflicto de interés + bitácora** como **contrato demostrativo**; ⏳ la aplicación real es del backend (MAIN) |
| **Casos:** paquete de plazos borrador no debe ser regla productiva | De acuerdo | ✅ se mantiene `validada:false`, `listoParaProduccion:false`; alerta por la variante más temprana y muestra la más tardía |
| **P0:** contrato común de eventos (id, idempotencia, esquema, tenant, actor, tiempo efectivo, correlación) | De acuerdo | ✅ en Casos (`crearEnvelopeEvento`) · ⏳ resto de módulos |
| **P0:** no generar CUT/CUV en los módulos | Ya cumplido (generadores = demo) | ✅ sin cambio; se reemplazan al recibir el servicio |
| **Licencias:** error de un día en el plazo cuando el reposo parte en día inhábil | **Cierto** (mi refutación anterior probó solo lunes, viernes y sábado) | ✅ corregido y con regresión (Parte 5) |
| **Licencias:** `construirAusenciaParaRemuneraciones` declara todos los días como no remunerados | Cierto | ⏳ P1 |
| **Licencias:** `empleadorAsumeSubsidio = true` por envío tardío | Sin respaldo oficial suficiente (hay **conflicto entre fuentes**: agosto lo marcó «verificado») | ⏳ P1 |
| **Licencias:** reclamos 15 d COMPIN + 5 d SUSESO como secuencia universal; usa `fechaResolucion` | Cierto | ⏳ P1 |
| **Licencias:** `PLAZO_PAGO_SUBSIDIO_DIAS_HABILES = 30` sin uso y sin sustento | Cierto | ⏳ P1 |
| **Licencias/Casos:** calendario duplicado y solo 2026 | Cierto | ⏳ P4 (parcial: Casos ya avisa `feriados_no_cargados_AAAA`) |
| **Credenciales:** renovación inventa 24 meses | **Cierto** | ⏳ P2 |
| **Credenciales:** credencial ≠ competencia ≠ aptitud ≠ autorización; aptitud como entrada de políticas | De acuerdo | ⏳ P2 |
| **MasterIdentifierService (17-oct):** relleno/truncamiento, dígitos aceptados, CUT de Health inválido, CUIT Core = Core Lite, etiqueta FHIR | **Todo cierto** (verificado ejecutando) | MAIN ya lo corrigió (Parte 3) |

---

## PARTE 5 · Verificaciones ejecutadas (reproducibles)

**A. `MasterIdentifierService` del 17-oct** (extraído del `.docx` del proyecto; `03_verificaciones/mis.mjs` + `probar.mjs`):
- Vectores de la especificación: `CUP-CL-13-2026-00000047` → **N7** ✓ · `CUP-NN-CL-13-2026-00000001` → **W4** ✓.
- `generarCUT` con `SALUD` → `SALUDXXX` (rellena); con 10 letras → trunca a 8; **acepta dígitos** (`RESCATE1`).
- `generarCUTAxon` produce `CUT-CL-13-AXON-0001-E9` (coincide con la especificación) pero **`validarCUT` lo rechaza**, `decodificarCUT` devuelve `null` y **`revocarCUT` lanza error**.
- Secuencia 10000 produce 5 dígitos (identificador inválido con CHK2 de apariencia válida); −1 y «abc» tampoco se rechazan: **garbage in, garbage out**.
- `generarCUITAxonCore` y `generarCUITAxonCoreLite` producen **la misma cadena** (se distinguen solo por metadato).
- `cutAFHIRIdentifier` etiqueta todo como «Employee Identifier». No existen validadores propios de los 10 identificadores nuevos.

**B. CUV propuesto** — implementación de referencia independiente (`03_verificaciones/cuv.mjs`, corre con `node cuv.mjs`): vectores `CUV-CL-13-AXONRADE-000001-P8` (**coincide con MAIN**), `…-000047-`, `CL-05`, `PE-15`, `…-999999-`. 5.000 emisiones consecutivas validan; CHK2 usa 200+ de los 256 valores. **Rechaza:** minúsculas, `_`, espacio, homoglifo cirílico, guion Unicode, 7 letras, otro código de 8 letras, SEQ de 5/7 dígitos, CHK2 alterado/hex/`Z6`, REG vacío o de 4 caracteres, SEQ 000000 y prefijo `CUT`. El generador **lanza error** con SEQ 0, 1.000.000, −1, «abc», ISO2 «chile». Ninguna otra familia valida como CUV ni al revés. **Hallazgo:** `AXONRADE` como código de tenant genera un **CUT válido** → hay que **reservar la palabra** en el registro de tenants. Cumple los criterios §120 (entidad nueva, ciclo propio, espacio propio, interoperabilidad, permanente, no representable como CUT/CUP, razón legal) y reglas §8-§25; pendientes según §121: revisión de seguridad y revisión legal del voluntariado.

**C. Licencias — plazo del trabajador (2 días hábiles siguientes al inicio del reposo), medido antes y después:** antes, un reposo que partía en **domingo** daba plazo el **miércoles** (el sábado daba martes) y uno que partía en el **lunes feriado 12-oct** daba el **jueves 15** (debía ser el miércoles 14). El ajuste `inicioConteo` movía el inicio al día hábil siguiente y luego contaba desde el día *después*. Corregido (`inicioConteo = fechaInicioReposo`) y 4 pruebas de regresión: sábado = domingo = martes; lunes → miércoles; lunes feriado → miércoles; viernes → martes. **Lección:** probar siempre la matriz de días de la semana + feriados, no tres fechas.

**D. Casos laborales:** 127 checks incl. prueba de propiedad: 60 secuencias aleatorias de 60 operaciones → ninguna transición ilegal, cada operación exitosa suma exactamente una versión y un registro de historial, ninguna muta el caso anterior, y la exploración alcanza ≥ 6 estados distintos.

---

## PARTE 6 · Motor de Casos laborales — referencia rápida

**Archivo:** `WorkforceCasosLaborales.jsx` (~1.230 líneas). UI mínima a propósito (motor primero). Todo es **demostración in-memory**; la reserva, el aislamiento por tenant y la relación vigente **los aplica el backend**.

**Modelo:** caso versionado e inmutable. Cada operación `(caso, datos, hoyISO) → { caso, auditoria } | { error }`. `hoyISO` es parámetro (no `Date.now()`), para poder probar. Fechas con aritmética UTC. Relatos, informes y evidencia se guardan como **referencias** (≤ 80 caracteres, sin saltos de línea), nunca como contenido.

**Estados (A-F):** `recibida`, `por_complementar` (A) · `clasificada` (A) · `evaluacion_inicial` (B) · `procedimiento_seleccionado` (C) · `en_investigacion`, `derivado_dt` (D) · `conclusiones` (E) · `en_seguimiento`, `cerrado` (F). Única máquina de estados: `TRANSICIONES` + `puedeTransicionar`, impuesta en `aplicar()`.

**Ramas:** acoso/violencia legal · violencia de terceros (puede activar la vía legal) · convivencia · riesgo psicosocial · riesgo físico/delito (acciones inmediatas, sin esperar la investigación). **Régimen jurídico** por caso (`codigo_trabajo` | `estatutario_publico` | `por_determinar`); denunciado del **art. 4 inc. 1** → derivación obligatoria a la DT.

**Operaciones principales:** `crearCaso`, `clasificarCaso`, `solicitarComplemento` / `recibirComplemento` / `continuarSinComplemento` (ORD. 146/13: no se archiva por inconsistente), `proponer|ordenar|implementar|descartarMedidaResguardo`, `registrarEvaluacionInicial`, `asignarRol`, `declararConflictoInteres`, `seleccionarProcedimiento`, `iniciarInvestigacion`, `derivarADT`, `registrarActuacion`, `estadoAudienciaPartes` (debido proceso: ambas partes oídas), `solicitarEvaluacionProfesional` / `registrarResultadoEvaluacion` (informe clínico **fuera** del expediente), `registrarConclusiones`, `remitirInformeADT`, `registrarConclusionesDT`, `registrarMedidaCorrectiva`, `marcarMedidaAplicada`, `declararSinMedidas`, `registrarSeguimiento`, `verificarCierre` / `cerrarCaso`.

**Acceso:** roles **del caso** (receptor, investigador, responsable, denunciante, denunciado), no del cargo. `evaluarAcceso` aplica, en orden: actor identificado → tenant → relación vigente → conflicto de interés → rol → permiso. `proyectarCaso` devuelve vista `completo` / `parte` (solo lo propio) / `null`. `registrarAcceso` deja bitácora también de lo denegado. Permisos del motor: `registrar`, `investigar`, `decidir`, `leer_expediente`, `leer_vista_parte` (**alinear nombres con la matriz de acciones de UnitShell** cuando MAIN entregue el contrato: ver, registrar, corregir, solicitar, ejecutar, interpretar, firmar, publicar, cerrar).

**Relojes** (datos, no constantes): `PAQUETE_REGLAS_CL_BORRADOR` — K0 resguardo DT (informativo) · K1 decidir investigar/derivar (3 días; corridos u hábiles) · K2 concluir investigación (30 días; inicio en denuncia o en inicio de investigación) · K3 remitir informe a la DT (2 o 5 días) · K4 medidas/sanciones (15 días; hábiles judiciales o corridos) · K5 pronunciamiento DT (informativo). **Ninguna validada por abogado.** Con variantes, alerta por la **más temprana** (`vencimientoOperativo`) y muestra la más tardía (`vencimientoMaximo`). Régimen estatutario → sin relojes (otro estatuto, no modelado). Calendario solo 2026 con aviso `feriados_no_cargados_AAAA`.

**Eventos (§57):** `CaseOpened`, `InvestigationStarted`, `InvestigationClosed`, `CaseClosed` con envelope común (`eventId`, `idempotencyKey` determinística, `schemaVersion`, `tenantId`, `legalEntityId`, `actorRef`, `ocurridoEn` ≠ `emitidoEn`, `correlationId`, `versionCaso`, `payload`). Solo identificadores opacos; **no** filtran partes ni relato.

**KPIs:** `calcularKPIsCasos(..., { umbralSupresion })` suprime cantidades pequeñas en los agregados que subirían a Country/World.

**Mock:** 19 casos determinísticos (todas las etapas, las 5 ramas, canal DT, art. 4, régimen estatutario y Código del Trabajo en institución pública, complemento, relojes en los 4 niveles, una decisión sin medidas, un caso cerrado de punta a punta).

---

## PARTE 7 · Lo aprendido de los documentos nuevos (qué implica para Workforce)

- **`Para_workforce_respuestsa_17-10`:** modelo de voluntariado por tenant (Parte 2) + auditoría de 3 JSX (Parte 4) + `MasterIdentifierService` pegado (Parte 5).
- **`Respuesta_para_workforce_de_MAIN_(GPT_sin_ClaudeD)`:** 7 ajustes a la v2 → ya incorporados en la **v2.1** enviada a MAIN (CUV por admisión; no pedir el archivo; Core Lite no limita colaboraciones; propiedad por objeto en UnitShell; taxonomía por ejes; límite interno de horas separado de lo legal; ORD. 146/13).
- **`para_WORKFORCE_-_UnitShell` (versión extendida):** cadena Person → Worker → Position → Org Assignment → Role Assignment → Credential → Operational Assignment → Policy → UnitShell; **Position es entidad de primer nivel**; ejemplo de la enfermera que rota UCI/Urgencia/Pabellón con un mismo Role; CR/CC se **referencian**, no se absorben; propuesta de los 9 equipos RADE y la estructura administrativa; referentes internacionales (INSARAG/OCHA/UNDAC/OSOCC, EMT-OMS, IFRC, IAMSAR, FEMA/NIMS, SNO de Chile) — Workforce **no** construye RADE: provee identidad, relaciones y asignaciones.
- **`Informe_Tecnico_UnitShell_Guia_MAIN_v1`:** UnitShell = capa de resolución de contexto (rol, unidad, actividad, paciente, perfil de prestación) sobre un Workflow Engine único; **permisos por acción** (ver/registrar/corregir/solicitar/ejecutar/interpretar/firmar/publicar/cerrar) validados **en backend**; la edad y el sexo clínico se usan solo cuando el método lo exige; estados separados por objeto. Implica: la **aptitud** de Credenciales es *entrada* del motor de políticas (PBAC), no una autorización; el actor que firma/valida ≠ quien abre el workspace.
- **`AXON_-_Investigacion,_simulación_y_docencia`:** un **solo** Workflow Engine con «paquetes de capacidades» (Research Core, Education Core, Simulation); **un solo motor de anonimización/seudonimización con perfiles** (anonimización total, seudonimización reversible, sintéticos, minimización) para investigación, docencia, simulación, Country y World; Research Data Access Gateway entre el núcleo clínico y la investigación. **Para Workforce:** (1) alumnos, docentes y tutores son **participaciones formativas**, no empleo: encajan en la familia «estancia formativa» de la taxonomía (sin CUT por defecto; decisión de identificador pendiente de MAIN, **no inventar**); (2) las credenciales/competencias de tutores y la aptitud alimentan la asignación de campos clínicos; (3) la analítica de workforce que suba a Country/World debe ser **agregada** (ya implementado en KPIs de Casos); (4) la evidencia de aprendizaje y las notas son de Education Core, no de Workforce.
- **Estado consolidado de MAIN (23-10):** Parte 3.

---

## PARTE 8 · Pendientes priorizados (en este orden)

**P1 · Licencias y Vacaciones → Remuneraciones (efecto económico)** — editar `WorkforceLicenciasMedicas.jsx`, `WorkforceVacacionesPermisos.jsx`, `test_licencias.mjs`, `test_vacaciones.mjs`:
1. `construirAusenciaParaRemuneraciones(lic)`: eliminar `diasNoRemuneradosPorEmpleador`. Nueva forma común en ambos archivos: `{ workerId, diasAusencia, motivo, categoria: 'licencia_medica' | 'feriado_legal' | 'permiso_especial', tratamientoEconomico: { tipo: 'por_determinar' | 'remuneracion_continua', pagadorProbable?, requiereRegla } }`. Licencia → `por_determinar` con `pagadorProbable` = `mutual` o `isapre_fonasa` (según circuito); feriado y permisos especiales (Art. 66, 195, 207 bis, con goce) → `remuneracion_continua`. Remuneraciones aplica la política; no resta meses completos.
2. Renombrar `empleadorAsumeSubsidio` → `empleadorFueraDePlazo` (incumplimiento registrado) + `efectoFinanciero: 'sujeto_a_regla_juridica_validada'`; neutralizar el aviso del modal y el KPI («AXON asume el subsidio»). **Antes de dar efecto financiero**, resolver con abogado/SUSESO el conflicto entre fuentes.
3. Reclamos: campos `entidadResolutora` (`isapre|compin|mutual|ccaf`), `fechaNotificacionResolucion` (no `fechaResolucion`) y `rutaReclamo` de un **catálogo versionado** (`isapre_rechazo` → reclamo ante COMPIN, 15 días hábiles desde la recepción del pronunciamiento; `compin_fonasa` → reposición, 5 días ante la misma entidad; SUSESO con sus propios requisitos), todo `validada:false`. Sin ruta definida → sin reloj de apelación y con aviso.
4. Eliminar `PLAZO_PAGO_SUBSIDIO_DIAS_HABILES` (sin uso; la fuente habla de periodicidad ≥ la de la remuneración, sin superar un mes).
5. Actualizar las 3 pruebas que fijan los campos viejos y agregar las nuevas.

**P2 · Credenciales** — la renovación demo usa `vigenciaMesesDefault || 24`: si el tipo es de vigencia variable o sin valor por defecto, **pedir la fecha del documento** (input) y bloquear sin ella. Exportar `construirEntradaPolitica(evaluacion)` → `{ personaId, funcionId, aptitud, bloqueantes, advertencias, vigenteAl, versionCatalogo }` (puerta etiquetada hacia PBAC). Documentar en cabecera: credencial ≠ competencia ≠ aptitud ≠ autorización efectiva; el acceso a credenciales lo controla MAIN; los requisitos por función serán configurables por jurisdicción/institución/cargo/servicio (hoy estáticos e ilustrativos).

**P3 · Eventos** — copiar `crearEnvelopeEvento` (Casos) a Credenciales (`CredentialIssued/Expired`), Remuneraciones (`PayrollCalculated`), Honorarios, Finiquito, y crear los de Licencias (`MedicalLeaveReceived/Approved/Rejected`, §57). Mantener campos existentes para no romper pruebas.

**P4 · Calendario y parámetros compartidos** — extraer feriados/días hábiles a un **contrato de MAIN** (región, institución, régimen, tipo de día, vigencia, fuente). Hasta entonces, extender a Licencias y Vacaciones el aviso `feriados_no_cargados_AAAA`.

**P5 · Organización y posiciones** (Maestro §18, §34-37; UnitShell): Position como entidad de primer nivel (`position_id, org_node_id, tipo, título, ocupación, requisitos de especialidad/credencial/competencia, dotación, vigencia`), Worker → Position → Assignment, subrogancia y delegación (§34-35), cobertura (§33). **No modificar los JSX visuales actuales** hasta que MAIN entregue los contratos P0 (propiedad por objeto).

**P6 · Participación voluntaria** (solo tras pasar G3 con MAIN y RADE): entidad **separada** de Worker/Employment; candidatura con id temporal **interno**; aptitud (apto/no apto/con restricciones + vigencia); asignaciones; documentos y firmas vía Document Engine; beneficios sin definir; CUV cuando MAIN lo emita. No inventar el identificador de alumnos/estancias formativas.

**P7 · Resto del Maestro §83:** salud ocupacional y accidentes, capacitaciones, evaluación de desempeño, bienestar y beneficios, reglamento interno y políticas, calendario institucional, Dashboard 40 / Workforce Analytics.

**P8 · Huecos conocidos:** formulario de **alta de trabajadores + contrato** (WorkforcePersonas); los 10 «honorarios» del roster figuran como `axon_core_lite` pero Honorarios los paga AXON → reclasificar al tocar el roster (y **sumarlo a las 9 copias a la vez**; `test_roster` lo exige); `roles.config.js` sin cruzar; AFC: el código usa **135,2 UF** (verificado de forma independiente; la revisión externa se contradecía) — sin acción.

**P9 · Validación jurídica (abogado):** tipo de día y plazos de K1, K2, K4; K3 (2 vs 5 días); inicio del cómputo de K2; aplicabilidad de la 21.431 al marketplace y piso de honorarios; voluntariado y sus beneficios; duelo por muerte de hijo (10 vs 7 días, Art. 66); Ley 19.451 (trasplantes) sin verificar.

**Decisiones que solo puede tomar el propietario:** estructura administrativa de RADE; beneficios de voluntarios; nomenclatura de la holding; identificador de alumnos/estancias formativas; si RADE necesita un identificador distinto para equipos.

---

## PARTE 9 · Patrones y disciplina de trabajo (mantener)

- **Puerta etiquetada:** cada archivo declara la forma exacta de lo que emitiría o consumiría, sin fingir conexión.
- **Registro canónico copiado, no importado**; `test_roster` verifica comportamiento idéntico en los 9 archivos. Cualquier cambio al roster se aplica a los 9.
- **Parámetro legal versionado:** artículo + fecha de verificación + fuente en el comentario; nunca constante sin origen.
- **Verificar en Node antes de entregar** (así aparecieron 8 bugs reales). Probar siempre en las 3 zonas horarias y con matriz de días de la semana + feriados.
- **No destructivo + auditoría:** versiones nuevas, nunca sobrescribir (§72); quién, qué, cuándo, antes/después, motivo (§45).
- **Estados separados por objeto** (solicitud, intervención, tarea, documento, comunicación, cargo).
- **Honestidad:** marcar `validada:false`, `provisional`, `inferido`; no presentar como regla legal lo que es interpretación.
- **Ningún nombre «AXON …» nuevo sin aprobación.**
- **Exportación:** un único zip ordenado con todos los archivos existentes (código, pruebas, informes, verificaciones, documentos de referencia, historial, índice); nunca entregas parciales. Verificarlo extrayéndolo y corriendo la suite (395 checks) antes de entregarlo.

---

## PARTE 10 · Inventario del paquete de export (un único zip ordenado)

```
AXON_Workforce_Export_COMPLETO_2026-10-27/
  00_LEEME_RETOMA.md                    ← este dossier (punto de entrada)
  00_INDICE.md                          ← índice de TODOS los archivos, con tamaño y descripción
  01_codigo_workforce/
    Workforce{Personas,Remuneraciones,Honorarios,TurnosAsistencia,LicenciasMedicas,
              VacacionesPermisos,EgresoFiniquito,Credenciales,CasosLaborales}.jsx
    tests/  test_*.mjs (10) · build_all.mjs · run_all.sh · README.md
  02_informes_para_MAIN/                ← v2.1 (vigente), v2, v1 (superada)
  03_verificaciones/                    ← mis.mjs · probar.mjs · cuv.mjs · package.json · LEEME.md
  04_documentos_de_referencia/          ← copias de los documentos del Proyecto + Estado Consolidado de MAIN del 23-oct
  05_historial_de_sesiones/             ← transcripciones completas de las sesiones + catálogo
  06_trabajo_interno/                   ← archivo original del 17-oct (Casos) y parches aplicados
```
Correr todo: `bash 01_codigo_workforce/tests/run_all.sh 01_codigo_workforce` → debe terminar con **TOTAL checks ok: 395** y las tres zonas horarias sin suites con falla.
