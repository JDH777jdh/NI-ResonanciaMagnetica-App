# Verificaciones de identificadores (reproducibles)

Requisito: Node 18+. Una sola vez: `npm install` (instala `crypto-js`).

| Script | Qué hace |
|---|---|
| `mis.mjs` | El `MasterIdentifierService.js` del 17-oct-2026 tal como llegó en `Para_workforce_respuestsa_17-10.docx`, extraído a un módulo ESM. **No es el motor vigente de MAIN** (MAIN ya lo corrigió; ver el estado consolidado del 23-oct). |
| `probar.mjs` | `node probar.mjs` — reproduce los hallazgos sobre ese motor: vectores §81 (N7, W4), relleno/truncamiento del código de tenant, dígitos aceptados, CUT de AXON Health que no pasa su validador (y `revocarCUT` que lanza), secuencia que desborda, CUIT Core = CUIT Core Lite, etiqueta FHIR «Employee Identifier». |
| `cuv.mjs` | `node cuv.mjs` — implementación de referencia **independiente** del CUV `CUV-{ISO2}-{REG}-AXONRADE-{SEQ6}-{CHK2}` con sus pruebas: vectores, 5.000 emisiones, cobertura de CHK2, 17 rechazos exigidos por la especificación, generador que lanza ante basura, convivencia con las otras familias y la colisión de la palabra `AXONRADE` como código de tenant. Debe terminar con **0 ❌**. |

`cuv.mjs` importa `mis.mjs` solo para el cálculo de CHK2 (SHA-256 → primer byte → letra+dígito). Cuando MAIN entregue la versión final del servicio, volver a correr `cuv.mjs` apuntándolo a ella y comparar los vectores.
