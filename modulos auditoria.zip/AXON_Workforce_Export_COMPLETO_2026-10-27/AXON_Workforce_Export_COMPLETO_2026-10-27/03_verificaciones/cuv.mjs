import * as N from './mis.mjs';

/* Propuesta de referencia — CUV-{ISO2}-{REG}-AXONRADE-{SEQ6}-{CHK2} */
export const CUV_REGEX = /^CUV-([A-Z]{2})-([A-Z0-9]{1,3})-AXONRADE-(\d{6})-([A-Z]\d)$/;
export const CUV_SEQ_MAX = 999999;
export function generarCUV({ paisISO2, regionCode, secuencia }) {
  if (!/^[A-Z]{2}$/.test(paisISO2 ?? '')) throw new Error('ISO2 inválido: exactamente 2 letras A-Z');
  if (!/^[A-Z0-9]{1,3}$/.test(regionCode ?? '')) throw new Error('REG inválido: 1 a 3 caracteres A-Z0-9');
  if (!Number.isInteger(secuencia) || secuencia < 1) throw new Error('SEQ inválida: entero >= 1');
  if (secuencia > CUV_SEQ_MAX) throw new Error('SEQ agotada para este ámbito: no se reutiliza ni se desborda');
  const base = `CUV-${paisISO2}-${regionCode}-AXONRADE-${String(secuencia).padStart(6, '0')}`;
  return `${base}-${N.calcularCheck2(base)}`;
}
export function validarCUV(v) {
  if (typeof v !== 'string') return { valido: false, codigo: 'FORMAT_INVALID' };
  const m = v.match(CUV_REGEX);
  if (!m) return { valido: false, codigo: 'FORMAT_INVALID' };
  const [, pais, region, seq, chk] = m;
  const base = v.slice(0, -(chk.length + 1));
  if (chk !== N.calcularCheck2(base)) return { valido: false, codigo: 'CHECKSUM_INVALID' };
  if (Number(seq) < 1) return { valido: false, codigo: 'SEMANTICALLY_INVALID' };
  return { valido: true, pais, region, secuencia: Number(seq) };
}

const t = (n, ok) => console.log((ok ? '✅ ' : '❌ ') + n);
console.log('--- vectores (ejemplos que MAIN puede fijar como test vectors) ---');
for (const [p, r, s] of [['CL','13',1],['CL','13',47],['CL','05',1],['CL','13',999999],['PE','15',1],['CL','XV',1]]) console.log(generarCUV({ paisISO2: p, regionCode: r, secuencia: s }));

console.log('\n--- ida y vuelta ---');
const v1 = generarCUV({ paisISO2: 'CL', regionCode: '13', secuencia: 47 });
t('generar → validar', validarCUV(v1).valido && validarCUV(v1).secuencia === 47);
let ok = true; for (let s = 1; s <= 5000; s++) { if (!validarCUV(generarCUV({ paisISO2: 'CL', regionCode: '13', secuencia: s })).valido) ok = false; } t('5.000 emisiones consecutivas validan', ok);
const chks = new Set(); for (let s = 1; s <= 20000; s++) chks.add(generarCUV({ paisISO2: 'CL', regionCode: '13', secuencia: s }).slice(-2)); t(`CHK2 usa ${chks.size} de 256 valores posibles en 20.000 emisiones`, chks.size > 200);

console.log('\n--- rechazos que exige la especificación (capas 1-5 y 77) ---');
const neg = [
  ['minúsculas', v1.toLowerCase(), 'FORMAT_INVALID'],
  ['separador "_"', v1.replace(/-/g, '_'), 'FORMAT_INVALID'],
  ['espacio final', v1 + ' ', 'FORMAT_INVALID'],
  ['espacio interno', v1.replace('AXONRADE-', 'AXONRADE- '), 'FORMAT_INVALID'],
  ['homoglifo cirílico (Х en lugar de X)', v1.replace('AXONRADE', 'A\u0425ONRADE'), 'FORMAT_INVALID'],
  ['guion Unicode (‑)', v1.replace('CUV-', 'CUV\u2011'), 'FORMAT_INVALID'],
  ['segmento de 7 letras (AXONRAD)', v1.replace('AXONRADE', 'AXONRAD'), 'FORMAT_INVALID'],
  ['otro código de 8 letras (AXONRESC)', v1.replace('AXONRADE', 'AXONRESC'), 'FORMAT_INVALID'],
  ['SEQ de 5 dígitos', v1.replace('-000047-', '-00047-'), 'FORMAT_INVALID'],
  ['SEQ de 7 dígitos', v1.replace('-000047-', '-0000047-'), 'FORMAT_INVALID'],
  ['checksum alterado', v1.slice(0, -1) + ((Number(v1.slice(-1)) + 1) % 10), 'CHECKSUM_INVALID'],
  ['checksum hexadecimal legacy (89)', v1.slice(0, -2) + '89', 'FORMAT_INVALID'],
  ['checksum reservado Z6', v1.slice(0, -2) + 'Z6', 'CHECKSUM_INVALID'],
  ['REG vacío', 'CUV-CL--AXONRADE-000047-' + N.calcularCheck2('CUV-CL--AXONRADE-000047'), 'FORMAT_INVALID'],
  ['REG de 4 caracteres', 'CUV-CL-1234-AXONRADE-000047-' + N.calcularCheck2('CUV-CL-1234-AXONRADE-000047'), 'FORMAT_INVALID'],
  ['SEQ 000000 (no se emite)', 'CUV-CL-13-AXONRADE-000000-' + N.calcularCheck2('CUV-CL-13-AXONRADE-000000'), 'SEMANTICALLY_INVALID'],
  ['prefijo CUT con el mismo cuerpo', v1.replace('CUV-', 'CUT-'), 'FORMAT_INVALID'],
];
for (const [n, val, esperado] of neg) { const r = validarCUV(val); t(`${n} → ${r.codigo || 'valido'}`, !r.valido && r.codigo === esperado); }

console.log('\n--- el generador rechaza basura (el actual la acepta, verificado) ---');
for (const [n, a] of [['SEQ 0', { paisISO2: 'CL', regionCode: '13', secuencia: 0 }], ['SEQ 1.000.000 (desborde)', { paisISO2: 'CL', regionCode: '13', secuencia: 1000000 }], ['SEQ -1', { paisISO2: 'CL', regionCode: '13', secuencia: -1 }], ['SEQ "abc"', { paisISO2: 'CL', regionCode: '13', secuencia: 'abc' }], ['ISO2 "chile"', { paisISO2: 'chile', regionCode: '13', secuencia: 1 }], ['REG "13a4"', { paisISO2: 'CL', regionCode: '13a4', secuencia: 1 }]]) { let lanzo = false; try { generarCUV(a); } catch { lanzo = true; } t(`lanza error con ${n}`, lanzo); }

console.log('\n--- convivencia con las otras familias (sin ambigüedad de tipo) ---');
const otros = [N.generarCUP({ paisISO2: 'CL', regionCode: '13', secuencia: 47, anio: 2026 }), N.generarCUT({ paisISO2: 'CL', regionCode: '13', tenantCode: 'CLIMEDSA', secuencia: 1 }), N.generarCUTAxon({ paisISO2: 'CL', regionCode: '13', secuencia: 1 }), N.generarCUITAxon({ paisISO2: 'CL', regionCode: '13', secuencia: 1 }), N.generarCUC({ paisISO2: 'CL', regionCode: '13', tenantCode: 'CLIMEDSA', secuencia: 1, anio: 2026 }), N.generarCUPRN({ paisISO2: 'CL', regionCode: '13', secuencia: 1, anio: 2026 }), N.generarCUPNN({ paisISO2: 'CL', regionCode: '13', secuencia: 1, anio: 2026 })];
t('ningún identificador de otra familia valida como CUV', otros.every((x) => !validarCUV(x).valido));
t('el CUV no valida como ninguna otra familia', [N.validarCUP, N.validarCUT, N.validarCUC, N.validarCUPRN, N.validarCUPNN].every((f) => !f(v1).valido));
const colision = N.generarCUT({ paisISO2: 'CL', regionCode: '13', tenantCode: 'AXONRADE', secuencia: 1 });
t(`"AXONRADE" como código de tenant produce un CUT válido (${colision}) → hay que reservar la palabra`, N.validarCUT(colision).valido);
