import CryptoJS from "crypto-js";

// ────────────────────────────────────────────────────────────────

// § 1 · CHK2 — ALGORITMO DEFINITIVO

//   value = letterIndex*10 + digit, A=0..Z=25 → 260 combinaciones,

//   de las cuales 256 son alcanzables por un byte (0-255): A0..Y9

//   cubren 0-249, Z0..Z5 cubren 250-255. Z6-Z9 son formalmente

//   "reservados" porque ningún byte los produce — si aparecen,

//   el valor no vino de este algoritmo.

//   Ejemplo verificado contra el propio documento: byte 0x89 (137

//   decimal) → 137/10=13 ("N", A=0..N=13), 137%10=7 → "N7".

// ────────────────────────────────────────────────────────────────

function encode256(byteValue) {

  const letterIndex = Math.floor(byteValue / 10);

  const digit = byteValue % 10;

  return `${String.fromCharCode(65 + letterIndex)}${digit}`;

}

function decode256(chk2) {

  const letter = chk2.charCodeAt(0) - 65;

  const digit = Number(chk2[1]);

  return letter * 10 + digit;

}

/** CHK2 — dígito verificador vigente (letra+dígito) para cualquier base de texto. */

export function calcularCheck2(base) {

  const hashHex = CryptoJS.SHA256(base).toString();

  const primerByte = parseInt(hashHex.substring(0, 2), 16);

  return encode256(primerByte);

}

/** Legacy — el calcularCheck() original de cup.js (2 chars hex). Solo para

 * validar/decodificar identificadores ya emitidos antes de CHK2-V1. Nunca

 * usar para generar identificadores nuevos. */

function calcularCheckLegacyHex(base) {

  return CryptoJS.SHA256(base).toString().substring(0, 2).toUpperCase();

}

/** Arma "{segmentos}-{CHK2}" — helper interno, no exportado, para no repetir

 * el mismo join+checksum en cada generador. */

function construirId(segmentos) {

  const base = segmentos.join("-");

  return `${base}-${calcularCheck2(base)}`;

}

// ────────────────────────────────────────────────────────────────

// § 2 · CUP (Paciente) — mismo formato de segmentos, CHK2 nuevo

//   CUP-{ISO2}-{REG}-{AÑO}-{SEQ8}-{CHK2}

// ────────────────────────────────────────────────────────────────

export function generarCUP({ paisISO2, regionCode, secuencia, anio = new Date().getFullYear() }) {

  const pais = String(paisISO2).toUpperCase();

  const reg = String(regionCode).toUpperCase();

  const seq = String(secuencia).padStart(8, "0");

  return construirId(["CUP", pais, reg, String(anio), seq]);

}

// ────────────────────────────────────────────────────────────────

// § 3 · CUT (Trabajador de Tenant) — CAMBIA de formato

//   Antes: CUT-{ISO2}-{REG}-{CLINICA4}-{SEQ8}-{CHK2}

//   Ahora: CUT-{ISO2}-{REG}-{TENANT8}-{SEQ4}-{CHK2}

// ────────────────────────────────────────────────────────────────

export function generarCUT({ paisISO2, regionCode, tenantCode, secuencia }) {

  const pais = String(paisISO2).toUpperCase();

  const reg = String(regionCode).toUpperCase();

  const tenant = String(tenantCode).toUpperCase().padEnd(8, "X").slice(0, 8);

  const seq = String(secuencia).padStart(4, "0");

  return construirId(["CUT", pais, reg, tenant, seq]);

}

// ────────────────────────────────────────────────────────────────

// § 4 · CUC (Convenio/Club de Tenant) — mismo formato, CHK2 nuevo

//   CUC-{ISO2}-{REG}-{TENANT8}-{AÑO}-{SEQ3}-{CHK2}

// ────────────────────────────────────────────────────────────────

export function generarCUC({ paisISO2, regionCode, tenantCode, secuencia, anio = new Date().getFullYear() }) {

  const pais = String(paisISO2).toUpperCase();

  const reg = String(regionCode).toUpperCase();

  const tenant = String(tenantCode).toUpperCase().padEnd(8, "X").slice(0, 8);

  const seq = String(secuencia).padStart(3, "0");

  return construirId(["CUC", pais, reg, tenant, String(anio), seq]);

}

// ────────────────────────────────────────────────────────────────

// § 5 · CUP-RN (Recién Nacido) — mismo formato, CHK2 nuevo

//   CUP-RN-{ISO2}-{REG}-{AÑO}-{SEQ8}-{CHK2} · caduca en 75 días

// ────────────────────────────────────────────────────────────────

export function generarCUPRN({ paisISO2, regionCode, secuencia, anio = new Date().getFullYear() }) {

  const pais = String(paisISO2).toUpperCase();

  const reg = String(regionCode).toUpperCase();

  const seq = String(secuencia).padStart(8, "0");

  return construirId(["CUP-RN", pais, reg, String(anio), seq]);

}

// ────────────────────────────────────────────────────────────────

// § 6 · CUP-NN (No Name) — CAMBIA de modelo, no solo de formato

//   Antes: NN-{AAMMDD}-{SEXO}-{SEQ2}, local por tenant/día, sin CHK2

//   Ahora: CUP-NN-{ISO2}-{REG}-{AÑO}-{SEQ8}-{CHK2}, correlativo

//   coordinado igual que CUP — sin fecha ni sexo en el código

//   (privacidad por diseño). `secuencia` ya no reinicia cada día:

//   viene del mismo contador atómico que usaría un CUP normal.

// ────────────────────────────────────────────────────────────────

export function generarCUPNN({ paisISO2, regionCode, secuencia, anio = new Date().getFullYear() }) {

  const pais = String(paisISO2).toUpperCase();

  const reg = String(regionCode).toUpperCase();

  const seq = String(secuencia).padStart(8, "0");

  return construirId(["CUP-NN", pais, reg, String(anio), seq]);

}

/** Legacy — el generarCUPNN() original de cup.js (NN-{AAMMDD}-{SEXO}-{SEQ2},

 * sin CHK2). Se conserva para decodificar/referenciar códigos NN ya emitidos

 * antes de este cambio — no usar para generar identificadores nuevos. */

export function generarCUPNNLegacy({ fecha = new Date(), sexoAparente, correlativoDelDia }) {

  const yy = String(fecha.getFullYear()).slice(-2);

  const mm = String(fecha.getMonth() + 1).padStart(2, "0");

  const dd = String(fecha.getDate()).padStart(2, "0");

  const seq = String(correlativoDelDia).padStart(2, "0");

  return `NN-${yy}${mm}${dd}-${sexoAparente}-${seq}`;

}

export function decodificarCUPNNLegacy(cupNN) {

  const m = cupNN.match(/^NN-(\d{2})(\d{2})(\d{2})-([MFX])-(\d{2})$/);

  if (!m) return null;

  const [, yy, mm, dd, sexo, seq] = m;

  return { fechaIngreso: `20${yy}-${mm}-${dd}`, sexoAparente: sexo, correlativoDelDia: parseInt(seq), esTemporal: true };

}

// ────────────────────────────────────────────────────────────────

// § 7 · LOS 10 IDENTIFICADORES NUEVOS — sin generador hasta hoy

// ────────────────────────────────────────────────────────────────

/** CUT-AXON-ADM — trabajador administrativo de AXON Holding (staff de

 * plataforma, no clínico). Formato: CUT-AXON-ADM-{ISO2}-{SEQ4}-{CHK2} */

export function generarCUTAxonAdm({ paisISO2, secuencia }) {

  const pais = String(paisISO2).toUpperCase();

  const seq = String(secuencia).padStart(4, "0");

  return construirId(["CUT-AXON-ADM", pais, seq]);

}

/** CUT-AXON-WLD — tenant digital de administración AXON World.

 * Formato: CUT-AXON-WLD-{ISO2}-{REG}-{SEQ4}-{CHK2} */

export function generarCUTAxonWld({ paisISO2, regionCode, secuencia }) {

  const pais = String(paisISO2).toUpperCase();

  const reg = String(regionCode).toUpperCase();

  const seq = String(secuencia).padStart(4, "0");

  return construirId(["CUT-AXON-WLD", pais, reg, seq]);

}

/** CUTG-AXON-WLD — trabajador (persona) de administración AXON World.

 * Formato: CUTG-AXON-WLD-{ISO2}-{REG}-{SEQ4}-{CHK2} */

export function generarCUTGAxonWld({ paisISO2, regionCode, secuencia }) {

  const pais = String(paisISO2).toUpperCase();

  const reg = String(regionCode).toUpperCase();

  const seq = String(secuencia).padStart(4, "0");

  return construirId(["CUTG-AXON-WLD", pais, reg, seq]);

}

/** CUT-AXON-CTRY — tenant digital de administración AXON Country.

 * Formato: CUT-AXON-CTRY-{ISO2}-{REG}-{SEQ4}-{CHK2} */

export function generarCUTAxonCtry({ paisISO2, regionCode, secuencia }) {

  const pais = String(paisISO2).toUpperCase();

  const reg = String(regionCode).toUpperCase();

  const seq = String(secuencia).padStart(4, "0");

  return construirId(["CUT-AXON-CTRY", pais, reg, seq]);

}

/** CUTG-AXON-CTRY — trabajador (persona) de administración AXON Country.

 * Formato: CUTG-AXON-CTRY-{ISO2}-{REG}-{SEQ4}-{CHK2} */

export function generarCUTGAxonCtry({ paisISO2, regionCode, secuencia }) {

  const pais = String(paisISO2).toUpperCase();

  const reg = String(regionCode).toUpperCase();

  const seq = String(secuencia).padStart(4, "0");

  return construirId(["CUTG-AXON-CTRY", pais, reg, seq]);

}

/** CUIT-AXON — AXON Health como institución digital propia (código "AXON"

 * fijo, no un tenant8 variable). Formato: CUIT-{ISO2}-{REG}-AXON-{SEQ4}-{CHK2} */

export function generarCUITAxon({ paisISO2, regionCode, secuencia }) {

  const pais = String(paisISO2).toUpperCase();

  const reg = String(regionCode).toUpperCase();

  const seq = String(secuencia).padStart(4, "0");

  return construirId(["CUIT", pais, reg, "AXON", seq]);

}

/** CUT-AXON — trabajador propio de AXON Health (staff clínico/operativo,

 * no de plataforma). Formato: CUT-{ISO2}-{REG}-AXON-{SEQ4}-{CHK2} */

export function generarCUTAxon({ paisISO2, regionCode, secuencia }) {

  const pais = String(paisISO2).toUpperCase();

  const reg = String(regionCode).toUpperCase();

  const seq = String(secuencia).padStart(4, "0");

  return construirId(["CUT", pais, reg, "AXON", seq]);

}

/** CUC-AXON — convenio/club a nivel AXON Health (no de un tenant Core

 * individual). Formato: CUC-AXON-{ISO2}-{REG}-{CORP8}-{AÑO}-{SEQ4}-{CHK2} */

export function generarCUCAxon({ paisISO2, regionCode, corpCode, secuencia, anio = new Date().getFullYear() }) {

  const pais = String(paisISO2).toUpperCase();

  const reg = String(regionCode).toUpperCase();

  const corp = String(corpCode).toUpperCase().padEnd(8, "X").slice(0, 8);

  const seq = String(secuencia).padStart(4, "0");

  return construirId(["CUC-AXON", pais, reg, corp, String(anio), seq]);

}

/** CUIT AXON Core — institución cliente Core. Mismo string que CUIT AXON

 * Core Lite (el propio documento lo advierte: se distinguen por metadata

 * `identifier_type`, no por la forma del código). Formato:

 * CUIT-{ISO2}-{REG}-{TENANT8}-{SEQ4}-{CHK2} */

export function generarCUITAxonCore({ paisISO2, regionCode, tenantCode, secuencia }) {

  const pais = String(paisISO2).toUpperCase();

  const reg = String(regionCode).toUpperCase();

  const tenant = String(tenantCode).toUpperCase().padEnd(8, "X").slice(0, 8);

  const seq = String(secuencia).padStart(4, "0");

  return construirId(["CUIT", pais, reg, tenant, seq]);

}

/** CUIT AXON Core Lite — profesional independiente. Mismo string que CUIT

 * AXON Core — ver nota de `generarCUITAxonCore`. Quien llama es responsable

 * de guardar `identifier_type: "CUIT_CORE_LITE"` junto al valor. */

export function generarCUITAxonCoreLite({ paisISO2, regionCode, tenantCode, secuencia }) {

  const pais = String(paisISO2).toUpperCase();

  const reg = String(regionCode).toUpperCase();

  const tenant = String(tenantCode).toUpperCase().padEnd(8, "X").slice(0, 8);

  const seq = String(secuencia).padStart(4, "0");

  return construirId(["CUIT", pais, reg, tenant, seq]);

}

// ────────────────────────────────────────────────────────────────

// § 8 · VALIDACIÓN — actualizada a CHK2 para los 5 identificadores

// ya en uso real (CUP/CUT/CUC/CUP-RN + el CUP-NN nuevo). Para los

// 10 identificadores de plataforma nuevos, `validarGenerico()` es

// funcional para cualquiera de ellos (recibe su propio regex),

// pero no tienen todavía un `validarXxx()` de nombre propio — se

// agregan cuando el primero de ellos entre en uso real, mismo

// criterio que ya se aplicó en cup.js ("no construir antes de

// tiempo lo que nadie llama todavía").

// ────────────────────────────────────────────────────────────────

const CUP_REGEX = /^CUP-([A-Z]{2})-([A-Z0-9]{1,3})-(\d{4})-(\d{8})-([A-Z]\d)$/;

const CUT_REGEX = /^CUT-([A-Z]{2})-([A-Z0-9]{1,3})-([A-Z0-9]{8})-(\d{4})-([A-Z]\d)$/;

const CUC_REGEX = /^CUC-([A-Z]{2})-([A-Z0-9]{1,3})-([A-Z0-9]{8})-(\d{4})-(\d{3})-([A-Z]\d)$/;

const CUP_RN_REGEX = /^CUP-RN-([A-Z]{2})-([A-Z0-9]{1,3})-(\d{4})-(\d{8})-([A-Z]\d)$/;

const CUP_NN_REGEX = /^CUP-NN-([A-Z]{2})-([A-Z0-9]{1,3})-(\d{4})-(\d{8})-([A-Z]\d)$/;

export function validarCUP(cup) {

  if (!cup || typeof cup !== "string") return { valido: false, error: "CUP vacío" };

  const m = cup.match(CUP_REGEX);

  if (!m) return { valido: false, error: "Formato CUP inválido" };

  const [, pais, region, anio, seq, checkRecibido] = m;

  const checkEsperado = calcularCheck2(`CUP-${pais}-${region}-${anio}-${seq}`);

  if (checkRecibido !== checkEsperado) return { valido: false, error: "Dígito verificador inválido" };

  return { valido: true, pais, region, anio: parseInt(anio), secuencia: parseInt(seq) };

}

export function validarCUT(cut) {

  if (!cut || typeof cut !== "string") return { valido: false, error: "CUT vacío" };

  const m = cut.match(CUT_REGEX);

  if (!m) return { valido: false, error: "Formato CUT inválido" };

  const [, pais, region, tenant, seq, checkRecibido] = m;

  const checkEsperado = calcularCheck2(`CUT-${pais}-${region}-${tenant}-${seq}`);

  if (checkRecibido !== checkEsperado) return { valido: false, error: "Dígito verificador inválido" };

  return { valido: true, pais, region, tenant, secuencia: parseInt(seq) };

}

export function validarCUC(cuc) {

  const m = String(cuc).match(CUC_REGEX);

  if (!m) return { valido: false, error: "Formato CUC inválido" };

  const [, pais, region, tenant, anio, seq, checkRecibido] = m;

  const checkEsperado = calcularCheck2(`CUC-${pais}-${region}-${tenant}-${anio}-${seq}`);

  if (checkRecibido !== checkEsperado) return { valido: false, error: "Dígito verificador inválido" };

  return { valido: true, pais, region, tenant, anio: parseInt(anio), secuencia: parseInt(seq) };

}

export function validarCUPRN(cup) {

  const m = String(cup).match(CUP_RN_REGEX);

  if (!m) return { valido: false, error: "Formato CUP-RN inválido" };

  const [, pais, region, anio, seq, checkRecibido] = m;

  const checkEsperado = calcularCheck2(`CUP-RN-${pais}-${region}-${anio}-${seq}`);

  if (checkRecibido !== checkEsperado) return { valido: false, error: "Dígito verificador inválido" };

  return { valido: true, pais, region, anio: parseInt(anio), secuencia: parseInt(seq) };

}

export function validarCUPNN(cup) {

  const m = String(cup).match(CUP_NN_REGEX);

  if (!m) return { valido: false, error: "Formato CUP-NN inválido" };

  const [, pais, region, anio, seq, checkRecibido] = m;

  const checkEsperado = calcularCheck2(`CUP-NN-${pais}-${region}-${anio}-${seq}`);

  if (checkRecibido !== checkEsperado) return { valido: false, error: "Dígito verificador inválido" };

  return { valido: true, pais, region, anio: parseInt(anio), secuencia: parseInt(seq) };

}

/** Validador genérico — sirve para cualquiera de los 15 mientras no tenga

 * un validarXxx() de nombre propio: recibe el regex del formato (con el

 * CHK2 como último grupo) y valida estructura + checksum en un solo paso. */

export function validarGenerico(valor, regex) {

  const m = String(valor).match(regex);

  if (!m) return { valido: false, error: "Formato inválido" };

  const checkRecibido = m[m.length - 1];

  const base = String(valor).slice(0, -(checkRecibido.length + 1)); // quita "-{CHK2}"

  const checkEsperado = calcularCheck2(base);

  if (checkRecibido !== checkEsperado) return { valido: false, error: "Dígito verificador inválido" };

  return { valido: true };

}

export function decodificarCUP(cup) {

  const r = validarCUP(cup);

  if (!r.valido) return null;

  return { cup, ...r, antiguedadAnios: new Date().getFullYear() - r.anio };

}

export function decodificarCUT(cut) {

  const r = validarCUT(cut);

  if (!r.valido) return null;

  return { cut, ...r };

}

/**

 * Características descriptivas — reemplaza la idea de geolocalización.

 * Mismo objetivo (ayudar a identificar/reunir con familia), sin

 * vigilancia de ubicación ni complejidad de stack geoespacial.

 */

export const CARACTERISTICAS_DESCRIPTIVAS_SCHEMA = {

  rangoEdadAparente:   "string — ej. '30-40 años'",

  alturaAproximada:    "string — ej. '1.70-1.75m'",

  senasParticulares:   "string — cicatrices, tatuajes, marcas distintivas",

  vestimentaIngreso:   "string — descripción de la ropa al momento de ingresar",

  objetosPersonales:   "string — pertenencias encontradas con el paciente",

  fotoUrl:             "string | null — foto de ingreso, solo bajo protocolo/consentimiento del tenant",

  registradoPor:       "string CUT",

};

// ────────────────────────────────────────────────────────────────

// § 9 · CICLO DE VIDA DEL CUT (revocación sin tocar el CUP)

//   Sin cambios respecto de cup.js — ver security.config.js →

//   IDENTITY_SCHEMA.LIFECYCLE_RULES

// ────────────────────────────────────────────────────────────────

/**

 * Revoca el CUT de una persona (renuncia/despido) SIN alterar su CUP

 * ni su historial clínico. Retorna el objeto de auditoría a persistir.

 */

export function revocarCUT(cut, motivo, revocadoPor) {

  const decoded = decodificarCUT(cut);

  if (!decoded) throw new Error("CUT inválido, no se puede revocar");

  return {

    cut,

    cutActivo:        false,

    cutRevokedAt:     new Date().toISOString(),

    cutRevokedReason: motivo,

    revocadoPor,

  };

}

// ────────────────────────────────────────────────────────────────

// § 10 · REGISTRO DE FALLECIMIENTO (archiva sin eliminar)

//   Sin cambios respecto de cup.js.

// ────────────────────────────────────────────────────────────────

export function registrarDefuncion({ cup, fechaDefuncion, causaBasica, certificadoNumero, registradoPor }) {

  const decoded = decodificarCUP(cup);

  if (!decoded) throw new Error("CUP inválido, no se puede registrar defunción");

  return {

    cup,

    fallecido:            true,

    fechaDefuncion,

    causaBasica:          causaBasica || null,

    certificadoNumero:    certificadoNumero || null,

    registradoPor,

    fichaArchivada:       true,

    fichaArchivadaEn:     new Date().toISOString(),

    bloqueoEscritura:     "permanente",

    fhir: { deceasedDateTime: fechaDefuncion, active: false },

  };

}

export function fichaEstaArchivada(personaRecord) {

  return personaRecord?.fallecido === true && personaRecord?.bloqueoEscritura === "permanente";

}

export const MENSAJE_BLOQUEO_FALLECIDO = "CUP ARCHIVADO POR FALLECIMIENTO, VERIFICAR DATOS";

export function verificarAccesoOBloquear(personaRecord) {

  if (fichaEstaArchivada(personaRecord)) {

    throw new Error(MENSAJE_BLOQUEO_FALLECIDO);

  }

  return { permitido: true };

}

export function calcularPrioridad(datoPaciente) {

  const { fechaNacimiento, condicionesPrioritarias = [], puntajeTriage = 0 } = datoPaciente;

  let nivel = 0;

  const razones = [];

  if (fechaNacimiento) {

    const edad = calcularEdad(fechaNacimiento);

    if (edad >= 80)      { nivel = Math.max(nivel, 3); razones.push(`Adulto mayor ${edad} años`); }

    else if (edad >= 60) { nivel = Math.max(nivel, 2); razones.push(`Adulto mayor ${edad} años`); }

    else if (edad <= 12) { nivel = Math.max(nivel, 2); razones.push(`Menor de edad ${edad} años`); }

  }

  const condMap = { embarazada:3, discapacidad:2, oncologico:3, dialisis:3, cardiovascular:2, mental:2 };

  condicionesPrioritarias.forEach(c => {

    if (condMap[c]) { nivel = Math.max(nivel, condMap[c]); razones.push(c); }

  });

  if (puntajeTriage === 1) { nivel = Math.max(nivel, 4); razones.push("Triage Rojo"); }

  if (puntajeTriage === 2) { nivel = Math.max(nivel, 3); razones.push("Triage Naranja"); }

  return {

    esPrioritario: nivel >= 2,

    nivel,

    razones,

    etiqueta: ["Normal","Preferente","Prioritario","Alta Prioridad","Crítico"][nivel] || "Normal",

    color:    ["#78909C","#2196F3","#FF8F00","#F44336","#9C27B0"][nivel] || "#78909C",

  };

}

// ────────────────────────────────────────────────────────────────

// § 11 · FHIR IDENTIFIERS — sin cambios respecto de cup.js

// ────────────────────────────────────────────────────────────────

export function cupAFHIRIdentifier(cup) {

  return {

    use: "official",

    type: { coding: [{ system:"http://terminology.hl7.org/CodeSystem/v2-0203", code:"MR", display:"Medical Record Number" }] },

    system: "https://axon-clinical.global/cup",

    value: cup,

  };

}

export function cutAFHIRIdentifier(cut) {

  return {

    use: "official",

    type: { coding: [{ system:"http://terminology.hl7.org/CodeSystem/v2-0203", code:"EI", display:"Employee Identifier" }] },

    system: "https://axon-clinical.global/cut",

    value: cut,

  };

}

export function rutAFHIRIdentifier(rut, paisISO2 = "CL") {

  return {

    use: "official",

    type: { coding: [{ system:"http://terminology.hl7.org/CodeSystem/v2-0203", code:"NNxxx", display:`National ID ${paisISO2}` }] },

    system: `https://axon-clinical.global/national-id/${paisISO2.toLowerCase()}`,

    value: rut,

  };

}

// ────────────────────────────────────────────────────────────────

// § 12 · HELPERS GENERALES (RUT chileno — extensible por país)

//   Sin cambios respecto de cup.js.

// ────────────────────────────────────────────────────────────────

export function calcularEdad(fechaNacimiento) {

  const hoy = new Date();

  const nac = new Date(fechaNacimiento);

  let edad = hoy.getFullYear() - nac.getFullYear();

  const m = hoy.getMonth() - nac.getMonth();

  if (m < 0 || (m === 0 && hoy.getDate() < nac.getDate())) edad--;

  return edad;

}

export function formatearRUT(rut) {

  const clean = String(rut).replace(/[^0-9kK]/g, "").toUpperCase();

  if (clean.length < 2) return clean;

  const cuerpo = clean.slice(0, -1);

  const dv = clean.slice(-1);

  const formateado = cuerpo.replace(/\B(?=(\d{3})+(?!\d))/g, ".");

  return `${formateado}-${dv}`;

}

export function validarRUT(rut) {

  const clean = String(rut).replace(/[^0-9kK]/g, "").toLowerCase();

  if (clean.length < 2) return false;

  const cuerpo = clean.slice(0, -1);

  const dvInput = clean.slice(-1);

  let suma = 0, mult = 2;

  for (let i = cuerpo.length - 1; i >= 0; i--) {

    suma += parseInt(cuerpo[i]) * mult;

    mult = mult === 7 ? 2 : mult + 1;

  }

  const dvCalc = 11 - (suma % 11);

  const dvEsp = dvCalc === 11 ? "0" : dvCalc === 10 ? "k" : String(dvCalc);

  return dvInput === dvEsp;

}

export default {

  // CHK2

  calcularCheck2,

  // Generadores — ya en uso real

  generarCUP, generarCUT, generarCUC, generarCUPRN, generarCUPNN,

  // Generadores — legacy (decodificación/compatibilidad)

  generarCUPNNLegacy, decodificarCUPNNLegacy,

  // Generadores — 10 nuevos de plataforma AXON

  generarCUTAxonAdm, generarCUTAxonWld, generarCUTGAxonWld,

  generarCUTAxonCtry, generarCUTGAxonCtry, generarCUITAxon, generarCUTAxon,

  generarCUCAxon, generarCUITAxonCore, generarCUITAxonCoreLite,

  // Validación / decodificación

  validarCUP, validarCUT, validarCUC, validarCUPRN, validarCUPNN, validarGenerico,

  decodificarCUP, decodificarCUT,

  // Ciclo de vida e identidad

  revocarCUT, registrarDefuncion, fichaEstaArchivada, verificarAccesoOBloquear, MENSAJE_BLOQUEO_FALLECIDO,

  calcularPrioridad,

  // FHIR

  cupAFHIRIdentifier, cutAFHIRIdentifier, rutAFHIRIdentifier,

  // Helpers generales

  calcularEdad, formatearRUT, validarRUT,

};

