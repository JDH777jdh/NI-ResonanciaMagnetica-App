import M from './mis.mjs';
import * as N from './mis.mjs';
const log = (t, v) => console.log(t.padEnd(62), typeof v === 'string' ? v : JSON.stringify(v));

// 1. vectores oficiales de la especificación (§81)
log('CHK2 CUP-CL-13-2026-00000047 (esperado N7)', N.calcularCheck2('CUP-CL-13-2026-00000047'));
log('CHK2 CUP-NN-CL-13-2026-00000001 (esperado W4)', N.calcularCheck2('CUP-NN-CL-13-2026-00000001'));

// 2. código de tenant: ¿relleno/truncamiento silencioso? ¿acepta dígitos?
const base = { paisISO2: 'CL', regionCode: '13', secuencia: 1 };
log('generarCUT tenant "SALUD" (5 letras)', N.generarCUT({ ...base, tenantCode: 'SALUD' }));
log('generarCUT tenant "SALUDMEDICO" (10 letras)', N.generarCUT({ ...base, tenantCode: 'SALUDMEDICO' }));
const conDigito = N.generarCUT({ ...base, tenantCode: 'RESCATE1' });
log('generarCUT tenant "RESCATE1" (con dígito)', conDigito);
log('validarCUT acepta el que lleva dígito', N.validarCUT(conDigito));

// 3. CUT de AXON Health: ¿pasa por el validador genérico? ¿se puede revocar?
const cutHealth = N.generarCUTAxon({ ...base });
log('generarCUTAxon', cutHealth);
log('validarCUT(CUT AXON Health)', N.validarCUT(cutHealth));
log('decodificarCUT(CUT AXON Health)', N.decodificarCUT(cutHealth));
try { N.revocarCUT(cutHealth, 'prueba', 'x'); log('revocarCUT(CUT AXON Health)', 'OK'); } catch (e) { log('revocarCUT(CUT AXON Health) lanza', e.message); }

// 4. desborde de secuencia: SEQ4 llega a 9999; ¿qué pasa con 10000?
const s9999 = N.generarCUT({ ...base, tenantCode: 'CLIMEDSA', secuencia: 9999 });
const s10000 = N.generarCUT({ ...base, tenantCode: 'CLIMEDSA', secuencia: 10000 });
log('generarCUT secuencia 9999', s9999);
log('generarCUT secuencia 10000 (5 dígitos)', s10000);
log('validarCUT(secuencia 10000)', N.validarCUT(s10000));
log('generarCUP secuencia 100000000 (9 dígitos)', N.generarCUP({ ...base, secuencia: 100000000 }));
log('validarCUP(secuencia 100000000)', N.validarCUP(N.generarCUP({ ...base, secuencia: 100000000 })));
log('generarCUT secuencia -1', N.generarCUT({ ...base, tenantCode: 'CLIMEDSA', secuencia: -1 }));
log('generarCUT secuencia "abc"', N.generarCUT({ ...base, tenantCode: 'CLIMEDSA', secuencia: 'abc' }));

// 5. CUIT Core vs Core Lite: ¿misma cadena?
const a = N.generarCUITAxonCore({ ...base, tenantCode: 'DRSMITHX' });
const b = N.generarCUITAxonCoreLite({ ...base, tenantCode: 'DRSMITHX' });
log('CUIT Core', a); log('CUIT Core Lite', b); log('¿idénticos?', a === b);

// 6. etiqueta FHIR del CUT
log('cutAFHIRIdentifier.type.coding[0].display', N.cutAFHIRIdentifier(conDigito).type.coding[0].display);

// 7. ¿existen CUV o validadores de los 10 identificadores nuevos?
log('exporta generarCUV / validarCUV', [typeof N.generarCUV, typeof N.validarCUV]);
log('validadores propios de CUT-AXON-ADM/WLD/CTRY, CUIT, CUC-AXON', [typeof N.validarCUTAxonAdm, typeof N.validarCUIT, typeof N.validarCUCAxon]);
