# AXON · Export completo de Workforce — 2026-10-27

Un solo zip con **todos los archivos existentes**, ordenados. **Empieza por `00_LEEME_RETOMA.md`.** (60 archivos)

## Cómo está ordenado

| Carpeta | Qué contiene |
|---|---|
| `00_LEEME_RETOMA.md` | Dossier v2: estado, decisiones del propietario, pendientes priorizados, cómo retomar |
| `01_codigo_workforce/` | Las 9 secciones `.jsx` + `tests/` (10 suites, **395 checks**) |
| `02_informes_para_MAIN/` | Lo enviado a MAIN: v2.1 (vigente), v2, v1 (superada) |
| `03_verificaciones/` | Scripts reproducibles sobre identificadores (motor del 17-oct y CUV) |
| `04_documentos_de_referencia/` | Copias de los documentos del Proyecto + Estado consolidado de MAIN del 23-oct |
| `05_historial_de_sesiones/` | Transcripciones completas de las sesiones |
| `06_trabajo_interno/` | Archivo original del 17-oct y parches aplicados |

## Verificar que todo está sano

Requisitos: Node 18+ e internet (instala `esbuild`). Desde la raíz del zip extraído:

    bash 01_codigo_workforce/tests/run_all.sh 01_codigo_workforce

Debe terminar con **TOTAL checks ok: 395** y, en las líneas `TZ=America/Santiago` y `TZ=Pacific/Auckland`, ninguna suite con falla.

## Qué subir al Proyecto antes de abrir el chat nuevo

1. `01_codigo_workforce/Workforce*.jsx` (los 9: **CasosLaborales es nuevo**; Credenciales, LicenciasMedicas, VacacionesPermisos y EgresoFiniquito cambiaron) y `01_codigo_workforce/tests/*` (reemplazan el `README.md` y `build_all.mjs` antiguos del Proyecto).
2. `00_LEEME_RETOMA.md` (dossier v2).
3. `04_documentos_de_referencia/workforce/AXON_MAIN_Workforce_Estado_Consolidado__2026-10-23_VIGENTE.md`.
4. `02_informes_para_MAIN/*` (v2.1 vigente).
El resto ya está en el Proyecto.

## Notas

- Los `.docx` del Proyecto son **texto plano con extensión .docx** (así los entrega el panel del Proyecto); se abren con cualquier editor de texto.
- Renombrados para evitar confusión: el Estado consolidado del 23-oct llegó como `…Estado_Consolidado (2).md`; el del 9-oct y el dossier del 11-sep llevan el sufijo `_anterior`.
- No incluidos por estar **superados**: el `README.md` y `build_all.mjs` del Proyecto, y las versiones antiguas de Credenciales, LicenciasMedicas, VacacionesPermisos y EgresoFiniquito (y sus `test_*`): las vigentes están en `01_codigo_workforce/`.

## Listado completo

| Archivo | Tamaño | Descripción |
|---|---:|---|
| `00_LEEME_RETOMA.md` | 34.5 KB | Dossier técnico y retoma de sesión v2 (27-oct-2026): estado, decisiones del propietario, pendientes priorizados. EMPEZAR AQUÍ. |
| `01_codigo_workforce/WorkforceCasosLaborales.jsx` | 108.2 KB | 9 · Casos laborales: Ley Karin y convivencia (flujo A-F, ramas, relojes, reserva) — NUEVO |
| `01_codigo_workforce/WorkforceCredenciales.jsx` | 51.5 KB | 8 · Credenciales versionadas, aptitud para la función y alertas de vencimiento |
| `01_codigo_workforce/WorkforceEgresoFiniquito.jsx` | 25.4 KB | 7 · Egreso y finiquito (Art. 162, 163 y 163 bis) |
| `01_codigo_workforce/WorkforceHonorarios.jsx` | 35.7 KB | 3 · Honorarios: BHE con retención 15,25 % / factura con IVA |
| `01_codigo_workforce/WorkforceLicenciasMedicas.jsx` | 53.3 KB | 5 · Licencias médicas (recepción): plazos, carencia, alertas, apelación |
| `01_codigo_workforce/WorkforcePersonas.jsx` | 26.6 KB | 1 · Registro canónico (30 personas: 20 empleados + 10 honorarios) y CUT provisional |
| `01_codigo_workforce/WorkforceRemuneraciones.jsx` | 55.2 KB | 2 · Liquidaciones (AFP, salud, AFC, impuesto único, gratificación, horas extra pactables) |
| `01_codigo_workforce/WorkforceTurnosAsistencia.jsx` | 37.7 KB | 4 · Turnos, asistencia, horas extra y déficit |
| `01_codigo_workforce/WorkforceVacacionesPermisos.jsx` | 39.9 KB | 6 · Feriado legal, progresivo y permisos especiales |
| `01_codigo_workforce/tests/README.md` | 1.5 KB | Cómo correr las pruebas |
| `01_codigo_workforce/tests/build_all.mjs` | 1.6 KB | Bundlea los 9 .jsx para poder probar sus funciones puras |
| `01_codigo_workforce/tests/run_all.sh` | 3.0 KB | Reconstruye el entorno y corre las 395 pruebas en UTC, America/Santiago y Pacific/Auckland |
| `01_codigo_workforce/tests/test_casos.mjs` | 40.6 KB | Pruebas de casos (127 checks) |
| `01_codigo_workforce/tests/test_credenciales.mjs` | 18.6 KB | Pruebas de credenciales (106 checks) |
| `01_codigo_workforce/tests/test_finiquito.mjs` | 3.4 KB | Pruebas de finiquito (18 checks) |
| `01_codigo_workforce/tests/test_honorarios.mjs` | 2.0 KB | Pruebas de honorarios (14 checks) |
| `01_codigo_workforce/tests/test_licencias.mjs` | 9.9 KB | Pruebas de licencias (47 checks) |
| `01_codigo_workforce/tests/test_personas.mjs` | 2.7 KB | Pruebas de personas (18 checks) |
| `01_codigo_workforce/tests/test_remuneraciones.mjs` | 4.4 KB | Pruebas de remuneraciones (19 checks) |
| `01_codigo_workforce/tests/test_roster.mjs` | 1.9 KB | Pruebas de roster (3 checks) |
| `01_codigo_workforce/tests/test_turnos.mjs` | 3.3 KB | Pruebas de turnos (18 checks) |
| `01_codigo_workforce/tests/test_vacaciones.mjs` | 4.3 KB | Pruebas de vacaciones (25 checks) |
| `02_informes_para_MAIN/AXON_Workforce_Actualizacion_para_MAIN_v2.1_2026-10-14.md` | 14.6 KB | VIGENTE · actualización de decisiones y dependencias para MAIN |
| `02_informes_para_MAIN/AXON_Workforce_Respuestas_para_MAIN_Verificacion_2026-10-09.md` | 15.4 KB | v1 · SUPERADA (verificación del 9-oct) |
| `02_informes_para_MAIN/AXON_Workforce_Respuestas_para_MAIN_v2_2026-10-14.md` | 26.7 KB | Versión anterior (v2) de las respuestas para MAIN |
| `03_verificaciones/LEEME.md` | 1.3 KB | Cómo reproducir las verificaciones de identificadores (npm install + node) |
| `03_verificaciones/cuv.mjs` | 5.8 KB | Referencia independiente del CUV con sus pruebas (debe terminar con 0 ❌) |
| `03_verificaciones/mis.mjs` | 25.8 KB | MasterIdentifierService del 17-oct extraído a ESM (no es el motor vigente de MAIN) |
| `03_verificaciones/package.json` | 0.1 KB | Dependencia mínima (crypto-js) |
| `03_verificaciones/probar.mjs` | 2.8 KB | Hallazgos sobre el motor del 17-oct (vectores, relleno del tenant, CUT de Health, FHIR) |
| `04_documentos_de_referencia/main_y_otros_dominios/AXON_Archivo_Lineas_AXON_Monetizacion_Cobros_Pagos.md` | 7.0 KB | Documento del Proyecto: MAIN, Contabilidad, Imagenología, monetización u otros dominios |
| `04_documentos_de_referencia/main_y_otros_dominios/AXON_Archivo_Lineas_AXON_Monetizacion_Cobros_Pagos__1_.md` | 10.0 KB | Documento del Proyecto: MAIN, Contabilidad, Imagenología, monetización u otros dominios |
| `04_documentos_de_referencia/main_y_otros_dominios/AXON_CLINICAL_ADVANCE_HOSPITAL_DIGITAL_ENTERPRISE__LINEAS_DE_AXON_Y_SUS_PROPUESTAS_ORGANIZACIONALES_DE_MONETIZACIONES_COBROS_Y_PAGOS.pdf` | 77.6 KB | Tabla fuente de monetización de las líneas AXON (PDF original) |
| `04_documentos_de_referencia/main_y_otros_dominios/AXON_Contabilidad_Dossier_Tecnico_y_Sincronizacion_MAIN__4_.md` | 38.8 KB | Documento del Proyecto: MAIN, Contabilidad, Imagenología, monetización u otros dominios |
| `04_documentos_de_referencia/main_y_otros_dominios/AXON_Contabilidad_Plan_de_Trabajo_Ordenado.md` | 10.3 KB | Documento del Proyecto: MAIN, Contabilidad, Imagenología, monetización u otros dominios |
| `04_documentos_de_referencia/main_y_otros_dominios/AXON_Hoja_de_Ruta_Backend_Addendum_Mapa_de_Dominios_2026-09-01__5_.md` | 13.5 KB | Documento del Proyecto: MAIN, Contabilidad, Imagenología, monetización u otros dominios |
| `04_documentos_de_referencia/main_y_otros_dominios/AXON_MAIN_Modelo_120_Familias_Analisis_2026-09-02__2_.md` | 6.1 KB | Documento del Proyecto: MAIN, Contabilidad, Imagenología, monetización u otros dominios |
| `04_documentos_de_referencia/main_y_otros_dominios/AXON_MAIN_Retoma_Sesion_2026-09-01__3_.md` | 9.7 KB | Documento del Proyecto: MAIN, Contabilidad, Imagenología, monetización u otros dominios |
| `04_documentos_de_referencia/main_y_otros_dominios/AtencionAgendaImagenologia__2_.jsx` | 217.6 KB | Documento del Proyecto: MAIN, Contabilidad, Imagenología, monetización u otros dominios |
| `04_documentos_de_referencia/main_y_otros_dominios/ContabilidadIngresos__3_.jsx` | 58.4 KB | Documento del Proyecto: MAIN, Contabilidad, Imagenología, monetización u otros dominios |
| `04_documentos_de_referencia/unitshell_identificadores_investigacion/AXON_-_Investigacion__simulación_y_docencia.docx` | 160.8 KB | Documento de referencia: UnitShell, identificadores o investigación/docencia |
| `04_documentos_de_referencia/unitshell_identificadores_investigacion/AXON_Identificadores_Universales_v1_0.docx` | 62.1 KB | Documento de referencia: UnitShell, identificadores o investigación/docencia |
| `04_documentos_de_referencia/unitshell_identificadores_investigacion/Informe_Tecnico_UnitShell_Guia_MAIN_v1.docx` | 65.6 KB | Documento de referencia: UnitShell, identificadores o investigación/docencia |
| `04_documentos_de_referencia/workforce/AXON_MAIN_Workforce_Estado_Consolidado__2026-10-09_anterior.md` | 8.9 KB | Versión anterior del Estado consolidado de MAIN (9-oct) |
| `04_documentos_de_referencia/workforce/AXON_MAIN_Workforce_Estado_Consolidado__2026-10-23_VIGENTE.md` | 56.7 KB | Estado consolidado de MAIN sobre Workforce, 23-oct-2026 (VIGENTE; era «Estado_Consolidado (2)») |
| `04_documentos_de_referencia/workforce/AXON_Workforce_Dossier_Tecnico_y_Retoma_Sesion__2026-09-11_anterior.md` | 26.9 KB | Dossier del 11-sep (vigente solo en sus Partes 2, 3, 6, 7 y 11; ver 00_LEEME_RETOMA.md) |
| `04_documentos_de_referencia/workforce/Documento_Maestro_de_Arquitectura_Workforce.docx` | 46.3 KB | Documento Maestro de Workforce (§1-84): la especificación que rige todo |
| `04_documentos_de_referencia/workforce/Para_workforce_respuestsa_17-10.docx` | 53.2 KB | Documento de referencia de Workforce / respuestas y revisiones de MAIN |
| `04_documentos_de_referencia/workforce/Respuesta_para_workforce_de_MAIN__GPT_sin_ClaudeD_.docx` | 25.6 KB | Documento de referencia de Workforce / respuestas y revisiones de MAIN |
| `04_documentos_de_referencia/workforce/Revision_md_de_workforce_para_main__gpt_.docx` | 40.2 KB | Documento de referencia de Workforce / respuestas y revisiones de MAIN |
| `04_documentos_de_referencia/workforce/para_WORKFORCE_-_UnitShell.docx` | 92.0 KB | Documento de referencia de Workforce / respuestas y revisiones de MAIN |
| `05_historial_de_sesiones/2026-10-13-17-27-03-axon-workforce-credenciales-ley-karin.txt` | 707.4 KB | Sesión 13-oct: Credenciales y Ley Karin |
| `05_historial_de_sesiones/2026-10-17-19-43-58-axon-workforce-casos-laborales-main-docs.txt` | 454.7 KB | Transcripción completa de sesión (Casos laborales y documentos de MAIN) |
| `05_historial_de_sesiones/2026-10-28-08-49-00-axon-workforce-casos-laborales-cuv-main-docs.txt` | 788.7 KB | Transcripción completa de sesión |
| `05_historial_de_sesiones/journal.txt` | 1.5 KB | Catálogo de transcripciones |
| `06_trabajo_interno/Casos_original_17oct.jsx` | 93.3 KB | WorkforceCasosLaborales.jsx tal como llegó el 17-oct (con el marcador @@ROSTER@@), base de la revisión |
| `06_trabajo_interno/patch/patch_casos.py` | 26.5 KB | Parche aplicado durante la sesión (referencia) |
| `06_trabajo_interno/patch/patch_casos2.py` | 13.6 KB | Parche aplicado durante la sesión (referencia) |
| `00_INDICE.md` | — | Este índice |
