# AXON MAIN — Hoja de Ruta Backend · Addendum: Mapa de Dominios
## 01-09-2026 · Preparación para recibir los módulos satélite leídos — solo mapeo, ningún código tocado todavía

---

## 0 · De dónde partimos, sin inventar nada

Lo real hoy, según `AXON_Hoja_de_Ruta_Backend_MAIN.md` (Fase 0, sin cambios desde entonces):

- `01-init.sql` tiene **10 tablas**, todas en un único esquema `core` (todavía no schema-per-tenant): facturas cifradas, roles_activos, categorías/órdenes de compra, valores×2, convenios×4.
- `CoreAdapter` (`index.js`) tiene **3 endpoints reales**: `GET /facturas/:id`, `POST /ordenes-compra/:ocId/factura`, `GET /health`. El resto son 501 o arrays vacíos.
- `DatabaseService.js` ya tiene el seam de abstracción (Fhir/Core/Mock Adapter) armado.
- **Fase 1** (cerrar un loop real con Convenios+CUC) sigue **pausada a pedido tuyo explícito** — nada de esto la reactiva.
- **Fase 3** (completar CoreAdapter + organizar por dominio) ya estaba prevista, con 5 carpetas candidatas: `facturas/`, `convenios/`, `roles/`, `valores/`, `modulos/`.

Lo que sigue es exactamente eso, Fase 3, pero puesto al día con los ~10 documentos de arquitectura satélite que llegaron después y que esa lista de 5 carpetas ya no cubre. **Es mapeo, no implementación** — no toca `01-init.sql` ni `index.js` reales.

---

## 1 · Dominios nuevos que hay que sumar al mapa

Ninguno de estos existe hoy en `01-init.sql`. La columna "entidades" no las inventé — son las que cada documento satélite ya propuso, para no reinventarlas dos veces.

| Dominio | Carpeta candidata en CoreAdapter | Entidades ya diseñadas por el satélite | Grupo de tablas candidato | Documento fuente |
|---|---|---|---|---|
| Finanzas / Contabilidad | `finance/` | `FinancialEntity`, `Journal`, `GLAccount`, `BudgetAccount`, `Period`, `AuditEvent` — con **Budget Ledger y General Ledger separados a propósito** | `core.finance_*` | Account Core — SIGFE Baseline + Consolidado SICOGEN (2 docs) |
| RRHH / Workforce | `workforce/` | `Person`, `Worker`, `Employment`, `Contract`, `Credential`, `Leave`, `Payroll`, `Case/Investigation` | `core.workforce_*` | Documento Maestro Workforce |
| AIMS (activos e infraestructura) | `aims/` | `Asset`, `Site`, `Building`, `Space`, `Network`, `Sensor`, `WorkOrder` | `core.aims_*` | AIMS Documento Maestro vFinal |
| Documentos (motor transversal) | `documents/` | `Document`, `DocumentType`, `Template`, `DocumentProfile`, `Verification` | `core.documents_*` | Documento Maestro de Arquitectura (Document Core) |
| Agenda / trazabilidad de Slot-Appointment | `scheduling/` | `Slot`, `Occupancy`, `Appointment`, event trail causal | `core.scheduling_*` | Arquitectura de Trazabilidad de Scheduling |
| Farmacia y Bodega | `supply/` | Stock/solicitud/recepción ya construidos en el prototipo; el documento "AXON Supply Core" les pone nombre (`SupplyNode`, `SupplyEvent`) — **ese nombre específico no está aprobado por ti todavía**, lo uso solo como referencia | `core.supply_*` | Dossier de Estado Farmacia/Bodega |
| Identidad de paciente transversal (AXON ID) | probablemente servicio propio, no `CoreAdapter` puro | `AXON ID` como capa de autenticación, separada de CUP (autorización sigue por tenant) | tabla de identidad + SSO, no `core.*` | Doc de Identidad/Portales/Interoperabilidad |
| Ficha Clínica (modelo canónico) | va al lado de `FhirAdapter`, no `CoreAdapter` | `Patient`, `Encounter`, `Observation`, `Condition`, `AllergyIntolerance`, `Medication`, `Procedure`... | esquema `fhir`, no `core` | Especificación Maestra de la Ficha Clínica Digital |

**Motor DICOM** y **Portal Paciente** quedan fuera de esta tabla a propósito — ya tienen su propio proceso/servicio (Motor DICOM corre aparte, con su propio `WorklistApiServer`; Portal Paciente consume servicios, no tiene tablas propias nuevas que yo haya visto).

---

## 2 · Un patrón que se repite en 6 de estos documentos — vale la pena resolverlo una sola vez

Contabilidad, Workforce, AIMS, Document Core, y en menor medida Farmacia y DICOM: **todos** proponen lo mismo — "mi dominio hace algo, y eso debe emitir un evento que otro dominio consume" (`PayrollCalculated` → Contabilidad, `PROCEDURE_COMPLETED` del motor DICOM → cobro, `DocumentIssued` → auditoría, etc.).

Esto ya estaba decidido en la Fase 5 de la hoja de ruta (Kafka particionado por CUP), pero Kafka es la **última** fase, y ya hay 5+ dominios pidiendo este patrón **ahora**, antes de llegar ahí. Una opción intermedia, sin construir Kafka todavía: una tabla simple `core.domain_events` (id, tipo, dominio_origen, payload jsonb, tenant_id, creado_en) que sirva de bandeja de eventos mínima mientras no exista el bus real — mismo espíritu que ya usa el proyecto con "puerta etiquetada" (`iomt.config.js`, `ia_integraciones.config.js`). No es una decisión tomada, es la pregunta que dejo abierta en la sección 4.

---

## 3 · Lo que estos documentos piden que NO es solo "dale backend a lo que ya existe"

Vale la pena decirlo explícito: Contabilidad (con Account Core) y el motor documental (Document Core) no piden simplemente conectar pantallas ya construidas — piden que MAIN **adopte motores transversales completamente nuevos** que hoy no existen ni como propuesta en la hoja de ruta. Ninguno de los dos está adoptado todavía, a diferencia de `standards.config.js`/`iomt.config.js` que sí pasaron por ese proceso formal en agosto.

---

## 4 · Lo que no toco sin que confirmes

- Si "Document Core" se evalúa como motor real nuevo, o se archiva como propuesta.
- Si "Account Core" (la versión ampliada tipo SIGFE) reemplaza el plan original de `CoreAdapter` para finanzas, o convive con él.
- El nombre `AXON Supply Core` — sigue sin aprobación tuya, lo dejé fuera de las carpetas candidatas por eso.
- Cualquier cambio real a `01-init.sql` o `index.js` — esto sigue siendo solo el mapa.
- Si la tabla `core.domain_events` de la sección 2 se construye ahora como puente temporal, o se espera a la Fase 5 real.

---

## 5 · Por dónde partir — tres candidatos, no elijo yo

1. **Elegir un dominio y dibujar su esquema real** (DDL de verdad, no solo el grupo de tablas) — el más pedido y con más preguntas explícitas esperando respuesta es Contabilidad/Account Core (16 puntos entre sus 3 documentos).
2. **Resolver primero la pregunta de la sección 2** (tabla puente de eventos sí/no) — desbloquea a varios dominios a la vez en vez de a uno solo.
3. **Evaluar formalmente Document Core** — es la propuesta más grande y más nueva (29-ago), y toca a todos los demás dominios de refilón (todos generan documentos/PDF).

---

## 6 · Las 75 sugerencias de `Informe_Maestro_Ciberseguridad_Arquitectura_Proyecto_Salud.docx` — evaluadas una por una

El archivo real en `/mnt/project` está dañado (pandoc no pudo abrirlo — mismo problema de corrupción de binarios que ya reportó el equipo DICOM con `.dcm`/`.pdf` al pasar por el panel de archivos del proyecto). Lo evalué igual con el texto completo que ya tenía cargado del documento. Si en algún momento necesitas la versión real de ese `.docx` de vuelta en el proyecto, probablemente convenga volver a subirlo directo a un mensaje del chat, no por el panel — es lo que le funcionó al equipo DICOM.

**No se puede aplicar los 75 de una vez — ni tendría sentido.** Varios dependen unos de otros (no hay Zero Trust real sin IAM real; no hay SIEM sin que exista algo corriendo que loguear). Los agrupé por si están listos para avanzar ya, o por qué fase de la hoja de ruta actual los desbloquea.

### A · Ya cubiertos en diseño — falta aplicarlos, no diseñarlos

| # | Control | Dónde ya está diseñado |
|---|---|---|
| 06 | RBAC | `roles.config.js` completo (169 roles reales) |
| 07 | ABAC/PBAC | El Master Authorization Model que estamos revisando ahora mismo |
| 09 | Session Security | `security.config.js` → `session` (JWT 480min, refresh 7d, 1 sesión concurrente, política de contraseña) |
| 10/11 | Tenant Isolation / RLS | `AXON_MAIN_Dossier_Tecnico_Consolidado.md` §2, con SQL de ejemplo (`app.current_tenant_id`) |
| 27 | Encryption in transit | `nginx.conf` ya fuerza TLS 1.3 + HSTS + redirect 80→443 |
| 28/29 | Encryption at rest / field-level | `pgp_sym_encrypt` ya en uso real en `core.facturas` (folio/monto cifrados) — patrón probado, falta replicarlo |
| 30 | Audit trail | `security.config.js` → `audit.criticalEvents` (lista extensa) + `retentionDays: 5475` |
| 37 | Network segmentation | `docker-compose.yml` ya aísla Postgres en red `axon_internal`, sin puerto expuesto al host |
| 38 | Microsegmentation IoMT | `iomt.config.js` → `GATEWAY_IOMT`, diseñado como única puerta, hoy `construida_inactiva` |
| 58 | Privacy engineering | Seudonimización/anonimización ya diseñada para Country/World, Fase 7 de esta misma hoja de ruta |
| 65 | Medical record integrity | Especificación de Ficha Clínica Digital, principio "no sobrescribir historia" ya está en el diseño |

### B · Listos para adoptar ya, sin esperar ninguna fase

Bajo esfuerzo, no dependen de Keycloak/K8s/CI-CD real:

| # | Control | Por qué se puede ahora |
|---|---|---|
| 02 | Threat Modeling | Es documentación, no código — se puede hacer por dominio a medida que se diseña cada uno |
| 18 | Rate limiting | Middleware simple sobre los 3 endpoints reales que ya tiene `CoreAdapter` |
| 19 | API inventory | Documentar lo poco que existe hoy, antes de que crezca sin registro |
| 20 | Schema validation | Validación de request/response en `index.js`, no requiere infraestructura nueva |
| 39 | Container hardening | El `Dockerfile` actual corre como root por defecto (no tiene `USER`) — agregar usuario no-root es un cambio de una línea |
| 51 | Incident Response | El propio informe ya trae 7 playbooks (IR-01 a IR-07) listos para adoptar como documento |

### C · Bloqueados por una fase que todavía no llega — se activan solos cuando lleguemos ahí

| Fase de la hoja de ruta | Controles que desbloquea |
|---|---|
| **Fase 2 — Keycloak real** | 04 IAM, 05 MFA resistente a phishing (el diseño de qué roles la necesitan ya existe en `security.config.js`), 08 Step-up auth |
| **Fase 3 — Completar CoreAdapter** | 12 Object-level auth, 13 Property-level auth, 14 Function-level auth, 15 Sensitive business-flow protection, 16 API Gateway, 72 Secure admin plane |
| **Fase 4 — FHIR real** | 60 FHIR/API security (bloqueado literal por `FhirAdapter._token()`, que hoy lanza error a propósito) |
| **Fase 5 — Eventos/NID Bridge** | 22 Third-party API security, 73 Data exfiltration controls (para lo que salga hacia MINSAL) |
| **Fase 6 — Kubernetes** | 40 Kubernetes security, 49 Runtime vulnerability management, 71 Immutable infrastructure |
| **Cuando exista backend con más de 3 endpoints reales** | 67 Secure file handling (hoy varios módulos ni guardan el archivo todavía, solo el nombre) |
| **Cuando exista Account Core/RCM real** (sección 1 de este mismo documento) | 63/64 Account Core segregation/tamper controls — ya identificados como gap por Contabilidad, no es hallazgo nuevo |
| **Cuando exista motor de consentimiento real** | 61 Clinical consent security |
| **Cuando exista módulo de telemedicina real** | 62 Telemedicine security |
| **Cuando exista pipeline de build** | 49 (parcial), 71 (parcial) |

### D · El gap más grande de los 75 — no depende de ninguna fase clínica, es puro y no existe nada todavía

**41 al 48, y el 75** (SAST, SCA, secret scanning, SBOM, artifact signing, build provenance, protected source, secure CI/CD, security testing gates) — hoy no hay ningún pipeline de CI/CD en el proyecto, ni siquiera uno simple. Esto no compite con las fases clínicas/de negocio — es infraestructura de desarrollo pura, se puede construir en paralelo sin tocar `CoreAdapter` ni esperar a Keycloak. Es candidato fuerte para ser el primer bloque de seguridad que se cierra completo, precisamente porque no bloquea ni lo bloquea nada del resto.

También sin nada construido, pero si dependen de tener algo corriendo primero: **31** (audit inmutable de verdad — hoy `immutable:true` es solo una bandera de configuración, no un mecanismo real), **32/33/34/36** (SIEM/UEBA/DLP/EDR), **50** (backup real — hoy `pgdata` es un volumen local sin respaldo), **57** (PAM/JIT), **70** (observabilidad).

### E · Prematuros — esperan a que exista lo que protegen

| # | Control | Por qué esperar |
|---|---|---|
| 35 | Deception (honeypots) | No tiene sentido sin producción real que proteger |
| 53/55 | Pentest / DAST | Nada en producción todavía |
| 74 | AI security | `ia_integraciones.config.js` sigue con todo en modo `"reglas"` o `"inactivo"`, sin proveedor de IA conectado |

### F · Necesitan tu decisión, no son solo técnicas

| # | Control | La decisión real |
|---|---|---|
| 01 | Gobernanza de ciberseguridad | ¿Quién es el owner formal? (`axon_owner` ya es "único con acceso real al código" según `roles.config.js`, pero formalizar comité/RACI es decisión tuya) |
| 25 | HSM | Elegir proveedor, mismo tipo de decisión que el sellado de tiempo pendiente de Fase 5 |
| 23/24 | Secrets Manager / KMS | Vault vs. equivalente cloud — el propio `_env.example` ya avisa que esto viene, falta elegir con qué |

### Resumen — 75 en 6 grupos

A (ya diseñados, falta aplicar): 11 · B (listos ya, sin esperar nada): 6 · C (esperan una fase ya planificada): ~14 · D (gap puro, sin nada construido): ~14 · E (prematuros): 3 · F (necesitan tu decisión): 3. El resto (~24) quedó repartido dentro de C/D según a qué fase o pieza específica se amarra — no los repetí en tabla aparte para no inflar esto, pero cada uno de los 75 quedó clasificado en alguno de los 6 grupos de arriba.

