# AXON Contabilidad — Plan de Trabajo Ordenado
## De lo simple-necesario a lo complejo, cada fase alimentada por la anterior

**Fecha:** 2026-09-08 · **Reestructurado desde Fase 3** tras recibir 2 auditorías externas (~70 hallazgos combinados) y la tabla maestra de monetización de las 8 líneas AXON. **Criterio de orden:** no es "fácil primero, difícil después" a secas — es **lo que desbloquea a los demás primero**, aunque sea trabajo de síntesis y no de código, y **lo bloqueado externamente al final**, aunque sea conceptualmente simple, porque no depende de nosotros.

---

## FASE 0 — Unificar antes de seguir construyendo (síntesis, cero código) ✅ COMPLETA Y CONGELADA (2026-09-04)

**Por qué va primero:** teníamos 6 documentos de Account Core que se fueron superponiendo y evolucionando. Cualquier cosa construida sin unificar esto primero corría el riesgo de contradecir alguno de los seis.

1. ✅ **Documento de Arquitectura Consolidada Definitiva** — 3 tensiones resueltas (10° subledger, 5 perfiles, nomenclatura Radar).
2. ✅ **Contrato único de Financial Event** (JSON) — con §6.1 (Financial Event → Journal Mapping) agregado tras revisión externa.
3. ✅ **Shape de `TaxResult`** — definido.
4. ✅ **Etiquetar 2.1 / 2.8 / 2.11 del dossier como "legacy/transicional"**.

**Confirmación externa (2026-09-04):** "coherente... está llegando al punto correcto para congelarlo como Fase 0."

---

## FASE 1 — Arreglos aislados de bajo riesgo ✅ COMPLETA (2026-09-04)

5. ✅ **`centroCosto` agregado a `ContabilidadHonorariosExternos.jsx`**.
6. ✅ **`fakeRUT`/`calcDV` y `semaforo()` consolidados** en `ContabilidadHelpersCompartidos.js`.

---

## FASE 2 — Conectar lo nuevo con lo que ya existe ✅ COMPLETA (2026-09-04)

7. ✅ **Tax Determination Engine** (`determinarImpuesto`) — envuelve la lógica ya verificada, devuelve `TaxResult`.
8. ✅ **Agreement Engine mínimo** (`resolverConvenio`) — `agreementId` técnico separado del `cuc` de negocio.

**Hallazgo extra resuelto fuera de fase (2026-09-05):** KPI "DSO" mal calculado (medía Billing Lag, no DSO real) — corregido, renombrado a `diasParaFacturar`.

---

## FASE 3 — Fundamentos transversales que todo lo demás necesita (REESTRUCTURADA 2026-09-08)

**Por qué cambia de contenido:** las 2 auditorías externas (`Informe_Auditoria_Correcciones.md`, `Respuestas_3_Completo.md`) convergen, de forma independiente, en que faltan **dos conceptos que casi todo lo demás va a consumir**. Construir Payer/RCM o Payment Orchestration antes de esto obligaría a reconstruirlos después — por eso se adelantan a esta fase, delante de lo que originalmente iba acá.

9. **Counterparty** — concepto unificador (`Payer · Customer · Supplier · Professional · Institution · Sponsor · GovernmentEntity · Bank · TaxAuthority`) para no seguir escribiendo `isapreNombre || convenioNombre || paciente || PAGADOR_LABEL[pagador]` (patrón confirmado como riesgo real en Ingresos Y Facturación, por 3 fuentes independientes).
10. **Charge como entidad propia** — hoy una fila de Ingresos mezcla Charge+Invoice+Payment+Revenue en un solo registro. Separar a `Charge` (el hecho de cobro) como entidad independiente de `Payment` (el hecho de pago) y `Revenue Recognition` (el reconocimiento contable).
11. **PatientFinancialAccount mínimo** — vista consolidada por paciente (hoy no existe ningún lugar que junte Encounter/Charges/Prepayments/Créditos de una misma persona).

---

## FASE 4 — Payer & Revenue Cycle real (depende de Fase 3)

**Por qué va acá:** con Counterparty y Charge ya existiendo, formalizar Fonasa/Isapre/Mutual deja de requerir inventar su propio modelo de contraparte.

12. **Claim / Adjudication** — hoy no existe forma de modelar que un asegurador apruebe solo una parte de lo cobrado (`Charge=100.000, Approved=75.000` → falta política de qué pasa con los $25.000: Patient / Write-off / Appeal).
13. **Payer/Coverage/Agreement formalizados sobre Counterparty** — límite duro ya definido: RCM gestiona el estado del reclamo, Account Core lleva la matemática de la deuda (CxC), RCM nunca lleva balances.
14. **Corrección de `condicionIVA`/exención**: la Circular 50/2022 aclara que la naturaleza ambulatoria/hospitalaria depende de alojamiento, alimentación y tratamiento continuo — "urgencias siempre exento" no es correcto en todos los casos. Requiere más contexto que solo `unidad` (conecta con el Tax Determination Engine de Fase 2, ampliándolo).

---

## FASE 5 — Payment Orchestration + PaymentPurpose (depende de Fase 3-4)

**Grounding real confirmado 2026-09-08:** la tabla de las 8 líneas AXON usa literalmente columnas **"Setup Fee & Exit"** y **"HaaS"** — `PaymentPurpose` no es una abstracción de arquitectura, es el modelo de negocio real.

15. **Payment Orchestration mínimo** — formaliza lo disperso hoy entre Conciliación Bancaria y Flujo de Caja, con Canal/Rail/Instrumento como tres ejes separados.
16. **`PaymentPurpose` explícito** — `PATIENT_SERVICE · PATIENT_PREPAYMENT · PATIENT_COPAY · INSTITUTIONAL_CONTRACT · SAAS · SETUP · EXIT · HAAS · TAKE_RATE · OTHER`. Conecta Contabilidad con el modelo comercial de AXON mismo (cobro a tenants), no solo con el paciente.

---

## FASE 6 — Dominios de prepago (dependen de Charge/Counterparty ya existentes)

17. **Prepayments & Stored Value** (Anticipo/Depósito/Crédito de cliente).
18. **Gift Cards** (programa/emisión/activación/saldo/canje/vencimiento) — separado de Prepayments.
19. **Loyalty & Benefits** — con el hallazgo de NIIF 15: la *emisión* de puntos también genera un Financial Event de pasivo diferido, no solo el canje.
20. **Financial Preauthorization** — una cita con prepago/garantía no reconoce ingreso automáticamente (`Appointment → Prepayment/Guarantee → servicio ocurre → recién ahí Charge real`).
21. **No-show como evento financiero potencial, no automático** — depende de una `Billing Policy` explícita del Agreement, la Agenda no decide sola que existe deuda.

---

## FASE 7 — Financial Allocation versionado (depende de Fases 4-6)

**Por qué va acá y no antes:** necesita que Payer/RCM (Fase 4) y los dominios de prepago (Fase 6) ya existan para tener algo real que asignar entre financiadores.

22. **Financial Allocation Engine** (`Allocation v1 → v2 → v3`, nunca destructivo) — reactivo a eventos económicos amplios (adjudicación, corrección de tarifa, cambio de cobertura, anulación, nota de crédito, cambio de beneficiario, devolución, corrección administrativa, cambio de pagador, reversa de pago), no solo a cambios de estado de RCM.
23. **Corrección de copago/bonificación** — los % fijos por pagador (`PARAMS_COPAGO_PCT`) son ilustrativos; un convenio real puede cubrir 100% o dejar copago variable. Reemplazo: `coverage = min(tariff × coveragePercent, benefitRemaining, benefitCap)`.

---

## FASE 8 — Procurement y el corte real de Adquisiciones (depende de Fase 3, aprovecha Fases 4-5)

24. **Procurement Commitment + 3-way match formalizado** — Compromiso presupuestario como entidad propia (crítico para tenants públicos), separado de Devengo y Pago.
25. **Corte real de Adquisiciones en 3 dominios** (Supply Core / AIMS / Account Core) — ya aprobado por Aleaxon; ejecutarlo bien requiere que Charge, Counterparty y Payment Orchestration ya estén estables, porque Adquisiciones toca varios de esos dominios a la vez.

---

## FASE 9 — Controles transversales (necesitan dominios reales para controlar)

26. **Compensatory Event Framework** — 10 tipos distintos (`Cancellation · Correction · Reversal · Credit Note · Debit Note · Refund · Chargeback · Reclassification · Write-off · Adjustment`), nunca borrar.
27. **Maker/Checker + política PBAC real** (RBAC+ABAC+SoD) para Conciliación Bancaria — resuelve la brecha de segregación de funciones que arrastramos desde el dossier original.
28. **Estados por dominio** (`ClinicalStatus, RCMStatus, AllocationStatus, PaymentStatus, SettlementStatus, ReconciliationStatus, AccountingStatus, TaxStatus`) reemplazando cualquier campo único `estado`.
29. **Correcciones menores acumuladas de las auditorías:** `exentoPct` debe medir % de monto, no % de transacciones · `totalPeriodo` debe distinguir Gross Charges/Net Revenue/Contractual Adjustments/Bad Debt · el folio de documento tributario no debe simularse dentro de Ingresos (es dueño Facturación).

---

## FASE 10 — Lo más complejo, con mayor dependencia interna

30. **Cierre Contable, Auditorías y Balance Anual** (sección 2.13) — depende de que las 12 secciones y varios de los motores nuevos existan primero. Sigue bloqueada externamente además (ver abajo).

---

## En paralelo — bloqueado externamente, no depende de nuestra secuencia

| Pendiente | Espera a |
|---|---|
| Modelo público/privado de Balances (NIIF vs. NICSP-CGR) | Investigación activa de Aleaxon |
| Fecha exacta de vigencia de Resolución N°1/2026 CGR | Confirmación de Aleaxon en LeyChile |
| Catálogo real 85+1 roles en Honorarios Médicos | `roles.config.js` de MAIN + decisión Matrona/Matrón |
| Clasificación regulatoria del Wallet (Ley Fintech) | Validación legal — sigue como hipótesis |
| `Hoja1` vs. `Tipos Tenant` como fuente de verdad | Aleaxon, junto con PBAC+RBAC+TenantType |
| Aprobación de MAIN sobre Account Core (lista completa) | Revisión de MAIN — Contabilidad ya aprobó su parte |
| Monetización de AXON Country y AXON World | No están en la tabla maestra de líneas — sin fuente propia todavía |

---

## Resumen visual de la lógica de dependencia

```
FASE 0 (unificar) ──► FASE 1 (aislados, en paralelo) ──► FASE 2 (Tax+Agreement)
   ──► FASE 3 (Counterparty + Charge + PatientFinancialAccount)
   ──► FASE 4 (Payer/RCM real) ──► FASE 5 (Payment Orchestration + PaymentPurpose)
   ──► FASE 6 (Prepago/GiftCard/Loyalty/Preauth) ──► FASE 7 (Allocation versionado)
   ──► FASE 8 (Procurement + corte Adquisiciones) ──► FASE 9 (Controles transversales)
   ──► FASE 10 (Cierre Contable)

BLOQUEADO EXTERNO ── no avanza más rápido aunque terminemos todo lo de arriba
```

---

*Este plan no fija fechas — fija orden. La Fase 3 en adelante fue reestructurada el 2026-09-08 para incorporar los ~70 hallazgos de 2 auditorías externas y la tabla maestra de monetización de las 8 líneas AXON, sin descartar nada de lo ya aprobado — solo se reordenó la secuencia según dependencia real.*
