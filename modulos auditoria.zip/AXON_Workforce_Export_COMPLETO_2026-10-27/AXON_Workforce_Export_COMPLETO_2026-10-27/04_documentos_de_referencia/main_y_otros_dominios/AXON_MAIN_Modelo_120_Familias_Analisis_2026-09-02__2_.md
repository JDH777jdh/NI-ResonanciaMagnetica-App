# AXON MAIN — El Modelo de 120 Familias Funcionales
## Leídos `axon_organizational_model_antigravity.md` y `axon_distribution_and_flows_antigravity.md`
### 02-09-2026

---

## 0 · Antes de entrar al fondo

Estos 2 MD son la versión condensada/pulida de una exploración mucho más larga que ya tenía cargada (los 2 docx: `AXON_Diccionario_Maestro_Organizacional_v1_0.docx` y `AXON Universal Organizational & Functional Model - 120 FAMILIAS Y UNIDADES.docx`). Los leí los 4 juntos para no perder contexto — el docx grande trae el ida-y-vuelta completo donde ya diste bastante de tu opinión; estos 2 MD son el resumen ejecutivo de eso, hecho con otra herramienta ("Antigravity").

Un detalle que rescato del docx grande porque aplica directo a cómo te hablo de esto en adelante: dejaste escrito ahí mismo que **ningún nombre nuevo con "AXON" adelante está aprobado hasta que tú lo confirmes** — rechazaste explícitamente "AXON Unit Architecture" por saturar la marca. Así que en este documento hablo de "Unit Shell"/"plantilla de unidad" sin el prefijo AXON, a propósito.

---

## 1 · Qué proponen estos 2 documentos, en corto

**Una taxonomía nueva y mucho más fina:** 120 "familias funcionales" (Cardiología, Imagenología, Farmacia Hospitalaria, Finanzas, RRHH...) agrupadas en 8 macro-dominios (M01 Gobierno → M08 Riesgos/Continuidad), cada una con un código estable (`AXON_CODE`, ej. `MED-CARD`, `DX-RAD`, `FIN-GEN`) independiente de cualquier norma o tenant.

**Una jerarquía canónica nueva:** `Tenant → Organization → Organizational Tree → (Dirección | CR | Unidad) → CC → Service/HealthcareService → Location → Capability → AXON Modules`. Hoy no existe nada de esto en el código — `AxonShell.jsx` es un árbol plano de `{id, label, color, submodules:[{id,label}]}`, sin CR, sin CC, sin `Organization`/`Location` como conceptos separados.

**Separación explícita CR/CC (local) vs. FHIR (interoperable):** el Centro de Responsabilidad y el Centro de Costo quedan como estructura administrativa/financiera de cada país/institución — no universales. La interoperabilidad internacional se resuelve aparte, mapeando a `Organization`/`HealthcareService`/`Location` de FHIR, más IHE/SNOMED CT/LOINC/DICOM según el dominio.

**"Unit Shell" — una sola plantilla para las 120:** en vez de programar 120 módulos distintos, cada familia hereda las mismas 12 subdivisiones (Dashboard, Calendario/Turnos, Workforce/Credenciales, Protocolos/SOP, Seguridad/Eventos, Supply, AIMS, Soporte/Solicitudes, Finanzas/Costo, Auditoría/PBAC-RBAC, Interoperabilidad, KPI). Esto no es una idea nueva de la nada — es literalmente lo que ya encontraste a mano en el docx grande al mirar tu propio Excel: Imagenología, Laboratorio y Hospitalización repiten Bodega/Sinergia/Reuniones/Turnos/Soporte/Mantenciones una y otra vez.

**Flujo financiero:** Unidad → Prestación/Orden → consume Supply + usa Workforce → dispara un `Financial Event` → Account Core, que internamente separa Patient Account (cuenta del paciente) / Cost Accounting (costeo) / General Ledger (contabilidad). Esto **coincide, punto por punto, con lo que ya propuso Contabilidad en sus documentos SIGFE/SICOGEN** y con el patrón que yo mismo dejé anotado en el addendum de mapa de dominios de ayer (sección 2, la tabla puente de eventos). Tres fuentes independientes llegando a la misma idea es una señal fuerte de que el patrón es real, no capricho de una sola sesión.

---

## 2 · Cómo se cruza contra lo que MAIN ya tiene construido — la escala real

| | Hoy en el código | El modelo de 120 familias |
|---|---|---|
| Unidad de medida | 30 módulos (`AxonShell.jsx`) / 33 en la hoja `Modulos` del Excel | 120 familias en 8 macro-dominios |
| Estructura de datos | Árbol plano `{id, label, color, submodules}` | `Organization`/`HealthcareService`/`Location` + CR/CC + Capability |
| Plantilla de unidad | Cada `.jsx` construido a mano, distinto entre sí | Una sola plantilla de 12 subdivisiones para las 120 |
| Interoperabilidad | Nombres/colores propios, sin mapeo FHIR formal | Cada familia con su tipo FHIR + IHE + terminología cuando aplica |

No es un ajuste — es otra capa de granularidad completa, con otro modelo de datos debajo. Vale la pena que lo veas con esa escala antes de decidir algo.

---

## 3 · La conexión directa con lo que dejamos pendiente ayer

El bloqueo de Agenda de Imagenología (si desagregar `clin_esp` en Medicina Nuclear/Gastroenterología/Urología/Ginecología/Dermatología/Neurología/Broncopulmonar/Oncología-Radioterapia/Odontología) **es exactamente el macro-dominio M02** de este modelo — ahí aparecen las 28 especialidades una por una, con código propio cada una. Si este modelo se adopta, esa pregunta se resuelve casi sola (se resuelve como "sí, con esta forma exacta").

Pero encontré algo que no calza: **Comité de Ética, Comité Médico y Junta Médica — que ya existen como módulos en `AxonShell.jsx` y que están en la misma pausa explícita del Estado Consolidado (junto con Docencia)** — no aparecen como familias en ninguno de los 8 macro-dominios de este modelo de 120. Docencia sí está (`095 · RES-EDU`), los otros tres no. No sé si es un olvido de cuando se armó la lista o una decisión de dejarlos fuera a propósito.

---

## 4 · Lo que esto significaría si se adopta — para que decidas con la escala real a la vista

Adoptar este modelo tocaría, como mínimo: `AxonShell.jsx` (toda la estructura de módulos), `tenantTypes.config.js` (`ALL_MODULE_IDS` pasa de 30 a otra cosa), `roles.config.js` (las categorías de rol probablemente se reorganizan para calzar con las familias), y el plan de `01-init.sql`/CoreAdapter del addendum de ayer (CR/CC como tablas nuevas). No es algo que yo deba empezar a construir solo porque encaja bien — es tan grande que prefiero que lo confirmes primero.

---

## 5 · La pregunta

¿Este modelo de 120 familias lo tratamos como **el modelo real a implementar** (y entonces sí conviene que lo use para resolver la pregunta de `clin_esp` que quedó pendiente, y para todo lo que sigue), o lo dejamos por ahora como **referencia/visión de largo plazo** mientras seguimos construyendo sobre la estructura de 30/33 módulos que ya existe?
