# AXON MAIN — Retoma de Sesión
## 01-09-2026 · Leído "Respuestas para el equipo MAIN + (1)" como pediste, esto es lo que encontré al cruzarlo con el resto del proyecto

---

## 0 · El archivo que me pediste leer

`Respuestas para el equipo MAIN + (1).txt` no es una respuesta puntual a preguntas mías — es el **documento fundacional** del ecosistema completo: qué es AXON Clinical Advance, y qué es cada una de las 7 piezas (AXON Health, AXON Core, AXON Core Lite, AXON NID Bridge, AXON Country, AXON World, AXON Dominium), más la explicación de cómo trabajamos juntos (tú respondes con archivos "Respuestas para el equipo MAIN + N", yo pregunto cuando no tengo contexto exacto, nada de decisiones grandes sin confirmar entre los dos).

Con eso como base, esto es lo que encontré revisando el resto de los ~50 documentos que ya están en este proyecto nuevo.

---

## 1 · Punto de partida oficial — confirmado, y bien traspasado

`AXON_Estado_Consolidado_Corte_Sesion.md` (corte **2026-08-21**) se declara a sí mismo como el "punto de partida único para retomar MAIN, incluido en un proyecto nuevo". Verifiqué que el traspaso a este proyecto se hizo completo:

- ✅ Los 3 archivos de configuración prometidos como "ya corregidos, listos": `security.config.js`, `standards.config.js`, `iomt.config.js` — están.
- ✅ Los 4 documentos vivos que pedía mantener actualizados: el propio Estado Consolidado, la Hoja de Ruta de Backend, la Guía de Sincronización de Satélites, el dossier de Sistema de Diseño — están los 4.
- ✅ Los 7 componentes `.jsx` construidos + `AxonShell.jsx` — están los 8.

Nada se perdió en el salto de proyecto.

---

## 2 · Dos cosas que ya cambiaron desde ese corte, y el Estado Consolidado todavía no lo refleja

**Sistema de Diseño de Temas.** Tu respuesta ya está escrita al final de `AXON_Sistema_Diseno_Temas_y_Modulos.md` (mismo día, 2026-08-21) — **elegiste Opción D**: se mantiene la identidad de color por módulo por ahora, con limpieza de los 4 pares duplicados cuando corresponda, color oficial final de cada módulo se define cuando tú digas (porque van a cambiar/sumar módulos). El Estado Consolidado sigue listando esto como "sin decidir todavía" — es el único desajuste real que encontré entre dos documentos con la misma fecha.

Quedan 3 cosas abiertas de ese mismo tema, tal como las dejaste:
- Qué cuenta exactamente como "territorio del sidebar" en el ajuste de color general — pediste revisarlo juntos, lugar por lugar.
- Qué son "tarjetas y pestañas internas" — dijiste que `RegistroMantenciones.jsx` no es buen ejemplo porque quedó atrasado en desarrollo.
- La pregunta sobre "modo automático por módulo" (Opción C) — dijiste que no la entendiste. Hay que reformularla cuando retomemos esto.

**Hoja de Ruta de Backend** tiene notas fechadas 19 y 20 de agosto con contexto tuyo que no alcanzó a resumirse en el Estado Consolidado: MVP = tenant Hospital completo primero, los demás tenants se arman después quitando módulos desde esa base; Core Lite se construye desde ahí mismo definiendo qué necesita cada naturaleza jurídica/sanitaria/comercial; AXON Health se mantiene deliberadamente más completo que AXON Core (es la ventaja competitiva, no un descuido); y hay urgencia comercial real — conversaciones en curso con comunas rurales y con un complejo penitenciario, ligadas al plazo de diciembre 2026 en que se define NID MINSAL. Nada de esto cierra un pendiente formal todavía (sigue en "te lo detallo cuando corresponda"), pero es contexto que vale la pena tener presente.

---

## 3 · Leí `Estructuración_y_arquitectura.xlsx` directo — primera vez que MAIN lo hace por su cuenta

Confirmé que es la misma versión que ya auditó Contabilidad (la hoja PBAC+RBAC calza exacto en 273 filas). 7 hojas: `PBAC + RBAC`, `Monetización`, `Take Rate AXON Health`, `Plataformas AXON`, `Tipos Tenant`, `Modulos`, `Modularización`.

| Hoja | Lo que encontré |
|---|---|
| `Tipos Tenant` | Sigue prácticamente vacía — solo "Administradores Master de AXON" marcado. Mismo hallazgo que ya tenía Contabilidad. |
| `Take Rate AXON Health` | Sigue 100% vacía (matriz Usuario × Servicio sin ningún valor). |
| `Plataformas AXON` | Confirma en texto los 25 tipos de tenant, uno por uno: Hospital, Clínica, Centro Médico, Servicio de Urgencia, Centro de Salud, Centro de Imágenes, Centro de Laboratorio, Centro de Diagnóstico, Centro de Psicología, Centro de Odontología, Centro de Salud Mental, Centro de Diálisis, Centro de Rehabilitación, Centro de Maternidad, Centro de Alimentación, Centro de Rescate, Centro de Farmacia, Centro de Movilización, Centro Oncológico, Residencia de Adulto Mayor, Policlínico Industrial, Mutual de Seguridad, Centro de Educación, Fuerzas Públicas y Uniformadas, Complejos Penitenciarios. |
| `Modularización` | **No aparecía nombrada en ningún dossier que había leído hasta ahora.** Son columnas por Plataforma × Tipo de Tenant ("AXON Core / Hospital", "AXON Core / Clínica"...) con filas de Módulo principal / Sub módulo / Sub sub módulo debajo de cada columna — 106 columnas, 80 filas. **Podría ser exactamente lo que responde al pendiente #1 del checklist** (mapeo de los 25 tipos de tenant → perfiles de módulos). Solo alcancé a ver el encabezado, no el contenido completo — lo dejo como candidato a revisar a fondo, no como algo ya resuelto. |
| `Modulos` | Tiene **33 módulos principales**, no 30 como hoy en `AxonShell.jsx`. Diferencia real, no de nombres: (1) donde `AxonShell.jsx` tiene un solo módulo `his_sistema` con 7 submódulos, el Excel separa **tres** módulos principales — "HIS (Hospital Information System)", "EMR (Electronic Medical Record)", "CIS (Clinical Information System) + Enterprise Imaging / EIMS" — que además calza con la arquitectura HIS/CIS/EMR/EIMS que ya describe `AXON_MAIN_Dossier_Tecnico_Consolidado.md` §1; (2) aparece un 33° módulo, **"División Médica"**, que hoy no existe en `AxonShell.jsx` de ninguna forma; (3) el Excel sí tiene submódulos reales bajo Dashboard (Botones de Seguridad, Anuncios Relevantes en Tiempo Real, Actividad Clínica Semanal...) mientras que en `AxonShell.jsx` Dashboard está con `submodules: []` vacío. |

---

## 4 · Material de satélites llegado después del corte del 21-ago, sin procesar todavía por MAIN

Esto es lo más grande que encontré. Desde el corte del Estado Consolidado hasta ayer (31-ago) llegaron ~15 documentos de arquitectura de otros módulos. No veo, en ninguno de los 4 documentos vivos de MAIN, evidencia de que esto ya se haya leído o respondido desde este lado:

| Dominio | Documento(s) | Fecha | Nota |
|---|---|---|---|
| Farmacia y Bodega | Dossier de Estado + sincronización (v6) | hasta 26-ago | La Guía de Sincronización de MAIN solo cubre hasta mediados de agosto |
| Contabilidad | Dossier técnico + 2 docs de Account Core (SIGFE/SICOGEN) | 25 → 30-ago | El primero tiene 5 preguntas abiertas explícitas (sección D) esperando decisión de MAIN; los otros dos piden aprobación en 11 puntos (sección 27-29) |
| Motor DICOM / RIS-PACS | Estado verificado + README + Dossier Maestro v1.0 | hasta 30-ago | Trae hallazgos propios (ej. discrepancia de formato de CUP de 5 vs 3 segmentos) sin cerrar con MAIN |
| Agenda de Imagenología | Dossier de Progreso | **31-ago, ayer** | El más reciente de todos. Pregunta de granularidad de `clin_esp` sigue abierta |
| Portal Paciente | 2 docs de arquitectura + Addendum de sincronización | 25-26 ago | El addendum deja pendiente explícito: 4 documentos definen "AXON Health" de forma distinta entre sí, sin resolver |
| Recursos Humanos / Workforce | Documento Maestro | reciente, sin fecha exacta | Motor completo nuevo, no cruzado con roles.config.js todavía |
| AIMS (activos e infraestructura) | Documento Maestro vFinal | reciente | Motor completo nuevo |
| Ficha Clínica Digital | Especificación Maestra | 29-ago | Define el modelo canónico completo (Patient/Encounter/Observation/...) |
| Identidad de Paciente / Portales / Monetización | Doc de arquitectura v1.0 | reciente | Propone el concepto "AXON ID" formalmente |
| Document Core (motor documental transversal) | Documento Maestro de Arquitectura | 29-ago | Propuesta de motor común para todo documento/PDF de AXON |
| Scheduling — trazabilidad de Slot/Appointment | Propuesta de arquitectura | sin fecha exacta | Pide decisiones explícitas de dominio (sección 19) |
| Consentimiento e Investigación (RM → mundial) | Dossier Maestro v3 | ago | Expansión Chile → internacional → mundial |

---

## 5 · Un cabo suelto que encontré, aparte

`ia_integraciones.config.js` está en el proyecto marcado "PROPUESTA v0.1... PENDIENTE DE CONFIRMAR con el equipo del main" — mismo protocolo que ya se usó para `standards.config.js`/`iomt.config.js` antes de adoptarlos formalmente. Pero la Guía de Sincronización (`AXON_Guia_Sincronizacion_Satelites_MAIN.md` §1) todavía no lo lista entre las 7 fuentes de verdad, y no aparece en el checklist del corte del 21-ago. No sé si se te quedó pendiente adoptarlo o decidiste dejarlo así a propósito.

---

## 6 · Por dónde seguir — candidatos, sin decidir yo por mi cuenta

1. Abrir a fondo la hoja `Modularización` del Excel — podría cerrar directo el pendiente #1 del checklist (perfiles de módulos por tipo de tenant).
2. Reconciliar `Modulos` (33) contra `AxonShell.jsx` (30) — decidir si separamos HIS/EMR/CIS+EIMS y si agregamos "División Médica".
3. Ponerte al día con Contabilidad — es el módulo satélite con más preguntas explícitas esperando respuesta de MAIN (16 puntos entre los 3 documentos).
4. Retomar el Sistema de Diseño con las 3 sub-preguntas que quedaron sin resolver.
5. Empezar por el material más nuevo (Agenda de Imagenología, de ayer) para no dejarlo acumular.

