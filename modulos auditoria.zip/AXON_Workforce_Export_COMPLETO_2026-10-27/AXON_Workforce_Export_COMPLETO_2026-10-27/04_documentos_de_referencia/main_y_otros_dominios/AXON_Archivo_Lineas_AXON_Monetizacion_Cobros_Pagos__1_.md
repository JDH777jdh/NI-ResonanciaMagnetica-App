# AXON — Archivo de Fuente: Líneas de AXON y Propuestas de Monetización, Cobros y Pagos
## Destilado completo — reemplaza tener que releer el PDF original

**Fecha de archivo:** 2026-09-08 · **Actualizado 2026-09-09** con tabla ampliada de Aleaxon (11 líneas, antes 8) · **Fuente:** `AXON_CLINICAL_ADVANCE_HOSPITAL_DIGITAL_ENTERPRISE_-_LINEAS_DE_AXON_Y_SUS_PROPUESTAS_ORGANIZACIONALES_DE_MONETIZACIONES_COBROS_Y_PAGOS.pdf` (1 página, tabla de Excel impresa a PDF)
**Estatus según Aleaxon:** *"provisorio hasta que determinemos o concluyamos algo más... no es verdad absoluta pero lo más probable que sí, es nuestra idea maestra como proyecto."* Se trata como la referencia de monetización más confiable disponible, no como definitivo.
**Actualización 2026-09-09 — resuelto lo que antes estaba pendiente:** Aleaxon advirtió explícitamente "falta Country y World" en la versión anterior — la nueva versión de la tabla los incluye a ambos, más una línea completamente nueva no vista antes en ningún documento del proyecto: **AXON RADE**.

---

## 1 · Tabla completa — ahora 11 líneas cubiertas

| Línea | Cobros y pagos | Trabajadores | Setup Fee & Exit | HaaS |
|---|---|---|---|---|
| **AXON Health** | Venta de todas las prestaciones del arancel FONASA (MLE — institución privada). Incluye delivery de fármacos, atención/hospitalización/urgencia domiciliaria, logística de móviles sanitarios (más que ambulancias). Cobro integrado vía I-Med/Medipass (sin determinar), aspiración futura de sistema propio. | Propios de AXON Health — RRHH y pagos vía Workforce + Account Core. Logística (delivery/movilización) comprada a terceros al inicio, evoluciona a flota propia con tracción. | No se cobra — es nuestra propia empresa. | No requiere — servidores/nube propios. |
| **AXON Core** | Venta de prestaciones FONASA (MLE o MAI — puede ser privada/pública/mixta). Cada tenant maneja su propia cartera según alcance clínico. Puede tener farmacia central/bodega propia, ser farmacia comercial pura, o ambas — "no todos son iguales, cada uno es diferente". | Propios de cada institución/tenant — NO son staff de AXON, solo usan la tecnología. Cada institución gestiona su RRHH/pagos vía Workforce + Account Core. | Se cobra, valores aún sin definir. | Depende de si el cliente lo requiere o prefiere, y aún no se definen valores. |
| **AXON Core Lite** | Venta de prestaciones de atención médica/clínica por profesionales independientes (médicos, kinesiólogos, psicólogos, enfermeros, matronas) vía telemedicina o domicilio — **sin procedimientos ni tratamientos, sin venta de medicamentos**. Sí tiene Supply Core, pero para **administrar sus propios insumos**, no para vender. Paga suscripción mensual + take rate. | Independientes, no dependen de una institución para RH/cobros/pagos. **Excluidos de la Ley 21.431**. | Se cobra, valores aún sin definir. | No requiere — servidores/nube propios. |
| **AXON NID Bridge** | Enrutador de interoperabilidad. Para empresas externas a AXON: posible monetización de tráfico de datos o suscripción al servicio. "Sin definir exactamente la viabilidad de monetización." | No son trabajadores — capa aditiva de procesamiento/mejora/administración de las plataformas AXON. | Depende de si es empresa parte de AXON o externa; aún sin definir valores. | No requiere — servidores/nube propios. |
| **AXON Patient** | Solo el paciente VIP paga suscripción mensual (descuentos/beneficios). Todos los pacientes (generales y VIP) tienen acceso **gratuito** al portal/ficha médica. Pueden acumular puntos/wallet/giftcard según lo que Account Core permita. | Son pacientes, no trabajadores — la diferencia es el perfil VIP (beneficios), nunca condición laboral. | No requiere. | No requiere — servidores/nube propios. |
| **AXON Advance** | Post-MVP: capa avanzada de módulos especializados por línea (Health/Core/Core Lite), con foco en AIMS/SMS — agrega dispositivos/sensores/elementos externos sobre el módulo básico. | No son trabajadores — capa aditiva. | Se cobra un valor agregado al contrato de base. | No requiere — servidores/nube propios. |
| **AXON IA** | Posterior a Advance: capa de IA de apoyo transversal — agentes médicos de triage (**sin capacidad diagnóstica**, solo apoyo), orquestación de datos/flujos, análisis de metadatos, evaluación en tiempo real. | No son trabajadores — capa aditiva. | Se cobra un valor agregado al contrato de base. | No requiere — servidores/nube propios. |
| **AXON Dominium** | No monetiza con pacientes — son los administradores de todas las líneas AXON. | Trabajadores de la capa de administración de las plataformas AXON, autoridad máxima dentro de su propio dominio — no ejercen tareas clínicas ni controlan RRHH/contable de Health/Core/Core Lite. | No requiere. | No requiere — servidores/nube propios. |
| **AXON Country** *(nuevo 2026-09-09)* | No monetiza con pacientes. Monetiza vía convenios gubernamentales dentro del territorio de cada despliegue nacional de AXON (B2G, en cada país donde AXON opere). | Capa de administración estadística — misma autoridad/no-control que Dominium sobre Health/Core/Core Lite. También trabajadores externos del gobierno que solo usan la tecnología, sin depender de recursos internos de AXON. | Se cobra, valores aún sin definir. | No requiere — servidores/nube propios. |
| **AXON World** *(nuevo 2026-09-09)* | No monetiza con pacientes. Monetiza vía convenios gubernamentales B2G internacionales/globales. | Misma naturaleza que Country, a escala global. | Se cobra, valores aún sin definir. | No requiere — servidores/nube propios. |
| **AXON RADE** *(nuevo 2026-09-09 — línea completamente nueva, no vista antes en ningún documento)* | No monetiza con pacientes — rama transversal que coordina recurso humano y logístico para **operaciones nacionales de rescate**. Puede monetizar con gobierno/entidades mundiales, pero "se debe estudiar para la no dependencia y control máximo propio de la gestión de rescate, es nuestra." | Propios de AXON Health, una central por región del país, con coordinación nacional y eventualmente global entre RADE regionales. RRHH/pagos vía Workforce + Account Core. **Maneja personal voluntariado** — tanto trabajadores dependientes/independientes de Health/Core/Core Lite como voluntariado individual externo a AXON (bajo condiciones de aceptación y requisitos). | No requiere — viene incluido dentro del contrato de cada línea clínica (Health/Core/Core Lite). | No requiere — servidores/nube propios. |

## 1.1 · Hallazgo nuevo de la actualización: voluntariado como categoría de "trabajador"

AXON RADE introduce algo que ninguna otra línea tiene: **personal voluntariado individual, externo a AXON, bajo condiciones de aceptación y requisitos** — ni empleado con contrato (Payroll) ni profesional a honorarios (Professional Fees). Es una tercera categoría de persona que Account Core podría necesitar reconocer eventualmente (¿se les paga algo, viáticos, seguro? ¿o es 100% ad-honorem?) — la tabla no lo especifica. Como el resto de RRHH, esto vive en el Módulo de RRHH/Workforce, no en Contabilidad — se deja anotado acá por si en algún momento Workforce pregunta cómo conectarlo a Account Core.

## 2 · Por qué esto es más importante de lo que parece para Contabilidad/Account Core

**Confirma que `PaymentPurpose` no es una abstracción — es el negocio real.** El hallazgo de `respuestas_para_contabilidad_3.docx` proponía `PATIENT_SERVICE · SAAS · SETUP · EXIT · HAAS · TAKE_RATE` como categorías necesarias para que el motor de pagos no fuera "solo paciente paga prestación". Esta tabla usa literalmente **"Setup Fee & Exit"** y **"HaaS"** como columnas — son categorías reales del modelo comercial de AXON, no una invención de la arquitectura.

**Refina el alcance de Adquisiciones/Supply para Core Lite:** confirma texto explícito — "no vende medicamentos ni otro tipo de atenciones, pero sí poseen Supply Core para la administración de sus insumos." Esto es más preciso que lo que ya habíamos aprobado (Adquisiciones "muy simplificada, sin 3 vías formal") — ahora sabemos que es específicamente para **consumo propio del profesional**, nunca para reventa.

**Confirma la base legal exacta del modelo Core Lite:** "Se excluyen de la Ley 21.431" — la ley de plataformas digitales/subordinación laboral. Ya lo sabíamos del dossier original, ahora está confirmado en la fuente de monetización también.

**Dominium confirmado, otra vez, como no-tenant-financiero:** coincide exacto con lo que ya archivamos del documento de FONASA/Isapres ("Dominium... participa en Account Core con su propio scope organizacional, nunca se mezcla con el dinero de los tenants").

**AXON Advance e IA son "capas", no líneas operacionales con Account Core propio** — ambas se cobran como "valor agregado al contrato base" de la línea que las contrata (Health/Core/Core Lite), no como tenants financieros independientes. Esto simplifica el modelo: no necesitan su propio Accounting Profile, se facturan como línea adicional dentro del contrato de quien las usa.

## 3 · Lo que sigue sin definir (a propósito, según la propia tabla)

- Los valores concretos de Setup Fee & Exit para Core/Core Lite/NID Bridge/Country/World ("aún no definimos valores") — el mecanismo de cobro ya está definido, el monto no.
- La viabilidad de monetización de NID Bridge "sin definir exactamente".
- Si el HaaS de Core es "depende del cliente" — no está resuelto qué gatilla esa decisión ni cómo se cobra cuando aplica.
- **AXON RADE:** si el voluntariado recibe algún tipo de compensación (viáticos, seguro) o es enteramente ad-honorem — no especificado, vive en el Módulo de RRHH/Workforce, no en Contabilidad.
- Cómo se depura la relación "control máximo propio" vs. "monetizar con gobierno/entidades mundiales" en RADE — la propia tabla dice que esto "se debe estudiar".

---

*Este archivo reemplaza la necesidad de releer el PDF original. Es la referencia de monetización más confiable que tenemos — se usa como grounding real para el concepto `PaymentPurpose` en el Plan de Trabajo Ordenado.*
