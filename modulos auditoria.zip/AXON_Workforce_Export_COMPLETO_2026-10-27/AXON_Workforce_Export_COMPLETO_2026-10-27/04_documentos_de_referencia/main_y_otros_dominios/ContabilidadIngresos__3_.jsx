import React, { useState, useMemo } from 'react';
import {
  TrendingUp, Search, Download, Plus, X, Landmark, ShieldCheck, Wallet,
  HardHat, Globe, Stethoscope, BedDouble, Scissors, ScanLine, FlaskConical,
  Video, Pill, FileText, Lock, Eye, ChevronDown, RotateCcw, CheckCircle2,
  Clock, Ban, Info, Hourglass, Banknote, CreditCard, ArrowLeftRight, FileCheck2, UserRound, Building2
} from 'lucide-react';

/* =========================================================================
   DISEÑO — copiado 1:1 desde HISClinico_Layer1.jsx solo para que este
   archivo se pueda previsualizar de forma independiente.
   Al integrar esto a tu proyecto: BORRA este bloque y usa el "C" y los
   átomos que ya existen en tu Layer1 (mismos nombres, mismos valores).
   ========================================================================= */
const C = {
  bg: '#F4F6F9', card: '#FFFFFF', border: '#E2E8F0', borderD: '#CBD5E1',
  ink: '#16233E', sub: '#5B6B85', mut: '#94A3B8',
  pri: '#2E7D32', priD: '#1B5E20', priL: '#EAF6EC',
  info: '#2563EB', infoL: '#EEF3FF',
  warn: '#B45309', warnL: '#FEF3E2',
  err: '#C62828', errL: '#FDECEC',
  vio: '#6D28D9', vioL: '#F2ECFB',
  teal: '#0E7490', tealL: '#E3F6FA',
  r: 10, rSm: 7, rLg: 14,
  shadow: '0 1px 3px rgba(16,24,40,.06), 0 1px 2px rgba(16,24,40,.04)',
  font: "'Inter', -apple-system, 'Segoe UI', Roboto, sans-serif",
};

const UNIDADES = {
  atencion_presencial: { label: 'Atención Presencial', icon: UserRound, color: '#4338CA' },
  urgencias: { label: 'Urgencias', icon: Stethoscope, color: '#C62828' },
  hospitalizacion: { label: 'Hospitalización', icon: BedDouble, color: '#2563EB' },
  pabellon: { label: 'Pabellón / Cirugías', icon: Scissors, color: '#6D28D9' },
  imagenologia: { label: 'Imagenología', icon: ScanLine, color: '#0E7490' },
  laboratorio: { label: 'Laboratorio', icon: FlaskConical, color: '#B45309' },
  telemedicina: { label: 'Telemedicina', icon: Video, color: '#2E7D32' },
  farmacia: { label: 'Farmacia', icon: Pill, color: '#BE185D' },
};

const PAGADORES = {
  fonasa_mai: { label: 'Fonasa · MAI', icon: Landmark, color: '#2563EB' },
  fonasa_mle: { label: 'Fonasa · MLE', icon: Landmark, color: '#1D4ED8' },
  isapre: { label: 'Isapre', icon: ShieldCheck, color: '#6D28D9' },
  particular: { label: 'Particular', icon: Wallet, color: '#2E7D32' },
  mutual: { label: 'Mutual (Ley 16.744)', icon: HardHat, color: '#B45309' },
  internacional: { label: 'Convenio internacional', icon: Globe, color: '#0E7490' },
  convenio_institucional: { label: 'Convenio institucional (CUC)', icon: Building2, color: '#BE185D' },
};

const ESTADOS = {
  pendiente: { label: 'Pendiente de facturar', color: '#B45309', bg: '#FEF3E2', icon: Clock },
  facturado: { label: 'Facturado', color: '#2563EB', bg: '#EEF3FF', icon: FileText },
  pagado: { label: 'Pagado', color: '#2E7D32', bg: '#EAF6EC', icon: CheckCircle2 },
  conciliado: { label: 'Conciliado', color: '#0E7490', bg: '#E3F6FA', icon: CheckCircle2 },
  anulado: { label: 'Anulado', color: '#C62828', bg: '#FDECEC', icon: Ban },
};

const MEDIOS_PAGO = {
  efectivo: { label: 'Efectivo', icon: Banknote, color: '#2E7D32', diasLiquidacion: 0 },
  transbank: { label: 'Transbank', icon: CreditCard, color: '#2563EB', diasLiquidacion: 2 },
  transferencia: { label: 'Transferencia', icon: ArrowLeftRight, color: '#0E7490', diasLiquidacion: 1 },
  cheque: { label: 'Cheque', icon: FileCheck2, color: '#B45309', diasLiquidacion: 3 },
};

/* % de copago que paga el paciente al momento de la atención, sobre el valor total
   de la prestación — el resto es "bonificación" que la aseguradora paga después.
   SUPUESTOS ilustrativos (varían por tramo Fonasa, plan Isapre, convenio) — quedan
   aquí, a la vista y en un solo lugar, para ajustar con los valores reales del
   cliente antes de producción. Mutual e internacional se modelan sin copago
   (cobertura 100% institucional) como simplificación razonable.
   Fuente del concepto: Fonasa declara "Valor Prestación" y "Bonificación" por
   separado (Declaración Jurada 1873, SII) — copago = Valor Prestación - Bonificación.
   fonasa_mai = 0: política "Copago Cero" (vigente desde sept. 2022) para prestaciones
   ambulatorias comunes en tramos A/B/C/D — verificado contra 2_Arancel_MAI_2025.xlsx
   (Consulta Medicina General, Hemograma, RX Tórax, Ecografía Abdominal: los 4 en $0)
   y cruzado con MarketingValores.jsx (nombra la política explícitamente).
   fonasa_mle se deja en 0.35: evidencia real insuficiente para un reemplazo más preciso
   (dos ejemplos reales dieron 50% y 60%, sin un patrón claro de reemplazo mejor fundamentado). */
const PARAMS_COPAGO_PCT = {
  fonasa_mai: 0, fonasa_mle: 0.35, isapre: 0.25, particular: 1.00, mutual: 0, internacional: 0,
  // convenio_institucional: supuesto ilustrativo — muchos convenios cubren 100% (copago 0),
  // otros dejan un copago simbólico. Ajustar según el convenio real de cada empresa/tenant.
  convenio_institucional: 0.10,
};

const ISAPRES = ['Banmédica', 'Consalud', 'Cruz Blanca', 'Colmena Golden Cross', 'Vida Tres', 'Nueva Masvida'];

/* Empresas/colegios/clubes/municipalidades con Convenio Institucional vigente — mock
   de muestra, solo para previsualizar el flujo. El CUC (Código Único de Convenio) lo
   genera y valida MAIN/Registro (cup.js) — formato CUC-{ISO2}-{REGIÓN}-{AÑO}-{SEQ8}-{CHK2},
   a propósito SIN código de tenant/clínica (el mismo CUC es válido en cualquier clínica
   de la red AXON). Contabilidad solo CONSUME un CUC ya asignado: no calcula el dígito
   verificador (SHA-256, responsabilidad de cup.js) ni valida el formato aquí. */
/* AGREEMENT ENGINE MÍNIMO — Fase 2 del plan de trabajo (2026-09-04).
   Separa Convenio de Pagador (principio de
   AXON_Account_Core_Arquitectura_Consolidada_Definitiva.md §5: "Convenio ≠
   Pagador ≠ Beneficiario ≠ Payment Method"). `agreementId` es el ID técnico
   interno de Account Core; `cuc` sigue siendo el identificador de negocio
   (viaja en businessDimensions del Financial Event, nunca lo reemplaza).
   `tipoConvenio: 'tenant'` porque los 4 son convenios propios de este
   tenant, no de red (CUC-AXON) — ver la nota de formato de CUC ya dejada
   documentada en el archivo de Ingreso de Pagos/Anticipos (pendiente #17
   del dossier, a propósito sin tocar el string de CUC todavía). */
const CONVENIOS = [
  { agreementId: 'agr_001', nombre: 'Empresas CMPC', cuc: 'CUC-CL-13-2026-00000047-F3', tipoConvenio: 'tenant' },
  { agreementId: 'agr_002', nombre: 'Colegio San Ignacio', cuc: 'CUC-CL-13-2026-00000112-A9', tipoConvenio: 'tenant' },
  { agreementId: 'agr_003', nombre: 'Club Deportivo Universidad Católica', cuc: 'CUC-CL-13-2026-00000089-K1', tipoConvenio: 'tenant' },
  { agreementId: 'agr_004', nombre: 'Municipalidad de Providencia', cuc: 'CUC-CL-13-2026-00000203-D5', tipoConvenio: 'tenant' },
];

// Puerta etiquetada — hoy busca en el array local; el día que exista un
// Agreement Engine real (MAIN), esta firma no cambia, solo su cuerpo.
export function resolverConvenio(cuc) {
  return CONVENIOS.find((c) => c.cuc === cuc) || null;
}

/* ---------------------------- formatters -------------------------------- */
const clp = (n) => '$' + Math.round(n).toLocaleString('es-CL');
const fmtDate = (iso) =>
  new Date(iso + 'T00:00:00').toLocaleDateString('es-CL', { day: '2-digit', month: 'short', year: 'numeric' });
const addDays = (iso, n) => {
  const d = new Date(iso + 'T00:00:00');
  d.setDate(d.getDate() + n);
  return d.toISOString().slice(0, 10);
};
const diffDays = (isoA, isoB) => Math.round((new Date(isoB + 'T00:00:00') - new Date(isoA + 'T00:00:00')) / 86400000);

// Ver ContabilidadHelpersCompartidos.js — versión canónica verificada de calcDV/fakeRUT (mismo comportamiento, base 9000000/mult 7919).
function calcDV(rutBody) {
  let suma = 0, mult = 2;
  for (let i = rutBody.length - 1; i >= 0; i--) {
    suma += parseInt(rutBody[i], 10) * mult;
    mult = mult === 7 ? 2 : mult + 1;
  }
  const resto = 11 - (suma % 11);
  if (resto === 11) return '0';
  if (resto === 10) return 'K';
  return String(resto);
}
function fakeRUT(seed) {
  const body = String(9000000 + (seed * 7919) % 8900000);
  const dv = calcDV(body);
  return body.slice(0, 2) + '.' + body.slice(2, 5) + '.' + body.slice(5) + '-' + dv;
}

/* Regla simplificada de IVA en salud (Art. 12 letra E N°19 y N°20, Ley de IVA).
   Validar caso a caso con tu contador antes de producción. */
function condicionIVA(unidad, pagador) {
  if (unidad === 'laboratorio') return 'afecto'; // excluido expresamente de la exención N°20
  if (['urgencias', 'imagenologia', 'telemedicina', 'farmacia', 'atencion_presencial'].includes(unidad)) return 'exento'; // ambulatorio sin alojamiento, N°20
  // hospitalizacion / pabellon: exento hasta arancel Fonasa/Isapre (N°19), afecto si es particular puro
  if (['particular', 'internacional'].includes(pagador)) return 'afecto';
  return 'exento';
}
function motivoIVA(cond, unidad) {
  if (cond === 'exento') return unidad === 'hospitalizacion' || unidad === 'pabellon'
    ? 'Art. 12 letra E N°19 — financiado hasta arancel Fonasa/Isapre'
    : 'Art. 12 letra E N°20 — prestación ambulatoria sin alojamiento';
  return unidad === 'laboratorio'
    ? 'Laboratorio excluido expresamente de la exención N°20'
    : 'Excedente sobre arancel / pagador particular';
}
function docTributario(pagador, cond, folio) {
  const institucional = ['fonasa_mai', 'fonasa_mle', 'isapre', 'mutual', 'internacional', 'convenio_institucional'].includes(pagador);
  if (institucional) return { tipo: cond === 'exento' ? 'Factura Exenta' : 'Factura', codigo: cond === 'exento' ? 34 : 33, folio };
  return { tipo: cond === 'exento' ? 'Boleta Exenta' : 'Boleta', codigo: cond === 'exento' ? 41 : 39, folio };
}

/* ═══════════════════════════════════════════════════════════════════════
   TAX DETERMINATION ENGINE — determinarImpuesto()
   Fase 2 del plan de trabajo (2026-09-04). Envuelve condicionIVA()/
   motivoIVA() — NO reemplaza esa lógica, ya verificada — y devuelve el
   shape TaxResult definido en
   AXON_Account_Core_Arquitectura_Consolidada_Definitiva.md §7:
   {taxable, taxType, rate, exemptionCode, ruleVersion, effectiveFrom,
   effectiveTo, determinationReason}.

   Se exporta para que otros dominios lo "consulten" en vez de reimplementar
   su propia regla de IVA — el principio de la Parte 4 del documento
   consolidado ("Tax Determination Engine... consultado, no poseído").

   Nota de honestidad: no invento una fecha de vigencia del Art. 12 letra E
   que no haya verificado — effectiveFrom queda null hasta confirmarla con
   fuente real, igual que el resto del código evita fechas sin respaldo.
   ═══════════════════════════════════════════════════════════════════════ */
export function determinarImpuesto(unidad, pagador) {
  const cond = condicionIVA(unidad, pagador);
  const taxable = cond === 'afecto';
  let exemptionCode = null;
  if (!taxable) {
    exemptionCode = (unidad === 'hospitalizacion' || unidad === 'pabellon') ? 'ART12_LETRA_E_N19' : 'ART12_LETRA_E_N20';
  }
  return {
    taxable,
    taxType: 'IVA',
    rate: taxable ? 0.19 : 0,
    exemptionCode,
    ruleVersion: 'LEY_IVA_ART12_LETRA_E_v1',
    effectiveFrom: null, // pendiente de verificar contra fuente oficial — no se inventa
    effectiveTo: null,
    determinationReason: motivoIVA(cond, unidad),
  };
}

// Separa el monto total de la prestación en lo que cobra la cajera HOY (copago,
// vía algún medio de pago) y lo que la aseguradora bonificará DESPUÉS — necesario
// para reconciliar caja real y para que Flujo de Caja proyecte bien los tiempos.
function calcularDesgloseCopago(monto, pagador) {
  const pctCopago = PARAMS_COPAGO_PCT[pagador] ?? 1;
  // Se topa a `monto`: redondear al centenar más cercano puede superarlo (pasaba en ~50% de
  // los casos con pagador 'particular', copago 100% — verificado en Node, bonificación
  // quedaba negativa en decenas de pesos). La bonificación nunca puede ser negativa.
  const montoCopago = Math.min(monto, Math.round((monto * pctCopago) / 100) * 100);
  const montoBonificacion = monto - montoCopago;
  return { montoCopago, montoBonificacion };
}

/* ═══════════════════════════════════════════════════════════════════════
   PUERTA ETIQUETADA (de consumo) — buscarPrestacionEnCatalogo
   Ingresos NO es dueño del catálogo de códigos/valores — eso es del
   módulo "Marketing" (antes "Comercial, Difusión y Convenios" — renombrado
   en una actualización posterior de MAIN), submódulo de Valores, a cargo
   del rol t_mkt_valores ("Encargado de Valores"). Esta función es el
   contrato de consumo: hoy la resuelve un stub mínimo local (solo códigos
   Fonasa REALES y verificados, para no inventar números que parezcan
   oficiales); cuando ese catálogo exista, se reemplaza el cuerpo de esta
   función por la consulta real — el formulario "Nuevo ingreso" no
   necesita cambiar.

   Forma esperada de cada entrada, una vez conectado al catálogo real:
   { codigo, tipoCodigo: 'fonasa'|'isapre'|'interno', glosa,
     valorReferencial, unidadSugerida }
   El campo "Prestación" del formulario sigue siendo texto libre mientras
   tanto — es la opción correcta para no simular un buscador conectado a
   un catálogo que todavía no existe. */
const CATALOGO_STUB_FONASA = [
  // 0404003 valorReferencial verificado 2026: Nivel 1 Total MLE $27.570 / Facturación Total MAI $27.220
  // (1-Libro-Arancel-MLE-2026.pdf y Excel MAI) — se usa el valor MAI por ser la modalidad
  // institucional base; ajustar a MLE si el contexto de uso lo requiere.
  { codigo: '0404003', tipoCodigo: 'fonasa', glosa: 'Ecografía abdominal (hígado, vía biliar, vesícula, páncreas, riñones, bazo)', valorReferencial: 27220, unidadSugerida: 'imagenologia' },
  { codigo: '0404002', tipoCodigo: 'fonasa', glosa: 'Ecografía obstétrica', valorReferencial: 42000, unidadSugerida: 'imagenologia' },
  { codigo: '0401009', tipoCodigo: 'fonasa', glosa: 'Radiografía de tórax simple', valorReferencial: 22000, unidadSugerida: 'imagenologia' },
  { codigo: '0401013', tipoCodigo: 'fonasa', glosa: 'Radiografía de abdomen simple (1 proyección)', valorReferencial: 24000, unidadSugerida: 'imagenologia' },
  { codigo: '0401014', tipoCodigo: 'fonasa', glosa: 'Radiografía de abdomen simple, proyección complementaria', valorReferencial: 18000, unidadSugerida: 'imagenologia' },
];
export function buscarPrestacionEnCatalogo(query) {
  const normalizar = (s) => s.trim().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  const q = normalizar(query);
  if (!q) return [];
  return CATALOGO_STUB_FONASA.filter((p) => normalizar(p.glosa).includes(q) || p.codigo.includes(q));
}

/* Semáforo de gestión: verde si cumple la meta, ámbar en zona de alerta, rojo si incumple.
   metaEsMinimo=true  -> mientras más alto, mejor (ej: tasa de facturación)
   metaEsMinimo=false -> mientras más bajo, mejor (ej: % ingresos atascados) */
// Ver ContabilidadHelpersCompartidos.js — versión canónica verificada de semaforo(). CORREGIDO 2026-09-04: antes usaba hex fijo, ahora los tokens C.* como el resto de las 9 secciones (mismos colores exactos: C.pri=#2E7D32, C.err=#C62828, C.warn=#B45309).
function semaforo(valor, metaEsMinimo, umbralBueno, umbralMalo) {
  const esBueno = metaEsMinimo ? valor >= umbralBueno : valor <= umbralBueno;
  const esMalo = metaEsMinimo ? valor < umbralMalo : valor > umbralMalo;
  if (esBueno) return C.pri;
  if (esMalo) return C.err;
  return C.warn;
}

/* ═══════════════════════════════════════════════════════════════════════
   PUERTA ETIQUETADA — calcularKPIsIngresos
   Función pura y exportable: recibe las filas ya filtradas y devuelve
   SOLO números (nada de íconos ni JSX). Este es el contrato que va a
   consumir "Alta Dirección → dir_kpis_fin" cuando lo construyamos: mismo
   cálculo que ve el contador en pantalla, sin duplicar la lógica.
   Cada futura sección de Contabilidad exportará una función equivalente
   (calcularKPIsEgresos, calcularKPIsBalances, etc.) con esta misma forma.
   ═══════════════════════════════════════════════════════════════════════ */
export function calcularKPIsIngresos(rows) {
  const sum = (pred) => rows.filter(pred).reduce((s, r) => s + r.monto, 0);

  const totalPeriodo = rows.reduce((s, r) => s + r.monto, 0);
  const facturado = sum((r) => r.estado !== 'pendiente' && r.estado !== 'anulado');
  const pendiente = sum((r) => r.estado === 'pendiente');
  const anulado = sum((r) => r.estado === 'anulado');
  const anuladoCount = rows.filter((r) => r.estado === 'anulado').length;
  const pendienteCount = rows.filter((r) => r.estado === 'pendiente').length;
  const ingresosValidos = totalPeriodo - anulado; // base real, sin transacciones sin efecto
  const tasaFacturacion = ingresosValidos ? Math.round((facturado / ingresosValidos) * 100) : 0;
  const tasaAtascado = ingresosValidos ? Math.round((pendiente / ingresosValidos) * 100) : 0;
  const ticketPromedioPendiente = pendienteCount ? Math.round(pendiente / pendienteCount) : 0;
  const exentoPct = rows.length ? Math.round((rows.filter((r) => r.condIVA === 'exento').length / rows.length) * 100) : 0;

  const facturadas = rows.filter((r) => r.fechaFacturacion);
  // CORREGIDO (2026-09-05): esto se llamaba "dso" pero mide fecha de PRESTACIÓN → fecha
  // de FACTURACIÓN — eso es "Billing Lag", no DSO real (Days Sales Outstanding, que mide
  // fecha de FACTURA → fecha de COBRO). No podemos calcular el DSO real todavía porque
  // esta sección no captura fechaPago — verificado, no existe en ningún lado del archivo.
  // Hallazgo confirmado por revisión externa (ver AXON_Contabilidad_Archivo_Respuestas_3_Completo.md §1).
  const diasParaFacturar = facturadas.length
    ? Math.round((facturadas.reduce((s, r) => s + diffDays(r.fecha, r.fechaFacturacion), 0) / facturadas.length) * 10) / 10
    : 0;

  const porUnidad = Object.keys(UNIDADES).map((id) => ({ id, monto: sum((r) => r.unidad === id) })).sort((a, b) => b.monto - a.monto);
  const porPagador = Object.keys(PAGADORES).map((id) => ({ id, monto: sum((r) => r.pagador === id) })).sort((a, b) => b.monto - a.monto);

  // Copago (caja de hoy) vs Bonificación (por cobrar a la aseguradora después) — el
  // desglose que alimenta la reconciliación de caja y la proyección de Flujo de Caja.
  const totalCopago = rows.reduce((s, r) => s + (r.montoCopago || 0), 0);
  const totalBonificacion = rows.reduce((s, r) => s + (r.montoBonificacion || 0), 0);
  const porMedioPago = Object.keys(MEDIOS_PAGO).map((id) => ({ id, monto: rows.filter((r) => r.medioPago === id).reduce((s, r) => s + r.montoCopago, 0) })).sort((a, b) => b.monto - a.monto);

  return {
    seccion: 'ingresos', transacciones: rows.length,
    totalPeriodo, facturado, pendiente, anulado, anuladoCount, pendienteCount,
    ingresosValidos, tasaFacturacion, tasaAtascado, ticketPromedioPendiente, exentoPct, diasParaFacturar,
    totalCopago, totalBonificacion, porMedioPago,
    porUnidad, porPagador,
  };
}

/* ------------------------------ mock data -------------------------------- */
const NOMBRES = ['María José', 'Pedro', 'Camila', 'Rodrigo', 'Fernanda', 'Ignacio', 'Valentina', 'Cristóbal', 'Antonia', 'Matías', 'Javiera', 'Sebastián', 'Catalina', 'Diego', 'Francisca', 'Tomás', 'Constanza', 'Felipe', 'Josefa', 'Nicolás'];
const APELLIDOS = ['González', 'Muñoz', 'Rojas', 'Díaz', 'Pérez', 'Soto', 'Contreras', 'Silva', 'Martínez', 'Sepúlveda', 'Morales', 'Rodríguez', 'López', 'Fuentes', 'Hernández', 'Torres'];
const PRESTACIONES = {
  atencion_presencial: [['Consulta medicina general', 18000], ['Consulta médico especialista', 35000], ['Control médico de seguimiento', 15000], ['Consulta medicina familiar', 20000], ['Evaluación preoperatoria', 25000]],
  urgencias: [['Consulta urgencia adulto', 32000], ['Consulta urgencia pediátrica', 34000], ['Sutura simple', 41000], ['Yeso antebraquial', 58000], ['Nebulización', 19000]],
  hospitalizacion: [['Día cama básica', 210000], ['Día cama UTI', 480000], ['Día cama UCI', 690000], ['Día cama pensionado', 260000]],
  pabellon: [['Colecistectomía laparoscópica', 2450000], ['Apendicectomía', 1680000], ['Artroscopia de rodilla', 1950000], ['Cesárea', 2100000], ['Hernioplastía inguinal', 1420000]],
  imagenologia: [['Radiografía de tórax', 22000], ['Ecografía abdominal', 48000], ['TAC de cerebro', 165000], ['Resonancia magnética columna', 245000], ['Mamografía bilateral', 52000]],
  laboratorio: [['Hemograma completo', 9500], ['Perfil bioquímico', 24000], ['Perfil lipídico', 15000], ['PCR viral respiratorio', 38000], ['Urocultivo', 12000]],
  telemedicina: [['Teleconsulta medicina general', 18000], ['Teleconsulta especialidad', 28000], ['Control post-operatorio remoto', 20000]],
  farmacia: [['Dispensación receta ambulatoria', 26000], ['Insumos clínicos hospitalización', 65000]],
};
const PAGADOR_POR_UNIDAD = {
  atencion_presencial: ['fonasa_mai', 'fonasa_mle', 'isapre', 'particular', 'mutual', 'convenio_institucional'],
  urgencias: ['fonasa_mai', 'isapre', 'particular', 'mutual', 'convenio_institucional'],
  hospitalizacion: ['fonasa_mai', 'isapre', 'particular'],
  pabellon: ['fonasa_mle', 'isapre', 'particular', 'mutual', 'internacional'],
  imagenologia: ['fonasa_mle', 'isapre', 'particular', 'convenio_institucional'],
  laboratorio: ['fonasa_mle', 'isapre', 'particular', 'convenio_institucional'],
  telemedicina: ['isapre', 'particular', 'internacional', 'convenio_institucional'],
  farmacia: ['fonasa_mai', 'isapre', 'particular'],
};
const ESTADO_POOL = ['pagado', 'pagado', 'facturado', 'facturado', 'conciliado', 'pendiente', 'pendiente', 'anulado'];

/* Rango dinámico: desde enero hasta el mes de HOY. En producción, HOY = new Date().
   Esto es lo mismo que se usó en Balances — un solo lugar para cambiar cuando
   pase a producción real. */
const HOY_ING = new Date('2026-07-05T00:00:00');
function mesesDelAnioHasta(hoy) {
  const anio = hoy.getFullYear(), mesActual = hoy.getMonth(), meses = [];
  for (let m = 0; m <= mesActual; m++) meses.push(`${anio}-${String(m + 1).padStart(2, '0')}`);
  return meses;
}
const MESES_ING = mesesDelAnioHasta(HOY_ING);
const HOY_ISO_ING = HOY_ING.toISOString().slice(0, 10);
const DIAS_DEL_MES = { '01': 31, '02': 28, '03': 31, '04': 30, '05': 31, '06': 30, '07': 31, '08': 31, '09': 30, '10': 31, '11': 30, '12': 31 };
// Meses ya cerrados no deberían mostrar "pendiente" — en la realidad, a esta altura ya se resolvió.
const ESTADO_POOL_HISTORICO = ['pagado', 'pagado', 'pagado', 'facturado', 'conciliado', 'conciliado', 'anulado'];

function genMock() {
  const rows = [];
  let seed = 1;
  const unidades = Object.keys(UNIDADES);
  const REGISTROS_POR_MES = 30;
  MESES_ING.forEach((mesStr, mesIdx) => {
    const esMesActual = mesIdx === MESES_ING.length - 1;
    const diasEnMes = mesStr === MESES_ING[MESES_ING.length - 1]
      ? Number(HOY_ING.getDate()) // el mes en curso solo llega hasta hoy, no hasta fin de mes
      : DIAS_DEL_MES[mesStr.slice(5, 7)];
    for (let i = 0; i < REGISTROS_POR_MES; i++) {
      seed += 13;
      const unidad = unidades[seed % unidades.length];
      const opciones = PAGADOR_POR_UNIDAD[unidad];
      const pagador = opciones[(seed * 3) % opciones.length];
      const [prestacion, base] = PRESTACIONES[unidad][(seed * 5) % PRESTACIONES[unidad].length];
      const variacion = 1 + (((seed * 17) % 30) - 15) / 100; // ±15%
      const monto = Math.round((base * variacion) / 100) * 100;
      const cond = condicionIVA(unidad, pagador);
      const dia = 1 + (seed % diasEnMes);
      const fecha = `${mesStr}-${String(dia).padStart(2, '0')}`;
      const pool = esMesActual ? ESTADO_POOL : ESTADO_POOL_HISTORICO;
      const estado = pool[seed % pool.length];
      const folio = estado === 'pendiente' ? null : 10450 + rows.length;
      const diasParaFacturar = 1 + (seed * 11) % 10; // 1 a 10 días — simula el rezago real entre atención y emisión
      const fechaFacturacion = estado === 'pendiente' || estado === 'anulado' ? null : addDays(fecha, diasParaFacturar);
      const { montoCopago, montoBonificacion } = calcularDesgloseCopago(monto, pagador);
      const medios = Object.keys(MEDIOS_PAGO);
      const medioPago = montoCopago > 0 ? medios[seed % medios.length] : null;
      rows.push({
        id: 'ing_' + (1000 + rows.length),
        fecha,
        fechaFacturacion,
        paciente: `${NOMBRES[seed % NOMBRES.length]} ${APELLIDOS[(seed * 2) % APELLIDOS.length]}`,
        rut: fakeRUT(seed),
        unidad,
        prestacion,
        codigoFonasa: unidad === 'laboratorio' || unidad === 'imagenologia' ? String(1000000 + (seed * 31) % 899999) : null,
        pagador,
        isapreNombre: pagador === 'isapre' ? ISAPRES[seed % ISAPRES.length] : null,
        convenioNombre: pagador === 'convenio_institucional' ? CONVENIOS[seed % CONVENIOS.length].nombre : null,
        convenioCUC: pagador === 'convenio_institucional' ? CONVENIOS[seed % CONVENIOS.length].cuc : null,
        agreementId: pagador === 'convenio_institucional' ? CONVENIOS[seed % CONVENIOS.length].agreementId : null,
        monto, montoCopago, montoBonificacion, medioPago,
        condIVA: cond,
        motivo: motivoIVA(cond, unidad),
        taxResult: determinarImpuesto(unidad, pagador),
        doc: docTributario(pagador, cond, folio),
        estado,
      });
    }
  });
  return rows.sort((a, b) => (a.fecha < b.fecha ? 1 : -1));
}

/* ------------------------------- átomos ---------------------------------- */
const Badge = ({ color, bg, icon: Icon, children }) => (
  <span style={{
    display: 'inline-flex', alignItems: 'center', gap: 5, padding: '3px 9px',
    borderRadius: 999, fontSize: 12, fontWeight: 600, color, background: bg, whiteSpace: 'nowrap',
  }}>
    {Icon && <Icon size={12} />}{children}
  </span>
);

const Btn = ({ variant = 'ghost', icon: Icon, children, onClick, style, type = 'button' }) => {
  const base = {
    display: 'inline-flex', alignItems: 'center', gap: 7, padding: '9px 15px', borderRadius: C.rSm,
    fontSize: 13.5, fontWeight: 600, cursor: 'pointer', border: '1px solid transparent',
    fontFamily: C.font, transition: 'filter .12s ease',
  };
  const variants = {
    primary: { background: C.pri, color: '#fff' },
    outline: { background: '#fff', color: C.ink, border: `1px solid ${C.border}` },
    ghost: { background: 'transparent', color: C.sub },
    danger: { background: '#fff', color: C.err, border: `1px solid ${C.errL}` },
  };
  return (
    <button
      type={type}
      onClick={onClick}
      onMouseEnter={(e) => (e.currentTarget.style.filter = 'brightness(0.96)')}
      onMouseLeave={(e) => (e.currentTarget.style.filter = 'none')}
      style={{ ...base, ...variants[variant], ...style }}
    >
      {Icon && <Icon size={15} />}{children}
    </button>
  );
};

const KPICard = ({ label, value, sub, icon: Icon, accent }) => (
  <div style={{
    background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, padding: '16px 18px',
    boxShadow: C.shadow, flex: 1, minWidth: 0,
  }}>
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
      <span style={{ fontSize: 12.5, color: C.sub, fontWeight: 600 }}>{label}</span>
      <div style={{ width: 28, height: 28, borderRadius: 8, background: accent + '18', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <Icon size={14} style={{ color: accent }} />
      </div>
    </div>
    <div style={{ fontSize: 22, fontWeight: 700, color: C.ink, letterSpacing: -0.3 }}>{value}</div>
    {sub && <div style={{ fontSize: 12, color: C.mut, marginTop: 3 }}>{sub}</div>}
  </div>
);

const FieldLabel = ({ children }) => (
  <label style={{ fontSize: 11.5, fontWeight: 600, color: C.sub, marginBottom: 5, display: 'block' }}>{children}</label>
);
const inputStyle = {
  width: '100%', padding: '8px 10px', borderRadius: C.rSm, border: `1px solid ${C.border}`,
  fontSize: 13.5, fontFamily: C.font, color: C.ink, outline: 'none', boxSizing: 'border-box', background: '#fff',
};

/* ---------------------------- sub-componentes ----------------------------- */
function BreakdownCard({ title, items, total }) {
  return (
    <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, padding: 18, boxShadow: C.shadow, flex: 1, minWidth: 0 }}>
      <div style={{ fontSize: 13, fontWeight: 700, color: C.ink, marginBottom: 14 }}>{title}</div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 11 }}>
        {items.map(([key, meta, monto]) => {
          const pct = total ? Math.round((monto / total) * 100) : 0;
          const Icon = meta.icon;
          return (
            <div key={key}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12.5, marginBottom: 4 }}>
                <span style={{ display: 'flex', alignItems: 'center', gap: 6, color: C.ink, fontWeight: 500 }}>
                  <Icon size={13} style={{ color: meta.color }} /> {meta.label}
                </span>
                <span style={{ color: C.sub, fontWeight: 600 }}>{clp(monto)} <span style={{ color: C.mut, fontWeight: 400 }}>({pct}%)</span></span>
              </div>
              <div style={{ height: 6, borderRadius: 4, background: C.bg, overflow: 'hidden' }}>
                <div style={{ height: '100%', width: pct + '%', background: meta.color, borderRadius: 4 }} />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function DetailModal({ row, onClose }) {
  if (!row) return null;
  const pag = PAGADORES[row.pagador], uni = UNIDADES[row.unidad], est = ESTADOS[row.estado];
  const mp = row.medioPago ? MEDIOS_PAGO[row.medioPago] : null;
  const neto = row.condIVA === 'afecto' ? Math.round(row.monto / 1.19) : row.monto;
  const iva = row.monto - neto;
  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(16,24,40,.45)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100, padding: 20 }} onClick={onClose}>
      <div style={{ background: '#fff', borderRadius: C.rLg, width: 520, maxWidth: '100%', maxHeight: '90vh', overflowY: 'auto', boxShadow: '0 20px 50px rgba(16,24,40,.25)' }} onClick={(e) => e.stopPropagation()}>
        <div style={{ padding: '18px 22px', borderBottom: `1px solid ${C.border}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
            <div style={{ width: 34, height: 34, borderRadius: 9, background: uni.color + '18', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <uni.icon size={16} style={{ color: uni.color }} />
            </div>
            <div>
              <div style={{ fontSize: 15, fontWeight: 700, color: C.ink }}>{row.prestacion}</div>
              <div style={{ fontSize: 12, color: C.mut }}>{fmtDate(row.fecha)} · {row.id}</div>
            </div>
          </div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: C.mut, padding: 4 }}><X size={18} /></button>
        </div>

        <div style={{ padding: 22, display: 'flex', flexDirection: 'column', gap: 16 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, background: C.infoL, padding: '9px 12px', borderRadius: C.rSm, fontSize: 12, color: '#1D4ED8' }}>
            <Lock size={13} />
            Dato de paciente identificado — tratado como dato sensible (Ley 19.628), mismo cifrado que la ficha clínica.
          </div>

          <div>
            <FieldLabel>Paciente</FieldLabel>
            <div style={{ fontSize: 14, color: C.ink, fontWeight: 600 }}>{row.paciente}</div>
            <div style={{ fontSize: 12.5, color: C.sub }}>RUT {row.rut}</div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
            <div>
              <FieldLabel>Unidad clínica</FieldLabel>
              <Badge color={uni.color} bg={uni.color + '18'} icon={uni.icon}>{uni.label}</Badge>
            </div>
            <div>
              <FieldLabel>Pagador</FieldLabel>
              <Badge color={pag.color} bg={pag.color + '18'} icon={pag.icon}>{row.isapreNombre || row.convenioNombre || pag.label}</Badge>
            </div>
          </div>

          {row.convenioCUC && (
            <div>
              <FieldLabel>Convenio institucional</FieldLabel>
              <div style={{ fontSize: 13, color: C.ink, fontWeight: 600 }}>{row.convenioNombre}</div>
              <div style={{ fontSize: 12, color: C.ink, fontFamily: 'monospace', background: C.bg, padding: '6px 10px', borderRadius: 6, display: 'inline-block', marginTop: 4 }}>{row.convenioCUC}</div>
            </div>
          )}

          {row.codigoFonasa && (
            <div>
              <FieldLabel>Código prestación (arancel)</FieldLabel>
              <div style={{ fontSize: 13, color: C.ink, fontFamily: 'monospace', background: C.bg, padding: '6px 10px', borderRadius: 6, display: 'inline-block' }}>{row.codigoFonasa}</div>
            </div>
          )}

          <div style={{ background: C.bg, borderRadius: C.rSm, padding: 14 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, color: C.sub, marginBottom: 6 }}>
              <span>Monto neto</span><span style={{ color: C.ink, fontWeight: 600 }}>{clp(neto)}</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, color: C.sub, marginBottom: 6 }}>
              <span>IVA {row.condIVA === 'exento' ? '(exento)' : '(19%)'}</span><span style={{ color: C.ink, fontWeight: 600 }}>{clp(iva)}</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 14.5, paddingTop: 8, borderTop: `1px dashed ${C.borderD}`, marginTop: 4 }}>
              <span style={{ fontWeight: 700, color: C.ink }}>Total</span><span style={{ fontWeight: 700, color: C.ink }}>{clp(row.monto)}</span>
            </div>
            <div style={{ fontSize: 11, color: C.mut, marginTop: 8, display: 'flex', gap: 5 }}><Info size={12} style={{ flexShrink: 0, marginTop: 1 }} />{row.motivo}</div>
          </div>

          {row.montoBonificacion > 0 ? (
            <div>
              <FieldLabel>Copago (caja de hoy) vs. Bonificación (por cobrar después)</FieldLabel>
              <div style={{ display: 'flex', gap: 10 }}>
                <div style={{ flex: 1, background: C.priL, borderRadius: C.rSm, padding: 10 }}>
                  <div style={{ fontSize: 10, color: C.pri, fontWeight: 700 }}>COPAGO {mp && `· ${mp.label}`}</div>
                  <div style={{ fontSize: 15, fontWeight: 700, color: C.ink }}>{clp(row.montoCopago)}</div>
                </div>
                <div style={{ flex: 1, background: C.infoL, borderRadius: C.rSm, padding: 10 }}>
                  <div style={{ fontSize: 10, color: C.info, fontWeight: 700 }}>BONIFICACIÓN · {row.isapreNombre || pag.label}</div>
                  <div style={{ fontSize: 15, fontWeight: 700, color: C.ink }}>{clp(row.montoBonificacion)}</div>
                </div>
              </div>
            </div>
          ) : row.medioPago ? (
            <div>
              <FieldLabel>Medio de pago</FieldLabel>
              <Badge color={mp.color} bg={mp.color + '18'} icon={mp.icon}>{mp.label}</Badge>
            </div>
          ) : null}

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
            <div>
              <FieldLabel>Documento tributario</FieldLabel>
              <div style={{ fontSize: 13, color: C.ink, fontWeight: 600 }}>{row.doc.tipo} ({row.doc.codigo})</div>
              <div style={{ fontSize: 12, color: C.mut }}>{row.doc.folio ? `Folio N° ${row.doc.folio}` : 'Sin folio — pendiente de emisión'}</div>
            </div>
            <div>
              <FieldLabel>Estado</FieldLabel>
              <Badge color={est.color} bg={est.bg} icon={est.icon}>{est.label}</Badge>
            </div>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 11, color: C.mut, paddingTop: 10, borderTop: `1px solid ${C.border}` }}>
            Recurso FHIR asociado: <span style={{ fontFamily: 'monospace', background: C.bg, padding: '2px 6px', borderRadius: 4 }}>Invoice</span>
          </div>
        </div>
      </div>
    </div>
  );
}

function NewIngresoModal({ onClose, onSave }) {
  const [form, setForm] = useState({ paciente: '', rut: '', unidad: 'urgencias', pagador: 'particular', prestacion: '', monto: '', medioPago: 'efectivo', convenio: '' });
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });
  const puedeGuardar = form.paciente.trim() && form.rut.trim() && form.prestacion.trim() && Number(form.monto) > 0;
  const preview = Number(form.monto) > 0 ? calcularDesgloseCopago(Number(form.monto), form.pagador) : null;

  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(16,24,40,.45)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100, padding: 20 }} onClick={onClose}>
      <div style={{ background: '#fff', borderRadius: C.rLg, width: 460, maxWidth: '100%', boxShadow: '0 20px 50px rgba(16,24,40,.25)' }} onClick={(e) => e.stopPropagation()}>
        <div style={{ padding: '18px 22px', borderBottom: `1px solid ${C.border}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ fontSize: 15, fontWeight: 700, color: C.ink }}>Registrar ingreso</div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: C.mut }}><X size={18} /></button>
        </div>
        <div style={{ padding: 22, display: 'flex', flexDirection: 'column', gap: 13 }}>
          <div>
            <FieldLabel>Nombre del paciente</FieldLabel>
            <input style={inputStyle} value={form.paciente} onChange={set('paciente')} placeholder="Ej: Carla Reyes Muñoz" />
          </div>
          <div>
            <FieldLabel>RUT</FieldLabel>
            <input style={inputStyle} value={form.rut} onChange={set('rut')} placeholder="12.345.678-9" />
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <div>
              <FieldLabel>Unidad clínica</FieldLabel>
              <select style={inputStyle} value={form.unidad} onChange={set('unidad')}>
                {Object.entries(UNIDADES).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
              </select>
            </div>
            <div>
              <FieldLabel>Pagador</FieldLabel>
              <select style={inputStyle} value={form.pagador} onChange={set('pagador')}>
                {Object.entries(PAGADORES).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
              </select>
            </div>
          </div>
          {form.pagador === 'convenio_institucional' && (
            <div>
              <FieldLabel>Convenio institucional (CUC)</FieldLabel>
              <input style={inputStyle} list="convenios-datalist" value={form.convenio} onChange={set('convenio')} placeholder="Ej: Empresas CMPC" />
              <datalist id="convenios-datalist">
                {CONVENIOS.map((c) => <option key={c.cuc} value={c.nombre} />)}
              </datalist>
            </div>
          )}
          <div>
            <FieldLabel>Prestación</FieldLabel>
            <input style={inputStyle} value={form.prestacion} onChange={set('prestacion')} placeholder="Ej: Ecografía abdominal" />
          </div>
          <div>
            <FieldLabel>Monto total (CLP)</FieldLabel>
            <input style={inputStyle} type="number" value={form.monto} onChange={set('monto')} placeholder="48000" />
          </div>
          {preview && preview.montoCopago > 0 && (
            <div>
              <FieldLabel>Medio de pago del copago</FieldLabel>
              <select style={inputStyle} value={form.medioPago} onChange={set('medioPago')}>
                {Object.entries(MEDIOS_PAGO).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
              </select>
            </div>
          )}
          {preview && (
            <div style={{ fontSize: 11.5, color: C.mut, background: C.bg, padding: 10, borderRadius: C.rSm }}>
              Copago (caja hoy): <b style={{ color: C.ink }}>{clp(preview.montoCopago)}</b>
              {preview.montoBonificacion > 0 && <> · Bonificación ({form.pagador === 'isapre' ? 'Isapre' : PAGADORES[form.pagador]?.label}, después): <b style={{ color: C.ink }}>{clp(preview.montoBonificacion)}</b></>}
            </div>
          )}
        </div>
        <div style={{ padding: '14px 22px', borderTop: `1px solid ${C.border}`, display: 'flex', justifyContent: 'flex-end', gap: 10 }}>
          <Btn variant="ghost" onClick={onClose}>Cancelar</Btn>
          <Btn variant="primary" icon={Plus} onClick={() => puedeGuardar && onSave(form)} style={{ opacity: puedeGuardar ? 1 : 0.5, cursor: puedeGuardar ? 'pointer' : 'not-allowed' }}>
            Registrar ingreso
          </Btn>
        </div>
      </div>
    </div>
  );
}

/* --------------------------------- vista principal ------------------------------------ */
export default function ContabilidadIngresos({ addToast }) {
  const toast = addToast || ((msg) => console.log(msg));
  const [data, setData] = useState(genMock);
  const [filtros, setFiltros] = useState({ desde: MESES_ING[0] + '-01', hasta: HOY_ISO_ING, unidad: 'todas', pagador: 'todos', estado: 'todos', q: '' });
  const [selected, setSelected] = useState(null);
  const [showNew, setShowNew] = useState(false);
  const [page, setPage] = useState(1);
  const [showLegend, setShowLegend] = useState(false);
  const perPage = 8;

  const filtered = useMemo(() => {
    return data.filter((r) => {
      if (r.fecha < filtros.desde || r.fecha > filtros.hasta) return false;
      if (filtros.unidad !== 'todas' && r.unidad !== filtros.unidad) return false;
      if (filtros.pagador !== 'todos' && r.pagador !== filtros.pagador) return false;
      if (filtros.estado !== 'todos' && r.estado !== filtros.estado) return false;
      if (filtros.q) {
        const q = filtros.q.toLowerCase();
        if (!r.paciente.toLowerCase().includes(q) && !r.rut.includes(q) && !String(r.doc.folio || '').includes(q)) return false;
      }
      return true;
    });
  }, [data, filtros]);

  // "Puerta etiquetada": el mismo cálculo que usará Alta Dirección más adelante.
  const kpi = useMemo(() => calcularKPIsIngresos(filtered), [filtered]);
  const porUnidadDisplay = kpi.porUnidad.map((item) => [item.id, UNIDADES[item.id], item.monto]);
  const porPagadorDisplay = kpi.porPagador.map((item) => [item.id, PAGADORES[item.id], item.monto]);
  const porMedioPagoDisplay = kpi.porMedioPago.filter((item) => item.monto > 0).map((item) => [item.id, MEDIOS_PAGO[item.id], item.monto]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / perPage));
  const pageRows = filtered.slice((page - 1) * perPage, page * perPage);

  const limpiarFiltros = () => { setFiltros({ desde: MESES_ING[0] + '-01', hasta: HOY_ISO_ING, unidad: 'todas', pagador: 'todos', estado: 'todos', q: '' }); setPage(1); };

  const exportarCSV = () => {
    const header = ['Fecha', 'Paciente', 'RUT', 'Unidad', 'Prestación', 'Pagador', 'Convenio/CUC', 'Monto', 'Copago', 'Medio Pago', 'Bonificación', 'IVA', 'Documento', 'Folio', 'Estado'];
    const lines = filtered.map((r) => [r.fecha, r.paciente, r.rut, UNIDADES[r.unidad].label, r.prestacion, r.isapreNombre || r.convenioNombre || PAGADORES[r.pagador].label, r.convenioCUC || '', r.monto, r.montoCopago, r.medioPago ? MEDIOS_PAGO[r.medioPago].label : '', r.montoBonificacion, r.condIVA, r.doc.tipo, r.doc.folio || '', ESTADOS[r.estado].label].join(';'));
    const blob = new Blob([header.join(';') + '\n' + lines.join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `ingresos_${filtros.desde}_a_${filtros.hasta}.csv`; a.click();
    URL.revokeObjectURL(url);
    toast('Archivo CSV descargado');
  };

  const handleSave = (form) => {
    const cond = condicionIVA(form.unidad, form.pagador);
    const { montoCopago, montoBonificacion } = calcularDesgloseCopago(Number(form.monto), form.pagador);
    const nuevo = {
      id: 'ing_' + (2000 + data.length),
      fecha: '2026-07-05',
      fechaFacturacion: null,
      paciente: form.paciente,
      rut: form.rut || fakeRUT(data.length + 1),
      unidad: form.unidad,
      prestacion: form.prestacion,
      codigoFonasa: null,
      pagador: form.pagador,
      isapreNombre: form.pagador === 'isapre' ? ISAPRES[0] : null,
      convenioNombre: form.pagador === 'convenio_institucional' ? (CONVENIOS.find((c) => c.nombre === form.convenio)?.nombre || form.convenio || CONVENIOS[0].nombre) : null,
      convenioCUC: form.pagador === 'convenio_institucional' ? (CONVENIOS.find((c) => c.nombre === form.convenio)?.cuc || CONVENIOS[0].cuc) : null,
      agreementId: form.pagador === 'convenio_institucional' ? (CONVENIOS.find((c) => c.nombre === form.convenio)?.agreementId || CONVENIOS[0].agreementId) : null,
      monto: Number(form.monto), montoCopago, montoBonificacion, medioPago: montoCopago > 0 ? form.medioPago : null,
      condIVA: cond,
      motivo: motivoIVA(cond, form.unidad),
      taxResult: determinarImpuesto(form.unidad, form.pagador),
      doc: docTributario(form.pagador, cond, null),
      estado: 'pendiente',
    };
    setData([nuevo, ...data]);
    setShowNew(false);
    toast('Ingreso registrado — queda pendiente de facturar');
  };

  return (
    <div style={{ fontFamily: C.font, background: C.bg, minHeight: '100%', padding: 22 }}>
      {/* header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 18, flexWrap: 'wrap', gap: 12 }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
            <div style={{ width: 34, height: 34, borderRadius: 9, background: C.priL, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <TrendingUp size={17} style={{ color: C.pri }} />
            </div>
            <div>
              <div style={{ fontSize: 18, fontWeight: 700, color: C.ink }}>Ingresos</div>
              <div style={{ fontSize: 12.5, color: C.mut }}>Salud, ventas médicas, cirugías, imagenología y telemedicina</div>
            </div>
          </div>
        </div>
        <div style={{ display: 'flex', gap: 9 }}>
          <Btn variant="outline" icon={Download} onClick={exportarCSV}>Exportar CSV</Btn>
          <Btn variant="primary" icon={Plus} onClick={() => setShowNew(true)}>Nuevo ingreso</Btn>
        </div>
      </div>

      {/* KPIs — métricas del período (datos base) */}
      <div style={{ fontSize: 11.5, fontWeight: 700, color: C.mut, textTransform: 'uppercase', letterSpacing: 0.4, marginBottom: 8 }}>Métricas del período</div>
      <div style={{ display: 'flex', gap: 14, marginBottom: 18, flexWrap: 'wrap' }}>
        <KPICard label="Ingresos del período" value={clp(kpi.totalPeriodo)} sub={`${kpi.transacciones} transacciones · bruto`} icon={TrendingUp} accent={C.pri} />
        <KPICard label="Facturado" value={clp(kpi.facturado)} sub={`${kpi.tasaFacturacion}% de ingresos válidos`} icon={FileText} accent={C.info} />
        <KPICard label="Pendiente de facturar" value={clp(kpi.pendiente)} sub={`${kpi.tasaAtascado}% de ingresos válidos`} icon={Clock} accent={C.warn} />
        <KPICard label="Anulado / sin efecto" value={clp(kpi.anulado)} sub={`${kpi.anuladoCount} transacciones`} icon={Ban} accent={C.mut} />
      </div>
      <div style={{ display: 'flex', gap: 14, marginBottom: 18, flexWrap: 'wrap' }}>
        <KPICard label="Copago recaudado (caja)" value={clp(kpi.totalCopago)} sub="Cobrado directo al paciente, mismo día" icon={Wallet} accent={C.pri} />
        <KPICard label="Bonificación por cobrar" value={clp(kpi.totalBonificacion)} sub="A Fonasa/Isapre, con demora" icon={Landmark} accent={C.info} />
      </div>

      {/* KPIs — indicadores de gestión (listos para alimentar Alta Dirección · dir_kpis_fin) */}
      <div style={{ fontSize: 11.5, fontWeight: 700, color: C.mut, textTransform: 'uppercase', letterSpacing: 0.4, marginBottom: 8 }}>Indicadores de gestión</div>
      <div style={{ display: 'flex', gap: 14, marginBottom: 14, flexWrap: 'wrap' }}>
        <KPICard label="Tasa de facturación" value={kpi.tasaFacturacion + '%'} sub="Meta: ≥ 90% al cierre de mes" icon={CheckCircle2} accent={semaforo(kpi.tasaFacturacion, true, 90, 60)} />
        <KPICard label="Ingresos atascados" value={kpi.tasaAtascado + '%'} sub="Meta: ≤ 10% de lo válido" icon={Clock} accent={semaforo(kpi.tasaAtascado, false, 10, 30)} />
        <KPICard label="Días para Facturar" value={kpi.diasParaFacturar + ' días'} sub="Meta: ≤ 3 días promedio (no es DSO — mide prestación→factura, no factura→cobro)" icon={Hourglass} accent={semaforo(kpi.diasParaFacturar, false, 3, 7)} />
        <KPICard label="Ticket promedio pendiente" value={clp(kpi.ticketPromedioPendiente)} sub={`${kpi.pendienteCount} documentos por cobrar`} icon={FileText} accent={C.vio} />
        <KPICard label="Prestaciones exentas de IVA" value={kpi.exentoPct + '%'} sub="Sobre el total del período" icon={Info} accent={C.teal} />
      </div>

      {/* breakdowns */}
      <div style={{ display: 'flex', gap: 14, marginBottom: 14, flexWrap: 'wrap' }}>
        <BreakdownCard title="Por unidad clínica" items={porUnidadDisplay} total={kpi.totalPeriodo} />
        <BreakdownCard title="Por tipo de pagador" items={porPagadorDisplay} total={kpi.totalPeriodo} />
        <BreakdownCard title="Copago por medio de pago" items={porMedioPagoDisplay} total={kpi.totalCopago} />
      </div>

      {/* filtros */}
      <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, padding: 16, boxShadow: C.shadow, marginBottom: 14 }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 10, alignItems: 'end' }}>
          <div>
            <FieldLabel>Desde</FieldLabel>
            <input type="date" style={inputStyle} value={filtros.desde} onChange={(e) => { setFiltros({ ...filtros, desde: e.target.value }); setPage(1); }} />
          </div>
          <div>
            <FieldLabel>Hasta</FieldLabel>
            <input type="date" style={inputStyle} value={filtros.hasta} onChange={(e) => { setFiltros({ ...filtros, hasta: e.target.value }); setPage(1); }} />
          </div>
          <div>
            <FieldLabel>Unidad</FieldLabel>
            <select style={inputStyle} value={filtros.unidad} onChange={(e) => { setFiltros({ ...filtros, unidad: e.target.value }); setPage(1); }}>
              <option value="todas">Todas</option>
              {Object.entries(UNIDADES).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
            </select>
          </div>
          <div>
            <FieldLabel>Pagador</FieldLabel>
            <select style={inputStyle} value={filtros.pagador} onChange={(e) => { setFiltros({ ...filtros, pagador: e.target.value }); setPage(1); }}>
              <option value="todos">Todos</option>
              {Object.entries(PAGADORES).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
            </select>
          </div>
          <div>
            <FieldLabel>Estado</FieldLabel>
            <select style={inputStyle} value={filtros.estado} onChange={(e) => { setFiltros({ ...filtros, estado: e.target.value }); setPage(1); }}>
              <option value="todos">Todos</option>
              {Object.entries(ESTADOS).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
            </select>
          </div>
          <div>
            <FieldLabel>Buscar</FieldLabel>
            <div style={{ position: 'relative' }}>
              <Search size={14} style={{ position: 'absolute', left: 9, top: 10, color: C.mut }} />
              <input style={{ ...inputStyle, paddingLeft: 28 }} placeholder="Paciente, RUT, folio" value={filtros.q} onChange={(e) => { setFiltros({ ...filtros, q: e.target.value }); setPage(1); }} />
            </div>
          </div>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 12 }}>
          <button onClick={() => setShowLegend(!showLegend)} style={{ display: 'flex', alignItems: 'center', gap: 5, background: 'none', border: 'none', cursor: 'pointer', color: C.info, fontSize: 12, fontWeight: 600, padding: 0 }}>
            <Info size={13} /> ¿Cuándo una prestación es exenta de IVA? <ChevronDown size={13} style={{ transform: showLegend ? 'rotate(180deg)' : 'none', transition: 'transform .15s' }} />
          </button>
          <button onClick={limpiarFiltros} style={{ display: 'flex', alignItems: 'center', gap: 5, background: 'none', border: 'none', cursor: 'pointer', color: C.sub, fontSize: 12.5, fontWeight: 600, padding: 0 }}>
            <RotateCcw size={13} /> Limpiar filtros
          </button>
        </div>
        {showLegend && (
          <div style={{ marginTop: 10, padding: 12, background: C.bg, borderRadius: C.rSm, fontSize: 12, color: C.sub, lineHeight: 1.6 }}>
            <b style={{ color: C.ink }}>Exento</b> — prestaciones ambulatorias sin alojamiento (Art. 12 letra E N°20, Ley de IVA) y lo financiado por Fonasa/Isapre hasta el arancel Fonasa (N°19).<br />
            <b style={{ color: C.ink }}>Afecto (19%)</b> — laboratorio clínico (excluido expresamente de la exención N°20) y lo facturado sobre el arancel o a pagadores particulares/internacionales. Confirma cada caso con tu contador antes de fijarlo como regla definitiva.
          </div>
        )}
      </div>

      {/* tabla */}
      <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, boxShadow: C.shadow, overflow: 'hidden' }}>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
            <thead>
              <tr style={{ background: C.bg, textAlign: 'left' }}>
                {['Fecha', 'Paciente', 'Unidad', 'Prestación', 'Pagador', 'Monto', 'IVA', 'Documento', 'Estado', ''].map((h) => (
                  <th key={h} style={{ padding: '10px 14px', fontSize: 11.5, fontWeight: 700, color: C.sub, textTransform: 'uppercase', letterSpacing: 0.3, whiteSpace: 'nowrap' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {pageRows.map((r) => {
                const uni = UNIDADES[r.unidad], pag = PAGADORES[r.pagador], est = ESTADOS[r.estado];
                const mp = r.medioPago ? MEDIOS_PAGO[r.medioPago] : null;
                return (
                  <tr key={r.id} style={{ borderTop: `1px solid ${C.border}`, cursor: 'pointer' }} onClick={() => setSelected(r)}
                      onMouseEnter={(e) => (e.currentTarget.style.background = C.bg)} onMouseLeave={(e) => (e.currentTarget.style.background = 'transparent')}>
                    <td style={{ padding: '11px 14px', color: C.sub, whiteSpace: 'nowrap' }}>{fmtDate(r.fecha)}</td>
                    <td style={{ padding: '11px 14px' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontWeight: 600, color: C.ink }}>
                        <Lock size={11} style={{ color: C.mut, flexShrink: 0 }} />{r.paciente}
                      </div>
                      <div style={{ fontSize: 11.5, color: C.mut }}>{r.rut}</div>
                    </td>
                    <td style={{ padding: '11px 14px' }}><Badge color={uni.color} bg={uni.color + '18'} icon={uni.icon}>{uni.label}</Badge></td>
                    <td style={{ padding: '11px 14px', color: C.ink, maxWidth: 180 }}>{r.prestacion}</td>
                    <td style={{ padding: '11px 14px' }}>
                      <Badge color={pag.color} bg={pag.color + '18'}>{r.isapreNombre || r.convenioNombre || pag.label}</Badge>
                      {mp && <div style={{ display: 'flex', alignItems: 'center', gap: 3, fontSize: 10.5, color: C.mut, marginTop: 3 }}><mp.icon size={10} />{mp.label}{r.montoBonificacion > 0 && ` · copago ${clp(r.montoCopago)}`}</div>}
                    </td>
                    <td style={{ padding: '11px 14px', fontWeight: 700, color: C.ink, whiteSpace: 'nowrap' }}>{clp(r.monto)}</td>
                    <td style={{ padding: '11px 14px' }}>
                      <span style={{ fontSize: 11.5, fontWeight: 600, color: r.condIVA === 'exento' ? C.pri : C.warn }}>{r.condIVA === 'exento' ? 'Exento' : 'Afecto'}</span>
                    </td>
                    <td style={{ padding: '11px 14px', whiteSpace: 'nowrap', color: C.sub }}>{r.doc.tipo} {r.doc.folio ? `N° ${r.doc.folio}` : '—'}</td>
                    <td style={{ padding: '11px 14px' }}><Badge color={est.color} bg={est.bg} icon={est.icon}>{est.label}</Badge></td>
                    <td style={{ padding: '11px 14px' }}><Eye size={15} style={{ color: C.mut }} /></td>
                  </tr>
                );
              })}
              {pageRows.length === 0 && (
                <tr><td colSpan={10} style={{ padding: '40px 14px', textAlign: 'center', color: C.mut, fontSize: 13 }}>
                  No hay ingresos que calcen con estos filtros. Ajusta el rango de fechas o el pagador, o <button onClick={limpiarFiltros} style={{ color: C.info, background: 'none', border: 'none', cursor: 'pointer', fontSize: 13, textDecoration: 'underline', padding: 0 }}>limpia los filtros</button>.
                </td></tr>
              )}
            </tbody>
          </table>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 16px', borderTop: `1px solid ${C.border}` }}>
          <span style={{ fontSize: 12, color: C.mut }}>{filtered.length} registros · página {page} de {totalPages}</span>
          <div style={{ display: 'flex', gap: 6 }}>
            <Btn variant="outline" onClick={() => setPage(Math.max(1, page - 1))} style={{ padding: '6px 12px', opacity: page === 1 ? 0.4 : 1 }}>Anterior</Btn>
            <Btn variant="outline" onClick={() => setPage(Math.min(totalPages, page + 1))} style={{ padding: '6px 12px', opacity: page === totalPages ? 0.4 : 1 }}>Siguiente</Btn>
          </div>
        </div>
      </div>

      {selected && <DetailModal row={selected} onClose={() => setSelected(null)} />}
      {showNew && <NewIngresoModal onClose={() => setShowNew(false)} onSave={handleSave} />}
    </div>
  );
}
