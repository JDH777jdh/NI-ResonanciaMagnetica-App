# AXON MAIN — Workforce: Estado Consolidado
## Revisión del "Documento Maestro de Arquitectura Workforce" — 09-10-2026

**Qué es esto:** Revisión completa (84 secciones) del dossier satélite de Workforce, con la misma exigencia que cualquier submisión — cruzado contra todo lo ya confirmado esta semana (Calendario y Turnos, Reuniones y Acuerdos, RADE, separación financiera) y contra el motor de identificadores ya construido (`MasterIdentifierService.js`, no solo contra lo que dice el dossier). Incluye verificación externa de las 2 leyes chilenas que cita (Ley Karin, Ley 21.431) contra fuentes oficiales. Documento vivo de Workforce de aquí en adelante — las próximas actualizaciones se editan acá.

---

## 1 · Veredicto

**Autorización condicional.** La arquitectura es sólida, internamente consistente, legalmente bien fundada (verificado en §5), y no contradice nada ya confirmado — al contrario, lo refuerza en varios puntos (§2). Condicional a 2 preguntas reales de diseño (§3) y 1 de nomenclatura (§4) antes de pasar a modelo de datos/construcción.

---

## 2 · Encaja y refuerza lo ya confirmado — sin tocar nada

- **Jerarquía de tenant (Health/Core/Core Lite):** igual a lo ya confirmado, con mucho más detalle legal/laboral por tipo — útil, no contradice nada.
- **Separación financiera** (Workforce calcula la realidad laboral, Account Core el impacto financiero, vía eventos como `PayrollCalculated`): mismo patrón exacto que ya fijamos para el motor DICOM ("el motor no se convierte en motor de facturación") — confirmado de forma independiente por 2° satélite distinto esta semana.
- **Frontera FHIR** (Practitioner/PractitionerRole complementa, no reemplaza, el modelo propio de Employment/Contract/Payroll): mismo patrón que DICOM — 2ª confirmación independiente del mismo principio.
- **"Dirección solo consume" generalizado a nivel plataforma:** AXON Dominium gobierna pero "autoridad sobre la plataforma no significa acceso indiscriminado a datos" (§63) — mismo principio que ya teníamos, ahora también a nivel Country/World (agregados/indicadores, nunca copia completa de datos individuales).
- **AXON NID Bridge:** reafirma que no debe ser "producto de interoperabilidad de RRHH" — mismo rol acotado (interoperabilidad sanitaria) que ya le fijamos para DICOM.
- **Calendario institucional** (§51, integra turnos+vacaciones+reuniones+capacitaciones): consistente con "Calendario y Turnos" y "Reuniones y Acuerdos operacionales" ya confirmados como Workforce — no contradice la parte de gobernanza formal que dejamos en `dir_secretaria`.
- **Motor de reglas jurisdiccionales** (reglas como datos versionados, no `if country == Chile`): alineado con tu preferencia general de interfaces configurables sobre hardcodeadas.

---

## 3 · 2 preguntas reales — no las resuelvo solo

### 3.1 CUT y relaciones múltiples — revisé el código ya construido, hay 1 ajuste concreto (no un rediseño)

Antes de alertar sin fundamento, fui a verificar contra `MasterIdentifierService.js` real. Resultado: el formato de CUT (`CUT-{PAIS}-{REGION}-{TENANT8}-{SEQ4}-{CHK2}`) **es compatible** con el modelo de relaciones múltiples del documento (una persona puede tener empleo en Health + relación en Core + independencia en Core Lite simultáneamente, §9) porque el generador no fuerza nada sobre tipo de relación — solo cuenta secuencial por tenant. No hace falta rediseñar el identificador.

Sí encontré un ajuste concreto y menor: `cutAFHIRIdentifier()` etiqueta todo CUT como `"Employee Identifier"` fijo en FHIR. Con el catálogo de 8 tipos de relación del documento (Empleado/Independiente/Honorario/Contratista/Externo/Subcontratado...), esa etiqueta ya no es correcta para un Honorario o Contratista. Fácil de ajustar cuando se implemente — no bloquea nada hoy.

Lo que sí queda abierto, y es de modelo de datos, no de identificador: cuando una persona tiene 2 relaciones simultáneas **dentro del mismo tenant** (ej. empleado de AXON Health que además es voluntario RADE ahí mismo), ¿se emite un 2º CUT en ese mismo tenant, o una relación adicional se vincula al mismo CUT? El generador no obliga a ninguna de las 2 opciones — es decisión de diseño de datos para cuando toque construir, no del identificador en sí.

### 3.2 Falta "Voluntario" en la taxonomía de relaciones — choca con lo ya confirmado de RADE

El catálogo de relaciones del documento (§8: Empleado/Independiente/Contratista/Personal externo/Honorario/Subcontratado, sobre las categorías base Persona/Trabajador/Profesional sanitario) no incluye **Voluntario**. Pero ya confirmamos esta semana que AXON RADE "administra personal voluntario de las 3 líneas... más voluntariado externo" — el voluntariado es una relación real que el ecosistema necesita gestionar, y este documento no la contempla en absoluto (RADE no se menciona ni una vez en las 84 secciones).

Dos caminos posibles, no elijo ninguno:
- **(a)** Agregar "Voluntario" como 9° tipo de relación dentro del mismo motor de Workforce, con sus propias reglas (sin remuneración, sin subordinación laboral formal, pero con cobertura/seguro/turnos igual que el resto).
- **(b)** Que RADE mantenga su propio registro de voluntarios, más liviano, fuera del motor de Workforce completo — solo cruzando identidad (CUP/RUT) sin pasar por todo el aparato de Employment/Contract/Payroll.

¿Cuál se ajusta más a lo que tenías pensado para RADE?

---

## 4 · Una pregunta de nomenclatura

El documento usa **"AXON HOLDING FAMILY'S"** como nombre paraguas por encima de "AXON Clinical Advance Hospital Digital Enterprise" (portada y §63). No aparece en ningún otro documento del proyecto ni en los 7 productos ya confirmados (Health/Core/Core Lite/NID Bridge/Country/World/Dominium). Antes de dejar que se filtre a otros documentos: ¿es un nombre que ya tenías pensado para la entidad holding y no me lo habías confirmado, o lo agregó quien escribió este dossier y no deberíamos adoptarlo? Tenemos la regla de no inventar nombres con prefijo AXON sin confirmar — por eso pregunto en vez de dejarlo pasar en silencio.

---

## 5 · Verificación legal externa — confirmado, con 1 matiz

Fui a la fuente oficial para las 2 leyes que cita el documento, porque son la base de decisiones de diseño reales (quién es independiente, cómo se gestiona la violencia laboral):

- **Ley Karin (21.643):** confirmado contra el Ministerio de la Mujer y Equidad de Género — sí cubre violencia ejercida por terceros ajenos a la relación laboral (clientes/usuarios/proveedores), exactamente como dice el documento en su §41 (relevante para "profesional agredido por paciente", §43). Trae detalle verificado que el documento no tenía y que vale la pena incorporar al motor de Casos (§44): investigación escrita/reservada/bilateral con **plazo de 30 días**, protocolo obligatorio dentro del Reglamento Interno, y cuestionario CEAL-SM/SUSESO obligatorio para empresas de 10+ trabajadores — es exactamente el tipo de "regla jurisdiccional versionada" que el propio documento propone en su Motor de Reglas (§19-22); podría ser su primer caso de prueba real.
- **Ley 21.431 (plataformas digitales):** el criterio oficial de la Dirección del Trabajo es el clásico de 3 elementos (servicios personales + remuneración + subordinación y dependencia). Los factores de autonomía que detalla el documento (disponibilidad, horario, precios, aceptar/rechazar servicios) no están enumerados tal cual en la página oficial de la DT — son una interpretación razonable de qué constituye evidencia de "no subordinación", no una lista legal literal. No es un error del documento, pero antes de construir la bitácora de evidencia de independencia (§7) como si fuera protección jurídica garantizada, valdría la pena que la revise un abogado laboral chileno — no soy abogado, y esto determina si Core Lite queda bien protegido legalmente frente a una recalificación como relación laboral dependiente.

Sources:
- [Ley Karin — Ministerio de la Mujer y Equidad de Género (PDF)](https://www.cnc.cl/wp-content/uploads/2024/07/11.07.24-Ley-Karin-Ministerio-de-la-Mujer-y-Equidad-de-Genero.pdf)
- [Dirección del Trabajo — Ley 21.431, plataformas digitales](https://www.dt.gob.cl/portal/1627/w3-article-122872.html)

---

## 6 · Qué sigue

Quedo con 3 preguntas tuyas (§3.1 relaciones múltiples/CUT, §3.2 Voluntario/RADE, §4 nomenclatura "AXON HOLDING FAMILY'S") antes de considerar esto listo para pasar a modelo de datos. El resto del documento — los 5 principios congelados del §79, el modelo canónico del §18, la separación legislación/regla ejecutable — lo tomo como base confirmada. Sigo sin construir nada hasta que me confirmes.

Nota aparte, no bloqueante: cuando se retome `roles.config.js` (sigue "en preparación activa" según lo último que sabemos), vale la pena cruzarlo contra la taxonomía de relaciones de este documento (§8) — hoy son dos listas de tipos de trabajador/rol que todavía no se han cruzado entre sí.
