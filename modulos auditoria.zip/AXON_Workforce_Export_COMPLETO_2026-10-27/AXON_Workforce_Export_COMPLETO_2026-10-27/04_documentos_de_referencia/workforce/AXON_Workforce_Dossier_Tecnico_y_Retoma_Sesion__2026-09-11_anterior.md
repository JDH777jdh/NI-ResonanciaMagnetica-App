# AXON — Módulo Workforce (RRHH)
## Dossier Técnico y Documento de Retoma de Sesión

**Fecha:** 2026-09-11 · **Motivo:** este chat creció lo suficiente como para continuar en uno nuevo dentro del mismo proyecto. Este documento es el punto de partida único para retomar — mismo formato y mismo propósito que ya cumple `AXON_Contabilidad_Dossier_Tecnico_y_Sincronizacion_MAIN.md` para Contabilidad.
**Estado del módulo:** 7 de ~16 secciones construidas y verificadas · arquitectura general aprobada (Documento Maestro) · CUT sigue provisional a propósito (MAIN lo inyecta)

---

## PARTE 0 · Cómo leer este documento, y qué vive dónde

Este documento cumple el mismo triple propósito que el dossier de Contabilidad:

1. **Dossier técnico** — qué hace cada uno de los 7 `.jsx` construidos, qué expone como contrato, qué parámetros legales usa y de dónde salen.
2. **Documento de retoma de sesión** — todo lo que se decidió, encontró o corrigió en el chat anterior y que **no vive en ningún otro documento del proyecto** — si no queda acá, se pierde.
3. **Mapa de navegación** — para no tener que releer la conversación completa.

### Qué ya estaba en el proyecto antes de este chat (no se repite contenido acá, solo se referencia)

| Documento | Rol |
|---|---|
| `Documento Maestro de Arquitectura Workforce.docx` | La especificación completa (§1-84) — el documento que rige todo lo construido |
| `AXON_Hoja_de_Ruta_Backend_Addendum_Mapa_de_Dominios...md` (×2, idénticos) | Reservó `workforce/` en CoreAdapter y `core.workforce_*` como grupo de tablas, antes de construir nada |
| `AXON_MAIN_Retoma_Sesion_2026-09-01.md` | Confirma que Workforce era, a esa fecha, un documento satélite sin procesar por MAIN |
| `AXON_MAIN_Modelo_120_Familias_Analisis.md` | El modelo de 120 familias (RRHH aparece como ejemplo) — sigue sin decisión, no se usó como base de nada de lo construido |
| `AXON_Contabilidad_Dossier_Tecnico_y_Sincronizacion_MAIN.md` | La puerta ya construida del lado de Contabilidad: `recibirLiquidacionRRHH(...)` en `ContabilidadEgresos.jsx`, esperando exactamente lo que Remuneraciones emite |
| `AXON_Contabilidad_Plan_de_Trabajo_Ordenado.md` / `AXON_Archivo_Lineas_AXON_Monetizacion_Cobros_Pagos.md` (×2) | Contexto de negocio — de dónde salió la distinción de trabajadores propios/tenant/independientes que ahora vive en `axonLinea` |
| `ContabilidadIngresos.jsx` / `AtencionAgendaImagenologia.jsx` | Los dos archivos de referencia de patrón de código — de ahí salió el formato provisional de CUT y el estilo de "puerta etiquetada" |
| `AXON_Identificadores_Universales_v1_0.docx` | Especificación real de CUT/CUP/CUC/CUIT — ver Parte 4, es la fuente del formato oficial (todavía no aplicado) |
| `1RAS_Correcciones_de_WORKFORCE.docx` | Revisión externa (GPT, con referencias a una revisión previa de Gemini) sobre los archivos ya construidos — ver Parte 8 para la evaluación punto por punto |

### Qué SOLO vivía en el chat anterior (por eso está completo acá)

Todo el resto de este documento: los 7 archivos construidos, los bugs reales encontrados y corregidos, los parámetros legales verificados con fuente y fecha, la evaluación de la revisión externa, y las decisiones de alcance (CUT provisional, sector público como campo sin motor, Person/Employment sin reestructurar).

---

## PARTE 1 · Workforce en el ecosistema AXON

Workforce es el motor de Recursos Humanos transversal del ecosistema — **no un RRHH por plataforma**. Sirve simultáneamente a trabajadores propios de AXON Health, trabajadores de instituciones tenant (AXON Core — Workforce es la tecnología, el empleador legal es la institución), e independientes (AXON Core Lite). Esta distinción vive en el campo `axonLinea` de cada persona.

**Los cinco principios que quedaron congelados (§79 del Documento Maestro), y que rigen todo lo construido:**

1. **Un solo motor** — no un RRHH distinto por plataforma, activado por capability.
2. **Modelo propio** — FHIR e ISO son referencia, nunca dependencia.
3. **Legislación desacoplada** — reglas jurisdiccionales como datos versionados, nunca `if country == Chile` en el código. El "Motor de Reglas Jurisdiccionales" (§19) formal **no está construido** — lo que existe hoy son parámetros versionados con fuente/fecha dentro de cada archivo, no un motor genérico.
4. **Separación financiera** — Workforce calcula la realidad laboral y emite eventos (`PayrollCalculated`, `HonorariumCalculated`, `TerminationCalculated`...); Account Core registra el impacto financiero. Workforce nunca escribe directo a lo contable.
5. **Separación de relaciones** — Empleado ≠ Independiente ≠ Honorario ≠ Contratista ≠ Externo, cada una con sus propias reglas.

---

## PARTE 2 · Inventario técnico — 7 archivos construidos y verificados

Todos en `/mnt/user-data/outputs/workforce/` (el usuario los descarga y sube al proyecto para el chat nuevo). Todos siguen el mismo patrón: **standalone-previsualizable** (mismo criterio que Contabilidad con `ContabilidadHelpersCompartidos.js` — el registro canónico se copia 1:1 a cada archivo, no se importa, para que cada uno se pueda previsualizar solo).

### 2.1 — `WorkforcePersonas.jsx` — Registro canónico (Personas y Registro CUT)

La **fuente única** del roster mock — 30 personas (20 empleados + 10 honorarios), compartidas exactamente por los 7 archivos (mismo `id`, `cut`, nombre, cargo en cualquiera de los 7 — verificado por hash MD5, no solo a ojo). Construida a mitad de sesión al descubrir que los primeros 4 archivos generaban rosters independientes sin relación entre sí.

- **Contrato exportado:** `generarPersonasCanonico()`, `nombreCompletoPersona(p)`, `calcularKPIsPersonas(personas)`.
- Modela `tipoRelacion` (empleado/honorario), `axonLinea` (axon_health/axon_core/axon_core_lite), `tenantId` (solo si axon_core — el empleador real es el tenant, no AXON), `sector` (privado/publico — agregado al final de la sesión, ver Parte 9), `fechaIngreso` (agregado a mitad de sesión, necesario para antigüedad).
- Verificado: determinismo (dos llamadas dan resultado idéntico — crítico porque esto se copia a 6 archivos más), distribución por línea AXON, sin duplicados de ID/CUT.

### 2.2 — `WorkforceRemuneraciones.jsx` — Liquidaciones (Empleados)

Primera sección construida — elegida por acoplar directo con la puerta ya construida en Contabilidad (`recibirLiquidacionRRHH`).

- **Contrato exportado:** `calcularLiquidacion(worker, periodo, input)`, `construirPayrollCalculatedEvent(liq)`, `construirPayloadLiquidacionRRHH(liq)` (reconstruido desde la descripción del Dossier de Contabilidad, no verificado contra el archivo real), `calcularKPIsRemuneraciones(liquidaciones)`.
- Motor: AFP + Salud + AFC (según tipo de contrato) + Impuesto Único progresivo + Gratificación legal (con tope) + Horas extra con recargo **pactable** (`worker.recargoHoraExtraPactado`, piso legal 50%, nunca menos — ver Parte 6.2).
- **16 checks** verificados en Node.

### 2.3 — `WorkforceHonorarios.jsx` — Profesionales y empresas independientes

- **Contrato exportado:** `calcularHonorario(professional, periodo, servicios)`, `construirHonorariumCalculatedEvent(hon)`, `calcularKPIsHonorarios(honorarios)`.
- Doble vía (reutiliza la tasa de retención YA verificada por Contabilidad, 15,25%, no se re-busca): Persona Natural → BHE + retención; Empresa → Factura + IVA 19%, sin retención.
- **12 checks** — la primera vez que se verificó formalmente en Node (se construyó antes de establecer la disciplina de testing completa).

### 2.4 — `WorkforceTurnosAsistencia.jsx` — Turnos y motor de asistencia

Construida para cerrar un hueco real: en Remuneraciones, `horasExtraTrabajadas` era ruido mock antes de esto.

- **Contrato exportado:** `calcularAsistenciaPeriodo(worker, periodo, registrosDiarios)`, `construirInputHorasParaRemuneraciones(asistencia)` (misma forma que espera el 3er parámetro de `calcularLiquidacion`), `calcularKPIsAsistencia(registros)`.
- Turnos 12×36, diurno administrativo, noche fijo — con flag `requiereSistemaExcepcional` (Art. 38 CT, resolución DT) por tipo de turno.
- **18 checks.** Bug real encontrado y corregido: precisión de punto flotante en `horasAsistidas` (sumar turnos de 8,4h acumulaba `176.40000000000006`).

### 2.5 — `WorkforceLicenciasMedicas.jsx` — Licencias médicas (Flujo 2: recepción)

Solo el flujo de RECEPCIÓN (§23 docx) — la emisión clínica vive en el sistema clínico, no acá.

- **Contrato exportado:** `calcularLicencia(worker, licencia)`, `construirAusenciaParaRemuneraciones(lic)`, `calcularUrgenciaEmpleador(lic, hoyISO)`, `calcularAlertas(licencias, hoyISO)`, `calcularUrgenciaApelacion(lic, hoyISO)`, `calcularAlertasApelacion(licencias, hoyISO)`, `construirIntakeDesdeNotificacionElectronica(notif)`, `calcularKPIsLicencias(licencias)`.
- Plazos en días hábiles (trabajador→empleador, empleador→COMPIN), carencia SIL, circuito Isapre/Fonasa vs. Mutual.
- **36 checks.** Motor de Alertas construido en dos rondas (ver Parte 6.3) tras pregunta directa sobre automatización.

### 2.6 — `WorkforceVacacionesPermisos.jsx` — Feriado legal y permisos especiales

Reutiliza el motor de días hábiles/feriados de Licencias Médicas (mismo `FERIADOS_CHILE_2026`, verificado byte-idéntico).

- **Contrato exportado:** `calcularAntiguedad(fechaIngreso, fechaReferencia)`, `calcularDerechoFeriadoAnual(aniosCompletos)`, `calcularSaldoFeriado(worker, diasTomados, fechaRef)`, `calcularPermisoEspecial(tipoId, fechaInicio)`, `construirAusenciaParaRemuneraciones(sol)`, `calcularKPIsVacacionesPermisos(solicitudes)`.
- Feriado progresivo (Art. 68), tope de acumulación (Art. 70), 5 tipos de permisos especiales (matrimonio, nacimiento, 3 variantes de duelo).
- **21 checks.** Bug real encontrado y corregido: `calcularAntiguedad` (ver Parte 6.4) — este mismo bug se corrigió también en Finiquito porque comparte la función.

### 2.7 — `WorkforceEgresoFiniquito.jsx` — Egreso y Finiquito

Última sección — construida con UI deliberadamente más simple (instrucción explícita de la sesión: priorizar motor sobre frontend, optimizar tokens).

- **Contrato exportado:** `calcularAntiguedad(...)` (copia corregida), `calcularFiniquito(worker, causalId, sueldoBase, fechaTermino, avisoPrevioDado, diasVacacionesPendientes)`, `construirTerminationCalculatedEvent(fin)`, `calcularKPIsFiniquitos(finiquitos)`.
- Indemnización por Años de Servicio (Art. 163, tope 11 años/90 UF, solo si causal = necesidades de la empresa), sustitutiva de aviso previo (Art. 162), especial por obra/faena (Art. 163 bis — **sin** tope de años, a diferencia de la IAS general).
- **18 checks.**

---

## PARTE 3 · Patrones transversales establecidos

| Patrón | Qué resuelve | Dónde verificarlo |
|---|---|---|
| **Registro canónico copiado, no importado** | Las 30 personas son idénticas en los 7 archivos, sin depender de un sistema de módulos real | `grep -c "esCore ? 'publico' : 'privado'"` en los 7 debe dar 1 cada uno; el hash MD5 del bloque `generarPersonasCanonico` debe ser idéntico salvo el `export` |
| **Puerta etiquetada** | Cada archivo declara la forma exacta de lo que emitiría hacia Account Core, sin fingir una conexión real | Funciones `construir*Event`/`construir*ParaRemuneraciones` en cada archivo |
| **Parámetro legal versionado** | Nunca una tasa/plazo como constante sin origen | Cada constante legal tiene comentario con artículo + fecha de verificación + fuente |
| **Verificación en Node antes de entregar** | Encontró 6 bugs reales (Parte 6) que una revisión visual no habría atrapado | Los scripts de prueba no persisten en este contenedor — ver Parte 7 si hace falta reconstruirlos |
| **Identidad de color violeta** | Todo Workforce comparte un color de módulo, distinto de Contabilidad (verde) e Imagenología (navy) | Mismo objeto `C` en los 7 archivos — sigue provisional, "Opción D" del Sistema de Diseño |

---

## PARTE 4 · Identificadores (CUT/CUP/CUC) — decisión tomada esta sesión

`AXON_Identificadores_Universales_v1_0.docx` (en el proyecto) define el formato REAL:

- **AXON Health** (§32, "CUT-AXON"): `CUT-{ISO2}-{REG}-AXON-{SEQ4}-{CHK2}` → ej. `CUT-CL-13-AXON-0001-E9`
- **AXON Core y Core Lite** (§36, "CUT Tenant"): `CUT-{ISO2}-{REG}-{TENANT8}-{SEQ4}-{CHK2}` → ej. `CUT-CL-13-CLIMEDSA-0001-I0` (Core Lite usa el mismo formato porque cada independiente es, para este efecto, su propio tenant de una persona — §119)
- CHK2 real: SHA-256 truncado al primer byte, codificado como letra+dígito (A0–Z5) — **no** el hash simple que usan los 7 archivos hoy.

**Decisión explícita del usuario:** el motor real (Master Identifier Service) es de MAIN, no de Workforce — mismo patrón ya confirmado para CUC en Contabilidad (`cup.js` es de MAIN, Contabilidad solo lo consume). El CUT es un valor que **MAIN inyectará** más adelante. Por instrucción directa, **no se actualizó el formato en los 7 archivos** — sigue el provisional (`CUT-CL-13-AXON-{seq8}-{hash simple}`) heredado de `AtencionAgendaImagenologia.jsx`, y así debe quedar hasta que MAIN entregue el generador real.

---

## PARTE 5 · Contratos exportados — tabla completa

| Archivo | Funciones exportadas |
|---|---|
| Personas | `generarPersonasCanonico()` · `nombreCompletoPersona(p)` · `calcularKPIsPersonas(personas)` |
| Remuneraciones | `calcularLiquidacion(worker, periodo, input)` · `construirPayrollCalculatedEvent(liq)` · `construirPayloadLiquidacionRRHH(liq)` · `calcularKPIsRemuneraciones(liqs)` |
| Honorarios | `calcularHonorario(prof, periodo, servicios)` · `construirHonorariumCalculatedEvent(hon)` · `calcularKPIsHonorarios(hons)` |
| Turnos y Asistencia | `calcularAsistenciaPeriodo(worker, periodo, registros)` · `construirInputHorasParaRemuneraciones(asist)` · `calcularKPIsAsistencia(registros)` |
| Licencias Médicas | `calcularLicencia(worker, lic)` · `construirAusenciaParaRemuneraciones(lic)` · `calcularUrgenciaEmpleador(lic, hoy)` · `calcularAlertas(lics, hoy)` · `calcularUrgenciaApelacion(lic, hoy)` · `calcularAlertasApelacion(lics, hoy)` · `construirIntakeDesdeNotificacionElectronica(notif)` · `calcularKPIsLicencias(lics)` |
| Vacaciones y Permisos | `calcularAntiguedad(ingreso, ref)` · `calcularDerechoFeriadoAnual(años)` · `calcularSaldoFeriado(worker, tomados, ref)` · `calcularPermisoEspecial(tipo, inicio)` · `construirAusenciaParaRemuneraciones(sol)` · `calcularKPIsVacacionesPermisos(sols)` |
| Egreso y Finiquito | `calcularAntiguedad(ingreso, ref)` · `calcularFiniquito(worker, causal, sueldo, término, aviso, díasVac)` · `construirTerminationCalculatedEvent(fin)` · `calcularKPIsFiniquitos(fins)` |

**Nota de consistencia:** `construirAusenciaParaRemuneraciones` existe en Licencias Médicas Y en Vacaciones y Permisos — a propósito devuelven la MISMA forma (`{workerId, diasAusencia, diasNoRemuneradosPorEmpleador, motivo}`), corregido tras encontrar que Vacaciones usaba un campo booleano distinto (`pagaEmpleador`) para el mismo concepto — ver Parte 6.5.

---

## PARTE 6 · Bugs reales encontrados y corregidos esta sesión

Ninguno de estos se habría atrapado sin correr el código — quedan documentados con detalle porque son exactamente el tipo de error que podría reaparecer si se reescribe algo sin volver a probar.

### 6.1 — Precisión de punto flotante (Turnos y Asistencia)
Sumar varios turnos de `horasPorDia` decimal (8,4h) acumulaba `176.40000000000006` en vez de `176.4`. El cálculo de horas extra/déficit ya redondeaba downstream y no se veía afectado, pero el campo crudo se habría mostrado roto en pantalla. Corregido con `Math.round(x*10)/10` al sumar.

### 6.2 — Recargo de horas extra fijo en 50% (Remuneraciones)
Encontrado por pregunta directa del usuario: *"el valor hora extra lo dejaste fijo? en algunos lugares es a convención entre trabajador y empleador."* El Art. 32 CT fija 50% como **piso legal**, no como valor único — las partes pueden pactar más (nunca menos). Antes se aplicaba 50% fijo a todos. Corregido: `worker.recargoHoraExtraPactado` por trabajador, con `Math.max(pactado, 0.50)` como piso infranqueable.

### 6.3 — Licencias Médicas sin motor de alertas proactivo
Encontrado por pregunta directa: *"tenemos una alerta aparte de la notificación de correo? algo que evite que el empleador se atrase?"* Lo que existía calculaba y MOSTRABA si algo ya llegó tarde (auditoría retrospectiva) — no había nada que avisara ANTES del vencimiento. Se construyó `calcularUrgenciaEmpleador`/`calcularAlertas` (días hábiles restantes hasta el plazo empleador→COMPIN, clasificado vencido/urgente/pronto/con margen), y en una segunda ronda se extendió el mismo patrón a la apelación de rechazos (`calcularUrgenciaApelacion`/`calcularAlertasApelacion`, plazo de 15 días hábiles ante COMPIN).

### 6.4 — Antigüedad mal calculada (Vacaciones y Permisos → propagado a Finiquito)
`calcularAntiguedad` dividía `diasTotales / 365.25` para sacar años completos. Alguien con EXACTAMENTE 2 años calendario (730 días) da `730/365.25 = 1.998`, que redondea a 1, no 2 — negándole el año de elegibilidad justo en el límite. Corregido con aritmética de calendario real (comparar año/mes/día del aniversario), no división por promedio. Encontrado al escribir las pruebas de Node, no al construir.

### 6.5 — Forma inconsistente entre dos "puertas etiquetadas" equivalentes
`construirAusenciaParaRemuneraciones` en Licencias devolvía `diasNoRemuneradosPorEmpleador` (número); la misma función en Vacaciones devolvía `pagaEmpleador` (booleano) — mismo propósito conceptual, forma distinta. Si Remuneraciones llega a consumir ambas, habría necesitado dos lógicas para el mismo concepto. Unificado a la forma numérica en los dos archivos. Encontrado en la auditoría cruzada, no en la construcción original.

### 6.6 — `CARGOS_LISTA` frágil en el registro canónico
En `WorkforcePersonas.jsx`, `CARGOS_LISTA` se derivaba con `Object.keys(CARGOS)` mientras los otros 6 archivos la tenían como array fijo copiado. Funcionaba porque el orden coincidía por casualidad, pero reordenar `CARGOS` en Personas (por legibilidad, por ejemplo) habría desincronizado el roster de los otros 6 archivos sin ningún error visible. Corregido: array fijo en los 7, verificado por hash que ahora son byte-idénticos.

---

## PARTE 7 · Parámetros legales vigentes — tabla única de referencia rápida

*Mismo principio que ya usa Contabilidad: cada valor es un dato versionado con fecha de vigencia y fuente, nunca una constante permanente. Todos verificados por búsqueda entre el 2026-09-09 y 2026-09-11, salvo donde se indica que se reutilizó un valor ya verificado por Contabilidad.*

| Parámetro | Valor | Fuente / vigencia |
|---|---|---|
| UF | $40.885,63 | Banco Central, 09-sep-2026 |
| UTM | $71.721 | Circular N°32 SII, sept-2026 — cambia mensual |
| AFP obligatorio | 10% + comisión (0,46%–1,44%) | DL 3.500 |
| Tope imponible AFP/Salud | 89,9 UF | Res. Ex. N°237 Sup. Pensiones, desde 01-feb-2026 |
| Salud (Fonasa/piso Isapre) | 7% | mismo tope que AFP |
| AFC — indefinido | 0,6% trab. + 2,4% empl. | Ley 19.728 |
| AFC — plazo fijo/por obra | 0% trab. + 3% empl. | Ley 19.728 — no aplica a Honorarios |
| Tope imponible AFC | 135,2 UF | AFC Chile — re-verificado tras contradicción en revisión externa (Parte 8) |
| Impuesto Único 2ª Cat. | 8 tramos, 4%–40%, exento hasta 13,5 UTM | Art. 43 N°1 LIR |
| IMM | $553.553 | Ley 21.830, desde 01-may-2026 |
| Gratificación legal | 25%, tope 4,75 IMM anual | Art. 50 CT |
| Jornada semanal máxima | 42h | Ley 21.561, desde 26-abr-2026 |
| Reforma Previsional (empleador) | 1%→3,5% gradual | Ley 21.735 — no descuento al trabajador |
| Recargo hora extra | Piso 50%, pactable hacia arriba | Art. 32 CT |
| Retención Honorarios (BHE) | 15,25% | **Reutilizado de Contabilidad**, verificado 2026-08-28 vs. SII dic-2025 |
| IVA (Factura Honorarios) | 19% | estable |
| Plazo licencia trabajador→empleador | 2 días hábiles (privado) / 3 (público) | DT, MINSAL, Sup. Salud, SUSESO |
| Plazo licencia empleador→COMPIN | 3 días hábiles | MINSAL, SUSESO — si se atrasa, empleador paga el subsidio |
| Carencia SIL | 3 días si licencia ≤10 días | — |
| Apelación rechazo COMPIN / SUSESO | 15 días hábiles / 5 días hábiles | — |
| Feriado legal | 15 días hábiles/año, sábado siempre inhábil | Art. 67, 69 CT |
| Feriado progresivo | +1 día cada 3 años sobre 10 años | Art. 68 CT |
| Feriado proporcional | 1,25 días hábiles/mes si <1 año | Art. 73 CT |
| Tope acumulación feriado | 2 períodos | Art. 70 CT |
| Permiso matrimonio/AUC | 5 días hábiles | Art. 207 bis CT |
| Permiso nacimiento hijo (padre) | 5 días corridos | Art. 195 CT |
| Duelo — hijo | 10 días corridos | Art. 66 CT — ⚠️ ver incertidumbre abajo |
| Duelo — cónyuge/conviviente civil | 7 días corridos | Art. 66 CT |
| Duelo — hijo en gestación | 7 días hábiles | Art. 66 CT |
| Duelo — hermano/padre/madre | 4 días hábiles | Art. 66 CT, ampliado de 3 (Ley 21.441, 2022) |
| Indemnización años de servicio (IAS) | 30 días/año, tope 11 años, tope base 90 UF | Art. 163 CT — solo si causal = necesidades de la empresa |
| Sustitutiva aviso previo | 30 días (1 mes) | Art. 162 CT — solo si no hubo aviso de 30 días |
| Especial obra/faena | 2,5 días/mes, **sin** tope de años | Art. 163 bis CT |

**⚠️ Incertidumbre sin resolver — Duelo por muerte de hijo:** fuentes oficiales discrepan. SUSESO y DerechoPedia citan "muerte de hijo ASÍ COMO muerte de cónyuge" bajo el mismo plazo de 7 días corridos (redacción que parece más antigua). Fuentes más recientes (leyes-cl.com, leydirecta.cl, ambas fechadas 2026) separan muerte de hijo en 10 días corridos, distinto de cónyuge en 7. Se usó **10** por ser la versión más reciente encontrada. Verificar contra el texto vigente en LeyChile antes de tratar este número como definitivo.

---

## PARTE 8 · La revisión externa (`1RAS_Correcciones_de_WORKFORCE.docx`) — evaluación

El usuario trajo un documento con una revisión extensa (GPT, con referencias a una revisión previa de Gemini) sobre los 7 archivos. Se evaluó punto por punto, no se aceptó ni se rechazó en bloque:

**Verificado empíricamente y refutado:** el documento afirmaba un "error de un día" en `sumarDiasHabiles()` de Licencias Médicas. Se probó con 3 fechas de inicio distintas (lunes, viernes antes de fin de semana, sábado) contra la regla exacta de la DT ("cuenta desde el día hábil siguiente al inicio") — los 3 casos calzaron exacto con lo esperado. No hay bug ahí; el ajuste `inicioConteo` del código es redundante pero no incorrecto.

**El documento se contradice a sí mismo** sobre el tope AFC (dice 135,1 UF en un punto, se retracta a 135,2 UF al final). Se re-verificó por búsqueda independiente: **135,2 UF es correcto**, sin cambios al código.

**Aceptado y actuado:**
- Sector público (Ley 19.664/Estatuto Administrativo) no estaba modelado en ningún motor → se agregó el campo `sector` (privado/publico) al registro canónico, **sin** construir el motor de reglas (queda como puerta etiquetada, ver Parte 9).
- Separación Person/Employment/Contract como entidades propias → se documentó conceptualmente en los comentarios de `WorkforcePersonas.jsx` (qué campos son "Persona" vs. "Relación/Employment"), **sin** reestructurar el shape a nivel de código.

**Rechazado, con razonamiento explícito:** la recomendación central del documento ("congelar funcionalmente los prototipos y hacer una refactorización arquitectónica completa antes de continuar", con un plan de 7 fases y ~18-20 dominios) **no se siguió**. Razones dadas en su momento:
1. La separación mock-primero/backend-después es la metodología YA establecida en todo el proyecto desde antes de Workforce (confirmada en el addendum de Mapa de Dominios: "es mapeo, no implementación"; en Contabilidad: 13 secciones construidas como mock antes de proponer Account Core).
2. La mayoría de lo señalado como "problema" ya estaba flagged explícitamente en los propios comentarios del código como "no construido todavía, puerta etiquetada" — no eran hallazgos nuevos.
3. Instrucción explícita del usuario después de leer esta evaluación: **"avanza más con la estructura que modificar esos valores... necesitamos trabajar más para el motor de workforce y después afinamos frontend... optimizamos el uso de tokens"** — priorizar motor sobre reestructuración masiva y sobre frontend.

---

## PARTE 9 · Lo que queda abierto a propósito (no es olvido, es alcance)

| Pendiente | Estado |
|---|---|
| CUT formato real (MAIN) | Provisional en los 7 archivos — MAIN lo inyecta, ver Parte 4 |
| Motor de reglas sector público (Ley 19.664) | Campo `sector` existe en las 30 personas; el motor de reglas (jornada/indemnización distintas) no está construido |
| Person/Employment como entidades separadas con historial temporal | Documentado conceptualmente en comentarios; no reestructurado — decisión explícita de no hacer ese refactor ahora |
| `roles.config.js` cruzado con Workforce | Nunca estuvo disponible en este chat — los 7 cargos usados (médico, enfermería, TENS, kinesiólogo, matrona, administrativo, auxiliar) son ilustrativos |
| Conexión real entre archivos (`construirInputHorasParaRemuneraciones`, `construirAusenciaParaRemuneraciones` → `calcularLiquidacion`) | Documentada y con forma verificada, pero **no conectada en código** — cada archivo sigue siendo standalone-previsualizable |
| Modelo de 120 Familias | Sin decisión — se construyó sobre la estructura de módulo único, no sobre esa taxonomía |

---

## PARTE 10 · Secciones sin construir todavía

De la lista completa del Documento Maestro (§83): Credenciales y Documentación, Organización/Posiciones/Asignaciones/Subrogancias, Salud Ocupacional y Accidentes, Denuncias/Casos/Investigaciones (Ley Karin), Capacitaciones, Evaluación de Desempeño, Bienestar y Beneficios, Reglamento Interno, Dashboard/Workforce Analytics.

---

## PARTE 11 · Verificación técnica — cómo se hizo, y cómo rehacerla

Cada archivo se verificó con **esbuild** (sintaxis + bundle con stubs de `react`/`lucide-react`) y un script de Node por archivo que llama las funciones puras exportadas con casos reales, incluyendo casos borde (topes, fechas límite, fracciones de año). Total: **149 checks** entre los 7 archivos (19+20+15+19+35+24+17), **0 fallas** en la corrida final contra los archivos definitivos de esta entrega.

**Los scripts de prueba viven en `/mnt/user-data/outputs/workforce/tests/`** (7 archivos `test_*.mjs` + `build_all.mjs` + `README.md` con el setup paso a paso) — se reconstruyeron una vez en esta misma sesión porque el contenedor se reinició y se perdió la primera versión; esta vez quedan guardados como output descargable, no solo en el contenedor efímero. Para usarlos en el chat nuevo: seguir el `README.md` de esa carpeta (instala esbuild, crea los stubs de `react`/`lucide-react`, bundlea los 7 `.jsx` y corre las 7 pruebas).

---

*Fin del documento. Punto de entrada único para la sesión nueva — desde acá se puede ir a cualquiera de los 7 `.jsx`, a `tests/` para re-verificar, o a cualquiera de los documentos del proyecto listados en la Parte 0.*
