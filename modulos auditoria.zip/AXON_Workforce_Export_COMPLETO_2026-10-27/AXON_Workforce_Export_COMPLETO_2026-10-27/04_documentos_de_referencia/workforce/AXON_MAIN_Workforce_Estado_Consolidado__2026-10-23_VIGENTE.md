# AXON MAIN — Workforce: Estado Consolidado
## Revisión del "Documento Maestro de Arquitectura Workforce" — 09-10-2026 · Actualizado 23-10-2026

**Qué es esto:** Revisión completa (84 secciones) del dossier satélite de Workforce, cruzada contra todo lo confirmado (Calendario/Turnos, Reuniones, RADE, separación financiera) y contra el motor de identificadores real (`MasterIdentifierService.js`). Incluye verificación externa de las leyes chilenas citadas (Ley Karin, Ley 21.431) contra fuentes oficiales. Documento vivo de Workforce — toda actualización se edita acá, no en archivos nuevos.

**11-10:** jdiazH compartió un intercambio extenso (con otra IA, "GPT", revisando este mismo documento + los dossiers de UnitShell) más sus propias decisiones directas. Verifiqué técnicamente cada observación contra el código real antes de incorporar nada — no transcribo conclusiones ajenas sin comprobarlas. Resultado: las 2 preguntas abiertas de la versión anterior quedan resueltas, se agrega el puente con UnitShell (Position/Role/Assignment) y se corrige una cifra legal que jdiazH había propuesto.

**21-10:** Workforce entregó su «Actualización para MAIN v2.1» (14-10) y la adjuntaste el 20-10. Solo se procesó lo del **CUV** (§5.3), porque pediste centrarnos ahí; lo demás de la v2.1 queda anotado en §10. El CUV pasa de «resuelto» (nombre y flujo, 11-10) a «formato decidido». **El mismo 21-10:** propusiste `CUV-{ISO2}-{REG}-{AXONRADE}-{SEQ6}-{CHK2}` y MAIN lo verificó con el motor; después respondiste D-1, D-2 y D-5 con las recomendaciones de MAIN, aprobaste las reglas R-CUV 1-10 y los 4 estados (con `AXONRADE` como único ámbito vigente, reservado como ámbito de plataforma y no como tenant) y autorizaste preparar G1 y G2 como adjuntos. **El 22-10 MAIN entregó G1 (texto de la spec v1.1) como adjunto y sumó el CUV al motor único (la sección § 13 de `MasterIdentifierService.js`, en el Proyecto), sin copias ni parches por tu regla de un solo motor; sus pruebas y vectores van en otro adjunto. No se creó ningún documento nuevo.** **El 23-10, tras tu pregunta sobre HL7 FHIR y tu respuesta «obvio completalo y guarda», MAIN completó en ese mismo motor la función FHIR del CUV (`cuvAFHIRIdentifier`: `type` con el código `CUV`, y `assigner` y `period` opcionales); no se tocó nada más de FHIR.** **Las decisiones del CUV están cerradas;** falta revisarlas con Workforce y RADE (G3) y lo que sigue (G4 a G6). Nada está emitido.

---

## 1 · Veredicto

**Autorización condicional, con todo lo pendiente ya resuelto 11-10 (CUT de AXON Health §4.3, concepto y flujo del CUV §5, Core Lite/Ley 21.431 §9.2) — lista para modelo de datos.** La arquitectura es sólida, internamente consistente, legalmente bien fundada (§9), y no contradice nada confirmado — al contrario, lo refuerza (§2). El CUV quedó **cerrado como decisión el 21-10** (D-1 a D-5 y sus reglas, §5.3); el 22-10 se entregó G1 como borrador y el CUV quedó integrado en el motor único (§ 13 de `MasterIdentifierService.js`), con su función FHIR completada el 23-10; falta revisarlo con Workforce y RADE y lo que sigue (G3 a G6). Del resto no queda nada abierto.

---

## 2 · Encaja y refuerza lo ya confirmado — sin tocar nada

- **Jerarquía de tenant (Health/Core/Core Lite):** igual a lo confirmado, con más detalle legal/laboral por tipo.
- **Separación financiera** (Workforce calcula la realidad laboral, Account Core el impacto financiero vía eventos tipo `PayrollCalculated`): mismo patrón que el motor DICOM — confirmado de forma independiente por 2° satélite.
- **Frontera FHIR** (Practitioner/PractitionerRole complementa, no reemplaza, el modelo propio): mismo patrón que DICOM — 2ª confirmación independiente.
- **"Dirección solo consume"** generalizado a Dominium/Country/World: autoridad de plataforma no es acceso indiscriminado — agregados/indicadores, nunca copia de datos individuales.
- **AXON NID Bridge:** no es "producto de interoperabilidad de RRHH" — mismo rol acotado que en DICOM.
- **Calendario institucional:** consistente con lo confirmado — ver tabla de propietarios en §7.
- **Motor de reglas jurisdiccionales como datos versionados:** reforzado esta sesión — ver §9.

---

## 3 · Cadena de identidad del trabajador — puente con UnitShell (NUEVO)

Los dossiers de UnitShell (v2.x) establecen una distinción que Workforce debe adoptar formalmente: **persona, trabajador, cargo, rol, asignación organizacional y asignación operativa no son el mismo objeto.** UnitShell presenta y consume ese contexto; no lo crea ni decide permisos efectivos — eso lo hace el Policy Engine de MAIN.

### 3.1 Cadena confirmada

```
Person (MAIN · identidad canónica, resolución de duplicados)
  └─ Worker / CUT (Workforce · identidad operativa, 1 por tenant — ver §4)
       ├─ Engagement (Workforce · relación: Empleo/Independiente/Honorario/
       │    Contratista/Externo/Subcontratado/Voluntario — pueden coexistir
       │    varias bajo el mismo Worker/CUT, cada una con su propio ciclo de vida)
       │     └─ Contrato/Acuerdo (instrumento jurídico cuando corresponda)
       ├─ Position / Cargo (Workforce+UnitShell · entidad maestra de 1ª clase,
       │    paralela a Role — ej. "Médico Radiólogo", "Enfermera Clínica")
       ├─ Organizational Assignment (Workforce+UnitShell · en qué OrgNode/
       │    subunidad se desempeña — puede rotar: UCI → Urgencia → Pabellón)
       ├─ Role Assignment (MAIN · qué función de autorización ejerce,
       │    + Credenciales/competencias + atributos ABAC + evaluación PBAC)
       └─ Operational Assignment (Workforce+UnitShell · turno/actividad
            concreta — ej. "turno UCI noche", "MRI-01")
            └─ Policy Engine → Effective Permissions → UnitShell →
               Dashboard Engine → Domain Engine (ejecuta, con su propia
               trazabilidad)
```

**Ejemplo que fija el patrón:** una enfermera conserva su mismo `Role = Enfermera` y su mismo `Position = Enfermera Clínica` mientras rota entre `Organizational Assignment = UCI`, `= Urgencia` y `= Pabellón`. Cambiar de unidad no obliga a crear un rol nuevo ni un cargo nuevo — solo cambia la asignación.

### 3.2 Position como entidad maestra — campos mínimos

```
Position
  ├─ position_id
  ├─ organization_scope / org_node_id
  ├─ position_type · title · occupation
  ├─ specialty_requirements · credential_requirements · competency_requirements
  ├─ headcount
  └─ valid_from / valid_to
```

### 3.3 Por qué importa para los 7 módulos de Workforce

Personas, Honorarios, Remuneraciones, Turnos y Asistencia, Vacaciones y Permisos, Licencias Médicas y Egreso/Finiquito **no se fusionan** en una sola entidad ni un proceso único — comparten identidad/contexto/relaciones/asignaciones, pero conservan su propio ciclo de vida y datos de dominio. Todos se conectan por `Person · Worker · Engagement · Contract · Position · Assignment`.

### 3.4 Frontera con CR/CC (Responsibility/Cost Center)

Workforce **no absorbe** CR/CC — los referencia cuando una asignación o proceso concreto lo necesita (ej. un analista de presupuesto sí necesita `CC Scope`; un médico radiólogo normalmente no). Mismo principio que ya aplicamos: cada modelo transversal es dueño de su dato, los demás lo consumen por referencia.

---

## 4 · CUT y relaciones múltiples — RESUELTO

### 4.1 Regla semántica final

**Un CUT por registro Worker, por tenant o microtenant — nunca por relación, contrato o asignación.**

| Objeto | Identifica | Cardinalidad |
|---|---|---|
| Identidad de persona (MAIN) | A la persona real, con resolución de duplicados | 1 por persona, siempre |
| CUT (Workforce) | Su registro de trabajador **dentro de un ámbito tenant/microtenant** | 1 por tenant/microtenant donde tenga registro |
| Engagement | Una relación concreta (empleo, independiente, voluntariado...) | N por CUT — varias relaciones simultáneas **no generan un 2° CUT** |
| Contrato/Acuerdo | El instrumento jurídico de cada Engagement, cuando aplique | 1 por Engagement que lo requiera |
| Operational Assignment | Turno/actividad/unidad concreta | N por Engagement |

**Esto cierra la pregunta que quedó abierta en la versión anterior de este documento** ("¿2 relaciones en el mismo tenant generan un 2° CUT?"): **no** — se vinculan al mismo CUT como 2 Engagements distintos.

**Ejemplo de 3 tenants:** una persona que trabaja en AXON Health, además en una institución AXON Core, y además mantiene su propio AXON Core Lite, tiene **3 CUT distintos** (uno por ámbito) y sigue siendo **1 sola identidad canónica** en MAIN. Un tenant no tiene acceso automático al CUT ni a los registros laborales de la persona en otro tenant — la resolución de identidad compartida, cuando sea legítima, pasa por el servicio de identidad de MAIN bajo autorización, no por exponer el CUT entre tenants.

**Precisión de ámbito confirmada contra el código real:** el campo `tenantCode` de 8 caracteres en `generarCUT()` **es el mismo slot** que usan `generarCUITAxonCore()` y `generarCUITAxonCoreLite()` para el código de tenant/microtenant — es decir, un microtenant de Core Lite **no necesita un campo nuevo**; usa el mismo slot de 8 caracteres que una institución Core, eligiendo su propio código. Esto coincide exactamente con tu regla ("un microtenant igual es un tenant independiente, institución solo que individual").

### 4.2 Verificación técnica del motor de identificadores — las 4 observaciones son reales

Fui a `MasterIdentifierService.js` (versión actual del Project) línea por línea, no acepté el análisis sin comprobarlo. **Las 4 observaciones son exactas:**

**A. El código de tenant no exige "8 letras" — permite 8 alfanuméricos y corrige en silencio.**
```js
const tenant = String(tenantCode).toUpperCase().padEnd(8, "X").slice(0, 8);
```
Si escribes `"SALUD"` (5 letras), el motor genera `"SALUDXXX"` sin avisar. Si escribes 9 caracteres, recorta el último sin avisar. El validador tampoco exige solo letras:
```js
const CUT_REGEX = /^CUT-([A-Z]{2})-([A-Z0-9]{1,3})-([A-Z0-9]{8})-(\d{4})-([A-Z]\d)$/;
```
el grupo de tenant es `[A-Z0-9]{8}` — alfanumérico, no "8 letras" como tu regla establece.

**B. Core y Core Lite comparten exactamente el mismo formato — la separación es solo metadata, no el código mismo.**
```js
/** CUIT AXON Core — institución cliente Core. Mismo string que CUIT AXON
 * Core Lite (el propio documento lo advierte: se distinguen por metadata
 * `identifier_type`, no por la forma del código). */
export function generarCUITAxonCore({ paisISO2, regionCode, tenantCode, secuencia }) { ... }
export function generarCUITAxonCoreLite({ paisISO2, regionCode, tenantCode, secuencia }) { ... }
```
Los dos cuerpos son idénticos. Esto es intencional y está documentado en el propio archivo — pero hoy **no hay ninguna regla que impida que una institución Core y un profesional Core Lite elijan el mismo código de 8 caracteres**, produciendo el mismo string con distinto `identifier_type` adjunto por quien llama. Es responsabilidad de quien invoca la función, no del motor.

**C. `generarCUTAxon()` (el CUT propio de AXON Health) no pasa su propio validador.**
```js
export function generarCUTAxon({ paisISO2, regionCode, secuencia }) {
  return construirId(["CUT", pais, reg, "AXON", seq]);  // "AXON" = 4 caracteres
}
```
El segmento `"AXON"` tiene 4 caracteres, pero `CUT_REGEX` exige exactamente 8 en esa posición. Un CUT de AXON Health (ej. `CUT-CL-13-AXON-0001-X1`) **no matchea `CUT_REGEX`** → `validarCUT()` lo rechaza → `decodificarCUT()` devuelve `null` → `revocarCUT()` lanza `"CUT inválido, no se puede revocar"`. Confirmado por lectura directa, no por inferencia: hoy **no se puede revocar el CUT de ningún trabajador propio de AXON Health** con el código tal como está.

**D. `cutAFHIRIdentifier()` etiqueta todo CUT como `"Employee Identifier"`, sin excepción.**
```js
export function cutAFHIRIdentifier(cut) {
  return { type: { coding: [{ code:"EI", display:"Employee Identifier" }] }, ... };
}
```
Con 7+ tipos de Engagement (Empleado/Independiente/Honorario/Contratista/Voluntario...), esto es incorrecto para cualquier CUT que no sea de un empleado. Verifiqué además el value set de ejemplo que usa FHIR hoy para este CodeSystem (`v2-0203`) y **`"EI"` no aparece en él** — sí aparecen `PRN` ("Provider number", mejor candidato para Independiente/Honorario cuando el CUT representa a un profesional habilitado) y `EN` ("Employer number", que identifica al empleador, no al empleado — no es sustituto). El código completo de la tabla v2-0203 es más amplio que ese value set de ejemplo, así que esto lo confirmaría el equipo de interoperabilidad FHIR antes de fijar el reemplazo — no lo doy por cerrado solo con esto.

### 4.3 Qué corregir — propuesta concreta para el equipo satélite

| # | Corrección | Alcance |
|---|---|---|
| 1 | `generarCUT()` y `CUT_REGEX`: exigir **exactamente 8 letras A-Z**, sin relleno ni truncamiento — rechazar con error explícito en vez de corregir en silencio | `MasterIdentifierService.js` |
| 2 | Reservar y validar unicidad del código de tenant (país+región+8 letras) en un **registro central**, único entre Core y Core Lite — hoy solo se distinguen por `identifier_type`, no hay unicidad garantizada | Capa de persistencia/backend, no solo el generador JS |
| 3 | Resolver el choque de `generarCUTAxon()` — ver opción recomendada abajo | `MasterIdentifierService.js` |
| 4 | `cutAFHIRIdentifier()`: elegir el código HL7 según el tipo de Engagement real, no fijo | `MasterIdentifierService.js` |

**RESUELTO 11-10:** decidiste mantener `"AXON"` (4 caracteres) tal como está — no se toca `generarCUTAxon()`. La corrección queda del lado del validador, no del generador: una familia de validación **dedicada** para el CUT de AXON Health, separada de la genérica que usan Core/Core Lite, en vez de forzar el formato de 8 caracteres sobre un literal que preferiste conservar corto.

**Patch concreto para el equipo satélite:**
```js
// Regex dedicado — el segmento de tenant es el literal fijo "AXON", no [A-Z0-9]{8}
const CUT_AXON_REGEX = /^CUT-([A-Z]{2})-([A-Z0-9]{1,3})-AXON-(\d{4})-([A-Z]\d)$/;

export function validarCUTAxon(cut) {
  if (!cut || typeof cut !== "string") return { valido: false, error: "CUT-AXON vacío" };
  const m = cut.match(CUT_AXON_REGEX);
  if (!m) return { valido: false, error: "Formato CUT-AXON inválido" };
  const [, pais, region, seq, checkRecibido] = m;
  const checkEsperado = calcularCheck2(`CUT-${pais}-${region}-AXON-${seq}`);
  if (checkRecibido !== checkEsperado) return { valido: false, error: "Dígito verificador inválido" };
  return { valido: true, pais, region, tenant: "AXON", secuencia: parseInt(seq) };
}
```
`decodificarCUT()` prueba primero el formato genérico (`validarCUT()`) y, si falla, cae a `validarCUTAxon()` antes de devolver `null` — un solo punto de entrada sigue sirviendo para decodificar/revocar cualquier CUT, sea de un tenant Core/Core Lite o de AXON Health, sin que quien llama tenga que saber de antemano a qué familia pertenece. `revocarCUT()` no se toca — hereda el arreglo automáticamente en cuanto `decodificarCUT()` reconoce el formato.

---

## 5 · Voluntariado / RADE — RESUELTO

**Camino elegido: variante de la opción (a) de la versión anterior, con una precisión importante — Voluntario entra como tipo de Engagement propio, pero NO se trata como relación laboral ni pasa por nómina/finiquito.**

### 5.1 Identificadores — se mantienen separados, no se reutilizan entre sí

| Identificador | A quién corresponde | Para qué sirve |
|---|---|---|
| Identidad de persona | Persona natural | Reconocer a la misma persona dentro de sus límites autorizados |
| CUP | Paciente | Dominio de pacientes |
| CUT | Trabajador (Engagement laboral) | Identidad de trabajador en su ámbito tenant |
| **CUV — Código Único Voluntario** (nombre confirmado el 11-10 y reconfirmado el 21-10; formato decidido el 21-10: §5.3) | Participación voluntaria | Evaluación, admisión, estado, asignaciones y trayectoria del voluntariado — **no genera CUT** |

No uses el CUP como identificador de voluntariado ni actives Employment para un voluntario — el `Engagement` debe tener `type: VOLUNTEER` con sus propias reglas (sin remuneración, sin subordinación laboral formal, sí cobertura/seguro/turnos/competencias).

### 5.2 Flujo RADE → MAIN → Workforce para un voluntario

1. **RADE — Postulación y preselección:** candidatura, experiencia, requisitos de ingreso, evaluación inicial de aptitud. Identificador temporal de expediente, interno de RADE o Workforce y nunca un CUV (§5.3, D-5).
2. **MAIN — Identidad de la persona:** resolución de identidad, detección de duplicados.
3. **RADE — Evaluación y admisión:** evaluación médica/psicológica cuando proceda (por profesionales competentes, acceso restringido al informe clínico — Workforce solo recibe el estado: apto / no apto / apto con restricciones + vigencia, nunca el informe completo), verificación de competencias, decisión de aptitud.
4. **MAIN — Emisión del CUV:** una vez autorizada la admisión, se solicita al motor de identificadores el CUV. El motor lo emite; la política de admisión decide si procede, no el motor. Contrato de emisión y reglas: §5.3.
5. **Workforce + Document Engine:** Workforce registra el Engagement de voluntariado (vigencia, competencias, asignaciones); Document Engine gestiona documentos/cláusulas/firmas/trazabilidad — formalizando el acuerdo de voluntariado **sin que se use para disfrazar una relación laboral** que en los hechos tenga esa naturaleza.
6. **RADE — Disponibilidad operativa:** la persona queda disponible para misiones compatibles con su aptitud vigente, capacitación y autorización efectiva.

**Separación de responsabilidad que se mantiene en todo el flujo:** RADE decide admisión operativa → MAIN aplica políticas de identidad/autorización → el motor de identificadores administra códigos → Workforce registra la relación → RADE gestiona el rescate. Ningún motor crea un CUT ficticio para voluntarios ni duplica identidad.

No existe un único examen médico/psicológico universal para todo voluntario de rescate — los requisitos se definen por función, riesgo, jurisdicción y normativa aplicable (detalle operativo que queda para el dossier de RADE, no aquí).

### 5.3 · CUV — familia de identificador (23-10 · decisiones y reglas aprobadas; G1 entregado como borrador; CUV integrado en el motor único, con su FHIR completo; nada emitido)

**Origen.** Workforce entregó su «Actualización para MAIN v2.1» (14-10) y la adjuntaste el 20-10 («algo resumido de CUV pero creo suficiente»). Piden **crear el CUV e integrarlo al Master Identifier Service**, con revisión y aprobación de MAIN (v2.1 §1, §2-7, §8-B1 y C2); la emisión sigue **bloqueada** hasta que esté documentado y probado. Su criterio (propuesta suya; la confirmaste el 21-10: nombre en D-1, alcance en D-2): un CUV a todo voluntario formalmente admitido en RADE, aunque ya tenga CUT en otro ámbito; no durante la postulación; no es un CUT con otra etiqueta, no reutiliza el CUP y no identifica cada rescate, turno ni asignación. Para el código proponen el enfoque estructural del motor con el código de tenant **del ámbito de RADE**, y dejan abierto si RADE usa un ámbito global o regionales (lo resolviste el 21-10, D-3). El reparto de responsabilidades es el de §5.2.

**Qué había el 21-10** (verificado contra el archivo y ejecutando su verificador; el CUV se sumó el 22-10, ver «Integrado y probado»)
- `MasterIdentifierService.js` (27-09) **no tenía CUV**: ni formato, generador, validador, regex ni revocación. Sí tenía las piezas para sumarlo: `construirId` + `calcularCheck2` (CHK2-V1), `validarGenerico(valor, regex)` y el patrón de `revocarCUT`. Con su verificador reproduje **12 de 12** vectores publicados en la spec v1.0.
- Los generadores **reciben** `secuencia`; no hay contador transaccional (el prototipo `DatabaseService.js` usa `this._pacientes.size + 1`, líneas 112-113 y 188-189). Es lo que Workforce pide corregir (v2.1 §2-5) y lo que la spec §59-61 exige; el CUV no puede emitirse así.
- Los 5 regex del motor son `const` internos **sin `export`** y los 10 de plataforma no tienen regex: es lo que contó el equipo DICOM («no tenía regex»). Queda **después** del CUV.
- Hoy los generadores rellenan o truncan en silencio (§4.2-A); el CUV **rechaza**.
- La spec v1.0 ya fija lo que el CUV debe respetar (§4-5, §48-50, §55-57, §59-61, §68 y §118, §74, §76-77, §120-121).

**¿Familia nueva?** Cumple las 7 preguntas de la §120: entidad nueva, ciclo de vida y namespace propios, identificación permanente, no representable con CUT ni CUP, razón jurídica y técnica (el voluntariado no es relación laboral). Es un cambio **aditivo** (prefijo y regex disjuntos de las 15 familias, CHK2-V1 intacto) y sin migración, porque no hay CUV emitidos. La clasificación jurídica del voluntariado (v2.1 §8-D) bloquea los flujos, no el código.

**Formato — decidido el 21-10 (tu propuesta, verificada por MAIN)**
```
CUV-{ISO2}-{REG}-{AXONRADE}-{SEQ6}-{CHK2}
CUV-CL-13-AXONRADE-000001-P8   ← calculado con el verificador del motor; ejemplo, no emitido
```
ISO2 y REG = país y región de **emisión**, como en las demás familias · `AXONRADE` = código del **ámbito RADE**: 8 letras A-Z, el mismo molde que TENANT8, sin relleno ni truncado; un único ámbito para todo RADE (D-3) · SEQ6 = 000001 a 999999 desde el backend (000000 reservado), un contador por (ISO2, REG) (D-4) · CHK2 = CHK2-V1 sin cambios.
Regex: `^CUV-([A-Z]{2})-([A-Z0-9]{1,3})-([A-Z]{8})-(\d{6})-([A-Z]\d)$` más SEQ ≠ 000000 (en otros lenguajes: coincidencia completa y `[0-9]`; ver «Integrado y probado»). El regex acepta cualquier grupo de 8 letras y la lista de ámbitos vigentes (hoy solo `AXONRADE`) es configuración (R-CUV-4), de modo que un ámbito nuevo sea un alta y no un cambio de formato; quedó aprobado junto con las reglas. Largo: 28 caracteres con REG de 2 (27 con REG de 1; 29 con REG de 3).

**Integrado y probado** (22-10; FHIR completado el 23-10): la sección § 13 se agregó al `MasterIdentifierService.js` del Proyecto, que sigue siendo el único motor (de 28.731 a 44.404 B): **solo se agregaron** 298 líneas (de 547 a 845) y no se quitó ninguna, comprobado contra el archivo del 27-09; los 12 vectores publicados de la spec y los 15 generadores anteriores dan los mismos valores (los 10 de plataforma, con valores de referencia calculados con el motor del 27-09 y comprobados con Python). Vectores del CUV (`cuv.vectors.json`): 9 positivos (p. ej. `CUV-CL-13-AXONRADE-000002-C2`, `…-999999-Q6`, `CUV-CL-ABC-AXONRADE-000001-C7` de 29 caracteres), 29 negativos con su clase (24 FORMAT_INVALID, 3 CHECKSUM_INVALID —incluido el reservado Z7—, 2 SEMANTICALLY_INVALID) y 20 entradas de generación inválida. **51 pruebas** con `node:test` (9 grupos; 12 son del FHIR), todas verdes; se provocaron **115 fallos a propósito** en el código (23 del 22-10 que siguen vigentes y 92 nuevos sobre el FHIR) y se detectaron 106: los otros 9 no cambian lo que hace el código (p. ej. aceptar «día 32» en un mes de 31 días, que el patrón de fecha ya impide), así que no hay nada que detectar; 40.000 validaciones al azar contra un validador independiente dieron 0 diferencias; 200.000 cálculos de CHK2 del motor frente a Python `hashlib` dieron 0 diferencias; con las 999.999 secuencias de CL-13 el CHK2 toma los 256 valores y nunca Z6-Z9. Ningún CUV valida como CUT, CUP, CUC, CUP-RN ni CUP-NN, ni al revés. **Hallazgos:** (1) nada en el motor impide que un tenant use `AXONRADE` como código: `generarCUT` y `generarCUC` lo aceptan y producen un valor válido (`CUT-CL-13-AXONRADE-0001-V2`), por eso hay que reservarlo (ver «Antes de emitir»); (2) al portar el regex a otro lenguaje hay dos trampas, confirmadas en Python: `$` acepta un salto de línea final y `\d` acepta dígitos Unicode; hay que usar coincidencia completa y `[0-9]`, y vale también para los regex de las otras familias si se portan.

**Reglas (R-CUV) — aprobadas el 21-10**
1. Identifica el registro de voluntario de **una persona en el ámbito RADE**; no a la persona (identidad canónica de MAIN), ni cada misión, turno o asignación (que referencian al CUV), ni una relación laboral.
2. Se emite solo al completarse la admisión. El identificador temporal del expediente **no es un CUV** ni se transforma en uno (como CUP-RN → CUP, spec §42).
3. Se emite aunque la persona ya tenga CUT en otro ámbito; no se deriva de CUP, CUT, RUT ni dato personal (spec §74).
4. `generarCUV()` es estricto: lanza error si el ámbito no son 8 letras A-Z o no figura entre los vigentes (hoy solo `AXONRADE`), si ISO2 o REG no cumplen o si la secuencia no está entre 1 y 999999.
5. Secuencia: contador transaccional del backend por (ISO2, REG, ámbito); huecos permitidos, reutilización nunca; al agotarse falla cerrado con alerta.
6. ISO2 y REG no se reasignan si la persona cambia de región, unidad o equipo (spec §49, §69). El código no lleva estado (vive en el registro, spec §57). CHK2 detecta tipeos (1 falso aceptado cada 256, spec §24); no autentica ni autoriza.
7. **No es una credencial:** al ser secuencial se puede enumerar. Cualquier credencial o QR lleva un token firmado distinto (Document Engine) y todo acceso por CUV pasa por autorización.
8. `identifier_type = CUV` obligatorio; FHIR propio, sin reutilizar «Employee Identifier» (v2.1 §2-4). El `type` ya lleva el código `CUV` de un CodeSystem de AXON (completado el 23-10 a tu pedido del 22-10; el 21-10 la regla decía «`type` por definir con Workforce»: nada está emitido, así que Workforce puede pedir otro código en G3). El recurso destino sigue por definir con Workforce.
9. Emisión idempotente: `idempotency_key` = acto de admisión de RADE; repetirla devuelve el mismo CUV sin consumir secuencia.
10. Compuertas de emisión (configurables, apagadas por defecto): spec aprobada · pruebas en verde · código RADE reservado · backend con registro y contador transaccional.

**Estados (spec §57) — aprobados el 21-10:** ACTIVE · SUSPENDED (bloqueo cautelar del identificador, p. ej. sospecha de suplantación; **no** es disponibilidad operativa, que es de RADE y Workforce) · ARCHIVED (retiro, fin de participación, fallecimiento) · REVOKED (error de emisión, fraude o decisión disciplinaria; irreversible y nunca se reasigna; una admisión posterior emite un CUV nuevo). Motivo en lista cerrada más texto libre.

**Emisión y funciones (maqueta, sin código).** El servicio recibe `{person_id, ámbito, admission_id, solicitante}`, verifica persona resuelta, admisión registrada, autorización del Policy Engine y emisión habilitada; reserva la secuencia, guarda el registro (spec §55), publica `identifier_issued` y devuelve `{cuv, identifier_type: "CUV", status: "ACTIVE", checksum_version: "CHK2-V1"}`. Errores: NOT_ADMITTED · PERSON_UNRESOLVED · NOT_AUTHORIZED · ISSUANCE_DISABLED · SEQUENCE_EXHAUSTED · EXISTING_CUV. En el archivo, todo aditivo: `generarCUV` · `validarCUV` (devuelve `codigo`: FORMAT_INVALID, CHECKSUM_INVALID o SEMANTICALLY_INVALID, spec §77) · `decodificarCUV` · `revocarCUV` (patrón de `revocarCUT`) · `cuvAFHIRIdentifier` · `CUV_REGEX`. **Un solo motor (regla tuya, 22-10: «no deben haber copias del motor y parches mucho menos, el motor es 1 solo»):** el CUV es la sección § 13 del `MasterIdentifierService.js` del Proyecto, con su `construirId` y su `calcularCheck2` y sin hash ni imports propios. No hay copias ni parches: el archivo del Proyecto es el motor (en el código, `src/utils/`). El zip de G2 que recibiste el 22-10 (traía una copia del motor y un `.patch`) queda sin uso; lo reemplaza un adjunto con solo las pruebas y los vectores.

**FHIR del CUV — comprobado el 22-10 y completado el 23-10** (tu pregunta, 22-10: «el CUV de masteridentifierservice esta alineado con HL7FHIR? creo que los demas si pero CUV no ?»; te consulté si completar ya `cuvAFHIRIdentifier` o dejarlo para G3 y respondiste «obvio completalo y guarda»; comprobado contra FHIR R4, la tabla HL7 v2 0203, la spec v1.0 §52-56 y el código del motor). *Veredicto del 22-10:* en estructura, el CUV estaba igual de alineado que CUP y CUT y es más estricto (valida el valor antes de armar el `Identifier`); le faltaba un `type` con código. *Hecho el 23-10:* `cuvAFHIRIdentifier` completa, directo en el `MasterIdentifierService.js` del Proyecto; los helpers de las otras familias no se tocaron.
- *Qué pide FHIR (R4):* un `Identifier` lleva `use` (lista fija), `type`, `system` (URI), `value`, `period` y `assigner` (la organización emisora), todos opcionales. `type` tiene binding **extensible** al value set de tipos de identificador (18 códigos en R4): hay que usar uno de ellos solo si alguno aplica; si ninguno cubre el concepto, vale otro código o solo texto.
- *CUV ahora (23-10):* `use: official`; `type` con `coding` (`system` `https://axon-clinical.global/CodeSystem/identifier-type`, `code` `CUV`, `display` «Código Único Voluntario») y `text`; `system` `https://axon-clinical.global/cuv`; `value`; y `period` y `assigner` solo si se pasan. Ninguno de los 18 códigos de HL7 le aplica (el más cercano, `PRN` «Provider number», identifica a prestadores de salud), por eso el código es de AXON: el catálogo `identifier_type` de la spec §56 como CodeSystem FHIR. Hoy solo lo usa el CUV y **todavía no está publicado como recurso FHIR**.
- *`assigner` y `period`:* el código del CUV no trae organización emisora ni vigencia, y el motor no las inventa: las entrega el registro del backend (spec §54-55: `issuer`, `effective_from` y `effective_to`) y, si no se pasan, no se incluyen. `assigner` es una `Reference` de FHIR (`reference`, `type`, `identifier`, `display`; al menos una de `reference`, `identifier` o `display`). `period` lleva `start` y/o `end` como `dateTime` de FHIR (con hora, la zona horaria es obligatoria; una fecha que no existe, como 2026-02-30, se rechaza) y, si ambos traen fecha y hora, `start` no puede ser posterior a `end`. Cualquier otra cosa (opciones desconocidas, `null`, tipos equivocados) lanza `CUVError` y no se corrige en silencio, como el resto del CUV. Ese rigor lo elegí yo dentro de lo que autorizaste: si prefieres algo más laxo, se cambia.
- *Comprobado:* 51 pruebas (12 del FHIR). Los 7 `Identifier` de salida (sin opciones; `period` solo con `start`, con `start` y `end` y solo con `end`; `assigner` por `reference` y `display`, por `identifier`; y con ambos) se contrastaron con un modelo FHIR independiente (`fhir.resources` 8.3.0, R4B; solo se usó en el entorno de pruebas, no es dependencia del proyecto): son válidos como `Identifier` y dentro de un `Practitioner` y de un `Patient`, y no pierden ningún campo. 55 fechas escogidas y 30.000 candidatos al azar dieron el mismo veredicto que ese modelo (0 diferencias) y los días de cada mes coinciden con los del calendario de Python. 115 fallos provocados, 106 detectados y 9 que no cambian el comportamiento («Integrado y probado», arriba). Solo se agregaron líneas: nada de lo existente cambió.
- *Los demás (sin tocar):* de las 15 familias de la v1.0 solo CUP y CUT tienen función FHIR; las otras 13 no tienen ninguna. CUP usa `MR`, que está en el value set y le aplica. CUT usa `EI`, que **no** está en el value set de R4 (existe en la tabla v2 0203 como «Employee number») y solo describe a empleados (ya señalado en §4.2-D). El helper del RUT (no es una de las 15 familias) usa el código `NNxxx` tal cual, pero es la plantilla de la tabla («xxx» = código ISO de 3 letras del país, p. ej. `NNCHL`) y tampoco está en el value set de R4. Los `display` de `MR` («Medical Record Number») y de `EI` («Employee Identifier») tampoco coinciden con los de la tabla («Medical record number», «Employee number»). Ninguno de los tres fija `assigner` ni `period` (son opcionales en FHIR).
- *Recurso destino — propuesta de MAIN para G3, sin decidir:* `Practitioner` con `PractitionerRole` (organización RADE): el alcance de `Practitioner` en R4 incluye «official volunteers». Una `Person` (la identidad canónica de MAIN) enlaza con `Person.link` al `Patient` (CUP) y a un `Practitioner` por ámbito (CUT por tenant, CUV de RADE), coherente con §4.1 (un CUT por tenant o microtenant donde la persona tenga registro).
- *`type` de las otras familias — propuesta, sin decidir:* extender el mismo CodeSystem de AXON a las otras familias con los códigos de §56 (`CUP`, `CUP_RN`, `CUT_TENANT`…), publicarlo como recurso CodeSystem y que CUP conserve `MR` además del código AXON. Así los identificadores AXON se distinguen por máquina sin forzar un código HL7 que no les corresponde. Para el CUV ya está hecho.
- *Namespace:* el `system` de CUP, CUT y CUV usa `https://axon-clinical.global/…`; la spec §54 da `https://id.axon.example/cup` como ejemplo conceptual «o el namespace definitivo que establezca la arquitectura», y ese definitivo no está fijado. Cambiar un `system` después de haber emitido rompe la coincidencia con lo ya enviado a otros sistemas, así que conviene fijarlo antes de la primera emisión. El CodeSystem de AXON usa el mismo dominio y cambiaría junto con él.
- *Falta, con tu OK:* **paso 2, no hecho:** CUT según el tipo de Engagement (§4.3-4), RUT, funciones FHIR para las otras 13 familias, publicar el CodeSystem y CUP con `MR` más el código AXON; todo directo en `MasterIdentifierService.js`, sin copias ni parches. **Para G3 con Workforce:** el recurso destino, quién figura como `assigner` (la organización que emite el código, MAIN, o la que admite al voluntario, RADE) y si se mantiene el código `CUV` del `type`.

**Spec v1.0 → v1.1 — redactado en G1 (22-10):** 18 cambios puntuales (portada, §2, §3, §5, §6, §7, §55 a §58, §70 a §72, §76, §81, §103, §116, §124 y §125) y 4 secciones nuevas, **47-A a 47-D** (identificador, reglas, ciclo de vida, contrato de emisión), sin renumerar porque otros documentos citan §48 a §125 por número. Lo aprobado el 21-10 queda escrito tal cual; lo propuesto va marcado (transiciones y motivos de SUSPENDED y ARCHIVED, valores del registro, y dos detalles de forma).

**Decisiones — D-1 a D-5 cerradas el 21-10**
| # | Decisión | Opciones | Mi recomendación |
|---|---|---|---|
| D-1 · decidida 21-10 | Nombre oficial (la sigla no cambia) | «Código Único Voluntario» (11-10) o «Código Único de Voluntariado» (tu mensaje del 20-10) | **Decidida: «Código Único Voluntario»** (el del 11-10): paralelo a Trabajador (CUT) y Paciente (CUP); Workforce lo define como identificador de la participación del voluntario |
| D-2 · decidida 21-10 | Alcance y readmisión | (A) **un CUV por persona y ámbito RADE**, estable aunque se retire y vuelva (los episodios viven en Workforce); un CUV revocado nunca se reactiva: si esa persona vuelve a ser admitida, se emite uno nuevo · (B) un CUV nuevo por cada admisión | **Decidida: A.** Calza con v2.1 §1 y con la regla del CUT (uno por registro y ámbito, §4.1); B multiplica los códigos de una misma persona |
| D-3 · decidida 21-10 | Ámbito de RADE (la pregunta abierta de Workforce) | (A) **un código de ámbito para todo RADE**; sus unidades regionales y sus 9 equipos son nodos internos (OrgNode), como una sucursal no es un tenant (spec §68, §118) · (B) un código por organización nacional de RADE | **A, con tu formato:** el ámbito único es `AXONRADE` (MAIN lo leyó como el valor fijo del tercer segmento; corrígeme si no). El formato soporta (B) si RADE algún día lo pide |
| D-4 · decidida 21-10 | Estructura y capacidad | (A) **`CUV-{ISO2}-{REG}-{AXONRADE}-{SEQ6}-{CHK2}`** · (B) con SEQ4 como el CUT (tope de 9.999 por ámbito, el agotamiento que Workforce ya observó) · (C) sin REG (regionalizar después sería un cambio de formato con migración) | **A, con tu formato** (SEQ6 con REG). Tras el primer CUV emitido el formato queda congelado (spec §4 y §121) |
| D-5 · decidida 21-10 | Identificador temporal del expediente de candidatura | (A) **interno de RADE o Workforce**, nunca mostrado como CUV · (B) una familia propia del motor | **Decidida: A.** No registra en MAIN a personas aún no admitidas ni suma otra familia (§120) |

**Qué falta (23-10).** *Decisiones:* ninguna abierta (la del FHIR la cerraste el 22-10: «obvio completalo y guarda»). *Hecho el 22-10:* G1 (adjunto) y el CUV en el motor único (§ 13), con sus pruebas y vectores en otro adjunto. *Hecho el 23-10:* `cuvAFHIRIdentifier` completa en el motor (ver «FHIR del CUV», arriba) y las pruebas y vectores actualizados en un adjunto nuevo (51 pruebas). *Siguen, en orden y con tu OK en cada compuerta:* G3 revisión con Workforce y RADE → G4 entrega a Workforce (la haces tú) → G5 corregir menciones → G6 backend. *Para G3 hay 9 puntos* (lista en G1 §6): recurso destino de FHIR, quién figura como `assigner` y confirmar el código `type` `CUV` (Workforce; propuesta de MAIN en «FHIR del CUV», arriba), autoridad que «admite» y origen de `admission_id`, cómo se fija `REG`, motivos y transiciones de SUSPENDED y ARCHIVED, reserva efectiva de `AXONRADE`, contador del backend, valores propuestos del registro, seguridad (el código revela la pertenencia a RADE) y clasificación jurídica. *Antes de emitir:* lo de abajo. *Fuera del CUV:* lo no procesado de la v2.1 (§10).

**Antes de emitir (no ahora):** (1) reservar `AXONRADE` en el registro central (§4.3-2) para que ningún tenant lo use (hallazgo de las pruebas, arriba): RADE no es un tipo de tenant en `tenantTypes.config.js` (20 tipos del 31-08, todos sanitarios) y, con un ámbito único, lo natural es registrarlo como ámbito de plataforma (Capa 0), como el literal `AXON` del CUT de AXON Health (aprobado el 21-10); falta la reserva efectiva en el registro del backend; no cambia el formato · (2) cómo se fija `REG` (donde se admite) · (3) qué rol de RADE es la autoridad que «admite» (origen de `admission_id`). Hecho el 22-10 (ampliado el 23-10: 51 pruebas, con el FHIR): pruebas con `node:test` (el `package.json` del Proyecto es el de `axon-core-api` y no declara runner; el paquete de pruebas trae el suyo), vectores en un JSON reutilizable por Workforce y otros lenguajes (spec §80-81) y un verificador independiente en Python; van en un adjunto aparte, sin copia del motor.

**Plan con compuertas** (no avanzo sin tu OK): **G0** tus decisiones (hecho el 21-10) → **G1** texto de la spec v1.1 (entregado el 22-10) → **G2** el CUV dentro del motor único + vectores + pruebas (hecho el 22-10, directo en `MasterIdentifierService.js` y sin copias ni parches, por tu regla de motor único; FHIR completado el 23-10) → **G3** revisión con Workforce y RADE → **G4** entrega a Workforce (la haces tú, v2.1 §8-B1) → **G5** corregir las menciones señaladas abajo → **G6** registro y contador transaccionales (backend; habilitan la emisión). G1 y las pruebas con vectores van como adjuntos, no como documentos nuevos del Proyecto; el motor se edita en su propio archivo.

**Los 7 puntos de Workforce (v2.1 §2):** 1 tenant de 8 letras → §4.2-A y §4.3-1, ya decidido; el CUV nace estricto y aplicarlo a `generarCUT` queda fuera de esta etapa · 2 reserva y unicidad central → §4.3-2 (backend) · 3 consistencia del CUT de AXON Health → §4.3, patch decidido 11-10, fuera de esta etapa · 4 `identifier_type` → R-CUV-8 y §4.2-D · 5 secuencias e idempotencia → R-CUV-5 y 9; backend en G6 · 6 pruebas con vectores → las del CUV; el resto después · 7 **familia CUV → esta sección.** Propuesta: CUV primero como cambio aditivo del motor; los puntos 1 a 6 como segundo cambio, salvo que decidas juntarlos.

**Señalado, sin resolver en silencio**
- Catálogo §5, UnitShell §6.5 (dos veces) y mi nota de memoria del 14-10 dicen que el motor ya cubre el CUV; el 21-10 no era así (se sumó el 22-10, § 13). La nota de memoria ya quedó anotada; Catálogo y UnitShell se corrigen a «CUV en el motor (§ 13), sin emisión hasta G6» cuando lo apruebes (G5). UnitShell §4 y §8 lo dan por «pausado»: se retomó el 20-10.
- «Voluntario» (11-10) frente a «voluntariado» (tu mensaje del 20-10): resuelto en D-1 (21-10) a favor de «Voluntario». MAIN dijo «Engagement tipo VOLUNTEER» (§5.1) y Workforce «participación voluntaria como entidad separada de Worker/Employment» (v2.1 §1 y §5): compatibles si Engagement es el concepto general; lo confirmo con el contrato MAIN–Workforce–UnitShell.
- Contador del CUV: la decisión D-4 lo da «por (ISO2, REG)» y la regla R-CUV-5 «por (ISO2, REG, ámbito)». G1 usa la segunda, que es la regla aprobada y equivale a la primera mientras `AXONRADE` sea el único ámbito; si prefieres la primera, se cambia en G1.
- Quedan tres cosas a tu criterio (detalle en el LEEME de las pruebas y, las dos primeras, en G1 §5): `validarCUV` lanza error si se le pasa mal la lista de ámbitos, en vez de saltarse el control en silencio; los comentarios «los 15 identificadores» del motor no se tocaron (15 es lo que define la spec v1.0; pasan a 16 cuando se apruebe la v1.1); y `cuvAFHIRIdentifier` rechaza con error las opciones desconocidas, el `null` y los valores mal formados de `assigner` y `period` en vez de corregirlos (23-10).
- G1 (adjunto del 22-10) habla de «parche» y de una copia de trabajo en su §5 y §8; además, en lo de FHIR dice que el `type` queda solo con texto y que el código y el recurso destino se definen con Workforce (regla 8, el párrafo «FHIR (§52 y §54)», las decisiones de diseño de su §5 y el punto 1 de G3), y cuenta «41 pruebas» y «24 fallos a propósito». Vale lo de esta sección: el CUV ya está en el motor único y su `type` ya lleva el código `CUV`. Ese texto se ajusta al armar la spec v1.1, o antes si me lo pides.
- El paquete de pruebas que recibiste el 22-10 (41 pruebas) quedó desactualizado: su prueba del FHIR espera el `type` solo con texto y falla contra el motor actual (40 de 41 en verde). Lo reemplaza el del 23-10 (51 pruebas); el del 22-10 no hay que usarlo.
- R-CUV-8 cambió de alcance: el 21-10 se aprobó con «`type` por definir con Workforce»; el 22-10 pediste completar la función FHIR y MAIN le puso el código `CUV` (CodeSystem de AXON). Como nada está emitido, Workforce puede pedir otro código en G3 sin migración; lo dejo anotado en vez de darlo por resuelto.
- §4.3 (arreglos del motor para el CUT de AXON Health y los otros tres) está escrito como «patch para el equipo satélite»; con tu regla de motor único esos arreglos también irían directo al motor. Siguen fuera de esta etapa y no los toqué: dime cuándo.
- La v2 de Workforce (con el Anexo de vectores) no está en el Proyecto; no bloquea, pero si trae vectores de CUV hay que cruzarlos.
- `crypto-js@4.2.0`, del que depende `calcularCheck2`, figura **deprecado en npm** («no longer maintained»). No bloquea el CUV; conviene anotarlo en el Stack.
- Contraste externo (no es norma para AXON): NIMS define la credencialización como verificar identidad y atributos de quienes responden (USFA, rev. 1-may-2026) y ESAR-VHP verifica identidad, licencias y credenciales de voluntarios de salud «antes de una emergencia» (ASPR TRACIE); es consistente con separar el registro del despliegue, pero ninguna habla de identificadores propios.

Sources: Workforce «Actualización para MAIN v2.1» (adjunto del 20-10) · `AXON_Identificadores_Universales_v1_0.docx` · `MasterIdentifierService.js` (27-09) · [NIMS: Credentialing — USFA](https://www.usfa.fema.gov/a-z/nims/credentialing.html) · [ESAR-VHP — ASPR TRACIE](https://asprtracie.hhs.gov/technical-resources/resource/2938/emncy-system-for-advance-registration-of-volunteer-health-professionals-esar-vhp) · [FHIR R4 — Datatypes (Identifier)](https://hl7.org/fhir/R4/datatypes.html) · [FHIR R4 — ValueSet identifier-type](https://www.hl7.org/fhir/R4/valueset-identifier-type.json.html) · [FHIR R4 — Practitioner](https://hl7.org/fhir/R4/Practitioner.html) · [FHIR R4 — Person](https://hl7.org/fhir/R4/Person.html) · [HL7 v2, tabla 0203 (hl7.eu)](https://hl7.eu/HL7v2x/v24/hl7v24tab0203.htm) · [FHIR — fuerza del binding «extensible» (STU3)](https://www.hl7.org/fhir/STU3/codesystem-binding-strength.xml.html) · [fhir.resources, modelo FHIR en Python (PyPI), usado solo como contraste en las pruebas](https://pypi.org/project/fhir.resources/)

---

## 6 · Separación de catálogos — no deben mezclarse (NUEVO)

Son 5 listas distintas, con referencias y reglas de compatibilidad entre sí, pero **nunca fusionadas**:

| Catálogo | Qué responde | Ejemplo |
|---|---|---|
| Tipo de relación (Engagement) | ¿Qué naturaleza tiene el vínculo? | Empleado, Independiente, Honorario, Contratista, Externo, Subcontratado, Voluntario |
| Cargo (Position) | ¿Qué cargo ocupa? | Médico Radiólogo, Enfermera Clínica, Analista de Presupuesto |
| Rol de autorización (Role) | ¿Qué función operativa puede ejercer? | Rol clínico UCI, Rol de aprobación financiera |
| Asignación organizacional | ¿En qué unidad/subunidad se desempeña? | Imagenología, UCI, Finanzas |
| Asignación operativa | ¿Qué turno/actividad/ubicación concreta? | Turno UCI noche, MRI-01 |

Un médico puede tener: relación de empleo + cargo de Médico Radiólogo + asignación en Imagenología + rol clínico + turno en una ubicación concreta — **ningún atributo reemplaza a los demás.** Nota no bloqueante que sigue pendiente: cuando se retome `roles.config.js`, cruzarlo contra este catálogo de relaciones (siguen siendo 2 listas sin cruzar).

---

## 7 · Calendarios — propietario por dominio (NUEVO)

Un calendario institucional unificado es útil para la experiencia de usuario, pero **no implica una única fuente de verdad.** Cada evento conserva su propietario y su ciclo de vida:

| Dominio | Propietario de la información |
|---|---|
| Fechas, zona horaria, reglas calendáricas comunes | Servicio transversal de calendario/tiempo de MAIN |
| Turnos laborales, asistencia y ausencias | Workforce |
| Agenda de pacientes, cupos y recursos asistenciales | Scheduling/Agenda Engine |
| Reuniones y acuerdos formales de gobernanza | Dominio de reuniones y gobernanza (`dir_secretaria`) |
| Inscripción y cumplimiento de capacitaciones | Workforce, o el dominio de capacitación que se defina |

La vista consolidada puede agregar eventos de todas las fuentes; los cambios, cancelaciones, auditoría y efectos sobre otros motores los decide el propietario de cada evento, no la vista.

---

## 8 · Nomenclatura "AXON HOLDING FAMILY'S" — resuelto

Sin cambios respecto de la versión anterior: es real, pero fuera de alcance de este proyecto. jdiazH confirmó que es el holding corporativo por encima de AXON Clinical Advance, con otras líneas AXON no sanitarias. No se mezcla con esta arquitectura.

---

## 9 · Verificación legal externa

### 9.1 Ley Karin (21.643) — flujo de gestión de casos para Workforce

Confirmado contra Biblioteca del Congreso Nacional y Dirección del Trabajo: Workforce necesita un **motor transversal de gestión de casos laborales**, no un formulario de denuncias. Flujo de 6 etapas:

**A. Recepción y clasificación** → denuncia/relato/incidente/derivación, con fecha, canal, responsable.
**B. Protección inmediata y evaluación de riesgo** → medidas de resguardo (separación de espacios, redistribución de jornada, atención psicológica temprana vía organismo administrador), conflictos de interés, conservación de antecedentes.
**C. Clasificación jurídica y selección de procedimiento** → determina la rama (tabla abajo) y el régimen aplicable.
**D. Investigación** → investigador imparcial, citaciones, entrevistas, pruebas, análisis del entorno. Si es investigación interna: por escrito, reserva estricta, ambas partes oídas, **30 días** (Art. 211-C); alternativa: derivar a Inspección del Trabajo dentro de **3 días**.
**E. Conclusión y plan correctivo** → resolución de autoridad competente, medidas correctivas, sanciones cuando procedan, remisión a Inspección del Trabajo para pronunciamiento.
**F. Seguimiento y cierre** → cumplimiento, reincidencias, vencimientos, evidencia, cierre auditable.

**Ramas que el motor debe soportar (no todas recorren el mismo procedimiento):**

| Rama | Qué gestiona Workforce |
|---|---|
| Acoso/violencia que activa el procedimiento legal (Art. 211-C) | Recepción formal, resguardo, investigador imparcial, citaciones, pruebas, tramitación ante autoridad |
| Violencia de terceros (paciente/usuario/proveedor agrede a un trabajador) | Protección, gestión de seguridad/incidente, preservación de evidencia, procedimiento cuando proceda |
| Conflicto interpersonal sin denuncia formal | Evaluación preventiva, mediación cuando corresponda, medidas organizacionales — sin encubrir hechos que ameriten investigación formal |
| Riesgo psicosocial / deficiencia organizacional | Evaluación de condiciones (carga, turnos, supervisión), medidas preventivas |
| Riesgo físico / amenaza grave / posible delito | Seguridad y emergencias, protección inmediata, derivación a autoridades — sin esperar el cierre de la investigación laboral |
| Denuncia contra jefatura/investigador/decisor | Reasignación a persona imparcial, manejo de conflicto de interés |
| Institución pública | Procedimiento administrativo propio (investigación/sumario administrativo) según Ley 21.643 — no forzar el procedimiento privado del Código del Trabajo |

**Matices que se mantienen del hallazgo anterior, reconfirmados:** el cuestionario CEAL-SM/SUSESO es obligatorio para centros de trabajo de **10+ trabajadores** (protocolo de vigilancia de riesgos psicosociales) — con evaluación alternativa para menos de 10; no es una exigencia exclusiva de Ley Karin, es parte del marco más amplio de riesgo psicosicial. La mediación de la DT **no es etapa obligatoria previa** ni sustituye la investigación formal cuando esta es exigible.

**Guardrail de diseño:** las evaluaciones médicas/psicológicas no deben activarse automáticamente como prueba — deben ser pertinentes, justificadas, y a cargo de profesionales competentes. La IA del sistema puede ayudar a organizar antecedentes o detectar vencimientos, **pero no debe decidir credibilidad de una denuncia, culpabilidad, ni sanción.**

**Alcance:** motor transversal para AXON Core y AXON Health (y, en general, cualquier organización con más de 1 trabajador). Core Lite necesita mecanismos de incidentes/reclamación adecuados a la naturaleza real de sus relaciones — no copia automática del procedimiento de un empleador dependiente.

Sources: [Ley Karin — Ministerio de la Mujer y Equidad de Género (PDF)](https://www.cnc.cl/wp-content/uploads/2024/07/11.07.24-Ley-Karin-Ministerio-de-la-Mujer-y-Equidad-de-Genero.pdf) · [Dirección del Trabajo — normativa](https://dt.gob.cl/legislacion/1624/w3-propertyvalue-183738.html)

### 9.2 Ley 21.431 / Core Lite — corrección de la cifra de horas (verificado en 3 fuentes independientes)

Tu propuesta original era "máximo 12 horas diarias de trabajo (no necesariamente continuas), bloqueando la app al superarlas." **Verifiqué contra la Dirección del Trabajo (Dictamen ORD. N°136/07, feb-2026), Carey (alerta legal) y un medio jurídico (Diario Constitucional) — las 3 fuentes coinciden exactamente, y la regla real es otra:**

El artículo 152 quáter Z de la Ley 21.431 no fija un máximo de horas trabajadas para el independiente de plataforma — fija una **garantía de desconexión: al menos 12 horas CONTINUAS sin conexión, dentro de cualquier ventana de 24 horas.** Son controles distintos:

| Control | Qué exige la ley | A quién aplica |
|---|---|---|
| Desconexión de independientes | ≥12 horas **continuas** de desconexión dentro de 24h — sin tope de horas trabajadas en sí | Trabajador independiente de plataforma |
| Jornada de dependientes | Máximo 10 horas **diarias** + máximo semanal (45h, bajando gradualmente a 40h hacia 2028 por Ley 21.561) | Trabajador dependiente con distribución libre de jornada |

**Por qué importa para la implementación:** sumar 12 horas de actividad (continuas o no) **no demuestra** que la persona tuvo 12 horas seguidas desconectada — son cálculos distintos. El diseño correcto no es un contador que bloquea al llegar a 12h acumuladas; es una ventana móvil de 24h que exige detectar un bloque **continuo** de 12h sin conexión en algún punto de esa ventana. Tu objetivo (evitar sobrecarga) sigue siendo válido como política interna adicional — pero no es lo que exige la ley, y conviene separar ambos controles en el diseño:

| Control | Rol en Core Lite |
|---|---|
| Límite interno de exposición | Política propia de AXON, adicional a la ley — libre de definir |
| Desconexión legal (independientes) | Bloque continuo de 12h sin conexión dentro de cada ventana de 24h, exigible por ley cuando aplique |
| Jornada de dependientes | 10h diarias + semanal — nunca 12h si el régimen aplicable es de dependiente |
| Registro de jornada | Sesiones, disponibilidad, servicios, desconexiones — distinguiendo horas efectivas de jornada pasiva |
| Bloqueo efectivo | Validado en backend, no solo en la interfaz |

**RESUELTO 11-10, por decisión directa tuya — corrige el hallazgo del 08-10:** confirmaste que Core Lite **sí** cae dentro del alcance de la Ley 21.431 — es, a la vez, obligación legal y política adoptada por AXON Core Lite. El hallazgo del 08-10 (desde el PDF de líneas AXON, que la daba por excluida) queda corregido — lo dejo anotado como corrección, no borrado en silencio, porque es exactamente el tipo de inconsistencia entre sesiones que se marca en vez de resolverse sola.

**Precisión de diseño que agregaste:** el trabajador **elige la hora** de su ventana de desconexión — no se le impone un horario fijo. El sistema solo interviene si excede la conexión continua más allá del punto en que ya no cabe un bloque de 12h continuas de desconexión dentro de la ventana móvil de 24h. Es el diseño de "ventana móvil + bloque continuo", no un contador de horas acumuladas (tabla de controles arriba, fila "Bloqueo efectivo") — el backend bloquea solo ante ese exceso, nunca por elegir un horario distinto cada día.

La recomendación de revisión por un abogado laboral chileno (ver versión anterior de este documento) queda como buena práctica general para blindar la clasificación de Core Lite, pero ya no es condición para avanzar — la decisión de diseño está tomada.

Sources: [Dirección del Trabajo — Dictamen 1831/39 y ORD. 136/07](https://dt.gob.cl/legislacion/1624/w3-propertyvalue-183738.html) · [Carey — entrada en vigencia Ley 21.431](https://www.carey.cl/api/archivo/entra-en-vigencia-ley-que-regula-el-contrato-de-trabajadores-plataformas-digitales-de-servicios?lang=es) · [Diario Constitucional — aplicación Ley 21.561 a plataformas](https://www.diarioconstitucional.cl/2026/02/27/aplicacion-de-la-ley-n21-561-jornada-laboral-y-remuneraciones-en-trabajadores-de-plataformas-digitales/)

### 9.3 Nota — identificación de órganos para trasplante (fuera de alcance de Workforce)

Mencionado de pasada en el mismo intercambio, explícitamente "para más adelante" según tus propias palabras. No es tema de Workforce — queda registrado como requisito arquitectónico futuro en `current-state.md` (dominio de trazabilidad clínica/biológica, no de identidad de trabajador) para no perderlo, sin desarrollarlo aquí.

### 9.4 Principio reforzado: reglas jurisdiccionales como registro versionado

Ambas correcciones de esta sección (Ley Karin y Ley 21.431) refuerzan el mismo principio ya anotado en §2: país, régimen, vigencia y fuente normativa deben ser **datos versionados** en un registro de MAIN (fuente, jurisdicción, vigencia, fecha de revisión, versión, parámetros, reglas de aplicación) — nunca condicionales tipo `if country == Chile` dispersos en JSX o backend. Las interpretaciones que requieren validación jurídica deben marcarse como tales, no convertirse en regla rígida por decisión de desarrollo.

---

## 10 · Qué sigue

Con §4, §5 y §4.3 resueltos el 11-10 (CUT de AXON Health, concepto y flujo del CUV, Core Lite/Ley 21.431), el modelo conceptual sigue cerrado. **El 21-10 quedaron cerradas las decisiones del CUV (§5.3, D-1 a D-5) y aprobadas sus reglas**; mientras no se apruebe la spec v1.1 y no exista el backend con registro y contador (G3 a G6; G1 está entregado como borrador y el CUV ya está en el motor, §5.3), la emisión de CUV sigue bloqueada (v2.1 §1). El equipo satélite tiene lo necesario para esquemas/APIs/eventos, incluido el patch del motor de §4.2-§4.3.

**De la v2.1 de Workforce queda sin procesar** (no se tocó; solo se vio el CUV): Core Lite con un único titular y las reglas de colaboración (v2.1 §3; corrige el Maestro §75-76) · propiedad por objeto del contrato MAIN–Workforce–UnitShell (§4) · separación entre participación y empleo en la taxonomía (§5) · Ley Karin, ORD. N.º 146/13 de la DT del 24-feb-2026 (§6; verificado por Workforce en dt.gob.cl, MAIN aún no lo verificó) · tope interno de 12 h diarias en Core Lite y divisor transitorio de 174 h del piso de honorarios (§7) · solicitudes técnicas C1 y C3 a C7 (§8; C6 y C7 tocan al motor de identificadores y se tratarán con los puntos 1 a 6). Nota no bloqueante: cruzar `roles.config.js` contra el catálogo de relaciones (§6) cuando se retome.
