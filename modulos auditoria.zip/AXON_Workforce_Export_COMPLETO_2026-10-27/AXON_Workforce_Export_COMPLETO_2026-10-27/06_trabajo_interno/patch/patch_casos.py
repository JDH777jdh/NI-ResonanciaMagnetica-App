import re, sys
P = '/mnt/user-data/outputs/workforce/WorkforceCasosLaborales.jsx'
CRED = '/mnt/user-data/outputs/workforce/WorkforceCredenciales.jsx'
t = open(P, encoding='utf-8').read()
cred = open(CRED, encoding='utf-8').read().split('\n')

def once(old, new, label):
    global t
    n = t.count(old)
    assert n == 1, f'[{label}] esperaba 1 coincidencia y hay {n}'
    t = t.replace(old, new)

def block(start, end, new, label):
    global t
    i = t.find(start); assert i >= 0 and t.count(start) == 1, f'[{label}] inicio no único/ausente'
    j = t.find(end, i + len(start)); assert j >= 0, f'[{label}] fin ausente'
    t = t[:i] + new + t[j:]

# ── 0. Registro canónico (P0: marcador sin resolver) ───────────────────────────
ini = next(k for k, l in enumerate(cred) if l.startswith('/* ---------------------------- identificadores (CUT provisional'))
fn = next(k for k, l in enumerate(cred) if l.startswith('export function generarPersonasCanonico'))
fin = next(k for k in range(fn, len(cred)) if cred[k] == '}')
roster = '\n'.join(cred[ini:fin + 1])
assert 'function calcDV' in roster and 'function makeCUT' in roster and 'return personas;' in roster
once('/*@@ROSTER@@*/', roster, 'roster')

# ── 1. Eventos: decisión ≠ cumplimiento ───────────────────────────────────────
block('export const EVENTOS = [', 'export const PROCEDIMIENTOS = {', r'''export const EVENTOS = [
  'denuncia_recibida', 'investigacion_iniciada', 'derivado_a_dt', 'investigacion_concluida',
  'informe_remitido_dt', 'conclusiones_dt_notificadas',
  'medidas_correctivas_aplicadas', // solo con medidas realmente aplicadas
  'decision_sin_medidas', // decisión fundamentada de NO aplicar medidas: otro hecho, con otro criterio de cumplimiento
];
export const REGIMENES = {
  codigo_trabajo: { label: 'Código del Trabajo' },
  estatutario_publico: { label: 'Régimen estatutario público (investigación sumaria o sumario)' },
  por_determinar: { label: 'Por determinar' },
};
''', 'eventos')

once("cumpleCon: ['medidas_aplicadas'], umbrales: { urgente: 3, pronto: 5 }", "cumpleCon: ['medidas_correctivas_aplicadas'], resuelveSinCumplir: ['decision_sin_medidas'], umbrales: { urgente: 3, pronto: 5 }", 'K4')
once('cumpleCon: [], umbrales: { urgente: 1, pronto: 2 }, version: 1,', 'cumpleCon: [], resuelveSinCumplir: [], umbrales: { urgente: 1, pronto: 2 }, version: 1,', 'R defaults')
t = re.sub(r"(\n    if \(\(r\.cumpleCon \|\| \[\]\)\.some\(\(e\) => !EVENTOS\.includes\(e\)\)\) errores\.push\(`\$\{r\.id\}: eventos de cumplimiento inválidos`\);)",
           r"\1\n    if ((r.resuelveSinCumplir || []).some((e) => !EVENTOS.includes(e))) errores.push(`${r.id}: eventos de resolución sin cumplimiento inválidos`);", t, count=1)
assert 'resolución sin cumplimiento inválidos' in t

# ── 2. Acceso: tenant, relación vigente, conflictos, rol del caso ────────────
block('export function evaluarAcceso(caso, actor, permiso) {', 'function exigir(caso, actor, permisos) {', r'''export function evaluarAcceso(caso, actor, permiso) {
  const pid = actor?.personaId;
  const deny = (motivo, roles = []) => ({ permitido: false, motivo, roles });
  if (!pid) return deny('Actor no identificado');
  // Contexto institucional y relación vigente. DEMOSTRACIÓN: en producción los resuelve el backend (MAIN), nunca el cliente.
  if (caso.tenantId && actor.tenantId !== caso.tenantId) return deny('Aislamiento por tenant: el actor no pertenece al tenant del caso');
  if (actor.relacionVigente !== true) return deny('Sin relación vigente con el tenant: el acceso se evalúa con la relación activa, no con el historial');
  if (caso.conflictos.some((c) => c.personaId === pid)) return deny('Persona con conflicto de interés declarado en este caso');
  const roles = rolesEnCaso(caso, pid);
  if (!roles.length) return deny('Sin rol asignado en el caso: expediente reservado', roles);
  const ok = roles.some((r) => PERMISOS_POR_ROL[r]?.[permiso]);
  return { permitido: ok, motivo: ok ? null : `El rol (${roles.join(', ')}) no permite «${permiso}»`, roles };
}
''', 'acceso')
t = re.sub(r"medidasQueLeAplican: caso\.medidasResguardo\.filter\(\(m\) => m\.destinatarioId === ref\)\.map\(\(m\) => \(\{ id: m\.id, tipo: m\.tipo, aplicadaEn: m\.aplicadaEn \}\)\),",
           "medidasQueLeAplican: caso.medidasResguardo.filter((m) => m.destinatarioId === ref && ['ordenada', 'implementada'].includes(m.estado)).map((m) => ({ id: m.id, tipo: m.tipo, estado: m.estado, ordenadaEn: m.ordenadaEn, implementadaEn: m.implementadaEn })),", t, count=1)
assert "['ordenada', 'implementada'].includes(m.estado)).map" in t

# ── 3. Máquina de estados central ──────────────────────────────────────────────
block('function aplicar(caso, cambios, meta) {', 'const maxFecha', r'''export const puedeTransicionar = (desde, hacia) => desde === hacia || (TRANSICIONES[desde] || []).includes(hacia);
function aplicar(caso, cambios, meta) {
  if (cambios.estado !== undefined && !puedeTransicionar(caso.estado, cambios.estado)) return err(`Transición no permitida: ${caso.estado} → ${cambios.estado}`, { transicionInvalida: true });
  const e = entrada(caso, meta);
  return { caso: { ...caso, ...cambios, version: caso.version + 1, historial: [...caso.historial, e] }, auditoria: e };
}
''', 'aplicar')

# ── 4. Enrutamiento por RÉGIMEN, no por sector del tenant ─────────────────────
block('export function evaluarEnrutamiento(caso) {', 'export function crearCaso(d, hoyISO) {', r'''export function evaluarEnrutamiento(caso) {
  const rama = RAMAS[caso.ramaId];
  if (!rama) return { error: 'El caso no está clasificado.' };
  let permitidos = [...rama.procedimientos];
  if (caso.procedimientoLegal && rama.procedimientosSiLegal) permitidos = [...new Set([...permitidos, ...rama.procedimientosSiLegal])];
  let obligatorio = null;
  const motivos = [], acciones = [];
  if (rama.inmediata || caso.evaluacionInicial?.riesgo === 'inmediato') acciones.push('activar_seguridad_y_emergencias', 'derivar_a_autoridades_sin_esperar_la_investigacion_laboral');
  if (caso.procedimientoLegal) {
    // La ruta depende del RÉGIMEN jurídico de las partes, que se determina caso a caso: el sector del tenant no decide.
    if (caso.regimenJuridico === 'estatutario_publico') {
      obligatorio = 'procedimiento_administrativo'; permitidos = ['procedimiento_administrativo'];
      motivos.push('Régimen estatutario público: corresponde el procedimiento administrativo de su estatuto (investigación sumaria o sumario), con plazos propios que este paquete no modela. Confirmar con abogado.');
    } else if (caso.denunciado?.relacion === 'art4_inc1') {
      obligatorio = 'derivacion_dt'; permitidos = ['derivacion_dt'];
      motivos.push('La denuncia se dirige a una persona del art. 4, inc. 1.º del Código del Trabajo: debe remitirse a la Dirección del Trabajo (ORD. N.º 146/13, 24-feb-2026).');
    }
  }
  return { ramaId: caso.ramaId, regimenJuridico: caso.regimenJuridico, permitidos, obligatorio, motivos, acciones, requiereInvestigadorImparcial: !!rama.imparcial && permitidos.includes('investigacion_interna') };
}

''', 'enrutamiento')
once('ramaId: null, procedimientoLegal: false, procedimiento: null,', "ramaId: null, procedimientoLegal: false, procedimiento: null, regimenJuridico: 'por_determinar', regimenInferido: false,", 'crearCaso regimen')

block('export function clasificarCaso(caso, { ramaId, activaProcedimientoLegal, motivo, actor }, hoyISO) {', '// ORD. N.º 146/13 (DT, 24-feb-2026): una denuncia inconsistente', r'''export function clasificarCaso(caso, { ramaId, activaProcedimientoLegal, regimenJuridico, motivo, actor }, hoyISO) {
  const e = noCerrado(caso) || exigir(caso, actor, ['registrar']);
  if (e) return e;
  if (caso.estado === 'por_complementar') return err('La denuncia está por complementar: registre el complemento o continúe sin él antes de clasificar.');
  const rama = RAMAS[ramaId];
  if (!rama) return err('Rama desconocida.');
  if (!motivo) return err('La clasificación requiere motivo (queda en el historial).');
  const legal = activaProcedimientoLegal === undefined ? !!rama.legalPorDefecto : !!activaProcedimientoLegal;
  if (legal && !rama.legalPorDefecto && !rama.procedimientosSiLegal) return err('Esta rama no activa el procedimiento legal: reclasifique a la rama que corresponda.');
  if (!legal && rama.legalPorDefecto) return err('La rama de acoso o violencia legal requiere el procedimiento legal; si los hechos no lo configuran, reclasifique.');
  if (regimenJuridico !== undefined && !['codigo_trabajo', 'estatutario_publico'].includes(regimenJuridico)) return err('Régimen jurídico inválido (codigo_trabajo o estatutario_publico).');
  // Régimen: se declara; solo se asume Código del Trabajo en tenants privados, y queda marcado como inferido.
  let regimen = regimenJuridico || (caso.regimenJuridico !== 'por_determinar' ? caso.regimenJuridico : null);
  let inferido = regimenJuridico ? false : caso.regimenInferido;
  if (!regimen && legal) {
    if (caso.sectorTenant === 'publico') return err('Institución pública: determine expresamente el régimen jurídico aplicable (estatutario público o Código del Trabajo); el sector del tenant por sí solo no decide la ruta.');
    regimen = 'codigo_trabajo'; inferido = true;
  }
  regimen = regimen || 'por_determinar';
  const enr = evaluarEnrutamiento({ ...caso, ramaId, procedimientoLegal: legal, regimenJuridico: regimen });
  const advertencias = [];
  if (caso.procedimiento && !enr.permitidos.includes(caso.procedimiento)) advertencias.push('El procedimiento ya seleccionado no está permitido con la nueva clasificación: revisar.');
  if (inferido) advertencias.push('Régimen jurídico asumido como Código del Trabajo por tratarse de un tenant privado: confirmar.');
  const clas = { version: caso.clasificaciones.length + 1, ramaId, procedimientoLegal: legal, regimenJuridico: regimen, regimenInferido: inferido, motivo, por: actor.personaId, en: hoyISO };
  const r = aplicar(caso, { ramaId, procedimientoLegal: legal, regimenJuridico: regimen, regimenInferido: inferido, clasificaciones: [...caso.clasificaciones, clas], estado: caso.estado === 'recibida' ? 'clasificada' : caso.estado },
    { accion: 'clasificar_caso', actor, hoyISO, anterior: { ramaId: caso.ramaId, procedimientoLegal: caso.procedimientoLegal, regimenJuridico: caso.regimenJuridico }, nuevo: { ramaId, procedimientoLegal: legal, regimenJuridico: regimen }, motivo });
  return { ...r, advertencias, enrutamiento: enr };
}

''', 'clasificar')

# ── 5. Medidas de resguardo: propuesta → ordenada → implementada ────────────────
block('export function agregarMedidaResguardo(', 'export function registrarEvaluacionInicial(', r'''export const ESTADOS_MEDIDA_RESGUARDO = {
  propuesta: { label: 'Propuesta' }, ordenada: { label: 'Ordenada' }, implementada: { label: 'Implementada' }, descartada: { label: 'Descartada' },
};
const buscarMedidaResguardo = (caso, id) => caso.medidasResguardo.find((m) => m.id === id);
const cambiarMedidaResguardo = (caso, id, patch) => caso.medidasResguardo.map((m) => (m.id === id ? { ...m, ...patch } : m));
// Una propuesta NO es una medida aplicada: solo la ordena quien decide, y solo cuenta como aplicada cuando hay implementación con evidencia.
export function proponerMedidaResguardo(caso, { tipo, destinatarioId, fundamento, actor }, hoyISO) {
  const e = noCerrado(caso) || exigir(caso, actor, ['registrar']);
  if (e) return e;
  if (!TIPOS_MEDIDA_RESGUARDO[tipo]) return err('Tipo de medida de resguardo inválido.');
  if (!destinatarioId) return err('Indique a quién se aplicaría la medida.');
  if (!fundamento) return err('Indique el fundamento de la medida.');
  const medida = { id: `r${caso.medidasResguardo.length + 1}`, tipo, destinatarioId, fundamento, estado: 'propuesta', propuestaEn: hoyISO, propuestaPor: actor.personaId, ordenadaEn: null, ordenadaPor: null, implementadaEn: null, evidenciaRef: null };
  const r = aplicar(caso, { medidasResguardo: [...caso.medidasResguardo, medida] }, { accion: 'proponer_medida_resguardo', actor, hoyISO, nuevo: { id: medida.id, tipo, destinatarioId }, motivo: fundamento });
  return { ...r, medidaId: medida.id };
}
export function ordenarMedidaResguardo(caso, { medidaId, actor }, hoyISO) {
  const e = noCerrado(caso) || exigir(caso, actor, ['decidir']);
  if (e) return e;
  const m = buscarMedidaResguardo(caso, medidaId);
  if (!m) return err('Medida de resguardo no encontrada.');
  if (m.estado !== 'propuesta') return err(`Solo se ordena una medida propuesta (estado actual: ${m.estado}).`);
  return aplicar(caso, { medidasResguardo: cambiarMedidaResguardo(caso, medidaId, { estado: 'ordenada', ordenadaEn: hoyISO, ordenadaPor: actor.personaId }) },
    { accion: 'ordenar_medida_resguardo', actor, hoyISO, anterior: { estado: 'propuesta' }, nuevo: { id: medidaId, estado: 'ordenada' } });
}
export function implementarMedidaResguardo(caso, { medidaId, fecha, evidenciaRef, actor }, hoyISO) {
  const e = noCerrado(caso) || exigir(caso, actor, ['registrar', 'decidir']);
  if (e) return e;
  const m = buscarMedidaResguardo(caso, medidaId);
  if (!m) return err('Medida de resguardo no encontrada.');
  if (m.estado !== 'ordenada') return err('Solo se implementa una medida ordenada: una propuesta no equivale a una medida aplicada.');
  if (!esReferencia(evidenciaRef)) return err('Indique solo una referencia a la evidencia de implementación.');
  const f = fecha || hoyISO;
  if (!fechaValida(f) || f > hoyISO || f < m.ordenadaEn) return err('Fecha de implementación inválida.');
  return aplicar(caso, { medidasResguardo: cambiarMedidaResguardo(caso, medidaId, { estado: 'implementada', implementadaEn: f, evidenciaRef }) },
    { accion: 'implementar_medida_resguardo', actor, hoyISO, anterior: { estado: 'ordenada' }, nuevo: { id: medidaId, estado: 'implementada', implementadaEn: f } });
}
export function descartarMedidaResguardo(caso, { medidaId, fundamento, actor }, hoyISO) {
  const e = noCerrado(caso) || exigir(caso, actor, ['decidir']);
  if (e) return e;
  const m = buscarMedidaResguardo(caso, medidaId);
  if (!m) return err('Medida de resguardo no encontrada.');
  if (!['propuesta', 'ordenada'].includes(m.estado)) return err(`No se puede descartar una medida ${m.estado}.`);
  if (!fundamento) return err('Indique el fundamento del descarte.');
  return aplicar(caso, { medidasResguardo: cambiarMedidaResguardo(caso, medidaId, { estado: 'descartada' }) },
    { accion: 'descartar_medida_resguardo', actor, hoyISO, anterior: { estado: m.estado }, nuevo: { id: medidaId, estado: 'descartada' }, motivo: fundamento });
}
''', 'resguardo')

block('export function registrarEvaluacionInicial(', 'export function asignarRol(', r'''export function registrarEvaluacionInicial(caso, { riesgo, urgenciaProteccion = false, riesgoRepresalias = false, decisionMedidas, fundamentoNoMedidas, actor }, hoyISO) {
  const e = noCerrado(caso) || exigir(caso, actor, ['registrar']);
  if (e) return e;
  if (!['clasificada', 'evaluacion_inicial'].includes(caso.estado)) return err('La evaluación inicial se registra después de clasificar el caso.');
  if (!RIESGOS.includes(riesgo)) return err('Riesgo inválido.');
  if (!['aplicadas', 'no_requeridas'].includes(decisionMedidas)) return err('Documente la decisión sobre las medidas de resguardo (aplicadas o no requeridas).');
  if (decisionMedidas === 'no_requeridas' && !fundamentoNoMedidas) return err('Si no se aplican medidas de resguardo, fundamente la decisión.');
  if (decisionMedidas === 'no_requeridas' && riesgo === 'inmediato') return err('Con riesgo inmediato no puede declararse que no se requieren medidas.');
  const vigentes = caso.medidasResguardo.filter((m) => ['ordenada', 'implementada'].includes(m.estado));
  if (decisionMedidas === 'aplicadas' && !vigentes.length) return err('Se indicó que hay medidas de resguardo, pero ninguna está ordenada o implementada (una propuesta no basta).');
  if (decisionMedidas === 'aplicadas' && riesgo === 'inmediato' && !vigentes.some((m) => m.estado === 'implementada')) return err('Con riesgo inmediato debe haber al menos una medida de resguardo implementada.');
  const ev = { version: caso.evaluaciones.length + 1, riesgo, urgenciaProteccion, riesgoRepresalias, decisionMedidas, fundamentoNoMedidas: fundamentoNoMedidas || null, en: hoyISO, por: actor.personaId };
  return aplicar(caso, { estado: 'evaluacion_inicial', evaluaciones: [...caso.evaluaciones, ev], evaluacionInicial: ev },
    { accion: 'registrar_evaluacion_inicial', actor, hoyISO, anterior: caso.evaluacionInicial ? { riesgo: caso.evaluacionInicial.riesgo } : null, nuevo: { riesgo, decisionMedidas } });
}

''', 'eval inicial')

# ── 6. Procedimiento: individualización también al derivar a la DT ──────────────
block('export function seleccionarProcedimiento(', 'export function iniciarInvestigacion(', r'''export function seleccionarProcedimiento(caso, { procedimiento, fundamento, actor }, hoyISO) {
  const e = noCerrado(caso) || exigir(caso, actor, ['decidir']);
  if (e) return e;
  if (!['evaluacion_inicial', 'procedimiento_seleccionado'].includes(caso.estado)) return err('Primero registre la evaluación inicial y el resguardo (etapa B).');
  if (!PROCEDIMIENTOS[procedimiento]) return err('Procedimiento desconocido.');
  const enr = evaluarEnrutamiento(caso);
  if (!enr.permitidos.includes(procedimiento)) return err(`El procedimiento no está permitido para este caso. Permitidos: ${enr.permitidos.join(', ')}.${enr.motivos.length ? ' ' + enr.motivos.join(' ') : ''}`, { enrutamiento: enr });
  if (!fundamento) return err('Documente por qué se elige ese procedimiento.');
  // ORD. N.º 146/13: individualizar a quien denuncia es requisito para investigar, también cuando el caso se deriva a la DT.
  if (['investigacion_interna', 'derivacion_dt'].includes(procedimiento) && !caso.denunciante.individualizado) {
    return err('Para iniciar una investigación o derivarla a la DT se requiere individualizar a la persona denunciante (ORD. N.º 146/13): solicite el complemento y mantenga medidas generales de resguardo (deber de protección del art. 184).');
  }
  if (procedimiento === 'investigacion_interna' && !caso.asignaciones.investigadorId) return err('Asigne un investigador imparcial antes de seleccionar la investigación interna.');
  return aplicar(caso, { procedimiento, estado: 'procedimiento_seleccionado' },
    { accion: 'seleccionar_procedimiento', actor, hoyISO, anterior: { procedimiento: caso.procedimiento }, nuevo: { procedimiento }, motivo: fundamento });
}
''', 'seleccionar')

# ── 7. Decisión ≠ cumplimiento ──────────────────────────────────────────────────
once('cambios.eventos = { ...caso.eventos, medidas_aplicadas: maxFecha(medidas.map((x) => x.aplicadaEn)) };', 'cambios.eventos = { ...caso.eventos, medidas_correctivas_aplicadas: maxFecha(medidas.map((x) => x.aplicadaEn)) };', 'evento aplicadas')
once('eventos: { ...caso.eventos, medidas_aplicadas: hoyISO }, estado:', 'eventos: { ...caso.eventos, decision_sin_medidas: hoyISO }, estado:', 'evento sin medidas')

block('export function verificarCierre(', 'export function cerrarCaso(', r'''export function verificarCierre(caso, motivoCierre, hoyISO, pack = PAQUETE_REGLAS_CL_BORRADOR, cal = CALENDARIO_CL) {
  const b = [], adv = [];
  if (caso.estado === 'cerrado') return { puedeCerrar: false, bloqueantes: ['El caso ya está cerrado.'], advertencias: [] };
  if (caso.estado === 'por_complementar' || caso.complemento?.estado === 'pendiente') b.push('Hay un complemento de denuncia pendiente: no puede cerrarse por inconsistente (ORD. N.º 146/13).');
  const derivable = motivoCierre === 'derivado_a_autoridad';
  const etapaOk = caso.estado === 'en_seguimiento'
    || (caso.estado === 'conclusiones' && !caso.procedimientoLegal)
    || (derivable && ['clasificada', 'evaluacion_inicial', 'procedimiento_seleccionado'].includes(caso.estado));
  if (!etapaOk && caso.estado !== 'por_complementar') b.push(`El caso está en «${ESTADOS[caso.estado].label}»: no corresponde cerrar todavía.`);
  if (caso.medidasCorrectivas.some((m) => m.estado !== 'aplicada')) b.push('Hay medidas correctivas dispuestas sin aplicar.');
  for (const r of calcularRelojes(caso, hoyISO, pack, cal)) {
    if (r.estado === 'corriendo' && !r.informativa) b.push(`Plazo pendiente: ${r.nombre}.`);
    if (r.estado === 'decidido_sin_medidas') adv.push('Se decidió no aplicar medidas: el plazo para disponer y aplicar medidas no se da por cumplido; confirmar con abogado que corresponde.');
  }
  return { puedeCerrar: b.length === 0, bloqueantes: b, advertencias: adv };
}
''', 'verificar cierre')

# ── 8. Relojes: régimen y «decidido sin medidas» ────────────────────────────────
once("  if (caso.sectorTenant === 'publico') return false;\n  if (r.canal", "  if (caso.regimenJuridico === 'estatutario_publico') return false; // otro estatuto: este paquete no lo modela\n  if (r.canal", 'aplicaRegla')
block('export function calcularRelojes(', 'export function calcularAlertasCasos(', r'''export function calcularRelojes(caso, hoyISO, pack = PAQUETE_REGLAS_CL_BORRADOR, cal = CALENDARIO_CL) {
  const out = [];
  for (const r of pack.reglas) {
    if (!aplicaRegla(r, caso)) continue;
    const cands = candidatos(r, caso, cal);
    if (!cands.length) continue;
    cands.sort((a, b) => (a.vence < b.vence ? -1 : a.vence > b.vence ? 1 : 0));
    const op = cands[0], mx = cands[cands.length - 1];
    const primero = (evs) => (evs || []).map((e) => caso.eventos[e]).filter(Boolean).sort()[0] || null;
    const cumplidoEn = primero(r.cumpleCon), sinMedidasEn = primero(r.resuelveSinCumplir);
    const base = {
      reglaId: r.id, nombre: r.nombre, actor: r.actor, informativa: !!r.informativa, validada: !!r.validada, ambigua: cands.length > 1, variantes: cands.length,
      provisional: caso.ramaId === null && !!(r.aplicaSi || {}).legalOSinClasificar,
      inicioEvento: op.inicioEvento, inicio: op.inicio, plazoDias: op.dias, tipoDia: op.tipoDia,
      vencimientoOperativo: op.vence, vencimientoMaximo: mx.vence, advertencias: [...new Set(cands.flatMap((c) => c.advertencias))],
    };
    if (cumplidoEn) { out.push({ ...base, estado: 'cumplido', cumplidoEn, cumplidoDentroOperativo: cumplidoEn <= op.vence, cumplidoDentroMaximo: cumplidoEn <= mx.vence, nivel: null, diasRestantes: null }); continue; }
    // Una decisión fundamentada de NO aplicar medidas no cumple la obligación: deja de correr, pero queda marcada para revisión.
    if (sinMedidasEn) { out.push({ ...base, estado: 'decidido_sin_medidas', decididoEn: sinMedidasEn, requiereRevision: true, nivel: null, diasRestantes: null }); continue; }
    const dr = contarDiasTipo(hoyISO, op.vence, op.tipoDia, cal);
    out.push({ ...base, estado: 'corriendo', nivel: nivelDe(dr, r.umbrales), diasRestantes: dr });
  }
  if (caso.complemento?.estado === 'pendiente') {
    const c = caso.complemento, dr = contarDiasTipo(hoyISO, c.venceEn, c.tipoDia, cal);
    out.push({ reglaId: 'complemento_denuncia', nombre: 'Plazo razonable para complementar la denuncia (ORD. N.º 146/13)', actor: 'empleador', informativa: false, validada: null, ambigua: false, variantes: 1, provisional: false, inicioEvento: 'complemento_solicitado', inicio: c.solicitadoEn, plazoDias: c.plazoDias, tipoDia: c.tipoDia, vencimientoOperativo: c.venceEn, vencimientoMaximo: c.venceEn, advertencias: c.advertencias || [], estado: 'corriendo', nivel: nivelDe(dr, { urgente: 1, pronto: 2 }), diasRestantes: dr });
  }
  return out;
}
''', 'relojes')
once("medidasResguardoActivas: abiertos.reduce((s, c) => s + c.medidasResguardo.filter((m) => m.estado === 'aplicada').length, 0),",
     "medidasResguardoActivas: abiertos.reduce((s, c) => s + c.medidasResguardo.filter((m) => m.estado === 'implementada').length, 0), medidasResguardoPendientes: abiertos.reduce((s, c) => s + c.medidasResguardo.filter((m) => ['propuesta', 'ordenada'].includes(m.estado)).length, 0),", 'kpi resguardo')

# ── 9. Contrato común de eventos ─────────────────────────────────────────────────
block('// Eventos de dominio (§57) — puerta etiquetada.', '\n' + roster.split('\n')[0], r'''// Eventos de dominio (§57) — puerta etiquetada. Contrato común (P0 de la revisión del 17-oct-2026): identificador de evento,
// clave de idempotencia determinística (reintentar no duplica), versión de esquema, tenant, entidad jurídica, actor, tiempo EFECTIVO
// (cuándo ocurrió el hecho, distinto de cuándo se emite), correlación y carga. La carga lleva SOLO identificadores opacos: nunca
// nombres, relatos, hechos ni las partes del caso. La auditoría persistente (§45) vive en `historial`; el bus real no existe todavía.
export const SCHEMA_EVENTOS_CASOS = '1.0';
export function crearEnvelopeEvento({ tipo, caso, actor = null, ocurridoEn, clave, payload = {}, emitidoEn = new Date().toISOString() }) {
  return {
    eventId: `evt:${tipo}:${caso.id}:${clave}`, idempotencyKey: `${tipo}|${caso.id}|${clave}`, schemaVersion: SCHEMA_EVENTOS_CASOS,
    tipo, dominioOrigen: 'workforce', tenantId: caso.tenantId, legalEntityId: caso.legalEntityId ?? null,
    actorRef: actor?.personaId || null, ocurridoEn, emitidoEn, correlationId: caso.id, versionCaso: caso.version, payload,
  };
}
export function construirCaseOpenedEvent(caso, emitidoEn) {
  return crearEnvelopeEvento({ tipo: 'CaseOpened', caso, actor: caso.historial[0]?.actor, ocurridoEn: caso.eventos.denuncia_recibida, clave: 'abierto', payload: { canalIngreso: caso.canalIngreso }, emitidoEn });
}
export function construirInvestigationStartedEvent(caso, emitidoEn) {
  if (!caso.eventos.investigacion_iniciada) return null;
  return crearEnvelopeEvento({ tipo: 'InvestigationStarted', caso, ocurridoEn: caso.eventos.investigacion_iniciada, clave: 'iniciada', emitidoEn });
}
export function construirInvestigationClosedEvent(caso, emitidoEn) {
  if (!caso.eventos.investigacion_concluida) return null;
  return crearEnvelopeEvento({ tipo: 'InvestigationClosed', caso, ocurridoEn: caso.eventos.investigacion_concluida, clave: 'concluida', emitidoEn });
}
export function construirCaseClosedEvent(caso, emitidoEn) {
  if (!caso.cierre) return null;
  return crearEnvelopeEvento({ tipo: 'CaseClosed', caso, ocurridoEn: caso.cierre.en, clave: 'cerrado', payload: { motivoCierre: caso.cierre.motivoCierre }, emitidoEn });
}
''', 'eventos dominio')

open(P, 'w', encoding='utf-8').write(t)
print('patch parte 1 OK —', len(t.split('\n')), 'líneas')
