import re
P = '/mnt/user-data/outputs/workforce/WorkforceCasosLaborales.jsx'
t = open(P, encoding='utf-8').read()

def once(old, new, label):
    global t
    n = t.count(old); assert n == 1, f'[{label}] esperaba 1 coincidencia y hay {n}'
    t = t.replace(old, new)

# ── Mock ────────────────────────────────────────────────────────────────────────
k = t.find('MOCK — determinístico respecto de `hoyISO`'); assert k > 0
ini = t.rfind('/* ═', 0, k)
fin = t.find('/* ═══════════════════════════ UI mínima', ini); assert fin > ini
mock = r'''/* ═══════════════════════════════════════════════════════════════════════
   MOCK — determinístico respecto de `hoyISO`. Se construye con las MISMAS operaciones del
   motor (así también las ejercita), usando como fecha de registro la fecha histórica de cada
   paso. Cubre: todas las etapas, las 5 ramas, canal DT, régimen estatutario público y Código
   del Trabajo dentro de una institución pública, art. 4 inc. 1, complemento, relojes en todos
   los niveles, una decisión sin medidas y un caso cerrado de punta a punta.
   ═══════════════════════════════════════════════════════════════════════ */
export const ACTOR_GENERAL_ID = 'per_1009'; // persona de RR.HH. sin rol en ningún caso
export const TENANT_DEMO_HEALTH = 'AXON-HEALTH', TENANT_DEMO_PUBLICO = 'HOSPITAL-REGIONAL-DEMO';
// DEMOSTRACIÓN: el tenant y la relación vigente del actor los resuelve el backend (MAIN); acá se fabrican para poder probar el aislamiento.
export function actorDemo(personaId, tenantId) { return { personaId, tenantId, relacionVigente: true }; }
export function generarCasosMock(personas, hoyISO) {
  const emp = personas.filter((p) => p.tipoRelacion === 'empleado');
  const id = (i) => emp[i].id;
  const rec = (c) => actorDemo(id(5), c.tenantId), resp = (c) => actorDemo(id(1), c.tenantId), inv = (c) => actorDemo(id(2), c.tenantId);
  const d = (n) => sumarDias(hoyISO, -n);
  const ok = (r) => { if (r.error) throw new Error(`mock: ${r.error}`); return r.caso; };
  let seq = 0;
  const nuevo = (o, fecha) => {
    seq++;
    const tenantId = o.tenantId || TENANT_DEMO_HEALTH;
    return ok(crearCaso({ id: `CL-2026-${String(seq).padStart(4, '0')}`, tenantId, sectorTenant: o.sector || 'privado', canalIngreso: o.canal || 'empleador', recibidaEn: fecha, denunciante: o.denunciante || { tipo: 'trabajador', personaId: id(10) }, denunciado: o.denunciado || { tipo: 'trabajador', personaId: id(15) }, relatoRef: `RELATO-${seq}`, responsableId: id(1), receptorId: id(5), actor: actorDemo(id(5), tenantId) }, fecha));
  };
  const clasif = (c, f, ramaId = 'acoso_violencia_legal', extra = {}) => ok(clasificarCaso(c, { ramaId, motivo: 'Hechos descritos en la denuncia', actor: rec(c), ...extra }, f));
  const resguardar = (c, f, tipo = 'separacion_espacios_fisicos') => {
    c = ok(proponerMedidaResguardo(c, { tipo, destinatarioId: c.denunciante.ref, fundamento: 'Resguardo inicial', actor: rec(c) }, f));
    const mid = c.medidasResguardo[c.medidasResguardo.length - 1].id;
    c = ok(ordenarMedidaResguardo(c, { medidaId: mid, actor: resp(c) }, f));
    return ok(implementarMedidaResguardo(c, { medidaId: mid, fecha: f, evidenciaRef: `EVID-RESG-${mid}`, actor: rec(c) }, f));
  };
  const evaluar = (c, f, riesgo = 'medio', tipo) => { c = resguardar(c, f, tipo); return ok(registrarEvaluacionInicial(c, { riesgo, decisionMedidas: 'aplicadas', actor: rec(c) }, f)); };
  const seleccionar = (c, f, procedimiento, fundamento) => ok(seleccionarProcedimiento(c, { procedimiento, fundamento, actor: resp(c) }, f));
  const investigar = (c, fAsig, fSel, fIni) => {
    c = ok(asignarRol(c, { personaId: id(2), rol: 'investigador', actor: rec(c) }, fAsig));
    c = seleccionar(c, fSel, 'investigacion_interna', 'Corresponde investigación interna');
    return ok(iniciarInvestigacion(c, { fecha: fIni, actor: rec(c) }, fIni));
  };
  const oirPartes = (c, f1, f2) => {
    c = ok(registrarActuacion(c, { tipo: 'declaracion', fecha: f1, participantes: [c.denunciante.ref], actor: inv(c) }, f1));
    return ok(registrarActuacion(c, { tipo: 'declaracion', fecha: f2, participantes: [c.denunciado.ref], actor: inv(c) }, f2));
  };
  const hastaConclusionesDT = (c, fConcl, fRem, fDT) => {
    c = ok(registrarConclusiones(c, { resultado: 'hechos_acreditados', referenciaInforme: `INF-${c.id.slice(-2)}`, fecha: fConcl, actor: inv(c) }, fConcl));
    c = ok(remitirInformeADT(c, { fecha: fRem, referencia: `ENVIO-${c.id.slice(-2)}`, actor: resp(c) }, fRem));
    return ok(registrarConclusionesDT(c, { fecha: fDT, referencia: `DT-NOT-${c.id.slice(-2)}`, actor: rec(c) }, fDT));
  };
  const casos = [];
  // 1-3: recién recibidas, sin decisión del empleador (reloj K1 con margen, urgente y vencido)
  casos.push(clasif(nuevo({}, d(0)), d(0)));
  casos.push(clasif(nuevo({}, d(2)), d(2)));
  casos.push(clasif(nuevo({}, d(5)), d(4)));
  // 4: investigación en curso, K2 «pronto»
  casos.push(investigar(evaluar(clasif(nuevo({}, d(25)), d(25)), d(24)), d(24), d(24), d(24)));
  // 5: investigación con K2 vencido
  let c5 = investigar(evaluar(clasif(nuevo({}, d(40)), d(40)), d(39)), d(39), d(39), d(38));
  c5 = ok(registrarActuacion(c5, { tipo: 'citacion', fecha: d(30), participantes: [c5.denunciante.ref], resultado: 'comparecio', actor: inv(c5) }, d(30)));
  casos.push(c5);
  // 6: investigación concluida, informe sin remitir (K3 urgente)
  let c6 = investigar(evaluar(clasif(nuevo({}, d(12)), d(12)), d(11)), d(11), d(11), d(10));
  c6 = oirPartes(c6, d(8), d(7));
  casos.push(ok(registrarConclusiones(c6, { resultado: 'hechos_acreditados', referenciaInforme: 'INF-006', fecha: d(1), actor: inv(c6) }, d(1))));
  // 7: denuncia contra persona del art. 4 inc. 1: derivación obligatoria a la DT
  let c7 = evaluar(clasif(nuevo({ denunciado: { tipo: 'trabajador', personaId: id(16), relacion: 'art4_inc1' } }, d(4)), d(4)), d(3));
  c7 = seleccionar(c7, d(3), 'derivacion_dt', 'Denuncia contra persona del art. 4 inc. 1');
  casos.push(ok(derivarADT(c7, { fecha: d(3), referencia: 'DT-DERIV-007', actor: resp(c7) }, d(3))));
  // 8: denuncia por complementar (ORD. 146/13)
  const c8 = nuevo({}, d(3));
  casos.push(ok(solicitarComplemento(c8, { plazoDias: 5, tipoDia: 'habil', fundamento: 'Faltan fechas y personas involucradas', actor: rec(c8) }, d(3))));
  // 9: convivencia, mediación opcional (sin relojes legales)
  let c9 = evaluar(clasif(nuevo({}, d(6)), d(6), 'convivencia'), d(5), 'bajo', 'redistribucion_jornada');
  casos.push(seleccionar(c9, d(5), 'mediacion_opcional', 'Conflicto interpersonal sin denuncia legal'));
  // 10: violencia de un paciente contra una TENS (sin procedimiento legal activado)
  let c10 = clasif(nuevo({ denunciante: { tipo: 'trabajador', personaId: id(12) }, denunciado: { tipo: 'tercero', ref: 'tercero:paciente-A' } }, d(2)), d(2), 'violencia_terceros');
  c10 = evaluar(c10, d(2), 'alto', 'atencion_psicologica_temprana');
  casos.push(seleccionar(c10, d(1), 'gestion_incidente_seguridad', 'Registrar el incidente y preservar evidencia'));
  // 11: caso cerrado de punta a punta (procedimiento legal completo)
  let c11 = investigar(evaluar(clasif(nuevo({}, d(80)), d(80)), d(79)), d(79), d(79), d(78));
  c11 = hastaConclusionesDT(oirPartes(c11, d(70), d(65)), d(55), d(54), d(30));
  c11 = ok(registrarMedidaCorrectiva(c11, { tipo: 'capacitacion', destinatarioId: c11.denunciado.ref, fundamento: 'Conforme al reglamento interno', actor: resp(c11) }, d(25)));
  c11 = ok(marcarMedidaAplicada(c11, { medidaId: 'c1', fecha: d(20), evidenciaRef: 'EVID-011', actor: resp(c11) }, d(20)));
  c11 = ok(registrarSeguimiento(c11, { medidaId: 'c1', resultado: 'cumplida', fecha: d(10), actor: resp(c11) }, d(10)));
  casos.push(ok(cerrarCaso(c11, { motivoCierre: 'medidas_aplicadas', fundamento: 'Medidas aplicadas y verificadas', actor: resp(c11) }, d(5))));
  // 12: amenaza grave: seguridad y derivación inmediata a autoridades
  let c12 = evaluar(clasif(nuevo({ denunciado: { tipo: 'tercero', ref: 'tercero:visitante-B' } }, d(1)), d(1), 'riesgo_fisico_delito'), d(1), 'inmediato');
  casos.push(seleccionar(c12, d(1), 'derivacion_autoridades', 'Riesgo inmediato: no se espera la investigación laboral'));
  // 13: institución pública con régimen estatutario declarado: procedimiento administrativo
  let c13 = evaluar(clasif(nuevo({ sector: 'publico', tenantId: TENANT_DEMO_PUBLICO }, d(10)), d(10), 'acoso_violencia_legal', { regimenJuridico: 'estatutario_publico' }), d(9));
  casos.push(seleccionar(c13, d(9), 'procedimiento_administrativo', 'Régimen estatutario público'));
  // 14: denuncia presentada ante la DT (reloj informativo)
  casos.push(clasif(nuevo({ canal: 'dt' }, d(1)), d(1)));
  // 15: recibida y sin clasificar (reloj K1 provisional)
  casos.push(nuevo({}, d(1)));
  // 16: institución pública con personal bajo el Código del Trabajo: aplica la ruta común (el sector no decide)
  casos.push(clasif(nuevo({ sector: 'publico', tenantId: TENANT_DEMO_PUBLICO }, d(2)), d(2), 'acoso_violencia_legal', { regimenJuridico: 'codigo_trabajo' }));
  // 17: etapa B: evaluación inicial hecha, sin procedimiento
  casos.push(evaluar(clasif(nuevo({}, d(3)), d(3)), d(2)));
  // 18: etapa F: conclusiones de la DT y decisión fundamentada de NO aplicar medidas (no cumple el plazo: queda para revisión)
  let c18 = investigar(evaluar(clasif(nuevo({}, d(60)), d(60)), d(59)), d(59), d(59), d(58));
  c18 = hastaConclusionesDT(oirPartes(c18, d(50), d(48)), d(40), d(39), d(20));
  casos.push(ok(declararSinMedidas(c18, { fundamento: 'Hechos no acreditados según las conclusiones', actor: resp(c18) }, d(15))));
  return casos;
}

'''
t = t[:ini] + mock + t[fin:]

# ── UI ──────────────────────────────────────────────────────────────────────────
i = t.find('function actorDeVista(caso, vista) {'); j = t.find('const Badge = (', i); assert 0 < i < j
t = t[:i] + '''function actorDeVista(caso, vista) {
  const a = caso.asignaciones;
  const m = { receptor: a.receptores[0], responsable: a.responsableId, investigador: a.investigadorId, denunciante: caso.denunciante.ref, denunciado: caso.denunciado.ref, general: ACTOR_GENERAL_ID };
  return actorDemo(m[vista] || null, caso.tenantId);
}

''' + t[j:]
once("  if (r.estado === 'cumplido') return `Cumplido el ${fmtDate(r.cumplidoEn)}`;", "  if (r.estado === 'cumplido') return `Cumplido el ${fmtDate(r.cumplidoEn)}`;\n  if (r.estado === 'decidido_sin_medidas') return `Decisión de no aplicar medidas el ${fmtDate(r.decididoEn)}`;", 'textoReloj')
t = re.sub(r"\{caso\.sectorTenant === 'publico' && <div style=.*?</div>\}", "{caso.regimenJuridico === 'estatutario_publico' && <div style={{ fontSize: 12, color: C.warn, background: C.warnL, padding: 10, borderRadius: C.rSm }}>Régimen estatutario público: no aplican los relojes del paquete del Código del Trabajo; los plazos del estatuto no están modelados.</div>}", t, count=1)
assert "caso.regimenJuridico === 'estatutario_publico' && <div" in t
once("{niv ? <Badge color={niv.color} bg={niv.bg}>{niv.label}</Badge> : <Badge color={C.pri}>Cumplido</Badge>}", "{niv ? <Badge color={niv.color} bg={niv.bg}>{niv.label}</Badge> : r.estado === 'decidido_sin_medidas' ? <Badge color={C.warn} bg={C.warnL}>Sin medidas: revisar</Badge> : <Badge color={C.pri}>Cumplido</Badge>}", 'badge reloj')
once("fila('Medidas de resguardo', caso.medidasResguardo.length)", "fila('Medidas de resguardo (implementadas / total)', `${caso.medidasResguardo.filter((m) => m.estado === 'implementada').length} / ${caso.medidasResguardo.length}`)", 'fila resguardo')
once("<FieldLabel>Ver como (la reserva se decide por el rol dentro de este caso)</FieldLabel>", "<FieldLabel>Ver como — DEMOSTRACIÓN: en producción la reserva, el aislamiento por tenant y la relación vigente los aplica el backend, no esta pantalla</FieldLabel>", 'demo label')
once("5. Versionado inmutable (§72)", "5. Versionado inmutable (§72)", 'ancla') if False else None

# ── Cabecera: decisiones nuevas ──────────────────────────────────────────────────
once("   8. CUT provisional (lo inyecta MAIN). Registro canónico copiado, no importado.\n", "   8. CUT provisional (lo inyecta MAIN). Registro canónico copiado, no importado.\n   9. Régimen jurídico por caso, no por sector del tenant: una institución pública puede tener personal bajo el Código del Trabajo y\n      otro bajo estatuto. Se declara al clasificar; solo en tenants privados se asume Código del Trabajo, marcado como inferido.\n  10. Una decisión NO es un cumplimiento: «decision_sin_medidas» y «medidas_correctivas_aplicadas» son hechos distintos y el plazo\n      del art. 211-E solo se da por cumplido con medidas realmente aplicadas.\n  11. Medidas de resguardo: propuesta → ordenada (quien decide) → implementada (con evidencia). Una propuesta no es una medida aplicada.\n  12. Estados: TRANSICIONES es la única máquina de estados y la hace cumplir `aplicar`. Eventos con contrato común (envelope).\n  13. Todo lo de acceso (rol del caso, tenant, relación vigente, bitácora) es DEMOSTRACIÓN del contrato: lo aplica el backend.\n", 'cabecera')

open(P, 'w', encoding='utf-8').write(t)
print('patch parte 2 OK —', len(t.split('\n')), 'líneas')
