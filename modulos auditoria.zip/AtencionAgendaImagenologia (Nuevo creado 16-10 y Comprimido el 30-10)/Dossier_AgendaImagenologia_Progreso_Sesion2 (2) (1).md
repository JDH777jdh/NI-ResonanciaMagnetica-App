# Dossier Técnico — Agenda de Imagenología · Sesión 2 (Slot Lifecycle / Historial del Cupo)

> Continuación de `Dossier_AgendaImagenologia_Progreso.md` (sesión 1, cierra 2026-08-31) y de `Sincronizacion_Satelites_MAIN.md` (2026-08-06). Este documento no repite el contenido de esos dos — los da por leídos y agrega lo que pasó después. Mismo espíritu: se escribe para que un chat nuevo dentro del mismo proyecto pueda retomar sin re-explorar todo de cero.

**Fecha de esta sesión:** posterior a `AXON_MAIN_Retoma_Sesion_2026-09-01.md` (que ya advertía: la propuesta de Scheduling Lifecycle & Traceability seguía "sin procesar" por MAIN — esta sesión es exactamente ese trabajo).
**Sesión cubierta:** 2 — arrancó ordenando cómo abordar el proyecto completo (MD → docx → JSX), pasó por el cruce de discrepancias de `Sincronizacion_Satelites_MAIN.md`, y terminó siendo casi enteramente la implementación del "Slot Lifecycle" / Historial del Cupo en `AtencionAgendaImagenologia.jsx`.

---

## RETOMA RÁPIDA — abrir un chat nuevo en este mismo proyecto (actualizado 2026-10-15)

**¿Se puede pasar a otro chat del proyecto?** Sí, con una condición: antes hay que subir las versiones vigentes y reemplazar las copias viejas, porque el chat nuevo lee `/mnt/project/` y trabajaría sobre lo que encuentre ahí.

1. `AtencionAgendaImagenologia.jsx` (la de outputs, ~251 KB). La copia del proyecto (`__5_`) es anterior a la sesión 3.
2. Este dossier (con la §9 de la sesión 3 y esta sección).
3. `smoke_agenda_imagenologia.cjs` (prueba de ejecución, 41 PASS / 0 FAIL).
4. `ARRANQUE_Antigravity_Telemedicina_WebRTC.md` (nuevo, ver §9.14).

`MasterIdentifierService.js` ya está en el proyecto; el JSX replica su algoritmo CHK2 con `sha256Hex()` puro (verificado contra `crypto-js`, mismo resultado).

**Primer mensaje sugerido en el chat nuevo:** «Lee el dossier (§0 y §9) y continúa desde 9.11».

**Abierto hoy:** (1) propagación enfoque B a Agenda/Presencial — sin empezar; (2) botón «Configuración agenda» — propuesto; (3) duración variable de bloques — pausada; (4) modelo de recurso humano — sin decisión; (5) «Notas de la Cita» sin auditar alta/baja; (6) `Sincronizacion_Satelites_MAIN.md` sin actualizar; (7) MD de Antigravity — creado, pendiente de revisión del usuario.

---

## 0. ⚠️ LEER ESTO PRIMERO — el archivo JSX

**`AtencionAgendaImagenologia.jsx` tiene ~2900 líneas ahora y cambió mucho respecto a la copia que hoy vive en el proyecto.** Todo el trabajo de esta sesión está en un archivo que el usuario descargó del chat anterior — **antes de continuar, confirmar que ya se subió esa versión al proyecto** (reemplazando o junto a la original). Si el chat nuevo lee `/mnt/project/AtencionAgendaImagenologia.jsx` y no tiene los componentes `MiniCalendario`, `TimelineCupo`, `PanelCupoVacio`, `CeldaOrdenDia`, `LeyendaEstados` — es la versión vieja, no la de esta sesión.

El propio archivo trae su historia con mucho más detalle que este dossier: **el bloque de comentarios al inicio del archivo tiene los puntos 12 a 21**, cada uno documentando una corrección de esta sesión con su razón. Este dossier es el resumen de alto nivel; el header del archivo es la fuente de verdad línea por línea.

**Sandbox se reinició una vez durante esta sesión** (ya había pasado 3 veces en la sesión 1, según ese dossier) — se perdió la copia de trabajo en `/home/claude`, se recuperó completa desde el último archivo entregado en outputs, y de ahí en adelante se empezó a copiar a outputs después de cada tanda de cambios validados, no solo al final. Aplicar el mismo criterio en la sesión 3.

---

## 1. Qué se resolvió de `Sincronizacion_Satelites_MAIN.md` en esta sesión

| # | Tema | Estado real al cierre de esta sesión |
|---|---|---|
| 1.1 | Formato CUP/CUT (3 vs 5 segmentos) | **Bloqueado.** Sigue esperando `cup.js` real — mismo pendiente desde hace 3 sesiones (sesión 3 del dossier original → sesión 1 de Imagenología → esta). Preguntar de nuevo antes de asumir que ya llegó. |
| 1.2 | Color de Imagenología | Decidido (`#1A4DA8`, confirmado contra `modules.config.js`) — **pero nunca se aplicó**. `C.pri` en el JSX sigue en `#0D47A1`. Es un cambio de una línea, quedó pendiente por enfocarse en el Slot Lifecycle. |
| 1.3 | Granularidad `atencion_clinica` (¿se desagrega `clin_esp`?) | Propuesta hecha (no desagregar todavía, construir genérico para que separar después sea agregar un id, no reconstruir pantallas) — **el usuario indicó que esto lo está ordenando el equipo MAIN ahora**, no se avanzó más de nuestro lado. |
| 1.4 | Marca de agua (3 valores distintos) | **Parcialmente resuelto** — ver sección 3 completa más abajo, tiene su propio hallazgo nuevo (probable bug de clipping) sin cerrar. |
| 1.5 | Gatillo de pánico por hold | Propuesta hecha (`holdMs: 3000` en `security.config.js`) — es un cambio del lado de MAIN (el config compartido), no del JSX; el gesto ya está implementado en los 3 satélites desde antes. No requiere acción en este archivo. |
| 1.6 | Teléfono/correo en `IDENTITY_SCHEMA` | Sigue dependiendo de un cambio de MAIN sobre el esquema real. **Aparte**, y sin relación directa con ese punto, se agregó `telefono1` al *mock* local de Imagenología (ver sección 4) — es una capa de datos de muestra, no resuelve el punto de arquitectura de fondo. |
| 1.7 / 1.8 / 1.11 | Roles / terminología / mayoría de edad sin conectar | Sin cambios — ya estaban bien triados como "pendiente de backend". |
| 1.9 | Auditoría (solo acciones, no vistas) | **Absorbido conceptualmente** en el hallazgo más grande (todo lo de Historial del Cupo / Scheduling Event Trail), pero **no implementado**: abrir el detalle de una orden para solo mirarla sigue sin quedar registrado. Sigue siendo una brecha real. |
| 1.10 | `USER_TYPE` para médico externo | Propuesta hecha (no crear uno nuevo — tratarlo como `Practitioner` de FHIR referenciado, no autenticado, catálogo compartido entre módulos) — **el usuario indicó que MAIN lo está ordenando**, no se avanzó más de nuestro lado. |
| 3.4 | CUC sin definir | **Bloqueado**, mismo motivo que 1.1 — mismo archivo (`cup.js`) resuelve ambos. |

**Conclusión de esta tabla:** de los 11 puntos originales, quedaron 4 explícitamente en manos de MAIN (1.1, 1.3, 1.10, 3.4), 2 sin acción necesaria (1.7/1.8/1.11, 1.5 ya no depende de este archivo), 1 con una propuesta hecha pero sin ejecutar (1.2 — un fix trivial pendiente), 1 con avance parcial en datos mock sin resolver el fondo (1.6), 1 identificado pero no resuelto (1.9), y 1.4 es la excepción grande — mutó en el trabajo central de la sesión.

---

## 2. El trabajo central de la sesión: Historial del Cupo (Slot Lifecycle) en `AtencionAgendaImagenologia.jsx`

Esto nació de la pregunta original de la sesión anterior ("¿cómo veo el lifecycle del slot?") y de la brecha ya identificada entonces: **no existía el Slot como entidad propia, ni un historial de ocupaciones consultable** — el "Historial del Cupo" que pide `AXON Agenda Web · Guía UX-UI...docx` (sección 16, "cupos vacíos con historia") no tenía dónde vivir.

**Decisión de alcance tomada al empezar, todavía vigente:** NO se construyó el Slot como *Aggregate Root* con su propio state machine (Available/Reserved/Occupied/Blocked/Freed, independiente del `estado` de la orden) — eso es la propuesta completa de `AXON Scheduling Lifecycle & Traceability.docx` / `Arquitectura de Trazabilidad de Scheduling.docx` (sección 19 de ambos: pide definir Aggregate Roots, invariantes y transiciones válidas primero). Lo que sí se construyó es **Occupancy History derivada** — la pieza observable que pide la guía UX-UI, sin el rediseño de modelo de datos completo. Este límite queda documentado en el propio código (punto 13 del header).

### 2.1 — Piezas nuevas, qué hace cada una

- **`historialDeCupo(ordenes, movimientos, auditoria, equipoId, fecha, hora, excluirId?)`** — función pura, el corazón de todo esto. No es un log nuevo: cruza 3 cosas que ya existían por separado.
  1. `ordenes` — las canceladas/reagendadas ya quedaban ahí con su estado, solo invisibles en la grilla (`ESTADOS_LIBERAN_CUPO` las excluye).
  2. `auditoria` — ya registraba quién y cuándo, nunca se cruzaba por cupo.
  3. `movimientosCupo` — **nuevo**, ver 2.4.
  Devuelve una lista normalizada `{ tipo: "orden" | "movimiento", ... }`.

- **`eventoDeAuditoria(auditoria, orden)`** — busca el evento de auditoría que corresponde al estado final de una orden (mapa `ACCION_POR_ESTADO_HISTORIAL`: cancelado→"Canceló orden", reagendada→"Reagendó solicitud", etc.). Caso especial importante: si la orden quedó "reagendada", ese evento de auditoría quedó etiquetado con el id de la orden **nueva** (`reagendadaHaciaId`), no el de esta — sigue ese link.

- **`TimelineCupo`** — componente compartido, renderiza la lista normalizada. Por cada entrada tipo "orden": paciente, badge de estado, link "reagendado a X" (ahora legible: equipo·fecha·hora, no un id crudo — ver 2.5), prestación, motivo de cancelación si existe, y actor+hora (o "Información histórica parcial — dato de muestra" si no hay registro de auditoría, sin inventar nada — mismo criterio que la guía UX-UI sección 21, "historial parcial o datos legados"). Por cada entrada tipo "movimiento": mismo criterio, con destino legible.

- **`PanelDetalle`** (ya existía) — ganó una sección nueva "Historial de este Cupo", solo aparece si hay algo que mostrar. También gambió el campo "Agendado por" (ver sección 4).

- **`PanelCupoVacio`** (nuevo) — la contraparte para un cupo **vacío con historia**: estado "Disponible" + el mismo `TimelineCupo` + botón directo a Nueva Solicitud.

- **`verCeldaVacia(equipoId, fecha, hora)`** — reemplaza el `onClick` directo a Nueva Solicitud en las 6 celdas vacías de la grilla de Día (regular + sobrecupo AM/PM × 2, ya no aplica igual a Semana, ver 2.6). Si el cupo nunca tuvo actividad, va directo a Nueva Solicitud — **sin cambio de comportamiento**. Si tuvo, abre `PanelCupoVacio` primero.

- **`PuntoHistorial`** — punto teal chico en la esquina de una celda vacía, visible *antes* de hacer clic, solo si esa celda tiene historial. Se agregó después de que el usuario preguntara "¿cómo lo veo, clic derecho?" — la primera versión no tenía ninguna señal previa, había que hacer clic a ciegas.

### 2.2 — Corrección de un hueco real, no solo una feature nueva

Al construir esto se encontró que **Imagenología nunca dejaba el link `reagendadaHaciaId`/`reagendadaDesdeId` al reagendar** (sí lo hacía `AtencionMedicaAgenda.jsx` desde su propia sesión anterior). Sin eso, el Historial no podía mostrar "fue reagendado hacia X". Corregido: agregados esos 2 campos (null por defecto) a las órdenes semilla y a las creadas en vivo, y ahora sí se completan al reagendar.

### 2.3 — Motivo de cancelación: decisión de producto, no solo de UI

Decidido explícitamente con el usuario:
- **Cancelar → motivo obligatorio.** `ModalMotivoCancelacion` bloquea la confirmación hasta escribir algo. Guardado en `orden.motivoCancelacion`, visible en el Historial.
- **Reagendar (formal Y drag&drop) → sin motivo, ninguno de los dos.** Decisión explícita: no romper la velocidad del gesto de arrastrar.
- **Este gate es solo para cancelación de STAFF.** Documentado en el código: si algún día se conecta un flujo de cancelación iniciada por el PACIENTE (Portal Paciente — que hoy no existe en este archivo), ese flujo *no* debe heredar el requisito de motivo.

### 2.4 — Drag&drop no debía perder la historia del cupo de origen

`moverOrdenPorDrag` muta fecha/hora/equipo de la MISMA orden (a propósito — es el atajo rápido, distinto del botón formal que crea una orden nueva). Sin nada más, el cupo de ORIGEN se quedaba sin ninguna orden que lo referenciara — su historial desaparecía sin dejar rastro al arrastrar. Se agregó `movimientosCupo` (nuevo state), un registro chico que se guarda ANTES de mutar la orden, con snapshot de paciente/prestación + origen + destino + actor + hora.

### 2.5 — Bug encontrado por el usuario probando: el link de reagendada se veía como código crudo

El Historial mostraba `"reagendado a SR-2026-M1788493402923"` para el reagendamiento formal, mientras que drag&drop sí mostraba algo legible (equipo·fecha·hora). Corregido: `historialDeCupo()` ahora resuelve la orden destino y muestra lo mismo en los dos casos.

### 2.6 — Grillas de Día y Semana, antes solo nombre+estado

- **Día**: `CeldaOrdenDia` (nuevo, reemplaza 3 bloques de botón repetidos inline) decide entre 2 layouts según `equiposVisibles.length === 1`: **apilado** (varios equipos, columnas angostas — nombre / prestación / estado·edad·teléfono en 3 líneas) o **ancha** (un solo equipo, sobra ancho — nombre/edad/prestación/teléfono/estado en una sola fila, como la tabla de referencia real que compartió el usuario). La versión ancha tuvo un bug de alineación (columnas usaban `minWidth`/`maxWidth` en vez de ancho fijo, así que no alineaban fila a fila) — corregido a ancho fijo por columna.
- **Semana**: `CeldaOrdenSemana` (nuevo). Semana no tiene el caso "ancha" — son siempre 7 columnas de día fijas. 3 líneas: nombre / prestación / estado·edad. Sin teléfono, no entra cómodo en ese ancho.
- Ambos requirieron agregar **`telefono1`** al paciente semilla (`fakeTelefono()`, mismo criterio determinístico que `fakeRUT()`) — antes ese campo no existía para ningún paciente de muestra, solo para los registrados a mano en el modal.

### 2.7 — Sidebar izquierdo: calendario mensual, leyenda, y ajustes estéticos

- **`MiniCalendario`** (nuevo) — faltaba por completo, el usuario lo detectó comparando contra una captura de referencia. Reusa `generarMatrizMes()` (la misma que ya usaba la vista "Mes" grande). Botón HOY, navegación de mes, clic en un día actualiza `fechaSel`.
- **`LeyendaEstados`** (nuevo) — colores de `ESTADOS` nunca habían tenido una referencia visible. Ubicada **arriba** del panel de notas (no abajo), a propósito: es contenido de consulta rápida, y las notas pueden crecer con un scroll largo. Pasó por 2 iteraciones: la primera con `flex-wrap` no alineaba en columnas reales (mismo tipo de bug que 2.6) — corregida a grid de 2 columnas fijas.
- **`C.panelGris` (`#F1F3F6`)** — nuevo color, fondo de nav + notas (antes blanco `C.sfc`), para que esos paneles laterales se distingan del contenido central. El header de KPIs quedó sin tocar — no confirmado si también se quiere ahí.
- Título del mes centrado dentro de su recuadro.
- Sacadas 2 líneas redundantes que aparecían arriba de la grilla en Mes y en Semana (resumen de fecha + nombre del equipo) — ya visible en el sidebar (mes, fecha, mini calendario, selector de Equipo) y en los propios encabezados de día de la grilla.
- `FlechaFecha` (nuevo, botón de ícono compacto) reemplazó al `Btn` genérico en las 3 filas de navegación de fecha (Mes/Semana/Día) — el `<input type="date"/"month">` se recortaba, sin espacio para mostrar la fecha completa. Columna del sidebar ensanchada de 168px a 188px de paso.

---

## 3. Marca de agua — unificación con un hallazgo nuevo sin cerrar

Se reconstruyeron con PIL (no capturas en vivo, sí con los parámetros reales de cada archivo) las 3 implementaciones existentes para comparar:

| Archivo | Técnica | Parámetros | Diagnóstico |
|---|---|---|---|
| Atención Médica / Presencial | grid 3×5, texto individual rotado | 0.06 · 20px · -45° | Bug de densidad confirmado: se ve amontonado en contenedor corto, con huecos grandes en uno alto (5 filas fijas repartidas en toda la altura). |
| Imagenología | `<pattern>` SVG, tile fijo en px | 0.07 · 21px · **-30°** · tileW **250** · tileH **60** (bajado de 105) | Densidad consistente confirmada (esa es la ventaja real de esta técnica) — **pero nuevo hallazgo**: el tile de 250px es ~3× más angosto que el texto real del watermark (~717px con CUT+fecha+deviceId). Un `<pattern>` SVG clippea su contenido al tile por default (estándar en Chrome/Firefox) — la reconstrucción muestra el texto cortado en fragmentos repetidos, no el string completo. |
| Telemedicina | grid 4×5 | 0.055 · 15px · -35° · color `#0A1726` (no negro) · **sin `mixBlendMode`** | **Nunca había entrado al análisis** — `Sincronizacion_Satelites_MAIN.md` solo comparó los 3 satélites de Agenda. Tiene el mismo bug de densidad que Atención Médica (misma técnica de grid), más sus propios valores distintos — es un 4º caso, no un 3º. |

**Decisión tomada:** adoptar la **técnica** de Imagenología (`<pattern>` SVG) como estándar para los 3 (y para lo que venga), no solo los números — pero **antes de propagarla, falta verificar el clipping del tile en un navegador real** y, si se confirma, ensanchar `tileW` o acortar el texto del watermark. Este punto **sigue abierto** — no se tocó `tileW` en esta sesión, solo `tileH` (que sí se confirmó y aplicó: 105→60, pedido explícito de filas más juntas).

**Pendiente concreto para sesión 3:** resolver `tileW`, y solo después propagar la técnica completa (con parámetros ya corregidos) a `AtencionMedicaAgenda.jsx`, `AtencionMedicaPresencial.jsx` y `AXON_Telemedicine_JuntaMedica.jsx` — hoy los 3 siguen con sus técnicas viejas, sin tocar.

---

## 4. Atribución de agendamiento — para cuando exista el dashboard real

Motivado por una pregunta del usuario sobre si los datos semilla soportarían KPIs de producción ("¿qué administrativa agenda más exámenes?", "¿que se terminan de realizar?"). Diagnóstico: utilización, cantidad de agendamientos, asistencias y no-asistencias **ya eran computables** con los datos existentes (pura agregación). Lo que **no existía en ningún lado** — ni en la orden ni en `auditoria`, que nunca corre para datos semilla — era quién agendó.

Se agregaron 2 pares de campos, con una distinción importante:

- **`agendadoPorCUT`/`agendadoPorNombre`** — quién hizo la acción que produjo *esta* orden específica (crear, reagendar formal, o mover por drag&drop). Este último caso se agregó recién al final, después de que el usuario probara y notara que drag&drop no lo actualizaba (solo el reagendamiento formal lo hacía) — corregido en `moverOrdenPorDrag`.
- **`agendadoOriginalmentePorCUT`/`agendadoOriginalmentePorNombre`** — quién inició la reserva de este paciente, **propagado a través de toda la cadena de reagendamientos**, sin importar el largo. Se prefirió esto por sobre inferirlo desde el Historial del Cupo (seguir `reagendadaDesdeId` a mano, salto por salto) porque para un KPI hay que poder calcularlo directo.

`PanelDetalle` muestra "Agendado originalmente por" siempre, y "Reagendado por" solo cuando `agendadoPorCUT !== agendadoOriginalmentePorCUT` (cubre reagendamiento formal y drag&drop con una sola condición, no dos gates distintos).

**Recordatorio importante, ya documentado en el propio código desde antes de esta sesión:** los KPICards de este módulo son la única superficie de indicadores *a propósito* — los indicadores reales van a Gestión/Alta Calidad + el dashboard principal, no a un tab acá. Esta sesión **no construyó ningún dashboard** — solo dejó el dato capturado y listo para cuando ese destino exista.

**Nota para revisar en sesión 3, sin resolver ahora:** al reagendar, la orden nueva queda atribuida en `agendadoPor` a quien reagenda, no a quien agendó la original — es la decisión más simple, pero quedó marcada como discutible por si se prefiere el criterio inverso.

---

## 5. Puertas etiquetadas (deliberadamente fuera de esta sesión)

| Puerta | Por qué se dejó fuera | Dónde está marcado |
|---|---|---|
| Slot como Aggregate Root, state machine propio (Available/Reserved/Occupied/Blocked/Freed) | Decisión de modelo de datos grande, requiere definir invariantes y transiciones primero (Arquitectura de Trazabilidad de Scheduling.docx, sección 19) | Comentario en `historialDeCupo()`, punto 13 del header |
| Auditoría de *vistas* (no solo acciones) — abrir un detalle para mirar sin modificar | Ya identificado (punto 1.9), no implementado | Tabla sección 1 de este dossier |
| Tab de Auditoría propio del cupo (3er tab del diseño original de la guía UX-UI: Estado/Historial/Auditoría) | Solo se construyeron 2 de los 3 (Estado+Historial fusionados, Historial nuevo) — la Auditoría global del módulo ya existía desde antes, pero no hay una vista de auditoría *filtrada a un cupo específico* | No marcado explícitamente en código todavía — anotar en sesión 3 |
| `tileW` del watermark (clipping) | Necesita verificación en navegador real, no se puede confirmar por reconstrucción | Sección 3 de este dossier |
| Propagar Historial del Cupo + mini calendario + atribución + leyenda + celdas enriquecidas a Agenda/Presencial de Atención Médica | Fue el plan original de la sesión, pero el usuario redirigió el foco entero a profundizar Imagenología primero | Sección 6 |
| Hilo B (Telemedicina) completo | Nunca se retomó desde el plan inicial de la sesión — sigue con sus propias discrepancias sin tocar (incluido el hallazgo nuevo del watermark, sección 3) | Sección 6 |
| Color `#1A4DA8` sin aplicar | Decidido, no ejecutado (punto 1.2) | Sección 1 |

---

## 6. Pendientes concretos para la sesión 3 — en orden sugerido

1. **Aplicar `C.pri = "#1A4DA8"`** en `AtencionAgendaImagenologia.jsx` — una línea, ya decidido, sin motivo para seguir esperando.
2. **Resolver `tileW` del watermark** (verificar clipping en navegador real, corregir ancho o acortar texto) — bloquea propagar la técnica al resto.
3. **Propagar a Atención Médica (Agenda + Presencial) y a Telemedicina**: técnica de marca de agua unificada, Historial del Cupo completo (con las mismas correcciones ya encontradas — no repetir el ciclo de descubrir el mismo bug 3 veces), mini calendario, teléfono en semilla, atribución agendadoPor/agendadoOriginalmentePor, motivo obligatorio al cancelar, leyenda de estados, celdas de Día/Semana enriquecidas, ajustes estéticos del sidebar (panelGris, mes centrado, FlechaFecha). Esto es la mayor parte del trabajo de sesión 3 probablemente.
4. **Retomar el hueco de auditoría de vistas** (punto 1.9) si se decide que vale la pena antes de propagar el patrón.
5. **Volver a `cup.js`** — preguntar si ya está disponible; desbloquea 1.1 y 3.4.
6. **Actualizar `Sincronizacion_Satelites_MAIN.md` mismo** (el archivo, no solo esta conversación) con las decisiones de esta sesión — quedó como intención declarada más de una vez, no se llegó a ejecutar.
7. Verificar con MAIN el estado de 1.3 y 1.10 (delegados a ellos esta sesión).

---

## 7. Aspiración / visión más amplia (no son tareas de la próxima sesión necesariamente)

- El patrón completo construido acá (Historial del Cupo, mini calendario, atribución, leyenda, celdas ricas) está pensado desde el diseño para **reutilizarse en las ~19 unidades de agenda**, no quedarse en Imagenología — sigue siendo la pieza piloto, ver Dossier sesión 1 sección 3.5 y 3.6 sobre el mismo criterio ya aplicado al panel de notas y a los 3 canales de llegada.
- Cuando exista el destino real (Gestión/Alta Calidad + dashboard principal), los datos de `agendadoPor`/`agendadoOriginalmentePor` + estados ya están listos para consumirse sin reconstruir semilla retroactivamente.
- La decisión de Slot como Aggregate Root sigue pendiente como definición de arquitectura mayor — cuando se tome, este Historial del Cupo derivado sería el punto de partida natural para migrar hacia un Event Trail real, no un reemplazo desde cero.
- Telemedicina quedó fuera de todo esto — cuando se retome, ya tiene 2 hallazgos nuevos esperando (su propio bug de densidad de marca de agua, nunca antes diagnosticado) que no requieren descubrirse de nuevo.

---

## 8. Bitácora resumida de la sesión 2

- Arrancó con un pedido de organización general del proyecto completo (11 documentos: 3 MD, 4 docx, 4 JSX) — se propuso un orden por hilo temático (Scheduling primero, Telemedicina después) en vez de estrictamente por tipo de archivo.
- Se mostró el Slot Lifecycle vs. Appointment Lifecycle como 2 diagramas (Visualizer), confirmando que el código actual solo modela el ciclo tipo Appointment.
- Se trabajaron los 11 puntos de `Sincronizacion_Satelites_MAIN.md` uno por uno (ver sección 1).
- El usuario delegó 4 puntos a MAIN y redirigió el resto de la sesión a construir el Slot Lifecycle real en Imagenología — esto ocupó la gran mayoría del tiempo.
- Construido en rondas iterativas, cada una gatillada por una captura de pantalla real del usuario probando el resultado anterior: Historial del Cupo → cruce con auditoría → motivo de cancelación → rastro de drag&drop → corrección del link de reagendada → enriquecimiento de Día → mini calendario faltante → atribución para KPIs → propagación de esa atribución al drag&drop (bug encontrado por el usuario) → enriquecimiento de Semana → leyenda de estados → limpieza de redundancias y ancho del selector de fecha.
- Un reinicio de sandbox a mitad de sesión, recuperado sin pérdida real gracias a un respaldo reciente en outputs — mismo patrón ya vivido en la sesión 1 del dossier original.
- Cierre: este documento, para continuar en un chat nuevo del mismo proyecto.

---

## 9. SESIÓN 3 — bitácora viva (se sigue en ESTE mismo archivo, no se crean más dossiers)

**Última actualización:** 2026-10-15 · **JSX de trabajo:** `AtencionAgendaImagenologia.jsx` (parte de la copia `(5)`, validado con esbuild en cada cambio).

### 9.1 Resuelto y aplicado en el JSX

| # | Qué | Detalle |
|---|---|---|
| 1 | Selector de fecha del sidebar (Mes/Semana/Día) | `NavegadorFecha` = 1 solo componente para las 3 vistas (antes estaba escrito 3 veces). Se dibuja texto+ícono a mano (centrado garantizado) y el `<input>` nativo queda invisible encima (opacity 0, absolute inset 0) para que el clic siga abriendo el calendario real. Motivo: el `<input type=date/month>` dibuja valor e ícono distinto según navegador y tipo, no controlable con CSS. Formato en un solo lugar: `formatearValorFecha()`. Vista Mes muestra solo el AÑO (el mes ya va grande arriba). |
| 2 | Bug: clic en pestaña Mes desde Día/Semana mostraba julio | `mesVista/anioVista` son estado propio (para hojear meses sin mover `fechaSel`) y nunca se sincronizaban al entrar a Mes (quedaba el valor inicial de useState). Fix: `irAVista()` sincroniza desde `fechaSel` solo al ENTRAR a Mes. Hojear meses dentro de Mes sigue sin tocar `fechaSel` (intencional). |
| 3 | Creatinina se perdía al guardar | `creatininaAdjunta`/`creatininaExpres` se capturaban en el modal pero no se copiaban a la orden. Ahora persisten (orden nueva + Modificar Cita), la semilla los trae en null/false, `PanelDetalle` muestra estado resuelto (verde) o pendiente (naranja), y el KPI "Creatinina Pendiente" excluye las resueltas (antes contaba todas). |
| 4 | Pestaña "Historial" renombrada a **"Agendamientos"** | Decisión del usuario. Motivo: "Historial" chocaba con "Historial de este Cupo". Descartados: "Agendados" (engañoso: la pestaña muestra todos los estados), "Movimientos agenda" (choca con `movimientosCupo` / etiqueta "Movido"), "Lista"/"Órdenes" (propuestos por Claude, no elegidos). También se renombró el id interno `historial` → `agendamientos` (solo 2 referencias). |
| 5 | Barras de scroll ocultas | Cinta de días (horizontal) y grillas Semana/Día sin barra visible: una sola clase `.axon-scroll-oculto` en el `<style>` existente (`scrollbar-width:none` + `::-webkit-scrollbar{display:none}`). El scroll sigue con rueda/trackpad/touch; con mouse la cinta solo se mueve con Shift+rueda. Ver fila 6 (la cinta se centra sola en el día seleccionado). |
| 6 | La cinta de días se centra sola en el día seleccionado | `useEffect` sobre `[vista, fechaSel]` con `cintaDiasRef`: el cálculo es sobre la propia cinta (no `scrollIntoView`, que también movería la página) y centra el pill marcado con `data-pill-activo`, con scroll suave. Motivo: sin barra visible y con la cinta partiendo en el día 1, el día actual (28) quedaba fuera de vista. Se centra SIEMPRE que cambia `fechaSel` (incluye clic en un pill que ya se veía); si molesta el movimiento, alternativa: centrar solo cuando el pill no está a la vista. |
| 7 | Eliminado `SelectorEquipoFoco` (punto 3) | Estaba definido y sin ningún uso (el sidebar arma Modalidad/Equipo con `<select>` inline); se borró con su comentario huérfano. Sin cambio visible. |
| 8 | "Cancelar" ya no aparece en órdenes "No Asistió" (punto 4) | Ahora solo se ofrece en Agendado y Confirmado (lista positiva, igual que "Modificar Cita"). Motivo: cancelar pisaba el estado No Asistió (dato de inasistencia); en `AtencionMedicaAgenda.jsx` un No Asistió solo ofrece Reagendar; y `Arquitectura de Trazabilidad de Scheduling.docx` pide no borrar la evidencia de un hecho histórico. Para liberar ese cupo sigue "Reagendar Cita". Aplicado tras un "continúa" sin respuesta explícita a la pregunta — **reversible**: restaurar la condición anterior `!("en_espera","en_atencion","atendido","cancelado","reagendada").includes(orden.estado)`. |
| 9 | Teléfono/correo/creatinina se perdían en 3 flujos (hallazgo propio, no pedido) | (a) Elegir un paciente EXISTENTE en Nueva Solicitud no copiaba `telefono1/telefono2/correo` al form — la orden nueva quedaba con esos campos vacíos aunque el paciente ya los tuviera registrado. (b) `abrirReagendarSolicitud` tampoco los pasaba — la orden reagendada armaba un objeto `paciente` nuevo desde cero, así que quedaba en blanco de verdad (no hay spread que lo proteja, a diferencia de Modificar). (c) `abrirModificarSolicitud` tampoco los pasaba (protegido por el spread `{...o.paciente, ...}` al guardar, no se llegó a perder) NI `creatininaAdjunta/creatininaExpres` (esto sí se pisaba de verdad — el fix del punto 1 escribe `form.creatininaAdjunta` directo, sin spread, así que abrir "Modificar Cita" en una orden con la creatinina ya resuelta y guardar sin tocar nada la volvía a dejar en pendiente). Las 3 funciones ahora copian esos campos desde `orden.paciente`/`orden`. |
| 10 | Reagendar tampoco pasaba si la orden médica ya venía adjunta | Mismo patrón de la fila 9: `abrirReagendarSolicitud` no pasaba `ordenAdjunta`, así que la reagendada quedaba como "Sin documento adjunto" aunque la original sí tuviera uno. `abrirModificarSolicitud` ya lo hacía bien, se copió el mismo patrón. |
| 11 | `adjuntosPrevios` reestructurado + mostrado (ver 9.6) | Objeto en vez de array; precarga en Modificar/Reagendar; primera vista en `PanelDetalle`. |
| 12 | `medicoSolicitanteId` se perdía al guardar | `MedicoPicker`/`MiniRegistroMedico` sí capturaban el id del médico referente elegido en el catálogo (`medicoSolicitanteId`), pero `ordenMedica` solo guardaba el nombre en texto libre — la orden quedaba sin el link al catálogo (`MEDICOS_REFERENTES_SEED`). Ahora se guarda en `ordenMedica.medicoSolicitanteId` (nueva orden y Modificar Cita) y se precarga en Modificar/Reagendar. Sin uso nuevo todavía — deja la puerta abierta para algo como "médicos que más refieren", no se construyó ningún reporte. |
| 13 | Drag&drop entre equipos de distinta modalidad, sin validar (línea de auditoría nueva, no la de 9.1-9.6) | Solo posible en Día con "Todas las modalidades" (ahí sí se ven equipos de distintas modalidades juntos en la misma grilla). `moverOrdenPorDrag` actualizaba `modalidad` al soltar pero `prestacion` (el catálogo real) se quedaba igual — se podía arrastrar una RM a un equipo de TAC y quedar con `modalidad="CT"` + `prestacion.modalidad="MR"`, inconsistente. Ahora se bloquea con toast si la modalidad del equipo destino no calza con la de la orden. |
| 14 | 2 KPIs contaban canceladas/reagendadas | "Consentimientos Pendientes" y "Creatinina Pendiente" no excluían `ESTADOS_LIBERAN_CUPO` (sí lo hacían "Órdenes Hoy"/"En Espera", quedó inconsistente). Una orden cancelada o reagendada que necesitaba consentimiento/creatinina y nunca se resolvió antes de cancelarse seguía inflando el KPI para siempre. |
| 15 | "Notas de los Sábado"/"Notas de los Domingo" (grammar) | Lunes-Viernes son invariables en plural en español ("los lunes"), pero Sábado/Domingo sí pluralizan (Sábados/Domingos) — nueva función `diaSemanaPlural()`, solo cambia el título visible, no las claves de guardado. |
| 16 | Motor CUP/CUT actualizado a `MasterIdentifierService.js` real (punto 2) | CHK2 vía SHA-256 (antes: hash propio `hashLiviano`, checksum distinto al real). CUT: tenant 4→8 chars, secuencia 8→4 dígitos. `USUARIOS_DEMO` dinámico. Import nuevo: `crypto-js` — **corregido después, ver fila 17: rompía la vista previa de artefactos.** |
| 17 | `crypto-js` rompía la vista previa de artefactos | Reportado por el usuario: "Error al cargar el artefacto... crypto-js" — esa librería no está en la lista que admite el sandbox de artefactos de Claude. Reemplazado por `sha256Hex()`, SHA-256 puro en JS sin dependencias (mismo algoritmo FIPS 180-4). Verificado 3 veces: contra vectores de prueba oficiales, contra `crypto-js` para los strings reales del motor, y contra la función tal cual quedó en el archivo — mismo checksum exacto en los 3 casos, cero diferencia. **Lección: cualquier código de este archivo debe evitar librerías fuera de la lista que admite la vista previa de artefactos** (revisar esa lista antes de agregar un import nuevo, no solo pensar en si existe en npm).|
| 18 | Fondo sutil en el botón HOY del MiniCalendario | Antes era texto plano, se confundía con una etiqueta. Mismo patrón de tinte que ya usa `Chip` (`${C.pri}12` + `borderRadius:6`), no un color nuevo. Aclarado de paso: "HOY" es una acción fija (como en Google Calendar), no describe la fecha seleccionada — no cambia según el día que estés mirando. |
| 19 | Watermark: tileW ahora se mide en vivo (Canvas 2D) | El usuario confirmó con captura real de la app que se veía clippeado (fragmentos tipo "12901-S3"/"01:30-A1" en vez del identificador completo). Aplicado el fix que estaba propuesto desde el inicio de la sesión 3, sin tocar: ángulo (-30°), tileH (60, mismo espaciado vertical), opacidad, ni el contenido del texto (sigue siendo CUT completo del trabajador en sesión + fecha + deviceId). Solo cambia tileW, de 250 fijo a medido con Canvas 2D (API estándar del navegador, no librería externa — no repite el problema de crypto-js). Efecto esperado: el texto se ve completo, pero el tile es más ancho (~780-790px con el CUT actual), así que los repeats quedan más separados horizontalmente que antes. |
| 20 | Reagendar borraba un hecho histórico (No Asistió/Cancelada) | `Auditorioa JSX agenda 2.txt`, hallazgo. Reagendar siempre pisaba `estado` a "reagendada", sin importar el estado anterior — una orden "No Asistió" quedaba como si simplemente se hubiera movido. Nuevo campo `estadoAntesDeReagendar`: se guarda solo si el estado previo era no_show/cancelado; `estado` sigue pasando a "reagendada" (libera el cupo en la grilla), pero el hecho queda visible en `TimelineCupo` y en el badge de `PanelDetalle` ("Antes: No Asistió"). |
| 21 | Modificar Cita no dejaba rastro en el Historial del Cupo | Mismo documento. Cambiar equipo/fecha/hora desde "Modificar Cita" movía la orden sin generar un `movimientosCupo`, a diferencia del drag&drop — el cupo de origen se quedaba sin historial. Ahora compara equipo/fecha/hora antes/después y registra el movimiento igual que `moverOrdenPorDrag`. |
| 22 | Modificar Cita no guardaba telefono/correo editados | Mismo documento, distinto del hallazgo de precarga (fila 9): aunque el campo ya se precargaba, un cambio real del usuario en el modal nunca se escribia de vuelta a la orden (el spread de paciente no los incluia). Corregido. |
| 23 | Consentimiento podia quedar inconsistente al modificar la prestacion | Mismo documento. Cambiar a una prestacion que si requiere consentimiento recalculaba requiereConsentimiento/plantillaConsentimiento pero nunca consentimientoEstado — podia quedar requiere=true + estado=no_requiere, nunca se pedia la firma. Ahora: si ya era requerido se respeta el estado existente; si pasa a requerirse recien ahora arranca en pendiente; si deja de requerirse pasa a no_requiere. |
| 24 | Auditoría de vistas (punto 1.9) implementada | "Vista" = abrir el detalle de una orden (`verDetalleOrden`, reemplaza los 7 `setOrdenSel(...)` que abrían el panel: 3 en Semana, 3 en Día, 1 en la tabla Agendamientos) o abrir el historial de un cupo vacío con historia (`verCeldaVacia`, solo cuando hay historial que mostrar). Acciones registradas: "Vio detalle de orden" / "Vio historial de cupo" en la tabla `auditoria` existente (pestaña Trazabilidad). NO cuenta ver nombres en la grilla ni tener abierta la tabla Agendamientos (ruido sin valor). **Efecto colateral detectado y corregido en el mismo cambio:** `eventoDeAuditoria()` caía por fallback a la primera entrada de auditoría de la orden, así que una orden de muestra cancelada que alguien solo abrió para mirar habría mostrado a esa persona como quien la canceló. Ahora excluye las acciones de vista (`ACCIONES_DE_VISTA`); probado con el código real en 4 escenarios (muestra+vista → "información histórica parcial"; cancelada en sesión+vista más nueva → la cancelación; reagendada con link → la reagendación; no_show+vista de cupo → parcial). |
| 25 | Historial de notas: quién escribió y quién borró (pedido del usuario, referencia philaxmed) | Cada uno de los 3 bloques de notas del panel derecho (Generales / día de la semana / fecha exacta) tiene un botón con ícono `History` (reloj con flecha, el equivalente al de philaxmed) arriba a la derecha de su encabezado, con el mismo tinte celeste del botón HOY. Abre un modal con las altas y bajas de ESE bloque: acción, quién, cuándo y el texto. Una baja conserva el texto borrado y quién lo había escrito originalmente (puede ser otra persona que quien lo borra). No es un log aparte: reutiliza la tabla `auditoria` (entidad `nota:<tipo>:<clave>`, mismo criterio que el Historial del Cupo), así que también aparece en Trazabilidad. `registrarAuditoria` ganó un 4º parámetro opcional `extra` (compatible hacia atrás) para llevar la nota estructurada. El modal cierra con X, clic fuera o Escape. |
| 26 | El panel de detalle mostraba una "foto" vieja de la orden (hallado por la prueba de ejecución real) | `ordenSel` guardaba una copia de la orden al abrirse y la seguía mostrando aunque cambiara después: tras Modificar Cita el panel mostraba los datos anteriores, y tras Reagendar seguía mostrando la orden como Confirmada con sus botones activos (Cancelar, Modificar) sobre una orden ya reagendada — se podía cancelar una orden reagendada. Ahora lo que se muestra se resuelve siempre desde `ordenes` por id (una sola fuente de verdad); el setter y los demás usos no cambian. |
| 27 | Etiqueta "Movido (drag&drop)" era fija | Desde la fila 21, Modificar Cita también genera movimientos de cupo, pero el Historial del Cupo los rotulaba siempre "Movido (drag&drop)". Cada movimiento ahora lleva `via` ("arrastrar" / "modificar") y la etiqueta lo respeta. |

### 9.2 Decisiones del usuario (no aplicar sin su autorización)

- **Color `C.pri`:** se queda en `#0D47A1`. MAIN va a mapear y redistribuir colores a todas las unidades; NO aplicar `#1A4DA8` hasta que MAIN entregue la asignación. *Pendiente de MAIN.*
- **Watermark:** el usuario quiere el mismo del jsx `(5)`. Medición hecha (Liberation Sans 21px, compatible con Arial): el texto real mide ~727px (CUT de 5 segmentos) contra un tile de 250px → un `<pattern>` SVG clippea por defecto, así que hoy se ve ~34% del string. Propuesta sin aplicar: calcular `tileW` en vivo con Canvas `measureText` (+ letterSpacing a mano). **Sin cambios, esperando que el usuario elija:** dejar como está / texto completo.
- **Propagación a Agenda/Presencial de Atención Médica y Telemedicina:** en pausa hasta cerrar los detalles estéticos y de lógica de este archivo.
- **Identificadores: APLICADO en `AtencionAgendaImagenologia.jsx`** (punto 2 de sesión 3). Motor CUP/CUT actualizado al algoritmo real: CHK2 vía SHA-256 (verificado contra el ejemplo del propio documento, byte 137→"N7"), usando `crypto-js` (misma librería que `MasterIdentifierService.js`, no se importó el archivo directo por no conocer su ruta relativa real en el proyecto — swap trivial si se resuelve). CUT pasa de tenant 4→8 caracteres y secuencia 8→4 dígitos. `USUARIOS_DEMO` pasó de 2 strings de CUT hardcodeados (checksum viejo) a `makeCUT()` dinámico, mismo patrón que ya usa `AtencionMedicaAgenda.jsx`. **Sin aplicar todavía en Agenda/Presencial/Telemedicina** — mismo cambio pendiente ahí (ver 9.8). Cruce completo contra el motor viejo, para referencia: CUP mismo molde de segmentos, cambia el checksum (SHA-256 primer byte → letra+dígito `A0–Z5`; el satélite usa un hash propio, no validaría contra `validarCUP()`); CUT cambia la estructura (tenant 4→8 caracteres, secuencia 8→4 dígitos); CUC ya definido (`CUC-país-región-tenant8-año-sec3-chk2`); CUP-NN pasa a correlativo coordinado con CHK2, sin fecha ni sexo en el código. Esto **resuelve 1.1 y 3.4** de `Sincronizacion_Satelites_MAIN.md`: el formato de 5 segmentos del satélite era correcto, faltan checksum y molde de CUT. Decisión del usuario: primero cerrar lo estético/lógico.
- **Auditoría de vistas (1.9): IMPLEMENTADA** (ver fila 24 de 9.1). Definición aplicada: abrir `PanelDetalle` o abrir el historial de un cupo vacío con historia. Sin decisión del usuario sobre el alcance exacto — se aplicó la interpretación que calza con `security.config.js` (`access_patient_history`/`view_imaging_report`) y se dejó explícita para poder ajustarla. Pendientes de criterio, no bloqueantes: (a) cada apertura registra una entrada, sin deduplicar (abrir la misma orden 5 veces = 5 entradas; es lo normal en una auditoría de acceso, pero si el volumen molesta se puede agrupar por usuario+orden en una ventana de tiempo); (b) la sección "Historial de este Cupo" dentro de `PanelDetalle` muestra pacientes anteriores pero queda cubierta por la misma entrada "Vio detalle de orden" — si se quiere granularidad por paciente visto, es una decisión aparte; (c) `AtencionMedicaAgenda.jsx`/`Presencial` tampoco auditan vistas — para cuando se propague (punto 1, enfoque B).

### 9.3 Pendientes de la lista de 4 hallazgos (esperan decisión del usuario)

- **Punto 3: resuelto** — `SelectorEquipoFoco` eliminado (ver fila 7 de 9.1).
- **Punto 4: resuelto** (ver fila 8 de 9.1). Posible mejora futura, sin decisión: "Revertir No-Show" (desmarcar una inasistencia marcada por error) — hoy no existe en ninguna de las dos agendas.
- Siguen abiertos los "detalles estéticos" que el usuario vaya anotando; el selector de fecha fue el primero.

### 9.4 Reglas de trabajo del usuario (recordatorio)

- Respuestas cortas en el chat; lo largo va a ESTE dossier. Nada de código ni dibujos en el chat salvo que se pidan.
- Cambios de estilo/color/nombres se proponen antes de aplicar; no tomar decisiones sin autorización; si no se entiende algo, preguntar.
- Un solo componente/lógica por cosa: nada de replicar el mismo código en Mes/Semana/Día.

### 9.5 Lecciones técnicas de esta sesión

- El sandbox no tiene navegador: el píxel exacto de un `<input type=date/month>` no se puede verificar acá. Se usó un widget del Visualizer, que corre en el navegador real del usuario, antes de tocar el archivo.
- Un `str_replace` que corta un bloque JSX a la mitad deja etiquetas huérfanas. Validar siempre con `npx esbuild archivo.jsx --loader:.jsx=jsx --outfile=/tmp/out.js` (el original pasa limpio; cualquier error es del cambio).
- Renombrar un id interno de vista: revisar con grep todas las referencias (`id:"..."` y `vista === "..."`); esbuild no detecta un id que quedó desalineado.


### 9.6 Resuelto — ya no queda flagueado

- **`adjuntosPrevios`** pasó de array plano `[archivo, link].filter(Boolean)` a objeto `{ archivo, link }` — reconstruible sin ambigüedad. Ahora: se precarga en Modificar Cita y en Reagendar (es referencia clínica del paciente — informes/links de exámenes previos —, no algo atado a una fecha puntual, así que tiene sentido que viaje con el paciente al reagendar); Modificar Cita ya escribe los cambios al guardar (antes ni se tocaba, así que cualquier cambio ahí se perdía igual que el resto); y se agregó su primera vista en `PanelDetalle` (sección "Exámenes previos", debajo de "Orden médica") — antes no se mostraba en ningún lado, aunque se guardara.


### 9.7 Cierre de esta línea de auditoría ("dato capturado, se pierde al guardar/editar/reagendar")

Repasados de punta a punta los 4 flujos de `ModalNuevaSolicitud` (Paciente, Orden médica, Prestación/Diagnóstico, Exámenes previos) contra Nueva/Modificar/Reagendar — no quedan más campos del formulario sin persistir o sin precargar. Filas 1, 9, 10, 11, 12 de la tabla 9.1 son todos hallazgos de esta misma línea, ninguno pedido explícitamente por el usuario. Si aparece un bug nuevo de este tipo, no es por falta de revisión en esta sesión — sería un campo agregado después.


### 9.8 Propagación (punto 1) — pausada por un hallazgo estructural, necesita tu decisión

Antes de tocar los otros 3 archivos: **el layout no es el mismo**. Imagenología usa 3 columnas (nav sidebar de 188px | contenido | notas), con `NavegadorFecha`/`MiniCalendario`/`FlechaFecha` viviendo en ese sidebar. `AtencionMedicaAgenda.jsx` y `AtencionMedicaPresencial.jsx` son de una sola columna, con tabs arriba y navegación de fecha con `Btn` de texto ("Semana anterior"/"Semana siguiente"), sin sidebar ni `<input type=date>` en ningún lado — la técnica de `NavegadorFecha` (centrado + overlay) no tiene dónde "pegarse" tal cual. `AXON_Telemedicine_JuntaMedica.jsx` no es una agenda en absoluto (es la sala de videollamada activa) — no tiene cupos, calendario, ni notas por fecha; lo único que comparte con esto es el componente `Watermark` propio, con su propio bug de densidad (fila de la sección 3, sesión 2) sin tocar todavía.

No se avanzó nada de esto — falta que decidas el enfoque antes de escribir código, para no rehacer un camino equivocado en 3 archivos grandes.


### 9.9 Decidido: propagación (punto 1) = enfoque B

Agenda/Presencial de Atención Médica mantienen su layout de una columna. Se porta solo lógica, sin sidebar: Historial del Cupo (dentro del panel de detalle existente), atribución de quién agendó, motivo obligatorio al cancelar, teléfono en la semilla. Quedan fuera (dependen del sidebar que no se va a construir ahí): mini calendario, selector de fecha centrado, leyenda de estados. Sin empezar todavía.

---

## 10. Verificación detallada — `Arquitectura_Tecnica_Scheduling_Engine_Agenda_v1.docx` vs. estado real del JSX

**Pedido explícito del usuario:** no adoptar las sugerencias a ciegas — verificar cada una contra lo que existe hoy en `AtencionAgendaImagenologia.jsx` (v2.9xx, ~2990 líneas) y decir qué aplica tal cual, qué necesita adaptación, y qué es prematuro para un prototipo sin backend. Nada de esta sección está aplicado al código — es solo el análisis pedido.

### 10.1 Ya está alineado (el documento confirma decisiones ya tomadas, no exige cambio)

| Propuesta del documento | Dónde ya lo tenemos | Verificado |
|---|---|---|
| Accession Number no debe inventarlo Agenda; CUP+ACC+StudyInstanceUID identifican persona/orden/estudio (doc §15, cita líneas 17-34 de este mismo archivo) | `acc: null` hasta Admisión, `soloNumero()`, decisión 2 del dossier sesión 1 | Coincide exacto — el documento literalmente cita nuestra propia corrección. |
| ESTADOS de agenda no deben confundirse con estado clínico/operativo (doc §7) | `en_atencion`/`atendido` son "reflejo del RIS-PACS", sin botones que los disparen desde Agenda (decisión 16, sesión 1) | Ya construido así desde la sesión 1. |
| "Puertas etiquetadas" como contrato de integración, no dependencia circular (doc §9, tabla DOOR-01 a DOOR-14) | Sección 4 del dossier sesión 1 (misma idea, tabla propia, sin numerar) | Mismo patrón — ver 10.4 para el cruce puerta-por-puerta. |
| `agendadoPor` como proyección/KPI, no fuente histórica única (doc §20) | Exactamente lo que se construyó en sesión 2 (`agendadoPorCUT`/`agendadoOriginalmentePorCUT`) | El documento valida la decisión tal como se tomó. |
| Watermark/Panic como "componente transversal de Security/UI infrastructure" (doc §25) | Ya documentado como código a propagar 1:1 entre satélites (dossier sesión 1, sección 2) | Coincide. |
| Slot vacío con historia reconstruible sin destruir identidad histórica (doc §7, Slot/Availability/Appointment) | Es exactamente el Historial del Cupo de sesión 2 (`historialDeCupo()`, `PanelCupoVacio`, `TimelineCupo`) | El documento describe en términos de backend (Occupancy, Event Trail) lo mismo que ya resolvimos como UX+derivación en memoria — ver 10.3 para el límite real. |
| CIE-10/11 debe salir a un Terminology Service real (doc §13) | Ya marcado como discrepancia 1.8 en `Sincronizacion_Satelites_MAIN.md` (`TerminologyService.js`/`terminology.seed.js` existen, el satélite usa catálogo local) | Gap ya conocido, no es un hallazgo nuevo del documento. |

### 10.2 El bloque de 20 minutos — tu punto, detallado

El documento tiene razón en el principio (doc §4): un Appointment no debería ser "un bloque de 20 minutos", sino un intervalo real. Pero aplicarlo tal cual hoy choca con 2 límites concretos que hay que resolver primero, no es un cambio de una línea:

1. **No hay dato real de duración.** `CATALOGO_PRESTACIONES` (107 filas de RM + placeholders de CT/CR/US/MG) no trae ningún campo de duración — ni en el CSV original ni en lo que se construyó. Adoptar duración variable sin inventar números sería repetir el mismo error que ya se evitó con nombre/valor comercial (no inventar lo que no se tiene).
2. **El renderizado de la grilla asume 1 orden = 1 celda.** `CeldaOrdenDia`/`CeldaOrdenSemana`, `ordenesPorCeldaDia`, el chequeo de `ocupado` en `guardarNuevaSolicitud`/`moverOrdenPorDrag` — todo compara por `hora` exacta, no por rango. Una prestación de 45 min ocupando 2-3 celdas de 20 min requiere un modelo de "celda ocupada por una orden que empezó antes" (equivalente visual a un rowspan), que hoy no existe en ningún lado del archivo.

**Propuesta de cómo adaptarlo, en 2 fases, para que decidas si tiene sentido:**
- **Fase 1 (compatible con el prototipo tal como está):** agregar `duracionMin` a cada prestación del catálogo (con un default razonable por modalidad donde no haya dato real — ej. CR 15, CT 20, MR 30/45 según si es "compleja", US 20, MG 15 — dejando explícito que son defaults, no datos reales, mismo criterio que ya se usó para los placeholders de CT/CR/US/MG). La grilla se queda en 20 min de visualGrid (como ya está); la orden guarda su propia duración y la muestra como dato (ej. un badge "45 min" en la celda), pero todavía NO bloquea celdas adicionales.
- **Fase 2 (requiere rediseño real del renderizado):** la orden efectivamente ocupa N celdas consecutivas y bloquea que se agende algo encima — recién ahí se resuelve el problema de fondo que plantea el documento. Esto toca `ordenesPorCeldaDia`, `CeldaOrdenDia/Semana`, el chequeo de `ocupado`, y probablemente el drag&drop (¿qué pasa si arrastras una orden de 45 min a un hueco de solo 20 min libres?).

No se tocó nada de esto todavía — queda para que digas si partimos por la Fase 1 o se deja completamente para cuando haya backend real (el documento mismo trata esto como problema de un Scheduling Engine con Postgres/exclusion constraints, no de un prototipo en memoria).

### 10.3 Límite real que el documento no resuelve por nosotros

El documento (§20) pide que `historialDeCupo()` "cambie de fuente" a una Timeline API real, conservando la UX — eso es correcto y es justamente el límite honesto que ya está documentado en el propio código (punto 13 del header del JSX, sección 5 del dossier sesión 2): Historial del Cupo hoy es Occupancy History derivada de `ordenes`+`auditoria`+`movimientosCupo` en memoria de sesión, no un Slot como Aggregate Root con su propia máquina de estados. El documento no cambia esa conclusión, solo la confirma con más vocabulario formal (Event Trail, Occupancy, Domain Events) — sigue pendiente de una decisión de arquitectura backend que no corresponde tomar desde este archivo.

### 10.4 Gaps reales que el documento sí expone (no estaban en nuestra lista)

| Gap | Detalle | Severidad |
|---|---|---|
| No existe modelo de recurso humano (tecnólogo/radiólogo) | El documento propone `ResourceType.PROFESSIONAL` junto a `EQUIPMENT` — hoy `EQUIPOS` es solo la máquina; no hay ningún campo ni catálogo de quién opera el equipo o informa el estudio. Puede ser intencional (eso vive en RIS-PACS, no en Agenda) o un gap real — no se puede saber sin que lo confirmes. | Media — depende de si Agenda necesita saberlo o es 100% del módulo operativo. |
| `calcularConsentimiento()`/reglas de creatinina están hardcodeadas en el componente | El documento (§21, tabla de migración) las trata como "Clinical Rule Adapter" / "Consent Rules Engine" externalizables — hoy viven como funciones JS fijas en este archivo. | Baja para el prototipo, relevante si mañana cambia una regla clínica y hay que tocar código en vez de configuración. |
| Pago/reserva (doc §11) no tiene ningún equivalente hoy | Ni puerta etiquetada ni mención — Imagenología no cobra nada todavía, a diferencia de Atención Médica que sí tiene `PAGADORES`. | Baja ahora, probablemente entra cuando exista `med_bonos`/equivalente (ya marcado como puerta etiquetada en el dossier sesión 1). |

### 10.5 Prematuro para este archivo (correcto en el documento, no aplica a un prototipo frontend)

Postgres con exclusion constraints, Kafka, Temporal, Keycloak/OIDC, OpenTelemetry, idempotency keys, FHIR Adapter real — todo esto es diseño de backend/infraestructura que el propio documento marca como evaluación para el equipo de arquitectura, no algo que un componente standalone en memoria pueda implementar. Se deja sin tocar, coincide con el límite honesto ya documentado en todo el proyecto.

### 10.6 Preguntas para decidir antes de tocar código

1. ¿Partimos la Fase 1 de duración variable (agregar `duracionMin` al catálogo, mostrarlo, sin bloquear celdas todavía), o se deja completamente para cuando haya backend?
2. ¿Agenda de Imagenología debería saber qué tecnólogo/radiólogo está asignado, o eso es 100% del módulo operativo RIS-PACS y no corresponde acá?
3. ¿Seguimos con la propagación a Agenda/Presencial (enfoque B, ya decidido) antes de tocar el modelo de duración, o esto tiene prioridad por sobre esa propagación?

### 9.10 Auditorioa JSX agenda 2.txt — procesado

Documento leido completo (auditoria externa anterior, 2 rondas de hallazgos + la discusion de Overbooking/Event Trail ya cubierta en sesiones previas). De los hallazgos de prioridad alta de la segunda ronda, los 4 accionables quedaron aplicados (filas 20-23). El punto de Modificar Cita rompiendo el Historial del Cupo y el de telefono/correo son el mismo tipo de hallazgo que ya veniamos encontrando en 9.7 — el documento llego a lo mismo por su cuenta, confirma que esa revision no estaba completa (faltaba el camino de edicion de slot via Modificar, no solo drag&drop).

No accionado, solo registrado (ya estaba igual en el dossier o es de decision, no de bug):
- Auditoria de notas (agregarNotaCita, notas generales/dia/fecha no llaman a registrarAuditoria) — mismo tema que 1.9, sigue pendiente de decidir que cuenta como auditable.
- AtencionMedicaAgenda.jsx tiene el MISMO bug de reagendar pisando no_show/cancelado (confirmado al revisar ese archivo) — para cuando se propague (punto 1, enfoque B).
- Timestamps guardados como texto formateado en vez de ISO, recursos sin tipo/capacidades, identificadores mock con Math.random()/Date.now() — correctamente catalogado por el documento como arquitectura backend, no tocar ahora.
- `Watermark` con id de `<pattern>` fijo (hallazgo de prioridad baja, 10.4 del documento) — **aplicado**: `patternId` único por instancia via `useRef`, para que 2 watermarks en el mismo DOM no compartan el mismo `<pattern>`.

Con esto, `Auditorioa JSX agenda 2.txt` queda completamente procesado: los 4 hallazgos de prioridad alta y el de prioridad baja del `<pattern>` aplicados; los de prioridad media (notas sin auditar, recursos pobres, timestamps como texto) correctamente dejados para cuando corresponda (decisión pendiente o arquitectura de backend).

### 9.11 Propuestas pendientes de tu decisión (nada de esto está aplicado)

- **Botón "Configuración agenda" con ícono de tuerca bajo Trazabilidad** (sugerido por el usuario a partir del menú "Opciones de Agenda" de philaxmed: Configurar agenda, Modificar día, Imprimir citas del día, Exportar citas del día, Exportar todas las citas). Opinión: sí, con 2 ajustes — (a) ubicarlo separado del grupo de vistas con una línea divisoria, porque no es una vista que se "selecciona" (las 5 de arriba se resaltan al estar activas) y (b) por ahora como puerta etiquetada (deshabilitado + tooltip con el motivo), igual que "Exportar citas" y "Consentimientos" en el header, porque todavía no hay nada detrás. Sería la entrada natural a duración variable de bloques (sección 10.2) y a la configuración self-service de `Arquitectura_Tecnica_Scheduling_Engine_Agenda_v1.docx` §24; en Atención Médica ya existe un "Configurar Bloques" deshabilitado con la misma idea. Ícono: `Settings` de lucide-react (hay que agregarlo al import). "Modificar día" e "Imprimir citas del día" de philaxmed no existen acá — no se agregan salvo que se pidan.
- **"Notas de la Cita"** (4º nivel, dentro del detalle de cada orden) tiene el mismo hueco que tenían las del panel derecho: no registra quién anota ni quién borra. No se tocó porque el pedido era el panel derecho. Si se extiende, usar una entidad distinta (por ejemplo `notaCita:<ordenId>`) para no mezclarse con `eventoDeAuditoria()`, que filtra por id de orden.

### 9.12 Prueba de ejecución real (jsdom) — cómo reproducirla

`esbuild` solo valida sintaxis: no detecta un identificador mal escrito, que compila bien y deja la pantalla en blanco (lo mismo que pasó con `crypto-js`). Desde esta sesión hay una prueba que renderiza la agenda de verdad en un DOM simulado y ejecuta los flujos (notas con historial, vistas Mes/Semana/Día/Agendamientos, detalle, Modificar con y sin cambio de slot, Reagendar de un No Asistió, Trazabilidad). Resultado actual: **41 PASS / 0 FAIL**. Ya encontró un bug real (fila 26). Se guarda como `smoke_agenda_imagenologia.cjs` junto a este dossier. Para correrla:

1. `mkdir t && cd t && npm init -y && npm i react@18.3.1 react-dom@18.3.1 lucide-react@0.383.0 jsdom@24 esbuild`
2. copiar el JSX como `src.jsx` y empaquetar: `./node_modules/.bin/esbuild src.jsx --bundle --platform=node --format=cjs --jsx=automatic --loader:.jsx=jsx --external:react --external:react-dom --external:lucide-react --outfile=bundle.cjs`
3. copiar `smoke_agenda_imagenologia.cjs` como `smoke.cjs` y correr `node smoke.cjs`

Limitación honesta: verifica comportamiento y datos, NO el aspecto visual (centrado, colores, espaciado) — eso solo se ve en un navegador real. En el entorno de prueba el canvas se simula (cada carácter mide 10px), por eso el tile del watermark da 797 y no el valor real del navegador.

### 9.13 Lección sobre el entorno

El directorio de trabajo del asistente (`/home/claude`) se reinició a mitad de esta sesión — pasó antes en este proyecto. Lo único que sobrevive es `/mnt/user-data/outputs`. Se restauró desde ahí sin pérdida porque se copia a outputs después de cada tanda de cambios; esa costumbre es la que lo hizo posible y hay que mantenerla (incluyendo la prueba `smoke_agenda_imagenologia.cjs`).

### 9.14 MD de arranque para Antigravity — creado, pendiente de revisión del usuario (2026-10-15)

Pedido del usuario: indicaciones en un MD para trabajar la capability de Telemedicina WebRTC en Antigravity, con el mismo stack y familia que `AtencionAgendaImagenologia`. Archivo: `ARRANQUE_Antigravity_Telemedicina_WebRTC.md` (15.074 bytes, ~4.300 tokens).

- **Hallazgo que cambió el diseño:** las guías de terceros hablaban de 12.000 caracteres por regla; la página oficial *Rules* de Antigravity (consultada hoy) dice **24.000 bytes por archivo** (se trunca) y 20.000 tokens compartidos entre reglas globales y `always_on`. Además, todo `.md` dentro de `.agents/rules/` exige frontmatter con `trigger` válido: sin él se descarta en silencio. `AGENTS.md` no lleva frontmatter y queda siempre activo; por eso el MD se entrega sin frontmatter, pensado como `AGENTS.md` en la carpeta del módulo.
- **Contenido:** reglas de trabajo del usuario (§1), stack ya usado en Agenda vs. lo que Telemedicina agrega con versiones de npm (§3), 6 contradicciones detectadas (§3.3), decisiones ya tomadas con fuente (§4), 12 reglas de dominio (§5), estado del prototipo (§6), Hito 1 propuesto (§7), checklist previo (§8) y 12 pendientes (§9).
- **No son decisiones:** §7 (Hito 1) y §9 son propuestas y preguntas mías. El usuario las revisa antes de pasárselo a Antigravity.
- **Verificado hoy:** docs de Antigravity (*Rules*); npm (`livekit-client` 2.22.4, `@livekit/components-react` 2.9.24, `@livekit/components-styles` 1.2.0, `livekit-server-sdk` 2.19.1; en npm React 19.3.1 y Vite 8.3.4); README de `livekit/livekit` (`livekit-server --dev`, `devkey`/`secret`); `config-sample.yaml` (TURN embebido, apagado por defecto).
- **Contradicciones destacadas (las decide el usuario):** `lucide-react@0.383.0` no admite React 19; «sin CSS externo» vs. estilos de LiveKit; TURN embebido de LiveKit vs. Coturn; endpoint de tokens (Vercel vs. backend Node); JS vs. TypeScript.
- **No verificado:** formato y ubicación de los *skills* de Antigravity (el menú de su documentación incluye una página «Workflows to skills migration»; no se leyó) y las versiones reales de React/Vite del repo AXON.
- **Sin hacer (si el usuario lo quiere):** convertir `Arquitectura_Maestra_de_Telemedicina.docx` a `.md` para que el agente pueda leerla completa.


### 9.15 Sesión 3 (continuación, 2026-10-16) — verificación y "Configurar agenda"

- **Verificado:** `AtencionAgendaImagenologia (Nuevo 16-10).jsx` es la versión más evolucionada (contiene las filas 1-27 de §9.1). Sobran, y los borra el usuario a mano (el proyecto es de solo lectura para el asistente): `AtencionAgendaImagenologia__5_.jsx` y `Dossier_..._Sesion2.md` (el original sin "(2)"). Se ignora el MD de arranque de Antigravity (decisión del usuario). `smoke_agenda_imagenologia.cjs` ya está en el proyecto.
- **Aplicado (fila 28):** botón **"Configurar agenda"** (ícono `Settings`) bajo Trazabilidad, separado por línea divisoria, **deshabilitado** como puerta etiquetada (tooltip: lo habilitará el motor de agenda). Decisión del usuario: sin panel vacío, para no construir pantallas sin motor. Es la entrada natural a duración variable de bloques (§10.2) y configuración self-service (Arquitectura Scheduling Engine §24).
- **Pendiente menor:** prop `anchoInput={130}` sobrante en `NavegadorFecha` (inofensivo). Dossier con §9.10-9.14 fuera de orden respecto a §10 y §9.2 aún menciona `crypto-js` (superado por fila 17); sin reordenar a la espera de autorización.

- **Aplicado (fila 29):** el historial de notas pasó de modal centrado a **panel lateral derecho** (`PanelHistorialNotas`, mismo patrón que `PanelCupoVacio`). Motivo (captura del usuario): en Día/Semana el modal quedaba tapado por los encabezados fijos de las grillas (`zIndex:2`), porque vivía dentro del panel de notas, que es `sticky` y crea su propio nivel de apilamiento. Ahora el estado vive en el componente principal (`historialNotasSel` = entidad + título) y el panel se dibuja ahí, fuera de ese contexto. Contenido igual (acción, quién, cuándo, texto, quién escribió la nota borrada); cierra con X y Escape. Ya no cierra por clic fuera (no hay fondo oscuro). Smoke test: 41 PASS / 0 FAIL; **no verificado visualmente en navegador real**, falta que el usuario lo confirme en Día y Semana.

- **Aplicado (fila 30):** el panel de historial de notas ahora también **cierra con clic fuera** (fondo transparente, sin oscurecer), además de X y Escape. Pedido del usuario.
- **Propuestas pendientes de autorización (a partir de 4 capturas del usuario, 2026-10-19):**
  1. **Autocompletado del navegador en "Nueva Solicitud":** la captura muestra que el navegador rellena Nombres con el nombre completo y Correo con el correo **del operador**, no del paciente (riesgo real: datos del operador en la ficha de un paciente). Propuesta: `autoComplete="off"` en los campos del paciente (nombres, apellidos, RUT, teléfonos, correo). Una separación automática nombre/apellidos vía `given-name`/`family-name` no aplica: no hay estándar para apellido materno y sería rellenar con datos del usuario, no del paciente.
  2. **Historial en "Notas de la Cita"** (dentro de PanelDetalle): sí, por consistencia con los otros 3 bloques y porque estaba marcado como hueco en §9.11. Entidad propia `notaCita:<ordenId>`; reutiliza el mismo panel de historial.
  3. **Encabezado "Resonador 1" en vista Día:** redundante cuando hay un solo equipo visible (el sidebar ya indica modalidad y equipo). Propuesta: ocultar esa fila solo si `equiposVisibles.length === 1`; con varios equipos (ej. RX) se mantiene.
  4. **Watermark y página en Agendamientos/Trazabilidad:** el wrapper de `ForensicWatermark` mide solo lo que mide el contenido, así que en vistas cortas la marca de agua termina a media pantalla (captura: corta a ~680px). Propuesta: `minHeight:"100vh"` en el wrapper. Es una marca forense: conviene que cubra siempre toda la pantalla.

- **Autorizado por el usuario y aplicado (filas 31-34), 2026-10-19:**
  - **31 · autocompletado:** `autoComplete="off"` en los 8 campos del paciente de Nueva Solicitud (lo llena personal administrativo, no el paciente).
  - **32 · Notas de la Cita con historial:** botón de historial en el bloque; alta y baja se registran en `auditoria` con entidad `notaCita:<ordenId>` (cierra el hueco de §9.11) y reutilizan `PanelHistorialNotas`.
  - **33 · encabezado de equipos en Día:** se oculta cuando hay un solo equipo visible y va centrado en su celda. **Matiz:** el usuario dijo "solo con múltiples modalidades", pero con RX (2 salas de la misma modalidad) quedarían columnas sin identificar, así que se mantiene con 2 o más equipos. Si prefiere el criterio literal, es cambiar `> 1` por `modalidadFoco === "todas"`.
  - **34 · marca de agua:** `minHeight:"100vh"` en el wrapper de `ForensicWatermark`; cubre toda la pantalla en vistas cortas (Agendamientos, Trazabilidad). No verificado en navegador real.

### 9.16 Consultas del usuario (2026-10-19) — sin cambios aplicados, esperan autorización
- **Colores de la cabecera en Semana:** lunes-viernes usan `C.bg` (más oscuro) y sábado-domingo `C.gridAlt` (más claro). En el cuerpo de Mes ocurre lo contrario (fin de semana más oscuro que la semana, que es blanca). Es una inversión visual, no un error de lógica. Propuesta: que la cabecera siga el mismo criterio que el cuerpo (fin de semana apenas más oscuro).
- **Tamaño Semana vs. Mes:** son distintos por diseño (Semana: cabecera con día + número grande y celdas con citas; Mes: panorama con solo el conteo, celdas de 70px). Propuesta: unificar solo la tipografía y el estilo de la cabecera de días; las celdas se quedan distintas. Pendiente confirmar qué "cuadros" quiere igualar.
- **Bloqueo de cupos (no existe hoy):** hoy solo se puede cancelar cita por cita y una celda vacía no se puede bloquear. Propuesta: acción "Bloquear" con alcance cupo / varios cupos (rango de horas) / día completo / varios días, por equipo, con motivo obligatorio. Las celdas bloqueadas se ven grises con candado, no aceptan citas ni drop, y quedan en el Historial del Cupo y Trazabilidad. Alineado con `SlotBlocked` / `AvailabilityException` de Arquitectura_Tecnica_Scheduling_Engine §6-7. Decisión abierta: qué hacer con citas ya existentes dentro del rango (recomendación: avisar y listarlas para reagendar, nunca cancelarlas automáticamente).

### 9.17 Sesión 3 (2026-10-19) — colores Mes/Semana, cabecera de Mes y **Bloqueo de cupos** (autorizado por el usuario)
- **Fila 35 · colores:** cabecera de sábado/domingo ahora `C.finde` (`#DCE5F4`, apenas más oscura que `C.bg`) en Semana y Mes; mismo criterio que el cuerpo (fin de semana más oscuro).
- **Fila 36 · cabecera de Mes:** la fila LUN-DOM pasa de ~25px a `minHeight:54` y tipografía igual a la cabecera de Semana. **Interpretación mía** de "los días de la semana del mismo tamaño que en Semana"; si se refería a las celdas de fecha (que siguen en 70px), falta confirmar.
- **Fila 37 · Bloqueo de cupos (nuevo):** botón **"Bloquear agenda"** en la cabecera. Modal: equipo, fecha desde/hasta (varios días), horario (**Todo el día / Rango de horas / Un cupo**) y motivo obligatorio; avisa cuántas citas agendadas/confirmadas quedan dentro de la zona.
  - **Visual:** celdas vacías bloqueadas en gris con rayas y candado; citas ya existentes dentro de la zona con gris, candado y borde rojo punteado.
  - **Citas existentes:** no se cancelan ni se mueven solas (decisión del usuario: **mover a mano**). `PanelDetalle` muestra alerta ("arrástrala a otro cupo o usa Reagendar Cita"); el panel del bloqueo lista las citas por mover y abre cada una.
  - **Reglas:** se pueden **arrastrar fuera** de la zona; **no** se puede soltar, reagendar, modificar ni crear citas **dentro** (excepción: Modificar Cita sin cambiar el cupo en una cita que ya estaba ahí). Clic en celda vacía bloqueada abre el detalle del bloqueo, con "Quitar bloqueo".
  - **Trazabilidad:** "Bloqueó agenda" / "Quitó bloqueo" en `auditoria`. Un bloqueo quitado queda `activo:false`.
  - **Límites conocidos / pendientes:** (a) el bloqueo todavía **no aparece dentro del Historial del Cupo** (solo en Trazabilidad); (b) quitar un bloqueo libera **todo el rango**, no hay desbloqueo parcial; (c) un bloqueo es por **un equipo** (no "todos los equipos de la modalidad"); (d) sin bloqueos recurrentes (ej. cada lunes); (e) vive en memoria, como el resto.
- **Smoke test:** ahora **49 PASS / 0 FAIL** (se agregaron 8 comprobaciones de bloqueo: abrir, exigir motivo, crear, celdas grises, clic abre el detalle, quitar, y las 2 acciones en Trazabilidad). Archivo actualizado: `smoke_agenda_imagenologia.cjs`. No verificado visualmente en navegador real.

### 9.18 Sesión 3 (2026-10-20) — historial visible del bloqueo y rol junto al nombre (autorizado por el usuario)
- **Fila 38 · Bloqueo en el Historial del Cupo:** cada cupo cubierto por un bloqueo (activo o ya quitado) muestra una entrada **"Bloqueado" / "Bloqueo quitado"** con rango, horario, motivo, **quién bloqueó** y, si se quitó, **quién desbloqueó y cuándo**. Un cupo libre que antes estuvo bloqueado queda con punto de historial. `historialDeCupo()` ganó el parámetro opcional `bloqueos` (8º). El registro del bloqueo ahora guarda `actorRol`, `quitadoPor`, `quitadoRol`, `quitadoTs`.
- **Fila 39 · Rol junto al nombre:** se muestra `rolLabel` al lado del nombre en el historial de notas (quién escribe/borra y "Escrita por"), Historial del Cupo (órdenes y movimientos), bloqueos y `PanelBloqueo`. **Es dato mock** (`USUARIOS_DEMO.rolLabel`): MAIN todavía cierra roles y workspaces; cuando existan, solo cambia la fuente de ese campo. Sin CUT, a pedido del usuario.
- **Pendiente de decisión:** ¿el desbloqueo lleva motivo? Recomendación: opcional (por defecto sin motivo, para no frenar la operación); hoy no se pide.
- **Smoke test:** 53 PASS / 0 FAIL (+4: bloqueo en el historial con nombre y rol, y rol en el historial de notas). No verificado en navegador real.
- **Fila 40:** el rol también se muestra bajo cada nota en la lista de **Notas de la Cita** (`PanelDetalle`) y en las notas del panel derecho; antes solo estaba en los historiales (captura del usuario).

### 9.19 Sesión 3 (2026-10-20) — motivos de bloqueo en lista y confirmación al desbloquear (autorizado)
- **Fila 41 · Motivo en lista:** el motivo del bloqueo es ahora un listbox cerrado (Mantención del equipo, Falla del equipo, Falta de personal, Reunión de personal, Capacitación, Licencia o vacaciones del profesional, Feriado o día no laborable, Limpieza o desinfección, Corte de energía o de sistema, Otro) + detalle opcional; con **"Otro" el detalle es obligatorio**. El bloqueo guarda `motivoTipo` (para contar por causa) y `motivo` (texto a mostrar). Constante `MOTIVOS_BLOQUEO`.
- **Fila 42 · Confirmación al desbloquear:** "Quitar bloqueo" pide confirmación ("Sí, quitar" / "Cancelar") que indica qué se libera (equipo, fechas, N días, horario). **Sin motivo** de desbloqueo, decisión del usuario.
- **Propuesto, pendiente de autorización:** desbloqueo **parcial** (por cupo, rango de horas/fechas, o total) en el mismo estilo del bloqueo. Hoy quitar libera todo el rango.
- **Smoke test:** 56 PASS / 0 FAIL (+3: «Otro» exige descripción, confirmación al quitar, cancelar mantiene el bloqueo).

### 9.20 Sesión 3 (2026-10-20) — desbloqueo parcial (autorizado)
- **Fila 43 · Desbloqueo parcial:** "Quitar bloqueo" ahora permite elegir **qué parte**: fecha desde/hasta (dentro del bloqueo) y horario **Todo el horario / Rango de horas / Un cupo**. Por defecto es el bloqueo completo. El resumen indica si libera todo o solo esa parte y cuántos días; sigue pidiendo confirmación y **sin motivo**.
- **Modelo:** el bloqueo sigue siendo **un solo registro** que acumula `liberaciones` (`fechaDesde/fechaHasta/horaDesde/horaHasta` + `por`, `rol`, `ts`). Un cupo sigue bloqueado mientras no caiga dentro de ninguna liberación (`liberacionDeCupo()`); si la liberación cubre todo el rango, el bloqueo queda `activo:false`. Los campos `quitadoPor/quitadoRol/quitadoTs` de §9.18 se reemplazaron por las liberaciones.
- **Historial del Cupo:** cada cupo muestra "Bloqueado" o "Bloqueo quitado" según si cae en una liberación, con quién bloqueó y quién desbloqueó. `PanelBloqueo` lista las "Partes ya liberadas". Trazabilidad: **"Quitó bloqueo"** (total) y **"Quitó bloqueo parcial"**.
- **Límites:** tras una quitada el panel se cierra; liberar una parte no divide el bloqueo en registros nuevos (se resuelve por liberaciones); sigue siendo por un solo equipo y sin bloqueos recurrentes; vive en memoria.
- **Smoke test:** **62 PASS / 0 FAIL** (+6: bloqueo parcial de un cupo, resumen, conteo 37→36, historial con quién desbloqueó). No verificado en navegador real.

### 9.21 Sesión 3 (2026-10-22) — "Cupo seleccionado" al desbloquear (autorizado)
- **Fila 44:** al hacer clic en un cupo bloqueado, el panel recuerda ese cupo (`bloqueoSelCupo`) y "Quitar bloqueo" ofrece: **Cupo seleccionado | Todo el horario | Rango de horas | Otro cupo**. **"Cupo seleccionado" viene marcado por defecto** (libera solo ese cupo: esa fecha y esa hora); "Todo el horario" pasa a ser elección consciente, para evitar liberar todo el rango por un clic distraído. "Otro cupo" reemplaza al antiguo "Un cupo": una fecha + una hora a elección (sugiere la del cupo clicado). Fechas desde/hasta solo aparecen en "Todo el horario" y "Rango de horas".
- **Resumen:** "Se liberará solo ese cupo: equipo · fecha · hora".
- **Smoke test:** 62 PASS / 0 FAIL (ajustados: el desbloqueo total ahora elige "Todo el horario"; el parcial usa el valor por defecto "Cupo seleccionado"). No verificado en navegador real.

### 9.22 Lectura de `Auditoria Agenda, MD y SmokeTest 22-10-2026.docx` (2026-10-22) — sin cambios aplicados
**Veredicto:** la auditoría es sólida y coincide con lo ya documentado (§10, Arquitectura Scheduling Engine). Su tesis central ("prototipo conservado como piloto funcional, no como fuente de verdad") es la misma del dossier. Verificado contra el JSX actual (3.577 líneas) lo que se puede verificar:
- **Confirmado:** (1) `generarBloques(8*60, 20*60, 20)` incluye 20:00 como hora de **inicio**; decidir si es cierre o cupo. (2) La búsqueda general de `SelectorCIE` usa siempre `CATALOGO_SEMILLA_CIE10`, aunque esté en modo CIE-11. (3) El catálogo guarda `405001` para varias prestaciones (incluida "RM DE HIPÓFISIS"). (4) `smoke_agenda_imagenologia.cjs` termina en `process.exit(0)` aunque haya FAIL, así que un sistema de CI lo daría por exitoso; además faltan `package.json` / `bundle.cjs` para reproducirlo.
- **Bug nuevo que la auditoría detecta y es real:** el `<select>` de hora de Nueva Solicitud solo lista `BLOQUES` (08:00–20:00). Al partir de un **sobrecupo** (ej. 07:40) la hora llega precargada pero el selector muestra "Hora…" (el valor no está en las opciones). Se guarda igual con esa hora, pero la pantalla engaña.
- **No verificable por mí:** el mapeo de códigos FONASA (la auditoría afirma que 0405002 = hipotálamo-hipófisis según el arancel 2025). No se corrige a ciegas: validar las 107 prestaciones contra la fuente y versión de arancel, guardar los códigos como texto con su cero inicial.
- **Puntos de la auditoría que ya estaban resueltos o documentados:** persistencia (límite honesto de memoria), duración variable (§10.2), Slot como Aggregate Root (§5), CUP generado localmente (§9.2, MasterIdentifierService), overbooking ≠ sobrecupo.
- **Fuera de alcance de este archivo (backend/MAIN):** PostgreSQL con restricciones de solapamiento, FHIR R4 real (`ServiceRequest`/`Appointment`/`Schedule`/`Slot`), terminología CIE/FONASA servida por MAIN, pago y consentimiento, Workflow/Dashboard/Document Engine, NID Bridge, puerta para IA. Todo consumido por contrato; el JSX no los implementa.
- **Nota:** la auditoría cita un `Dossier_..._Actualizado_2026-10-16.md` que **no está en el proyecto**; no pude cruzarlo.
- **Correcciones inmediatas propuestas (pendientes de autorización):** (a) smoke test que falle de verdad (`process.exit(fallas ? 1 : 0)`) y sume `package.json`; (b) incluir la hora precargada en el selector cuando no esté en `BLOQUES`; (c) la búsqueda general de CIE debe respetar la norma elegida (mientras no exista catálogo CIE-11 en el prototipo, avisar en vez de mostrar CIE-10); (d) decidir el significado de las 20:00; (e) validación sistemática de códigos FONASA (necesita la fuente).

### 9.23 Sesión 3 (2026-10-22) — correcciones inmediatas de la auditoría (autorizadas: 2 y 1)
- **Fila 45 · hora de sobrecupo en Nueva Solicitud:** el selector de hora ahora incluye la hora precargada cuando no está en `BLOQUES` (ej. 07:40), rotulada "07:40 ⚡ sobrecupo", en orden cronológico. Antes mostraba "Hora…" aunque la cita se guardaba con esa hora.
- **Fila 46 · smoke test:** termina con `process.exit(fallas ? 1 : 0)` (antes siempre 0). Verificado: con un FAIL forzado devuelve código 1. **Sigue faltando** un `package.json` para reproducirlo sin instrucciones manuales (§9.12).
- **Smoke test:** 65 PASS / 0 FAIL (+3 de sobrecupo).
- **Pendientes de §9.22 sin aplicar:** (3) búsqueda CIE que respete la norma elegida; significado de las 20:00; validación de códigos FONASA contra la fuente.

### 9.24 Sesión 3 (2026-10-22) — CIE por norma, cierre 20:00 y FONASA (decisiones del usuario)
- **Fila 47 · CIE respeta su norma:** la búsqueda general de `SelectorCIE` usa el catálogo de la norma elegida. Nuevo `CATALOGO_SEMILLA_CIE11`, armado solo con los códigos CIE-11 que ya existían en `MAPEO_CIE`/`CIE_GENERAL` (no se inventó ninguno). Muestra "Catálogo de muestra CIE-X (N códigos) — lo reemplaza el servicio terminológico de MAIN" y "Sin resultados…" cuando corresponde. **Es mock:** CIE-10 y CIE-11 los sirve MAIN, con versión y vigencia.
- **Fila 48 · 20:00 es el cierre, no un cupo:** el último cupo regular parte a las **19:40**; 20:00 pasa a ser el **primer sobrecupo de la tarde** (antes 20:20). El horario vive en tres constantes (`HORARIO_APERTURA_MIN`, `HORARIO_CIERRE_MIN`, `PASO_BLOQUE_MIN`) y es **configurable por tenant** (cada institución tiene horarios, aperturas y duraciones distintos): hoy es mock; lo gobernará "Configurar agenda" cuando exista el motor. Cambió también el rango por defecto del modal de bloqueo (08:00–19:40).
- **FONASA (decisión del usuario):** los códigos del catálogo de Resonancia Magnética salen del CSV del usuario: son códigos FONASA y **códigos internos propios** para prestaciones nuevas que está abriendo en su región, asimilados a los de FONASA (por eso varias prestaciones comparten un código base y `codigoInterno` las distingue). **No se valida contra el arancel ahora**: la auditoría lo tomó como inconsistencia, pero es diseño. La validación y el catálogo maestro son **trabajo de MAIN** (la Agenda lo consumirá). Queda **pendiente** informar a MAIN de esta regla de asimilación de códigos internos a FONASA.
- **Pendiente:** actualizar `Sincronizacion_Satelites_MAIN.md` (sin actualizar desde la sesión 2) con estas decisiones: catálogo de prestaciones y CIE servidos por MAIN, horarios configurables por tenant, códigos internos asimilados a FONASA.
- **Smoke test:** 68 PASS / 0 FAIL (+3: CIE-11 vs CIE-10, y el último cupo regular es 19:40). No verificado en navegador real.

### 9.25 Sesión 3 (2026-10-22) — pendientes de UI/UX/accesibilidad (autorizado: todo menos celular/tablet)
- **Fila 49 · Bloqueos en Mes:** cada día muestra "Día bloqueado" (fondo gris con rayas) o "N cupos bloqueados" para el equipo en foco.
- **Fila 50 · Leyenda:** se agregaron "Bloqueado" y "Por mover" (cita dentro de un cupo bloqueado).
- **Fila 51 · Arrastrar sobre zona bloqueada:** el cursor pasa a "no permitido" y la celda se marca en rojo con "Bloqueado" mientras se arrastra encima (antes no pasaba nada visible).
- **Fila 52 · Letras:** ningún texto queda bajo **10 px** (había de 7 a 9.5 px); celdas de Día/Semana con textos más grandes (nombre 11–12, detalle 10–11) y alturas de celda mayores (Día 60, Semana 54). Badges 10/11. **Revisar en pantalla:** celdas ocupadas más altas y posibles recortes en columnas angostas.
- **Fila 53 · KPIs** con el fondo gris de los paneles laterales (`C.panelGris`). Reversible: una línea en `KPICard`.
- **Fila 54 · Accesibilidad de diálogos:** hook `useDialogo` en los 10 paneles/modales: **Escape cierra solo el de arriba** (pila), el foco entra al abrir y **vuelve al elemento anterior** al cerrar, `role="dialog"` + `aria-modal`. **Pendiente:** atrapar Tab dentro del diálogo.
- **Fila 55 · "Mover cita" (alternativa a arrastrar):** botón en el detalle y diálogo con equipo (misma modalidad), fecha y hora; mismas validaciones que arrastrar (bloqueo, cupo ocupado, modalidad). Queda en el Historial del Cupo como "Movido (Mover cita)" y en Trazabilidad como "Movió cita".
- **Fila 56 · Revertir No-Show:** botón en citas "No Asistió"; vuelve al estado previo (`estadoAntesDeNoShow`; si es dato de muestra sin ese campo, a "Agendado"). Trazabilidad: "Revirtió no-show".
- **Fila 57 · Pestaña Auditoría del cupo:** el Historial del Cupo (en el detalle y en el panel de cupo vacío) tiene pestañas **Historial | Auditoría (N)**; la segunda filtra la auditoría de la sesión a los eventos que tocaron ese cupo (órdenes, movimientos, bloqueos).
- **Pendiente de decisión:** cabecera de Mes (¿se quería igualar la cabecera o las celdas de fecha?); color oficial del módulo (espera a MAIN); botones Exportar/Imprimir/Configurar agenda (esperan al motor).
- **Pendiente a propósito (celular y tablet):** punto de quiebre único a 860 px, filas anchas y formularios, paneles laterales de 400–420 px. **El usuario avisó que se retoma al final: recordárselo cuando todo lo demás esté resuelto.**
- **Smoke test:** 82 PASS / 0 FAIL (+14). Las pruebas siguen sin cubrir el aspecto visual real.

### 9.26 Revisión punto por punto de la 2ª mitad de `Auditoria Agenda, MD y SmokeTest 22-10-2026.docx` (desde "1. Decisiones que fijaría para evitar duplicaciones en MAIN") — 2026-10-23
**Aclaración honesta:** en §9.22 leí esa mitad solo a nivel resumen ("backend/MAIN"). Esta es la revisión punto por punto. Nada aplicado al JSX.
1. **Responsabilidades (tabla "fuente de verdad"):** coherente con lo ya decidido (CIE y prestaciones/FONASA los sirve MAIN; Agenda es dueña de reserva/disponibilidad; Account Core del precio y cobro; Workflow de la llegada; Dashboard consume eventos; NID Bridge traduce; Dominium configura). Sin cambios para el JSX. Dato a verificar fuera de este proyecto: lo que cita de la guía EIS v0.2.0 y la Norma 820 (no lo pude comprobar).
2. **Recursos FHIR R4:** la separación `ServiceRequest` (qué examen) / `Appointment` (reserva) / `Schedule` + `Slot` (disponibilidad) es correcta. Los estados de la tabla de correspondencia calzan con R4 (`Appointment`: proposed, pending, booked, arrived, fulfilled, cancelled, noshow, checked-in, waitlist; `Slot`: free, busy, busy-unavailable, busy-tentative; sin "rescheduled"). **Mapeo a nuestros estados:** "Bloqueado" = `Slot busy-unavailable`; "No Asistió" = `noshow`; "Cancelada" = `cancelled`; "Reagendada" = no existe en FHIR (cita nueva + vínculo interno); "En Espera" es **cola de Workflow**, no un estado FHIR; "En Atención" = `Encounter in-progress`; "Atendido" = `Appointment fulfilled`, separado del informe. "Agendado/Confirmado" no son estados FHIR distintos: la confirmación del paciente va en `participant.status` (accepted/tentative). **Punto útil para nuestro catálogo:** `codigosFacturacion` (varios códigos por prestación) NO va como varios `coding` equivalentes en `ServiceRequest.code`; la prestación clínica y sus códigos de facturación se relacionan por separado.
3. **CIE por prestación:** el documento recomienda sugerir (no asignar) indicaciones, guardarlas como concepto codificado (sistema + versión + código + display) y que el mapeo prestación→indicaciones tenga gobierno clínico y lo sirva MAIN. **Brecha real en el JSX:** `SelectorCIE` recibe modalidad y subespecialidad, **no la prestación seleccionada**, y las selecciones se guardan como texto "código - descripción". Lo que pediste ("al elegir RM de columna, que aparezcan todas las lesiones de columna") **no está implementado** en el prototipo. Opciones: (a) mock por prestación con una región anatómica en el catálogo (necesito esa columna o los rangos CIE por región), (b) dejarlo definido como contrato para MAIN. Pendiente de tu decisión.
4. **Prestaciones, pago y consentimiento:** flujo propuesto (elegibilidad → *hold* con vencimiento → precio y pago por Account Core → confirmación transaccional → preparación/consentimiento) es razonable y **no corresponde al JSX** (necesita backend, pasarela e idempotencia). Recomienda no imponer pago anticipado a todos: depende del pagador/convenio. El consentimiento sigue siendo evidencia aparte, versionada; nunca un booleano en la cita. Nuestro JSX ya lo separa (puerta etiquetada de firma).
5. **UnitShell, Workflow, Dashboard, Document Engine:** de acuerdo en que "Activar llegada" por recepción/tótem/portal debe ser una **misma operación idempotente** que publica un evento a Workflow; hoy el JSX cambia el estado local (válido como prototipo). Exportar/Imprimir → Document Engine; indicadores reales → Dashboard; "Configurar agenda" → configuración por tenant (Dominium solo políticas globales).
6. **NID Bridge / Dominium:** modelo canónico interno + traducción por destinatario; diferenciar `AuditEvent` (acceso/auditoría) de `Provenance` (quién creó/modificó). Coincide con lo que ya separamos en Trazabilidad (acciones) y el historial. Sin cambios en el JSX.
7. **IA:** el documento recomienda **no** poner un botón o agente ficticio; definir condiciones (APIs autorizadas, nunca escribir directo en la base, propuesta hasta confirmación, trazabilidad). **Hoy el JSX no tiene ninguna puerta de IA**, y eso es coherente. Si quieres una puerta etiquetada visible, es decisión tuya.
8. **StandardService.js:** no está en el proyecto; ni el documento ni yo podemos afirmar qué hace. **Para avanzar necesito el archivo.**
- **Lo que el documento NO entrega (y la pregunta original pedía):** instancias FHIR validadas. Los JSON son esqueletos con marcadores `{...}`. Validar de verdad exige el validador FHIR y el paquete de perfiles chilenos (IG EIS), que no tengo. **Propuesta útil y factible:** un MD de **mapeo campo por campo** (cada campo de la orden del JSX → elemento FHIR, qué recurso, qué falta) para entregar a MAIN.

---
## 11. MAPA DE ALINEACIÓN Y SINCRONIZACIÓN — Agenda de Imagenología ↔ MAIN y capabilities transversales (2026-10-23)

> **Para qué sirve:** que MAIN y cada motor vean, en un solo lugar, qué entrega la Agenda, qué espera recibir y qué le falta hoy. Está escrito **desde el lado Agenda**: lo que dice de otros módulos es lo que la Agenda **necesita o propone**, no lo que ellos ya hacen; cada contrato lo confirma el dueño del módulo.
> **Leyenda:** ✅ existe en el JSX (verificado) · 🧪 simulado con datos de muestra · 🚪 puerta etiquetada (botón deshabilitado, sin nada detrás) · ⬜ no existe, es propuesta. Cuando un módulo ya aparece en documentos del proyecto lo indico; si no, queda como **supuesto**.

### 11.1 Qué tiene hoy la Agenda (inventario verificado en `AtencionAgendaImagenologia (Nuevo 16-10).jsx`)
- **Entidad principal `orden`** (cita + solicitud juntas): identificadores (`id`, `acc`/`ot` en `null` hasta Admisión), `equipoId`, `modalidad`, `fecha`, `hora`; `paciente` (CUP, RUT, nombres, apellidos, fecha de nacimiento, `telefono1/2`, `correo`); `prestacion` (modalidad, subespecialidad, `codigoFonasa`, `codigoInterno`, `codigosFacturacion[]`, contraste, lateralidad) + `nombreFinal`; consentimiento (`requiere`, `plantilla`, `estado`); creatinina (`requiere`, `adjunta`, `exprés`); `ordenMedica` (adjunta, médico solicitante + id, fecha, diagnóstico de sospecha); `diagnosticos[]` (texto "código - descripción"); `adjuntosPrevios`; `notasCita[]`; `canal`, `canalLlegada`; `estado` y `estadoAntesDe…`; vínculos de reagendamiento; `motivoCancelacion`; atribución `agendadoPor*` y `agendadoOriginalmentePor*`.
- **Otras entidades en memoria:** equipos (`EQUIPOS`, 6, solo nombre/modalidad/área), bloqueos (con `liberaciones`), `movimientosCupo`, `auditoria`, notas (generales / día de la semana / fecha), sobrecupos AM/PM, médicos referentes, usuarios de prueba con `rolLabel`.
- **Estados propios:** agendado, confirmado, en espera, en atención, atendido, no asistió, cancelada, reagendada. **En espera / en atención / atendido son reflejo del módulo operativo**, no los controla la Agenda.
- **Seguridad:** marca de agua forense, botón de pánico (`moduleId: img_agenda`), auditoría de acciones y de vistas, `deviceId` simulado.
- **Puertas etiquetadas (todas 🚪, deshabilitadas):** Consentimientos ↗ / Ver-Firmar consentimiento (FESpa/FESpro), Enviar a módulo operativo RIS-PACS ↗, Cobrar Cita (Bonos y Pagos) ↗, Reenviar confirmación WhatsApp/Correo, Leer datos automáticamente (OCR), Escanear (hardware), Exportar citas ↗, Configurar agenda. **Simulados (🧪):** tótem y Portal Paciente como canales de llegada.

### 11.2 Brechas PROPIAS de la Agenda (lo que le falta aunque nadie más cambie)
| # | Brecha | Efecto | Quién la cierra |
|---|---|---|---|
| P1 | Todo vive en memoria de sesión (órdenes, bloqueos, auditoría, notas) | Se pierde al recargar; no hay concurrencia ni auditoría duradera | Scheduling Engine (backend) |
| P2 | Ocupación por `equipo + fecha + hora`, bloques fijos de 20 min (constantes mock) | No hay duración variable, buffers, ni intervalos `startAt/endAt` | Scheduling Engine + "Configurar agenda" |
| P3 | Sin *Slot* ni *Occupancy* como entidades; el historial del cupo es **derivado** | Historial correcto para demo, no fuente de verdad | Scheduling Engine |
| P4 | `orden` mezcla solicitud clínica, reserva y estado operativo | Hay que separar `ServiceRequest` / `Appointment` / estado de ejecución | Scheduling + Interop |
| P5 | Sobrecupo = horas extra fuera de horario; **no existe overbooking real** (2 citas en un cupo) | Capacidad por política pendiente | Scheduling Engine |
| P6 | Un solo recurso por cita (el equipo); sin profesional/sala/técnico | Decisión abierta: ¿la Agenda debe saber el tecnólogo/radiólogo? | Decisión del usuario + Workforce |
| P7 | **Imagenología no captura pagador/convenio** (Atención Médica sí tiene `PAGADORES`) | Sin eso no se puede resolver precio ni cobro anticipado | Definir con Account Core |
| P8 | CIE no depende de la prestación elegida (solo modalidad + subespecialidad) y se guarda como texto | No cumple "al elegir RM de columna, mostrar lesiones de columna"; no es dato codificado | MAIN (mapeo) + Agenda (consumo) |
| P9 | Documentos adjuntos: solo se guarda el **nombre**; la foto de cámara no se persiste | No hay documento real asociado | Document Engine |
| P10 | Reglas de consentimiento y creatinina escritas en el código; CR/US/MG sin matriz confirmada | Un cambio clínico exige tocar código | Consent Engine / reglas |
| P11 | Roles, usuarios y `deviceId` son de prueba; CUP/CUT se generan en el navegador | No hay autorización real ni identidad central | MAIN (Identity, roles, UnitShell) |
| P12 | Timestamps guardados como texto formateado; IDs con `Date.now()` | Dificulta ordenar eventos de varias fuentes | Backend |
| P13 | Horario de atención fijo (08:00–20:00) | Cada tenant tiene el suyo | "Configurar agenda" / Tenant config |
| P14 | Los bloqueos son por **un equipo** y **sin recurrencia** | No cubre "todos los lunes" ni "toda la modalidad" | Agenda (siguiente iteración) |
| P15 | Accesibilidad: falta atrapar Tab en diálogos; todo el trabajo **celular/tablet** quedó para el final | Pendiente declarado | Agenda (UI) |
| P16 | Pruebas: `smoke_agenda_imagenologia.cjs` valida comportamiento, no aspecto ni backend | Cobertura visual real = ninguna | Agenda + QA |

### 11.3 Mapa por módulo: qué entrega la Agenda, para qué, y qué espera recibir
> Columnas: **Agenda ofrece** (salida) · **Para qué** · **Agenda espera recibir** (entrada) · **Hoy** (estado real) · **Brecha / decisión abierta**.

| Módulo / capability | Agenda ofrece | Para qué | Agenda espera recibir | Hoy | Brecha / decisión |
|---|---|---|---|---|---|
| **MAIN · Identidad y paciente** (MasterIdentifierService, registro maestro) | Referencia al paciente (CUP); datos mínimos para registrar uno nuevo | Una sola identidad de persona en toda la plataforma | CUP/CUT válidos y resolución de paciente; ciclo de vida (CUT revocado, ficha archivada por fallecimiento, CUP-NN/RN) | 🧪 replica el algoritmo CHK2 en el navegador (`sha256Hex`) | La Agenda **no debe generar** CUP; falta `telefono/correo` en `IDENTITY_SCHEMA.PERSON_FIELDS` (punto 1.6) |
| **MAIN · Seguridad** (`security.config.js`, `deviceUUID`, `aes`) | Acciones y vistas auditables; `moduleId`; marca de agua y pánico | Cumplir `audit.criticalEvents` (ver imagen/historial = auditable) | Valores únicos de marca de agua y `holdMs` del pánico; `deviceUUID` real; auditoría persistente con retención | 🧪 valores propios (0.07 / 21 px); auditoría en memoria | Sigue abierto: valor único de marca de agua (1.4) y gatillo de pánico por mantener presionado (1.5) |
| **MAIN · Roles, UnitShell, Workforce** | Pide permiso por acción (ver, agendar, confirmar, cancelar, bloquear, desbloquear, mover); contexto de OrgNode/servicio/ubicación/equipo | Que cada persona vea y haga solo lo que su asignación permite | Permisos efectivos y contexto activo; **cargo/rol real** (hoy `rolLabel` de prueba); turnos de profesionales si pasan a ser recurso | 🧪 usuarios de prueba | Roles y workspaces aún los cierra MAIN; la Agenda solo cambia la fuente del dato |
| **MAIN · Catálogo de prestaciones** (+ códigos FONASA/internos) | Nada; es **consumidor** | Que Agenda, Consentimiento, Pago y Facturación usen el mismo catálogo | Prestación canónica con: códigos FONASA, **códigos internos asimilados a FONASA** (regla del usuario), modalidad, región anatómica, contraste, lateralidad, duración, preparación, reglas de consentimiento y condiciones de cobro | 🧪 catálogo local (107 de RM del CSV; CT/CR/US/MG de relleno) | Validar códigos y mantener el catálogo es de MAIN. Falta informarles la regla de códigos internos |
| **MAIN · Terminología (CIE-10/11)** (`TerminologyService`) | Contexto: prestación, modalidad, subespecialidad; la selección del profesional | Indicación clínica **codificada**, con versión | Búsqueda CIE-10/CIE-11 versionada; **sugerencias por prestación** (mapeo gobernado); concepto estructurado (sistema, versión, código, texto) | 🧪 catálogos de muestra por norma (CIE-11 armado con los códigos ya existentes) | P8: hoy la sugerencia es por modalidad+subespecialidad; falta por prestación |
| **MAIN · Configuración de módulos** (`modules.config.js`, colores, granularidad `clin_esp`) | Pide id de módulo y color oficial | Que todas las unidades de agenda se vean y se nombren igual | Color oficial; decisión de si `clin_esp` se desagrega | 🧪 color azul de prueba | Espera la asignación de colores de MAIN |
| **Scheduling Engine** (futuro backend de la Agenda) | Contrato funcional: citas, bloqueos, movimientos, estados, atribución; la UI como cliente | Que la verdad (disponibilidad, reservas, conflictos) no viva en React | API de disponibilidad por intervalos, reserva con *hold*, reagendar/cancelar con motivo, bloqueos con liberación parcial, línea de tiempo del cupo, versión/concurrencia, idempotencia | ✅ prototipo funcional como **referencia de comportamiento** | P1–P5, P12, P13 |
| **Motor DICOM / RIS-PACS** (`HIS-RIS-PACS.jsx`) | Cita confirmada o en espera con: CUP, prestación (con lateralidad y contraste), modalidad, equipo, fecha/hora, médico solicitante → alimenta la **worklist (MWL)** | Que el estudio nazca de una cita real | **ACC y OT** (se asignan en Admisión; la Agenda no los inventa); estado operativo (en atención, atendido); informe finalizado; cancelaciones o no-show de ellos | 🚪 botón "Enviar a módulo operativo RIS-PACS"; ✅ ACC/OT en `null` | Contrato de eventos pendiente; **no-show y cancelación son solo de la Agenda** (confirmado en la revisión de RIS-PACS) |
| **Account Core** (contabilidad, cobro) | Evento de **intención financiera**: cita creada/confirmada/cancelada/no-show; referencia a prestación y códigos de facturación (sin precio) | Que el cobro anticipado y la cuenta final no se mezclen | Precio, cobertura, copago, **estado de pago**; política de cobro por pagador; confirmación del pago para confirmar la cita | 🚪 "Cobrar Cita (Bonos y Pagos)" | **P7**: falta capturar pagador/convenio; definir en qué momento paga el paciente (portal) |
| **Motor de Consentimiento (FES)** | Si la prestación exige consentimiento, qué plantilla, datos del paciente para prellenar, nombre final de la prestación | Consentimiento versionado y firmado antes del examen | Estado (pendiente / firmado FESpa+FESpro), referencia a la evidencia (PDF, hash, versión), vínculo al estudio o atención | 🚪 botones de firma; 🧪 estado de muestra | P10: reglas hoy en código; CR/US/MG sin matriz confirmada |
| **Document Engine** | Solicitudes: imprimir/exportar citas del día, comprobante de cita, hoja de preparación; almacenar orden médica, informes previos, creatinina, fotos | Documentos con plantilla, permisos y marca | PDF/Excel generado; documento persistido con **id, hash y metadatos**; URLs de acceso con permiso | 🚪 "Exportar citas"; nombre de archivo solo | P9 |
| **Dashboard Engine / Gestión–Alta Calidad** | Eventos con **atribución** (quién agendó originalmente / quién reagendó), estados, motivos de cancelación y de bloqueo (por causa), no-show y su reversión, canal de reserva y de llegada, tiempos | KPI de producción, ocupación, inasistencia, bloqueos por causa | Nada operativo (solo consume) | 🧪 4 KPI locales a propósito; datos listos para consumir | P12: falta evento persistente con hora ISO |
| **Workflow Engine** | Evento **"llegada"** (canal: recepción, tótem o portal) y cita confirmada | Coordinar cola, asignación y paso a atención | Inicio y fin de atención; cola; asignaciones; estado final | 🧪 "Activar llegada" cambia el estado local; tótem y portal simulados | Debe ser **una misma operación idempotente** para los 3 canales |
| **Notificaciones** (WhatsApp / correo) | Eventos creada/confirmada/reagendada/cancelada con el contacto del paciente | Confirmación y recordatorios | Estado de entrega; **respuesta del paciente** (confirmar o cancelar por mensaje) | 🚪 aviso y "Reenviar confirmación" | Falta contacto en el esquema central; política de recordatorios |
| **Portal Paciente / Tótem** | Disponibilidad **publicable** (sin nombres internos), reserva con *hold*, activar llegada | Que el paciente reserve, pague y llegue solo a examinarse | Solicitudes de reserva, cancelaciones del paciente (**sin motivo obligatorio**), pago, consentimiento previo, llegada | 🧪 simulados | Requiere Scheduling Engine con *hold* y Account Core |
| **Atención Presencial / Telemedicina / otras agendas** | Mismo patrón de UI y de datos (historial del cupo, bloqueos, notas, atribución) | Una sola experiencia de agenda en las ~19 unidades | Estados de atención (`Encounter`); en telemedicina, sala virtual como recurso | ⬜ propagación **enfoque B** decidida y sin empezar | Pendiente desde la sesión 3 |
| **AIMS** (activos e infraestructura) | Reservas por equipo; bloqueos por "Mantención" o "Falla" con motivo | No agendar sobre un equipo caído | **Catálogo de equipos** (tipo, capacidades, sede); **estado operativo** y calendario de mantenciones (idealmente bloqueos automáticos) | 🧪 `EQUIPOS` de prueba | Compatibilidad prestación↔equipo hoy solo por modalidad |
| **Workforce / RR.HH.** | Atribución por persona (CUT) | KPI por agendador | Asignaciones y turnos si el profesional pasa a ser recurso | 🧪 | P6 |
| **OCR / Document AI** | Documento de la orden médica | Pre-llenar solicitante, fecha, diagnóstico | Campos extraídos **con nivel de confianza**, para validación humana | 🚪 | Nunca debe volverse dato clínico sin validar |
| **NID Bridge / Dominium** | Modelo canónico (órdenes, citas, disponibilidad) | Traducir a FHIR R4 / HL7 según el destinatario; configurar conexiones | Recursos validados, rechazos y reintentos; parámetros de conexión | ⬜ nada implementado en el JSX | Mapeo campo → FHIR pendiente (ver §9.26) |
| **IA transversal** | Contexto autorizado y eventos | Sugerir horarios o indicaciones, **siempre como propuesta** | Propuestas con modelo, versión y decisión del usuario | ⬜ sin puerta (a propósito) | Decisión tuya: ¿puerta etiquetada visible o solo contrato? |
| **Supply / Farmacia** (insumos, contraste) | Qué prestaciones llevan contraste | Prever insumos | **Sin contrato definido**; no lo invento | ⬜ | Pregunta abierta para MAIN |

### 11.4 Eventos: lo que la Agenda emitiría y lo que debería recibir (propuesta, no existe aún)
**Emite:** `CitaCreada` · `CitaConfirmada` / `CitaDesconfirmada` · `CitaModificada` · `CitaReagendada` (origen → destino; vínculo) · `CitaMovida` (arrastrar, Mover cita o Modificar) · `CitaCancelada` (**motivo obligatorio si es personal de la agenda**) · `NoShowMarcado` / `NoShowRevertido` · `LlegadaActivada` (canal) · `CupoBloqueado` (equipo, fechas, horas, **motivo por causa**) · `BloqueoLiberado` (total o parcial) · `NotaAgregada` / `NotaEliminada` · `DetalleConsultado` / `HistorialCupoConsultado` (auditoría de lectura).
**Debe recibir:** `AccessionAsignado` (ACC/OT) · `EstadoOperativoRecibido` (en atención, atendido) · `InformeFinalizado` · `ConsentimientoFirmado` · `PagoRegistrado` / `PagoFallido` · `EquipoFueraDeServicio` / `MantencionProgramada` · `ReservaSolicitadaPorPaciente` · `CancelacionSolicitadaPorPaciente` · `RespuestaDeConfirmacion`.
Todo evento con `eventId`, `tenantId`, `occurredAt` ISO, actor (persona, rol, canal), `correlationId` y `causationId`.

### 11.5 Reglas de alineación que ya están decididas y se mantienen
1. La Agenda **no genera** ACC, OT ni identidades; los recibe.
2. Estados operativos (en espera, en atención, atendido) **los refleja**, no los controla.
3. **No-show y cancelación son exclusivos de la Agenda**; nunca llegan al módulo operativo.
4. Catálogos (CIE y prestaciones/FONASA) **los sirve MAIN**; la Agenda solo consume y guarda referencia + versión.
5. Precio y cobro son de Account Core; la Agenda solo expresa la intención.
6. Consentimiento es evidencia aparte y versionada; nunca un booleano en la cita.
7. Cancelar por personal pide motivo; reagendar y mover no. Si algún día el **paciente** cancela por portal, ese flujo no hereda el requisito.
8. Las citas en un cupo bloqueado **no se mueven solas**: se mueven a mano; no se aceptan citas nuevas en la zona.
9. El horario de atención es **configurable por tenant**; el cierre no es un cupo.
10. Una acción de lectura de datos clínicos es auditable.

### 11.6 Qué necesita la Agenda de MAIN para avanzar (en orden de impacto)
1. Contrato del **catálogo de prestaciones** (campos, región anatómica, duración, reglas de consentimiento y cobro) y la regla de **códigos internos asimilados a FONASA**.
2. Servicio **terminológico**: CIE-10/11 y sugerencias por prestación.
3. Contrato de **eventos operativos** con RIS-PACS (ACC/OT y estados) y con **Workflow** (llegada).
4. **Pagador/convenio** y momento del pago (Account Core + Portal).
5. **Roles y permisos por acción** (UnitShell) y contexto de tenant, para sustituir los usuarios de prueba.
6. Respuesta sobre `IDENTITY_SCHEMA` (teléfono/correo), color oficial del módulo, y valor único de marca de agua.
7. Archivo **`StandardService.js`** (no está en el proyecto; sin él no puedo decir qué resuelve).

### 11.7 Qué hace falta de TI (Agenda) para no frenar a los demás
Separar en el JSX las capas (presentación / datos / reglas) para que cada puerta etiquetada pase de botón deshabilitado a una llamada real sin rehacer pantallas; reemplazar `Date.now()` y `toLocaleString` por identificadores y fechas ISO entregados por el backend; y mantener `smoke_agenda_imagenologia.cjs` como prueba de regresión del frontend.
