const { JSDOM } = require("jsdom");
const dom = new JSDOM("<!doctype html><html><body><div id='root'></div></body></html>", { url: "http://localhost/", pretendToBeVisual: true });
const { window } = dom;
for (const k of Object.getOwnPropertyNames(window)) { if (k in globalThis) continue; try { globalThis[k] = window[k]; } catch (e) {} }
globalThis.window = window; globalThis.document = window.document;
Object.defineProperty(globalThis, "navigator", { value: window.navigator, configurable: true });
globalThis.IS_REACT_ACT_ENVIRONMENT = true;
window.HTMLCanvasElement.prototype.getContext = function () { return { font: "", measureText: (t) => ({ width: String(t).length * 10 }) }; };
window.Element.prototype.scrollTo = function () {};

const errores = [];
console.error = (...a) => { const m = a.map(String).join(" "); if (!/not wrapped in act|IS_REACT_ACT_ENVIRONMENT/.test(m)) errores.push(m.slice(0, 260)); };

const React = require("react"); const { createRoot } = require("react-dom/client"); const { act } = require("react-dom/test-utils");
const Comp = require("./bundle.cjs").default;
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const $ = (s, el = document) => el.querySelector(s);
const txt = () => document.body.textContent;
const click = async (el) => { if (!el) throw new Error("click: elemento no encontrado"); await act(async () => { el.dispatchEvent(new window.MouseEvent("click", { bubbles: true, cancelable: true })); }); };
const typeIn = async (inp, v) => { const set = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value").set; set.call(inp, v); await act(async () => { inp.dispatchEvent(new window.Event("input", { bubbles: true })); }); };
const selectVal = async (sel, v) => { const set = Object.getOwnPropertyDescriptor(window.HTMLSelectElement.prototype, "value").set; set.call(sel, v); await act(async () => { sel.dispatchEvent(new window.Event("change", { bubbles: true })); }); };
const btn = (t) => $$("button").find((b) => b.textContent.trim() === t);
const selWith = (t) => $$("select").find((s) => [...s.options].some((o) => o.textContent.trim() === t || o.textContent.includes(t)));
const out = [];
const ok = (n, c, x = "") => { out.push((c ? "PASS " : "FAIL ") + n + (x ? "  [" + x + "]" : "")); };
const esc = (f) => async () => { try { await f(); } catch (e) { out.push("FAIL (excepción) " + f.name + ": " + (e && e.message)); } };

(async () => {
  const root = createRoot(document.getElementById("root"));
  await act(async () => { root.render(React.createElement(Comp, {})); });

  await esc(async function inicial() {
    ok("render inicial", txt().includes("Agenda de Imagenología"));
    ok("panel de notas (RM)", txt().includes("Notas — Resonancia (RM)"));
    ok("3 botones de historial de notas", $$('button[aria-label="Historial de este bloque de notas"]').length === 3);
    const pat = $('pattern[id^="axon-watermark-tile-"]');
    ok("watermark: pattern con id único y tileW dinámico", !!pat && Number(pat.getAttribute("width")) > 250, pat && pat.getAttribute("width"));
    ok("cinta de días: 1 pill activo", $$("[data-pill-activo]").length === 1);
  })();

  await esc(async function notas() {
    const inputs = () => $$('input[placeholder="Escribir nota..."]');
    await typeIn(inputs()[0], "Laxante la víspera");
    await click(inputs()[0].nextElementSibling);
    ok("nota agregada aparece", txt().includes("Laxante la víspera"));
    await click($$('button[aria-label="Historial de este bloque de notas"]')[0]);
    let m = $('[role="dialog"]');
    ok("historial (1): muestra el rol junto al nombre", !!m && m.textContent.includes("Personal Administrativo"));
    ok("historial (1): muestra 'Agregó nota' + actor + texto", !!m && m.textContent.includes("Agregó nota") && m.textContent.includes("Pamela Iturra Vásquez") && m.textContent.includes("Laxante la víspera"));
    await click($('[role="dialog"] button[title="Cerrar"]'));
    ok("historial se cierra con X", !$('[role="dialog"]'));
    // otro usuario borra la nota
    const selU = selWith("Viendo como: Marcelo");
    const optM = [...selU.options].find((o) => o.textContent.includes("Marcelo"));
    await selectVal(selU, optM.value);
    const textEl = $$("div").find((d) => d.children.length === 0 && d.textContent === "Laxante la víspera");
    await click(textEl.parentElement.querySelector("button"));
    ok("nota borrada desaparece", !txt().includes("Laxante la víspera") || !!$('[role="dialog"]'));
    await click($$('button[aria-label="Historial de este bloque de notas"]')[0]);
    m = $('[role="dialog"]'); const t = m.textContent;
    ok("historial (2): 'Eliminó nota' por Marcelo, escrita por Pamela", t.includes("Eliminó nota") && t.includes("Marcelo Reyes Fuentealba") && t.includes("Escrita por Pamela Iturra Vásquez"));
    ok("historial (2): orden más reciente primero", t.indexOf("Eliminó nota") < t.indexOf("Agregó nota"), t.indexOf("Eliminó nota") + "<" + t.indexOf("Agregó nota"));
    ok("historial (2): conserva el texto borrado", t.includes("Laxante la víspera"));
    await act(async () => { window.dispatchEvent(new window.KeyboardEvent("keydown", { key: "Escape", bubbles: true })); });
    ok("historial se cierra con Escape", !$('[role="dialog"]'));
    await click($$('button[aria-label="Historial de este bloque de notas"]')[1]);
    ok("bloque 2 sin movimientos (historial aislado por bloque)", $('[role="dialog"]').textContent.includes("Sin movimientos todavía"));
    await click($('[role="dialog"] button[title="Cerrar"]'));
    await selectVal(selU, [...selU.options].find((o) => o.textContent.includes("Pamela")).value);
  })();

  await esc(async function vistasYMes() {
    const dateIn = $('input[type="date"]');
    await selectVal; await typeIn(dateIn, "2026-12-15");
    await click(btn("Mes"));
    ok("irAVista: Mes abre en el mes de fechaSel (Diciembre)", txt().includes("Diciembre"), $('input[type="month"]') && $('input[type="month"]').value);
    const sp = $('input[type="month"]').parentElement.querySelector("span");
    ok("selector de Mes muestra solo el año", /^\d{4}$/.test(sp.textContent.trim()), sp.textContent);
    await click(btn("Semana")); ok("vista Semana renderiza", !!$('button[title="Semana anterior"]'));
    await click(btn("Agendamientos")); ok("vista Agendamientos renderiza", txt().includes("órdenes encontradas"));
  })();

  await esc(async function detalleYModificar() {
    await click(btn("Día"));
    await click(btn("HOY"));
    await click($('button[title="Día siguiente"]'));
    const celdas = $$('button[draggable="true"]');
    ok("hay órdenes arrastrables mañana", celdas.length > 0, String(celdas.length));
    await click(celdas[0]);
    ok("PanelDetalle abre", txt().includes("FHIR·ServiceRequest") && txt().includes("Orden médica"));
    await click(btn("Modificar Cita"));
    ok("modal Modificar Solicitud abre", txt().includes("Modificar Solicitud"));
    const medico = $('input[placeholder="Buscar médico solicitante por nombre..."]');
    await typeIn(medico, "Dr. Prueba Smoke");
    await click(btn("Guardar Cambios"));
    ok("Guardar Cambios (sin cambio de slot) → toast", txt().includes("Solicitud modificada"));
    ok("PanelDetalle abierto refleja el médico nuevo tras Modificar", txt().includes("Dr. Prueba Smoke"), "si FALLA: el panel queda con datos viejos");
  })();

  await esc(async function modificarConCambioDeSlot() {
    await click(btn("Modificar Cita"));
    const horaSel = selWith("Hora...");
    const actual = horaSel.value;
    let exito = false;
    for (const o of [...horaSel.options].filter((o) => o.value && o.value !== actual)) {
      await selectVal(horaSel, o.value);
      await click(btn("Guardar Cambios"));
      if (!txt().includes("Modificar Solicitud")) { exito = true; break; }
    }
    ok("Modificar con cambio de hora guarda (el modal se cierra)", exito);
    const punto = $('span[title="Este cupo tiene historial"]');
    ok("el cupo de ORIGEN quedó con punto de historial", !!punto);
    await click(punto.parentElement);
    ok("PanelCupoVacio abre con el movimiento etiquetado 'Modificar Cita' (no 'drag&drop')", txt().includes("Movido (Modificar Cita)") && !txt().includes("Movido (drag&drop)"));
  })();

  await esc(async function reagendarNoShow() {
    await click(btn("Agendamientos"));
    await selectVal(selWith("Todos los estados"), "no_show");
    const fila = $$("tbody tr").find((r) => r.textContent.includes("No Asistió"));
    ok("hay una orden No Asistió en la lista", !!fila);
    await click(fila);
    ok("detalle de la No Asistió abre", txt().includes("FHIR·ServiceRequest"));
    ok("No Asistió NO ofrece 'Cancelar'", !btn("Cancelar"));
    ok("No Asistió sí ofrece 'Reagendar Cita'", !!btn("Reagendar Cita"));
    await click(btn("Reagendar Cita"));
    ok("modal Reagendar abre", txt().includes("Reagendar Solicitud"));
    const horaSel = selWith("Hora...");
    let exito = false;
    for (const o of [...horaSel.options].filter((o) => o.value)) {
      await selectVal(horaSel, o.value);
      await click(btn("Confirmar Reagendamiento"));
      if (!txt().includes("Reagendar Solicitud")) { exito = true; break; }
    }
    ok("reagendar guarda (el modal se cierra)", exito);
    ok("tras Reagendar, el panel YA abierto muestra 'Antes: No Asistió' (sin reabrirlo)", txt().includes("Antes: No Asistió"));
    ok("tras Reagendar, el panel ya no ofrece Cancelar ni Modificar", !btn("Cancelar") && !btn("Modificar Cita"));
    await selectVal(selWith("Todos los estados"), "reagendada");
    const fila2 = $$("tbody tr").find((r) => r.textContent.includes("Reagendada"));
    ok("la orden quedó Reagendada", !!fila2);
    await click(fila2);
    ok("estadoAntesDeReagendar: panel muestra 'Antes: No Asistió'", txt().includes("Antes: No Asistió"));
  })();

  await esc(async function accesibilidadYMoverCita() {
    // Paneles que quedaron abiertos de las pruebas anteriores: Escape los cierra de a uno, el de arriba primero
    for (let i = 0; i < 8 && $('[role="dialog"]'); i++) await act(async () => { window.dispatchEvent(new window.KeyboardEvent("keydown", { key: "Escape", bubbles: true })); });
    ok("Escape cierra de a uno todos los paneles abiertos hasta dejar la pantalla limpia", !$('[role="dialog"]'));
    await click(btn("Día"));
    const celda = $$('button[draggable="true"]')[0];
    ok("hay una cita para probar accesibilidad", !!celda);
    await click(celda);
    ok("detalle abre como diálogo (role + aria-modal)", !!$('[role="dialog"][aria-modal="true"]'));
    ok("ofrece 'Mover cita' (alternativa a arrastrar)", !!btn("Mover cita"));
    await click(btn("Mover cita"));
    ok("Mover cita abre su diálogo", !!$('[aria-label="Mover cita"]'));
    await act(async () => { window.dispatchEvent(new window.KeyboardEvent("keydown", { key: "Escape", bubbles: true })); });
    ok("Escape cierra SOLO el diálogo de arriba (Mover cita), el detalle sigue", !$('[aria-label="Mover cita"]') && txt().includes("Notas de la Cita"));
    await act(async () => { window.dispatchEvent(new window.KeyboardEvent("keydown", { key: "Escape", bubbles: true })); });
    ok("segundo Escape cierra el detalle", !txt().includes("Notas de la Cita"));
  })();

  await esc(async function revertirNoShow() {
    await click(btn("Agendamientos"));
    await selectVal(selWith("Todos los estados"), "no_show");
    const fila = $$("tbody tr").find((r) => r.textContent.includes("No Asistió"));
    ok("hay otra orden No Asistió", !!fila);
    await click(fila);
    ok("ofrece 'Revertir No-Show'", !!btn("Revertir No-Show"));
    await click(btn("Revertir No-Show"));
    ok("revertir devuelve la cita a un estado activo", txt().includes("Revirtió la inasistencia") && !btn("Revertir No-Show"));
    await act(async () => { window.dispatchEvent(new window.KeyboardEvent("keydown", { key: "Escape", bubbles: true })); });
  })();

  await esc(async function horaDeSobrecupo() {
    await click(btn("Día"));
    await click($('button[title^="Sobrecupo antes de las 08:00"]'));
    const lab = $$("div").find((d) => d.children.length === 0 && d.textContent.startsWith("07:40"));
    ok("aparece la fila de sobrecupo 07:40", !!lab);
    const etiquetas = $$("div").filter((d) => d.children.length === 0).map((d) => d.textContent.trim());
    ok("el cierre 20:00 no es un cupo regular: el último es 19:40", etiquetas.includes("19:40") && !etiquetas.includes("20:00"));
    await click(lab.nextElementSibling);
    ok("Nueva Solicitud abre desde el sobrecupo", txt().includes("Nueva Solicitud de Imagen"));
    const horaSel = $$("select").find((x) => x.value === "07:40");
    ok("el selector de hora muestra 07:40 (antes mostraba 'Hora...')", !!horaSel && [...horaSel.options].some((o) => o.value === "07:40"));
    await click(btn("Cancelar"));
  })();

  await esc(async function cieRespetaNorma() {
    await click(btn("Nueva Solicitud"));
    await click(btn("CIE-11"));
    await click($$("button").find((b) => b.textContent.includes("Otro (búsqueda en catálogo completo)")));
    const buscador = $('input[placeholder="Buscar por código o palabra clave..."]');
    await typeIn(buscador, "MD80");
    ok("CIE-11: la búsqueda encuentra un código CIE-11", txt().includes("Hallazgos anormales en imagen del sistema nervioso central"));
    await click(btn("CIE-10"));
    ok("CIE-10: la misma búsqueda ya no lo encuentra y avisa", !txt().includes("Hallazgos anormales en imagen del sistema nervioso central") && txt().includes("Sin resultados en el catálogo de muestra CIE-10"));
    await click(btn("Cancelar"));
  })();

  await esc(async function bloqueoDeAgenda() {
    await click(btn("Día"));
    await click(btn("Bloquear agenda"));
    ok("modal Bloquear agenda abre", txt().includes("Motivo (obligatorio)"));
    await click(btn("Guardar bloqueo"));
    ok("sin motivo no guarda (aviso)", txt().includes("Selecciona el motivo del bloqueo"));
    const selM = $$("select").find((x) => [...x.options].some((o) => o.textContent === "Selecciona un motivo..."));
    await selectVal(selM, "Otro");
    await click(btn("Guardar bloqueo"));
    ok("«Otro» exige descripción", txt().includes("Describe el motivo"));
    await selectVal(selM, "Mantención del equipo");
    const ta = $('textarea[placeholder^="Detalle (opcional)"]');
    const setT = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, "value").set;
    setT.call(ta, "Mantención del resonador");
    await act(async () => { ta.dispatchEvent(new window.Event("input", { bubbles: true })); });
    await click(btn("Guardar bloqueo"));
    ok("bloqueo se crea", txt().includes("Bloqueo creado"));
    const capas = $$('span[title^="Cupo bloqueado"]');
    ok("celdas vacías del día quedan bloqueadas (gris + candado)", capas.length > 0, String(capas.length));
    ok("la leyenda explica 'Bloqueado' y 'Por mover'", txt().includes("Por mover") && txt().includes("Bloqueado"));
    await click(btn("Mes"));
    ok("vista Mes marca el día bloqueado", txt().includes("Día bloqueado"));
    await click(btn("Día"));
    const capas2 = $$('span[title^="Cupo bloqueado"]');
    await click(capas2[0].parentElement);
    ok("clic en celda bloqueada abre el detalle del bloqueo (no Nueva Solicitud)", txt().includes("Citas por mover a mano") && !txt().includes("Nueva Solicitud de Imagen"));
    await click(btn("Quitar bloqueo"));
    ok("quitar pide confirmación (aún no libera)", txt().includes("¿Quitar este bloqueo?") && $$('span[title^="Cupo bloqueado"]').length > 0);
    await click(btn("Cancelar"));
    ok("cancelar la confirmación mantiene el bloqueo", $$('span[title^="Cupo bloqueado"]').length > 0);
    await click(btn("Quitar bloqueo"));
    await click(btn("Todo el horario"));
    await click(btn("Sí, quitar"));
    ok("quitar bloqueo libera las celdas", txt().includes("Bloqueo quitado") && $$('span[title^="Cupo bloqueado"]').length === 0);
    const punto2 = $('span[title="Este cupo tiene historial"]');
    ok("tras quitar, la celda queda con punto de historial", !!punto2);
    await click(punto2.parentElement);
    const tt = txt();
    ok("Historial del Cupo: 'Bloqueo quitado' + motivo", tt.includes("Bloqueo quitado") && tt.includes("Mantención del equipo — Mantención del resonador"));
    ok("Historial del Cupo: quién bloqueó (nombre + rol) y quién desbloqueó", tt.includes("Bloqueó: Pamela Iturra Vásquez · Personal Administrativo") && tt.includes("Desbloqueó: Pamela Iturra Vásquez · Personal Administrativo"));
  })();

  await esc(async function desbloqueoParcial() {
    await click(btn("Día"));
    await click(btn("Bloquear agenda"));
    const selM = $$("select").find((x) => [...x.options].some((o) => o.textContent === "Selecciona un motivo..."));
    await selectVal(selM, "Falla del equipo");
    await click(btn("Guardar bloqueo"));
    const contar = () => $$('span[title^="Cupo bloqueado"]').length + $$('button[style*="dashed"]').length;
    const antes = contar();
    ok("segundo bloqueo creado (día completo)", antes > 0, String(antes));
    await click($$('span[title^="Cupo bloqueado"]')[0].parentElement);
    await click(btn("Quitar bloqueo"));
    ok("por defecto ofrece 'Cupo seleccionado' y libera solo ese cupo", !!btn("Cupo seleccionado") && txt().includes("Se liberará solo ese cupo"));
    await click(btn("Sí, quitar"));
    const despues = contar();
    ok("desbloqueo parcial: se libera 1 cupo y el resto sigue bloqueado", despues === antes - 1 && despues > 0, antes + " -> " + despues);
    const libre = $$('span[title="Este cupo tiene historial"]');
    ok("el cupo liberado queda con historial", libre.length > 0);
    await click(libre[0].parentElement);
    ok("Historial del Cupo: 'Bloqueo quitado' con quién desbloqueó", txt().includes("Bloqueo quitado") && txt().includes("Desbloqueó: Pamela Iturra Vásquez"));
    await click(btn("Auditoría (3)") || $$("button").find((b) => b.textContent.startsWith("Auditoría (")));
    ok("pestaña Auditoría del cupo: muestra el bloqueo y el desbloqueo parcial", txt().includes("Bloqueó agenda") && txt().includes("Quitó bloqueo parcial"));
  })();

  await esc(async function trazabilidad() {
    await click(btn("Trazabilidad"));
    const t = txt();
    for (const a of ["Agregó nota", "Eliminó nota", "Vio detalle de orden", "Modificó solicitud", "Reagendó solicitud", "Bloqueó agenda", "Quitó bloqueo", "Quitó bloqueo parcial", "Revirtió no-show"]) ok("Trazabilidad registra: " + a, t.includes(a));
  })();

  await act(async () => { root.unmount(); });
  console.log(out.join("\n"));
  const fallas = out.filter((l) => l.startsWith("FAIL")).length;
  console.log("\n" + (out.length - fallas) + " PASS / " + fallas + " FAIL");
  console.log("console.error capturados: " + errores.length); errores.slice(0, 8).forEach((e) => console.log("  - " + e));
  process.exit(fallas ? 1 : 0); // falla de verdad si hay algún FAIL (antes salía siempre con 0)
})();
