/**
 * ═══════════════════════════════════════════════════════════════
 * ATENCIÓN CLÍNICA Y DIAGNÓSTICA → AGENDA DE IMAGENOLOGÍA
 * ═══════════════════════════════════════════════════════════════
 * FHIR ServiceRequest · Capa 2 · v2 — CORRECCIÓN COMPLETA
 *
 * CORRECCIONES DE ESTA SESIÓN (sobre la v1 "ImagenologiaRISPACS.jsx"):
 * 1. Accession Number corregido: es un correlativo simple del RIS
 *    (DICOM 0008,0050, VR=SH, sin formato universal), NO el mismo
 *    molde con región/checksum que usa CUP/CUT. Se sacó el hash.
 * 2. "OT" descartado como identificador: en DICOM, OT es un VALOR del
 *    campo Modality (0008,0060) = "Other" (equipo/imagen que no
 *    encaja en ninguna categoría, o fusión de varias) — no es un
 *    correlativo de nada. CUP + ACC + Study Instance UID ya alcanzan
 *    para identificar persona, orden y estudio.
 * 3. ALCANCE RECORTADO A SOLO AGENDA. Esto es la agenda/programación
 *    de exámenes de imagen — el mismo rol que Gestión Agenda cumple
 *    para consulta médica. La operación real (worklist del
 *    tecnólogo, adquisición, C-STORE, informe) la construye el
 *    equipo de RIS-PACS en su propio módulo — no vive acá. Se
 *    sacaron los botones "Iniciar Adquisición / Marcar Adquirido /
 *    Marcar Informado" de la v1. Queda un botón fantasma "Enviar a
 *    módulo operativo RIS-PACS ↗" deshabilitado, puerta etiquetada
 *    para cuando exista esa conexión real.
 * 4. Catálogo de prestaciones: estructura MODALIDAD-AGNÓSTICA con
 *    codigoFonasa / codigoInterno / codigosFacturacion (rollup para
 *    prestaciones combinadas, ej. "RM DE COLUMNA CERVICODORSAL" =
 *    0405005+0405006) / contraste / lateralidad. Sembrado con el
 *    listado REAL de Resonancia Magnética (107 prestaciones, CSV del
 *    usuario). CT/CR/US/MG quedan con catálogo placeholder mínimo,
 *    pendientes de listas reales equivalentes. El nombre/valor
 *    comercial de cada prestación sigue viviendo en el submódulo de
 *    Valores (Marketing/Contabilidad) — acá solo se referencia el
 *    código, para no duplicar la fuente de verdad financiera.
 * 5. Nomenclatura de lateralidad: portado 1:1 el diccionario
 *    anatómico + reglas gramaticales chilenas (género/plural) que ya
 *    tenía el usuario, generalizado más allá de RM. El nombre final
 *    alimenta tanto la vista como el consentimiento informado.
 * 6. Consentimiento: matriz — RM SIEMPRE requiere consentimiento
 *    (cambia la plantilla si es con o sin contraste); TAC solo si
 *    lleva contraste. Para CR/US/MG, sin matriz confirmada todavía:
 *    se usa el flag `contraste` del catálogo como aproximación —
 *    pendiente de que el usuario confirme esas reglas también.
 *    Firma FESpa/FESpro sigue como puerta etiquetada.
 * 7. CIE-10/CIE-11 contextual: portado el clasificador del usuario
 *    (MAPEO_CIE por subespecialidad + toggle de norma + "🔎 Otro"
 *    abre búsqueda completa), mejorado para usar el campo real
 *    `especialidad` del catálogo en vez de adivinar por palabras
 *    clave. Clave compuesta `modalidad::especialidad` porque otras
 *    modalidades (ej. Ecografía) no comparten la misma taxonomía de
 *    subespecialidades que Resonancia — solo MR tiene mapeo
 *    específico hoy, el resto cae en el bucket GENERAL. Ahora
 *    admite selección múltiple (antes era single-select).
 * 8. Orden médica: sección nueva — adjuntar documento + campos
 *    manuales al lado (médico solicitante, fecha emisión,
 *    diagnóstico de sospecha). Sin OCR real: es un componente
 *    frontend sin backend, la lectura automática del PDF queda
 *    como puerta etiquetada (el usuario ya usó una API de OCR para
 *    cédula de identidad chilena antes — hay camino, no se eligió
 *    proveedor). La identidad del paciente se resuelve por RUT/CUP,
 *    no por el PDF.
 * 9. Creatinina: alerta no bloqueante si edad ≥ 60 y la prestación
 *    lleva contraste — adjuntar informe o marcar "se realiza exprés
 *    el día del examen". No se agrega un campo de digitación en
 *    worklist de tecnólogo acá — eso ya lo tiene el equipo de
 *    RIS-PACS como puerta etiquetada en su propio módulo operativo.
 * 10. Adjuntos del portal paciente: informes PDF o links externos de
 *     exámenes previos, generalizado (no exclusivo de creatinina).
 * 11. Marca de agua: opacidad/tamaño subidos a 0.07/21, dejados en
 *     una constante nombrada y documentada para reutilizar en
 *     cualquier módulo nuevo sin tener que volver a preguntar.
 * ═══════════════════════════════════════════════════════════════
 * CORRECCIONES DE LA SESIÓN DE SINCRONIZACIÓN CON MAIN (sobre lo de arriba):
 * 12. Marca de agua: pasa a ser el estándar propuesto para los 3 satélites
 *     (hoy cada uno tenía su propia copia con valores distintos — ver
 *     Sincronizacion_Satelites_MAIN.md punto 1.4). tileH bajado de 105 a
 *     60 (pedido explícito: filas más juntas verticalmente). PENDIENTE:
 *     tileW=250 vs. el largo real del texto del watermark (~700px+ con
 *     CUT+fecha+deviceId) — un <pattern> SVG clippea su contenido al
 *     tile por default, así que el texto probablemente sale cortado en
 *     fragmentos repetidos en vez de mostrarse completo. No verificado
 *     en navegador real todavía — antes de propagar esta técnica a
 *     Agenda/Presencial/Telemedicina, confirmar y corregir tileW.
 * 13. Historial del Cupo (ver AXON Agenda Web · Guía UX-UI, sección 16 —
 *     "cupos vacíos con historia"): agregada historialDeCupo(), que
 *     deriva la ocupación histórica de un cupo (equipo+fecha+hora) desde
 *     `ordenes` mismo — las canceladas/reagendadas ya quedaban ahí, solo
 *     que invisibles en la grilla y en ningún otro lado consultables. No
 *     es un log nuevo aparte.
 *     - Cupo OCUPADO: nueva sección "Historial de este Cupo" dentro de
 *       PanelDetalle (se muestra solo si hay algo que mostrar).
 *     - Cupo VACÍO con historia: nuevo panel PanelCupoVacio al hacer
 *       clic (estado + historial + botón directo a Nueva Solicitud).
 *     - Cupo VACÍO sin historia: sin cambios — sigue yendo directo a
 *       Nueva Solicitud, mismo comportamiento de siempre, sin click de más.
 *     De paso, corregido un hueco real: reagendar acá no dejaba el link
 *     `reagendadaHaciaId` hacia adelante que sí tiene
 *     AtencionMedicaAgenda.jsx — sin eso, el historial no podía mostrar
 *     "reagendado hacia X". Agregados `reagendadaHaciaId`/
 *     `reagendadaDesdeId` (null por defecto) a las órdenes semilla y a
 *     las creadas manualmente.
 *     LÍMITE HONESTO / PUERTA ETIQUETADA: esto es Occupancy History
 *     derivada de `ordenes` en memoria de sesión — no un Slot como
 *     Aggregate Root con su propio state machine (Available/Reserved/
 *     Occupied/Blocked/Freed) corriendo en paralelo al `estado` de la
 *     orden. Esa es una decisión de modelo más grande, sin tomar
 *     todavía (ver AXON Scheduling Lifecycle & Traceability.docx y
 *     Arquitectura de Trazabilidad de Scheduling.docx, sección 19 de
 *     ambos — piden definir Aggregate Roots, invariantes y transiciones
 *     válidas antes de construirlo).
 * 14. Historial del Cupo — ronda 2, sobre lo del punto 13:
 *     - Cruzado con `auditoria` (eventoDeAuditoria()): cada entrada del
 *       Historial ahora muestra quién y cuándo, cuando el dato existe. La
 *       guía UX-UI lo pide explícito (sección 8: cada evento con su hora;
 *       sección 9: "Actor" como campo mínimo). Sigue el link
 *       `reagendadaHaciaId` porque la auditoría de "Reagendó solicitud"
 *       queda etiquetada con el id de la orden NUEVA, no la vieja.
 *     - Dato semilla (`genOrdenes()`) nunca pasó por `registrarAuditoria`,
 *       así que no va a tener actor/hora — se muestra "Información
 *       histórica parcial" en vez de inventar algo. Mismo patrón que la
 *       guía UX-UI sección 21 ("Historial parcial o datos legados").
 *     - Motivo: OBLIGATORIO al cancelar (ModalMotivoCancelacion, gate
 *       antes de confirmar) — NADA al reagendar, ni el botón formal ni
 *       drag&drop (decisión explícita: cancelar es un clic deliberado sin
 *       velocidad que proteger; reagendar por drag&drop es justo el
 *       atajo rápido, pedir motivo ahí le quita la razón de existir).
 *       Este gate es solo para cancelación iniciada por STAFF desde este
 *       panel — si se conecta un flujo de cancelación del PACIENTE
 *       (Portal Paciente), ese flujo no debe heredar este requisito.
 *     - `movimientosCupo` (nuevo): drag&drop muta fecha/hora/equipoId de
 *       la MISMA orden a propósito (ver moverOrdenPorDrag) — sin este
 *       registro chico aparte, el cupo de ORIGEN quedaba sin ninguna
 *       orden que lo referenciara y su historial desaparecía sin dejar
 *       rastro al arrastrar. historialDeCupo() ahora combina `ordenes` +
 *       `movimientosCupo`, normalizado para TimelineCupo.
 * 15. Feedback sobre capturas reales de esta sesión:
 *     - Bug real: el Historial mostraba "reagendado a SR-2026-M..." (el id
 *       crudo) para el reagendamiento formal, mientras el de drag&drop sí
 *       mostraba equipo+fecha+hora legible. Corregido — historialDeCupo()
 *       ahora resuelve `destino` (la orden nueva) y TimelineCupo usa el
 *       mismo formato para ambos casos.
 *     - Grilla de Día enriquecida (pedido: faltaban datos vs. una vista de
 *       referencia real que sí mostraba prestación/edad/fono): las celdas
 *       ocupadas ahora muestran nombre + prestación + estado·edad·fono.
 *       Requirió agregar `telefono1` a `genOrdenes()` — antes el paciente
 *       semilla no tenía NINGÚN campo de contacto (solo los registrados a
 *       mano en el modal). `fakeTelefono()` nuevo, mismo criterio
 *       determinístico que fakeRUT(). No tocado en Semana (columnas más
 *       angostas) — a evaluar aparte si se quiere ahí también.
 *     - 2 ajustes estéticos: título del mes centrado dentro de su
 *       recuadro; paneles laterales (nav + notas) con fondo gris claro
 *       (`C.panelGris`, nuevo) en vez de blanco, para que se distingan
 *       más del contenido central — no tocado el header de KPIs.
 * 16. Más feedback sobre capturas reales:
 *     - Faltaba el calendario mensual persistente en el sidebar — antes
 *       solo había flechas ± día/semana/mes + un <input type="date">
 *       nativo, sin vista de conjunto. `MiniCalendario` nuevo, reusa
 *       generarMatrizMes() (la misma matriz que ya usaba la vista "Mes"
 *       grande). Seleccionar un día actualiza `fechaSel`; si el punto de
 *       partida era vista "Mes", salta a "Día" (mismo criterio que ya
 *       usa el calendario grande).
 *     - La grilla de Día apilaba nombre/prestación/datos en 3 líneas
 *       siempre, aunque con un solo equipo visible la columna se estira
 *       (minmax(130px,1fr)) y queda mucho ancho sin usar — exactamente
 *       lo que se ve como espacio en blanco en ese caso. `CeldaOrdenDia`
 *       (nuevo, reemplaza el botón que se repetía inline en las 3
 *       ubicaciones de Día) decide entre 2 layouts: apilado (varios
 *       equipos, columnas angostas) o en fila — Hora ya está aparte en
 *       la columna común; Nombre/Edad/Prestación/Teléfono/Estado en una
 *       sola línea — igual que la tabla de referencia que compartió el
 *       usuario, cuando `equiposVisibles.length === 1`.
 * 17. Sobre la fila ancha del punto 16: las columnas no alineaban entre
 *     filas — usaba minWidth/maxWidth en vez de un ancho fijo, así que el
 *     punto de corte real dependía del largo del nombre de cada fila.
 *     Corregido a `width` fijo por columna (Prestación sigue en flex:1,
 *     es la única que debe absorber el espacio sobrante).
 *     `LeyendaEstados` (nuevo): color + nombre de cada ESTADOS, arriba
 *     del panel de notas (no abajo — es de consulta frecuente, y notas
 *     puede crecer largo). BloqueNotas dejó de cargar la clase sticky
 *     `axon-img-notas` en su propia raíz; ahora la lleva un wrapper
 *     nuevo en el render principal que envuelve leyenda+notas juntas
 *     como una sola columna del grid de 3 columnas.
 * 18. Atribución de quién agendó (`agendadoPorCUT`/`agendadoPorNombre`):
 *     antes no existía en ningún lado — ni en la orden ni en `auditoria`
 *     (que nunca corre para datos semilla) — así que "qué administrativa
 *     agenda más" no se podía responder ni para el mock. Semilla: asignado
 *     determinísticamente a uno de los 2 USUARIOS_DEMO (mismo criterio que
 *     fakeRUT()/fakeTelefono()). Creación en vivo: `usuarioActual` real, no
 *     un sorteo. Reagendar (formal) atribuye la orden nueva a quien hizo el
 *     reagendamiento, no a quien agendó la original — decisión simple,
 *     discutible, documentada acá por si se quiere el criterio inverso.
 *     Modificar (editId) preserva el campo original vía spread, no lo
 *     toca. Visible en PanelDetalle ("Agendado por"). A propósito NO se
 *     construyó un dashboard de producción acá — los KPICards de este
 *     módulo son la única superficie de indicadores a propósito (ver nota
 *     en el componente principal); esto solo deja el dato capturado para
 *     cuando exista el destino real (Gestión/Alta Calidad + dashboard).
 * 19. Sobre el punto 18: agregado `agendadoOriginalmentePorCUT`/Nombre,
 *     propagado a través de toda la cadena de reagendamientos (sin
 *     importar el largo de la cadena) — antes solo existía
 *     `agendadoPorNombre`, que en una orden reagendada se pisaba con
 *     quien reagendó, perdiendo quién iba a agendar originalmente al
 *     paciente. Elegido en vez de inferirlo desde el Historial del Cupo
 *     (seguir `reagendadaDesdeId` a mano, salto por salto) porque para
 *     un KPI de producción hay que poder calcularlo directo, no
 *     reconstruir una cadena por cada orden. PanelDetalle ahora muestra
 *     "Agendado originalmente por" siempre, y "Reagendado por" solo si
 *     `reagendadaDesdeId` existe (evita repetir el mismo nombre 2 veces
 *     en una orden que nunca se reagendó).
 *     Leyenda de estados: pasó de flex-wrap (cada fila envolvía según el
 *     largo de su propio label, columnas desalineadas) a grid de 2
 *     columnas fijas — mismo tipo de bug que ya se había corregido en
 *     las celdas de Día.
 * 20. QA real detectó un hueco en el punto 19: `agendadoPorNombre` solo se
 *     actualizaba en el reagendamiento formal — drag&drop mutaba la orden
 *     (fecha/hora/equipo) pero nunca tocaba ese campo, así que
 *     "Reagendado por" no aparecía aunque el movimiento sí hubiera
 *     pasado. Corregido en moverOrdenPorDrag(). De paso, la condición de
 *     PanelDetalle para mostrar "Reagendado por" dejó de mirar
 *     `reagendadaDesdeId` (específico del flujo formal) y ahora compara
 *     `agendadoPorCUT !== agendadoOriginalmentePorCUT` — cubre los 2
 *     caminos con una sola condición.
 *     Vista Semana enriquecida (antes solo nombre+estado): agregada
 *     `CeldaOrdenSemana`, nueva, mismo criterio que CeldaOrdenDia pero
 *     sin el layout "ancha" (Semana son siempre 7 columnas de día fijas,
 *     nunca se libera tanto ancho como con Día + un solo equipo) — 3
 *     líneas: nombre / prestación / estado·edad. Sin teléfono acá, no
 *     entra cómodo en el ancho de una columna de día.
 * 21. Feedback de UI sobre el sidebar:
 *     - Sacada la línea de resumen ("lun 07 sept al dom 13 sept —
 *       Resonador 1" en Semana; el nombre del equipo solo en Mes) que
 *       aparecía arriba de la grilla en Mes y Semana — redundante contra
 *       el sidebar izquierdo (mes, fecha, mini calendario, selector de
 *       Equipo) y contra los propios encabezados de día de la grilla, que
 *       ya muestran las fechas exactas.
 *     - El <input type="date"/month"> de Mes/Semana/Día se recortaba —
 *       sin espacio para mostrar la fecha completa porque los 2 botones
 *       de flecha (Btn genérico, con padding pensado para texto+ícono)
 *       ocupaban más de lo necesario en una columna de 168px. Agregado
 *       `FlechaFecha` (ícono solo, padding mínimo) para esos 6 botones
 *       (3 filas × 2), más la columna del sidebar ensanchada a 188px —
 *       ya venía cargando más contenido (mini calendario, leyenda ya no
 *       vive acá pero el resto sí) del que tenía cuando se fijó en 168px.
 * ═══════════════════════════════════════════════════════════════
 */

import { useState, useMemo, useEffect, useRef, useCallback, Fragment } from "react";
import {
  ScanLine, X, Search, ChevronLeft, ChevronRight,
  CheckCircle2, Info, ArrowRight, Clock, Lock, ShieldCheck,
  Activity, FileText, AlertTriangle, ClipboardList, Paperclip,
  Calendar, LayoutDashboard, Filter, Link2, Plus, Camera, RefreshCw, History, Settings, Ban,
} from "lucide-react";

/* ═══════════════════════════ ACCESIBILIDAD DE DIÁLOGOS ═══════════════════════════
   Todos los paneles y modales usan este hook: Escape cierra SOLO el que está arriba (pila),
   el foco entra al diálogo al abrirse y vuelve al elemento anterior al cerrarse, y el
   contenedor se anuncia como diálogo modal (role/aria-modal). Pendiente: atrapar Tab. */
const PILA_ESCAPE = [];
let escapeInstalado = false;
function useDialogo(onCerrar) {
  const ref = useRef(null);
  const cerrarRef = useRef(onCerrar);
  cerrarRef.current = onCerrar;
  useEffect(() => {
    const previo = document.activeElement;
    const entrada = { cerrar: () => cerrarRef.current && cerrarRef.current() };
    PILA_ESCAPE.push(entrada);
    if (!escapeInstalado) {
      window.addEventListener("keydown", (e) => { if (e.key === "Escape" && PILA_ESCAPE.length) PILA_ESCAPE[PILA_ESCAPE.length - 1].cerrar(); });
      escapeInstalado = true;
    }
    if (ref.current && !ref.current.contains(document.activeElement)) ref.current.focus({ preventScroll:true });
    return () => {
      const i = PILA_ESCAPE.indexOf(entrada);
      if (i >= 0) PILA_ESCAPE.splice(i, 1);
      if (previo && previo.focus && document.contains(previo)) previo.focus({ preventScroll:true });
    };
  }, []);
  return { ref, role:"dialog", "aria-modal":"true", tabIndex:-1 };
}

/* ═══════════════════════════ DISEÑO ═══════════════════════════ */
const C = {
  sidebarBg:"#071526", sidebarHov:"#0F2540", sidebarAct:"#1A3E6E",
  bg:"#EAF0FB",        sfc:"#FFFFFF",        brd:"#E2EAF4",
  txt:"#1B2A3B",       txm:"#455A64",        txl:"#78909C",
  pri:"#0D47A1",       tea:"#00A693",        dan:"#C62828",
  war:"#E65100",       suc:"#2E7D32",        pur:"#6A1B9A",
  amb:"#FF8F00",
  gridLine:"#C7D2E3",  gridAlt:"#F6F8FB",
  finde:"#DCE5F4", // cabecera de sábado/domingo en Semana y Mes: apenas más oscura que C.bg (mismo criterio que el cuerpo: fin de semana más oscuro)
  panelGris:"#F1F3F6", // fondo de los paneles laterales (nav / notas) — pedido explícito del usuario para resaltarlos, distinto de gridAlt (casi blanco, ya usado para franjas de tabla)
};

// Config de marca de agua — acordada esta sesión (0.07/21), pensada para
// copiar tal cual a cualquier módulo nuevo. Pendiente: subir Agenda y
// Presencial de Atención Médica al mismo valor (hoy están en 0.06/20).
const WATERMARK_CONFIG = { opacity: 0.07, fontSize: 21 };

const Badge = ({ c=C.pri, sm, children }) => (
  <span style={{ display:"inline-flex", alignItems:"center", padding:sm?"1px 6px":"2px 8px", fontSize:sm?10:11, fontWeight:600, letterSpacing:"0.3px", borderRadius:4, background:`${c}18`, color:c, border:`1px solid ${c}28` }}>{children}</span>
);
const CUPPill = ({ cup }) => (
  <span style={{ fontSize:10, fontWeight:700, background:"#1B2A3B", color:"#00A693", padding:"2px 6px", borderRadius:4, letterSpacing:"0.3px", fontFamily:"monospace" }}>{cup}</span>
);
const ACCPill = ({ acc }) => acc ? (
  <span style={{ fontSize:10, fontWeight:700, background:"#1B2A3B", color:"#5B9BF5", padding:"2px 6px", borderRadius:4, letterSpacing:"0.3px", fontFamily:"monospace" }}>{soloNumero(acc)}</span>
) : (
  <span style={{ fontSize:10, fontWeight:600, background:"#E2EAF4", color:"#78909C", padding:"2px 6px", borderRadius:4, letterSpacing:"0.3px" }}>ACC pendiente</span>
);
const Btn = ({ children, icon:I, v="primary", sz="md", col, onClick, dis, title }) => {
  const p = { sm:"5px 10px", md:"7px 14px", lg:"10px 20px" }[sz];
  const f = { sm:11, md:12, lg:13 }[sz];
  const i = { sm:12, md:13, lg:14 }[sz];
  const bg = v==="primary"?(col||C.pri):v==="success"?C.suc:v==="danger"?C.dan:v==="teal"?C.tea:"transparent";
  const fg = v==="ghost"?C.txm:"#fff";
  const bd = v==="ghost"?`1px solid ${C.brd}`:v==="outline"?`1px solid ${col||C.pri}`:"none";
  const fgo = v==="outline"?(col||C.pri):fg;
  return (
    <button title={title} onClick={onClick} disabled={dis} style={{ padding:p, fontSize:f, fontWeight:600, gap:5, background:dis?"#CFD8DC":(v==="ghost"||v==="outline"?(v==="outline"?`${col||C.pri}10`:"#fff"):bg), color:dis?"#90A4AE":fgo, border:dis?`1px solid ${C.brd}`:bd, borderRadius:7, cursor:dis?"not-allowed":"pointer", display:"inline-flex", alignItems:"center", transition:"all 0.15s" }}>
      {I&&<I size={i}/>}{children}
    </button>
  );
};
const SH = ({ title, sub, icon:I, col, children }) => (
  <div style={{ marginBottom:18, paddingBottom:14, borderBottom:`1px solid ${C.brd}` }}>
    <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", flexWrap:"wrap", gap:10 }}>
      <div style={{ display:"flex", alignItems:"center", gap:12 }}>
        {I&&<div style={{ background:`${col}18`, borderRadius:10, padding:10 }}><I size={22} color={col}/></div>}
        <div>
          <h2 style={{ margin:0, fontSize:17, fontWeight:700, color:C.txt }}>{title}</h2>
          {sub&&<p style={{ margin:"2px 0 0", fontSize:11, color:C.txl }}>{sub}</p>}
        </div>
      </div>
      {children&&<div style={{ display:"flex", gap:8, flexWrap:"wrap", alignItems:"center" }}>{children}</div>}
    </div>
  </div>
);
const TBar = ({ tabs, act, on }) => (
  <div style={{ display:"flex", borderBottom:`1px solid ${C.brd}`, marginBottom:18, overflowX:"auto", minWidth:0 }}>
    {tabs.map(t=>(
      <button key={t.id} onClick={()=>on(t.id)} style={{ padding:"8px 13px", fontSize:11, fontWeight:act===t.id?600:400, color:act===t.id?C.pri:C.txl, borderBottom:`2px solid ${act===t.id?C.pri:"transparent"}`, background:"none", border:"none", borderBottomWidth:2, borderBottomStyle:"solid", cursor:"pointer", display:"flex", alignItems:"center", gap:5, whiteSpace:"nowrap" }}>
        {t.icon&&<t.icon size={12}/>}{t.label}
      </button>
    ))}
  </div>
);
const KPICard = ({ label, value, sub, icon:I, col, compact }) => (
  <div style={{ background:C.panelGris, borderRadius:compact?10:12, border:`1px solid ${C.brd}`, boxShadow:"0 1px 4px rgba(0,0,0,0.05)", padding:compact?"9px 12px":"15px 17px", position:"relative", overflow:"hidden" }}>
    <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:compact?2:5 }}>
      <div>
        <div style={{ fontSize:compact?10:11, color:C.txl, fontWeight:500, textTransform:"uppercase", letterSpacing:"0.5px" }}>{label}</div>
        <div style={{ fontSize:compact?17:24, fontWeight:700, color:C.txt, lineHeight:1.1, marginTop:2 }}>{value}</div>
      </div>
      <div style={{ background:`${col}18`, borderRadius:compact?7:9, padding:compact?6:9 }}><I size={compact?14:19} color={col}/></div>
    </div>
    {sub&&<div style={{ fontSize:compact?10:11, color:C.txl }}>{sub}</div>}
    <div style={{ position:"absolute", top:0, left:0, width:3, height:"100%", background:col, borderRadius:compact?"10px 0 0 10px":"12px 0 0 12px" }}/>
  </div>
);
const Chip = ({ active, onClick, children }) => (
  <button onClick={onClick} style={{ padding:"5px 12px", borderRadius:7, fontSize:11, fontWeight:600, cursor:"pointer", border:`1px solid ${active?C.pri:C.brd}`, background:active?`${C.pri}12`:"#fff", color:active?C.pri:C.txm, whiteSpace:"nowrap" }}>
    {children}
  </button>
);

/* ═══════════════════════════ SEGURIDAD — portado 1:1 de Agenda/Presencial ═══════════════════════════ */
function mockDeviceId() {
  let h = 0;
  const s = "preview-session-device";
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0;
  return `DEV-${h.toString(16).toUpperCase().padStart(8, "0").slice(0, 8)}`;
}
const DEVICE_ID_DEMO = mockDeviceId();

function useRelojEnVivo() {
  const [ahora, setAhora] = useState(() => new Date());
  useEffect(() => {
    const id = setInterval(() => setAhora(new Date()), 1000);
    return () => clearInterval(id);
  }, []);
  return ahora;
}

// Antes: N repeticiones calculadas a mano como % del contenedor — se veía
// disperso en páginas altas (huecos sin cubrir) o amontonado en páginas
// cortas (el "desordenado" que se veía en la vista previa). Un <pattern>
// SVG nativo resuelve esto de raíz: el tile tiene tamaño FIJO en píxeles,
// así que se repite solo, con el mismo ritmo visual, sin importar cuánto
// mida el contenido — nunca más hay que adivinar un número de repetición.
// Mide el ancho real que va a ocupar `text` con la MISMA fuente/peso/
// letterSpacing que el <text> real de abajo — Canvas 2D es API estándar
// del navegador (no una librería externa), funciona igual en el navegador
// real y en la vista previa de artefactos.
let _canvasMedicionWatermark = null;
function anchoDeTextoWatermark(text, fontSize, letterSpacingPx = 1) {
  if (!_canvasMedicionWatermark) _canvasMedicionWatermark = document.createElement("canvas");
  const ctx = _canvasMedicionWatermark.getContext("2d");
  ctx.font = `300 ${fontSize}px Arial, sans-serif`;
  // letterSpacing no tiene soporte parejo en Canvas 2D todavía — se suma a
  // mano el mismo valor que el letterSpacing="1" del <text> SVG real.
  return ctx.measureText(text).width + text.length * letterSpacingPx;
}

// Antes: tileW fijo en 250px — clippeaba el texto real (~65% del
// identificador completo se perdía, confirmado con captura real: se veían
// fragmentos tipo "12901-S3"/"01:30-A1" en vez de CUT+fecha+deviceId
// completos). Un <pattern> SVG clippea su contenido al tile por default
// (overflow:hidden, valor inicial de la spec SVG). Ahora tileW se mide en
// vivo — mismo <pattern>, mismo ángulo, mismo tileH (misma estructura y
// espaciado vertical de siempre), solo el ancho se ajusta al identificador
// completo, así nunca más depende de adivinar un número fijo.
function WatermarkSVG({ text, opacity, angle, fontSize, color }) {
  const tileW = useMemo(() => Math.max(280, Math.ceil(anchoDeTextoWatermark(text, fontSize)) + 60), [text, fontSize]);
  const tileH = 60;
  // Id fijo colisionaba si este componente se montaba más de una vez en el
  // mismo DOM (ej. 2 paneles con watermark a la vez) — ambos referenciarían
  // el mismo <pattern>, con resultados ambiguos. Uno por instancia.
  const patternId = useRef(`axon-watermark-tile-${Math.random().toString(36).slice(2)}`).current;
  return (
    <svg xmlns="http://www.w3.org/2000/svg" style={{ position:"absolute", top:0, left:0, width:"100%", height:"100%", pointerEvents:"none", userSelect:"none", zIndex:9999, opacity, mixBlendMode:"multiply" }} aria-hidden="true">
      <defs>
        <pattern id={patternId} width={tileW} height={tileH} patternUnits="userSpaceOnUse" patternTransform={`rotate(${angle})`}>
          <text x={tileW / 2} y={tileH / 2} textAnchor="middle" dominantBaseline="middle" fontSize={fontSize} fontFamily="Arial, sans-serif" fontWeight="300" letterSpacing="1" fill={color}>{text}</text>
        </pattern>
      </defs>
      <rect width="100%" height="100%" fill={`url(#${patternId})`}/>
    </svg>
  );
}
function ForensicWatermark({ children, forceClean = false, user = {} }) {
  const showWatermark = !forceClean && !!user.cut;
  const watermarkText = useMemo(() => {
    if (!showWatermark) return "";
    const fecha = new Date().toLocaleString("es-CL", { day:"2-digit", month:"2-digit", year:"numeric", hour:"2-digit", minute:"2-digit" });
    return `${user.cut || "CUT-???"} | ${fecha} | ${user.deviceId || "DEV-???"}`;
  }, [showWatermark, user.cut, user.deviceId]);
  return (
    <div style={{ position:"relative", width:"100%", minHeight:"100vh" }}>
      {children}
      {showWatermark && <WatermarkSVG text={watermarkText} opacity={WATERMARK_CONFIG.opacity} angle={-30} fontSize={WATERMARK_CONFIG.fontSize} color="#000000"/>}
    </div>
  );
}

const CLICK_WINDOW_MS = 1200, CLICKS_REQUIRED = 3, HOLD_MS = 3000, CONFIRM_FLASH_MS = 180;
function PanicTrigger({ children, cut = null, deviceId = null, moduleId = null }) {
  const clickTimes = useRef([]);
  const holdTimer = useRef(null);
  const [flashing, setFlashing] = useState(false);
  const dispararAlerta = useCallback((metodo) => {
    console.warn("[PANIC] Alerta disparada (Capa 2 conectará esto al backend):", { variant:"staff", metodo, cut, deviceId, moduleId, timestamp:new Date().toISOString() });
    setFlashing(true);
    setTimeout(() => setFlashing(false), CONFIRM_FLASH_MS);
  }, [cut, deviceId, moduleId]);
  const handleClick = useCallback(() => {
    const now = Date.now();
    clickTimes.current = [...clickTimes.current, now].filter(t => now - t <= CLICK_WINDOW_MS);
    if (clickTimes.current.length >= CLICKS_REQUIRED) { clickTimes.current = []; dispararAlerta("triple_clic"); }
  }, [dispararAlerta]);
  const iniciarHold = useCallback(() => {
    holdTimer.current = setTimeout(() => { dispararAlerta("mantener_presionado"); holdTimer.current = null; }, HOLD_MS);
  }, [dispararAlerta]);
  const cancelarHold = useCallback(() => {
    if (holdTimer.current) { clearTimeout(holdTimer.current); holdTimer.current = null; }
  }, []);
  return (
    <div
      onClick={handleClick}
      onMouseDown={iniciarHold} onMouseUp={cancelarHold} onMouseLeave={cancelarHold}
      onTouchStart={iniciarHold} onTouchEnd={cancelarHold}
      style={{ display:"inline-block", cursor:"default", opacity:flashing ? 0.55 : 1, transition:`opacity ${CONFIRM_FLASH_MS}ms ease`, userSelect:"none" }}
    >
      {children}
    </div>
  );
}

/* ═══════════════════════════ MOTOR CUP / ACC / OT — corregido contra HIS-RIS-PACS.jsx real ═══════════════════════════
   Hallazgo clave al revisar el módulo operativo real: ACC y OT son AMBOS
   null mientras el registro está en fase "agendados" (líneas 309-310 de
   ese archivo) — recién se generan al completar Admisión (línea 1312).
   O sea: NO es trabajo de esta agenda generarlos. Formato adoptado tal
   cual del archivo real (líneas 144-145):
     const makeOT  = (n) => `OT-2026-${pad(n,6)}`
     const makeACC = (n) => `ACC-2026-${pad(n,8)}`
   OT SÍ es un identificador real de AXON (Orden de Trabajo interna,
   generado junto al ACC en Admisión) — la sesión anterior lo descarté
   por confundirlo con el valor DICOM Modality="Other"; con el archivo
   real a la vista, era el otro OT, no el de DICOM. Corregido. */
const PAIS = "CL", REGION = "13";
// TENANT: MasterIdentifierService usa 8 caracteres (antes 4, "AXON" a secas)
// — se rellena igual que construirId real: .padEnd(8,"X").slice(0,8).
const TENANT = "AXON".padEnd(8, "X").slice(0, 8);
// CHK2 — algoritmo real de MasterIdentifierService.js (reemplaza a cup.js):
// SHA-256 del string base, primer byte codificado como letra+dígito
// (A0-Z5, A=0..Z=25 → cubre los 256 valores de un byte). Antes este
// archivo usaba un hash propio (hashLiviano, rolling×31) que generaba un
// checksum DISTINTO al real — no habría validado contra validarCUP()/
// validarCUT() del servicio real. Verificado contra el ejemplo del propio
// documento: byte 0x89 (137) -> "N7".
function encode256(byteValue) {
  const letterIndex = Math.floor(byteValue / 10);
  const digit = byteValue % 10;
  return `${String.fromCharCode(65 + letterIndex)}${digit}`;
}
// SHA-256 puro en JS, sin dependencias — la vista previa de artefactos de
// Claude no admite crypto-js ("Error al cargar el artefacto... crypto-js",
// reportado por el usuario). Mismo algoritmo estándar (FIPS 180-4), mismo
// resultado exacto que CryptoJS.SHA256(x).toString() — verificado contra
// los vectores de prueba oficiales (SHA256("")/SHA256("abc")) y contra
// crypto-js para los strings reales de este motor antes de reemplazarlo.
function sha256Hex(message) {
  const K = [
    0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
    0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
    0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
    0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
    0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
    0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
    0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
    0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2,
  ];
  let H = [0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19];
  const bytes = new TextEncoder().encode(message);
  const withOne = new Uint8Array((((bytes.length + 9 + 63) >> 6) << 6));
  withOne.set(bytes);
  withOne[bytes.length] = 0x80;
  const dv = new DataView(withOne.buffer);
  dv.setUint32(withOne.length - 8, Math.floor((bytes.length * 8) / 0x100000000), false);
  dv.setUint32(withOne.length - 4, (bytes.length * 8) >>> 0, false);
  const rotr = (x, n) => (x >>> n) | (x << (32 - n));
  const w = new Uint32Array(64);
  for (let off = 0; off < withOne.length; off += 64) {
    for (let i = 0; i < 16; i++) w[i] = dv.getUint32(off + i * 4, false);
    for (let i = 16; i < 64; i++) {
      const s0 = rotr(w[i-15],7) ^ rotr(w[i-15],18) ^ (w[i-15] >>> 3);
      const s1 = rotr(w[i-2],17) ^ rotr(w[i-2],19) ^ (w[i-2] >>> 10);
      w[i] = (w[i-16] + s0 + w[i-7] + s1) >>> 0;
    }
    let [a,b,c,d,e,f,g,h] = H;
    for (let i = 0; i < 64; i++) {
      const S1 = rotr(e,6) ^ rotr(e,11) ^ rotr(e,25);
      const ch = (e & f) ^ (~e & g);
      const t1 = (h + S1 + ch + K[i] + w[i]) >>> 0;
      const S0 = rotr(a,2) ^ rotr(a,13) ^ rotr(a,22);
      const maj = (a & b) ^ (a & c) ^ (b & c);
      const t2 = (S0 + maj) >>> 0;
      h=g; g=f; f=e; e=(d+t1)>>>0; d=c; c=b; b=a; a=(t1+t2)>>>0;
    }
    const upd = [a,b,c,d,e,f,g,h];
    H = H.map((v,i) => (v + upd[i]) >>> 0);
  }
  return H.map(v => v.toString(16).padStart(8,"0")).join("");
}
function calcularCheck2(base) {
  const hashHex = sha256Hex(base);
  const primerByte = parseInt(hashHex.substring(0, 2), 16);
  return encode256(primerByte);
}
function construirId(segmentos) {
  const base = segmentos.join("-");
  return `${base}-${calcularCheck2(base)}`;
}
function makeCUP(seq, anio = 2026) {
  const s = String(seq).padStart(8, "0");
  return construirId(["CUP", PAIS, REGION, String(anio), s]);
}
function makeCUT(seq) {
  const s = String(seq).padStart(4, "0"); // antes 8 dígitos — MasterIdentifierService usa 4
  return construirId(["CUT", PAIS, REGION, TENANT, s]);
}
// Solo se usan cuando el registro avanza a Admisión — nunca en agenda.
// Reciben el correlativo n desde el módulo operativo real, no desde acá.
// Sin cambios — ACC/OT no están en el alcance de MasterIdentifierService.
function makeOT(n) { return `OT-2026-${String(n).padStart(6, "0")}`; }
function makeACC(n) { return `ACC-2026-${String(n).padStart(8, "0")}`; }
// Igual que soloNumero() del módulo operativo real (línea 362 de ese
// archivo) — evita repetir el prefijo cuando la etiqueta del campo ya
// dice "Accession Number" u "OT".
function soloNumero(valor) { return valor ? valor.replace(/^(OT|ACC)-/, "") : "—"; }

/* ═══════════════════════════ CATÁLOGOS ═══════════════════════════ */
const EQUIPOS = [
  { id:"eq-rx1",  nombre:"Sala RX 1",   modalidad:"CR", area:"Imagenología General", color:"#1A4DA8" },
  { id:"eq-rx2",  nombre:"Sala RX 2",   modalidad:"CR", area:"Imagenología General", color:"#1A4DA8" },
  { id:"eq-tac1", nombre:"TAC 1",       modalidad:"CT", area:"Tomografía Computada", color:"#00838F" },
  { id:"eq-rm1",  nombre:"Resonador 1", modalidad:"MR", area:"Resonancia Magnética", color:"#6A1B9A" },
  { id:"eq-eco1", nombre:"Ecógrafo 1",  modalidad:"US", area:"Ecografía",             color:"#2E7D32" },
  { id:"eq-mmg1", nombre:"Mamógrafo 1", modalidad:"MG", area:"Mamografía",            color:"#AD1457" },
];
const MODALIDAD_LABEL = { CR:"Radiografía (RX)", CT:"Tomografía (TAC)", MR:"Resonancia (RM)", US:"Ecografía", MG:"Mamografía" };

// Estructura modalidad-agnóstica. codigosFacturacion: array porque hay
// prestaciones combinadas (ej. "RM DE COLUMNA CERVICODORSAL" rola a dos
// códigos base). contraste/lateralidad: true/false/null (null = sin dato
// en la fuente, no asumido como "No" — a revisar con Contabilidad/Valores).
// Nombre y valor comercial NO viven acá — solo el código de referencia;
// la fuente de verdad de precio/nombre comercial sigue siendo el
// submódulo de Valores (Marketing/Contabilidad).
const CATALOGO_PRESTACIONES = [
  { modalidad:"MR", especialidad:"NEURORADIOLOGÍA", codigoFonasa:"405001", codigoInterno:null, codigosFacturacion:["405001"], nombre:"RM DE CEREBRO", contraste:false, lateralidad:false },
  { modalidad:"MR", especialidad:"NEURORADIOLOGÍA", codigoFonasa:"405001", codigoInterno:null, codigosFacturacion:["405001"], nombre:"RM DE HIPÓFISIS", contraste:true, lateralidad:false },
  { modalidad:"MR", especialidad:"NEURORADIOLOGÍA", codigoFonasa:"405001", codigoInterno:null, codigosFacturacion:["405001"], nombre:"RM DE OÍDOS", contraste:true, lateralidad:false },
  { modalidad:"MR", especialidad:"NEURORADIOLOGÍA", codigoFonasa:"405003", codigoInterno:null, codigosFacturacion:["405003"], nombre:"RM DE ÓRBITAS", contraste:true, lateralidad:false },
  { modalidad:"MR", especialidad:"NEURORADIOLOGÍA", codigoFonasa:"405005", codigoInterno:null, codigosFacturacion:["405005"], nombre:"RM DE COLUMNA CERVICAL", contraste:false, lateralidad:false },
  { modalidad:"MR", especialidad:"NEURORADIOLOGÍA", codigoFonasa:"405006", codigoInterno:null, codigosFacturacion:["405006"], nombre:"RM DE COLUMNA DORSAL", contraste:false, lateralidad:false },
  { modalidad:"MR", especialidad:"NEURORADIOLOGÍA", codigoFonasa:"405007", codigoInterno:null, codigosFacturacion:["405007"], nombre:"RM DE COLUMNA LUMBAR", contraste:false, lateralidad:false },
  { modalidad:"MR", especialidad:"NEURORADIOLOGÍA", codigoFonasa:"405011", codigoInterno:null, codigosFacturacion:["405011"], nombre:"RM DE COLUMNA SACROCOXÍGEA", contraste:false, lateralidad:false },
  { modalidad:"MR", especialidad:"NEURORADIOLOGÍA", codigoFonasa:"405011", codigoInterno:null, codigosFacturacion:["405011"], nombre:"RM DE COXIS", contraste:false, lateralidad:false },
  { modalidad:"MR", especialidad:"NEURORADIOLOGÍA", codigoFonasa:"405016", codigoInterno:null, codigosFacturacion:["405016"], nombre:"RM DE COLUMNA TOTAL", contraste:false, lateralidad:false },
  { modalidad:"MR", especialidad:"NEURORADIOLOGÍA", codigoFonasa:null, codigoInterno:"4050161", codigosFacturacion:["0405005", "0405006"], nombre:"RM DE COLUMNA CERVICODORSAL", contraste:false, lateralidad:false },
  { modalidad:"MR", especialidad:"NEURORADIOLOGÍA", codigoFonasa:null, codigoInterno:"4050162", codigosFacturacion:["0405006", "0405007"], nombre:"RM DE COLUMNA DORSOLUMBAR", contraste:false, lateralidad:false },
  { modalidad:"MR", especialidad:"NEURORADIOLOGÍA", codigoFonasa:null, codigoInterno:"4050163", codigosFacturacion:["405005"], nombre:"RM DE COLUMNA CERVICAL DINÁMICA (Flexión-Extensión)", contraste:false, lateralidad:false },
  { modalidad:"MR", especialidad:"NEURORADIOLOGÍA", codigoFonasa:null, codigoInterno:"4050164", codigosFacturacion:["405007"], nombre:"RM DE COLUMNA LUMBAR DINÁMICA (Flexión-Extensión)", contraste:false, lateralidad:false },
  { modalidad:"MR", especialidad:"NEURORADIOLOGÍA", codigoFonasa:null, codigoInterno:"4050165", codigosFacturacion:["0405005", "0405009"], nombre:"RM DE PLEXOS BRAQUIALES", contraste:true, lateralidad:true },
  { modalidad:"MR", especialidad:"NEURORADIOLOGÍA", codigoFonasa:null, codigoInterno:"4050166", codigosFacturacion:["0405007", "0405011"], nombre:"RM DE PLEXOS LUMBARES", contraste:true, lateralidad:false },
  { modalidad:"MR", especialidad:"MÚSCULO ESQUELÉTICO", codigoFonasa:"405028", codigoInterno:null, codigosFacturacion:["405028"], nombre:"RM DE ORTEJO (S)  DEL PIÉ", contraste:false, lateralidad:true },
  { modalidad:"MR", especialidad:"MÚSCULO ESQUELÉTICO", codigoFonasa:"405028", codigoInterno:null, codigosFacturacion:["405028"], nombre:"RM DE PIÉ", contraste:false, lateralidad:true },
  { modalidad:"MR", especialidad:"MÚSCULO ESQUELÉTICO", codigoFonasa:"405028", codigoInterno:null, codigosFacturacion:["405028"], nombre:"RM DE ANTEPIÉ O MEDIOPIÉ", contraste:false, lateralidad:true },
  { modalidad:"MR", especialidad:"MÚSCULO ESQUELÉTICO", codigoFonasa:"405028", codigoInterno:null, codigosFacturacion:["405028"], nombre:"RM DE TOBILLO O RETROPIÉ", contraste:false, lateralidad:true },
  { modalidad:"MR", especialidad:"MÚSCULO ESQUELÉTICO", codigoFonasa:"405029", codigoInterno:null, codigosFacturacion:["405029"], nombre:"RM DE PIERNA", contraste:false, lateralidad:true },
  { modalidad:"MR", especialidad:"MÚSCULO ESQUELÉTICO", codigoFonasa:"405013", codigoInterno:null, codigosFacturacion:["405013"], nombre:"RM DE RODILLA", contraste:false, lateralidad:true },
  { modalidad:"MR", especialidad:"MÚSCULO ESQUELÉTICO", codigoFonasa:"405030", codigoInterno:null, codigosFacturacion:["405030"], nombre:"RM DE MUSLO", contraste:false, lateralidad:true },
  { modalidad:"MR", especialidad:"MÚSCULO ESQUELÉTICO", codigoFonasa:"405030", codigoInterno:null, codigosFacturacion:["405030"], nombre:"RM DE CADERA", contraste:false, lateralidad:true },
  { modalidad:"MR", especialidad:"MÚSCULO ESQUELÉTICO", codigoFonasa:"405011", codigoInterno:null, codigosFacturacion:["405011"], nombre:"RM DE SÍNFISIS PÚBICA", contraste:false, lateralidad:false },
  { modalidad:"MR", especialidad:"MÚSCULO ESQUELÉTICO", codigoFonasa:"405011", codigoInterno:null, codigosFacturacion:["405011"], nombre:"RM DE PELVIS ÓSEA o MÚSCULO ESQUELÉTICA", contraste:false, lateralidad:false },
  { modalidad:"MR", especialidad:"MÚSCULO ESQUELÉTICO", codigoFonasa:"405011", codigoInterno:null, codigosFacturacion:["405011"], nombre:"RM DE GLÚTEO", contraste:false, lateralidad:true },
  { modalidad:"MR", especialidad:"MÚSCULO ESQUELÉTICO", codigoFonasa:"405011", codigoInterno:null, codigosFacturacion:["405011"], nombre:"RM DE ART. SACROILIÁCAS", contraste:true, lateralidad:false },
  { modalidad:"MR", especialidad:"MÚSCULO ESQUELÉTICO", codigoFonasa:"405024", codigoInterno:null, codigosFacturacion:["405024"], nombre:"RM DE DEDO (S) DE LA MANO", contraste:false, lateralidad:true },
  { modalidad:"MR", especialidad:"MÚSCULO ESQUELÉTICO", codigoFonasa:"405024", codigoInterno:null, codigosFacturacion:["405024"], nombre:"RM DE MUÑECA", contraste:false, lateralidad:true },
  { modalidad:"MR", especialidad:"MÚSCULO ESQUELÉTICO", codigoFonasa:"405024", codigoInterno:null, codigosFacturacion:["405024"], nombre:"RM DE MANO", contraste:false, lateralidad:true },
  { modalidad:"MR", especialidad:"MÚSCULO ESQUELÉTICO", codigoFonasa:null, codigoInterno:"4050241", codigosFacturacion:["0405024", "0405024"], nombre:"RM DE MANOS (A.R.)", contraste:true, lateralidad:false },
  { modalidad:"MR", especialidad:"MÚSCULO ESQUELÉTICO", codigoFonasa:"405025", codigoInterno:null, codigosFacturacion:["405025"], nombre:"RM DE ANTEBRAZO", contraste:false, lateralidad:true },
  { modalidad:"MR", especialidad:"MÚSCULO ESQUELÉTICO", codigoFonasa:"405026", codigoInterno:null, codigosFacturacion:["405026"], nombre:"RM DE CODO", contraste:false, lateralidad:true },
  { modalidad:"MR", especialidad:"MÚSCULO ESQUELÉTICO", codigoFonasa:"405025", codigoInterno:null, codigosFacturacion:["405025"], nombre:"RM DE BRAZO", contraste:false, lateralidad:true },
  { modalidad:"MR", especialidad:"MÚSCULO ESQUELÉTICO", codigoFonasa:"405009", codigoInterno:null, codigosFacturacion:["405009"], nombre:"RM DE ESCÁPULA", contraste:false, lateralidad:true },
  { modalidad:"MR", especialidad:"MÚSCULO ESQUELÉTICO", codigoFonasa:"405027", codigoInterno:null, codigosFacturacion:["405027"], nombre:"RM DE HOMBRO", contraste:false, lateralidad:true },
  { modalidad:"MR", especialidad:"MÚSCULO ESQUELÉTICO", codigoFonasa:"405009", codigoInterno:null, codigosFacturacion:["405009"], nombre:"RM DE PARRILLA COSTAL", contraste:false, lateralidad:false },
  { modalidad:"MR", especialidad:"MÚSCULO ESQUELÉTICO", codigoFonasa:null, codigoInterno:"4050091", codigosFacturacion:["0405009", "0405019"], nombre:"RM DE TÓRAX (Protocolo SOT - SST)", contraste:true, lateralidad:false },
  { modalidad:"MR", especialidad:"MÚSCULO ESQUELÉTICO", codigoFonasa:"405009", codigoInterno:null, codigosFacturacion:["405009"], nombre:"RM DE TÓRAX ÓSEO o MÚSCULO ESQUELÉTICO", contraste:null, lateralidad:false },
  { modalidad:"MR", especialidad:"MÚSCULO ESQUELÉTICO", codigoFonasa:"405009", codigoInterno:null, codigosFacturacion:["405009"], nombre:"RM DE ESTERNÓN", contraste:false, lateralidad:false },
  { modalidad:"MR", especialidad:"MÚSCULO ESQUELÉTICO", codigoFonasa:"405009", codigoInterno:null, codigosFacturacion:["405009"], nombre:"RM DE CLAVÍCULA", contraste:false, lateralidad:false },
  { modalidad:"MR", especialidad:"MÚSCULO ESQUELÉTICO", codigoFonasa:"405004", codigoInterno:null, codigosFacturacion:["405004"], nombre:"RM DE ART. TEMPOROMANDIBULARES", contraste:false, lateralidad:false },
  { modalidad:"MR", especialidad:"MÚSCULO ESQUELÉTICO", codigoFonasa:null, codigoInterno:"40501611", codigosFacturacion:["0405016", "0405011"], nombre:"RM DE PELVIESPONDILOPATÍA (Protocolo PEP)", contraste:true, lateralidad:false },
  { modalidad:"MR", especialidad:"MÚSCULO ESQUELÉTICO", codigoFonasa:null, codigoInterno:"4050232", codigosFacturacion:["405023"], nombre:"RM DE EXTREMIDADES INFERIORES", contraste:false, lateralidad:false },
  { modalidad:"MR", especialidad:"MÚSCULO ESQUELÉTICO", codigoFonasa:null, codigoInterno:"4050231", codigosFacturacion:["0405029", "0405030"], nombre:"RM DE EXTREMIDAD INFERIOR", contraste:false, lateralidad:true },
  { modalidad:"MR", especialidad:"MÚSCULO ESQUELÉTICO", codigoFonasa:null, codigoInterno:"4050221", codigosFacturacion:["0405025", "0405025"], nombre:"RM DE EXTREMIDAD SUPERIOR", contraste:false, lateralidad:true },
  { modalidad:"MR", especialidad:"CUERPO", codigoFonasa:"405010", codigoInterno:null, codigosFacturacion:["405010"], nombre:"RM DE ABDOMEN", contraste:true, lateralidad:false },
  { modalidad:"MR", especialidad:"CUERPO", codigoFonasa:"405010", codigoInterno:null, codigosFacturacion:["405010"], nombre:"RM DE ABDOMEN (Hepato Específico)", contraste:true, lateralidad:false },
  { modalidad:"MR", especialidad:"CUERPO", codigoFonasa:"405098", codigoInterno:null, codigosFacturacion:["405098"], nombre:"COLANGIO RESONANCIA MAGNÉTICA (COLANGIO-RM)", contraste:false, lateralidad:null },
  { modalidad:"MR", especialidad:"CUERPO", codigoFonasa:"405012", codigoInterno:null, codigosFacturacion:["405012"], nombre:"RM DE ABDOMEN Y PELVIS", contraste:true, lateralidad:false },
  { modalidad:"MR", especialidad:"CUERPO", codigoFonasa:"405001", codigoInterno:null, codigosFacturacion:["405001"], nombre:"RM DE CARA o MAXILO-FACIAL", contraste:false, lateralidad:false },
  { modalidad:"MR", especialidad:"CUERPO", codigoFonasa:"405001", codigoInterno:null, codigosFacturacion:["405001"], nombre:"RM DE CAVIDADES PARANASALES", contraste:false, lateralidad:false },
  { modalidad:"MR", especialidad:"CUERPO", codigoFonasa:"405005", codigoInterno:null, codigosFacturacion:["405005"], nombre:"RM DE CUELLO", contraste:true, lateralidad:false },
  { modalidad:"MR", especialidad:"CUERPO", codigoFonasa:"405011", codigoInterno:null, codigosFacturacion:["405011"], nombre:"RM DE GENITALES", contraste:true, lateralidad:false },
  { modalidad:"MR", especialidad:"CUERPO", codigoFonasa:"405031", codigoInterno:null, codigosFacturacion:["405031"], nombre:"RM DE MAMA (BILATERAL)", contraste:true, lateralidad:false },
  { modalidad:"MR", especialidad:"CUERPO", codigoFonasa:"405010", codigoInterno:null, codigosFacturacion:["405010"], nombre:"RM DE PARED ABDOMINAL", contraste:false, lateralidad:false },
  { modalidad:"MR", especialidad:"CUERPO", codigoFonasa:"405011", codigoInterno:null, codigosFacturacion:["405011"], nombre:"RM DE PELVIS (FEMENINA)", contraste:true, lateralidad:false },
  { modalidad:"MR", especialidad:"CUERPO", codigoFonasa:"405011", codigoInterno:null, codigosFacturacion:["405011"], nombre:"RM DE PELVIS (P. BLANDA)", contraste:false, lateralidad:false },
  { modalidad:"MR", especialidad:"CUERPO", codigoFonasa:"405011", codigoInterno:null, codigosFacturacion:["405011"], nombre:"RM DE PELVIS (PERINÉ)", contraste:true, lateralidad:false },
  { modalidad:"MR", especialidad:"CUERPO", codigoFonasa:"405011", codigoInterno:null, codigosFacturacion:["405011"], nombre:"RM DE PELVIS (PLACENTA-ACRETISMO)", contraste:false, lateralidad:false },
  { modalidad:"MR", especialidad:"CUERPO", codigoFonasa:"405011", codigoInterno:null, codigosFacturacion:["405011"], nombre:"RM DE PELVIS (VEJIGA O URETRA)", contraste:true, lateralidad:false },
  { modalidad:"MR", especialidad:"CUERPO", codigoFonasa:"405011", codigoInterno:null, codigosFacturacion:["405011"], nombre:"RM DE PROSTATA MULTIPARAMÉTRICA", contraste:true, lateralidad:false },
  { modalidad:"MR", especialidad:"CUERPO", codigoFonasa:"405010", codigoInterno:null, codigosFacturacion:["405010"], nombre:"RM DE RIÑONES O RENAL", contraste:true, lateralidad:false },
  { modalidad:"MR", especialidad:"CUERPO", codigoFonasa:"405009", codigoInterno:null, codigosFacturacion:["405009"], nombre:"RM DE TÓRAX", contraste:true, lateralidad:false },
  { modalidad:"MR", especialidad:"CUERPO", codigoFonasa:null, codigoInterno:"4050121", codigosFacturacion:["0405009", "0405010"], nombre:"RM DE TORAX Y ABDOMEN", contraste:true, lateralidad:false },
  { modalidad:"MR", especialidad:"CUERPO", codigoFonasa:null, codigoInterno:"4050122", codigosFacturacion:["0405009", "0405010", "0405011"], nombre:"RM DE TORAX, ABDOMEN Y PELVIS", contraste:true, lateralidad:false },
  { modalidad:"MR", especialidad:"ANGIOGRAFÍA POR RM", codigoFonasa:"405017", codigoInterno:null, codigosFacturacion:["405017"], nombre:"ANGIORM DE CARA", contraste:false, lateralidad:false },
  { modalidad:"MR", especialidad:"ANGIOGRAFÍA POR RM", codigoFonasa:"405017", codigoInterno:null, codigosFacturacion:["405017"], nombre:"ANGIORM DE CEREBRO", contraste:false, lateralidad:false },
  { modalidad:"MR", especialidad:"ANGIOGRAFÍA POR RM", codigoFonasa:"405018", codigoInterno:null, codigosFacturacion:["405018"], nombre:"ANGIORM DE CUELLO", contraste:true, lateralidad:false },
  { modalidad:"MR", especialidad:"ANGIOGRAFÍA POR RM", codigoFonasa:"405019", codigoInterno:null, codigosFacturacion:["405019"], nombre:"ANGIORM DE TÓRAX", contraste:true, lateralidad:false },
  { modalidad:"MR", especialidad:"ANGIOGRAFÍA POR RM", codigoFonasa:null, codigoInterno:"4050191", codigosFacturacion:["0405009", "0405019"], nombre:"ANGIORM DE ART. PULMONAR", contraste:true, lateralidad:false },
  { modalidad:"MR", especialidad:"ANGIOGRAFÍA POR RM", codigoFonasa:"405019", codigoInterno:null, codigosFacturacion:["405019"], nombre:"ANGIORM DE AORTA", contraste:true, lateralidad:false },
  { modalidad:"MR", especialidad:"ANGIOGRAFÍA POR RM", codigoFonasa:null, codigoInterno:"4050192", codigosFacturacion:["0405009", "0405019"], nombre:"ANGIORM DE ART. CORONARIAS", contraste:true, lateralidad:false },
  { modalidad:"MR", especialidad:"ANGIOGRAFÍA POR RM", codigoFonasa:"405020", codigoInterno:null, codigosFacturacion:["405020"], nombre:"ANGIORM DE ABDOMEN", contraste:true, lateralidad:false },
  { modalidad:"MR", especialidad:"ANGIOGRAFÍA POR RM", codigoFonasa:"405020", codigoInterno:null, codigosFacturacion:["405020"], nombre:"ANGIORM RENAL", contraste:true, lateralidad:false },
  { modalidad:"MR", especialidad:"ANGIOGRAFÍA POR RM", codigoFonasa:"405021", codigoInterno:null, codigosFacturacion:["405021"], nombre:"ANGIORM DE PELVIS", contraste:true, lateralidad:false },
  { modalidad:"MR", especialidad:"ANGIOGRAFÍA POR RM", codigoFonasa:"405023", codigoInterno:null, codigosFacturacion:["405023"], nombre:"ANGIORM DE EXTREMIDADES INFERIORES", contraste:true, lateralidad:false },
  { modalidad:"MR", especialidad:"ANGIOGRAFÍA POR RM", codigoFonasa:null, codigoInterno:"4050233", codigosFacturacion:["405023"], nombre:"ANGIORM DE EXTEMIDAD INFERIOR", contraste:true, lateralidad:true },
  { modalidad:"MR", especialidad:"ANGIOGRAFÍA POR RM", codigoFonasa:"405022", codigoInterno:null, codigosFacturacion:["405022"], nombre:"ANGIORM DE EXTREMIDAD SUPERIOR", contraste:true, lateralidad:true },
  { modalidad:"MR", especialidad:"ANGIOGRAFÍA POR RM", codigoFonasa:"405022", codigoInterno:null, codigosFacturacion:["405022"], nombre:"ANGIORM DE EXTREMIDAD  EN ZONA DIRIGIDA", contraste:true, lateralidad:true },
  { modalidad:"MR", especialidad:"ANGIOGRAFÍA POR RM", codigoFonasa:null, codigoInterno:null, codigosFacturacion:[], nombre:"ANGIORM DE CUERPO COMPLETO", contraste:true, lateralidad:false },
  { modalidad:"MR", especialidad:"ESTUDIOS O PROCEDIMIENTOS AVANZADOS", codigoFonasa:null, codigoInterno:"4050011", codigosFacturacion:[], nombre:"ESPECTROSCOPÍA CEREBRAL POR RM", contraste:true, lateralidad:false },
  { modalidad:"MR", especialidad:"ESTUDIOS O PROCEDIMIENTOS AVANZADOS", codigoFonasa:null, codigoInterno:"4050012", codigosFacturacion:[], nombre:"ESTUDIO DE FLUJO LCR o CEREBRAL POR RM", contraste:false, lateralidad:false },
  { modalidad:"MR", especialidad:"ESTUDIOS O PROCEDIMIENTOS AVANZADOS", codigoFonasa:"405016", codigoInterno:"4050167", codigosFacturacion:[], nombre:"MIELOGRAFÍA MEDULAR POR RM (MIELO-RM o RM DE MÉDULA)", contraste:true, lateralidad:false },
  { modalidad:"MR", especialidad:"ESTUDIOS O PROCEDIMIENTOS AVANZADOS", codigoFonasa:null, codigoInterno:"4050301", codigosFacturacion:[], nombre:"NEUROTRACTOGRAFÍA DE NERVIO PERIFÉRICO POR RM", contraste:true, lateralidad:true },
  { modalidad:"MR", especialidad:"ESTUDIOS O PROCEDIMIENTOS AVANZADOS", codigoFonasa:null, codigoInterno:"4050013", codigosFacturacion:[], nombre:"PERFUSIÓN CEREBRAL POR RM", contraste:true, lateralidad:false },
  { modalidad:"MR", especialidad:"ESTUDIOS O PROCEDIMIENTOS AVANZADOS", codigoFonasa:null, codigoInterno:"4050302", codigosFacturacion:[], nombre:"RM DE NERVIO PERIFÉRICO", contraste:true, lateralidad:true },
  { modalidad:"MR", especialidad:"ESTUDIOS O PROCEDIMIENTOS AVANZADOS", codigoFonasa:null, codigoInterno:"4050014", codigosFacturacion:[], nombre:"TRACTOGRAFÍA CEREBRAL POR RM", contraste:true, lateralidad:false },
  { modalidad:"MR", especialidad:"ESTUDIOS O PROCEDIMIENTOS AVANZADOS", codigoFonasa:null, codigoInterno:"4050303", codigosFacturacion:[], nombre:"ESTUDIO DE CARTÍLAGO POR RM (Mapping T2)", contraste:false, lateralidad:true },
  { modalidad:"MR", especialidad:"ESTUDIOS O PROCEDIMIENTOS AVANZADOS", codigoFonasa:null, codigoInterno:"4050234", codigosFacturacion:["0405011", "0405013"], nombre:"RM DE EXTREMIDADES INFERIORES (Protocolo de Torsión Femoral)", contraste:false, lateralidad:false },
  { modalidad:"MR", especialidad:"ESTUDIOS O PROCEDIMIENTOS AVANZADOS", codigoFonasa:null, codigoInterno:"4050235", codigosFacturacion:["405013"], nombre:"RM DE RODILLA (Protocolo Disfunción Patelofemoral)", contraste:false, lateralidad:true },
  { modalidad:"MR", especialidad:"ESTUDIOS O PROCEDIMIENTOS AVANZADOS", codigoFonasa:null, codigoInterno:"4050193", codigosFacturacion:["0405009", "0405019"], nombre:"CARDIO RESONANCIA MAGNÉTICA (CARDIO-RM)", contraste:true, lateralidad:false },
  { modalidad:"MR", especialidad:"ESTUDIOS O PROCEDIMIENTOS AVANZADOS", codigoFonasa:null, codigoInterno:"4050015", codigosFacturacion:["405001"], nombre:"SIALOGRAFÍA POR RESONANCIA MAGNÉTICA (SIALO-RM)", contraste:true, lateralidad:false },
  { modalidad:"MR", especialidad:"ESTUDIOS O PROCEDIMIENTOS AVANZADOS", codigoFonasa:null, codigoInterno:"4050016", codigosFacturacion:["0405001", "0405005"], nombre:"RM DE LARINGE (Protocolo Cuerdas vocales y Fonación)", contraste:false, lateralidad:false },
  { modalidad:"MR", especialidad:"ESTUDIOS O PROCEDIMIENTOS AVANZADOS", codigoFonasa:"405011", codigoInterno:null, codigosFacturacion:["405011"], nombre:"URETROGRAFÍA POR RESONANCIA MAGNÉTICA (URETRO-RM)", contraste:true, lateralidad:false },
  { modalidad:"MR", especialidad:"ESTUDIOS O PROCEDIMIENTOS AVANZADOS", codigoFonasa:"405011", codigoInterno:null, codigosFacturacion:["405011"], nombre:"CISTOGRAFÍA MICCIONAL POR RESONANCIA MAGNÉTICA (CISTO-RM)", contraste:true, lateralidad:false },
  { modalidad:"MR", especialidad:"ESTUDIOS O PROCEDIMIENTOS AVANZADOS", codigoFonasa:"405012", codigoInterno:null, codigosFacturacion:["405012"], nombre:"UROGRAFÍA POR RESONANCIA MAGNÉTICA (URO-RM)", contraste:true, lateralidad:false },
  { modalidad:"MR", especialidad:"ESTUDIOS O PROCEDIMIENTOS AVANZADOS", codigoFonasa:"405012", codigoInterno:null, codigosFacturacion:["405012"], nombre:"ENTEROGRAFÍA POR RESONANCIA MAGNÉTICA (ENTERO-RM)", contraste:true, lateralidad:false },
  { modalidad:"MR", especialidad:"ESTUDIOS O PROCEDIMIENTOS AVANZADOS", codigoFonasa:"405011", codigoInterno:null, codigosFacturacion:["405011"], nombre:"DEFECOGRAFÍA POR RESONANCIA MAGNÉTICA (DEFECO-RM)", contraste:true, lateralidad:false },
  { modalidad:"MR", especialidad:"ESTUDIOS O PROCEDIMIENTOS AVANZADOS", codigoFonasa:null, codigoInterno:"4050101", codigosFacturacion:["4050101"], nombre:"ELASTOGRAFÍA POR RESONANCIA MAGNÉTICA (ELASTO-RM)", contraste:false, lateralidad:false },
  { modalidad:"MR", especialidad:"ESTUDIOS O PROCEDIMIENTOS AVANZADOS", codigoFonasa:null, codigoInterno:"4050401", codigosFacturacion:["0405001", "0405012", "0405011"], nombre:"RM DE CUERPO COMPLETO", contraste:false, lateralidad:false },
  { modalidad:"MR", especialidad:"ESTUDIOS O PROCEDIMIENTOS AVANZADOS", codigoFonasa:null, codigoInterno:"4050402", codigosFacturacion:[], nombre:"LINFO-RM O LINFOGRAFÍA POR RESONANCIA MAGNÉTICA DE CUERPO COMPLETO", contraste:true, lateralidad:false },
  { modalidad:"MR", especialidad:"ESTUDIOS O PROCEDIMIENTOS AVANZADOS", codigoFonasa:null, codigoInterno:"4050403", codigosFacturacion:[], nombre:"LINFO-RM O LINFOGRAFÍA POR RESONANCIA MAGNÉTICA (ZONA DIRIGIDA)", contraste:true, lateralidad:false },
  { modalidad:"MR", especialidad:"ESTUDIOS O PROCEDIMIENTOS AVANZADOS", codigoFonasa:"405032", codigoInterno:null, codigosFacturacion:["405032"], nombre:"RESONANCIA MAGNÉTICA FETAL", contraste:false, lateralidad:false },
  { modalidad:"MR", especialidad:"ESTUDIOS O PROCEDIMIENTOS AVANZADOS", codigoFonasa:"405001", codigoInterno:null, codigosFacturacion:["405001"], nombre:"RM DE CEREBRO FETAL", contraste:false, lateralidad:false },
  { modalidad:"MR", especialidad:"ESTUDIOS O PROCEDIMIENTOS AVANZADOS", codigoFonasa:"405032", codigoInterno:null, codigosFacturacion:["405032"], nombre:"RM DE CUERPO FETAL", contraste:false, lateralidad:false },
  { modalidad:"MR", especialidad:"ESTUDIOS O PROCEDIMIENTOS AVANZADOS", codigoFonasa:"405032", codigoInterno:null, codigosFacturacion:["405032"], nombre:"RM MÚSCULO ESQUELÉTICA FETAL", contraste:false, lateralidad:false },
  // PLACEHOLDER — sin catálogo real todavía, ver nota #4 del encabezado.
  { modalidad:"CT", especialidad:"General", codigoFonasa:null, codigoInterno:null, codigosFacturacion:[], nombre:"TAC de Cerebro sin contraste", contraste:false, lateralidad:false },
  { modalidad:"CT", especialidad:"General", codigoFonasa:null, codigoInterno:null, codigosFacturacion:[], nombre:"TAC de Abdomen y Pelvis con contraste", contraste:true, lateralidad:false },
  { modalidad:"CT", especialidad:"General", codigoFonasa:null, codigoInterno:null, codigosFacturacion:[], nombre:"Angiografía por TAC de Tórax", contraste:true, lateralidad:false },
  { modalidad:"CR", especialidad:"General", codigoFonasa:null, codigoInterno:null, codigosFacturacion:[], nombre:"Radiografía de Tórax AP/Lateral", contraste:false, lateralidad:false },
  { modalidad:"CR", especialidad:"General", codigoFonasa:null, codigoInterno:null, codigosFacturacion:[], nombre:"Radiografía de Columna Lumbosacra", contraste:false, lateralidad:false },
  { modalidad:"CR", especialidad:"General", codigoFonasa:null, codigoInterno:null, codigosFacturacion:[], nombre:"Radiografía de Muñeca", contraste:false, lateralidad:true },
  { modalidad:"US", especialidad:"General", codigoFonasa:null, codigoInterno:null, codigosFacturacion:[], nombre:"Ecografía Abdominal", contraste:false, lateralidad:false },
  { modalidad:"US", especialidad:"General", codigoFonasa:null, codigoInterno:null, codigosFacturacion:[], nombre:"Ecografía Doppler Vascular", contraste:false, lateralidad:true },
  { modalidad:"MG", especialidad:"General", codigoFonasa:null, codigoInterno:null, codigosFacturacion:[], nombre:"Mamografía Bilateral de Tamizaje", contraste:false, lateralidad:false },
];

// Matriz de consentimiento — RM y TAC confirmadas con el usuario. El resto
// (CR/US/MG) usa el flag `contraste` del catálogo como aproximación,
// pendiente de que el usuario confirme la regla real para esas modalidades.
function calcularConsentimiento(modalidad, contraste) {
  if (modalidad === "MR") return { requiere:true, plantilla: contraste ? "RM_CON_CONTRASTE" : "RM_SIN_CONTRASTE" };
  if (modalidad === "CT") return { requiere: !!contraste, plantilla: contraste ? "TAC_CON_CONTRASTE" : null };
  return { requiere: !!contraste, plantilla: contraste ? `${modalidad}_CON_CONTRASTE` : null };
}

// Diccionario anatómico — portado del código del usuario, generalizado más
// allá de RM. Género/plural para aplicar reglas gramaticales chilenas al
// nombre final (el mismo nombre que después imprime el consentimiento).
const DICCIONARIO_ANATOMICO = {
  "PIE": { genero:"M", plural:"PIES" }, "TOBILLO": { genero:"M", plural:"TOBILLOS" },
  "PIERNA": { genero:"F", plural:"PIERNAS" }, "RODILLA": { genero:"F", plural:"RODILLAS" },
  "MUSLO": { genero:"M", plural:"MUSLOS" }, "CADERA": { genero:"F", plural:"CADERAS" },
  "GLÚTEO": { genero:"M", plural:"GLÚTEOS" }, "MANO": { genero:"F", plural:"MANOS" },
  "MUÑECA": { genero:"F", plural:"MUÑECAS" }, "ANTEBRAZO": { genero:"M", plural:"ANTEBRAZOS" },
  "CODO": { genero:"M", plural:"CODOS" }, "BRAZO": { genero:"M", plural:"BRAZOS" },
  "ESCÁPULA": { genero:"F", plural:"ESCÁPULAS" }, "HOMBRO": { genero:"M", plural:"HOMBROS" },
  "EXTREMIDAD": { genero:"F", plural:"EXTREMIDADES" }, "DEDO": { genero:"M", plural:"DEDOS" },
  "ORTEJO": { genero:"M", plural:"ORTEJOS" }, "MAMA": { genero:"F", plural:"MAMAS" },
  "RIÑÓN": { genero:"M", plural:"RIÑONES" },
};
function construirNombreEspecifico(nombreBase, lateralidad) {
  if (!["Derecha","Izquierda","Ambas"].includes(lateralidad)) return nombreBase;
  const base = nombreBase.toUpperCase();
  const palabra = Object.keys(DICCIONARIO_ANATOMICO).find(k => base.includes(k));
  if (!palabra) return `${nombreBase} ${lateralidad.toUpperCase()}`;
  const { genero, plural } = DICCIONARIO_ANATOMICO[palabra];
  if (lateralidad === "Ambas") {
    const sufijo = genero === "M" ? "AMBOS" : "AMBAS";
    const nuevo = base.replace(palabra, plural);
    if (nuevo.includes(`DE ${plural}`)) return nuevo.replace(`DE ${plural}`, `DE ${sufijo} ${plural}`);
    return `${nuevo} ${sufijo}`;
  }
  const sufijoLado = genero === "F" ? lateralidad.toUpperCase() : lateralidad.toUpperCase().replace(/A$/, "O");
  return `${nombreBase} ${sufijoLado}`;
}

// CIE-10/11 contextual — portado del clasificador del usuario. Clave
// compuesta modalidad::especialidad porque cada modalidad puede tener su
// propia taxonomía de subespecialidades (Ecografía no comparte las de RM).
// Solo MR tiene mapeo específico hoy — el resto cae en GENERAL.
const MAPEO_CIE = {
  MR: {
    "NEURORADIOLOGÍA": {
      "CIE-10": ["R93.0 - Hallazgos anormales en diagnóstico por imagen de cabeza","G40.9 - Epilepsia, tipo no especificado","G43.9 - Migraña, no especificada","I64.X - Accidente vascular encefálico agudo (ACV)","C71.9 - Tumor maligno del encéfalo","R51.X - Cefalea","S06.9 - Traumatismo intracraneal no especificado (TEC)","G30.9 - Enfermedad de Alzheimer / Demencia","M50.2 - Desplazamiento de disco cervical","M51.2 - Desplazamiento de disco intervertebral lumbar","H47.0 - Trastornos del nervio óptico"],
      "CIE-11": ["MD80 - Hallazgos anormales en imagen del sistema nervioso central","8B20 - Epilepsia","8B11 - Infarto cerebral","9B60 - Migraña","1D40 - Tumores primarios del SNC","MB41 - Cefalea","8A20 - Enfermedad de Alzheimer","FA80 - Artrosis y patología de disco espinal"],
    },
    "MÚSCULO ESQUELÉTICO": {
      "CIE-10": ["R93.6 - Hallazgos anormales en imagen de miembros","R93.7 - Hallazgos anormales en imagen de sistema osteomuscular","M54.5 - Lumbago no especificado","M17.9 - Gonartrosis no especificada (Rodilla)","M16.9 - Coxartrosis no especificada (Cadera)","M23.2 - Trastorno de menisco debido a desgarro","S83.2 - Desgarro de meniscos (Traumático)","M75.1 - Síndrome del manguito rotador","M05.9 - Artritis reumatoide","S82.0 - Fractura de la rótula / ósea"],
      "CIE-11": ["MD85 - Hallazgos anormales en imagen del sistema musculoesquelético","FA80 - Artrosis","ME84 - Dolor espinal / Lumbago","NC72 - Lesiones de rodilla o pierna inferior","FB53.1 - Síndrome del manguito rotador","FA20 - Artritis reumatoide"],
    },
    "CUERPO": {
      "CIE-10": ["R93.5 - Hallazgos anormales en imagen de regiones abdominales","R91.X - Hallazgos anormales en diagnóstico por imagen de pulmón","R10.4 - Dolor abdominal y pélvico","K80.2 - Colelitiasis (Cálculos en vesícula)","N20.0 - Urolitiasis (Cálculos en riñón)","C22.0 - Carcinoma hepatocelular","C61.X - Tumor maligno de la próstata","N92.0 - Sangrado uterino / Miomatosis","K57.9 - Enfermedad diverticular","J18.9 - Neumonía","C34.9 - Tumor maligno de bronquios o pulmón"],
      "CIE-11": ["MD81 - Hallazgos anormales en imagen de abdomen","MD83 - Hallazgos anormales en imagen del pulmón","ME04 - Dolor abdominal","DC11 - Colelitiasis","GB70 - Urolitiasis","2D10 - Neoplasias malignas del aparato digestivo","2C25 - Neoplasias malignas del pulmón","GA31 - Endometriosis y miomatosis"],
    },
    "ANGIOGRAFÍA POR RM": {
      "CIE-10": ["R93.1 - Hallazgos anormales en imagen de corazón y circulación","I71.9 - Aneurisma aórtico","I67.1 - Aneurisma cerebral no roto","I70.9 - Aterosclerosis generalizada","I80.2 - Trombosis venosa profunda (TVP)","I65.2 - Oclusión y estenosis de arteria carótida","I73.9 - Enfermedad vascular periférica","Q28.2 - Malformación arteriovenosa"],
      "CIE-11": ["MD84 - Hallazgos anormales en imagen del sistema cardiovascular","BD50 - Aneurisma aórtico","8B22 - Aneurisma cerebral","BD40 - Aterosclerosis","BD71 - Trombosis venosa profunda","8B12 - Estenosis oclusiva de arterias precerebrales"],
    },
    "ESTUDIOS O PROCEDIMIENTOS AVANZADOS": {
      "CIE-10": ["R92.X - Hallazgos anormales en diagnóstico por imagen de la mama","C50.9 - Tumor maligno de la mama","I51.9 - Enfermedad cardíaca, no especificada (Para Cardio-RM)","K50.9 - Enfermedad de Crohn (Para Entero-RM)","K59.0 - Constipación / Trastorno defecatorio (Para Defeco-RM)","N31.9 - Disfunción neuromuscular de vejiga (Para Cisto/Uretro-RM)","K74.6 - Cirrosis hepática (Para Elasto-RM)","K11.2 - Sialadenitis / Patología salival (Para Sialo-RM)"],
      "CIE-11": ["MD82 - Hallazgos anormales en imagen de la mama","2C6Y - Neoplasias malignas de mama","BC4Z - Enfermedad miocárdica (Cardio-RM)","DD70 - Enfermedad de Crohn (Entero-RM)","ME05 - Estreñimiento crónico (Defeco-RM)","GC11 - Retención urinaria (Uretro/Cisto-RM)","DB90 - Fibrosis y cirrosis hepática (Elasto-RM)"],
    },
  },
};
const CIE_GENERAL = {
  "CIE-10": ["R93.8 - Hallazgos anormales en diagnóstico por imagen de otras partes","Z01.6 - Examen radiológico (pesquisa de rutina)","R69.X - Causas de morbilidad desconocidas y no especificadas"],
  "CIE-11": ["MF05 - Examen radiológico o de diagnóstico por imagen","MD8X - Otros hallazgos anormales en imagen"],
};
function sugerenciasCIE(modalidad, especialidad, norma) {
  const bucket = MAPEO_CIE[modalidad]?.[especialidad];
  return bucket ? bucket[norma] : CIE_GENERAL[norma];
}

// Catálogo semilla de búsqueda completa (mismo criterio que Presencial:
// catálogo de muestra, no fuente de verdad, con carga de CSV disponible).
const CATALOGO_SEMILLA_CIE10 = [
  { codigo:"Z00.0", label:"Control de salud del adulto" }, { codigo:"I10", label:"Hipertensión esencial (primaria)" },
  { codigo:"M54.5", label:"Lumbago no especificado" }, { codigo:"M51.2", label:"Desplazamiento de disco intervertebral lumbar" },
  { codigo:"S83.2", label:"Desgarro de meniscos (Traumático)" }, { codigo:"M17.9", label:"Gonartrosis no especificada" },
  { codigo:"R93.0", label:"Hallazgos anormales en imagen de cabeza" }, { codigo:"G43.9", label:"Migraña, no especificada" },
  { codigo:"R10.4", label:"Dolor abdominal y pélvico" }, { codigo:"K80.2", label:"Colelitiasis" },
  { codigo:"N20.0", label:"Urolitiasis" }, { codigo:"J18.9", label:"Neumonía" },
  { codigo:"I71.9", label:"Aneurisma aórtico" }, { codigo:"I80.2", label:"Trombosis venosa profunda (TVP)" },
  { codigo:"C50.9", label:"Tumor maligno de la mama" }, { codigo:"S06.9", label:"Traumatismo intracraneal no especificado (TEC)" },
  { codigo:"Z01.6", label:"Examen radiológico (pesquisa de rutina)" },
];
// Catálogo de muestra CIE-11: se arma con los códigos CIE-11 que YA existen en MAPEO_CIE /
// CIE_GENERAL (no se inventa ninguno). Es MOCK: en producción CIE-10 y CIE-11 los sirve el
// servicio terminológico de MAIN, con versión y vigencia.
const CATALOGO_SEMILLA_CIE11 = (() => {
  const vistos = new Map();
  const juntar = (lista) => lista.forEach(t => { const i = t.indexOf(" - "); if (i > 0 && !vistos.has(t.slice(0, i))) vistos.set(t.slice(0, i), t.slice(i + 3)); });
  Object.values(MAPEO_CIE).forEach(esp => Object.values(esp).forEach(n => juntar(n["CIE-11"])));
  juntar(CIE_GENERAL["CIE-11"]);
  return [...vistos].map(([codigo, label]) => ({ codigo, label }));
})();
function buscarEnCatalogo(items, query) {
  if (!query || query.trim().length < 2) return [];
  const q = query.toLowerCase();
  return items.filter(c => c.codigo.toLowerCase().includes(q) || c.label.toLowerCase().includes(q)).slice(0, 8);
}

const NOMBRES = ["María José","Pedro","Camila","Rodrigo","Fernanda","Ignacio","Valentina","Cristóbal","Antonia","Matías","Javiera","Sebastián","Catalina","Diego","Francisca","Tomás","Constanza","Felipe","Josefa","Nicolás"];
const APELLIDOS = ["González","Muñoz","Rojas","Díaz","Pérez","Soto","Contreras","Silva","Martínez","Sepúlveda","Morales","Rodríguez","López","Fuentes","Hernández","Torres"];

// Estados de AGENDA + reflejo informativo del RIS. "En Atención" y
// "Atendido" NO se controlan desde acá (no hay botón que los dispare) —
// son el reflejo de cuando el paciente entra y sale de sala en el
// módulo operativo. Hoy, sin conexión real, se seedean en el mock para
// que la grilla se vea completa; el día que exista conexión, vienen de
// allá. Mismo patrón que "en_atencion" en AtencionMedicaAgenda.jsx.
const ESTADOS = {
  agendado:    { label:"Agendado",    color:C.txl },
  confirmado:  { label:"Confirmado",  color:C.tea },
  en_espera:   { label:"En Espera",   color:C.war },
  en_atencion: { label:"En Atención", color:C.pur },
  atendido:    { label:"Atendido",    color:C.suc },
  no_show:     { label:"No Asistió",  color:C.dan },
  cancelado:   { label:"Cancelada",   color:C.txl },
  reagendada:  { label:"Reagendada",  color:C.txl },
};
const ESTADOS_LIBERAN_CUPO = new Set(["cancelado", "reagendada"]);

// Acción esperada en `auditoria` según el estado final de la orden — cruza
// el evento correcto (actor + hora), no solo "el más reciente para este
// id" (que podría traer una acción posterior sin relación).
const ACCION_POR_ESTADO_HISTORIAL = {
  cancelado: "Canceló orden",
  reagendada: "Reagendó solicitud",
  no_show: "Marcó no-show",
  confirmado: "Confirmó orden",
};
// Caso especial: si la orden quedó "reagendada", el evento de auditoría de
// ESA acción quedó etiquetado con el id de la orden NUEVA
// (reagendadaHaciaId) — sin seguir ese link nunca se encuentra quién
// reagendó ni cuándo, aunque el dato exista.
// Acciones de VISTA (auditoría de lectura, punto 1.9). Se declaran acá, junto
// a ACCION_POR_ESTADO_HISTORIAL, porque eventoDeAuditoria() las tiene que
// excluir: una vista NO es quien produjo un cambio de estado. Sin esto, una
// orden de muestra cancelada que alguien solo abrió para mirar mostraría al
// que la miró como si la hubiera cancelado (el fallback candidatos[0] caía
// en la entrada de vista, en vez del honesto "información histórica parcial").
const ACCION_VISTA_ORDEN = "Vio detalle de orden";
const ACCION_VISTA_CUPO = "Vio historial de cupo";
const ACCIONES_DE_VISTA = new Set([ACCION_VISTA_ORDEN, ACCION_VISTA_CUPO]);

function eventoDeAuditoria(auditoria, orden) {
  const entidadBuscada = (orden.estado === "reagendada" && orden.reagendadaHaciaId) ? orden.reagendadaHaciaId : orden.id;
  const candidatos = auditoria.filter(a => a.entidad === entidadBuscada && !ACCIONES_DE_VISTA.has(a.accion));
  const accionEsperada = ACCION_POR_ESTADO_HISTORIAL[orden.estado];
  return (accionEsperada && candidatos.find(a => a.accion === accionEsperada)) || candidatos[0] || null;
}

// ═══ HISTORIAL DEL CUPO — ver AXON Agenda Web · Guía UX-UI (Slot Lifecycle
// Inspector) y AXON Scheduling Lifecycle & Traceability (Slot Occupancy
// Traceability). No es un log nuevo aparte: cruza 3 cosas que ya existían
// por separado —
//   1. `ordenes` — canceladas/reagendadas quedan ahí con su estado, solo
//      invisibles en la grilla (ESTADOS_LIBERAN_CUPO las excluye).
//   2. `auditoria` — ya registra quién y cuándo; nunca se cruzaba por
//      cupo. Sigue el link `reagendadaHaciaId` vía eventoDeAuditoria().
//   3. `movimientos` — drag&drop muta fecha/hora/equipoId de la MISMA
//      orden a propósito (ver moverOrdenPorDrag), así que el cupo de
//      ORIGEN se queda sin ninguna orden que lo referencie. Sin este log
//      chico aparte, ese movimiento borra la historia del cupo de origen
//      sin dejar rastro.
// Devuelve una lista normalizada { tipo:"orden"|"movimiento", ... } para
// que TimelineCupo no tenga que conocer 2 modelos de datos distintos.
// LÍMITE HONESTO: sigue siendo Occupancy History derivada en memoria de
// sesión, no un Slot como Aggregate Root con su propio state machine
// (Available/Reserved/Occupied/Blocked/Freed) independiente del `estado`
// de la orden — decisión de modelo más grande, todavía no tomada (ver
// Arquitectura de Trazabilidad de Scheduling.docx, sección 19).
function historialDeCupo(ordenes, movimientos, auditoria, equipoId, fecha, hora, excluirId = null, bloqueos = []) {
  const deOrdenes = ordenes
    .filter(o => o.equipoId === equipoId && o.fecha === fecha && o.hora === hora && o.id !== excluirId)
    .map(o => {
      // Antes se mostraba el id crudo (SR-2026-M...) como "destino" — un
      // código que no dice nada al staff. El equipo/fecha/hora reales ya
      // existen en la orden nueva, solo había que ir a buscarlos.
      const destino = (o.estado === "reagendada" && o.reagendadaHaciaId) ? ordenes.find(x => x.id === o.reagendadaHaciaId) : null;
      return { tipo:"orden", key:`o-${o.id}`, orden:o, evento:eventoDeAuditoria(auditoria, o), destino };
    });
  const deMovimientos = movimientos
    .filter(m => m.equipoOrigenId === equipoId && m.fechaOrigen === fecha && m.horaOrigen === hora)
    .map(m => ({ tipo:"movimiento", key:`m-${m.id}`, mov:m }));
  // Bloqueos que cubren este cupo (activos o ya quitados): explican por qué un cupo estuvo/está bloqueado.
  const deBloqueos = bloqueos
    .filter(b => b.equipoId === equipoId && fecha >= b.fechaDesde && fecha <= b.fechaHasta && hora >= b.horaDesde && hora <= b.horaHasta)
    .map(b => ({ tipo:"bloqueo", key:`b-${b.id}`, bloqueo:b, lib:liberacionDeCupo(b, fecha, hora) }));
  return [...deBloqueos, ...deOrdenes, ...deMovimientos];
}

// Antes, una celda vacía se veía IGUAL tuviera o no historial — había que
// hacer clic a ciegas para enterarse. Este punto es la señal previa que
// pide la guía UX-UI (sección 16, "cupos vacíos con historia"): visible
// sin interactuar, no reemplaza el panel, solo avisa que existe.
const PuntoHistorial = ({ ordenes, movimientos, auditoria, equipoId, fecha, hora, bloqueos = [] }) =>
  historialDeCupo(ordenes, movimientos, auditoria, equipoId, fecha, hora, null, bloqueos).length > 0
    ? <span title="Este cupo tiene historial" style={{ position:"absolute", top:3, right:3, width:5, height:5, borderRadius:"50%", background:C.tea, boxShadow:"0 0 0 1.5px #fff", pointerEvents:"none" }}/>
    : null;

/* ═══════════════════════════ BLOQUEO DE CUPOS ═══════════════════════════
   Un bloqueo cubre un equipo, un rango de fechas y un rango de horas (todo el
   día = 00:00–23:59, un cupo = hora desde = hora hasta). Las citas que ya
   estaban dentro NO se cancelan ni se mueven solas: quedan marcadas para que
   el personal las mueva a mano (arrastrando o con Reagendar Cita). Lo que no
   se permite es meter citas nuevas, ni arrastrar ni reagendar hacia la zona
   bloqueada. Alineado con SlotBlocked / AvailabilityException de
   Arquitectura_Tecnica_Scheduling_Engine §6-7 (puerta: hoy vive en memoria). */
const TODAS_HORAS = generarBloques(6*60, 22*60, 20); // cubre bloques regulares + sobrecupos AM/PM
const ESTADOS_MOVER_A_MANO = ["agendado","confirmado"];
const FONDO_BLOQUEADO = "repeating-linear-gradient(135deg, #ECEFF1, #ECEFF1 6px, #E1E5E8 6px, #E1E5E8 12px)";
// Desbloqueo parcial: el bloqueo es UN registro que acumula `liberaciones` (rangos de
// fecha × hora que se quitaron). Un cupo sigue bloqueado mientras no caiga dentro de
// ninguna liberación; así el historial conserva quién bloqueó y quién liberó qué parte.
function liberacionDeCupo(b, fecha, hora) {
  return (b.liberaciones || []).find(l => fecha >= l.fechaDesde && fecha <= l.fechaHasta && hora >= l.horaDesde && hora <= l.horaHasta) || null;
}
function bloqueoDeCupo(bloqueos, equipoId, fecha, hora) {
  return bloqueos.find(b => b.activo && !liberacionDeCupo(b, fecha, hora) && b.equipoId === equipoId && fecha >= b.fechaDesde && fecha <= b.fechaHasta && hora >= b.horaDesde && hora <= b.horaHasta) || null;
}
function citasEnBloqueo(ordenes, b) {
  return ordenes.filter(o => o.equipoId === b.equipoId && o.fecha >= b.fechaDesde && o.fecha <= b.fechaHasta && o.hora >= b.horaDesde && o.hora <= b.horaHasta && !liberacionDeCupo(b, o.fecha, o.hora) && ESTADOS_MOVER_A_MANO.includes(o.estado));
}
function textoHorarioBloqueo(b) {
  if (b.horaDesde === "00:00" && b.horaHasta === "23:59") return "Todo el día";
  return b.horaDesde === b.horaHasta ? b.horaDesde : `${b.horaDesde} – ${b.horaHasta}`;
}
// Motivos típicos de bloqueo (lista cerrada, para poder contar después cuántos hubo por cada causa).
// "Otro" obliga a escribir el detalle; en los demás el detalle es opcional.
const MOTIVOS_BLOQUEO = ["Mantención del equipo","Falla del equipo","Falta de personal","Reunión de personal","Capacitación","Licencia o vacaciones del profesional","Feriado o día no laborable","Limpieza o desinfección","Corte de energía o de sistema","Otro"];
function diasDeBloqueo(b) {
  return Math.round((new Date(b.fechaHasta + "T00:00:00") - new Date(b.fechaDesde + "T00:00:00")) / 86400000) + 1;
}
function textoFechasBloqueo(b) {
  return b.fechaDesde === b.fechaHasta ? fmtCorta(b.fechaDesde) : `${fmtCorta(b.fechaDesde)} → ${fmtCorta(b.fechaHasta)}`;
}
// Capa sobre una celda VACÍA bloqueada (gris con rayas + candado). No intercepta clics:
// el clic de la celda abre el detalle del bloqueo.
const CapaBloqueo = ({ bloqueos, equipoId, fecha, hora, hover }) => {
  const b = bloqueoDeCupo(bloqueos, equipoId, fecha, hora);
  if (!b) return null;
  const rechazando = hover === `${equipoId}_${fecha}_${hora}`;
  return (
    <span title={`Cupo bloqueado — ${b.motivo}`} style={{ position:"absolute", inset:0, background: rechazando ? `${C.dan}22` : FONDO_BLOQUEADO, outline: rechazando ? `2px solid ${C.dan}` : "none", outlineOffset:-2, display:"flex", alignItems:"center", justifyContent:"center", gap:4, pointerEvents:"none" }}>
      <Lock size={11} color={rechazando ? C.dan : C.txl}/>{rechazando && <span style={{ fontSize:10, fontWeight:700, color:C.dan }}>Bloqueado</span>}
    </span>
  );
};

/* ═══════════════════════════ CELDA DE ORDEN — VISTA DÍA ═══════════════════════════
   Antes: una sola versión apilada (nombre / prestación / estado·edad·fono
   en 3 líneas), usada siempre — se veía bien con muchos equipos (columnas
   angostas) pero dejaba un montón de ancho sin usar cuando quedaba un
   único equipo visible (columna ~1fr, mucho más ancha que su contenido).
   `ancha` decide entre las 2: con pocos equipos visibles, ordena los
   mismos datos en fila — mismo criterio que la tabla de referencia real
   (Hora | Nombre | Edad | Tipo | Fono), aprovechando el espacio en vez de
   apilar texto en una columna angosta que ya no existe. */
const CeldaOrdenDia = ({ orden, bloqueada, ancha, arrastrando, onClick, dragProps, bordePosicion, minHeightAngosta }) => {
  const est = ESTADOS[orden.estado];
  const arrastrable = ["agendado","confirmado"].includes(orden.estado);
  const opacidad = arrastrando === orden.id ? 0.4 : 1;
  const bordeLado = bordePosicion === "top" ? { borderTop:`1px solid ${C.gridLine}` } : { borderBottom:`1px solid ${C.gridLine}` };
  const tituloArrastre = arrastrable ? "Arrastra para reagendar rápido a otro bloque" : undefined;

  if (ancha) {
    const edad = calcularEdad(orden.paciente.fechaNacimiento, orden.fecha);
    return (
      <button onClick={onClick} {...dragProps} title={tituloArrastre} style={{ border:"none", ...bordeLado, borderLeft:`3px solid ${est.color}`, background:bloqueada ? FONDO_BLOQUEADO : `${est.color}10`, outline:bloqueada ? `1.5px dashed ${C.dan}` : "none", outlineOffset:-2, cursor:arrastrable ? "grab" : "pointer", textAlign:"left", minHeight:40, padding:"6px 14px", display:"flex", alignItems:"center", gap:16, opacity:opacidad, width:"100%", boxSizing:"border-box" }}>
        {/* Ancho FIJO (no min/max) en cada columna salvo Prestación —
            antes con minWidth/maxWidth el ancho real dependía del largo
            del nombre de cada fila, y las columnas siguientes (edad,
            teléfono, estado) quedaban desalineadas fila a fila. */}
        <span style={{ fontSize:12, fontWeight:700, color:C.txt, width:190, flexShrink:0, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{nombreCompletoPaciente(orden.paciente)}</span>
        <span style={{ fontSize:11, color:C.txl, width:32, flexShrink:0 }}>{edad}a</span>
        <span style={{ fontSize:11, color:C.txm, flex:1, minWidth:0, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{orden.nombreFinal}</span>
        <span style={{ fontSize:11, color:C.txl, width:124, flexShrink:0 }}>{orden.paciente.telefono1 || "—"}</span>
        <span style={{ width:90, flexShrink:0 }}><Badge c={est.color} sm>{est.label}</Badge></span>
        <span style={{ width:14, flexShrink:0, display:"flex" }}>{orden.requiereConsentimiento && orden.consentimientoEstado !== "completado" && <ShieldCheck size={11} color={C.war}/>}</span>
        {bloqueada && <Lock size={11} color={C.dan} style={{ flexShrink:0 }}/>}
      </button>
    );
  }

  return (
    <button onClick={onClick} {...dragProps} title={tituloArrastre} style={{ border:"none", ...bordeLado, borderLeft:`3px solid ${est.color}`, background:bloqueada ? FONDO_BLOQUEADO : `${est.color}10`, outline:bloqueada ? `1.5px dashed ${C.dan}` : "none", outlineOffset:-2, cursor:arrastrable ? "grab" : "pointer", textAlign:"left", minHeight:minHeightAngosta, padding:"4px 6px", opacity:opacidad }}>
      <div style={{ fontSize:11.5, fontWeight:700, color:C.txt, whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis" }}>{nombreCompletoPaciente(orden.paciente)}</div>
      <div style={{ fontSize:10, color:C.txm, whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis", marginTop:1 }}>{orden.nombreFinal}</div>
      <div style={{ fontSize:10, color:C.txl, marginTop:2, display:"flex", alignItems:"center", gap:3, whiteSpace:"nowrap", overflow:"hidden" }}>
        <span style={{ fontWeight:700, color:est.color, flexShrink:0 }}>{est.label}</span>
        <span style={{ flexShrink:0 }}>· {calcularEdad(orden.paciente.fechaNacimiento, orden.fecha)}a</span>
        <span style={{ overflow:"hidden", textOverflow:"ellipsis" }}>· {orden.paciente.telefono1 || "—"}</span>
        {orden.requiereConsentimiento && orden.consentimientoEstado !== "completado" && <ShieldCheck size={10} color={C.war} style={{ flexShrink:0 }}/>}
        {bloqueada && <Lock size={10} color={C.dan} style={{ flexShrink:0 }}/>}
      </div>
    </button>
  );
};

/* ═══════════════════════════ CELDA DE ORDEN — VISTA SEMANA ═══════════════════════════
   Antes: solo nombre + estado (2 líneas). Semana no tiene el caso "ancha"
   de Día — son siempre 7 columnas de día fijas, nunca se libera tanto
   ancho como con un solo equipo — así que va directo a una versión
   compacta de 3 líneas (nombre / prestación / estado·edad), sin el
   teléfono que sí entra en Día. Un solo componente para las 3 ubicaciones
   (regular + sobrecupo AM/PM) en vez de repetirlo inline 3 veces. */
const CeldaOrdenSemana = ({ orden, bloqueada, arrastrando, onClick, dragProps, bordePosicion, minHeight }) => {
  const est = ESTADOS[orden.estado];
  const arrastrable = ["agendado","confirmado"].includes(orden.estado);
  const opacidad = arrastrando === orden.id ? 0.4 : 1;
  const bordeLado = bordePosicion === "top" ? { borderTop:`1px solid ${C.gridLine}` } : { borderBottom:`1px solid ${C.gridLine}` };
  return (
    <button onClick={onClick} {...dragProps} title={arrastrable ? "Arrastra para reagendar rápido a otro bloque" : undefined} style={{ border:"none", ...bordeLado, borderLeft:`3px solid ${est.color}`, background:bloqueada ? FONDO_BLOQUEADO : `${est.color}10`, outline:bloqueada ? `1.5px dashed ${C.dan}` : "none", outlineOffset:-2, cursor:arrastrable ? "grab" : "pointer", textAlign:"left", minHeight, padding:"4px 6px", opacity:opacidad }}>
      <div style={{ fontSize:11, fontWeight:700, color:C.txt, whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis" }}>{nombreCompletoPaciente(orden.paciente)}</div>
      <div style={{ fontSize:10, color:C.txm, whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis", marginTop:1 }}>{orden.nombreFinal}</div>
      <div style={{ display:"flex", alignItems:"center", gap:4, marginTop:1, whiteSpace:"nowrap", overflow:"hidden" }}>
        <span style={{ fontSize:10, fontWeight:700, color:est.color, flexShrink:0 }}>{est.label}</span>
        <span style={{ fontSize:10, color:C.txl, flexShrink:0 }}>· {calcularEdad(orden.paciente.fechaNacimiento, orden.fecha)}a</span>
        {orden.requiereConsentimiento && orden.consentimientoEstado !== "completado" && <ShieldCheck size={10} color={C.war} style={{ flexShrink:0 }}/>}
        {bloqueada && <Lock size={10} color={C.dan} style={{ flexShrink:0 }}/>}
      </div>
    </button>
  );
};

// Los 3 caminos posibles para activar la misma "En Espera" — mismo
// patrón que simularLlegadaTotem() del módulo operativo real, adaptado
// acá para que también se pueda simular el canal Portal Paciente.
const CANALES_LLEGADA = {
  recepcion: { label:"Recepción / mostrador", color:C.tea },
  totem:     { label:"Tótem de autoatención", color:C.amb },
  portal:    { label:"Portal Paciente",        color:C.pri },
};
const CONSENT_ESTADOS = {
  no_requiere:      { label:"No requiere",               color:C.txl },
  pendiente_fespa:  { label:"Pendiente firma paciente",   color:C.war },
  completado:       { label:"Firmado (FESpa+FESpro)",    color:C.suc },
};

function generarBloques(desdeMin, hastaMin, pasoMin) {
  const out = [];
  for (let m = desdeMin; m <= hastaMin; m += pasoMin) out.push(`${String(Math.floor(m/60)).padStart(2,"0")}:${String(m%60).padStart(2,"0")}`);
  return out;
}
// Horario regular: MOCK. Cada tenant define el suyo (aperturas, cierres y duración de bloque
// distintos) desde "Configurar agenda" cuando exista el motor; acá viven en un solo lugar.
// El CIERRE no es un cupo: el último cupo regular parte 20 min antes. Lo que sigue después
// (y antes de la apertura) se agrega como sobrecupo.
const HORARIO_APERTURA_MIN = 8*60, HORARIO_CIERRE_MIN = 20*60, PASO_BLOQUE_MIN = 20;
const BLOQUES = generarBloques(HORARIO_APERTURA_MIN, HORARIO_CIERRE_MIN - PASO_BLOQUE_MIN, PASO_BLOQUE_MIN); // 08:00 a 19:40 (cierre 20:00)
// Horas candidatas para SOBRECUPO — antes de abrir y después de cerrar.
// No es exclusivo de urgencias: también sirve para ambulatorio extra u
// hospitalizados en Imagenología. No son bloques fijos:
// se van agregando de a uno con el botón "+", igual que el sobrecupo de
// AtencionMedicaAgenda.jsx, pero acotado a estas dos franjas.
const HORAS_URGENCIA_AM = generarBloques(6*60, HORARIO_APERTURA_MIN - PASO_BLOQUE_MIN, PASO_BLOQUE_MIN).reverse(); // 07:40 → 06:00, de más cercana a más lejana
const HORAS_URGENCIA_PM = generarBloques(HORARIO_CIERRE_MIN, 22*60, PASO_BLOQUE_MIN); // 20:00 → 22:00 (el cierre es el primer sobrecupo posible)
// Antes era una lista fija de 15 fechas sueltas — no se podía navegar más
// allá. Ahora es un rango continuo (±45 días desde HOY, ~3 meses) generado
// con sumarDias() (function declarada más abajo, hoisted). Fuera de este
// rango la UI sigue siendo navegable, solo que no hay citas de muestra.
function generarRangoFechas(centroISO, diasAntes, diasDespues) {
  const dias = [];
  for (let i = -diasAntes; i <= diasDespues; i++) dias.push(sumarDias(centroISO, i));
  return dias;
}
// Antes eran fechas fijas ("2026-07-06"/"11:15"). A pedido explícito del
// usuario (comparó con Google Calendar): ahora se calculan de la fecha/hora
// real del navegador al cargar. Trade-off aceptado y confirmado: los datos
// de muestra (genOrdenes) usan HOY/AHORA para su narrativa, así que el
// conteo de "Atendidas hoy"/"En Espera"/etc. ya NO es fijo de sesión en
// sesión — cambia según cuándo se abra. Se recalcula una vez al cargar el
// módulo, no cada segundo (para eso ya existe useRelojEnVivo(), que es un
// reloj visual distinto, no toca la narrativa de los datos).
function hoyISO() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function ahoraHHMM() {
  const d = new Date();
  return `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
}
const HOY = hoyISO();
const DIAS = generarRangoFechas(HOY, 45, 45);
const AHORA = ahoraHHMM();

// Feriados Chile 2026 — verificados por búsqueda (15 nacionales + 2
// regionales = 17). Hardcodeados por ahora; candidato natural a una fuente
// dinámica real más adelante (ej. una API de feriados chilenos), no una
// dependencia urgente hoy.
const FERIADOS_CHILE_2026 = {
  "2026-01-01": "Año Nuevo",
  "2026-04-03": "Viernes Santo",
  "2026-04-04": "Sábado Santo",
  "2026-05-01": "Día Nacional del Trabajo",
  "2026-05-21": "Glorias Navales",
  "2026-06-07": "Asalto y Toma del Morro de Arica (regional)",
  "2026-06-29": "San Pedro y San Pablo",
  "2026-07-16": "Virgen del Carmen",
  "2026-08-15": "Asunción de la Virgen",
  "2026-08-20": "Natalicio de O'Higgins (regional)",
  "2026-09-18": "Fiestas Patrias",
  "2026-09-19": "Glorias del Ejército",
  "2026-10-12": "Encuentro de Dos Mundos",
  "2026-10-31": "Iglesias Evangélicas y Protestantes",
  "2026-11-01": "Todos los Santos",
  "2026-12-08": "Inmaculada Concepción",
  "2026-12-25": "Navidad",
};
function esFinDeSemana(fechaISO) {
  const dow = new Date(fechaISO + "T00:00:00").getDay();
  return dow === 0 || dow === 6;
}

// Médico SOLICITANTE (quien emite la orden) — puede ser de AXON (identidad +
// CUT propios, ya tiene cuenta en el sistema) o externo (no tiene CUT, se
// registra manualmente la primera vez que se le recibe una orden). No
// confundir con MEDICOS de Atención Médica — ese catálogo es de quienes
// ATIENDEN acá adentro; este es de quienes SOLICITAN el examen desde fuera
// o dentro de AXON, puede haber traslape de personas pero son roles
// distintos en este formulario.
const MEDICOS_REFERENTES_SEED = [
  { id:"mr1", origen:"axon",    cut:makeCUT(950), nombreCompleto:"Dr. Benjamín Araya Contreras", especialidad:"Medicina General" },
  { id:"mr2", origen:"axon",    cut:makeCUT(951), nombreCompleto:"Dra. Carolina Espinoza Reyes", especialidad:"Ginecología y Obstetricia" },
  { id:"mr3", origen:"axon",    cut:makeCUT(952), nombreCompleto:"Dr. Ignacio Fuentes Torres", especialidad:"Traumatología" },
  { id:"mr4", origen:"externo", cut:null, nombreCompleto:"Dr. Francisco Salinas Bravo", especialidad:"Traumatología" },
  { id:"mr5", origen:"externo", cut:null, nombreCompleto:"Dra. Valentina Correa Muñoz", especialidad:"Medicina General" },
  { id:"mr6", origen:"externo", cut:null, nombreCompleto:"Dr. Andrés Pizarro León", especialidad:"Medicina Interna" },
];

const USUARIOS_DEMO = [
  { cut:makeCUT(901), nombres:"Pamela", apellidoPaterno:"Iturra", apellidoMaterno:"Vásquez", rol:"ADMIN_STAFF", rolLabel:"Personal Administrativo" },
  { cut:makeCUT(940), nombres:"Marcelo", apellidoPaterno:"Reyes", apellidoMaterno:"Fuentealba", rol:"ADMIN_STAFF", rolLabel:"Admisión Imagenología" },
];
const nombreUsuario = (u) => `${u.nombres} ${u.apellidoPaterno} ${u.apellidoMaterno}`;

/* ═══════════════════════════ HELPERS ═══════════════════════════ */
function calcDV(rutBody) {
  let suma = 0, mult = 2;
  for (let i = rutBody.length - 1; i >= 0; i--) { suma += parseInt(rutBody[i], 10) * mult; mult = mult === 7 ? 2 : mult + 1; }
  const resto = 11 - (suma % 11);
  if (resto === 11) return "0";
  if (resto === 10) return "K";
  return String(resto);
}
function fakeRUT(seed) {
  const body = String(9000000 + (seed * 7919) % 8900000);
  return body.slice(0, 2) + "." + body.slice(2, 5) + "." + body.slice(5) + "-" + calcDV(body);
}
// Antes, el paciente semilla (genOrdenes) no tenía NINGÚN campo de
// teléfono — solo lo pacientes registrados a mano en el modal lo tenían.
// Por eso la grilla no tenía nada real que mostrar. Mismo criterio que
// fakeRUT(): determinístico a partir del seed, mismo patrón +56 9 que ya
// se usa en los placeholders del formulario.
function fakeTelefono(seed) {
  const n = String(20000000 + (seed * 6113) % 79999999);
  return `+56 9 ${n.slice(0, 4)} ${n.slice(4, 8)}`;
}
const fmtCorta = (iso) => new Date(iso + "T00:00:00").toLocaleDateString("es-CL", { weekday:"short", day:"2-digit", month:"short" });
const fmtLarga = (iso) => new Date(iso + "T00:00:00").toLocaleDateString("es-CL", { weekday:"long", day:"2-digit", month:"long", year:"numeric" });
function calcularEdad(fechaNacISO, fechaRefISO) {
  const [an, mn, dn] = fechaNacISO.split("-").map(Number);
  const [ar, mr, dr] = fechaRefISO.split("-").map(Number);
  let edad = ar - an;
  if (mr < mn || (mr === mn && dr < dn)) edad--;
  return edad;
}
const nombreCompletoPaciente = (p) => `${p.nombres} ${p.apellidoPaterno} ${p.apellidoMaterno}`;
function isoDate(anio, mes, dia) { return `${anio}-${String(mes).padStart(2,"0")}-${String(dia).padStart(2,"0")}`; }
function sumarDias(fechaISO, n) {
  const [a, m, d] = fechaISO.split("-").map(Number);
  const base = new Date(a, m - 1, d);
  base.setDate(base.getDate() + n);
  return isoDate(base.getFullYear(), base.getMonth() + 1, base.getDate());
}
function diaSemanaISO(anio, mes, dia) { const dow = new Date(anio, mes - 1, dia).getDay(); return dow === 0 ? 6 : dow - 1; }
function lunesDeSemana(fechaISO) {
  const [a, m, d] = fechaISO.split("-").map(Number);
  return sumarDias(fechaISO, -diaSemanaISO(a, m, d));
}
function diasEnMes(anio, mes) { return new Date(anio, mes, 0).getDate(); }
function generarMatrizMes(anio, mes) {
  const totalDias = diasEnMes(anio, mes);
  const offset = diaSemanaISO(anio, mes, 1);
  const anioPrev = mes === 1 ? anio - 1 : anio, mesPrev = mes === 1 ? 12 : mes - 1;
  const diasPrev = diasEnMes(anioPrev, mesPrev);
  const celdas = [];
  for (let i = offset - 1; i >= 0; i--) celdas.push({ fecha: isoDate(anioPrev, mesPrev, diasPrev - i), fueraDeMes:true });
  for (let dia = 1; dia <= totalDias; dia++) celdas.push({ fecha: isoDate(anio, mes, dia), fueraDeMes:false });
  const anioNext = mes === 12 ? anio + 1 : anio, mesNext = mes === 12 ? 1 : mes + 1;
  let diaNext = 1;
  while (celdas.length % 7 !== 0) { celdas.push({ fecha: isoDate(anioNext, mesNext, diaNext), fueraDeMes:true }); diaNext++; }
  return celdas;
}
const DIAS_SEMANA_LABEL = ["Lun","Mar","Mié","Jue","Vie","Sáb","Dom"];
const DIAS_SEMANA_COMPLETO = ["Lunes","Martes","Miércoles","Jueves","Viernes","Sábado","Domingo"];
function nombreDiaSemana(fechaISO) {
  const [a, m, d] = fechaISO.split("-").map(Number);
  return DIAS_SEMANA_COMPLETO[diaSemanaISO(a, m, d)];
}
// "los Lunes/Martes/Miércoles/Jueves/Viernes" ya son plurales invariables en
// español ("el lunes" / "los lunes") — pero Sábado/Domingo sí pluralizan
// (Sábados/Domingos). Solo para el título del panel de notas.
function diaSemanaPlural(dia) {
  return (dia === "Sábado" || dia === "Domingo") ? `${dia}s` : dia;
}

/* ═══════════════════════════ MINI CALENDARIO DEL SIDEBAR ═══════════════════════════
   Antes no existía — el nav de la izquierda solo tenía flechas ± un día/
   semana/mes y un <input type="date"> nativo, sin vista de conjunto del
   mes. Reusa generarMatrizMes(), el mismo generador que ya usaba la vista
   "Mes" grande, solo que en formato compacto para el sidebar. */
// Btn genérico (sz="sm") tiene padding pensado para texto+ícono — acá
// solo hay ícono, en una fila de 3 elementos dentro de una columna
// angosta. Este es más chico a propósito, para dejarle más ancho al
// <input type="date"> de al lado (antes se recortaba, sin espacio para
// mostrar la fecha completa).
const FlechaFecha = ({ onClick, Icono, title }) => (
  <button onClick={onClick} title={title} style={{ border:`1px solid ${C.brd}`, background:"#fff", borderRadius:6, padding:"5px 3px", cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0 }}>
    <Icono size={12} color={C.txl}/>
  </button>
);

// Reemplaza los 3 bloques que antes estaban duplicados (Mes/Semana/Día).
// No se estiliza el input nativo (su ícono/formato interno lo dibuja cada
// navegador distinto, sin control real por CSS) — se dibuja el texto+ícono
// a mano (centrado real, garantizado) y el input real queda invisible
// encima, mismo tamaño, para que el clic siga abriendo el calendario nativo.
function formatearValorFecha(tipo, valor) {
  if (!valor) return "—";
  if (tipo === "month") {
    const [anio] = valor.split("-");
    return anio; // el nombre del mes ya se muestra grande arriba (título NOMBRES_MES)
  }
  const [anio, mes, dia] = valor.split("-");
  return `${dia}-${mes}-${anio}`;
}
const NavegadorFecha = ({ tipo, valor, onCambiar, onAnterior, onSiguiente, tituloAnterior, tituloSiguiente, title }) => (
  <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", gap:4, marginTop:6 }}>
    <FlechaFecha onClick={onAnterior} Icono={ChevronLeft} title={tituloAnterior}/>
    <div title={title} style={{ position:"relative", flex:1, display:"flex", alignItems:"center", justifyContent:"center", gap:6, padding:"6px 4px", fontSize:11, fontWeight:600, color:C.txt, border:`1px solid ${C.brd}`, borderRadius:7, background:"#fff", boxSizing:"border-box" }}>
      <span>{formatearValorFecha(tipo, valor)}</span>
      <Calendar size={12} color={C.txl}/>
      <input type={tipo} value={valor} onChange={onCambiar} style={{ position:"absolute", inset:0, width:"100%", height:"100%", opacity:0, cursor:"pointer", border:"none", padding:0, margin:0, boxSizing:"border-box" }}/>
    </div>
    <FlechaFecha onClick={onSiguiente} Icono={ChevronRight} title={tituloSiguiente}/>
  </div>
);

const DIAS_MINI = ["L","M","X","J","V","S","D"];
const MiniCalendario = ({ anioCtx, mesCtx, fechaSel, onSeleccionar, onCambiarMes }) => {
  const celdas = generarMatrizMes(anioCtx, mesCtx);
  return (
    <div style={{ marginTop:10 }}>
      <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:6 }}>
        <button onClick={() => onCambiarMes(-1)} title="Mes anterior" style={{ border:"none", background:"none", cursor:"pointer", padding:2, display:"flex" }}><ChevronLeft size={13} color={C.txl}/></button>
        <button onClick={() => onSeleccionar(HOY)} style={{ border:"none", background:`${C.pri}12`, borderRadius:6, cursor:"pointer", fontSize:10, fontWeight:700, color:C.pri, padding:"2px 8px" }}>HOY</button>
        <button onClick={() => onCambiarMes(1)} title="Mes siguiente" style={{ border:"none", background:"none", cursor:"pointer", padding:2, display:"flex" }}><ChevronRight size={13} color={C.txl}/></button>
      </div>
      <div style={{ display:"grid", gridTemplateColumns:"repeat(7,1fr)", gap:1 }}>
        {DIAS_MINI.map(d => <div key={d} style={{ fontSize:10, textAlign:"center", color:C.txl, fontWeight:700, paddingBottom:3 }}>{d}</div>)}
        {celdas.map(celda => {
          const esHoy = celda.fecha === HOY, esSel = celda.fecha === fechaSel;
          return (
            <button key={celda.fecha} onClick={() => onSeleccionar(celda.fecha)} disabled={celda.fueraDeMes} style={{
              aspectRatio:"1", border:"none", borderRadius:5, cursor:celda.fueraDeMes ? "default" : "pointer",
              fontSize:10, fontWeight: esSel || esHoy ? 700 : 500,
              background: esSel ? C.pri : (esHoy ? `${C.pri}18` : "transparent"),
              color: esSel ? "#fff" : (celda.fueraDeMes ? C.txl : C.txt),
              opacity: celda.fueraDeMes ? 0.4 : 1,
            }}>{Number(celda.fecha.slice(8,10))}</button>
          );
        })}
      </div>
    </div>
  );
};

/* ═══════════════════════════ MOCK: genOrdenes (solo estados de agenda) ═══════════════════════════ */
function genOrdenes() {
  const rows = [];
  let seed = 0, n = 0;
  DIAS.forEach((fecha) => {
    EQUIPOS.forEach((equipo) => {
      BLOQUES.forEach((hora) => {
        seed += 7;
        const libre = (seed % 100) >= 55;
        if (libre) return;
        n++;

        const prestacionesModalidad = CATALOGO_PRESTACIONES.filter(p => p.modalidad === equipo.modalidad);
        const prest = prestacionesModalidad[(seed * 11) % prestacionesModalidad.length] || CATALOGO_PRESTACIONES[0];
        const anioNac = 2026 - (18 + (seed % 68));
        const mesNac = 1 + (seed % 12);
        const diaNac = 1 + (seed % 28);
        const fechaNacimiento = isoDate(anioNac, mesNac, diaNac);
        const edad = calcularEdad(fechaNacimiento, fecha);

        let lateralidadSel = null;
        if (prest.lateralidad) lateralidadSel = ["Derecha","Izquierda","Ambas"][seed % 3];
        const nombreFinal = lateralidadSel ? construirNombreEspecifico(prest.nombre, lateralidadSel) : prest.nombre;

        let estado, canalLlegada = null;
        if (fecha < HOY) { const r = seed % 20; estado = r === 0 ? "no_show" : r === 1 ? "cancelado" : "atendido"; }
        else if (fecha > HOY) { estado = (seed % 9 === 0) ? "agendado" : "confirmado"; }
        else if (seed % 15 === 0) { estado = "no_show"; }
        else if (hora < AHORA) { estado = "atendido"; }
        else if (hora === "11:00") { estado = "en_atencion"; canalLlegada = "recepcion"; }
        else if (seed % 6 === 0) { estado = "en_espera"; canalLlegada = ["recepcion","totem","portal"][seed % 3]; }
        else { estado = (seed % 9 === 0) ? "agendado" : "confirmado"; }

        const consent = calcularConsentimiento(equipo.modalidad, prest.contraste);
        const consentimientoEstado = !consent.requiere ? "no_requiere" : (fecha < HOY || estado === "en_espera" || estado === "en_atencion" || estado === "atendido" ? "completado" : "pendiente_fespa");

        rows.push({
          id: `SR-2026-${String(n).padStart(6, "0")}`,
          acc: null, ot: null,
          equipoId: equipo.id, modalidad: equipo.modalidad,
          fecha, hora,
          paciente: {
            cup: makeCUP(2000 + n), rut: fakeRUT(seed),
            nombres: NOMBRES[seed % NOMBRES.length],
            apellidoPaterno: APELLIDOS[(seed * 2) % APELLIDOS.length],
            apellidoMaterno: APELLIDOS[(seed * 5) % APELLIDOS.length],
            fechaNacimiento, telefono1: fakeTelefono(seed),
          },
          prestacion: prest, lateralidadSel, nombreFinal,
          requiereConsentimiento: consent.requiere, plantillaConsentimiento: consent.plantilla, consentimientoEstado,
          requiereCreatinina: consent.requiere && !!prest.contraste && edad >= 60,
          creatininaAdjunta: null, creatininaExpres: false,
          diagnosticos: [],
          ordenMedica: { adjunta: seed % 3 !== 0, medicoSolicitante: `Dr. ${APELLIDOS[(seed*3)%APELLIDOS.length]}`, medicoSolicitanteId: null, fechaEmision: sumarDias(fecha, -(1 + seed % 5)), diagnosticoSospecha: "Ver adjunto" },
          adjuntosPrevios: { archivo: null, link: null }, notasCita: [],
          canal: (seed % 5 === 0) ? "Portal Paciente" : (seed % 5 === 1) ? "Interconsulta" : "Presencial",
          canalLlegada,
          estado,
          // Trazabilidad de reagendamiento — antes faltaba acá (sí existía en
          // AtencionMedicaAgenda.jsx). Sin esto, historialDeCupo() no puede
          // mostrar "reagendado hacia X" cuando arma el Historial del Cupo.
          reagendadaHaciaId: null, reagendadaDesdeId: null, estadoAntesDeReagendar: null,
          // Quién agendó esta orden — antes NO existía en ningún lado (ni acá
          // ni en auditoria, que nunca corre para datos semilla). Sin esto,
          // "qué administrativa agenda más" no se puede responder ni para el
          // mock. Determinístico igual que fakeRUT()/fakeTelefono() — no es
          // la agenda real de nadie, pero deja el campo listo para cuando el
          // dashboard real (Gestión/Alta Calidad) lo necesite.
          agendadoPorCUT: USUARIOS_DEMO[seed % USUARIOS_DEMO.length].cut,
          agendadoPorNombre: nombreUsuario(USUARIOS_DEMO[seed % USUARIOS_DEMO.length]),
          // Quién inició la reserva de este paciente, propagado a través de
          // toda la cadena de reagendamientos (ver guardarNuevaSolicitud).
          // En semilla no hay cadena todavía, así que es igual a agendadoPor.
          agendadoOriginalmentePorCUT: USUARIOS_DEMO[seed % USUARIOS_DEMO.length].cut,
          agendadoOriginalmentePorNombre: nombreUsuario(USUARIOS_DEMO[seed % USUARIOS_DEMO.length]),
        });
      });
    });
  });
  return rows;
}

/* ═══════════════════════════ BUSCADOR DE PACIENTES (CUP/RUT/nombre) ═══════════════════════════ */
function buscarPacientes(pacientes, query) {
  if (!query || query.trim().length < 2) return [];
  const q = query.toLowerCase();
  return pacientes.filter(p =>
    p.cup.toLowerCase().includes(q) || p.rut.toLowerCase().includes(q) ||
    p.nombres.toLowerCase().includes(q) || p.apellidoPaterno.toLowerCase().includes(q) || p.apellidoMaterno.toLowerCase().includes(q)
  ).slice(0, 6);
}
const PacientePicker = ({ pacientes, onSeleccionar }) => {
  const [q, setQ] = useState("");
  const [abierto, setAbierto] = useState(false);
  const resultados = useMemo(() => buscarPacientes(pacientes, q), [pacientes, q]);
  return (
    <div style={{ position:"relative" }}>
      <input
        value={q} onChange={e => { setQ(e.target.value); setAbierto(true); }} onFocus={() => setAbierto(true)}
        onBlur={() => setTimeout(() => setAbierto(false), 150)}
        placeholder="Buscar por CUP, RUT o nombre..."
        style={{ width:"100%", padding:"8px 10px", fontSize:12, border:`1px solid ${C.brd}`, borderRadius:7, boxSizing:"border-box" }}
      />
      {abierto && resultados.length > 0 && (
        <div style={{ position:"absolute", top:"100%", left:0, right:0, background:"#fff", border:`1px solid ${C.brd}`, borderRadius:7, marginTop:3, boxShadow:"0 6px 16px rgba(0,0,0,0.12)", zIndex:20, maxHeight:200, overflowY:"auto" }}>
          {resultados.map(p => (
            <button key={p.cup} onMouseDown={() => { onSeleccionar(p); setQ(""); setAbierto(false); }} style={{ display:"flex", flexDirection:"column", width:"100%", padding:"7px 10px", background:"none", border:"none", borderBottom:`1px solid ${C.brd}`, cursor:"pointer", textAlign:"left", gap:2 }}>
              <span style={{ fontSize:11, fontWeight:600, color:C.txt }}>{nombreCompletoPaciente(p)} · {calcularEdad(p.fechaNacimiento, HOY)} años</span>
              <span style={{ display:"flex", gap:8 }}><CUPPill cup={p.cup}/><span style={{ fontSize:10, color:C.txl }}>{p.rut}</span></span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
};

/* ═══════════════════════════ BUSCADOR DE MÉDICO SOLICITANTE ═══════════════════════════ */
function buscarMedicos(medicos, query) {
  if (!query || query.trim().length < 1) return [];
  const q = query.toLowerCase();
  return medicos.filter(m => m.nombreCompleto.toLowerCase().includes(q) || (m.especialidad || "").toLowerCase().includes(q)).slice(0, 7);
}
const MedicoPicker = ({ medicos, valor, onSeleccionar, onRegistrarNuevo }) => {
  const [q, setQ] = useState(valor || "");
  const [abierto, setAbierto] = useState(false);
  const resultados = useMemo(() => buscarMedicos(medicos, q), [medicos, q]);
  useEffect(() => { setQ(valor || ""); }, [valor]);
  return (
    <div style={{ position:"relative" }}>
      <input
        value={q} onChange={e => { setQ(e.target.value); setAbierto(true); onSeleccionar(e.target.value, null); }} onFocus={() => setAbierto(true)}
        onBlur={() => setTimeout(() => setAbierto(false), 150)}
        placeholder="Buscar médico solicitante por nombre..."
        style={{ width:"100%", padding:"7px 8px", fontSize:12, border:`1px solid ${C.brd}`, borderRadius:7, boxSizing:"border-box" }}
      />
      {abierto && (
        <div style={{ position:"absolute", top:"100%", left:0, right:0, background:"#fff", border:`1px solid ${C.brd}`, borderRadius:7, marginTop:3, boxShadow:"0 6px 16px rgba(0,0,0,0.12)", zIndex:20, maxHeight:220, overflowY:"auto" }}>
          {resultados.map(m => (
            <button key={m.id} onMouseDown={() => { onSeleccionar(m.nombreCompleto, m); setQ(m.nombreCompleto); setAbierto(false); }} style={{ display:"flex", justifyContent:"space-between", alignItems:"center", width:"100%", padding:"7px 10px", background:"none", border:"none", borderBottom:`1px solid ${C.brd}`, cursor:"pointer", textAlign:"left", gap:8 }}>
              <span>
                <div style={{ fontSize:11, fontWeight:600, color:C.txt }}>{m.nombreCompleto}</div>
                <div style={{ fontSize:10, color:C.txl }}>{m.especialidad}</div>
              </span>
              {m.origen === "axon" ? <ACCPill acc={m.cut}/> : <Badge c={C.txl} sm>Externo</Badge>}
            </button>
          ))}
          {resultados.length === 0 && q.trim().length > 0 && (
            <div style={{ padding:"7px 10px", fontSize:10.5, color:C.txl }}>Sin coincidencias para "{q}".</div>
          )}
          <button onMouseDown={() => { onRegistrarNuevo(q); setAbierto(false); }} style={{ display:"flex", alignItems:"center", gap:6, width:"100%", padding:"8px 10px", background:C.bg, border:"none", cursor:"pointer", textAlign:"left" }}>
            <Plus size={11} color={C.pri}/><span style={{ fontSize:10.5, color:C.pri, fontWeight:600 }}>Registrar médico{q.trim() ? ` "${q.trim()}"` : " nuevo"}</span>
          </button>
        </div>
      )}
    </div>
  );
};
const MiniRegistroMedico = ({ nombreInicial, onGuardar, onCerrar }) => {
  const dlg = useDialogo(onCerrar);
  const partes = (nombreInicial || "").replace(/^(Dr\.|Dra\.)\s*/i, "").split(" ");
  const [tratamiento, setTratamiento] = useState("Dr.");
  const [nombres, setNombres] = useState(partes[0] || "");
  const [apellidoPaterno, setApellidoPaterno] = useState(partes[1] || "");
  const [apellidoMaterno, setApellidoMaterno] = useState(partes[2] || "");
  const [rut, setRut] = useState("");
  const [especialidad, setEspecialidad] = useState("");
  return (
    <div {...dlg} style={{ position:"fixed", inset:0, background:"rgba(15,23,32,0.5)", display:"flex", alignItems:"center", justifyContent:"center", zIndex:70, padding:20 }}>
      <div style={{ background:"#fff", borderRadius:12, width:400, maxWidth:"100%", padding:20, boxSizing:"border-box" }}>
        <div style={{ fontSize:14, fontWeight:700, color:C.txt, marginBottom:12 }}>Registrar médico externo</div>
        <div style={{ display:"grid", gridTemplateColumns:"70px 1fr", gap:8, marginBottom:8 }}>
          <select value={tratamiento} onChange={e=>setTratamiento(e.target.value)} style={{ padding:"7px 6px", fontSize:12, border:`1px solid ${C.brd}`, borderRadius:7 }}>
            <option>Dr.</option><option>Dra.</option>
          </select>
          <input value={nombres} onChange={e=>setNombres(e.target.value)} placeholder="Nombres" style={{ padding:"7px 8px", fontSize:12, border:`1px solid ${C.brd}`, borderRadius:7 }}/>
        </div>
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:8, marginBottom:8 }}>
          <input value={apellidoPaterno} onChange={e=>setApellidoPaterno(e.target.value)} placeholder="Ap. Paterno" style={{ padding:"7px 8px", fontSize:12, border:`1px solid ${C.brd}`, borderRadius:7 }}/>
          <input value={apellidoMaterno} onChange={e=>setApellidoMaterno(e.target.value)} placeholder="Ap. Materno" style={{ padding:"7px 8px", fontSize:12, border:`1px solid ${C.brd}`, borderRadius:7 }}/>
        </div>
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:8, marginBottom:14 }}>
          <input value={rut} onChange={e=>setRut(e.target.value)} placeholder="RUT" style={{ padding:"7px 8px", fontSize:12, border:`1px solid ${C.brd}`, borderRadius:7 }}/>
          <input value={especialidad} onChange={e=>setEspecialidad(e.target.value)} placeholder="Especialidad (no excluyente)" style={{ padding:"7px 8px", fontSize:12, border:`1px solid ${C.brd}`, borderRadius:7 }}/>
        </div>
        <div style={{ display:"flex", gap:8, justifyContent:"flex-end" }}>
          <Btn v="ghost" onClick={onCerrar}>Cancelar</Btn>
          <Btn v="success" icon={CheckCircle2} onClick={() => {
            if (!nombres.trim() || !apellidoPaterno.trim()) { return; }
            onGuardar({ tratamiento, nombres, apellidoPaterno, apellidoMaterno, rut, especialidad });
          }}>Guardar Médico</Btn>
        </div>
      </div>
    </div>
  );
};

/* ═══════════════════════════ MOTIVO OBLIGATORIO AL CANCELAR ═══════════════════════════
   Decisión explícita del usuario: motivo OBLIGATORIO al cancelar, NADA al
   reagendar (ni el botón formal ni drag&drop) — cancelar es siempre un
   clic deliberado, no hay velocidad que proteger. Este gate es solo para
   cancelación iniciada por STAFF desde este panel. Si en algún momento se
   conecta un flujo de cancelación iniciada por el PACIENTE (Portal
   Paciente), ese flujo NO debe pedir motivo — decisión explícita aparte,
   no aplicar este mismo componente ahí sin revisar. */
const ModalMotivoCancelacion = ({ paciente, onConfirmar, onCerrar }) => {
  const dlg = useDialogo(onCerrar);
  const [motivo, setMotivo] = useState("");
  return (
    <div {...dlg} style={{ position:"fixed", inset:0, background:"rgba(15,23,32,0.5)", display:"flex", alignItems:"center", justifyContent:"center", zIndex:70, padding:20 }}>
      <div style={{ background:"#fff", borderRadius:12, width:400, maxWidth:"100%", padding:20, boxSizing:"border-box" }}>
        <div style={{ fontSize:14, fontWeight:700, color:C.txt, marginBottom:4 }}>Cancelar solicitud</div>
        <div style={{ fontSize:11, color:C.txl, marginBottom:12 }}>{paciente} — el motivo queda en el Historial de este Cupo.</div>
        <textarea autoFocus value={motivo} onChange={e => setMotivo(e.target.value)} placeholder="Motivo de la cancelación (obligatorio)..." rows={3} style={{ width:"100%", padding:"8px 10px", fontSize:12, border:`1px solid ${C.brd}`, borderRadius:7, boxSizing:"border-box", fontFamily:"inherit", resize:"vertical" }}/>
        <div style={{ display:"flex", gap:8, justifyContent:"flex-end", marginTop:14 }}>
          <Btn v="ghost" onClick={onCerrar}>Volver</Btn>
          <Btn v="danger" icon={AlertTriangle} dis={!motivo.trim()} onClick={() => onConfirmar(motivo.trim())}>Confirmar cancelación</Btn>
        </div>
      </div>
    </div>
  );
};

/* ═══════════════════════════ CAPTURA POR CÁMARA ═══════════════════════════
   Distinto de "Escanear" (driver TWAIN/WIA de un escáner de oficina, que un
   componente en el navegador NO puede controlar). Una cámara — webcam de PC
   o cámara de celular — SÍ es accesible desde JS estándar del navegador vía
   getUserMedia(), sin backend ni API de terceros. Por eso esto es real y
   funciona; "Escanear" (hardware dedicado) queda aparte como puerta
   etiquetada. Requiere permiso del navegador y contexto seguro (https). */
const CapturaCamara = ({ onCapturar, onCerrar }) => {
  const dlg = useDialogo(onCerrar);
  const videoRef = useRef(null);
  const streamRef = useRef(null);
  const [foto, setFoto] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    let activo = true;
    navigator.mediaDevices?.getUserMedia?.({ video: { facingMode:"environment" } })
      .then(stream => {
        if (!activo) { stream.getTracks().forEach(t => t.stop()); return; }
        streamRef.current = stream;
        if (videoRef.current) videoRef.current.srcObject = stream;
      })
      .catch(() => setError("No se pudo acceder a la cámara — revisa los permisos del navegador."));
    return () => { activo = false; streamRef.current?.getTracks().forEach(t => t.stop()); };
  }, []);

  const capturar = () => {
    const video = videoRef.current;
    if (!video) return;
    const canvas = document.createElement("canvas");
    canvas.width = video.videoWidth; canvas.height = video.videoHeight;
    canvas.getContext("2d").drawImage(video, 0, 0);
    setFoto(canvas.toDataURL("image/jpeg", 0.85));
  };

  return (
    <div {...dlg} style={{ position:"fixed", inset:0, background:"rgba(15,23,32,0.6)", display:"flex", alignItems:"center", justifyContent:"center", zIndex:80, padding:20 }}>
      <div style={{ background:"#fff", borderRadius:12, width:440, maxWidth:"100%", padding:16, boxSizing:"border-box" }}>
        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:10 }}>
          <div style={{ fontSize:13, fontWeight:700, color:C.txt }}>Tomar foto del documento</div>
          <button onClick={onCerrar} style={{ background:"none", border:"none", cursor:"pointer" }}><X size={16} color={C.txl}/></button>
        </div>
        {error ? (
          <div style={{ padding:16, fontSize:11, color:C.dan, background:`${C.dan}10`, borderRadius:8 }}>{error}</div>
        ) : foto ? (
          <img src={foto} alt="Captura" style={{ width:"100%", borderRadius:8, marginBottom:10 }}/>
        ) : (
          <video ref={videoRef} autoPlay playsInline muted style={{ width:"100%", borderRadius:8, background:"#000", marginBottom:10 }}/>
        )}
        <div style={{ display:"flex", gap:8, justifyContent:"flex-end", marginTop:10 }}>
          <Btn v="ghost" onClick={onCerrar}>Cancelar</Btn>
          {foto ? (
            <>
              <Btn v="outline" icon={RefreshCw} onClick={() => setFoto(null)}>Repetir</Btn>
              <Btn v="success" icon={CheckCircle2} onClick={() => onCapturar(foto)}>Usar esta foto</Btn>
            </>
          ) : !error && (
            <Btn v="primary" icon={Camera} onClick={capturar}>Capturar</Btn>
          )}
        </div>
      </div>
    </div>
  );
};

/* ═══════════════════════════ SELECTOR CIE CONTEXTUAL — multi-select ═══════════════════════════ */
const SelectorCIE = ({ modalidad, especialidad, seleccionados, onCambiar }) => {
  const [norma, setNorma] = useState("CIE-10");
  const [buscando, setBuscando] = useState(false);
  const [q, setQ] = useState("");
  const sugeridos = useMemo(() => sugerenciasCIE(modalidad, especialidad, norma), [modalidad, especialidad, norma]);
  const catalogoNorma = norma === "CIE-11" ? CATALOGO_SEMILLA_CIE11 : CATALOGO_SEMILLA_CIE10;
  const resultadosBusqueda = useMemo(() => buscarEnCatalogo(catalogoNorma, q), [catalogoNorma, q]);
  const agregar = (texto) => {
    if (!seleccionados.some(s => s === texto)) onCambiar([...seleccionados, texto]);
  };
  const quitar = (texto) => onCambiar(seleccionados.filter(s => s !== texto));
  return (
    <div>
      <div style={{ display:"flex", gap:6, marginBottom:8 }}>
        {["CIE-10","CIE-11"].map(n => (
          <button key={n} onClick={() => setNorma(n)} style={{ fontSize:11, padding:"4px 10px", borderRadius:7, border:`1px solid ${norma===n?C.pri:C.brd}`, background:norma===n?`${C.pri}12`:"#fff", color:norma===n?C.pri:C.txm, cursor:"pointer", fontWeight:600 }}>{n}</button>
        ))}
        <span style={{ fontSize:10, color:C.txl, alignSelf:"center", marginLeft:4 }}>Sugerido para: {especialidad || "General"}</span>
      </div>
      {!buscando ? (
        <div style={{ display:"flex", flexDirection:"column", gap:4 }}>
          {sugeridos.map(op => (
            <button key={op} onClick={() => agregar(op)} style={{ textAlign:"left", fontSize:11, padding:"7px 9px", borderRadius:7, border:`1px solid ${C.brd}`, background:seleccionados.includes(op)?`${C.suc}10`:"#fff", color:C.txt, cursor:"pointer" }}>{op}</button>
          ))}
          <button onClick={() => setBuscando(true)} style={{ textAlign:"left", fontSize:11, padding:"7px 9px", borderRadius:7, border:`1px dashed ${C.brd}`, background:"#fff", color:C.txl, cursor:"pointer" }}>🔎 Otro (búsqueda en catálogo completo)</button>
        </div>
      ) : (
        <div>
          <input autoFocus value={q} onChange={e=>setQ(e.target.value)} placeholder="Buscar por código o palabra clave..." style={{ width:"100%", padding:"7px 9px", fontSize:12, border:`1px solid ${C.brd}`, borderRadius:7, boxSizing:"border-box", marginBottom:6 }}/>
          <div style={{ fontSize:10, color:C.txl, marginBottom:5 }}>Catálogo de muestra {norma} ({catalogoNorma.length} códigos) — lo reemplaza el servicio terminológico de MAIN.</div>
          {q.trim().length >= 2 && resultadosBusqueda.length === 0 && <div style={{ fontSize:10.5, color:C.txl, fontStyle:"italic", marginBottom:4 }}>Sin resultados en el catálogo de muestra {norma}.</div>}
          {resultadosBusqueda.map(r => (
            <button key={r.codigo} onClick={() => agregar(`${r.codigo} - ${r.label}`)} style={{ display:"block", width:"100%", textAlign:"left", fontSize:11, padding:"6px 9px", borderRadius:7, border:`1px solid ${C.brd}`, background:"#fff", marginBottom:3, cursor:"pointer" }}>
            <span style={{ fontFamily:"monospace", fontWeight:700, color:C.pri }}>{r.codigo}</span> · {r.label}
            </button>
          ))}
          <button onClick={() => { setBuscando(false); setQ(""); }} style={{ fontSize:10, color:C.txl, background:"none", border:"none", cursor:"pointer", marginTop:4 }}>← Volver a sugeridos</button>
        </div>
      )}
      {seleccionados.length > 0 && (
        <div style={{ display:"flex", gap:6, flexWrap:"wrap", marginTop:9 }}>
          {seleccionados.map(s => (
            <span key={s} style={{ fontSize:10, padding:"3px 9px", borderRadius:12, background:`${C.pri}12`, color:C.pri, display:"flex", alignItems:"center", gap:5 }}>
              {s.split(" - ")[0]}
              <button onClick={() => quitar(s)} style={{ background:"none", border:"none", cursor:"pointer", padding:0, display:"flex" }}><X size={10} color={C.pri}/></button>
            </span>
          ))}
        </div>
      )}
    </div>
  );
};

/* ═══════════════════════════ TIMELINE DE HISTORIAL DEL CUPO ═══════════════════════════
   Compartido entre PanelDetalle (cupo ocupado, se excluye la orden actual) y
   PanelCupoVacio (cupo vacío, se muestran todas). Cada entrada es "orden"
   (una orden completa que tuvo este cupo) o "movimiento" (un drag&drop que
   se originó acá) — ver historialDeCupo(). Actor/hora se muestran cuando
   existen; si no (dato semilla, nunca pasó por auditoria), se avisa
   explícitamente en vez de mostrar algo a medias — mismo criterio que la
   guía UX-UI sección 21 ("Historial parcial o datos legados"): no
   presentar ausencia de dato como ausencia de actividad, y no inventar. */
const TimelineCupo = ({ historial }) => {
  if (historial.length === 0) {
    return <div style={{ fontSize:10.5, color:C.txl, fontStyle:"italic" }}>Sin ocupaciones anteriores registradas para este cupo.</div>;
  }
  return (
    <div>
      {historial.map((item, idx) => {
        const esUltimo = idx === historial.length - 1;
        const filaStyle = { display:"flex", gap:8, paddingBottom:9, marginBottom:9, borderBottom: esUltimo ? "none" : `1px solid ${C.brd}` };

        if (item.tipo === "bloqueo") {
          const b = item.bloqueo;
          return (
            <div key={item.key} style={filaStyle}>
              <div style={{ width:8, height:8, borderRadius:"50%", background:C.txl, marginTop:4, flexShrink:0 }}/>
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ display:"flex", gap:6, alignItems:"center", flexWrap:"wrap" }}>
                  <Badge c={C.txl} sm>{item.lib ? "Bloqueo quitado" : "Bloqueado"}</Badge>
                  <span style={{ fontSize:10, color:C.txl }}>{textoFechasBloqueo(b)} · {textoHorarioBloqueo(b)}</span>
                </div>
                <div style={{ fontSize:10.5, color:C.txm, marginTop:3, fontStyle:"italic" }}>"{b.motivo}"</div>
                <div style={{ fontSize:10, color:C.txl, marginTop:3 }}>Bloqueó: {b.actorNombre}{b.actorRol ? ` · ${b.actorRol}` : ""} · {b.ts}</div>
                {item.lib && <div style={{ fontSize:10, color:C.txl, marginTop:2 }}>Desbloqueó: {item.lib.por}{item.lib.rol ? ` · ${item.lib.rol}` : ""} · {item.lib.ts}</div>}
              </div>
            </div>
          );
        }
        if (item.tipo === "movimiento") {
          const m = item.mov;
          const eqDestino = EQUIPOS.find(e => e.id === m.equipoDestinoId);
          return (
            <div key={item.key} style={filaStyle}>
              <div style={{ width:8, height:8, borderRadius:"50%", background:C.amb, marginTop:4, flexShrink:0 }}/>
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ fontSize:11, fontWeight:600, color:C.txt }}>{nombreCompletoPaciente(m.pacienteSnapshot)}</div>
                <div style={{ display:"flex", gap:6, alignItems:"center", marginTop:3, flexWrap:"wrap" }}>
                  <Badge c={C.amb} sm>{m.via === "modificar" ? "Movido (Modificar Cita)" : m.via === "mover" ? "Movido (Mover cita)" : "Movido (drag&drop)"}</Badge>
                  <span style={{ fontSize:10, color:C.txl }}>→ {eqDestino?.nombre || m.equipoDestinoId} · {fmtCorta(m.fechaDestino)} {m.horaDestino}</span>
                </div>
                <div style={{ fontSize:10, color:C.txl, marginTop:2 }}>{m.nombreFinalSnapshot}</div>
                <div style={{ fontSize:10, color:C.txl, marginTop:3 }}>{m.ts} · {m.actorNombre}{m.actorRol ? ` · ${m.actorRol}` : ""}</div>
              </div>
            </div>
          );
        }

        const o = item.orden, evento = item.evento;
        const est = ESTADOS[o.estado];
        return (
          <div key={item.key} style={filaStyle}>
            <div style={{ width:8, height:8, borderRadius:"50%", background:est.color, marginTop:4, flexShrink:0 }}/>
            <div style={{ flex:1, minWidth:0 }}>
              <div style={{ fontSize:11, fontWeight:600, color:C.txt }}>{nombreCompletoPaciente(o.paciente)}</div>
              <div style={{ display:"flex", gap:6, alignItems:"center", marginTop:3, flexWrap:"wrap" }}>
                <Badge c={est.color} sm>{est.label}</Badge>
                {o.estadoAntesDeReagendar && <span style={{ fontSize:10, color:C.txl }}>(antes: {ESTADOS[o.estadoAntesDeReagendar].label})</span>}
                {o.estado === "reagendada" && o.reagendadaHaciaId && (
                  <span style={{ fontSize:10, color:C.tea }}>
                    → {item.destino ? `${EQUIPOS.find(e => e.id === item.destino.equipoId)?.nombre || item.destino.equipoId} · ${fmtCorta(item.destino.fecha)} ${item.destino.hora}` : `reagendado a ${o.reagendadaHaciaId}`}
                  </span>
                )}
                {o.reagendadaDesdeId && <span style={{ fontSize:10, color:C.txl }}>viene de {o.reagendadaDesdeId}</span>}
              </div>
              <div style={{ fontSize:10, color:C.txl, marginTop:2 }}>{o.nombreFinal}{o.acc ? ` · ACC ${soloNumero(o.acc)}` : ""}</div>
              {o.motivoCancelacion && <div style={{ fontSize:10, color:C.txm, marginTop:3, fontStyle:"italic" }}>"{o.motivoCancelacion}"</div>}
              {evento
                ? <div style={{ fontSize:10, color:C.txl, marginTop:3 }}>{evento.ts} · {evento.actorNombre}{evento.actorRol ? ` · ${evento.actorRol}` : ""}</div>
                : <div style={{ fontSize:10, color:C.txl, marginTop:3, fontStyle:"italic" }}>Información histórica parcial — dato de muestra, anterior a esta sesión.</div>}
            </div>
          </div>
        );
      })}
    </div>
  );
};

/* ═══════════════════════════ HISTORIAL | AUDITORÍA DEL CUPO ═══════════════════════════
   Tercera pestaña de la guía UX-UI: el Historial responde "qué pasó" y la Auditoría "quién hizo
   qué": acá se filtra la `auditoria` de la sesión a los eventos que tocaron ESTE cupo. */
const HistorialCupoTabs = ({ historial, auditoria }) => {
  const [tab, setTab] = useState("historial");
  const eventos = auditoria.filter(a => historial.some(it =>
    (it.tipo === "orden" && (a.entidad === it.orden.id || (it.orden.reagendadaHaciaId && a.entidad === it.orden.reagendadaHaciaId && a.accion === "Reagendó solicitud"))) ||
    (it.tipo === "movimiento" && a.entidad === it.mov.ordenId) ||
    (it.tipo === "bloqueo" && a.entidad === it.bloqueo.id)));
  const pestana = (id, label) => (
    <button onClick={() => setTab(id)} style={{ fontSize:11, padding:"5px 12px", borderRadius:7, border:`1px solid ${tab===id?C.pri:C.brd}`, background:tab===id?`${C.pri}12`:"#fff", color:tab===id?C.pri:C.txm, cursor:"pointer", fontWeight:600 }}>{label}</button>
  );
  return (
    <div>
      <div style={{ display:"flex", gap:6, marginBottom:10 }}>{pestana("historial","Historial")}{pestana("auditoria",`Auditoría (${eventos.length})`)}</div>
      {tab === "historial" ? <TimelineCupo historial={historial}/> : (
        <div>
          {eventos.length === 0 && <div style={{ fontSize:11, color:C.txl, fontStyle:"italic" }}>Sin eventos de auditoría de esta sesión para este cupo. Los datos de muestra anteriores no tienen registro.</div>}
          {eventos.map(a => (
            <div key={a.id} style={{ padding:"7px 0", borderBottom:`1px solid ${C.brd}` }}>
              <div style={{ display:"flex", gap:6, alignItems:"center", flexWrap:"wrap" }}><Badge c={C.tea} sm>{a.accion}</Badge><span style={{ fontSize:11, fontWeight:600, color:C.txt }}>{a.actorNombre}</span>{a.actorRol && <span style={{ fontSize:10, color:C.txl }}>· {a.actorRol}</span>}</div>
              <div style={{ fontSize:10, color:C.txl, marginTop:2 }}>{a.ts}</div>
              <div style={{ fontSize:10.5, color:C.txm, marginTop:3, lineHeight:1.4 }}>{a.detalle}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

/* ═══════════════════════════ PANEL DE DETALLE ═══════════════════════════ */
const PanelDetalle = ({ orden, equipo, historial, onClose, onConfirmar, onDesconfirmar, onActivarLlegada, onNoShow, onCancelar, onModificar, onReagendar, onAgregarNotaCita, onEliminarNotaCita, autor, cantEventosNotas = 0, onVerHistorialNotas, bloqueoActual = null, onMover, onRevertirNoShow, auditoria = [] }) => {
  const dlg = useDialogo(onClose);
  const est = ESTADOS[orden.estado];
  const cons = CONSENT_ESTADOS[orden.consentimientoEstado];
  const edad = calcularEdad(orden.paciente.fechaNacimiento, orden.fecha);
  const campos = [
    ["RUT", orden.paciente.rut], ["Fecha de nacimiento", fmtLarga(orden.paciente.fechaNacimiento)], ["Edad (calculada)", `${edad} años`],
    ["Equipo", equipo ? `${equipo.nombre} · ${equipo.area}` : "—"], ["Modalidad", MODALIDAD_LABEL[orden.modalidad] || orden.modalidad],
    ["Subespecialidad", orden.prestacion.especialidad], ["Fecha", fmtLarga(orden.fecha)], ["Hora", orden.hora],
    ["Prestación", orden.nombreFinal],
    ["Código Fonasa", orden.prestacion.codigoFonasa || "—"], ["Código interno", orden.prestacion.codigoInterno || "—"],
    ["Accession Number", orden.acc ? soloNumero(orden.acc) : "Pendiente — se asigna en Admisión"],
    ["OT (Orden de Trabajo)", orden.ot ? soloNumero(orden.ot) : "Pendiente — se asigna en Admisión"],
    ["Canal de solicitud", orden.canal],
    ["Agendado originalmente por", orden.agendadoOriginalmentePorNombre || orden.agendadoPorNombre || "—"],
  ];
  // Antes esto miraba solo reagendadaDesdeId, que el drag&drop nunca fija
  // (muta la misma orden, no crea una nueva) — por eso "Reagendado por"
  // no aparecía ahí aunque sí hubiera pasado un movimiento real. Comparar
  // agendadoPor contra agendadoOriginalmentePor cubre los 2 caminos con
  // la misma condición: si alguien distinto al que inició la reserva
  // tocó esta orden (reagendó formal o arrastró), difieren.
  const fueTocadaPorOtro = orden.agendadoOriginalmentePorCUT && orden.agendadoPorCUT !== orden.agendadoOriginalmentePorCUT;
  if (fueTocadaPorOtro) campos.push(["Reagendado por", orden.agendadoPorNombre || "—"]);
  if (orden.canalLlegada) campos.push(["Canal de llegada", CANALES_LLEGADA[orden.canalLlegada].label]);
  return (
    <div {...dlg} style={{ position:"fixed", top:0, right:0, bottom:0, width:420, maxWidth:"92vw", background:C.sfc, borderLeft:`1px solid ${C.brd}`, boxShadow:"-4px 0 20px rgba(0,0,0,0.12)", zIndex:50, display:"flex", flexDirection:"column" }}>
      <div style={{ padding:"16px 18px", borderBottom:`1px solid ${C.brd}`, display:"flex", justifyContent:"space-between", alignItems:"flex-start" }}>
        <div>
          <div style={{ fontSize:14, fontWeight:700, color:C.txt }}>{nombreCompletoPaciente(orden.paciente)}</div>
          <div style={{ marginTop:4, display:"flex", gap:6 }}><CUPPill cup={orden.paciente.cup}/><ACCPill acc={orden.acc}/></div>
        </div>
        <button onClick={onClose} style={{ background:"none", border:"none", cursor:"pointer", padding:4 }}><X size={18} color={C.txl}/></button>
      </div>
      <div style={{ padding:"14px 18px", overflowY:"auto", flex:1 }}>
        <div style={{ marginBottom:14, display:"flex", gap:6, flexWrap:"wrap" }}>
          <Badge c={est.color}>{est.label}</Badge>
          {orden.estadoAntesDeReagendar && <Badge c={C.txl} sm>Antes: {ESTADOS[orden.estadoAntesDeReagendar].label}</Badge>}
          <Badge c={C.pri} sm>FHIR·ServiceRequest</Badge>
        </div>

        {bloqueoActual && ["agendado","confirmado"].includes(orden.estado) && (
          <div style={{ marginBottom:12, padding:"9px 11px", background:`${C.dan}10`, border:`1px solid ${C.dan}40`, borderRadius:8, fontSize:11, color:C.dan, display:"flex", gap:6, alignItems:"flex-start" }}>
            <Lock size={13} style={{ flexShrink:0, marginTop:1 }}/>
            <span><strong>Esta cita está en un cupo bloqueado</strong> ({bloqueoActual.motivo}). No se mueve sola: arrástrala a otro cupo en la grilla o usa «Reagendar Cita».</span>
          </div>
        )}
        <div style={{ marginBottom:12, padding:"9px 11px", background:C.bg, borderRadius:8 }}>
          <div style={{ display:"flex", alignItems:"center", gap:6, marginBottom:6 }}>
            <Paperclip size={12} color={C.txm}/>
            <span style={{ fontSize:11, fontWeight:700, color:C.txm }}>Orden médica</span>
          </div>
          <div style={{ fontSize:11, color:C.txt }}>{orden.ordenMedica.adjunta ? "Documento adjunto ✓" : "Sin documento adjunto"} · {orden.ordenMedica.medicoSolicitante} · emitida {fmtCorta(orden.ordenMedica.fechaEmision)}</div>
        </div>

        {(orden.adjuntosPrevios?.archivo || orden.adjuntosPrevios?.link) && (
          <div style={{ marginBottom:12, padding:"9px 11px", background:C.bg, borderRadius:8 }}>
            <div style={{ display:"flex", alignItems:"center", gap:6, marginBottom:6 }}>
              <Link2 size={12} color={C.txm}/>
              <span style={{ fontSize:11, fontWeight:700, color:C.txm }}>Exámenes previos</span>
            </div>
            {orden.adjuntosPrevios.archivo && <div style={{ fontSize:11, color:C.txt }}>Informe adjunto: {orden.adjuntosPrevios.archivo}</div>}
            {orden.adjuntosPrevios.link && <div style={{ fontSize:11, color:C.txt, marginTop:orden.adjuntosPrevios.archivo?4:0, wordBreak:"break-all" }}>Link: {orden.adjuntosPrevios.link}</div>}
          </div>
        )}

        {orden.requiereConsentimiento && (
          <div style={{ marginBottom:12, padding:"9px 11px", background:`${cons.color}10`, borderRadius:8, display:"flex", flexDirection:"column", gap:8 }}>
            <div style={{ display:"flex", alignItems:"center", gap:6 }}>
              <ShieldCheck size={13} color={cons.color}/>
              <span style={{ fontSize:11, fontWeight:700, color:cons.color }}>Consentimiento: {cons.label}</span>
              <Badge c={C.txl} sm>{orden.plantillaConsentimiento}</Badge>
            </div>
            <Btn v="ghost" sz="sm" icon={Lock} dis title="Firma FESpa/FESpro — puerta etiquetada, pendiente del catálogo real de prestaciones + plantillas PDF validadas">Ver / Firmar Consentimiento</Btn>
          </div>
        )}

        {orden.requiereCreatinina && (orden.creatininaAdjunta || orden.creatininaExpres ? (
          <div style={{ marginBottom:12, padding:"9px 11px", background:`${C.suc}10`, borderRadius:8, fontSize:11, color:C.suc, display:"flex", gap:6, alignItems:"flex-start" }}>
            <ShieldCheck size={13} style={{ flexShrink:0, marginTop:1 }}/>
            <span>Función renal (creatinina) resuelta — {orden.creatininaAdjunta ? `informe adjunto: ${orden.creatininaAdjunta}` : "se realizará exprés el día del examen"}.</span>
          </div>
        ) : (
          <div style={{ marginBottom:12, padding:"9px 11px", background:`${C.war}10`, borderRadius:8, fontSize:11, color:C.war, display:"flex", gap:6, alignItems:"flex-start" }}>
            <AlertTriangle size={13} style={{ flexShrink:0, marginTop:1 }}/>
            <span>Paciente ≥60 años + contraste: requiere función renal (creatinina). Adjunta el informe o se realiza exprés el día del examen.</span>
          </div>
        ))}

        {campos.map(([label, val]) => (
          <div key={label} style={{ display:"flex", justifyContent:"space-between", padding:"7px 0", borderBottom:`1px solid ${C.brd}`, gap:10 }}>
            <span style={{ fontSize:11, color:C.txl }}>{label}</span>
            <span style={{ fontSize:11, fontWeight:600, color:C.txt, textAlign:"right", fontFamily: label.includes("UID") || label==="Accession Number" ? "monospace" : "inherit", wordBreak:"break-all" }}>{val}</span>
          </div>
        ))}

        {/* Historial del Cupo — responde "¿qué pasó antes en este mismo
            equipo+fecha+hora?", distinto del estado actual de arriba y de
            la Auditoría (quién hizo qué). Solo aparece si hay algo que
            mostrar, para no ensanchar el panel en el caso común. */}
        {historial.length > 0 && (
          <div style={{ marginTop:12, marginBottom:4 }}>
            <div style={{ fontSize:11, fontWeight:700, color:C.txl, textTransform:"uppercase", marginBottom:7, display:"flex", alignItems:"center", gap:5 }}>
              <Clock size={12} color={C.txl}/> Historial de este Cupo ({historial.length})
            </div>
            <HistorialCupoTabs historial={historial} auditoria={auditoria}/>
          </div>
        )}

        {(orden.estado === "en_atencion" || orden.estado === "atendido") && (
          <div style={{ marginTop:12, padding:"9px 11px", background:`${ESTADOS[orden.estado].color}10`, borderRadius:8, fontSize:11, color:ESTADOS[orden.estado].color, display:"flex", gap:6, alignItems:"flex-start" }}>
            <Info size={13} style={{ flexShrink:0, marginTop:1 }}/>
            <span>{orden.estado === "en_atencion" ? "El paciente ya entró a sala — lo controla el módulo operativo RIS-PACS, no esta agenda." : "Examen realizado — el estado se actualiza desde el módulo operativo RIS-PACS."}</span>
          </div>
        )}

        {/* Notas de la Cita — 4º nivel del panel de notas, 1:1 con esta orden
            (a diferencia de Generales/Día-semana/Del día, que son de toda la
            agenda). Inspirado en "Notas de la Cita" de la referencia real. */}
        <div style={{ marginTop:4, marginBottom:12 }}>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:6 }}>
            <div style={{ fontSize:11, fontWeight:700, color:C.txl, textTransform:"uppercase" }}>Notas de la Cita</div>
            <button onClick={onVerHistorialNotas} title={`Historial: quién escribió o borró notas (${cantEventosNotas})`} aria-label="Historial de notas de la cita" style={{ border:"none", background:`${C.pri}12`, borderRadius:6, cursor:"pointer", padding:4, display:"flex" }}><History size={14} color={C.pri}/></button>
          </div>
          <div style={{ maxHeight:110, overflowY:"auto", marginBottom:6 }}>
            {(orden.notasCita || []).length === 0 && <div style={{ fontSize:10, color:C.txl, fontStyle:"italic" }}>Sin notas todavía.</div>}
            {(orden.notasCita || []).map(n => (
              <div key={n.id} style={{ background:C.bg, borderRadius:7, padding:"6px 8px", marginBottom:5 }}>
                <div style={{ fontSize:11, color:C.txt }}>{n.texto}</div>
                <div style={{ display:"flex", justifyContent:"space-between", marginTop:2 }}>
                  <span style={{ fontSize:10, color:C.txl }}>{n.autor}{n.autorRol ? ` · ${n.autorRol}` : ""} · {n.ts}</span>
                  <button onClick={() => onEliminarNotaCita(n.id)} style={{ background:"none", border:"none", cursor:"pointer", padding:0 }}><X size={10} color={C.txl}/></button>
                </div>
              </div>
            ))}
          </div>
          <NotaCitaInput onAgregar={onAgregarNotaCita}/>
        </div>

        <div style={{ marginTop:12, padding:"8px 10px", background:`${C.pri}08`, borderRadius:7, fontSize:10, color:C.txm, display:"flex", gap:6, alignItems:"flex-start" }}>
          <Info size={12} color={C.pri} style={{ flexShrink:0, marginTop:1 }}/>
          <span>Adquisición, C-STORE e informe se reflejan acá solo cuando exista conexión con el módulo operativo de RIS-PACS — esta agenda no los controla ni los simula.</span>
        </div>
      </div>
      <div style={{ padding:"14px 18px", borderTop:`1px solid ${C.brd}`, display:"flex", flexWrap:"wrap", gap:8 }}>
        {orden.estado === "agendado" && <Btn v="success" icon={CheckCircle2} onClick={onConfirmar}>Confirmar</Btn>}
        {orden.estado === "confirmado" && (
          <>
            <Btn v="teal" icon={ArrowRight} onClick={() => onActivarLlegada("recepcion")} title="Camino 1 — el paciente saca número y lo atiende personal de recepción">Activar Llegada</Btn>
            <Btn v="outline" col={C.amb} sz="sm" onClick={() => onActivarLlegada("totem")} title="Camino 2 — simula que el paciente se acercó solo al tótem de autoatención">Simular Tótem</Btn>
            <Btn v="outline" col={C.pri} sz="sm" onClick={() => onActivarLlegada("portal")} title="Camino 3 — simula que el paciente activó su llegada desde el Portal Paciente">Simular Portal Paciente</Btn>
            <Btn v="ghost" sz="sm" onClick={onDesconfirmar}>Desconfirmar</Btn>
          </>
        )}
        {(orden.estado === "agendado" || orden.estado === "confirmado") && <Btn v="ghost" icon={AlertTriangle} onClick={onNoShow}>No-Show</Btn>}
        {orden.estado === "no_show" && <Btn v="outline" icon={RefreshCw} onClick={onRevertirNoShow} title="Deshacer una inasistencia marcada por error: la cita vuelve al estado que tenía antes">Revertir No-Show</Btn>}
        {["agendado","confirmado"].includes(orden.estado) && <Btn v="outline" onClick={onModificar}>Modificar Cita</Btn>}
        {["agendado","confirmado"].includes(orden.estado) && <Btn v="outline" onClick={onMover} title="Mover a otro cupo sin arrastrar (teclado o pantalla táctil)">Mover cita</Btn>}
        {["agendado","confirmado","no_show","cancelado"].includes(orden.estado) && <Btn v="outline" onClick={onReagendar}>Reagendar Cita</Btn>}
        {["agendado","confirmado"].includes(orden.estado) && <Btn v="ghost" icon={X} onClick={onCancelar}>Cancelar</Btn>}
        {orden.estado === "en_espera" && <Btn v="ghost" dis icon={Lock} title="Puerta etiquetada — pendiente de conexión con el módulo operativo real">Enviar a módulo operativo RIS-PACS ↗</Btn>}
        <Btn v="ghost" sz="sm" dis title="Puerta etiquetada — Bonos y Pagos (med_bonos) todavía no está construido">Cobrar Cita (Bonos y Pagos) ↗</Btn>
        <Btn v="ghost" sz="sm" icon={Lock} dis title="Puerta etiquetada — reenvío de confirmación por WhatsApp/correo, pendiente de integración real">Reenviar confirmación WhatsApp/Correo</Btn>
      </div>
    </div>
  );
};

const ModalBloqueo = ({ form, setForm, ordenes, onGuardar, onCerrar }) => {
  const dlg = useDialogo(onCerrar);
  const horaDesde = form.horario === "dia" ? "00:00" : form.horaDesde;
  const horaHasta = form.horario === "dia" ? "23:59" : form.horario === "cupo" ? form.horaDesde : form.horaHasta;
  const afectadas = citasEnBloqueo(ordenes, { equipoId:form.equipoId, fechaDesde:form.fechaDesde, fechaHasta:form.fechaHasta, horaDesde, horaHasta });
  const opcion = (id, label) => (
    <button onClick={() => setForm(f => ({ ...f, horario:id }))} style={{ fontSize:11, padding:"5px 12px", borderRadius:7, border:`1px solid ${form.horario===id?C.pri:C.brd}`, background:form.horario===id?`${C.pri}12`:"#fff", color:form.horario===id?C.pri:C.txm, cursor:"pointer", fontWeight:600 }}>{label}</button>
  );
  const sel = { width:"100%", padding:"7px 8px", fontSize:12, border:`1px solid ${C.brd}`, borderRadius:7, boxSizing:"border-box" };
  return (
    <div {...dlg} style={{ position:"fixed", inset:0, background:"rgba(15,23,32,0.45)", display:"flex", alignItems:"center", justifyContent:"center", zIndex:60, padding:20 }}>
      <div style={{ background:C.sfc, borderRadius:14, width:460, maxWidth:"100%", maxHeight:"92vh", overflowY:"auto", padding:22, boxSizing:"border-box" }}>
        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:16 }}>
          <div style={{ fontSize:15, fontWeight:700, color:C.txt }}>Bloquear agenda</div>
          <button onClick={onCerrar} style={{ background:"none", border:"none", cursor:"pointer" }}><X size={18} color={C.txl}/></button>
        </div>
        <div style={{ fontSize:10, color:C.txm, marginBottom:4 }}>Equipo</div>
        <select value={form.equipoId} onChange={e => setForm(f => ({ ...f, equipoId:e.target.value }))} style={{ ...sel, marginBottom:12 }}>
          {EQUIPOS.map(eq => <option key={eq.id} value={eq.id}>{eq.nombre} · {MODALIDAD_LABEL[eq.modalidad]}</option>)}
        </select>
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:8, marginBottom:12 }}>
          <div>
            <div style={{ fontSize:10, color:C.txm, marginBottom:4 }}>Fecha desde</div>
            <input type="date" value={form.fechaDesde} onChange={e => e.target.value && setForm(f => ({ ...f, fechaDesde:e.target.value, fechaHasta: f.fechaHasta < e.target.value ? e.target.value : f.fechaHasta }))} style={sel}/>
          </div>
          <div>
            <div style={{ fontSize:10, color:C.txm, marginBottom:4 }}>Fecha hasta (varios días)</div>
            <input type="date" value={form.fechaHasta} min={form.fechaDesde} onChange={e => e.target.value && setForm(f => ({ ...f, fechaHasta:e.target.value }))} style={sel}/>
          </div>
        </div>
        <div style={{ fontSize:10, color:C.txm, marginBottom:4 }}>Horario</div>
        <div style={{ display:"flex", gap:6, marginBottom:8 }}>{opcion("dia","Todo el día")}{opcion("rango","Rango de horas")}{opcion("cupo","Un cupo")}</div>
        {form.horario !== "dia" && (
          <div style={{ display:"grid", gridTemplateColumns: form.horario === "rango" ? "1fr 1fr" : "1fr", gap:8, marginBottom:12 }}>
            <div>
              <div style={{ fontSize:10, color:C.txm, marginBottom:3 }}>{form.horario === "rango" ? "Hora desde" : "Hora del cupo"}</div>
              <select value={form.horaDesde} onChange={e => setForm(f => ({ ...f, horaDesde:e.target.value, horaHasta: f.horaHasta < e.target.value ? e.target.value : f.horaHasta }))} style={sel}>{TODAS_HORAS.map(h => <option key={h} value={h}>{h}</option>)}</select>
            </div>
            {form.horario === "rango" && (
              <div>
                <div style={{ fontSize:10, color:C.txm, marginBottom:3 }}>Hora hasta (incluida)</div>
                <select value={form.horaHasta} onChange={e => setForm(f => ({ ...f, horaHasta:e.target.value }))} style={sel}>{TODAS_HORAS.filter(h => h >= form.horaDesde).map(h => <option key={h} value={h}>{h}</option>)}</select>
              </div>
            )}
          </div>
        )}
        <div style={{ fontSize:10, color:C.txm, marginBottom:4, marginTop: form.horario === "dia" ? 8 : 0 }}>Motivo (obligatorio)</div>
        <select value={form.motivoTipo} onChange={e => setForm(f => ({ ...f, motivoTipo:e.target.value }))} style={{ ...sel, marginBottom:8 }}>
          <option value="">Selecciona un motivo...</option>
          {MOTIVOS_BLOQUEO.map(m => <option key={m} value={m}>{m}</option>)}
        </select>
        <textarea value={form.motivoDetalle} onChange={e => setForm(f => ({ ...f, motivoDetalle:e.target.value }))} placeholder={form.motivoTipo === "Otro" ? "Describe el motivo (obligatorio)..." : "Detalle (opcional), ej. mantención preventiva, vuelve el jueves"} rows={2} style={{ ...sel, fontFamily:"inherit", resize:"vertical", marginBottom:12 }}/>
        {afectadas.length > 0 ? (
          <div style={{ marginBottom:12, padding:"9px 11px", background:`${C.war}10`, borderRadius:8, fontSize:11, color:C.war, display:"flex", gap:6, alignItems:"flex-start" }}>
            <AlertTriangle size={13} style={{ flexShrink:0, marginTop:1 }}/>
            <span><strong>{afectadas.length} cita{afectadas.length === 1 ? "" : "s"} agendada{afectadas.length === 1 ? "" : "s"} o confirmada{afectadas.length === 1 ? "" : "s"}</strong> quedan dentro de esta zona. No se cancelan ni se mueven solas: quedarán marcadas para que las muevas a mano.</span>
          </div>
        ) : (
          <div style={{ marginBottom:12, fontSize:10, color:C.txl }}>No hay citas agendadas ni confirmadas dentro de esta zona.</div>
        )}
        <div style={{ display:"flex", gap:8, justifyContent:"flex-end" }}>
          <Btn v="ghost" onClick={onCerrar}>Cancelar</Btn>
          <Btn v="danger" icon={Ban} onClick={onGuardar}>Guardar bloqueo</Btn>
        </div>
      </div>
    </div>
  );
};

const PanelBloqueo = ({ bloqueo, equipo, citas, cupoSel, onClose, onVerCita, onQuitar }) => {
  const dlg = useDialogo(onClose);
  const [confirmando, setConfirmando] = useState(false);
  const [lib, setLib] = useState({ fechaDesde:bloqueo.fechaDesde, fechaHasta:bloqueo.fechaHasta, horario: cupoSel ? "sel" : "todo", horaDesde:"", horaHasta:"", fechaOtro:"" });
  const horasPosibles = TODAS_HORAS.filter(h => h >= bloqueo.horaDesde && h <= bloqueo.horaHasta);
  const hDesde = lib.horaDesde || (cupoSel && horasPosibles.includes(cupoSel.hora) ? cupoSel.hora : (horasPosibles[0] || bloqueo.horaDesde));
  const hHasta = lib.horaHasta || horasPosibles[horasPosibles.length - 1] || bloqueo.horaHasta;
  const fechaOtro = lib.fechaOtro || (cupoSel && cupoSel.fecha) || bloqueo.fechaDesde;
  // sel = el cupo en el que se hizo clic; todo/rango = por fechas y horario; otro = un cupo a elección.
  const liberacion = lib.horario === "sel" && cupoSel
    ? { fechaDesde:cupoSel.fecha, fechaHasta:cupoSel.fecha, horaDesde:cupoSel.hora, horaHasta:cupoSel.hora }
    : lib.horario === "otro"
    ? { fechaDesde:fechaOtro, fechaHasta:fechaOtro, horaDesde:hDesde, horaHasta:hDesde }
    : { fechaDesde:lib.fechaDesde, fechaHasta:lib.fechaHasta,
        horaDesde: lib.horario === "rango" ? hDesde : bloqueo.horaDesde,
        horaHasta: lib.horario === "rango" ? (hHasta < hDesde ? hDesde : hHasta) : bloqueo.horaHasta };
  const opLib = (id, label) => (
    <button onClick={() => setLib(l => ({ ...l, horario:id }))} style={{ fontSize:10.5, padding:"4px 9px", borderRadius:7, border:`1px solid ${lib.horario===id?C.pri:C.brd}`, background:lib.horario===id?`${C.pri}12`:"#fff", color:lib.horario===id?C.pri:C.txm, cursor:"pointer", fontWeight:600 }}>{label}</button>
  );
  const selL = { width:"100%", padding:"6px 7px", fontSize:11, border:`1px solid ${C.brd}`, borderRadius:7, boxSizing:"border-box" };
  const esTotal = liberacion.fechaDesde <= bloqueo.fechaDesde && liberacion.fechaHasta >= bloqueo.fechaHasta && liberacion.horaDesde <= bloqueo.horaDesde && liberacion.horaHasta >= bloqueo.horaHasta;
  const diasLib = diasDeBloqueo({ fechaDesde:liberacion.fechaDesde, fechaHasta:liberacion.fechaHasta });
  return (
  <div {...dlg} style={{ position:"fixed", top:0, right:0, bottom:0, width:400, maxWidth:"92vw", background:C.sfc, borderLeft:`1px solid ${C.brd}`, boxShadow:"-4px 0 20px rgba(0,0,0,0.12)", zIndex:50, display:"flex", flexDirection:"column" }}>
    <div style={{ padding:"16px 18px", borderBottom:`1px solid ${C.brd}`, display:"flex", justifyContent:"space-between", alignItems:"flex-start" }}>
      <div>
        <div style={{ fontSize:14, fontWeight:700, color:C.txt }}>{equipo ? equipo.nombre : "—"}</div>
        <div style={{ fontSize:11, color:C.txl, marginTop:3 }}>{textoFechasBloqueo(bloqueo)} · {textoHorarioBloqueo(bloqueo)}</div>
      </div>
      <button onClick={onClose} style={{ background:"none", border:"none", cursor:"pointer", padding:4 }}><X size={18} color={C.txl}/></button>
    </div>
    <div style={{ padding:"14px 18px", overflowY:"auto", flex:1 }}>
      <div style={{ marginBottom:14, display:"flex", gap:6, flexWrap:"wrap" }}><Badge c={C.txl}>Bloqueado</Badge><Badge c={C.pri} sm>FHIR·Slot busy-unavailable</Badge></div>
      {[["Motivo", bloqueo.motivo], ["Bloqueado por", `${bloqueo.actorNombre}${bloqueo.actorRol ? ` · ${bloqueo.actorRol}` : ""}`], ["Cuándo", bloqueo.ts]].map(([l, v]) => (
        <div key={l} style={{ display:"flex", justifyContent:"space-between", padding:"7px 0", borderBottom:`1px solid ${C.brd}`, gap:10 }}>
          <span style={{ fontSize:11, color:C.txl }}>{l}</span>
          <span style={{ fontSize:11, fontWeight:600, color:C.txt, textAlign:"right" }}>{v}</span>
        </div>
      ))}
      {(bloqueo.liberaciones || []).length > 0 && (
        <div style={{ marginTop:12 }}>
          <div style={{ fontSize:11, fontWeight:700, color:C.txl, textTransform:"uppercase", marginBottom:6 }}>Partes ya liberadas ({bloqueo.liberaciones.length})</div>
          {bloqueo.liberaciones.map((l, i) => (
            <div key={i} style={{ fontSize:10, color:C.txm, padding:"5px 0", borderBottom:`1px solid ${C.brd}` }}>{textoFechasBloqueo(l)} · {textoHorarioBloqueo(l)}<div style={{ fontSize:10, color:C.txl }}>{l.por}{l.rol ? ` · ${l.rol}` : ""} · {l.ts}</div></div>
          ))}
        </div>
      )}
      <div style={{ marginTop:14, fontSize:11, fontWeight:700, color:C.txl, textTransform:"uppercase", marginBottom:7 }}>Citas por mover a mano ({citas.length})</div>
      {citas.length === 0 && <div style={{ fontSize:10.5, color:C.txl, fontStyle:"italic" }}>No hay citas agendadas ni confirmadas dentro de este bloqueo.</div>}
      {citas.map(o => (
        <button key={o.id} onClick={() => onVerCita(o)} style={{ display:"block", width:"100%", textAlign:"left", padding:"7px 9px", marginBottom:5, border:`1px solid ${C.brd}`, borderRadius:7, background:"#fff", cursor:"pointer" }}>
          <div style={{ fontSize:11, fontWeight:600, color:C.txt }}>{nombreCompletoPaciente(o.paciente)}</div>
          <div style={{ fontSize:10, color:C.txl }}>{fmtCorta(o.fecha)} · {o.hora} · {o.nombreFinal}</div>
        </button>
      ))}
      <div style={{ marginTop:12, padding:"8px 10px", background:`${C.pri}08`, borderRadius:7, fontSize:10, color:C.txm, display:"flex", gap:6, alignItems:"flex-start" }}>
        <Info size={12} color={C.pri} style={{ flexShrink:0, marginTop:1 }}/>
        <span>Las citas se pueden arrastrar fuera de la zona bloqueada o reagendar. No se pueden agendar citas nuevas ahí. Puedes quitar todo el bloqueo o solo una parte (un cupo, un rango de horas, algunos días).</span>
      </div>
    </div>
    <div style={{ padding:"14px 18px", borderTop:`1px solid ${C.brd}` }}>
      {!confirmando ? (
        <Btn v="outline" icon={X} onClick={() => setConfirmando(true)}>Quitar bloqueo</Btn>
      ) : (
        <div style={{ padding:"10px 12px", background:`${C.war}10`, border:`1px solid ${C.war}40`, borderRadius:8 }}>
          <div style={{ fontSize:11, color:C.war, fontWeight:700, marginBottom:4 }}>¿Quitar este bloqueo?</div>
          <div style={{ fontSize:10, color:C.txm, marginBottom:4 }}>Qué parte quitar</div>
          <div style={{ display:"flex", gap:5, flexWrap:"wrap", marginBottom:8 }}>{cupoSel && opLib("sel","Cupo seleccionado")}{opLib("todo","Todo el horario")}{opLib("rango","Rango de horas")}{opLib("otro","Otro cupo")}</div>
          {(lib.horario === "todo" || lib.horario === "rango") && (
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:6, marginBottom:8 }}>
              <input type="date" value={lib.fechaDesde} min={bloqueo.fechaDesde} max={bloqueo.fechaHasta} onChange={e => e.target.value && setLib(l => ({ ...l, fechaDesde:e.target.value, fechaHasta: l.fechaHasta < e.target.value ? e.target.value : l.fechaHasta }))} style={selL}/>
              <input type="date" value={lib.fechaHasta} min={lib.fechaDesde} max={bloqueo.fechaHasta} onChange={e => e.target.value && setLib(l => ({ ...l, fechaHasta:e.target.value }))} style={selL}/>
            </div>
          )}
          {lib.horario === "otro" && (
            <div style={{ marginBottom:8 }}><input type="date" value={fechaOtro} min={bloqueo.fechaDesde} max={bloqueo.fechaHasta} onChange={e => e.target.value && setLib(l => ({ ...l, fechaOtro:e.target.value }))} style={selL}/></div>
          )}
          {(lib.horario === "rango" || lib.horario === "otro") && (
            <div style={{ display:"grid", gridTemplateColumns: lib.horario === "rango" ? "1fr 1fr" : "1fr", gap:6, marginBottom:8 }}>
              <select value={hDesde} onChange={e => setLib(l => ({ ...l, horaDesde:e.target.value }))} style={selL}>{horasPosibles.map(h => <option key={h} value={h}>{h}</option>)}</select>
              {lib.horario === "rango" && <select value={hHasta} onChange={e => setLib(l => ({ ...l, horaHasta:e.target.value }))} style={selL}>{horasPosibles.filter(h => h >= hDesde).map(h => <option key={h} value={h}>{h}</option>)}</select>}
            </div>
          )}
          <div style={{ fontSize:10.5, color:C.txm, marginBottom:10, lineHeight:1.4 }}>{esTotal ? "Se liberará todo el bloqueo" : lib.horario === "sel" ? "Se liberará solo ese cupo" : "Se liberará solo esa parte; el resto sigue bloqueado"}: {equipo ? equipo.nombre : "—"} · {textoFechasBloqueo(liberacion)} ({diasLib} día{diasLib === 1 ? "" : "s"}) · {textoHorarioBloqueo(liberacion)}. Esos cupos quedarán disponibles para agendar.</div>
          <div style={{ display:"flex", gap:8 }}>
            <Btn v="danger" icon={X} onClick={() => onQuitar(liberacion)}>Sí, quitar</Btn>
            <Btn v="ghost" onClick={() => setConfirmando(false)}>Cancelar</Btn>
          </div>
        </div>
      )}
    </div>
  </div>
  );
};

/* ═══════════════════════════ MOVER CITA (sin arrastrar) ═══════════════════════════
   Alternativa accesible al arrastrar: mismo gesto rápido (misma orden, mismo ACC/OT/notas, solo
   cambian equipo/fecha/hora) pero con selectores, usable con teclado y en pantallas táctiles.
   Reutiliza las mismas validaciones que arrastrar (bloqueos, cupo ocupado, modalidad). */
const ModalMoverCita = ({ orden, bloqueoEn, onMover, onCerrar }) => {
  const dlg = useDialogo(onCerrar);
  const [fecha, setFecha] = useState(orden.fecha);
  const [hora, setHora] = useState(orden.hora);
  const [equipoId, setEquipoId] = useState(orden.equipoId);
  const bloq = bloqueoEn(equipoId, fecha, hora);
  const sel = { width:"100%", padding:"7px 8px", fontSize:12, border:`1px solid ${C.brd}`, borderRadius:7, boxSizing:"border-box" };
  const horas = TODAS_HORAS.includes(orden.hora) ? TODAS_HORAS : [...TODAS_HORAS, orden.hora].sort();
  return (
    <div {...dlg} aria-label="Mover cita" style={{ position:"fixed", inset:0, background:"rgba(15,23,32,0.45)", display:"flex", alignItems:"center", justifyContent:"center", zIndex:70, padding:20 }}>
      <div style={{ background:C.sfc, borderRadius:14, width:400, maxWidth:"100%", padding:20, boxSizing:"border-box" }}>
        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:4 }}>
          <div style={{ fontSize:15, fontWeight:700, color:C.txt }}>Mover cita</div>
          <button onClick={onCerrar} title="Cerrar" style={{ background:"none", border:"none", cursor:"pointer" }}><X size={18} color={C.txl}/></button>
        </div>
        <div style={{ fontSize:11, color:C.txl, marginBottom:14 }}>{nombreCompletoPaciente(orden.paciente)} — {orden.nombreFinal}</div>
        <div style={{ fontSize:10.5, color:C.txm, marginBottom:4 }}>Equipo (misma modalidad)</div>
        <select value={equipoId} onChange={e => setEquipoId(e.target.value)} style={{ ...sel, marginBottom:10 }}>
          {EQUIPOS.filter(e => e.modalidad === orden.modalidad).map(eq => <option key={eq.id} value={eq.id}>{eq.nombre}</option>)}
        </select>
        <div style={{ display:"grid", gridTemplateColumns:"1.2fr 1fr", gap:8, marginBottom:10 }}>
          <div><div style={{ fontSize:10.5, color:C.txm, marginBottom:4 }}>Fecha</div><input type="date" value={fecha} onChange={e => e.target.value && setFecha(e.target.value)} style={sel}/></div>
          <div><div style={{ fontSize:10.5, color:C.txm, marginBottom:4 }}>Hora</div><select value={hora} onChange={e => setHora(e.target.value)} style={sel}>{horas.map(h => <option key={h} value={h}>{h}</option>)}</select></div>
        </div>
        {bloq && <div style={{ marginBottom:10, padding:"7px 10px", background:`${C.dan}10`, borderRadius:7, fontSize:11, color:C.dan, display:"flex", gap:6, alignItems:"center" }}><Lock size={12}/>Cupo bloqueado ({bloq.motivo}) — elige otro.</div>}
        <div style={{ display:"flex", gap:8, justifyContent:"flex-end" }}>
          <Btn v="ghost" onClick={onCerrar}>Cancelar</Btn>
          <Btn v="success" icon={CheckCircle2} dis={!!bloq} onClick={() => onMover(equipoId, fecha, hora)}>Mover cita</Btn>
        </div>
      </div>
    </div>
  );
};

/* ═══════════════════════════ PANEL DE CUPO VACÍO CON HISTORIA ═══════════════════════════
   Contraparte de PanelDetalle para el caso "crítico" de la guía UX-UI
   (sección 16): un cupo Disponible puede tener historia. Solo se llega acá
   cuando historialDeCupo() no está vacío (ver verCeldaVacia en el
   componente principal) — un cupo realmente sin uso previo sigue yendo
   directo a Nueva Solicitud, sin este paso de más. */
const PanelCupoVacio = ({ slot, equipo, historial, auditoria = [], onClose, onNuevaSolicitud }) => {
  const dlg = useDialogo(onClose);
  return (
  <div {...dlg} style={{ position:"fixed", top:0, right:0, bottom:0, width:400, maxWidth:"92vw", background:C.sfc, borderLeft:`1px solid ${C.brd}`, boxShadow:"-4px 0 20px rgba(0,0,0,0.12)", zIndex:50, display:"flex", flexDirection:"column" }}>
    <div style={{ padding:"16px 18px", borderBottom:`1px solid ${C.brd}`, display:"flex", justifyContent:"space-between", alignItems:"flex-start" }}>
      <div>
        <div style={{ fontSize:14, fontWeight:700, color:C.txt }}>{equipo ? equipo.nombre : "—"}</div>
        <div style={{ fontSize:11, color:C.txl, marginTop:3 }}>{fmtLarga(slot.fecha)} · {slot.hora}</div>
      </div>
      <button onClick={onClose} style={{ background:"none", border:"none", cursor:"pointer", padding:4 }}><X size={18} color={C.txl}/></button>
    </div>
    <div style={{ padding:"14px 18px", overflowY:"auto", flex:1 }}>
      <div style={{ marginBottom:16, display:"flex", gap:6, flexWrap:"wrap" }}>
        <Badge c={C.suc}>Disponible</Badge>
        <Badge c={C.pri} sm>FHIR·Slot</Badge>
      </div>
      <div style={{ fontSize:11, fontWeight:700, color:C.txl, textTransform:"uppercase", marginBottom:7, display:"flex", alignItems:"center", gap:5 }}>
        <Clock size={12} color={C.txl}/> Historial de este Cupo ({historial.length})
      </div>
      <HistorialCupoTabs historial={historial} auditoria={auditoria}/>
      <div style={{ marginTop:14, padding:"8px 10px", background:`${C.pri}08`, borderRadius:7, fontSize:10, color:C.txm, display:"flex", gap:6, alignItems:"flex-start" }}>
        <Info size={12} color={C.pri} style={{ flexShrink:0, marginTop:1 }}/>
        <span>Este cupo está libre ahora mismo — lo de arriba es lo que pasó acá antes, no afecta si se puede agendar hoy.</span>
      </div>
    </div>
    <div style={{ padding:"14px 18px", borderTop:`1px solid ${C.brd}` }}>
      <Btn v="success" icon={ScanLine} onClick={onNuevaSolicitud}>Nueva Solicitud para este cupo</Btn>
    </div>
  </div>
  );
};

const NotaCitaInput = ({ onAgregar }) => {
  const [texto, setTexto] = useState("");
  return (
    <div style={{ display:"flex", gap:5 }}>
      <input value={texto} onChange={e=>setTexto(e.target.value)} onKeyDown={e => { if (e.key === "Enter" && texto.trim()) { onAgregar(texto.trim()); setTexto(""); } }} placeholder="Agregar nota a esta cita..." style={{ flex:1, padding:"6px 8px", fontSize:11, border:`1px solid ${C.brd}`, borderRadius:6, boxSizing:"border-box" }}/>
      <button onClick={() => { if (texto.trim()) { onAgregar(texto.trim()); setTexto(""); } }} style={{ padding:"6px 10px", fontSize:11, fontWeight:700, background:C.pri, color:"#fff", border:"none", borderRadius:6, cursor:"pointer" }}>+</button>
    </div>
  );
};

/* ═══════════════════════════ MODAL NUEVA SOLICITUD ═══════════════════════════ */
const ModalNuevaSolicitud = ({ bloqueoDestino, form, setForm, pacientes, medicosReferentes, onAgregarMedico, onGuardar, onCerrar }) => {
  const dlg = useDialogo(onCerrar);
  const [registrandoMedico, setRegistrandoMedico] = useState(false);
  const [capturando, setCapturando] = useState(null); // "orden" | "informe" | null
  const prestacionesModalidad = CATALOGO_PRESTACIONES.filter(p => p.modalidad === form.modalidad);
  const especialidades = [...new Set(prestacionesModalidad.map(p => p.especialidad))];
  const prestacionesEspecialidad = prestacionesModalidad.filter(p => p.especialidad === form.especialidad);
  const prestSel = prestacionesEspecialidad.find(p => p.nombre === form.prestacionNombre);
  const equiposDeModalidad = EQUIPOS.filter(e => e.modalidad === form.modalidad);
  const edad = form.fechaNacimiento ? calcularEdad(form.fechaNacimiento, form.fecha) : null;
  const consent = prestSel ? calcularConsentimiento(form.modalidad, prestSel.contraste) : null;
  const nombreFinal = prestSel ? construirNombreEspecifico(prestSel.nombre, form.lateralidad) : "";
  const necesitaCreatinina = consent?.requiere && !!prestSel?.contraste && edad !== null && edad >= 60;

  return (
    <div {...dlg} style={{ position:"fixed", inset:0, background:"rgba(15,23,32,0.45)", display:"flex", alignItems:"center", justifyContent:"center", zIndex:60, padding:20 }}>
      <div style={{ background:C.sfc, borderRadius:14, width:560, maxWidth:"100%", maxHeight:"92vh", overflowY:"auto", padding:22, boxSizing:"border-box" }}>
        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:16 }}>
          <div style={{ fontSize:15, fontWeight:700, color:C.txt }}>{form.editId ? "Modificar Solicitud" : form.reagendaDesdeId ? "Reagendar Solicitud" : "Nueva Solicitud de Imagen"}</div>
          <button onClick={onCerrar} style={{ background:"none", border:"none", cursor:"pointer" }}><X size={18} color={C.txl}/></button>
        </div>

        {/* 1 · Paciente */}
        <div style={{ fontSize:11, fontWeight:700, color:C.txl, textTransform:"uppercase", marginBottom:6 }}>1 · Paciente</div>
        {!form.pacienteCup ? (
          <div style={{ marginBottom:16 }}>
            <PacientePicker pacientes={pacientes} onSeleccionar={p => setForm(f => ({ ...f, pacienteCup:p.cup, nombres:p.nombres, apellidoPaterno:p.apellidoPaterno, apellidoMaterno:p.apellidoMaterno, rut:p.rut, fechaNacimiento:p.fechaNacimiento, telefono1:p.telefono1 || "", telefono2:p.telefono2 || "", correo:p.correo || "" }))}/>
            <button onClick={() => setForm(f => ({ ...f, pacienteCup:"NUEVO" }))} style={{ marginTop:6, fontSize:10, color:C.pri, background:"none", border:"none", cursor:"pointer", padding:0, textDecoration:"underline" }}>¿No aparece? Registrar paciente nuevo</button>
          </div>
        ) : form.pacienteCup === "NUEVO" ? (
          <div style={{ marginBottom:16 }}>
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:8, marginBottom:8 }}>
              <div>
                <div style={{ fontSize:10, color:C.txm, marginBottom:3 }}>Nombres *</div>
                <input autoComplete="off" value={form.nombres} onChange={e=>setForm(f=>({...f, nombres:e.target.value}))} placeholder="Nombres" style={{ width:"100%", padding:"7px 8px", fontSize:12, border:`1px solid ${C.brd}`, borderRadius:7, boxSizing:"border-box" }}/>
              </div>
              <div>
                <div style={{ fontSize:10, color:C.txm, marginBottom:3 }}>Ap. Paterno *</div>
                <input autoComplete="off" value={form.apellidoPaterno} onChange={e=>setForm(f=>({...f, apellidoPaterno:e.target.value}))} placeholder="Paterno" style={{ width:"100%", padding:"7px 8px", fontSize:12, border:`1px solid ${C.brd}`, borderRadius:7, boxSizing:"border-box" }}/>
              </div>
              <div>
                <div style={{ fontSize:10, color:C.txm, marginBottom:3 }}>Ap. Materno</div>
                <input autoComplete="off" value={form.apellidoMaterno} onChange={e=>setForm(f=>({...f, apellidoMaterno:e.target.value}))} placeholder="Materno" style={{ width:"100%", padding:"7px 8px", fontSize:12, border:`1px solid ${C.brd}`, borderRadius:7, boxSizing:"border-box" }}/>
              </div>
            </div>
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:8, marginBottom:8 }}>
              <div>
                <div style={{ fontSize:10, color:C.txm, marginBottom:3 }}>RUT *</div>
                <input autoComplete="off" value={form.rut} onChange={e=>setForm(f=>({...f, rut:e.target.value}))} placeholder="12.345.678-9" style={{ width:"100%", padding:"7px 8px", fontSize:12, border:`1px solid ${C.brd}`, borderRadius:7, boxSizing:"border-box" }}/>
              </div>
              <div>
                <div style={{ fontSize:10, color:C.txm, marginBottom:3 }}>Fecha de nacimiento *</div>
                <input autoComplete="off" type="date" value={form.fechaNacimiento} onChange={e=>setForm(f=>({...f, fechaNacimiento:e.target.value}))} style={{ width:"100%", padding:"7px 8px", fontSize:12, border:`1px solid ${C.brd}`, borderRadius:7, boxSizing:"border-box" }}/>
              </div>
            </div>
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:8 }}>
              <div>
                <div style={{ fontSize:10, color:C.txm, marginBottom:3 }}>Teléfono 1</div>
                <input autoComplete="off" value={form.telefono1} onChange={e=>setForm(f=>({...f, telefono1:e.target.value}))} placeholder="+56 9..." style={{ width:"100%", padding:"7px 8px", fontSize:12, border:`1px solid ${C.brd}`, borderRadius:7, boxSizing:"border-box" }}/>
              </div>
              <div>
                <div style={{ fontSize:10, color:C.txm, marginBottom:3 }}>Teléfono 2</div>
                <input autoComplete="off" value={form.telefono2} onChange={e=>setForm(f=>({...f, telefono2:e.target.value}))} placeholder="Opcional" style={{ width:"100%", padding:"7px 8px", fontSize:12, border:`1px solid ${C.brd}`, borderRadius:7, boxSizing:"border-box" }}/>
              </div>
              <div>
                <div style={{ fontSize:10, color:C.txm, marginBottom:3 }}>Correo</div>
                <input autoComplete="off" value={form.correo} onChange={e=>setForm(f=>({...f, correo:e.target.value}))} placeholder="correo@ejemplo.cl" style={{ width:"100%", padding:"7px 8px", fontSize:12, border:`1px solid ${C.brd}`, borderRadius:7, boxSizing:"border-box" }}/>
              </div>
            </div>
            <div style={{ fontSize:10, color:C.txl, marginTop:5 }}>Se necesita al menos un teléfono o un correo — es el dato que usa la confirmación por WhatsApp/correo.</div>
          </div>
        ) : (
          <div style={{ marginBottom:16, display:"flex", justifyContent:"space-between", alignItems:"center", padding:"9px 11px", background:`${C.suc}10`, borderRadius:8 }}>
            <div style={{ fontSize:12, fontWeight:700, color:C.txt }}>{form.nombres} {form.apellidoPaterno} {form.apellidoMaterno} · {edad ?? "—"} años · <CUPPill cup={form.pacienteCup}/></div>
            <button onClick={() => setForm(f => ({ ...f, pacienteCup:null }))} style={{ fontSize:10, color:C.txl, background:"none", border:"none", cursor:"pointer" }}>Cambiar</button>
          </div>
        )}

        {/* 2 · Orden médica */}
        <div style={{ fontSize:11, fontWeight:700, color:C.txl, textTransform:"uppercase", marginBottom:6 }}>2 · Orden médica</div>
        <div style={{ marginBottom:16, padding:"10px 11px", background:C.bg, borderRadius:8 }}>
          <div style={{ display:"flex", gap:6, marginBottom:8 }}>
            <label style={{ display:"flex", alignItems:"center", gap:8, fontSize:11, color:C.txm, cursor:"pointer", flex:1, background:"#fff", border:`1px solid ${C.brd}`, borderRadius:7, padding:"7px 9px" }}>
              <Paperclip size={13}/> {form.ordenAdjunta ? form.ordenAdjunta : "Adjuntar archivo (PDF/foto)"}
              <input type="file" style={{ display:"none" }} onChange={e => setForm(f => ({ ...f, ordenAdjunta: e.target.files[0]?.name || null }))}/>
            </label>
            <Btn v="outline" sz="sm" icon={Camera} onClick={() => setCapturando("orden")} title="Cámara real — funciona (getUserMedia, API estándar del navegador). Distinto de un escáner físico de oficina, que sí requiere driver/app puente y queda como puerta etiquetada.">Tomar foto</Btn>
            <Btn v="ghost" sz="sm" icon={Lock} dis title="Escáner físico de oficina — puerta etiquetada. Un componente en el navegador no puede controlar ese hardware directamente (necesita driver TWAIN/WIA o una app puente local con su propia API). La cámara de al lado sí es real porque usa una API estándar del navegador, no hardware dedicado.">Escanear (hardware)</Btn>
          </div>
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:8, marginBottom:8 }}>
            <MedicoPicker
              medicos={medicosReferentes} valor={form.medicoSolicitante}
              onSeleccionar={(nombre, m) => setForm(f => ({ ...f, medicoSolicitante:nombre, medicoSolicitanteId: m?.id || null }))}
              onRegistrarNuevo={() => setRegistrandoMedico(true)}
            />
            <input type="date" value={form.fechaEmisionOrden} onChange={e=>setForm(f=>({...f, fechaEmisionOrden:e.target.value}))} style={{ padding:"7px 8px", fontSize:12, border:`1px solid ${C.brd}`, borderRadius:7 }}/>
          </div>
          <Btn v="ghost" sz="sm" icon={Lock} dis title="Lectura automática del PDF (OCR/Document AI) — puerta etiquetada, sin backend en este componente">Leer datos automáticamente</Btn>
        </div>
        {registrandoMedico && (
          <MiniRegistroMedico
            nombreInicial={form.medicoSolicitante}
            onCerrar={() => setRegistrandoMedico(false)}
            onGuardar={(datos) => {
              const nuevo = onAgregarMedico(datos);
              setForm(f => ({ ...f, medicoSolicitante:nuevo.nombreCompleto, medicoSolicitanteId:nuevo.id }));
              setRegistrandoMedico(false);
            }}
          />
        )}
        {capturando && (
          <CapturaCamara
            onCerrar={() => setCapturando(null)}
            onCapturar={(dataUrl) => {
              if (capturando === "orden") setForm(f => ({ ...f, ordenAdjunta:"foto-camara.jpg", ordenAdjuntaDataUrl:dataUrl }));
              else setForm(f => ({ ...f, informePrevioArchivo:"foto-camara.jpg", informePrevioDataUrl:dataUrl }));
              setCapturando(null);
            }}
          />
        )}

        {/* 3 · Prestación */}
        <div style={{ fontSize:11, fontWeight:700, color:C.txl, textTransform:"uppercase", marginBottom:6 }}>3 · Prestación</div>
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:8, marginBottom:8 }}>
          <div>
            <div style={{ fontSize:10, color:C.txm, marginBottom:4 }}>Modalidad</div>
            <select value={form.modalidad} onChange={e => { const m = e.target.value; const eq = EQUIPOS.find(x => x.modalidad === m); setForm(f => ({ ...f, modalidad:m, equipoId: eq?.id || "", especialidad:"", prestacionNombre:"", lateralidad:"", hora:"" })); }} style={{ width:"100%", padding:"7px 8px", fontSize:12, border:`1px solid ${C.brd}`, borderRadius:7 }}>
              {Object.keys(MODALIDAD_LABEL).map(m => <option key={m} value={m}>{MODALIDAD_LABEL[m]}</option>)}
            </select>
          </div>
          <div>
            <div style={{ fontSize:10, color:C.txm, marginBottom:4 }}>Subespecialidad</div>
            <select value={form.especialidad} onChange={e=>setForm(f=>({...f, especialidad:e.target.value, prestacionNombre:"", lateralidad:""}))} style={{ width:"100%", padding:"7px 8px", fontSize:12, border:`1px solid ${C.brd}`, borderRadius:7 }}>
              <option value="">Seleccionar...</option>
              {especialidades.map(e => <option key={e} value={e}>{e}</option>)}
            </select>
          </div>
        </div>
        <div style={{ marginBottom:8 }}>
          <div style={{ fontSize:10, color:C.txm, marginBottom:4 }}>Prestación</div>
          <select value={form.prestacionNombre} onChange={e=>setForm(f=>({...f, prestacionNombre:e.target.value, lateralidad:""}))} disabled={!form.especialidad} style={{ width:"100%", padding:"7px 8px", fontSize:12, border:`1px solid ${C.brd}`, borderRadius:7, background:!form.especialidad?C.bg:"#fff" }}>
            <option value="">Seleccionar...</option>
            {prestacionesEspecialidad.map(p => <option key={p.nombre} value={p.nombre}>{p.nombre}</option>)}
          </select>
        </div>
        {prestSel?.lateralidad && (
          <div style={{ marginBottom:8, display:"flex", gap:6 }}>
            {["Derecha","Izquierda","Ambas"].map(l => (
              <button key={l} onClick={()=>setForm(f=>({...f, lateralidad:l}))} style={{ fontSize:11, padding:"5px 12px", borderRadius:7, border:`1px solid ${form.lateralidad===l?C.pri:C.brd}`, background:form.lateralidad===l?`${C.pri}12`:"#fff", color:form.lateralidad===l?C.pri:C.txm, cursor:"pointer" }}>{l}</button>
            ))}
          </div>
        )}
        {prestSel && (
          <div style={{ marginBottom:8, padding:"8px 10px", background:C.bg, borderRadius:7, fontSize:11, color:C.txt }}>
            Nombre final: <strong>{nombreFinal}</strong> · Códigos: {[prestSel.codigoFonasa, prestSel.codigoInterno].filter(Boolean).join(" / ") || "sin código"}
          </div>
        )}
        {consent?.requiere && (
          <div style={{ marginBottom:14, padding:"8px 10px", background:`${C.war}10`, borderRadius:7, fontSize:10, color:C.war, display:"flex", gap:6, alignItems:"flex-start" }}>
            <ShieldCheck size={12} style={{ flexShrink:0, marginTop:1 }}/>
            <span>Requiere consentimiento informado — plantilla <strong>{consent.plantilla}</strong>. Firma real pendiente (puerta etiquetada).</span>
          </div>
        )}

        {/* 4 · Diagnóstico — sospecha (texto de la orden) junto a su interpretación CIE, como pediste */}
        <div style={{ fontSize:11, fontWeight:700, color:C.txl, textTransform:"uppercase", marginBottom:6 }}>4 · Diagnóstico</div>
        <div style={{ marginBottom:8 }}>
          <div style={{ fontSize:10, color:C.txm, marginBottom:4 }}>Diagnóstico de sospecha (texto de la orden médica)</div>
          <textarea value={form.diagnosticoSospecha} onChange={e=>setForm(f=>({...f, diagnosticoSospecha:e.target.value}))} placeholder="Tal como viene escrito en la orden — a mano, computador, como sea" rows={2} style={{ width:"100%", padding:"7px 8px", fontSize:12, border:`1px solid ${C.brd}`, borderRadius:7, boxSizing:"border-box", fontFamily:"inherit", resize:"vertical" }}/>
        </div>
        <div style={{ marginBottom:16 }}>
          <div style={{ fontSize:10, color:C.txm, marginBottom:4 }}>Interpretación en CIE-10/11 (uno o más)</div>
          <SelectorCIE modalidad={form.modalidad} especialidad={form.especialidad} seleccionados={form.diagnosticos} onCambiar={(d)=>setForm(f=>({...f, diagnosticos:d}))}/>
        </div>

        {/* 5 · Fecha / hora / equipo */}
        <div style={{ fontSize:11, fontWeight:700, color:C.txl, textTransform:"uppercase", marginBottom:6 }}>5 · Fecha, hora y equipo</div>
        <div style={{ display:"grid", gridTemplateColumns:"1.1fr 0.8fr 1.1fr", gap:8, marginBottom:6 }}>
          <div>
            <div style={{ fontSize:10, color:C.txm, marginBottom:3 }}>Fecha</div>
            <input type="date" value={form.fecha} onChange={e=> e.target.value && setForm(f=>({...f, fecha:e.target.value, hora:""}))} style={{ width:"100%", padding:"7px 8px", fontSize:12, border:`1px solid ${C.brd}`, borderRadius:7, boxSizing:"border-box" }}/>
          </div>
          <div>
            <div style={{ fontSize:10, color:C.txm, marginBottom:3 }}>Hora</div>
            <select value={form.hora} onChange={e=>setForm(f=>({...f, hora:e.target.value}))} style={{ width:"100%", padding:"7px 8px", fontSize:12, border:`1px solid ${C.brd}`, borderRadius:7, boxSizing:"border-box" }}>
              <option value="">Hora...</option>
              {/* Si la hora viene de un sobrecupo (fuera de 08:00–20:00) no está en BLOQUES: se agrega para que el selector no muestre "Hora..." con una hora ya cargada */}
              {(form.hora && !BLOQUES.includes(form.hora) ? [...BLOQUES, form.hora].sort() : BLOQUES).map(h=><option key={h} value={h}>{BLOQUES.includes(h) ? h : `${h} ⚡ sobrecupo`}</option>)}
            </select>
          </div>
          <div>
            <div style={{ fontSize:10, color:C.txm, marginBottom:3 }}>Equipo</div>
            <select value={form.equipoId} onChange={e=>setForm(f=>({...f, equipoId:e.target.value}))} style={{ width:"100%", padding:"7px 8px", fontSize:12, border:`1px solid ${C.brd}`, borderRadius:7, boxSizing:"border-box" }}>
              {equiposDeModalidad.map(eq => <option key={eq.id} value={eq.id}>{eq.nombre}</option>)}
            </select>
          </div>
        </div>
        {bloqueoDestino && <div style={{ marginBottom:8, padding:"7px 10px", background:`${C.dan}10`, borderRadius:7, fontSize:10.5, color:C.dan, display:"flex", gap:6, alignItems:"center" }}><Lock size={12}/>Cupo bloqueado ({bloqueoDestino.motivo}) — elige otra hora o equipo.</div>}
        <div style={{ fontSize:10, color:C.txl, marginBottom:14 }}>{fmtLarga(form.fecha)} · calendario sin límite de fechas — solo los bloques 08:00–20:00 aparecen en el selector de hora; los sobrecupos fuera de ese horario (urgencias, hospitalizados, ambulatorio extra) se agregan desde la grilla de la agenda, no desde acá.</div>

        {/* 6 · Creatinina */}
        {necesitaCreatinina && (
          <div style={{ marginBottom:14, padding:"9px 11px", background:`${C.war}10`, borderRadius:8, fontSize:11, color:C.war }}>
            <div style={{ display:"flex", gap:6, alignItems:"flex-start", marginBottom:6 }}>
              <AlertTriangle size={13} style={{ flexShrink:0, marginTop:1 }}/>
              <span>Paciente de {edad} años + contraste: requiere función renal (creatinina).</span>
            </div>
            <label style={{ display:"flex", alignItems:"center", gap:8, cursor:"pointer" }}>
              <Paperclip size={12}/> {form.creatininaAdjunta ? form.creatininaAdjunta : "Adjuntar informe (opcional)"}
              <input type="file" style={{ display:"none" }} onChange={e => setForm(f => ({ ...f, creatininaAdjunta: e.target.files[0]?.name || null }))}/>
            </label>
            <label style={{ display:"flex", alignItems:"center", gap:6, marginTop:6, cursor:"pointer" }}>
              <input type="checkbox" checked={form.creatininaExpres} onChange={e => setForm(f => ({ ...f, creatininaExpres:e.target.checked }))}/>
              Se realizará creatinina exprés el día del examen
            </label>
          </div>
        )}

        {/* 7 · Adjuntos previos */}
        <div style={{ fontSize:11, fontWeight:700, color:C.txl, textTransform:"uppercase", marginBottom:6 }}>7 · Exámenes previos (opcional)</div>
        <div style={{ marginBottom:18, padding:"9px 11px", background:C.bg, borderRadius:8 }}>
          <div style={{ display:"flex", gap:6, marginBottom:8 }}>
            <label style={{ display:"flex", alignItems:"center", gap:8, fontSize:11, color:C.txm, cursor:"pointer", flex:1, background:"#fff", border:`1px solid ${C.brd}`, borderRadius:7, padding:"7px 9px" }}>
              <Paperclip size={13}/> {form.informePrevioArchivo ? form.informePrevioArchivo : "Adjuntar informe previo (PDF)"}
              <input type="file" style={{ display:"none" }} onChange={e => setForm(f => ({ ...f, informePrevioArchivo: e.target.files[0]?.name || null }))}/>
            </label>
            <Btn v="outline" sz="sm" icon={Camera} onClick={() => setCapturando("informe")} title="Cámara real — funciona (getUserMedia, API estándar del navegador)">Tomar foto</Btn>
            <Btn v="ghost" sz="sm" icon={Lock} dis title="Escáner físico de oficina — puerta etiquetada, misma razón que en Orden médica">Escanear (hardware)</Btn>
          </div>
          <label style={{ display:"flex", alignItems:"center", gap:8, fontSize:11, color:C.txm }}>
            <Link2 size={13}/>
            <input value={form.informePrevioLink} onChange={e=>setForm(f=>({...f, informePrevioLink:e.target.value}))} placeholder="o pega un link externo (institución donde se realizó)" style={{ flex:1, padding:"6px 8px", fontSize:11, border:`1px solid ${C.brd}`, borderRadius:6 }}/>
          </label>
        </div>

        {!form.editId && (
          <div style={{ marginBottom:12, display:"flex", gap:6, alignItems:"flex-start", fontSize:10, color:C.txl }}>
            <Lock size={11} style={{ flexShrink:0, marginTop:1 }}/>
            <span>Al guardar se enviaría confirmación automática por WhatsApp y correo — puerta etiquetada, pendiente de integración real.</span>
          </div>
        )}
        <div style={{ display:"flex", gap:8, justifyContent:"flex-end" }}>
          <Btn v="ghost" onClick={onCerrar}>{form.reagendaDesdeId ? "Volver atrás sin cambios" : "Cancelar"}</Btn>
          <Btn v="success" icon={CheckCircle2} onClick={onGuardar}>{form.editId ? "Guardar Cambios" : form.reagendaDesdeId ? "Confirmar Reagendamiento" : "Guardar Solicitud"}</Btn>
        </div>
      </div>
    </div>
  );
};

/* ═══════════════════════════ BLOQUE DE NOTAS — pieza COMPARTIDA entre las
   ~19 unidades de agenda (Imagenología, Laboratorio, Oftalmología, ORL,
   Anatomía Patológica, Cardiología, Terapia y Rehabilitación, Obstetricia,
   Psicología, Medicina Nuclear, Gastroenterología, Urología, Ginecología,
   Dermatología, Neurología, Broncopulmonología, Oncología/Radioterapia,
   Odontología...) — se construye una vez acá, se integra primero en
   Imagenología para validar el diseño, y después se propaga tal cual al
   resto (mismo criterio que ForensicWatermark/PanicTrigger).
   3 niveles inspirados en la referencia real (philaxmed):
   1. Generales — persistentes, no ligadas a fecha (protocolos, avisos fijos).
   2. Por día de la semana — recurrentes (ej. "Notas de los Sábado" se repite
      cada sábado, no solo hoy).
   3. Del día — ligadas a la fecha exacta seleccionada.
   La 4ª capa (Notas de la Cita, por orden individual) vive en PanelDetalle,
   no acá, porque es 1:1 con una orden, no con la agenda completa.
   Sin backend: vive en memoria de sesión, mismo límite honesto de siempre. */
const NotaItem = ({ nota, onEliminar }) => (
  <div style={{ background:"#fff", border:`1px solid ${C.brd}`, borderRadius:7, padding:"7px 9px", marginBottom:6 }}>
    <div style={{ fontSize:11, color:C.txt, lineHeight:1.4, whiteSpace:"pre-wrap" }}>{nota.texto}</div>
    <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginTop:4 }}>
      <span style={{ fontSize:10, color:C.txl }}>{nota.autor}{nota.autorRol ? ` · ${nota.autorRol}` : ""} · {nota.ts}</span>
      <button onClick={onEliminar} style={{ background:"none", border:"none", cursor:"pointer", padding:2 }}><X size={11} color={C.txl}/></button>
    </div>
  </div>
);
// Historial de las notas (quién escribió, quién borró). No es un log aparte:
// reutiliza la tabla `auditoria` de siempre (mismo criterio que el Historial
// del Cupo) — cada alta/baja de una nota registra una entrada con
// entidad = "nota:<tipo>:<clave>", y el botón de cada bloque muestra las
// entradas de SU entidad. Una baja guarda el texto borrado + quién lo había
// escrito originalmente (puede ser otra persona que quien lo borra).
const ACCION_NOTA_AGREGADA = "Agregó nota";
const ACCION_NOTA_ELIMINADA = "Eliminó nota";
const entidadNota = (tipo, clave) => `nota:${tipo}:${clave}`;

// Panel lateral (mismo patrón que PanelCupoVacio / Historial del Cupo). Se
// dibuja desde el componente principal, NO dentro del panel de notas: ese
// panel es sticky y crea su propio nivel de apilamiento, así que cualquier
// cosa dibujada ahí adentro quedaba tapada por los encabezados fijos de las
// grillas Día/Semana.
const PanelHistorialNotas = ({ titulo, eventos, onCerrar }) => {
  const dlg = useDialogo(onCerrar);
  return (
    <>
    {/* Fondo transparente (sin oscurecer): solo captura el clic fuera para cerrar */}
    <div onClick={onCerrar} style={{ position:"fixed", inset:0, zIndex:49 }}/>
    <div {...dlg} aria-label="Historial de notas" style={{ position:"fixed", top:0, right:0, bottom:0, width:400, maxWidth:"92vw", background:C.sfc, borderLeft:`1px solid ${C.brd}`, boxShadow:"-4px 0 20px rgba(0,0,0,0.12)", zIndex:50, display:"flex", flexDirection:"column" }}>
      <div style={{ padding:"16px 18px", borderBottom:`1px solid ${C.brd}`, display:"flex", justifyContent:"space-between", alignItems:"flex-start", gap:10 }}>
        <div style={{ minWidth:0 }}>
          <div style={{ fontSize:14, fontWeight:700, color:C.txt }}>Historial de notas</div>
          <div style={{ fontSize:11, color:C.txl, marginTop:3 }}>{titulo}</div>
        </div>
        <button onClick={onCerrar} title="Cerrar" style={{ background:"none", border:"none", cursor:"pointer", padding:4, flexShrink:0 }}><X size={18} color={C.txl}/></button>
      </div>
      <div style={{ padding:"14px 18px", overflowY:"auto", flex:1 }}>
        {eventos.length === 0 && <div style={{ fontSize:11, color:C.txl, fontStyle:"italic" }}>Sin movimientos todavía en este bloque de notas.</div>}
        {eventos.map((ev, i) => {
          const borrada = ev.accion === ACCION_NOTA_ELIMINADA;
          const col = borrada ? C.dan : C.suc;
          const nota = ev.nota || { texto:"", autor:"", ts:"" };
          return (
            <div key={ev.id} style={{ display:"flex", gap:9, paddingBottom:10, marginBottom:10, borderBottom: i === eventos.length - 1 ? "none" : `1px solid ${C.brd}` }}>
              <div style={{ width:8, height:8, borderRadius:"50%", background:col, marginTop:4, flexShrink:0 }}/>
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ display:"flex", alignItems:"center", gap:6, flexWrap:"wrap" }}>
                  <Badge c={col} sm>{ev.accion}</Badge>
                  <span style={{ fontSize:11, fontWeight:600, color:C.txt }}>{ev.actorNombre}</span>
                  {ev.actorRol && <span style={{ fontSize:10, color:C.txl }}>· {ev.actorRol}</span>}
                </div>
                <div style={{ fontSize:10, color:C.txl, marginTop:3 }}>{ev.ts}</div>
                <div style={{ fontSize:11, color:borrada ? C.txm : C.txt, marginTop:5, lineHeight:1.4, whiteSpace:"pre-wrap", wordBreak:"break-word", textDecoration: borrada ? "line-through" : "none" }}>{nota.texto}</div>
                {borrada && <div style={{ fontSize:10, color:C.txl, marginTop:3 }}>Escrita por {nota.autor}{nota.autorRol ? ` · ${nota.autorRol}` : ""} · {nota.ts}</div>}
              </div>
            </div>
          );
        })}
      </div>
    </div>
    </>
  );
};

const SubBloqueNotas = ({ titulo, sub, notas, onAgregar, onEliminar, cantEventos = 0, onVerHistorial }) => {
  const [texto, setTexto] = useState("");
  return (
    <div style={{ marginBottom:16 }}>
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", gap:6 }}>
        <div style={{ minWidth:0 }}>
          <div style={{ fontWeight:700, fontSize:12, color:C.txt, marginBottom:1 }}>{titulo}</div>
          {sub && <div style={{ fontSize:10, color:C.txl, marginBottom:7 }}>{sub}</div>}
        </div>
        <button onClick={onVerHistorial} title={`Historial: quién escribió o borró notas (${cantEventos})`} aria-label="Historial de este bloque de notas" style={{ border:"none", background:`${C.pri}12`, borderRadius:6, cursor:"pointer", padding:4, display:"flex", flexShrink:0 }}>
          <History size={14} color={C.pri}/>
        </button>
      </div>
      <div style={{ maxHeight:150, overflowY:"auto", marginBottom:6 }}>
        {notas.length === 0 && <div style={{ fontSize:10, color:C.txl, fontStyle:"italic" }}>Sin notas todavía.</div>}
        {notas.map(n => <NotaItem key={n.id} nota={n} onEliminar={() => onEliminar(n.id)}/>)}
      </div>
      <div style={{ display:"flex", gap:5 }}>
        <input value={texto} onChange={e=>setTexto(e.target.value)} onKeyDown={e => { if (e.key === "Enter" && texto.trim()) { onAgregar(texto.trim()); setTexto(""); } }} placeholder="Escribir nota..." style={{ flex:1, padding:"6px 8px", fontSize:11, border:`1px solid ${C.brd}`, borderRadius:6, boxSizing:"border-box" }}/>
        <button onClick={() => { if (texto.trim()) { onAgregar(texto.trim()); setTexto(""); } }} style={{ padding:"6px 10px", fontSize:11, fontWeight:700, background:C.pri, color:"#fff", border:"none", borderRadius:6, cursor:"pointer" }}>+</button>
      </div>
    </div>
  );
};

/* ═══════════════════════════ LEYENDA DE ESTADOS ═══════════════════════════
   Los colores de ESTADOS se usan en la grilla, en Historial y en el
   Historial del Cupo, pero nunca había un lugar que dijera qué significa
   cada uno. Va arriba del panel de notas (no abajo): es una referencia
   rápida, y las notas ya pueden crecer bastante como para que algo de
   consulta frecuente quede escondido debajo de un scroll largo. */
const LeyendaEstados = () => (
  <div style={{ background:C.panelGris, border:`1px solid ${C.brd}`, borderRadius:12, padding:"12px 14px", marginBottom:12 }}>
    <div style={{ fontSize:10, color:C.txl, marginBottom:8, fontWeight:700, textTransform:"uppercase", letterSpacing:"0.3px" }}>Estados de la Agenda</div>
    {/* flex-wrap dejaba que cada fila envolviera según el largo del label
        de esa fila — mismo problema de fondo que las columnas de la
        grilla de Día. Un grid de 2 columnas fijas alinea todo en
        columnas reales, una arriba de la otra. */}
    <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", rowGap:7, columnGap:10 }}>
      {Object.values(ESTADOS).map(est => (
        <div key={est.label} style={{ display:"flex", alignItems:"center", gap:5, minWidth:0 }}>
          <span style={{ width:8, height:8, borderRadius:"50%", background:est.color, flexShrink:0 }}/>
          <span style={{ fontSize:11, color:C.txm, whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis" }}>{est.label}</span>
        </div>
      ))}
      <div style={{ display:"flex", alignItems:"center", gap:5, minWidth:0 }} title="Cupo bloqueado: no acepta citas nuevas">
        <span style={{ width:10, height:10, borderRadius:2, background:FONDO_BLOQUEADO, border:`1px solid ${C.gridLine}`, flexShrink:0 }}/>
        <span style={{ fontSize:11, color:C.txm, whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis" }}>Bloqueado</span>
      </div>
      <div style={{ display:"flex", alignItems:"center", gap:5, minWidth:0 }} title="Cita agendada dentro de un cupo bloqueado: hay que moverla a mano">
        <span style={{ width:10, height:10, borderRadius:2, background:FONDO_BLOQUEADO, outline:`1.5px dashed ${C.dan}`, outlineOffset:-1, flexShrink:0 }}/>
        <span style={{ fontSize:11, color:C.txm, whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis" }}>Por mover</span>
      </div>
    </div>
  </div>
);

const BloqueNotas = ({ fechaSel, modalidad, notasGenerales, notasPorDiaSemana, notasPorFecha, onAgregar, onEliminar, auditoria = [], onVerHistorial }) => {
  const diaSemana = nombreDiaSemana(fechaSel);
  if (modalidad === "todas") {
    return (
      <div style={{ background:C.panelGris, border:`1px solid ${C.brd}`, borderRadius:12, padding:"16px 14px", height:"fit-content", fontSize:11, color:C.txl, lineHeight:1.5 }}>
        Las notas son propias de cada modalidad — selecciona una específica (no "Todas") en el filtro de arriba para verlas y escribir.
      </div>
    );
  }
  const claveGeneral = modalidad;
  const claveDia = `${modalidad}_${diaSemana}`;
  const claveFecha = `${modalidad}_${fechaSel}`;
  const eventosDe = (tipo, clave) => auditoria.filter(a => a.entidad === entidadNota(tipo, clave));
  const etiqueta = MODALIDAD_LABEL[modalidad];
  return (
    <div style={{ background:C.panelGris, border:`1px solid ${C.brd}`, borderRadius:12, padding:"14px 14px 6px", height:"fit-content" }}>
      <div style={{ fontSize:10, color:C.txl, marginBottom:9, fontWeight:700, textTransform:"uppercase", letterSpacing:"0.3px" }}>Notas — {etiqueta}</div>
      <SubBloqueNotas titulo="📌 Notas Generales" sub="Persistentes, propias de esta modalidad" notas={notasGenerales[claveGeneral] || []} onAgregar={(t)=>onAgregar("generales", claveGeneral, t)} onEliminar={(id)=>onEliminar("generales", claveGeneral, id)} cantEventos={eventosDe("generales", claveGeneral).length} onVerHistorial={() => onVerHistorial(entidadNota("generales", claveGeneral), `Notas Generales · ${etiqueta}`)}/>
      <SubBloqueNotas titulo={`🗓️ Notas de los ${diaSemanaPlural(diaSemana)}`} sub="Se repiten cada semana ese día, no solo hoy" notas={notasPorDiaSemana[claveDia] || []} onAgregar={(t)=>onAgregar("diaSemana", claveDia, t)} onEliminar={(id)=>onEliminar("diaSemana", claveDia, id)} cantEventos={eventosDe("diaSemana", claveDia).length} onVerHistorial={() => onVerHistorial(entidadNota("diaSemana", claveDia), `Notas de los ${diaSemanaPlural(diaSemana)} · ${etiqueta}`)}/>
      <SubBloqueNotas titulo={`Notas de ${fmtCorta(fechaSel)}`} sub="Ligadas a esta fecha exacta" notas={notasPorFecha[claveFecha] || []} onAgregar={(t)=>onAgregar("fecha", claveFecha, t)} onEliminar={(id)=>onEliminar("fecha", claveFecha, id)} cantEventos={eventosDe("fecha", claveFecha).length} onVerHistorial={() => onVerHistorial(entidadNota("fecha", claveFecha), `Notas de ${fmtCorta(fechaSel)} · ${etiqueta}`)}/>
    </div>
  );
};

/* ═══════════════════════════ COMPONENTE PRINCIPAL ═══════════════════════════ */
export default function AtencionAgendaImagenologia({ addToast }) {
  // Antes: si no venía addToast desde fuera, los avisos cadan en console.log
  // — silenciosos, por eso "el botón no respondía" al faltar un campo.
  // Ahora siempre se ve algo, tenga o no addToast conectado el host.
  const [toasts, setToasts] = useState([]);
  const toast = (msg, tipo = "info") => {
    if (addToast) addToast(msg, tipo);
    const id = `${Date.now()}-${Math.random()}`;
    setToasts(prev => [...prev, { id, msg, tipo }]);
    setTimeout(() => setToasts(prev => prev.filter(t => t.id !== id)), 4200);
  };
  const relojEnVivo = useRelojEnVivo();

  const [usuarioActual, setUsuarioActual] = useState(USUARIOS_DEMO[0]);
  const [ordenes, setOrdenes] = useState(genOrdenes);
  const [medicosReferentes, setMedicosReferentes] = useState(MEDICOS_REFERENTES_SEED);
  const agregarMedicoReferente = (datos) => {
    const nombreCompleto = `${datos.tratamiento} ${datos.nombres} ${datos.apellidoPaterno} ${datos.apellidoMaterno}`.trim();
    const nuevo = { id:`mr-${Date.now()}`, origen:"externo", cut:null, nombreCompleto, especialidad: datos.especialidad || "No especificada", rut: datos.rut };
    setMedicosReferentes(prev => [...prev, nuevo]);
    registrarAuditoria("Registró médico externo", nuevo.id, `${nombreCompleto}${datos.especialidad ? ` — ${datos.especialidad}` : ""}`);
    return nuevo;
  };
  const [auditoria, setAuditoria] = useState([]);
  const [vista, setVista] = useState("dia");
  const [modalidadFoco, setModalidadFoco] = useState("MR");
  const [equipoFocoId, setEquipoFocoId] = useState(EQUIPOS.find(e => e.modalidad === "MR").id);
  const [fechaSel, setFechaSel] = useState(HOY);
  // El panel de detalle abría con una "foto" de la orden y la seguía mostrando
  // igual aunque la orden cambiara después (Modificar Cita, Reagendar, notas):
  // tras reagendar, el panel seguía mostrando la orden como "Confirmada" con
  // sus botones (Cancelar, etc.) activos sobre una orden que ya estaba
  // reagendada. Ahora lo que se muestra se resuelve SIEMPRE desde `ordenes`
  // por id — una sola fuente de verdad. El setter y los demás usos de
  // `ordenSel` no cambian.
  const [ordenSelSnapshot, setOrdenSel] = useState(null);
  const ordenSel = ordenSelSnapshot ? (ordenes.find(o => o.id === ordenSelSnapshot.id) || ordenSelSnapshot) : null;
  const [cupoVacioSel, setCupoVacioSel] = useState(null); // {equipoId,fecha,hora} — Historial del Cupo de un slot vacío
  const [movimientosCupo, setMovimientosCupo] = useState([]); // rastro de drag&drop, ver moverOrdenPorDrag()
  const [bloqueos, setBloqueos] = useState([]); // bloqueos de cupos (ver bloque BLOQUEO DE CUPOS)
  const [bloqueoSelCupo, setBloqueoSelCupo] = useState(null); // cupo en el que se hizo clic (para "Cupo seleccionado" al desbloquear)
  const [bloqueoSelId, setBloqueoSelId] = useState(null); // panel de detalle de un bloqueo
  const [formBloqueo, setFormBloqueo] = useState(null); // modal Bloquear agenda
  const bloqueoEn = (equipoId, fecha, hora) => bloqueoDeCupo(bloqueos, equipoId, fecha, hora);
  const [historialNotasSel, setHistorialNotasSel] = useState(null); // {entidad, titulo} — panel lateral de historial de notas
  const [moviendoOrden, setMoviendoOrden] = useState(null); // orden que se está moviendo con "Mover cita"
  const [cancelandoOrden, setCancelandoOrden] = useState(null); // orden pendiente de motivo antes de cancelar
  const [form, setForm] = useState(null);
  const [filtros, setFiltros] = useState({ modalidad:"todas", estado:"todos", q:"" });
  const [pagina, setPagina] = useState(1);
  const [notasGenerales, setNotasGenerales] = useState({});
  const [sobrecuposAM, setSobrecuposAM] = useState({});
  const [sobrecuposPM, setSobrecuposPM] = useState({});

  const agregarSobrecupo = (tipo, equipoId, fecha) => {
    const HORAS = tipo === "am" ? HORAS_URGENCIA_AM : HORAS_URGENCIA_PM;
    const key = `${equipoId}_${fecha}`;
    const mapaActual = tipo === "am" ? sobrecuposAM : sobrecuposPM;
    const setFn = tipo === "am" ? setSobrecuposAM : setSobrecuposPM;
    const actuales = mapaActual[key] || [];
    const siguiente = HORAS[actuales.length];
    if (!siguiente) { toast("No quedan más horas de sobrecupo disponibles en esa franja", "warning"); return; }
    setFn(prev => ({ ...prev, [key]: [...(prev[key] || []), siguiente] }));
    const eq = EQUIPOS.find(e => e.id === equipoId);
    registrarAuditoria("Agregó sobrecupo", equipoId, `Sobrecupo ${siguiente} (${tipo === "am" ? "antes de apertura" : "después de cierre"}) para ${eq?.nombre} el ${fecha}`);
    toast(`Sobrecupo agregado a las ${siguiente}`, "success");
  };
  const [notasPorDiaSemana, setNotasPorDiaSemana] = useState({});
  const [notasPorFecha, setNotasPorFecha] = useState({});

  const agregarNota = (tipo, clave, texto) => {
    const nota = { id:`N-${Date.now()}`, texto, autor:nombreUsuario(usuarioActual), autorRol:usuarioActual.rolLabel, ts: relojEnVivo.toLocaleString("es-CL", { day:"2-digit", month:"2-digit", hour:"2-digit", minute:"2-digit" }) };
    if (tipo === "generales") setNotasGenerales(prev => ({ ...prev, [clave]: [nota, ...(prev[clave] || [])] }));
    if (tipo === "diaSemana") setNotasPorDiaSemana(prev => ({ ...prev, [clave]: [nota, ...(prev[clave] || [])] }));
    if (tipo === "fecha") setNotasPorFecha(prev => ({ ...prev, [clave]: [nota, ...(prev[clave] || [])] }));
    registrarAuditoria(ACCION_NOTA_AGREGADA, entidadNota(tipo, clave), `«${texto}»`, { nota:{ texto:nota.texto, autor:nota.autor, autorRol:nota.autorRol, ts:nota.ts } });
  };
  const eliminarNota = (tipo, clave, id) => {
    // Antes la nota se filtraba y desaparecía sin dejar rastro del texto ni de
    // quién la borró. Se busca ANTES de filtrar para poder guardar qué se borró.
    const mapa = tipo === "generales" ? notasGenerales : tipo === "diaSemana" ? notasPorDiaSemana : notasPorFecha;
    const nota = (mapa[clave] || []).find(n => n.id === id);
    if (tipo === "generales") setNotasGenerales(prev => ({ ...prev, [clave]: (prev[clave] || []).filter(n => n.id !== id) }));
    if (tipo === "diaSemana") setNotasPorDiaSemana(prev => ({ ...prev, [clave]: (prev[clave] || []).filter(n => n.id !== id) }));
    if (tipo === "fecha") setNotasPorFecha(prev => ({ ...prev, [clave]: (prev[clave] || []).filter(n => n.id !== id) }));
    if (nota) registrarAuditoria(ACCION_NOTA_ELIMINADA, entidadNota(tipo, clave), `«${nota.texto}» — escrita por ${nota.autor} (${nota.ts})`, { nota:{ texto:nota.texto, autor:nota.autor, autorRol:nota.autorRol, ts:nota.ts } });
  };
  const PAGE_SIZE = 12;
  const [mesVista, setMesVista] = useState(7);
  const [anioVista, setAnioVista] = useState(2026);
  const matrizMes = useMemo(() => generarMatrizMes(anioVista, mesVista), [anioVista, mesVista]);
  const cambiarMesVista = (delta) => {
    let m = mesVista + delta, a = anioVista;
    if (m > 12) { m = 1; a++; } else if (m < 1) { m = 12; a--; }
    setMesVista(m); setAnioVista(a);
  };
  const NOMBRES_MES = ["Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"];

  // Mini calendario del sidebar: en vista "mes" reusa la navegación que ya
  // existía (anioVista/mesVista); en semana/día, mueve fechaSel un mes
  // completo, con el día acotado al largo real del mes destino (nunca "31
  // de febrero"). Seleccionar un día imita lo que ya hace la vista "Mes"
  // grande: fija la fecha y salta a "Día" — pero solo si el punto de
  // partida era "Mes"; si ya se estaba en semana/día, se queda ahí.
  const cambiarMesSidebar = (delta) => {
    if (vista === "mes") { cambiarMesVista(delta); return; }
    setFechaSel(f => {
      const [a, m, d] = f.split("-").map(Number);
      let mn = m + delta, an = a;
      if (mn > 12) { mn = 1; an++; } else if (mn < 1) { mn = 12; an--; }
      return isoDate(an, mn, Math.min(d, diasEnMes(an, mn)));
    });
  };
  const seleccionarDiaSidebar = (fecha) => {
    setFechaSel(fecha);
    if (vista === "mes") setVista("dia");
  };

  // Bug real: mesVista/anioVista son su propio estado (para poder hojear
  // meses en la vista Mes sin mover fechaSel de Semana/Día) — pero nunca se
  // sincronizaban AL ENTRAR a Mes, así que si fechaSel estaba en septiembre
  // y se hacía clic en la pestaña "Mes", se seguía mostrando julio (el
  // valor inicial de useState). Se sincroniza una sola vez, justo al pasar
  // de otra vista a "mes" — navegar meses ya adentro de Mes sigue sin tocar
  // fechaSel, eso no cambia.
  const irAVista = (id) => {
    if (id === "mes" && vista !== "mes") {
      const [a, m] = fechaSel.split("-").map(Number);
      setAnioVista(a); setMesVista(m);
    }
    setVista(id);
  };

  // La cinta de días (vista Día) no muestra barra de scroll, así que el día
  // seleccionado tiene que quedar a la vista solo: se centra cada vez que cambia
  // fechaSel (o al entrar a Día). El cálculo es sobre la propia cinta —
  // scrollIntoView movería también la página completa.
  const cintaDiasRef = useRef(null);
  useEffect(() => {
    if (vista !== "dia") return;
    const cinta = cintaDiasRef.current;
    const activo = cinta ? cinta.querySelector("[data-pill-activo]") : null;
    if (!cinta || !activo) return;
    const rc = cinta.getBoundingClientRect(), ra = activo.getBoundingClientRect();
    const izq = cinta.scrollLeft + (ra.left - rc.left) - (rc.width - ra.width) / 2;
    cinta.scrollTo({ left: Math.max(0, izq), behavior: "smooth" });
  }, [vista, fechaSel]);

  const equipoFoco = EQUIPOS.find(e => e.id === equipoFocoId) || EQUIPOS[0];

  const pacientesRegistro = useMemo(() => {
    const porCup = {};
    ordenes.forEach(o => { if (!porCup[o.paciente.cup]) porCup[o.paciente.cup] = o.paciente; });
    return Object.values(porCup);
  }, [ordenes]);

  // `extra` (opcional): campos estructurados que el texto de `detalle` no puede
  // llevar bien (ej. la nota completa de un evento de notas). Las 3 llamadas
  // existentes de 3 argumentos no cambian.
  const registrarAuditoria = (accion, entidad, detalle, extra = {}) => {
    const ts = new Date().toLocaleString("es-CL", { day:"2-digit", month:"2-digit", year:"numeric", hour:"2-digit", minute:"2-digit", second:"2-digit" });
    setAuditoria(prev => [{ id:`AUD-${prev.length + 1}`, ts, actorCUT:usuarioActual.cut, actorNombre:nombreUsuario(usuarioActual), actorRol:usuarioActual.rolLabel, accion, entidad, detalle, ...extra }, ...prev]);
  };
  const cambiarUsuario = (cut) => setUsuarioActual(USUARIOS_DEMO.find(u => u.cut === cut));
  const cambiarModalidadFoco = (m) => {
    setModalidadFoco(m);
    if (m === "todas") return;
    const eq = EQUIPOS.find(e => e.modalidad === m);
    if (eq) setEquipoFocoId(eq.id);
  };

  const kpis = useMemo(() => {
    const hoy = ordenes.filter(o => o.fecha === HOY && !ESTADOS_LIBERAN_CUPO.has(o.estado));
    return {
      ordenesHoy: hoy.length,
      enEspera: hoy.filter(o => o.estado === "en_espera").length,
      consentimientosPendientes: ordenes.filter(o => o.requiereConsentimiento && o.consentimientoEstado !== "completado" && !ESTADOS_LIBERAN_CUPO.has(o.estado) && o.fecha >= HOY).length,
      creatininaPendiente: ordenes.filter(o => o.requiereCreatinina && !o.creatininaAdjunta && !o.creatininaExpres && !ESTADOS_LIBERAN_CUPO.has(o.estado) && o.fecha >= HOY).length,
    };
  }, [ordenes]);

  const ordenesPorCeldaDia = useMemo(() => {
    const map = {};
    ordenes.filter(o => o.fecha === fechaSel && !ESTADOS_LIBERAN_CUPO.has(o.estado)).forEach(o => { map[`${o.equipoId}_${o.hora}`] = o; });
    return map;
  }, [ordenes, fechaSel]);

  const listaFiltrada = useMemo(() => {
    return ordenes.filter(o => {
      if (filtros.modalidad !== "todas" && o.modalidad !== filtros.modalidad) return false;
      if (filtros.estado !== "todos" && o.estado !== filtros.estado) return false;
      if (filtros.q) {
        const q = filtros.q.toLowerCase();
        const ok = nombreCompletoPaciente(o.paciente).toLowerCase().includes(q) || o.paciente.rut.includes(q) || (o.acc || "").toLowerCase().includes(q);
        if (!ok) return false;
      }
      return true;
    }).sort((a, b) => a.fecha === b.fecha ? a.hora.localeCompare(b.hora) : b.fecha.localeCompare(a.fecha));
  }, [ordenes, filtros]);
  const totalPaginas = Math.max(1, Math.ceil(listaFiltrada.length / PAGE_SIZE));
  const listaPagina = listaFiltrada.slice((pagina - 1) * PAGE_SIZE, pagina * PAGE_SIZE);

  // security.config.js (audit.criticalEvents) incluye "view_imaging_report"
  // y "access_patient_history" — ver un dato clínico ya es auditable, no
  // solo modificarlo. "Vista" = abrir el detalle de una orden o el
  // historial de un cupo vacío (ahí también se ven pacientes anteriores,
  // ver verCeldaVacia más abajo) — no cuenta solo ver nombres en la
  // grilla ni tener la tabla de Agendamientos abierta, sería ruido sin
  // valor real (cientos de eventos por sesión). Antes esto no existía en
  // ningún lado — abrir un detalle para solo mirarlo no quedaba
  // registrado (punto 1.9 de Sincronizacion_Satelites_MAIN.md).
  const verDetalleOrden = (orden) => {
    setOrdenSel(orden);
    registrarAuditoria(ACCION_VISTA_ORDEN, orden.id, `Abrió el detalle de ${nombreCompletoPaciente(orden.paciente)} — ${orden.nombreFinal}`);
  };

  const cambiarEstado = (id, nuevoEstado, msg, accionLabel, extra = {}) => {
    setOrdenes(prev => prev.map(o => o.id !== id ? o : { ...o, estado:nuevoEstado, ...extra }));
    setOrdenSel(prev => (prev && prev.id === id) ? { ...prev, estado:nuevoEstado, ...extra } : prev);
    registrarAuditoria(accionLabel, id, msg);
    toast(msg, "success");
  };

  // Los 3 caminos (recepción / tótem / portal paciente) activan el mismo
  // estado "en_espera" — solo cambia el canal registrado para trazabilidad.
  const activarLlegada = (orden, canal) => {
    const etiqueta = CANALES_LLEGADA[canal].label;
    cambiarEstado(orden.id, "en_espera", `Activó la llegada de ${nombreCompletoPaciente(orden.paciente)} — canal: ${etiqueta}`, "Activó llegada", { canalLlegada: canal });
  };

  /* ── Arrastrar y soltar (HTML5 nativo, sin librerías) ──────────────────
     Mueve la MISMA orden a otro bloque/equipo — distinto del botón formal
     "Reagendar Cita", que a propósito crea una orden nueva y deja la
     original en estado "reagendada" para trazabilidad. Este es el gesto
     rápido tipo Google Calendar: mismo id, mismo ACC/OT/notas, solo
     cambian fecha/hora/equipo. Solo se permite si el estado todavía no
     avanzó más allá de Confirmado — no tiene sentido arrastrar algo que
     ya está En Espera/Atendido. */
  const [arrastrando, setArrastrando] = useState(null); // id de la orden que se está arrastrando
  const [celdaSobrevolada, setCeldaSobrevolada] = useState(null); // `${equipoId}_${fecha}_${hora}` bajo el cursor

  const moverOrdenPorDrag = (ordenId, nuevoEquipoId, nuevaFecha, nuevaHora, via = "arrastrar") => {
    const orden = ordenes.find(o => o.id === ordenId);
    if (!orden) return;
    if (orden.equipoId === nuevoEquipoId && orden.fecha === nuevaFecha && orden.hora === nuevaHora) return; // soltó en el mismo lugar
    const equipoNuevo = EQUIPOS.find(e => e.id === nuevoEquipoId);
    // Bug real: en Día con "Todas las modalidades" se ven equipos de distinta
    // modalidad en la misma grilla — sin este chequeo, se podía arrastrar una
    // orden de RM a un equipo de TAC. moverOrdenPorDrag actualiza `modalidad`
    // al soltar, pero `prestacion` (el catálogo real) se queda igual —
    // quedaba una orden con modalidad="CT" y prestacion.modalidad="MR".
    if (equipoNuevo && equipoNuevo.modalidad !== orden.modalidad) {
      toast(`No se puede mover: "${orden.nombreFinal}" es de ${MODALIDAD_LABEL[orden.modalidad]}, y ${equipoNuevo.nombre} es de ${MODALIDAD_LABEL[equipoNuevo.modalidad]}`, "warning");
      return;
    }
    if (bloqueoEn(nuevoEquipoId, nuevaFecha, nuevaHora)) { toast("Ese cupo está bloqueado — no se pueden mover citas ahí", "warning"); return; }
    const ocupado = ordenes.some(o => o.id !== ordenId && o.equipoId === nuevoEquipoId && o.fecha === nuevaFecha && o.hora === nuevaHora && !ESTADOS_LIBERAN_CUPO.has(o.estado));
    if (ocupado) { toast("Ese bloque ya está ocupado — no se puede soltar ahí", "warning"); return; }
    const detalle = `${nombreCompletoPaciente(orden.paciente)}: ${orden.fecha} ${orden.hora} (${orden.equipoId}) → ${nuevaFecha} ${nuevaHora} (${equipoNuevo?.nombre || nuevoEquipoId})`;
    // Drag&drop muta fecha/hora/equipoId de la MISMA orden (a propósito —
    // es el atajo rápido, distinto del botón formal "Reagendar Cita" que
    // crea una orden nueva). Sin este registro, el cupo de ORIGEN se queda
    // sin ninguna orden que lo referencie y su historial desaparece sin
    // dejar rastro. Sin motivo a propósito — es el gesto rápido tipo
    // Google Calendar, pedir motivo acá le quitaría la velocidad que tiene
    // hoy (decisión explícita: motivo solo al cancelar).
    setMovimientosCupo(prev => [{
      id: `MOV-${Date.now()}`,
      via,
      ordenId,
      pacienteSnapshot: orden.paciente, nombreFinalSnapshot: orden.nombreFinal,
      equipoOrigenId: orden.equipoId, fechaOrigen: orden.fecha, horaOrigen: orden.hora,
      equipoDestinoId: nuevoEquipoId, fechaDestino: nuevaFecha, horaDestino: nuevaHora,
      ts: new Date().toLocaleString("es-CL", { day:"2-digit", month:"2-digit", year:"numeric", hour:"2-digit", minute:"2-digit", second:"2-digit" }),
      actorNombre: nombreUsuario(usuarioActual), actorRol: usuarioActual.rolLabel,
    }, ...prev]);
    setOrdenes(prev => prev.map(o => o.id !== ordenId ? o : {
      ...o, equipoId:nuevoEquipoId, fecha:nuevaFecha, hora:nuevaHora, modalidad:equipoNuevo?.modalidad || o.modalidad,
      // Antes esto no se tocaba acá — "Reagendado por" solo se poblaba en
      // el reagendamiento formal (que crea una orden nueva), nunca en
      // drag&drop (que muta la misma orden). agendadoOriginalmentePor* NO
      // se toca — sigue apuntando a quien inició la reserva de verdad.
      agendadoPorCUT: usuarioActual.cut, agendadoPorNombre: nombreUsuario(usuarioActual),
    }));
    registrarAuditoria(via === "mover" ? "Movió cita" : "Reagendó arrastrando y soltando", ordenId, detalle);
    toast("Cita movida", "success");
    return true;
  };

  // Props comunes para que cualquier celda de la grilla (ocupada = origen
  // arrastrable, vacía = destino soltable) tenga el mismo comportamiento,
  // sin repetir la misma lógica en Semana y Día por separado.
  const dragOrigenProps = (orden) => (!["agendado","confirmado"].includes(orden.estado) ? {} : {
    draggable: true,
    onDragStart: (e) => { setArrastrando(orden.id); e.dataTransfer.effectAllowed = "move"; e.dataTransfer.setData("text/plain", orden.id); },
    onDragEnd: () => { setArrastrando(null); setCeldaSobrevolada(null); },
  });
  const dragDestinoProps = (equipoId, fecha, hora) => {
    if (bloqueoEn(equipoId, fecha, hora)) {
      // zona bloqueada: no acepta soltar citas. El cursor pasa a "no permitido" y la celda se
      // marca en rojo mientras se arrastra encima (antes no pasaba nada visible).
      const keyB = `${equipoId}_${fecha}_${hora}`;
      return {
        onDragOver: (e) => { if (arrastrando) { e.dataTransfer.dropEffect = "none"; setCeldaSobrevolada(keyB); } },
        onDragLeave: () => { setCeldaSobrevolada(prev => (prev === keyB ? null : prev)); },
      };
    }
    const key = `${equipoId}_${fecha}_${hora}`;
    return {
      onDragOver: (e) => { if (arrastrando) { e.preventDefault(); setCeldaSobrevolada(key); } },
      onDragLeave: () => { setCeldaSobrevolada(prev => (prev === key ? null : prev)); },
      onDrop: (e) => { e.preventDefault(); const id = e.dataTransfer.getData("text/plain") || arrastrando; if (id) moverOrdenPorDrag(id, equipoId, fecha, hora); setArrastrando(null); setCeldaSobrevolada(null); },
    };
  };

  const abrirNuevaSolicitud = (prefill = {}) => setForm({
    editId: prefill.editId || null, reagendaDesdeId: prefill.reagendaDesdeId || null,
    pacienteCup: prefill.pacienteCup || null, nombres: prefill.nombres || "", apellidoPaterno: prefill.apellidoPaterno || "", apellidoMaterno: prefill.apellidoMaterno || "", rut: prefill.rut || "", fechaNacimiento: prefill.fechaNacimiento || "",
    telefono1: prefill.telefono1 || "", telefono2: prefill.telefono2 || "", correo: prefill.correo || "",
    ordenAdjunta: prefill.ordenAdjunta || null, medicoSolicitante: prefill.medicoSolicitante || "", medicoSolicitanteId: prefill.medicoSolicitanteId || null, fechaEmisionOrden: prefill.fechaEmisionOrden || HOY, diagnosticoSospecha: prefill.diagnosticoSospecha || "",
    modalidad: prefill.modalidad || "MR", especialidad: prefill.especialidad || "", prestacionNombre: prefill.prestacionNombre || "", lateralidad: prefill.lateralidad || "",
    equipoId: prefill.equipoId || EQUIPOS.find(e => e.modalidad === (prefill.modalidad || "MR"))?.id,
    diagnosticos: prefill.diagnosticos || [], fecha: prefill.fecha || HOY, hora: prefill.hora || "",
    creatininaAdjunta: prefill.creatininaAdjunta || null, creatininaExpres: prefill.creatininaExpres || false,
    informePrevioArchivo: prefill.informePrevioArchivo || null, informePrevioLink: prefill.informePrevioLink || "",
  });

  // Reemplaza el onClick directo a abrirNuevaSolicitud() en las celdas
  // vacías de la grilla. Si el cupo nunca tuvo actividad, el comportamiento
  // es IDÉNTICO al de antes (directo a Nueva Solicitud, sin click de más).
  // Si tuvo, primero muestra el Historial del Cupo — caso "crítico" de la
  // guía UX-UI (sección 16): un cupo disponible puede tener historia.
  const abrirBloqueo = () => setFormBloqueo({ equipoId: modalidadFoco === "todas" ? EQUIPOS[0].id : equipoFocoId, fechaDesde:fechaSel, fechaHasta:fechaSel, horario:"dia", horaDesde:BLOQUES[0], horaHasta:BLOQUES[BLOQUES.length - 1], motivoTipo:"", motivoDetalle:"" });
  const guardarBloqueo = () => {
    const f = formBloqueo;
    if (!f.motivoTipo) { toast("Selecciona el motivo del bloqueo", "warning"); return; }
    if (f.motivoTipo === "Otro" && !f.motivoDetalle.trim()) { toast("Describe el motivo (elegiste «Otro»)", "warning"); return; }
    if (f.fechaHasta < f.fechaDesde) { toast("La fecha hasta no puede ser anterior a la fecha desde", "warning"); return; }
    const horaDesde = f.horario === "dia" ? "00:00" : f.horaDesde;
    const horaHasta = f.horario === "dia" ? "23:59" : f.horario === "cupo" ? f.horaDesde : f.horaHasta;
    if (horaHasta < horaDesde) { toast("La hora hasta no puede ser anterior a la hora desde", "warning"); return; }
    const nuevo = { id:`BLQ-${Date.now()}`, activo:true, equipoId:f.equipoId, fechaDesde:f.fechaDesde, fechaHasta:f.fechaHasta, horaDesde, horaHasta, motivoTipo:f.motivoTipo, motivo: f.motivoTipo === "Otro" ? f.motivoDetalle.trim() : (f.motivoDetalle.trim() ? `${f.motivoTipo} — ${f.motivoDetalle.trim()}` : f.motivoTipo), actorNombre:nombreUsuario(usuarioActual), actorRol:usuarioActual.rolLabel, ts:new Date().toLocaleString("es-CL", { day:"2-digit", month:"2-digit", year:"numeric", hour:"2-digit", minute:"2-digit", second:"2-digit" }) };
    const eq = EQUIPOS.find(e => e.id === f.equipoId);
    const porMover = citasEnBloqueo(ordenes, nuevo).length;
    setBloqueos(prev => [nuevo, ...prev]);
    registrarAuditoria("Bloqueó agenda", nuevo.id, `${eq?.nombre} · ${textoFechasBloqueo(nuevo)} · ${textoHorarioBloqueo(nuevo)} — motivo: ${nuevo.motivo}${porMover ? ` — ${porMover} cita(s) por mover a mano` : ""}`);
    toast(porMover ? `Bloqueo creado — ${porMover} cita(s) quedaron dentro de la zona: muévelas a mano` : "Bloqueo creado", porMover ? "warning" : "success");
    setFormBloqueo(null);
  };
  const quitarBloqueo = (b, lib) => {
    const total = lib.fechaDesde <= b.fechaDesde && lib.fechaHasta >= b.fechaHasta && lib.horaDesde <= b.horaDesde && lib.horaHasta >= b.horaHasta;
    const nuevaLib = { ...lib, por:nombreUsuario(usuarioActual), rol:usuarioActual.rolLabel, ts:new Date().toLocaleString("es-CL", { day:"2-digit", month:"2-digit", year:"numeric", hour:"2-digit", minute:"2-digit", second:"2-digit" }) };
    setBloqueos(prev => prev.map(x => x.id === b.id ? { ...x, activo: total ? false : x.activo, liberaciones:[...(x.liberaciones || []), nuevaLib] } : x));
    const eq = EQUIPOS.find(e => e.id === b.equipoId);
    registrarAuditoria(total ? "Quitó bloqueo" : "Quitó bloqueo parcial", b.id, `${eq?.nombre} · ${textoFechasBloqueo(nuevaLib)} · ${textoHorarioBloqueo(nuevaLib)} (bloqueo original: ${textoFechasBloqueo(b)} · ${textoHorarioBloqueo(b)} — motivo: ${b.motivo})`);
    toast(total ? "Bloqueo quitado" : "Parte del bloqueo quitada — el resto sigue bloqueado", "success");
    setBloqueoSelId(null);
  };
  const verCeldaVacia = (equipoId, fecha, hora) => {
    const bq = bloqueoEn(equipoId, fecha, hora);
    if (bq) { setBloqueoSelCupo({ fecha, hora }); setBloqueoSelId(bq.id); return; }
    const hist = historialDeCupo(ordenes, movimientosCupo, auditoria, equipoId, fecha, hora, null, bloqueos);
    if (hist.length === 0) {
      const eq = EQUIPOS.find(e => e.id === equipoId);
      abrirNuevaSolicitud({ modalidad: eq?.modalidad, equipoId, fecha, hora });
      return;
    }
    // Acá sí se ven pacientes anteriores del cupo (TimelineCupo) — es una
    // vista de datos de pacientes distintos al del flujo actual, mismo
    // criterio que verDetalleOrden. Solo se registra cuando HAY historial
    // que mostrar: si está vacío va directo a Nueva Solicitud y no se ve
    // ningún dato de paciente, no hay nada que auditar.
    const eq = EQUIPOS.find(e => e.id === equipoId);
    registrarAuditoria(ACCION_VISTA_CUPO, `${equipoId}_${fecha}_${hora}`, `Abrió el historial del cupo ${eq?.nombre || equipoId} · ${fecha} ${hora} (${hist.length} ocupación${hist.length === 1 ? "" : "es"} anterior${hist.length === 1 ? "" : "es"})`);
    setCupoVacioSel({ equipoId, fecha, hora });
  };

  const abrirModificarSolicitud = (orden) => abrirNuevaSolicitud({
    editId: orden.id, pacienteCup: orden.paciente.cup, nombres: orden.paciente.nombres, apellidoPaterno: orden.paciente.apellidoPaterno, apellidoMaterno: orden.paciente.apellidoMaterno, rut: orden.paciente.rut, fechaNacimiento: orden.paciente.fechaNacimiento,
    telefono1: orden.paciente.telefono1 || "", telefono2: orden.paciente.telefono2 || "", correo: orden.paciente.correo || "",
    ordenAdjunta: orden.ordenMedica.adjunta ? "documento.pdf" : null, medicoSolicitante: orden.ordenMedica.medicoSolicitante, medicoSolicitanteId: orden.ordenMedica.medicoSolicitanteId || null, fechaEmisionOrden: orden.ordenMedica.fechaEmision, diagnosticoSospecha: orden.ordenMedica.diagnosticoSospecha,
    modalidad: orden.modalidad, especialidad: orden.prestacion.especialidad, prestacionNombre: orden.prestacion.nombre, lateralidad: orden.lateralidadSel || "",
    equipoId: orden.equipoId, diagnosticos: orden.diagnosticos, fecha: orden.fecha, hora: orden.hora,
    creatininaAdjunta: orden.creatininaAdjunta || null, creatininaExpres: !!orden.creatininaExpres,
    informePrevioArchivo: orden.adjuntosPrevios?.archivo || null, informePrevioLink: orden.adjuntosPrevios?.link || "",
  });

  // No modifica la orden original al abrir — solo se toca al GUARDAR. Cerrar
  // el modal sin guardar es, por diseño, la opción de "volver atrás" — mismo
  // patrón que reagendar() en AtencionMedicaAgenda.jsx.
  const abrirReagendarSolicitud = (orden) => abrirNuevaSolicitud({
    reagendaDesdeId: orden.id, pacienteCup: orden.paciente.cup, nombres: orden.paciente.nombres, apellidoPaterno: orden.paciente.apellidoPaterno, apellidoMaterno: orden.paciente.apellidoMaterno, rut: orden.paciente.rut, fechaNacimiento: orden.paciente.fechaNacimiento,
    telefono1: orden.paciente.telefono1 || "", telefono2: orden.paciente.telefono2 || "", correo: orden.paciente.correo || "",
    ordenAdjunta: orden.ordenMedica.adjunta ? "documento.pdf" : null, medicoSolicitante: orden.ordenMedica.medicoSolicitante, medicoSolicitanteId: orden.ordenMedica.medicoSolicitanteId || null, fechaEmisionOrden: orden.ordenMedica.fechaEmision, diagnosticoSospecha: orden.ordenMedica.diagnosticoSospecha,
    modalidad: orden.modalidad, especialidad: orden.prestacion.especialidad, prestacionNombre: orden.prestacion.nombre, lateralidad: orden.lateralidadSel || "",
    equipoId: orden.equipoId, diagnosticos: orden.diagnosticos, fecha: HOY, hora:"",
    informePrevioArchivo: orden.adjuntosPrevios?.archivo || null, informePrevioLink: orden.adjuntosPrevios?.link || "",
  });

  const agregarNotaCita = (ordenId, texto) => {
    const nota = { id:`N-${Date.now()}`, texto, autor:nombreUsuario(usuarioActual), autorRol:usuarioActual.rolLabel, ts: relojEnVivo.toLocaleString("es-CL", { day:"2-digit", month:"2-digit", hour:"2-digit", minute:"2-digit" }) };
    setOrdenes(prev => prev.map(o => o.id !== ordenId ? o : { ...o, notasCita:[nota, ...(o.notasCita||[])] }));
    registrarAuditoria(ACCION_NOTA_AGREGADA, `notaCita:${ordenId}`, `«${texto}»`, { nota:{ texto:nota.texto, autor:nota.autor, autorRol:nota.autorRol, ts:nota.ts } });
    setOrdenSel(prev => (prev && prev.id === ordenId) ? { ...prev, notasCita:[nota, ...(prev.notasCita||[])] } : prev);
  };
  const eliminarNotaCita = (ordenId, notaId) => {
    const notaBorrada = (ordenes.find(o => o.id === ordenId)?.notasCita || []).find(n => n.id === notaId);
    if (notaBorrada) registrarAuditoria(ACCION_NOTA_ELIMINADA, `notaCita:${ordenId}`, `«${notaBorrada.texto}» — escrita por ${notaBorrada.autor} (${notaBorrada.ts})`, { nota:{ texto:notaBorrada.texto, autor:notaBorrada.autor, autorRol:notaBorrada.autorRol, ts:notaBorrada.ts } });
    setOrdenes(prev => prev.map(o => o.id !== ordenId ? o : { ...o, notasCita:(o.notasCita||[]).filter(n => n.id !== notaId) }));
    setOrdenSel(prev => (prev && prev.id === ordenId) ? { ...prev, notasCita:(prev.notasCita||[]).filter(n => n.id !== notaId) } : prev);
  };

  const guardarNuevaSolicitud = () => {
    if (!form.pacienteCup) { toast("Busca un paciente existente o registra uno nuevo", "warning"); return; }
    if (form.pacienteCup === "NUEVO" && (!form.nombres || !form.rut.trim() || !form.fechaNacimiento)) { toast("Completa nombre, RUT y fecha de nacimiento del paciente nuevo", "warning"); return; }
    if (form.pacienteCup === "NUEVO" && !form.telefono1.trim() && !form.telefono2.trim() && !form.correo.trim()) { toast("Registra al menos un teléfono o un correo de contacto", "warning"); return; }
    if (!form.prestacionNombre || !form.hora) { toast("Selecciona la prestación y la hora", "warning"); return; }
    const prestSel = CATALOGO_PRESTACIONES.find(p => p.modalidad === form.modalidad && p.nombre === form.prestacionNombre);
    if (prestSel.lateralidad && !form.lateralidad) { toast("Esta prestación requiere indicar lateralidad", "warning"); return; }
    const origenEdit = form.editId ? ordenes.find(o => o.id === form.editId) : null;
    const mismoSlotQueAntes = origenEdit && origenEdit.equipoId === form.equipoId && origenEdit.fecha === form.fecha && origenEdit.hora === form.hora;
    if (!mismoSlotQueAntes && bloqueoEn(form.equipoId, form.fecha, form.hora)) { toast("Ese cupo está bloqueado — elige otro horario", "warning"); return; }
    const ocupado = ordenes.some(o => o.equipoId === form.equipoId && o.fecha === form.fecha && o.hora === form.hora && !ESTADOS_LIBERAN_CUPO.has(o.estado) && o.id !== form.editId && o.id !== form.reagendaDesdeId);
    if (ocupado) { toast("Ese bloque ya está ocupado para ese equipo", "warning"); return; }

    const consent = calcularConsentimiento(form.modalidad, prestSel.contraste);
    const nombreFinal = construirNombreEspecifico(prestSel.nombre, form.lateralidad);
    const nombreCompleto = `${form.nombres} ${form.apellidoPaterno} ${form.apellidoMaterno}`.trim();

    if (form.editId) {
      const ordenOriginal = ordenes.find(o => o.id === form.editId);
      // Mismo rastro que ya deja moverOrdenPorDrag (drag&drop) — sin esto,
      // "Modificar Cita" tenía el mismo hueco que drag&drop antes de que
      // existiera movimientosCupo: el cupo de ORIGEN se quedaba sin
      // ninguna orden que lo referenciara, su historial desaparecía sin
      // dejar rastro al cambiar equipo/fecha/hora desde este modal.
      const cambioDeSlot = ordenOriginal && (ordenOriginal.equipoId !== form.equipoId || ordenOriginal.fecha !== form.fecha || ordenOriginal.hora !== form.hora);
      if (cambioDeSlot) {
        setMovimientosCupo(prev => [{
          id: `MOV-${Date.now()}`,
          via: "modificar",
          ordenId: form.editId,
          pacienteSnapshot: ordenOriginal.paciente, nombreFinalSnapshot: ordenOriginal.nombreFinal,
          equipoOrigenId: ordenOriginal.equipoId, fechaOrigen: ordenOriginal.fecha, horaOrigen: ordenOriginal.hora,
          equipoDestinoId: form.equipoId, fechaDestino: form.fecha, horaDestino: form.hora,
          ts: new Date().toLocaleString("es-CL", { day:"2-digit", month:"2-digit", year:"numeric", hour:"2-digit", minute:"2-digit", second:"2-digit" }),
          actorNombre: nombreUsuario(usuarioActual), actorRol: usuarioActual.rolLabel,
        }, ...prev]);
      }
      // Si el consentimiento YA era requerido antes de este cambio, se
      // respeta el estado existente (firmado/pendiente) — no se reinicia
      // solo porque se tocó otro campo. Si pasa a requerirse recién ahora,
      // arranca en pendiente. Si deja de requerirse, pasa a no_requiere.
      // Antes esto nunca se recalculaba acá: cambiar a una prestación que
      // sí necesita firma podía dejar requiereConsentimiento=true con
      // consentimientoEstado="no_requiere" (inconsistente, nunca se pedía
      // la firma aunque la pantalla dijera que se requería).
      const consentimientoEstadoNuevo = !consent.requiere
        ? "no_requiere"
        : (ordenOriginal?.requiereConsentimiento ? ordenOriginal.consentimientoEstado : "pendiente_fespa");
      setOrdenes(prev => prev.map(o => o.id !== form.editId ? o : {
        ...o, equipoId: form.equipoId, modalidad: form.modalidad, fecha: form.fecha, hora: form.hora,
        // telefono1/telefono2/correo faltaban acá — se precargaban en el
        // modal (fix anterior) pero un cambio real del usuario se perdía
        // igual, porque esta actualización nunca los escribía de vuelta.
        paciente: { ...o.paciente, rut: form.rut, nombres: form.nombres, apellidoPaterno: form.apellidoPaterno, apellidoMaterno: form.apellidoMaterno, fechaNacimiento: form.fechaNacimiento, telefono1: form.telefono1 || "", telefono2: form.telefono2 || "", correo: form.correo || "" },
        prestacion: prestSel, lateralidadSel: form.lateralidad || null, nombreFinal,
        requiereConsentimiento: consent.requiere, plantillaConsentimiento: consent.plantilla, consentimientoEstado: consentimientoEstadoNuevo,
        requiereCreatinina: consent.requiere && !!prestSel.contraste && form.fechaNacimiento && calcularEdad(form.fechaNacimiento, form.fecha) >= 60,
        creatininaAdjunta: form.creatininaAdjunta || null, creatininaExpres: !!form.creatininaExpres,
        diagnosticos: form.diagnosticos,
        ordenMedica: { adjunta: !!form.ordenAdjunta, medicoSolicitante: form.medicoSolicitante, medicoSolicitanteId: form.medicoSolicitanteId || null, fechaEmision: form.fechaEmisionOrden, diagnosticoSospecha: form.diagnosticoSospecha },
        adjuntosPrevios: { archivo: form.informePrevioArchivo || null, link: form.informePrevioLink || null },
      }));
      registrarAuditoria("Modificó solicitud", form.editId, `${nombreCompleto} — ${nombreFinal} el ${form.fecha} ${form.hora}`);
      toast("Solicitud modificada", "success");
      setForm(null);
      return;
    }

    const cupFinal = form.pacienteCup === "NUEVO" ? makeCUP(9000 + Math.floor(Math.random() * 999)) : form.pacienteCup;
    const nuevaId = `SR-2026-M${Date.now()}`;
    // Si viene de un reagendamiento, la orden de origen ya trae su propio
    // agendadoOriginalmentePor (que a su vez pudo venir de un reagendamiento
    // anterior) — se propaga tal cual, sin importar cuántos saltos tenga la
    // cadena. Si es una orden fresca, el origen es quien la crea ahora.
    const ordenOrigen = form.reagendaDesdeId ? ordenes.find(o => o.id === form.reagendaDesdeId) : null;
    const nueva = {
      id: nuevaId, acc: null, ot: null,
      equipoId: form.equipoId, modalidad: form.modalidad, fecha: form.fecha, hora: form.hora,
      paciente: { cup: cupFinal, rut: form.rut, nombres: form.nombres, apellidoPaterno: form.apellidoPaterno, apellidoMaterno: form.apellidoMaterno, fechaNacimiento: form.fechaNacimiento, telefono1: form.telefono1, telefono2: form.telefono2, correo: form.correo },
      prestacion: prestSel, lateralidadSel: form.lateralidad || null, nombreFinal,
      requiereConsentimiento: consent.requiere, plantillaConsentimiento: consent.plantilla, consentimientoEstado: consent.requiere ? "pendiente_fespa" : "no_requiere",
      requiereCreatinina: consent.requiere && !!prestSel.contraste && form.fechaNacimiento && calcularEdad(form.fechaNacimiento, form.fecha) >= 60,
      creatininaAdjunta: form.creatininaAdjunta || null, creatininaExpres: !!form.creatininaExpres,
      diagnosticos: form.diagnosticos, canalLlegada:null, notasCita:[],
      ordenMedica: { adjunta: !!form.ordenAdjunta, medicoSolicitante: form.medicoSolicitante, medicoSolicitanteId: form.medicoSolicitanteId || null, fechaEmision: form.fechaEmisionOrden, diagnosticoSospecha: form.diagnosticoSospecha },
      adjuntosPrevios: { archivo: form.informePrevioArchivo || null, link: form.informePrevioLink || null },
      canal:"Presencial", estado:"agendado",
      reagendadaHaciaId: null, reagendadaDesdeId: form.reagendaDesdeId || null,
      agendadoPorCUT: usuarioActual.cut, agendadoPorNombre: nombreUsuario(usuarioActual),
      agendadoOriginalmentePorCUT: ordenOrigen?.agendadoOriginalmentePorCUT || usuarioActual.cut,
      agendadoOriginalmentePorNombre: ordenOrigen?.agendadoOriginalmentePorNombre || nombreUsuario(usuarioActual),
    };
    setOrdenes(prev => {
      let next = [...prev, nueva];
      // Antes solo se marcaba "reagendada" acá, pisando SIEMPRE el estado
      // anterior — si la orden ya estaba en "No Asistió" o "Cancelada" (un
      // hecho histórico real), reagendar lo borraba silenciosamente y lo
      // reemplazaba por "Reagendada", como si simplemente se hubiera
      // movido. `estado` sigue pasando a "reagendada" (es lo que libera el
      // cupo en la grilla), pero el hecho anterior se guarda aparte en
      // estadoAntesDeReagendar para que el Historial del Cupo lo siga
      // mostrando, en vez de desaparecer.
      if (form.reagendaDesdeId) next = next.map(o => {
        if (o.id !== form.reagendaDesdeId) return o;
        const esHechoHistorico = o.estado === "no_show" || o.estado === "cancelado";
        return { ...o, estado:"reagendada", reagendadaHaciaId: nuevaId, estadoAntesDeReagendar: esHechoHistorico ? o.estado : null };
      });
      return next;
    });
    if (form.reagendaDesdeId) {
      registrarAuditoria("Reagendó solicitud", nuevaId, `${nombreCompleto}: ${form.reagendaDesdeId} → ${nuevaId} (${form.fecha} ${form.hora})`);
      toast("Solicitud reagendada — el cupo anterior quedó libre", "success");
    } else {
      registrarAuditoria("Creó solicitud de imagen", nuevaId, `${nombreCompleto} — ${nombreFinal} el ${form.fecha} ${form.hora}${consent.requiere ? " — requiere consentimiento" : ""}`);
      toast("Solicitud creada — se enviará confirmación por WhatsApp/correo cuando esa puerta esté conectada", "success");
    }
    setForm(null);
  };

  const equiposVisibles = modalidadFoco === "todas" ? EQUIPOS : EQUIPOS.filter(e => e.modalidad === modalidadFoco);

  return (
    <ForensicWatermark user={{ cut: usuarioActual.cut, deviceId: DEVICE_ID_DEMO }}>
    {/* Layout de 3 columnas: nav (izquierda, fija) | contenido (centro,
        flexible) | notas (derecha, fija). Bajo ~860px todo se apila en
        una sola columna (nav arriba del contenido, notas abajo) y se
        apaga el "sticky" de nav/notas — mismo criterio que ya se usaba
        para el panel de notas, ahora extendido a 3 columnas. */}
    <style>{`
      .axon-img-grid { display:grid; grid-template-columns: 188px minmax(0, 1fr) 280px; gap:16px; align-items:start; }
      .axon-img-notas, .axon-img-nav { position: sticky; top: 12px; }
      [role="dialog"]:focus { outline: none; }
      /* Scroll sin barra visible (la rueda/trackpad/touch siguen funcionando) — una sola clase
         para cinta de días y grillas Semana/Día, así las 3 se comportan igual. */
      .axon-scroll-oculto { scrollbar-width: none; -ms-overflow-style: none; }
      .axon-scroll-oculto::-webkit-scrollbar { display: none; width: 0; height: 0; }
      @media (max-width: 860px) {
        .axon-img-grid { grid-template-columns: 1fr; }
        .axon-img-notas, .axon-img-nav { position: static; }
      }
    `}</style>
    <SH title="Agenda de Imagenología" sub="Atención Clínica y Diagnóstica — ServiceRequest (FHIR R4) · solo agenda" icon={ScanLine} col={C.pri}>
      <select value={usuarioActual.cut} onChange={e => cambiarUsuario(e.target.value)} style={{ padding:"7px 10px", fontSize:11, fontWeight:600, border:`1px solid ${C.brd}`, borderRadius:7, background:"#fff", color:C.txt }}>
        {USUARIOS_DEMO.map(u => <option key={u.cut} value={u.cut}>Viendo como: {nombreUsuario(u)} ({u.rolLabel})</option>)}
      </select>
      <Btn v="ghost" sz="sm" icon={Lock} dis title="Firma FESpa/FESpro — puerta etiquetada, pendiente del catálogo real + plantillas validadas">Consentimientos ↗</Btn>
      <Btn v="ghost" sz="sm" dis title="Exportar el listado de citas — puerta etiquetada, configurable por modalidad cuando se necesite (ej. exportar solo RM, o toda Imagenología)">Exportar citas ↗</Btn>
      <PanicTrigger cut={usuarioActual.cut} deviceId={DEVICE_ID_DEMO} moduleId="img_agenda">
        <span title="Hora del sistema — triple clic o mantener presionado ~3s" style={{ padding:"7px 10px", fontSize:11, fontWeight:600, color:C.txl, fontFamily:"monospace", border:`1px solid ${C.brd}`, borderRadius:7, background:"#fff", userSelect:"none" }}>
          {relojEnVivo.toLocaleTimeString("es-CL", { hour:"2-digit", minute:"2-digit", second:"2-digit" })}
        </span>
      </PanicTrigger>
      <Badge c={C.pri}>FHIR·ServiceRequest</Badge>
      <Btn v="outline" col={C.dan} icon={Ban} onClick={abrirBloqueo} title="Bloquear un cupo, un rango de horas, un día o varios días de un equipo">Bloquear agenda</Btn>
      <Btn v="primary" icon={ScanLine} onClick={() => abrirNuevaSolicitud()}>Nueva Solicitud</Btn>
    </SH>

    <div className="axon-img-grid">
    <div className="axon-img-nav">
      <div style={{ background:C.panelGris, border:`1px solid ${C.brd}`, borderRadius:12, padding:"14px 12px" }}>

        {/* Título grande + navegación de fecha — solo tienen sentido en
            Mes/Semana/Día. Historial/Trazabilidad no tienen "fecha
            enfocada" propia, así que este bloque no se muestra ahí. */}
        {(vista === "mes" || vista === "semana" || vista === "dia") && (() => {
          const [anioCtx, mesCtx] = vista === "mes" ? [anioVista, mesVista] : fechaSel.split("-").map(Number);
          return (
            <div style={{ marginBottom:14, paddingBottom:12, borderBottom:`1px solid ${C.brd}` }}>
              <div style={{ fontSize:19, fontWeight:800, color:C.txt, textTransform:"uppercase", letterSpacing:"0.3px", textAlign:"center" }}>{NOMBRES_MES[mesCtx-1]}</div>
              {vista === "mes" && (
                <NavegadorFecha tipo="month" anchoInput={130}
                  valor={`${anioVista}-${String(mesVista).padStart(2,"0")}`}
                  onCambiar={e => { if (!e.target.value) return; const [a,m] = e.target.value.split("-").map(Number); setAnioVista(a); setMesVista(m); }}
                  onAnterior={() => cambiarMesVista(-1)} onSiguiente={() => cambiarMesVista(1)}
                  tituloAnterior="Mes anterior" tituloSiguiente="Mes siguiente"/>
              )}
              {vista === "semana" && (
                <NavegadorFecha tipo="date"
                  valor={fechaSel}
                  onCambiar={e => e.target.value && setFechaSel(e.target.value)}
                  onAnterior={() => setFechaSel(f => sumarDias(lunesDeSemana(f), -7))}
                  onSiguiente={() => setFechaSel(f => sumarDias(lunesDeSemana(f), 7))}
                  tituloAnterior="Semana anterior" tituloSiguiente="Semana siguiente"
                  title="Elige cualquier día — se muestra la semana completa que lo contiene"/>
              )}
              {vista === "dia" && (
                <NavegadorFecha tipo="date"
                  valor={fechaSel}
                  onCambiar={e => e.target.value && setFechaSel(e.target.value)}
                  onAnterior={() => setFechaSel(f => sumarDias(f, -1))}
                  onSiguiente={() => setFechaSel(f => sumarDias(f, 1))}
                  tituloAnterior="Día anterior" tituloSiguiente="Día siguiente"/>
              )}
              <MiniCalendario anioCtx={anioCtx} mesCtx={mesCtx} fechaSel={fechaSel} onSeleccionar={seleccionarDiaSidebar} onCambiarMes={cambiarMesSidebar}/>
            </div>
          );
        })()}

        <div style={{ fontSize:10, fontWeight:700, color:C.txl, textTransform:"uppercase", marginBottom:4 }}>Modalidad</div>
        <select value={modalidadFoco} onChange={e => cambiarModalidadFoco(e.target.value)} style={{ width:"100%", padding:"6px 7px", fontSize:11, border:`1px solid ${C.brd}`, borderRadius:7, marginBottom:12, boxSizing:"border-box" }}>
          <option value="todas">Todas las modalidades</option>
          {Object.keys(MODALIDAD_LABEL).map(m => <option key={m} value={m}>{MODALIDAD_LABEL[m]}</option>)}
        </select>

        {(vista === "mes" || vista === "semana" || vista === "dia") && (
          <div style={{ marginBottom:14 }}>
            <div style={{ fontSize:10, fontWeight:700, color:C.txl, textTransform:"uppercase", marginBottom:4 }}>Equipo</div>
            {modalidadFoco === "todas" ? (
              <div style={{ fontSize:10, color:C.txl, lineHeight:1.4 }}>No aplica con "Todas las modalidades": Mes/Semana piden elegir una modalidad específica, y Día ya muestra todos los equipos junto sin necesitar este selector.</div>
            ) : (
              <select value={equipoFocoId} onChange={e => setEquipoFocoId(e.target.value)} style={{ width:"100%", padding:"6px 7px", fontSize:11, border:`1px solid ${C.brd}`, borderRadius:7, boxSizing:"border-box" }}>
                {EQUIPOS.filter(e => e.modalidad === modalidadFoco).map(eq => <option key={eq.id} value={eq.id}>{eq.nombre}</option>)}
              </select>
            )}
          </div>
        )}

        <div style={{ fontSize:10, fontWeight:700, color:C.txl, textTransform:"uppercase", marginBottom:5 }}>Vista</div>
        <div style={{ display:"flex", flexDirection:"column", gap:2 }}>
          {[{ id:"mes", label:"Mes", icon:LayoutDashboard }, { id:"semana", label:"Semana", icon:Calendar }, { id:"dia", label:"Día", icon:Clock }, { id:"agendamientos", label:"Agendamientos", icon:Filter }, { id:"auditoria", label:"Trazabilidad", icon:Lock }].map(t => (
            <button key={t.id} onClick={() => irAVista(t.id)} style={{ display:"flex", alignItems:"center", gap:7, padding:"7px 8px", borderRadius:7, border:"none", background:vista===t.id ? `${C.pri}12` : "transparent", color:vista===t.id ? C.pri : C.txm, fontWeight:vista===t.id?600:400, fontSize:11.5, cursor:"pointer", textAlign:"left" }}>
              <t.icon size={13}/>{t.label}
            </button>
          ))}
        </div>
        {/* Puerta etiquetada: no es una vista que se selecciona (por eso va separada
            y no se resalta), es la entrada a la configuración del motor de agenda
            (duración de bloques, horarios, recursos). Deshabilitada hasta que exista. */}
        <div style={{ marginTop:8, paddingTop:8, borderTop:`1px solid ${C.brd}` }}>
          <button disabled title="Puerta etiquetada — la habilitará el motor de agenda (duración de bloques, horarios, recursos, excepciones)" style={{ width:"100%", display:"flex", alignItems:"center", gap:7, padding:"7px 8px", borderRadius:7, border:"none", background:"transparent", color:"#90A4AE", fontWeight:400, fontSize:11.5, cursor:"not-allowed", textAlign:"left" }}>
            <Settings size={13}/>Configurar agenda
          </button>
        </div>
      </div>
    </div>
    <div style={{ minWidth:0 }}>
      {/* Estos KPICards son la única superficie de indicadores acá — a propósito.
          Los indicadores clínico-administrativos reales van a Gestión/Alta Calidad
          + el dashboard principal, no a un tab dentro de este módulo. Puerta
          etiquetada: cuando exista ese destino, esto se emite como evento,
          no se construye una pestaña de "Indicadores" propia acá.
          Tira delgada a pedido del usuario — KPICard recibe compact acá. */}
      <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit, minmax(160px, 1fr))", gap:10, marginBottom:16 }}>
        <KPICard label="Órdenes Hoy" value={kpis.ordenesHoy} sub="Todos los equipos" icon={ClipboardList} col={C.pri} compact/>
        <KPICard label="En Espera" value={kpis.enEspera} sub="Listas para el módulo operativo" icon={Activity} col={C.war} compact/>
        <KPICard label="Consentimientos Pendientes" value={kpis.consentimientosPendientes} sub="Firma paciente" icon={ShieldCheck} col={C.amb} compact/>
        <KPICard label="Creatinina Pendiente" value={kpis.creatininaPendiente} sub="≥60 años + contraste" icon={AlertTriangle} col={C.dan} compact/>
      </div>

      {vista === "mes" && (
        <div>
          {modalidadFoco === "todas" ? (
            <div style={{ padding:32, textAlign:"center", background:C.sfc, border:`1px solid ${C.brd}`, borderRadius:12, color:C.txl, fontSize:12 }}>
              El calendario mensual es por equipo — selecciona una modalidad específica arriba para verlo. "Todas las modalidades" solo aplica a la vista Día.
            </div>
          ) : (
            <>
              <div style={{ border:`1px solid ${C.brd}`, borderRadius:12, overflow:"hidden", background:C.sfc }}>
                <div style={{ display:"grid", gridTemplateColumns:"repeat(7, 1fr)" }}>
                  {DIAS_SEMANA_LABEL.map((d, i) => (
                    <div key={d} style={{ minHeight:54, display:"flex", alignItems:"center", justifyContent:"center", padding:"8px", fontSize:10, fontWeight:700, color:C.txl, background: i >= 5 ? C.finde : C.bg, borderBottom:`1px solid ${C.gridLine}`, textTransform:"uppercase" }}>{d}</div>
                  ))}
                  {matrizMes.map((celda) => {
                    const ordenesDia = ordenes.filter(o => o.equipoId === equipoFoco.id && o.fecha === celda.fecha && !ESTADOS_LIBERAN_CUPO.has(o.estado));
                    const esHoy = celda.fecha === HOY;
                    const finde = esFinDeSemana(celda.fecha);
                    const feriado = FERIADOS_CHILE_2026[celda.fecha];
                    const nBloq = celda.fueraDeMes ? 0 : BLOQUES.filter(h => bloqueoDeCupo(bloqueos, equipoFoco.id, celda.fecha, h)).length;
                    const diaBloq = nBloq === BLOQUES.length;
                    return (
                      <button key={celda.fecha} disabled={celda.fueraDeMes} title={feriado || undefined} onClick={() => { setFechaSel(celda.fecha); setVista("dia"); }} style={{ border:"none", borderRight:`1px solid ${C.gridLine}`, borderBottom:`1px solid ${C.gridLine}`, background:celda.fueraDeMes ? C.bg : (diaBloq ? FONDO_BLOQUEADO : (finde ? C.gridAlt : "#fff")), minHeight:70, padding:6, textAlign:"left", cursor:celda.fueraDeMes ? "default" : "pointer", opacity:celda.fueraDeMes ? 0.45 : 1 }}>
                        <div style={{ display:"flex", alignItems:"center", gap:4 }}>
                          <span style={{ fontSize:11, fontWeight:600, color:C.txt, borderBottom:esHoy ? `2px solid ${C.pri}` : "2px solid transparent" }}>{Number(celda.fecha.slice(8,10))}</span>
                          {feriado && <div style={{ width:4, height:4, borderRadius:"50%", background:C.war, flexShrink:0 }}/>}
                        </div>
                        {ordenesDia.length > 0 && <div style={{ marginTop:4, fontSize:10, fontWeight:700, color:C.pri, background:`${C.pri}12`, borderRadius:5, padding:"1px 5px", display:"inline-block" }}>{ordenesDia.length} órdenes</div>}
                        {nBloq > 0 && <div title="Cupos bloqueados este día" style={{ marginTop:4, fontSize:10, fontWeight:700, color:C.txm, display:"flex", alignItems:"center", gap:3 }}><Lock size={10}/>{diaBloq ? "Día bloqueado" : `${nBloq} cupo${nBloq === 1 ? "" : "s"} bloqueado${nBloq === 1 ? "" : "s"}`}</div>}
                      </button>
                    );
                  })}
                </div>
              </div>
            </>
          )}
        </div>
      )}

      {vista === "semana" && (
        <div>
          {modalidadFoco === "todas" ? (
            <div style={{ padding:32, textAlign:"center", background:C.sfc, border:`1px solid ${C.brd}`, borderRadius:12, color:C.txl, fontSize:12 }}>
              La semana es por equipo — selecciona una modalidad específica arriba para verla.
            </div>
          ) : (
            <>
              <div className="axon-scroll-oculto" style={{ overflowX:"auto", overflowY:"auto", maxHeight:560, border:`1px solid ${C.brd}`, borderRadius:12, background:C.sfc, minWidth:0 }}>
                <div style={{ display:"grid", gridTemplateColumns:"70px repeat(7, minmax(90px, 1fr))", minWidth:70 + 7 * 90 }}>
                  <div style={{ borderBottom:`1px solid ${C.gridLine}`, background:C.bg, position:"sticky", top:0, zIndex:2 }}/>
                  {[0,1,2,3,4,5,6].map(i => {
                    const f = sumarDias(lunesDeSemana(fechaSel), i);
                    const esHoy = f === HOY;
                    const finde = esFinDeSemana(f);
                    const feriado = FERIADOS_CHILE_2026[f];
                    return (
                      <div key={f} title={feriado || undefined} style={{ padding:"8px", borderBottom:`1px solid ${C.gridLine}`, borderLeft:`1px solid ${C.gridLine}`, background: finde ? C.finde : C.bg, textAlign:"center", position:"sticky", top:0, zIndex:2 }}>
                        <div style={{ fontSize:10, fontWeight:700, color:C.txl, textTransform:"uppercase" }}>{DIAS_SEMANA_LABEL[i]}</div>
                        <div style={{ fontSize:14, fontWeight:700, color:C.txt, display:"inline-block", borderBottom:esHoy ? `2px solid ${C.pri}` : "2px solid transparent", lineHeight:1.6 }}>{Number(f.slice(8,10))}</div>
                        {feriado && <div style={{ width:4, height:4, borderRadius:"50%", background:C.war, margin:"2px auto 0" }}/>}
                      </div>
                    );
                  })}

                  {/* Sobrecupo ANTES de 08:00 */}
                  {(() => {
                    const dias7 = [0,1,2,3,4,5,6].map(i => sumarDias(lunesDeSemana(fechaSel), i));
                    const filas = [...new Set(dias7.flatMap(f => sobrecuposAM[`${equipoFoco.id}_${f}`] || []))].sort();
                    return filas.map(hora => (
                      <Fragment key={`am-${hora}`}>
                        <div style={{ padding:"6px", borderBottom:`1px solid ${C.gridLine}`, background:`${C.amb}14`, fontSize:10, color:C.amb, fontWeight:700, display:"flex", alignItems:"center" }}>{hora} ⚡</div>
                        {[0,1,2,3,4,5,6].map(i => {
                          const f = sumarDias(lunesDeSemana(fechaSel), i);
                          const tiene = (sobrecuposAM[`${equipoFoco.id}_${f}`] || []).includes(hora);
                          const orden = tiene ? ordenes.find(o => o.equipoId === equipoFoco.id && o.fecha === f && o.hora === hora && !ESTADOS_LIBERAN_CUPO.has(o.estado)) : null;
                          const key = `${equipoFoco.id}_${f}_${hora}`;
                          const sobrevolada = celdaSobrevolada === key;
                          if (!tiene) return <div key={i} style={{ borderBottom:`1px solid ${C.gridLine}`, borderLeft:`1px solid ${C.gridLine}`, background:C.bg, minHeight:34 }}/>;
                          if (!orden) return <button key={i} onClick={() => verCeldaVacia(equipoFoco.id, f, hora)} {...dragDestinoProps(equipoFoco.id, f, hora)} style={{ border:"none", borderBottom:`1px solid ${C.gridLine}`, borderLeft:`1px solid ${C.gridLine}`, background:sobrevolada ? `${C.suc}18` : `${C.amb}08`, outline:sobrevolada ? `2px dashed ${C.suc}` : "none", outlineOffset:-2, cursor:"pointer", minHeight:34, display:"flex", alignItems:"center", justifyContent:"center", position:"relative" }}><ScanLine size={9} color={sobrevolada ? C.suc : C.amb}/><PuntoHistorial bloqueos={bloqueos} ordenes={ordenes} movimientos={movimientosCupo} auditoria={auditoria} equipoId={equipoFoco.id} fecha={f} hora={hora}/><CapaBloqueo bloqueos={bloqueos} equipoId={equipoFoco.id} fecha={f} hora={hora} hover={celdaSobrevolada}/></button>;
                          return <CeldaOrdenSemana key={i} orden={orden} bloqueada={!!bloqueoDeCupo(bloqueos, orden.equipoId, orden.fecha, orden.hora)} arrastrando={arrastrando} onClick={() => verDetalleOrden(orden)} dragProps={dragOrigenProps(orden)} bordePosicion="bottom" minHeight={54}/>;
                        })}
                      </Fragment>
                    ));
                  })()}
                  <div style={{ padding:"3px", background:`${C.amb}08` }}/>
                  {[0,1,2,3,4,5,6].map(i => {
                    const f = sumarDias(lunesDeSemana(fechaSel), i);
                    return (
                      <button key={i} onClick={() => agregarSobrecupo("am", equipoFoco.id, f)} title="Sobrecupo antes de las 08:00 — no es solo urgencia: también ambulatorio extra u hospitalizados" style={{ border:"none", background:`${C.amb}08`, cursor:"pointer", padding:"3px", display:"flex", alignItems:"center", justifyContent:"center" }}>
                        <Plus size={8} color={C.amb}/>
                      </button>
                    );
                  })}

                  {BLOQUES.map((hora, fi) => (
                    <Fragment key={hora}>
                      <div style={{ padding:"8px", borderBottom:`1px solid ${C.gridLine}`, background:fi % 2 === 1 ? C.gridAlt : "#fff", fontSize:11, color:C.txl, fontWeight:600, display:"flex", alignItems:"center" }}>{hora}</div>
                      {[0,1,2,3,4,5,6].map(i => {
                        const f = sumarDias(lunesDeSemana(fechaSel), i);
                        const orden = ordenes.find(o => o.equipoId === equipoFoco.id && o.fecha === f && o.hora === hora && !ESTADOS_LIBERAN_CUPO.has(o.estado));
                        const filaBg = fi % 2 === 1 ? C.gridAlt : "#fff";
                        const key = `${equipoFoco.id}_${f}_${hora}`;
                        const sobrevolada = celdaSobrevolada === key;
                        if (!DIAS.includes(f)) {
                          return <div key={i} style={{ borderBottom:`1px solid ${C.gridLine}`, borderLeft:`1px solid ${C.gridLine}`, background:C.bg, minHeight:38 }}/>;
                        }
                        if (!orden) {
                          return (
                            <button key={i} onClick={() => verCeldaVacia(equipoFoco.id, f, hora)} {...dragDestinoProps(equipoFoco.id, f, hora)} style={{ border:"none", borderBottom:`1px solid ${C.gridLine}`, borderLeft:`1px solid ${C.gridLine}`, background:sobrevolada ? `${C.suc}18` : filaBg, outline:sobrevolada ? `2px dashed ${C.suc}` : "none", outlineOffset:-2, cursor:"pointer", minHeight:38, display:"flex", alignItems:"center", justifyContent:"center", position:"relative" }}>
                              <ScanLine size={10} color={sobrevolada ? C.suc : C.gridLine}/>
                              <PuntoHistorial bloqueos={bloqueos} ordenes={ordenes} movimientos={movimientosCupo} auditoria={auditoria} equipoId={equipoFoco.id} fecha={f} hora={hora}/><CapaBloqueo bloqueos={bloqueos} equipoId={equipoFoco.id} fecha={f} hora={hora} hover={celdaSobrevolada}/>
                            </button>
                          );
                        }
                        return (
                          <CeldaOrdenSemana key={i} orden={orden} bloqueada={!!bloqueoDeCupo(bloqueos, orden.equipoId, orden.fecha, orden.hora)} arrastrando={arrastrando} onClick={() => verDetalleOrden(orden)} dragProps={dragOrigenProps(orden)} bordePosicion="bottom" minHeight={54}/>
                        );
                      })}
                    </Fragment>
                  ))}

                  {/* Sobrecupo DESPUÉS de 20:00 */}
                  <div style={{ padding:"3px", background:`${C.amb}08` }}/>
                  {[0,1,2,3,4,5,6].map(i => {
                    const f = sumarDias(lunesDeSemana(fechaSel), i);
                    return (
                      <button key={i} onClick={() => agregarSobrecupo("pm", equipoFoco.id, f)} title="Sobrecupo después de las 20:00 — no es solo urgencia: también ambulatorio extra u hospitalizados" style={{ border:"none", background:`${C.amb}08`, cursor:"pointer", padding:"3px", display:"flex", alignItems:"center", justifyContent:"center" }}>
                        <Plus size={8} color={C.amb}/>
                      </button>
                    );
                  })}
                  {(() => {
                    const dias7 = [0,1,2,3,4,5,6].map(i => sumarDias(lunesDeSemana(fechaSel), i));
                    const filas = [...new Set(dias7.flatMap(f => sobrecuposPM[`${equipoFoco.id}_${f}`] || []))].sort();
                    return filas.map(hora => (
                      <Fragment key={`pm-${hora}`}>
                        <div style={{ padding:"6px", borderTop:`1px solid ${C.gridLine}`, background:`${C.amb}14`, fontSize:10, color:C.amb, fontWeight:700, display:"flex", alignItems:"center" }}>{hora} ⚡</div>
                        {[0,1,2,3,4,5,6].map(i => {
                          const f = sumarDias(lunesDeSemana(fechaSel), i);
                          const tiene = (sobrecuposPM[`${equipoFoco.id}_${f}`] || []).includes(hora);
                          const orden = tiene ? ordenes.find(o => o.equipoId === equipoFoco.id && o.fecha === f && o.hora === hora && !ESTADOS_LIBERAN_CUPO.has(o.estado)) : null;
                          const key = `${equipoFoco.id}_${f}_${hora}`;
                          const sobrevolada = celdaSobrevolada === key;
                          if (!tiene) return <div key={i} style={{ borderTop:`1px solid ${C.gridLine}`, borderLeft:`1px solid ${C.gridLine}`, background:C.bg, minHeight:34 }}/>;
                          if (!orden) return <button key={i} onClick={() => verCeldaVacia(equipoFoco.id, f, hora)} {...dragDestinoProps(equipoFoco.id, f, hora)} style={{ border:"none", borderTop:`1px solid ${C.gridLine}`, borderLeft:`1px solid ${C.gridLine}`, background:sobrevolada ? `${C.suc}18` : `${C.amb}08`, outline:sobrevolada ? `2px dashed ${C.suc}` : "none", outlineOffset:-2, cursor:"pointer", minHeight:34, display:"flex", alignItems:"center", justifyContent:"center", position:"relative" }}><ScanLine size={9} color={sobrevolada ? C.suc : C.amb}/><PuntoHistorial bloqueos={bloqueos} ordenes={ordenes} movimientos={movimientosCupo} auditoria={auditoria} equipoId={equipoFoco.id} fecha={f} hora={hora}/><CapaBloqueo bloqueos={bloqueos} equipoId={equipoFoco.id} fecha={f} hora={hora} hover={celdaSobrevolada}/></button>;
                          const est = ESTADOS[orden.estado];
                          return <CeldaOrdenSemana key={i} orden={orden} bloqueada={!!bloqueoDeCupo(bloqueos, orden.equipoId, orden.fecha, orden.hora)} arrastrando={arrastrando} onClick={() => verDetalleOrden(orden)} dragProps={dragOrigenProps(orden)} bordePosicion="top" minHeight={54}/>;
                        })}
                      </Fragment>
                    ));
                  })()}
                </div>
              </div>
              <div style={{ marginTop:8, fontSize:10, color:C.txl }}>⚡ = sobrecupo (ambulatorio extra, hospitalizados o urgencias) fuera del horario regular. Arrastra una cita Agendada/Confirmada a otro bloque para reagendarla rápido. Fuera del rango de datos de muestra (fuera de {fmtCorta(DIAS[0])}–{fmtCorta(DIAS[DIAS.length-1])}) aparece gris — es límite del mock, no un día no laborable real.</div>
            </>
          )}
        </div>
      )}

      {vista === "dia" && (
        <div>
          <div ref={cintaDiasRef} className="axon-scroll-oculto" style={{ display:"flex", gap:5, marginBottom:16, overflowX:"auto", paddingBottom:4, minWidth:0 }}>
            {(() => {
              const [anioPill, mesPill] = fechaSel.split("-").map(Number);
              const diasDelMesPill = diasEnMes(anioPill, mesPill);
              const pillsDelMes = Array.from({ length: diasDelMesPill }, (_, i) => isoDate(anioPill, mesPill, i + 1));
              const irAMesAdyacente = (delta) => {
                let m = mesPill + delta, a = anioPill;
                if (m > 12) { m = 1; a++; } else if (m < 1) { m = 12; a--; }
                setFechaSel(isoDate(a, m, 1));
              };
              const celdaFlecha = (delta, Icono, titulo) => (
                <button onClick={() => irAMesAdyacente(delta)} title={titulo} style={{ minWidth:52, flexShrink:0, padding:"6px 4px", borderRadius:8, border:`1px solid ${C.brd}`, background:C.bg, cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center" }}>
                  <Icono size={16} color={C.txl}/>
                </button>
              );
              return (
                <>
                  {celdaFlecha(-1, ChevronLeft, "Mes anterior")}
                  {pillsDelMes.map(d => {
                    const count = ordenes.filter(o => o.fecha === d && equiposVisibles.some(eq => eq.id === o.equipoId) && !ESTADOS_LIBERAN_CUPO.has(o.estado)).length;
                    const activo = d === fechaSel;
                    const esHoy = d === HOY;
                    const finde = esFinDeSemana(d);
                    const feriado = FERIADOS_CHILE_2026[d];
                    return (
                      <button key={d} data-pill-activo={activo ? "1" : undefined} onClick={() => setFechaSel(d)} title={feriado || undefined} style={{ minWidth:52, flexShrink:0, padding:"6px 4px", borderRadius:8, border:`1px solid ${activo ? C.pri : esHoy ? C.pri : C.brd}`, background:activo ? C.pri : (finde ? C.gridAlt : C.sfc), cursor:"pointer", textAlign:"center" }}>
                        <div style={{ fontSize:10, fontWeight:600, textTransform:"uppercase", color:activo ? "#fff" : C.txl }}>{fmtCorta(d).split(",")[0]}</div>
                        <div style={{ fontSize:13, fontWeight:700, color:activo ? "#fff" : C.txt }}>{d.slice(8,10)}</div>
                        {count > 0 && <div style={{ fontSize:10, color:activo ? "rgba(255,255,255,0.85)" : C.pri, marginTop:1, fontWeight:700 }}>{count}</div>}
                        {feriado && <div style={{ width:4, height:4, borderRadius:"50%", background:activo ? "#fff" : C.war, margin:"2px auto 0" }}/>}
                      </button>
                    );
                  })}
                  {celdaFlecha(1, ChevronRight, "Mes siguiente")}
                </>
              );
            })()}
          </div>

          <div className="axon-scroll-oculto" style={{ overflowX:"auto", overflowY:"auto", maxHeight:560, border:`1px solid ${C.brd}`, borderRadius:12, background:C.sfc, minWidth:0 }}>
            <div style={{ display:"grid", gridTemplateColumns:`70px repeat(${equiposVisibles.length}, minmax(130px, 1fr))`, minWidth:70 + equiposVisibles.length * 130 }}>
              {/* Con un solo equipo visible el encabezado es redundante (el sidebar ya indica modalidad y equipo) */}
              {equiposVisibles.length > 1 && <div style={{ borderBottom:`1px solid ${C.gridLine}`, background:C.bg, position:"sticky", top:0, zIndex:2 }}/>}
              {equiposVisibles.length > 1 && equiposVisibles.map(eq => (
                <div key={eq.id} style={{ padding:"10px 8px", borderBottom:`1px solid ${C.gridLine}`, borderLeft:`1px solid ${C.gridLine}`, background:C.bg, position:"sticky", top:0, zIndex:2, textAlign:"center" }}>
                  <div style={{ fontSize:11, fontWeight:700, color:eq.color }}>{eq.nombre}</div>
                  <div style={{ fontSize:10, color:C.txl }}>{eq.area}{modalidadFoco === "todas" ? ` · ${MODALIDAD_LABEL[eq.modalidad]}` : ""}</div>
                </div>
              ))}

              {/* Sobrecupo ANTES de 08:00 — no es bloque regular */}
              {(() => {
                const filas = [...new Set(equiposVisibles.flatMap(eq => sobrecuposAM[`${eq.id}_${fechaSel}`] || []))].sort();
                return filas.map(hora => (
                  <Fragment key={`am-${hora}`}>
                    <div style={{ padding:"6px", borderBottom:`1px solid ${C.gridLine}`, background:`${C.amb}14`, fontSize:10, color:C.amb, fontWeight:700, display:"flex", alignItems:"center" }}>{hora} ⚡</div>
                    {equiposVisibles.map(eq => {
                      const tiene = (sobrecuposAM[`${eq.id}_${fechaSel}`] || []).includes(hora);
                      const orden = tiene ? ordenesPorCeldaDia[`${eq.id}_${hora}`] : null;
                      const key = `${eq.id}_${fechaSel}_${hora}`;
                      const sobrevolada = celdaSobrevolada === key;
                      if (!tiene) return <div key={eq.id} style={{ borderBottom:`1px solid ${C.gridLine}`, borderLeft:`1px solid ${C.gridLine}`, background:C.bg, minHeight:38 }}/>;
                      if (!orden) return <button key={eq.id} onClick={() => verCeldaVacia(eq.id, fechaSel, hora)} {...dragDestinoProps(eq.id, fechaSel, hora)} style={{ border:"none", borderBottom:`1px solid ${C.gridLine}`, borderLeft:`1px solid ${C.gridLine}`, background:sobrevolada ? `${C.suc}18` : `${C.amb}08`, outline:sobrevolada ? `2px dashed ${C.suc}` : "none", outlineOffset:-2, cursor:"pointer", minHeight:38, display:"flex", alignItems:"center", justifyContent:"center", position:"relative" }}><ScanLine size={10} color={sobrevolada ? C.suc : C.amb}/><PuntoHistorial bloqueos={bloqueos} ordenes={ordenes} movimientos={movimientosCupo} auditoria={auditoria} equipoId={eq.id} fecha={fechaSel} hora={hora}/><CapaBloqueo bloqueos={bloqueos} equipoId={eq.id} fecha={fechaSel} hora={hora} hover={celdaSobrevolada}/></button>;
                      return <CeldaOrdenDia key={eq.id} orden={orden} bloqueada={!!bloqueoDeCupo(bloqueos, orden.equipoId, orden.fecha, orden.hora)} ancha={equiposVisibles.length === 1} arrastrando={arrastrando} onClick={() => verDetalleOrden(orden)} dragProps={dragOrigenProps(orden)} bordePosicion="bottom" minHeightAngosta={60}/>;
                    })}
                  </Fragment>
                ));
              })()}
              <div style={{ padding:"4px", background:`${C.amb}08` }}/>
              {equiposVisibles.map(eq => (
                <button key={eq.id} onClick={() => agregarSobrecupo("am", eq.id, fechaSel)} title="Sobrecupo antes de las 08:00 — ambulatorio extra, hospitalizados o urgencias" style={{ border:"none", background:`${C.amb}08`, cursor:"pointer", padding:"4px", display:"flex", alignItems:"center", justifyContent:"center", gap:3 }}>
                  <Plus size={9} color={C.amb}/><span style={{ fontSize:10, fontWeight:700, color:C.amb }}>Sobrecupo</span>
                </button>
              ))}

              {BLOQUES.map((hora, fi) => (
                <Fragment key={hora}>
                  <div style={{ padding:"8px", borderBottom:`1px solid ${C.gridLine}`, background:fi % 2 === 1 ? C.gridAlt : "#fff", fontSize:11, color:C.txl, fontWeight:600, display:"flex", alignItems:"center" }}>{hora}</div>
                  {equiposVisibles.map(eq => {
                    const orden = ordenesPorCeldaDia[`${eq.id}_${hora}`];
                    const filaBg = fi % 2 === 1 ? C.gridAlt : "#fff";
                    const key = `${eq.id}_${fechaSel}_${hora}`;
                    const sobrevolada = celdaSobrevolada === key;
                    if (!orden) {
                      return (
                        <button key={eq.id} onClick={() => verCeldaVacia(eq.id, fechaSel, hora)} {...dragDestinoProps(eq.id, fechaSel, hora)} style={{ border:"none", borderBottom:`1px solid ${C.gridLine}`, borderLeft:`1px solid ${C.gridLine}`, background:sobrevolada ? `${C.suc}18` : filaBg, outline:sobrevolada ? `2px dashed ${C.suc}` : "none", outlineOffset:-2, cursor:"pointer", minHeight:34, display:"flex", alignItems:"center", justifyContent:"center", position:"relative" }}>
                          <ScanLine size={11} color={sobrevolada ? C.suc : C.gridLine}/>
                          <PuntoHistorial bloqueos={bloqueos} ordenes={ordenes} movimientos={movimientosCupo} auditoria={auditoria} equipoId={eq.id} fecha={fechaSel} hora={hora}/><CapaBloqueo bloqueos={bloqueos} equipoId={eq.id} fecha={fechaSel} hora={hora} hover={celdaSobrevolada}/>
                        </button>
                      );
                    }
                    const est = ESTADOS[orden.estado];
                    return (
                      <CeldaOrdenDia key={eq.id} orden={orden} bloqueada={!!bloqueoDeCupo(bloqueos, orden.equipoId, orden.fecha, orden.hora)} ancha={equiposVisibles.length === 1} arrastrando={arrastrando} onClick={() => verDetalleOrden(orden)} dragProps={dragOrigenProps(orden)} bordePosicion="bottom" minHeightAngosta={60}/>
                    );
                  })}
                </Fragment>
              ))}

              {/* Sobrecupo DESPUÉS de 20:00 */}
              <div style={{ padding:"4px", background:`${C.amb}08` }}/>
              {equiposVisibles.map(eq => (
                <button key={eq.id} onClick={() => agregarSobrecupo("pm", eq.id, fechaSel)} title="Sobrecupo después de las 20:00 — ambulatorio extra, hospitalizados o urgencias" style={{ border:"none", background:`${C.amb}08`, cursor:"pointer", padding:"4px", display:"flex", alignItems:"center", justifyContent:"center", gap:3 }}>
                  <Plus size={9} color={C.amb}/><span style={{ fontSize:10, fontWeight:700, color:C.amb }}>Sobrecupo</span>
                </button>
              ))}
              {(() => {
                const filas = [...new Set(equiposVisibles.flatMap(eq => sobrecuposPM[`${eq.id}_${fechaSel}`] || []))].sort();
                return filas.map(hora => (
                  <Fragment key={`pm-${hora}`}>
                    <div style={{ padding:"6px", borderTop:`1px solid ${C.gridLine}`, background:`${C.amb}14`, fontSize:10, color:C.amb, fontWeight:700, display:"flex", alignItems:"center" }}>{hora} ⚡</div>
                    {equiposVisibles.map(eq => {
                      const tiene = (sobrecuposPM[`${eq.id}_${fechaSel}`] || []).includes(hora);
                      const orden = tiene ? ordenesPorCeldaDia[`${eq.id}_${hora}`] : null;
                      const key = `${eq.id}_${fechaSel}_${hora}`;
                      const sobrevolada = celdaSobrevolada === key;
                      if (!tiene) return <div key={eq.id} style={{ borderTop:`1px solid ${C.gridLine}`, borderLeft:`1px solid ${C.gridLine}`, background:C.bg, minHeight:38 }}/>;
                      if (!orden) return <button key={eq.id} onClick={() => verCeldaVacia(eq.id, fechaSel, hora)} {...dragDestinoProps(eq.id, fechaSel, hora)} style={{ border:"none", borderTop:`1px solid ${C.gridLine}`, borderLeft:`1px solid ${C.gridLine}`, background:sobrevolada ? `${C.suc}18` : `${C.amb}08`, outline:sobrevolada ? `2px dashed ${C.suc}` : "none", outlineOffset:-2, cursor:"pointer", minHeight:38, display:"flex", alignItems:"center", justifyContent:"center", position:"relative" }}><ScanLine size={10} color={sobrevolada ? C.suc : C.amb}/><PuntoHistorial bloqueos={bloqueos} ordenes={ordenes} movimientos={movimientosCupo} auditoria={auditoria} equipoId={eq.id} fecha={fechaSel} hora={hora}/><CapaBloqueo bloqueos={bloqueos} equipoId={eq.id} fecha={fechaSel} hora={hora} hover={celdaSobrevolada}/></button>;
                      const est = ESTADOS[orden.estado];
                      return <CeldaOrdenDia key={eq.id} orden={orden} bloqueada={!!bloqueoDeCupo(bloqueos, orden.equipoId, orden.fecha, orden.hora)} ancha={equiposVisibles.length === 1} arrastrando={arrastrando} onClick={() => verDetalleOrden(orden)} dragProps={dragOrigenProps(orden)} bordePosicion="top" minHeightAngosta={60}/>;
                    })}
                  </Fragment>
                ));
              })()}
            </div>
          </div>
          <div style={{ marginTop:8, fontSize:10, color:C.txl }}>⚡ = sobrecupo fuera del horario regular 08:00–20:00 (ambulatorio extra, hospitalizados o urgencias — no es exclusivo de urgencia). Arrastra una cita Agendada/Confirmada a otro bloque para reagendarla rápido. Fuera del rango de {fmtCorta(DIAS[0])}–{fmtCorta(DIAS[DIAS.length-1])} la agenda sigue navegable, solo que no hay datos de muestra.</div>
        </div>
      )}

      {vista === "agendamientos" && (
        <div>
          <div style={{ display:"flex", gap:8, marginBottom:14, flexWrap:"wrap", alignItems:"center" }}>
            <div style={{ position:"relative", flex:"1 1 220px" }}>
              <Search size={13} color={C.txl} style={{ position:"absolute", left:10, top:9 }}/>
              <input value={filtros.q} onChange={e => { setFiltros(f => ({ ...f, q:e.target.value })); setPagina(1); }} placeholder="Buscar paciente, RUT o Accession Number..." style={{ width:"100%", padding:"7px 10px 7px 30px", fontSize:12, border:`1px solid ${C.brd}`, borderRadius:7, boxSizing:"border-box" }}/>
            </div>
            <select value={filtros.modalidad} onChange={e => { setFiltros(f => ({ ...f, modalidad:e.target.value })); setPagina(1); }} style={{ padding:"7px 10px", fontSize:12, border:`1px solid ${C.brd}`, borderRadius:7 }}>
              <option value="todas">Todas las modalidades</option>
              {Object.entries(MODALIDAD_LABEL).map(([k,v]) => <option key={k} value={k}>{v}</option>)}
            </select>
            <select value={filtros.estado} onChange={e => { setFiltros(f => ({ ...f, estado:e.target.value })); setPagina(1); }} style={{ padding:"7px 10px", fontSize:12, border:`1px solid ${C.brd}`, borderRadius:7 }}>
              <option value="todos">Todos los estados</option>
              {Object.entries(ESTADOS).map(([k,v]) => <option key={k} value={k}>{v.label}</option>)}
            </select>
          </div>
          <div style={{ background:C.sfc, border:`1px solid ${C.brd}`, borderRadius:12, overflow:"hidden" }}>
            <table style={{ width:"100%", borderCollapse:"collapse" }}>
              <thead>
                <tr style={{ background:C.bg }}>
                  {["Fecha","Hora","Equipo","Paciente","Prestación","Estado","Consent.",""].map(h => (
                    <th key={h} style={{ padding:"9px 12px", textAlign:"left", fontSize:10, fontWeight:700, color:C.txl, textTransform:"uppercase", borderBottom:`1px solid ${C.brd}` }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {listaPagina.length === 0 && (
                  <tr><td colSpan={8} style={{ padding:26, textAlign:"center", fontSize:12, color:C.txl }}>No se encontraron órdenes con estos filtros.</td></tr>
                )}
                {listaPagina.map(o => {
                  const eq = EQUIPOS.find(x => x.id === o.equipoId);
                  const est = ESTADOS[o.estado];
                  const cons = CONSENT_ESTADOS[o.consentimientoEstado];
                  return (
                    <tr key={o.id} onClick={() => verDetalleOrden(o)} style={{ borderBottom:`1px solid ${C.brd}`, cursor:"pointer" }}>
                      <td style={{ padding:"9px 12px", fontSize:11, color:C.txt }}>{o.fecha.slice(8,10)}/{o.fecha.slice(5,7)}</td>
                      <td style={{ padding:"9px 12px", fontSize:11, color:C.txt }}>{o.hora}</td>
                      <td style={{ padding:"9px 12px", fontSize:11, color:C.txt }}>{eq ? eq.nombre : "—"}</td>
                      <td style={{ padding:"9px 12px" }}>
                        <div style={{ fontSize:11, fontWeight:600, color:C.txt }}>{nombreCompletoPaciente(o.paciente)}</div>
                        <ACCPill acc={o.acc}/>
                      </td>
                      <td style={{ padding:"9px 12px", fontSize:11, color:C.txm }}>{o.nombreFinal}</td>
                      <td style={{ padding:"9px 12px" }}><Badge c={est.color} sm>{est.label}</Badge></td>
                      <td style={{ padding:"9px 12px" }}>{o.requiereConsentimiento ? <Badge c={cons.color} sm>{cons.label}</Badge> : <span style={{ fontSize:10, color:C.txl }}>—</span>}</td>
                      <td style={{ padding:"9px 12px", textAlign:"right" }}><ArrowRight size={13} color={C.txl}/></td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginTop:12, flexWrap:"wrap", gap:8 }}>
            <span style={{ fontSize:11, color:C.txl }}>{listaFiltrada.length} órdenes encontradas</span>
            <div style={{ display:"flex", gap:6, alignItems:"center" }}>
              <Btn v="ghost" sz="sm" icon={ChevronLeft} dis={pagina <= 1} onClick={() => setPagina(p => p - 1)}>Anterior</Btn>
              <span style={{ fontSize:11, color:C.txm }}>{pagina} / {totalPaginas}</span>
              <Btn v="ghost" sz="sm" icon={ChevronRight} dis={pagina >= totalPaginas} onClick={() => setPagina(p => p + 1)}>Siguiente</Btn>
            </div>
          </div>
        </div>
      )}

      {vista === "auditoria" && (
        <div>
          <div style={{ display:"flex", alignItems:"flex-start", gap:8, marginBottom:12, padding:"10px 12px", background:`${C.pri}08`, borderRadius:9, fontSize:11, color:C.txm }}>
            <Lock size={13} color={C.pri} style={{ flexShrink:0, marginTop:1 }}/>
            <span>Registro de trazabilidad de esta sesión: quién crea, confirma o cancela una solicitud. Base de un futuro <strong>AuditEvent</strong> (FHIR) — hoy vive solo en memoria.</span>
          </div>
          <div style={{ background:C.sfc, border:`1px solid ${C.brd}`, borderRadius:12, overflow:"hidden" }}>
            <table style={{ width:"100%", borderCollapse:"collapse" }}>
              <thead>
                <tr style={{ background:C.bg }}>
                  {["Fecha/Hora","Usuario","Rol","Acción","Detalle"].map(h => (
                    <th key={h} style={{ padding:"9px 12px", textAlign:"left", fontSize:10, fontWeight:700, color:C.txl, textTransform:"uppercase", borderBottom:`1px solid ${C.brd}` }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {auditoria.length === 0 && (
                  <tr><td colSpan={5} style={{ padding:26, textAlign:"center", fontSize:12, color:C.txl }}>Aún no hay acciones registradas en esta sesión.</td></tr>
                )}
                {auditoria.map(a => (
                  <tr key={a.id} style={{ borderBottom:`1px solid ${C.brd}` }}>
                    <td style={{ padding:"8px 12px", fontSize:10, color:C.txm, whiteSpace:"nowrap" }}>{a.ts}</td>
                    <td style={{ padding:"8px 12px", fontSize:11, color:C.txt, fontWeight:600 }}>{a.actorNombre}</td>
                    <td style={{ padding:"8px 12px" }}><Badge c={C.tea} sm>{a.actorRol}</Badge></td>
                    <td style={{ padding:"8px 12px", fontSize:11, color:C.txt }}>{a.accion}</td>
                    <td style={{ padding:"8px 12px", fontSize:11, color:C.txm }}>{a.detalle}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {ordenSel && (
        <PanelDetalle
          orden={ordenSel} equipo={EQUIPOS.find(e => e.id === ordenSel.equipoId)}
          historial={historialDeCupo(ordenes, movimientosCupo, auditoria, ordenSel.equipoId, ordenSel.fecha, ordenSel.hora, ordenSel.id, bloqueos)}
          onClose={() => setOrdenSel(null)}
          onConfirmar={() => cambiarEstado(ordenSel.id, "confirmado", `Confirmó la orden de ${nombreCompletoPaciente(ordenSel.paciente)}`, "Confirmó orden")}
          onDesconfirmar={() => cambiarEstado(ordenSel.id, "agendado", `Desconfirmó la orden de ${nombreCompletoPaciente(ordenSel.paciente)}`, "Desconfirmó orden")}
          onActivarLlegada={(canal) => activarLlegada(ordenSel, canal)}
          onNoShow={() => cambiarEstado(ordenSel.id, "no_show", `Marcó inasistencia de ${nombreCompletoPaciente(ordenSel.paciente)}`, "Marcó no-show", { estadoAntesDeNoShow: ordenSel.estado })}
          onRevertirNoShow={() => cambiarEstado(ordenSel.id, ordenSel.estadoAntesDeNoShow || "agendado", `Revirtió la inasistencia de ${nombreCompletoPaciente(ordenSel.paciente)}`, "Revirtió no-show")}
          auditoria={auditoria}
          onCancelar={() => setCancelandoOrden(ordenSel)}
          onModificar={() => abrirModificarSolicitud(ordenSel)}
          onMover={() => setMoviendoOrden(ordenSel)}
          onReagendar={() => abrirReagendarSolicitud(ordenSel)}
          onAgregarNotaCita={(texto) => agregarNotaCita(ordenSel.id, texto)}
          onEliminarNotaCita={(id) => eliminarNotaCita(ordenSel.id, id)}
          autor={nombreUsuario(usuarioActual)}
          cantEventosNotas={auditoria.filter(a => a.entidad === `notaCita:${ordenSel.id}`).length}
          bloqueoActual={bloqueoDeCupo(bloqueos, ordenSel.equipoId, ordenSel.fecha, ordenSel.hora)}
          onVerHistorialNotas={() => setHistorialNotasSel({ entidad:`notaCita:${ordenSel.id}`, titulo:`Notas de la Cita · ${nombreCompletoPaciente(ordenSel.paciente)}` })}
        />
      )}
      {moviendoOrden && <ModalMoverCita orden={moviendoOrden} bloqueoEn={bloqueoEn} onMover={(eq, fe, ho) => { if (moverOrdenPorDrag(moviendoOrden.id, eq, fe, ho, "mover")) setMoviendoOrden(null); }} onCerrar={() => setMoviendoOrden(null)}/>}
      {cancelandoOrden && (
        <ModalMotivoCancelacion
          paciente={nombreCompletoPaciente(cancelandoOrden.paciente)}
          onCerrar={() => setCancelandoOrden(null)}
          onConfirmar={(motivo) => {
            cambiarEstado(cancelandoOrden.id, "cancelado", `Canceló la orden de ${nombreCompletoPaciente(cancelandoOrden.paciente)} — motivo: ${motivo}`, "Canceló orden", { motivoCancelacion: motivo });
            setCancelandoOrden(null);
          }}
        />
      )}
      {bloqueoSelId && (() => {
        const b = bloqueos.find(x => x.id === bloqueoSelId);
        return b ? <PanelBloqueo bloqueo={b} equipo={EQUIPOS.find(e => e.id === b.equipoId)} citas={citasEnBloqueo(ordenes, b)} cupoSel={bloqueoSelCupo} onClose={() => setBloqueoSelId(null)} onVerCita={(o) => { setBloqueoSelId(null); verDetalleOrden(o); }} onQuitar={(lib) => quitarBloqueo(b, lib)}/> : null;
      })()}
      {formBloqueo && <ModalBloqueo form={formBloqueo} setForm={setFormBloqueo} ordenes={ordenes} onGuardar={guardarBloqueo} onCerrar={() => setFormBloqueo(null)}/>}
      {historialNotasSel && (
        <PanelHistorialNotas titulo={historialNotasSel.titulo} eventos={auditoria.filter(a => a.entidad === historialNotasSel.entidad)} onCerrar={() => setHistorialNotasSel(null)}/>
      )}
      {cupoVacioSel && (
        <PanelCupoVacio
          slot={cupoVacioSel} equipo={EQUIPOS.find(e => e.id === cupoVacioSel.equipoId)}
          historial={historialDeCupo(ordenes, movimientosCupo, auditoria, cupoVacioSel.equipoId, cupoVacioSel.fecha, cupoVacioSel.hora, null, bloqueos)} auditoria={auditoria}
          onClose={() => setCupoVacioSel(null)}
          onNuevaSolicitud={() => {
            const eq = EQUIPOS.find(e => e.id === cupoVacioSel.equipoId);
            abrirNuevaSolicitud({ modalidad: eq?.modalidad, equipoId: cupoVacioSel.equipoId, fecha: cupoVacioSel.fecha, hora: cupoVacioSel.hora });
            setCupoVacioSel(null);
          }}
        />
      )}
      {form && (
        <ModalNuevaSolicitud bloqueoDestino={bloqueoEn(form.equipoId, form.fecha, form.hora)} form={form} setForm={setForm} pacientes={pacientesRegistro} medicosReferentes={medicosReferentes} onAgregarMedico={agregarMedicoReferente} onGuardar={guardarNuevaSolicitud} onCerrar={() => setForm(null)}/>
      )}
    </div>
    <div className="axon-img-notas">
      <LeyendaEstados/>
      <BloqueNotas
        fechaSel={fechaSel} modalidad={modalidadFoco}
        notasGenerales={notasGenerales} notasPorDiaSemana={notasPorDiaSemana} notasPorFecha={notasPorFecha}
        onAgregar={agregarNota} onEliminar={eliminarNota}
       auditoria={auditoria} onVerHistorial={(entidad, titulo) => setHistorialNotasSel({ entidad, titulo })}/>
    </div>
    </div>
    <div style={{ position:"fixed", top:16, right:16, zIndex:99999, display:"flex", flexDirection:"column", gap:8, maxWidth:320 }}>
      {toasts.map(t => {
        const col = t.tipo === "warning" ? C.war : t.tipo === "success" ? C.suc : t.tipo === "error" ? C.dan : C.pri;
        return (
          <div key={t.id} style={{ background:"#1B2A3B", color:"#fff", borderLeft:`4px solid ${col}`, borderRadius:8, padding:"10px 14px", fontSize:12, boxShadow:"0 6px 20px rgba(0,0,0,0.25)", display:"flex", alignItems:"flex-start", gap:8 }}>
            {t.tipo === "warning" ? <AlertTriangle size={14} color={col} style={{ flexShrink:0, marginTop:1 }}/> : <Info size={14} color={col} style={{ flexShrink:0, marginTop:1 }}/>}
            <span style={{ flex:1 }}>{t.msg}</span>
            <button onClick={() => setToasts(prev => prev.filter(x => x.id !== t.id))} style={{ background:"none", border:"none", cursor:"pointer", padding:0 }}><X size={12} color="#90A4AE"/></button>
          </div>
        );
      })}
    </div>
    </ForensicWatermark>
  );
}
