# AXON — Módulo Contabilidad
## Dossier Técnico y Documento de Sincronización con MAIN

**Fecha:** 2026-08-30 · **Última actualización de contenido:** 2026-10-20 · **Reemplaza/actualiza a:** la versión de este mismo archivo del 2026-08-25, y a `AXON_Contabilidad_Dossier_Tecnico.md` (2026-07-20)
**Estado del módulo:** 11 de 13 secciones construidas y confirmadas · 2 pendientes (ver Parte 12) · arquitectura de evolución (Account Core) ya aprobada por Aleaxon, pendiente de aprobación formal de MAIN

---

## 🚀 PARA UNA SESIÓN NUEVA — EMPEZAR ACÁ

### ▶ ESTADO VIGENTE AL 2026-10-20 — leer primero (prevalece sobre los bloques marcados como histórico)

**Hecho desde el cierre del 2026-09-17**

- **Refactor de Patient Financial Profile a 3 niveles + contexto organizacional UnitShell v2.0 — COMPLETADO** en `ContabilidadIngresos.jsx` (guardado el 2026-10-16; la decisión de hacerlo en un solo pase se tomó el 2026-10-06). El archivo pasó de 1.424 a **1.752 líneas** y de 27 a **32 exports nombrados**. Solo cambió el bloque Charge + PatientFinancialAccount (líneas 169-202 del original): cabecera, cola (átomos, mock, render, JSX) e imports son idénticos al original — la pantalla no se tocó.
  - **Exports nuevos (5):** `resolverOrgNode` (OrgNode vigente a una fecha; estados RESOLVED / UNRESOLVED / AMBIGUOUS) · `resolverContextoOrganizacional` · `construirEpisodeFinancialAccounts` (**nivel 1**, EpisodeFinancialAccount) · `resolverTenantPatientFinancialView` (**nivel 2**) · `resolverPatientFinancialProfile` (**nivel 3**).
  - **Compatibilidad:** `construirCharge(row, ctx?)` — segundo argumento opcional; ahora agrega `organizationalContext`. `resolverPatientFinancialAccount(rows, rut)` queda **@deprecated**, con la misma firma y la misma salida.
  - **Verificación:** 916 aserciones OK, 0 fallas (suite T1-T4 con arnés Node + esbuild), reproducida desde cero a partir de lo guardado. Un fallo inicial (T4.6) fue un error de ruta del propio test, no del código. Material y README en `outputs/contabilidad/refactor_pfa_unitshell/`.
  - Cierra la "decisión pendiente" que figuraba en este encabezado (Parte 8 de `AXON_Contabilidad_Archivo_Especificacion_Patient_Financial_Profile.md`).
  - **Alcance respecto de UnitShell v2.0:** se implementó únicamente el contexto OrgNode vigente a fecha dentro de Charge. Sin construir: ResponsibilityCenter/CostCenter con asignaciones vigentes, Cost Allocation Engine, distribución de costos de Payroll, Public Budget Context (perfil público), reestructuración completa de FinancialEvent y Financial Metrics Gateway para Dashboard Engine.
- **`ContabilidadHonorariosExternos.jsx` — `handleSave` ahora asigna `centroCosto`** (484 → 485 líneas, guardado el 2026-10-17). Un honorario creado desde el formulario quedaba sin centro de costo: fuera del desglose `porCentro`, con el campo vacío en el detalle y en el CSV (el "CERRADO 2026-09-04" de 2.4 estaba incompleto). Verificado ejecutando el `handleSave` real: 0/12 casos correctos antes, 12/12 después, sin regresión sobre las 56 filas del mock. Script en `outputs/contabilidad/verificaciones/test_hext_handlesave.cjs`.

**Archivos — qué ve un chat nuevo y qué hay que subir (verificado con `wc`/`grep` el 2026-10-20)**

- `/mnt/project` es de solo lectura. Sus 10 `.jsx` más `ContabilidadHelpersCompartidos.js` **ya son las versiones de las Fases 2-9** (verificado por marcadores de código, exports y el comentario de Fase 1), con **dos excepciones** cuyas versiones nuevas viven solo en `/mnt/user-data/outputs/contabilidad/` y hay que subir al proyecto: `ContabilidadIngresos.jsx` (1.752 líneas) y `ContabilidadHonorariosExternos.jsx` (485 líneas).
- **`ContabilidadCentroCostoPorUnidad.jsx` NO está en el proyecto** (hay 10 `.jsx`, no 11). La afirmación anterior de que "la versión del proyecto ya es la vigente" era incorrecta: hay que subirlo.
- Las cifras de líneas de las Partes 2.x se corrigieron con `wc -l` reales (varias estaban desfasadas por 1-2 líneas tras la consolidación de Fase 1, y la de Ingresos por mucho más).

**Pendiente vigente** (detalle en la Parte 12)

- Fase 9: Compensatory Event Framework · Maker/Checker en Conciliación Bancaria · Estados por dominio.
- Cierre Contable (2.13): bloqueado por el modelo público/privado NICSP-CGR.
- Subir al proyecto los tres archivos indicados arriba.


Este chat creció demasiado. Si estás retomando esto en un **chat nuevo dentro del mismo proyecto de Claude** ("CONTABILIAD - AXON"), lee esto primero — antes que cualquier otra parte del documento.

### (Histórico, 2026-09-17 — el estado vigente está arriba) Qué archivos había que volver a subir

Los archivos del proyecto original (`/mnt/project/`) siguen disponibles en cualquier chat nuevo del mismo proyecto — **pero los `.jsx` de Contabilidad que aparecen ahí son las versiones DE ANTES de esta sesión**. Durante esta sesión se modificaron 10 de los 11 `.jsx` y se creó 1 archivo nuevo — esas versiones actualizadas **solo existen como los archivos que te entregué para descargar**, no se guardaron de vuelta en el proyecto automáticamente. Si el chat nuevo lee directo desde `/mnt/project/ContabilidadIngresos.jsx`, va a ver 875 líneas viejas, no las 1.424 líneas con todo el trabajo de Fases 2 a 9.

**Grupo A — HAY QUE SUBIR ESTOS 11 al chat nuevo (o al proyecto), si no, se pierde el trabajo de código de esta sesión:**
`ContabilidadIngresos.jsx` (875→1424 líneas) · `ContabilidadAdquisiciones.jsx` (1121→1232) · `ContabilidadHonorariosExternos.jsx` (459→484) · `ContabilidadBalances.jsx` (319→354) · `ContabilidadEgresos.jsx` (563→625) · `ContabilidadFacturacion.jsx` · `ContabilidadFlujoCaja.jsx` · `ContabilidadObligacionesTributarias.jsx` · `ContabilidadConciliacionBancaria.jsx` · `ContabilidadHonorariosMedicos.jsx` (estos últimos 5 con cambio menor, solo el comentario de Fase 1) · **`ContabilidadHelpersCompartidos.js`** (archivo nuevo, no existe en el proyecto original).

**Incidente verificado y corregido (2026-09-17):** al consolidar Fase 1, `ContabilidadEgresos.jsx` se copió por error desde la versión original de `/mnt/project` (perdiendo la función `recibirLiquidacionRRHH` ya construida), y esa versión incompleta se entregó varias veces sin que se notara. Aleaxon detectó la inconsistencia por el tamaño del archivo. Se verificaron los 11 archivos del Grupo A, uno por uno, contra la lista completa de todo lo agregado en la sesión (no solo el último cambio) — **Egresos fue el único afectado**, ya está corregido y reconfirmado (625 líneas, 2/2 exports). Queda como recordatorio: al copiar varios archivos en lote desde `/mnt/project`, verificar primero si alguno tenía una edición previa que no venga de ahí.

**No hace falta subir:** `ContabilidadCentroCostoPorUnidad.jsx` — es el único de los 11 que no se tocó en toda la sesión, la versión del proyecto ya es la vigente.

**Grupo B — los 19 documentos `.md` de esta sesión** (dossier maestro, propuestas, archivos de fuentes, plan de trabajo) — ninguno existe en el proyecto original, son 100% nuevos. Este mismo archivo que estás leyendo es uno de ellos — si lo estás viendo, probablemente ya lo subiste.

### Mensaje sugerido para abrir el chat nuevo

> *"Continuamos el trabajo de Contabilidad de AXON. Te subí el dossier maestro actualizado (`AXON_Contabilidad_Dossier_Tecnico_y_Sincronizacion_MAIN.md`) y los `.jsx`/`.js` actualizados. Léelos y dime en qué quedamos antes de seguir."*

### (Histórico) Estado exacto al cierre de la sesión del 2026-09-17

> Superado por el estado vigente de más arriba; se conserva como registro. La "decisión pendiente" de este bloque ya está resuelta.

- **Fases 0 a 8 del Plan de Trabajo Ordenado: completas y verificadas en Node.**
- **Fase 9: parcial** — el punto 29 (correcciones menores: `exentoPct` por monto, desglose Gross/Net/Contractual/BadDebt, documentación de folio) está hecho. Los puntos 26-28 (Compensatory Event Framework, Maker/Checker para Conciliación Bancaria, Estados por dominio) **siguen sin construir**.
- **⚠️ Decisión pendiente tuya, la más importante ahora mismo:** la Especificación Maestra de Patient Financial Profile (recién archivada) reveló que `resolverPatientFinancialAccount` (Fase 3) no calza con el modelo de 3 niveles que definiste en ese documento (`EpisodeFinancialAccount → TenantPatientFinancialView → PatientFinancialProfile`) — ver `AXON_Contabilidad_Archivo_Especificacion_Patient_Financial_Profile.md` Parte 8 para el detalle completo. Falta que decidas si se refactoriza ahora o se deja para más adelante.
- Bloqueados externos sin cambio: público/privado de Balances (tu investigación NICSP-CGR en curso), catálogo 85+1 roles (MAIN), aprobación formal de MAIN sobre Account Core.

### Mapa completo de los 19 documentos — ver la tabla de la Parte 0, más abajo

---

## PARTE 0 · Cómo leer este documento, y el mapa completo de documentos del módulo

Este documento cumple tres funciones a la vez, a propósito:

1. **Dossier técnico interno** — qué hace cada uno de los `.jsx` construidos, qué expone cada uno como contrato ("puerta etiquetada"), qué parámetros legales usa y de dónde salen, y qué patrones se repiten entre secciones.
2. **Documento de sincronización con MAIN**, formato `AXON_Guia_Sincronizacion_Satelites_MAIN.md` §6: **(A)** ya alineado, **(B)** discrepancias/brechas reales, **(C)** qué aporta Contabilidad a la infraestructura compartida, **(D)** preguntas abiertas.
3. **Panorama consolidado** — desde acá se puede seguir el hilo de todo lo avanzado sin tener que abrir los 12 documentos satélite uno por uno, aunque cada uno sigue siendo la fuente de detalle completo en su tema.

### Mapa completo de documentos del módulo (todos en `/mnt/user-data/outputs/contabilidad/`)

| Documento | Rol |
|---|---|
| **Este archivo** | Dossier maestro — estado consolidado, índice de todo lo demás |
| `AXON_Contabilidad_Propuesta_Alineacion_Control_Plane_Account_Core.md` | Propuesta enviada a MAIN: límite Supply Core/Account Core, Module Catalog, `accountingProfile` |
| `AXON_Nota_Contabilidad_para_FarmaciaBodega_Supply_Core_AIMS.md` | Nota corta a Farmacia/Bodega sobre el hallazgo de AIMS |
| `AXON_Contabilidad_Investigacion_NICSP_CGR_SII_TGR.md` | Investigación propia (SII/TGR/CGR) — insumo para la investigación de Aleaxon sobre público/privado |
| `AXON_Contabilidad_Archivo_PDFs_Fuentes_Legales_y_Tecnicas.md` | Destilado de 4 PDFs (hospital público v/s privado, Facturación OAPIs, automatización, calendario de obligaciones) |
| `AXON_Account_Core_Arquitectura_Consolidada_Definitiva.md` | **Referencia vigente de Account Core** — unifica los 6 archivos siguientes, resuelve sus 3 tensiones (subledgers, perfiles, nomenclatura Radar) |
| `AXON_Contabilidad_Archivo_Account_Core_SIGFE_Baseline.md` | Superado — absorbido en el Consolidado Definitivo |
| `AXON_Contabilidad_Archivo_Account_Core_Consolidado_Final.md` | Detalle de respaldo — absorbido en el Consolidado Definitivo |
| `AXON_Contabilidad_Archivo_Account_Core_Especificacion_Ingenieria.md` | Detalle de ingeniería (testing, checklist, modelo de dominio completo) |
| `AXON_Contabilidad_Archivo_Account_Core_Payer_Revenue_Cycle.md` | Detalle clínico-financiero (Valuation Engine, Tariff versionado) |
| `AXON_Contabilidad_Archivo_Account_Core_Ingreso_Pagos_Anticipos.md` | Detalle legal (Cuenta Corriente, Giftcard/IVA) — su propuesta de subledger corregida en el Consolidado Definitivo §9 |
| `AXON_Contabilidad_Archivo_Account_Core_Revenue_Agreements_Payments_Loyalty.md` | Detalle completo del análisis multi-agente (Allocation, Compensatory Events, Maker/Checker) |
| `AXON_Contabilidad_Archivo_Modelo_Organizacional_120_Familias.md` | Dónde vive Contabilidad en el catálogo de 120 familias, concepto de CR, PBAC concreto |
| `AXON_Contabilidad_Mapeo_13_Secciones_vs_Account_Core.md` | Reconciliación entre el código real y el vocabulario de Account Core |
| `AXON_Contabilidad_Archivo_Informe_Auditoria_Correcciones.md` | Auditoría externa: 40 hallazgos, 12 pruebas matemáticas, prioridades P0/P1/P2 |
| `AXON_Contabilidad_Archivo_Respuestas_3_Completo.md` | Segunda revisión externa (4.689 líneas): DSO mal calculado (verificado y corregido), Counterparty, PaymentPurpose, Financial Preauthorization |
| `AXON_Archivo_Lineas_AXON_Monetizacion_Cobros_Pagos.md` | Tabla maestra de las 11 líneas AXON (incl. Country/World/RADE) — grounding real de `PaymentPurpose` |
| `AXON_Contabilidad_Archivo_Especificacion_Patient_Financial_Profile.md` | Especificación maestra v1.0 (8.367 líneas) — 11 decisiones confirmadas, modelo de 3 niveles de PatientFinancialAccount, FundingSource/Voucher/Subsidio |
| `AXON_Contabilidad_Plan_de_Trabajo_Ordenado.md` | Roadmap de todo lo pendiente, ordenado por dependencia real (Fase 0 en curso) |
| `ContabilidadBalances.jsx` | Versión corregida (régimen tributario ya no hardcodeado en 27%) |
| `ContabilidadEgresos.jsx` | Versión con puerta etiquetada `recibirLiquidacionRRHH` para el Módulo de RRHH/Workforce |
| `ContabilidadHonorariosExternos.jsx` | Versión con `centroCosto` agregado (gap cerrado, Fase 1) |
| `ContabilidadHelpersCompartidos.js` | Versión canónica de `fakeRUT`/`calcDV`/`semaforo` — lista para importar cuando se integre a producción |
| `ContabilidadIngresos.jsx` | Con Tax Determination Engine + Agreement Engine mínimo (Fase 2) además del comentario de Fase 1 |
| `Egresos` / `HonorariosMedicos` / `HonorariosExternos` / `Facturacion` / `Adquisiciones` / `FlujoCaja` / `ObligacionesTributarias` / `ConciliacionBancaria` | Con comentario de una línea apuntando al canónico compartido (Fase 1, sin cambio de lógica) |

Todo lo afirmado acá sobre código fue verificado leyendo los archivos reales (grep/wc, nunca de memoria). Todo lo afirmado sobre el Excel fue verificado abriendo el archivo con Python. Todo lo afirmado sobre SIGFE/CGR/SII fue verificado con búsquedas y fetch directo a fuentes oficiales (DIPRES, SII, vLex) — el detalle de cada verificación vive en los documentos satélite correspondientes.

---

## PARTE 1 · Contabilidad dentro del ecosistema AXON — contexto de una línea

Contabilidad es el módulo #29-31 (numeración difiere levemente entre hojas del Excel — Parte 7.3) dentro de AXON Health & Core, alimenta a "Alta Dirección → KPI's Financieros" (confirmado en la hoja `Modulos` del Excel), y es el único módulo, junto con Alta Dirección y AXON NID Bridge, marcado presente para los **26 tipos de tenant** en la hoja `Hoja1` del Excel, sin excepción.

**Dirección de evolución aprobada:** Contabilidad evoluciona hacia **Account Core**, un único motor financiero multi-tenant configurable por perfil (AXON Health / hospital público / clínica privada / centro médico / profesional independiente), no 13 pantallas ni 5 códigos distintos. Ver Parte 8.

---

## PARTE 2 · Inventario técnico — 13 secciones (11 construidas, 2 pendientes)

### 2.1 — Ingresos (`ContabilidadIngresos.jsx`, 1.752 líneas tras el refactor del 2026-10-16; 1.424 antes)
> **Legacy/transicional (2026-09-04), parcialmente resuelto por Fase 2:** el campo `pagador` sigue siendo el resumen de interfaz. Se agregaron dos motores mínimos (ver abajo) que empiezan a separar Convenio/Impuesto de Pagador, sin romper nada de lo que ya funcionaba — verificado en Node contra los 56 casos posibles y contra los 4 convenios existentes.
> **CORREGIDO 2026-09-05:** el KPI "DSO" en realidad medía fecha de prestación→facturación (Billing Lag), no factura→cobro (DSO real) — renombrado a `diasParaFacturar`. El DSO real no se puede calcular todavía porque `fechaPago` no existe en el archivo (verificado, no está en ningún lado).

Ingresos por unidad clínica (8) y pagador (7: Fonasa MAI/MLE, Isapre, Particular, Mutual, Internacional, Convenio Institucional/CUC).
- **Copago vs. bonificación** — `calcularDesgloseCopago(monto, pagador)`. `PARAMS_COPAGO_PCT`: `fonasa_mai=0` (Copago Cero, sept-2022), `fonasa_mle=0.35`, `isapre=0.25`, `particular=1.00`, `mutual=0`, `internacional=0`, `convenio_institucional=0.10`.
- **IVA** — `condicionIVA(unidad, pagador)`: laboratorio siempre afecto; ambulatorio sin alojamiento exento (Art. 12 letra E N°20); hospitalización/pabellón exento hasta arancel (N°19), afecto si particular/internacional.
- **Contrato exportado (32 nombrados + el componente por defecto; eran 27 antes del refactor del 2026-10-16):** ver Plan de Trabajo Ordenado para el detalle por fase y el estado vigente (arriba) para los 5 nuevos (contexto OrgNode vigente a fecha y los 3 niveles de Patient Financial Profile). Líneas: 875 originales → 1.424 tras las Fases 2-9 → 1.752 tras el refactor (las cifras "933" y "1403" que figuraban antes estaban desactualizadas).
- **Tax Determination Engine:** envuelve `condicionIVA()`/`motivoIVA()` (sin tocar esa lógica) y devuelve el shape `TaxResult` del documento consolidado (§7). Verificado en Node: 100% consistente con la lógica original en las 56 combinaciones posibles de unidad×pagador. No inventa fecha de vigencia (`effectiveFrom: null`) hasta confirmarla con fuente real.
- **Agreement Engine mínimo:** cada convenio ahora tiene `agreementId` (interno) separado de `cuc` (identificador de negocio) y `tipoConvenio: 'tenant'`. `resolverConvenio(cuc)` es la puerta etiquetada para cuando exista un Agreement Engine real. No se tocó el string de CUC (pendiente #17, a propósito).
- **KPIs con meta:** facturación ≥90%, atascados ≤10%, Días para Facturar ≤3 días (renombrado el 2026-09-05: mide prestación→factura, no es DSO).
- **Único con estado `conciliado`** — cierra el ciclo completo.

### 2.2 — Egresos (`ContabilidadEgresos.jsx`, 625 líneas)
7 categorías × 10 centros de costo. `recurrente` + `dentroConvenio` como banderas independientes.
- **Contrato exportado:** `calcularKPIsEgresos(rows)`, **`recibirLiquidacionRRHH({...}, idBase)`** (nueva, 2026-09-02).
- **Puerta etiquetada para el MÓDULO DE RECURSOS HUMANOS / WORKFORCE** (motor separado, confirmado por Aleaxon — no es sección de Contabilidad). Recibe sueldo bruto + desglose de descuentos (AFP/Fonasa-Isapre/Cesantía/Mutualidad) y calcula automáticamente el vencimiento real de Previred (día 13 del mes siguiente al período, con rollover de diciembre a enero verificado en Node). Mientras RRHH/Workforce no exista, nadie la llama y Egresos sigue igual.
- **Gap conocido:** sin estado `conciliado` — pausado explícitamente por Aleaxon ("esperemos esto aún").

### 2.3 — Honorarios Médicos y de Personal (`ContabilidadHonorariosMedicos.jsx`, 530 líneas)
`TASA_RETENCION_HONORARIOS = 0.1525` — **verificado 2026-08-28 contra comunicado oficial del SII (dic-2025): correcto para 2026.** Escala legislada hasta 17% en 2028 (Ley 21.133) — recordatorio de Aleaxon: tratar siempre como parámetro versionado, no como constante fija, porque valores como este cambian por ley cada año.
- **Contrato exportado:** `calcularKPIsHonorarios(rows)`.
- Bloqueada para reemplazo de catálogo (85+1 roles) hasta que MAIN confirme Matrona/Matrón en `roles.config.js`.

### 2.4 — Honorarios Externos (`ContabilidadHonorariosExternos.jsx`, 485 líneas tras el fix de handleSave del 2026-10-17; 484 antes)
Doble vía: Persona Natural → BHE + retención 15,25%; Empresa → Factura + IVA 19%.
- **Contrato exportado:** `calcularKPIsHonorariosExternos(rows)`.
- **CERRADO 2026-09-04:** ya captura `centroCosto` (mapeado desde categoría, mismas claves que Egresos) — era el único gap real detectado en el Mapeo contra Account Core. Agregado también a la agregación KPI (`porCentro`) y al CSV exportado. **Completado el 2026-10-17:** `handleSave` (registro nuevo desde el formulario) no asignaba `centroCosto`; corregido con 1 línea (ver estado vigente).
- **Gap:** tampoco llega a `conciliado`.

### 2.5 — Facturación (`ContabilidadFacturacion.jsx`, 539 líneas)
DTE 33/34/39/41, CAF por tipo, vigencia 6 meses. Compone desde Ingresos.
- **Contrato exportado:** `emitirDTE(borrador, cafPool)`, `calcularKPIsFacturacion(documentos, cafPool)`.
- **Referencia técnica real cuando se conecte:** librerías verificadas en el archivo de PDFs — `@devlas/dte-sii` (npm, MIT, confirmado real) y `gepd/HTTP-DTE` (GitHub, MIT, confirmado real, envuelve LibreDTE en Docker).
- **Punto de apoyo real más avanzado** — `CoreAdapter` ya tiene endpoint de facturas (ver Parte 6).

### 2.6 — Adquisiciones (`ContabilidadAdquisiciones.jsx`, 1232 líneas)
Requisición→Solicitada→Aprobada→Enviada→Recibida→Facturada. 3 vías, Acuse de Recibo 8 días corridos, NC/ND, `ROLES_FINANCIEROS`.
- **Contrato exportado (8 en total tras Fase 8):** `calcularKPIsAdquisiciones(rows)`, `recibirRequisicion({...}, idBase)`, **`resolverDominioResponsable(categoria)`, `evaluarTresVias(row)`, `crearCommitment(row, aprobadoPor)`, `devengarCommitment(commitment, tresVias)`, `emitirPurchaseOrderApproved(row, aprobadoPor)`, `emitirGoodsReceived(row)`** (Fase 8, nuevas 2026-09-09).
- **Corte Supply Core/AIMS/Account Core EJECUTADO 2026-09-09** (antes solo aprobado en documento): `resolverDominioResponsable` mapea las 5 categorías — `insumos_clinicos`→SUPPLY_CORE, `equipamiento_medico`/`mobiliario`/`tecnologia`→AIMS, `servicios_generales`→ACCOUNT_CORE. Nada del flujo actual se eliminó (Supply Core/AIMS no existen como módulos reales todavía) — se agregó la frontera explícita y los eventos de traspaso (`PurchaseOrderApproved`, `GoodsReceived`, mismos nombres que el catálogo de eventos del Documento Maestro §12), listos para cuando esos módulos existan.
- **3-way match formalizado:** `evaluarTresVias` ahora compara cantidad Y monto facturado (antes eran 2 derivaciones sueltas en el render, `hay3Vias`/`discrepancia3Vias` — siguen funcionando igual, esta es la versión reutilizable). Verificado en Node con 4 casos: calce perfecto, descalce de cantidad, descalce de monto, y sin recepción/factura todavía.
- **Procurement Commitment:** nace al aprobar (`crearCommitment`), se devenga solo si pasan las 3 vías (`devengarCommitment` — verificado que rechaza devengar con descalce). Separa Compromiso/Devengo/Pago como 3 momentos distintos, crítico para tenants públicos.

### 2.7 — Balances (`ContabilidadBalances.jsx`, 354 líneas)
Estado de Resultados + Estado de Situación Financiera, NIIF.
- **CORREGIDO 2026-08-28:** el impuesto a la renta mensual ya no está fijo en 27% — ahora hay un selector real (`REGIMENES`: 14A=27%, Pro Pyme 14D N°3=12,5%), igual al que ya existía en Obligaciones Tributarias. Verificado en Node: con régimen 14A los números son idénticos a los de antes del fix (nadie ve un cambio sin elegir Pro Pyme); el balance sigue cuadrando en los 14 casos probados (7 meses × 2 regímenes).
- **Contrato exportado:** `calcularIndicadoresBalance(resultados, balance)` (firma sin cambios).
- **Hallazgo grande de investigación (2026-08-28), pendiente de aplicar — bloqueado por decisión de Aleaxon:** los hospitales públicos probablemente **no pagan Impuesto a la Renta en absoluto**. Art. 40 N°1 LIR exime a instituciones/organismos autónomos del Estado; los Servicios de Salud (DFL 1/2005) encajan en esa categoría; jurisprudencia SII real (Ord. 1306/2018) confirma el mismo criterio para una farmacia municipal. Si se confirma, el selector de régimen que acabamos de corregir **no aplicaría en absoluto** a un tenant público — no sería "otra tasa", sería la ausencia de la obligación (salvo actividades puntuales con ánimo de lucro real). Ver Parte 10.

### 2.8 — Flujo de Caja (`ContabilidadFlujoCaja.jsx`, 486 líneas)
> **Legacy/transicional (2026-09-04):** hoy compone solo desde Ingresos+Egresos+Hon.Médicos+Hon.Externos. En la arquitectura objetivo, también debería escuchar eventos del dominio Prepayments & Stored Value — un convenio institucional prepagado de $20M impacta el flujo de caja real mucho antes de reconocerse como ingreso clínico (ver `AXON_Account_Core_Arquitectura_Consolidada_Definitiva.md` §17).

Compone desde Ingresos+Egresos+Hon.Médicos+Hon.Externos. Separa copago (inmediato) de bonificación (con desfase).
- **Contrato exportado:** `recibirMovimientoCaja`, `calcularProyeccionFlujoCaja`.

### 2.9 — Obligaciones Tributarias (`ContabilidadObligacionesTributarias.jsx`, 469 líneas)
F29 mensual, composición pura. Remanente de crédito fiscal con arrastre real. `REGIMENES` (14A/Pro Pyme). Interés moratorio confirmado solo para 1er semestre 2026.
- **Contrato exportado:** `calcularKPIsObligacionesTributarias(...)`.
- **Nuevo del archivo de PDFs:** calendario más fino disponible — F29 día 20/22, RCV antes del cierre F29, Previred día 13 (AFP/Fonasa-Isapre/Cesantía/Mutualidad, solo con trabajadores), Libro de Remuneraciones DT día 15 (solo 5+ trabajadores), Patentes municipales enero/julio — ninguno de estos últimos tres está modelado hoy.

### 2.10 — Centro de Costo por Unidad (`ContabilidadCentroCostoPorUnidad.jsx`, 473 líneas según el registro previo; archivo ausente de /mnt/project, no verificable el 2026-10-20)
Centro de Costo vs. Subtítulo Presupuestario (21/22/29) como ejes independientes.
- **Contrato exportado:** `calcularKPIsCentroCosto(...)`.
- **Cruce con Account Core:** la Financial Dimension Matrix del Consolidado Final (Parte 8) trata Cost Center y Budget Account como 2 de 12 dimensiones posibles — confirma que este archivo ya modela bien 2 ejes reales, con espacio para más si se necesitan (Fund, Program, Project, Branch).

### 2.11 — Conciliación Bancaria (`ContabilidadConciliacionBancaria.jsx`, 457 líneas)
> **Legacy/transicional (2026-09-04):** hoy compone directo desde Ingresos. En la arquitectura objetivo se alimentaría desde la fase de Settlement de Payment Orchestration — los lotes que cruzan contra la cartola son liquidaciones de Transbank/MercadoPago/transferencias masivas, no el registro clínico en sí (ver `AXON_Account_Core_Arquitectura_Consolidada_Definitiva.md` §17). El Maker/Checker de §11 de ese mismo documento es, además, la resolución concreta de la brecha de segregación de funciones de esta sección.

Motor N:1, `sugerirConciliaciones()`. Compone desde Ingresos.
- **Contrato exportado:** `sugerirConciliaciones(...)`, `calcularKPIsConciliacion(...)`.
- **Gap confirmado por 2 fuentes independientes:** sin segregación de funciones — Resolución Exenta 1.962/2022 CGR citada tanto en nuestra investigación original como, de forma independiente, en el PDF de "Hospital público v/s privado".
- Solo cierra el lado de Ingresos — Egresos/Honorarios nunca llegan a `conciliado` (no tienen ese estado).

### 2.12 — Remuneraciones CUT — reclasificada 2026-09-02: no es nuestra sección
Aparece en la hoja `Modulos` del Excel, pero Aleaxon confirmó (2026-09-02) que existe un módulo/motor **Workforce (RRHH)** independiente que la maneja, sincronizándose con Contabilidad más adelante. **Ya no está pendiente de construir como sección propia** — lo pendiente ahora es dejar una puerta etiquetada en Egresos para recibir esos datos cuando Workforce exista.

### 2.13 — Cierre Contable, Auditorías y Balance Anual (pendiente de construir)
Bloqueado por resolver primero el modelo público/privado de Balances (2.7). Cuando se retome, el flujo de referencia ya existe: Closing Engine del Consolidado Final (Parte 8) — `MONTH-END CLOSE → SUBLEDGER CHECKS → BUDGET CHECKS (si aplica) → BANK/TREASURY → TAX/COMPLIANCE → DEBIT=CREDIT → VALIDATION ENGINE → CLOSE CANDIDATE → APPROVAL → FINAL CLOSE → LOCK PERIOD → FINANCIAL STATEMENTS`.

---

## PARTE 3 · Patrones transversales

| Patrón | Dónde se usa | Qué resuelve |
|---|---|---|
| **Puerta etiquetada** | Las 13 secciones | Reemplazar el mock por la fuente real sin tocar la pantalla |
| **Composición sin duplicar** | Facturación, Flujo de Caja, Obligaciones Tributarias, Centro de Costo, Conciliación Bancaria | No duplican dataset, leen de las secciones dueñas |
| **3 vías + factura retenida + NC/ND** | Adquisiciones | Reutilizable por cualquier módulo de compras |
| **N:1 en conciliación** | Conciliación Bancaria | Lotes reales (Fonasa/Isapre) |
| **Doble vía documental** (BHE vs. Factura) | Honorarios Externos, Adquisiciones, Egresos | Reutilizable con proveedores mixtos |
| **Parámetro legal versionado** | `TASA_RETENCION_HONORARIOS`, `UTM_VALOR_REFERENCIA`, `PARAMS_COPAGO_PCT`, `TASA_INTERES_MORA`, `REGIMENES` | Nunca hardcodeado sin fuente/fecha — principio reforzado ahora también por Account Core §23 (Consolidado Final) |

**Nota de evolución:** Account Core formaliza "puerta etiquetada" como **Financial Event Model** (Clinical/Supply/Procurement/Billing/HR-Payroll/Treasury/Fleet Event → Financial Event → Validation → Subledger/GL) — mismo espíritu, vocabulario más preciso. Ver Parte 8.

### 3.1 — Grafo de dependencias real (verificado)

```
Ingresos / Egresos / Hon.Médicos / Hon.Externos / Adquisiciones / Balances   (fuente propia)
        │
        ├── Facturación             ← Ingresos
        ├── Flujo de Caja           ← Ingresos + Egresos + Hon.Médicos + Hon.Externos
        ├── Obligaciones Tributarias ← Ingresos + Egresos + Hon.Médicos + Hon.Externos
        ├── Centro de Costo         ← Egresos + Hon.Médicos + Hon.Externos
        └── Conciliación Bancaria   ← Ingresos (estado='pagado')
```

### 3.2 — Duplicación de código — consolidada 2026-09-04

- **`fakeRUT()`+`calcDV()`**: seguía duplicada en 4 archivos (Ingresos, Hon.Médicos, Hon.Externos, Facturación) — verificado que las 3 copias de `calcDV` eran idénticas, y que las bases/multiplicadores distintos de `fakeRUT` en cada archivo eran a propósito (para no repetir los mismos RUT falsos entre pacientes/doctores/proveedores). Se creó `ContabilidadHelpersCompartidos.js` con una versión parametrizada (`fakeRUT(seed, base, multiplicador)`) que reproduce exacto los 3 comportamientos — verificado en Node contra los 4 archivos originales, sin fallas en 5 seeds distintas. Los 4 archivos originales no se tocaron en su lógica, solo se les agregó un comentario de una línea apuntando a la versión canónica.
- **`semaforo()`**: seguía duplicada en 9 de 13 archivos (todos menos Balances y Centro de Costo — confirmado que no es casualidad: son las únicas 2 secciones que solo reportan/agregan, no transaccionan). **Hallazgo extra encontrado al consolidar:** Ingresos usaba colores hex fijos (`#2E7D32`/`#C62828`/`#B45309`) en vez de los tokens `C.pri`/`C.err`/`C.warn` que usan los otros 8 — corregido (mismos colores exactos, verificado que `C.pri` etc. ya tenían esos mismos valores hex en ese archivo). Los otros 8 archivos no cambiaron su lógica, solo comentario de referencia.

**Ninguno de los 9 archivos importa de `ContabilidadHelpersCompartidos.js` todavía** — a propósito, cada uno sigue siendo standalone-previsualizable (principio de la Parte 0). El import real ocurre recién al integrar a producción, tal como ya estaba planeado desde el dossier original.

---

## PARTE 4 · Sincronización con MAIN (formato A/B/C/D)

### (A) Ya alineado con MAIN

- CUC de Ingresos coincide con `cup.js` (✅ confirmado).
- `ROLES_FINANCIEROS` de Adquisiciones calza con el Excel PBAC+RBAC.
- Patrón "puerta etiquetada" coincide con el Motor DICOM.
- Contabilidad presente para los 26 tipos de tenant, coincide con `PERFIL_FARMACIA` de la Hoja de Ruta.
- **Nuevo:** la estructura de SIGFE que describe el Consolidado Final coincide casi textual con la página oficial de DIPRES — verificado por fetch directo.
- **Nuevo:** el límite Supply Core/Account Core de Adquisiciones ya no es hipótesis — confirmado como "decisión consolidada" en `AXON Supply Core.docx` mismo.
- **Nuevo:** Resolución Exenta 1.962/2022 CGR (segregación de funciones) confirmada de forma independiente por 2 fuentes (nuestra investigación + el PDF de hospital público/privado).

### (B) Discrepancias y brechas reales

1. Sin PBAC real para Contabilidad (273 filas del Excel, 0 con URN/Acción/Condición/Alcance). **Sigue abierto.**
2. "Remuneraciones CUT" — tres fuentes que no calzan. **Sigue abierto, ahora con más detalle concreto (Previred/Libro DT) para decidir.**
3. `Tipos Tenant` vs. `Hoja1` sobre Contabilidad. **Sigue abierto.**
4. Egresos/Hon.Médicos/Hon.Externos nunca llegan a `conciliado`. **Sigue abierto.**
5. Sin segregación de funciones en Conciliación Bancaria. **Sigue abierto, con doble confirmación de fuente.**
6. Sin generador de CUIT en `cup.js`. **Sigue abierto, no bloquea nada hoy.**
7. Duplicación `fakeRUT`/`semaforo`. **Sigue abierto, deuda de consolidación de bajo riesgo.**
8. `CoreAdapter` real solo cubre 2 de 13 secciones. **Sigue así, esperado en esta etapa.**
9. **Nuevo:** "Privado" no es un bloque uniforme — una clínica **S.A. abierta** (Ley 18.046) tiene una capa adicional real de CMF con auditoría trimestral, que una clínica privada común no tiene. Candidato a campo `requiresCMFAudit` en `accountingProfile`.
10. **Nuevo:** el hallazgo de que Adquisiciones podría partirse en 3 dominios (Supply Core/AIMS/Account Core), no 2 — sin confirmar por MAIN.

### (C) Lo que Contabilidad aporta a la infraestructura compartida

Ver Parte 3 (patrones + grafo + duplicaciones). **Ahora además:** toda la arquitectura de Account Core (Parte 8) — Budget Ledger/GL, Financial Dimension Matrix, Validation Engine, Closing Engine, están todas ya aprobadas por Aleaxon como dirección de evolución del módulo completo, con una separación explícita de qué decide Contabilidad y qué decide MAIN (Parte 8.7).

### (D) Preguntas — respondidas por Aleaxon el 2026-09-02 (`respuestas_para_contabilidad_1.txt`)

1. **Remuneraciones CUT — RESUELTO.** No es sección de Contabilidad ni ampliación de Egresos: existe un módulo/motor **Workforce (RRHH)** separado, que se sincronizará con Contabilidad más adelante. Acción concreta pendiente: dejar una **puerta etiquetada** en Egresos (tipo `recibirLiquidacionRRHH(...)`) lista para esa conexión futura. Sección 2.12 del dossier se reclasifica de "pendiente de construir" a "no nos corresponde construirla — preparar puerta de entrada".
2. **`Hoja1` vs. `Tipos Tenant` — sigue abierto.** En resolución activa junto con PBAC+RBAC y TenantType. Principio confirmado: **un solo software multiconfigurable y adaptativo a toda naturaleza**, no forks por tipo — coincide exacto con la arquitectura de Account Core ya aprobada.
3. **`conciliado` en Egresos/Honorarios — pausado explícitamente** ("esperemos esto aún"). No construir todavía.
4. **`default_enabled=true` universal — CONFIRMADO 2026-09-02, con matiz importante.** Sí, para cualquier tenant sin excepción — pero debe existir la opción de **deshabilitarlo por tenant específico** si alguno quiere prescindir del módulo, aunque Contabilidad es el "enganche comercial" de AXON y un argumento de venta fuerte. Esto es exactamente el patrón `Tenant Type (default) → Tenant Configuration (override real)` que ya documenta `AXON Health — Arquitectura Maestra de Tenant Types...md` — no es una excepción nueva, es la aplicación directa de ese principio ya aprobado.
5. **"Complejo Fronterizo" — decisión de MAIN**, no de Contabilidad. Nuestro deber es estar preparados para cualquier naturaleza comercial, independiente de qué decida MAIN sobre el catálogo de tipos.
6. **Corte de Adquisiciones en 3 dominios (Supply Core/AIMS/Account Core) — APROBADO.** Instrucción explícita: dejar puertas para integraciones/configuraciones posteriores.
7. **Lista completa de aprobaciones de Account Core (Parte 8.7) — APROBADA de parte de Contabilidad.** Queda a la espera de las indicaciones que correspondan de MAIN sobre lo que a ellos les toca decidir.

---

## PARTE 5 · Contratos exportados

| Archivo | Función(es) | Firma |
|---|---|---|
| Ingresos | 32 exports nombrados (27 de las Fases 2-7: Tax, Agreement, Counterparty, Charge, PatientFinancialAccount **@deprecated**, Claim/Adjudication, Payment Orchestration/Purpose, Prepagos/GiftCard/Loyalty/Preauth/No-show, Financial Allocation versionado; **+5 del refactor 2026-10-16**: resolverOrgNode, resolverContextoOrganizacional, construirEpisodeFinancialAccounts, resolverTenantPatientFinancialView, resolverPatientFinancialProfile) | Ver 2.1 y el Plan de Trabajo Ordenado |
| Egresos | `calcularKPIsEgresos`, `recibirLiquidacionRRHH` | `(rows) => KPIs` · `({...}, idBase) => EgresoRow` |
| Honorarios Médicos | `calcularKPIsHonorarios` | `(rows) => KPIs` |
| Honorarios Externos | `calcularKPIsHonorariosExternos` | `(rows) => KPIs` |
| Facturación | `emitirDTE`, `calcularKPIsFacturacion` | `(borrador, cafPool) => {documento,cafPoolActualizado}|{error}` · `(documentos, cafPool) => KPIs` |
| Adquisiciones | 8 exports tras Fase 8: `calcularKPIsAdquisiciones`, `recibirRequisicion`, `resolverDominioResponsable`, `evaluarTresVias`, `crearCommitment`, `devengarCommitment`, `emitirPurchaseOrderApproved`, `emitirGoodsReceived` | Ver 2.6 |
| Balances | `calcularIndicadoresBalance` | `(resultados, balance) => Indicadores` (sin cambios tras el fix) |
| Flujo de Caja | `recibirMovimientoCaja`, `calcularProyeccionFlujoCaja` | ver dossier detallado |
| Obligaciones Tributarias | `calcularKPIsObligacionesTributarias` | `(ingresosRows, egresosRows, honMedRows, honExtRows, regimenKey) => KPIs` |
| Centro de Costo | `calcularKPIsCentroCosto` | `(egresosRows, honMedRows, honExtRows) => KPIs` |
| Conciliación Bancaria | `sugerirConciliaciones`, `calcularKPIsConciliacion` | ver dossier detallado |

---

## PARTE 6 · Estado real de conexión a backend

`CoreAdapter` tiene 3 endpoints reales: `GET /facturas/:id`, `POST /ordenes-compra/:ocId/factura`, `GET /health`. Facturación y Adquisiciones ya tienen apoyo real; las otras 11 secciones (13 contando las pendientes) siguen 100% mock — esperado en esta etapa.

---

## PARTE 7 · Hallazgos del Excel (sesión original, sin cambios)

7.1 — `Monetización`/`Modulos`/`Plataformas AXON`/`Hoja1` completas; `PBAC+RBAC` con roles sin políticas; `Tipos Tenant` casi vacía; `Take Rate` 100% vacía.
7.2 — El Word "Observaciones" cuenta 13 tipos de tenant donde la hoja tiene 25 columnas — lectura parcial, no error de datos.
7.3 — Numeración de Contabilidad inconsistente entre hojas (#29 vs #31) — mismo síntoma de catálogos no unificados que ya señalan ambos Word.

---

## PARTE 8 · Account Core — arquitectura aprobada (resumen; detalle completo en `AXON_Account_Core_Arquitectura_Consolidada_Definitiva.md`)

**Aprobado por Aleaxon el 2026-08-30, unificado el 2026-09-04.** Pendiente aprobación formal de MAIN sobre los puntos que le corresponden (8.7).

**Actualización 2026-09-04:** después de 4 documentos adicionales de Account Core (Especificación de Ingeniería, Payer/Revenue Cycle, Ingreso de Pagos/Anticipos, y el análisis multi-agente de Revenue/Agreements/Payments/Loyalty), se unificó todo en un solo documento consolidado definitivo. Los puntos 8.1-8.9 de abajo quedan como resumen; el detalle completo y actualizado (10 subledgers, Agreement Engine, Payment Orchestration, Financial Allocation versionado, Compensatory Events, Maker/Checker, estados por dominio) vive en ese archivo.

**8.1 — Arquitectura:** un solo Account Core, con Budget Engine + Accounting Engine + Control Engine convergiendo en un Canonical Financial Model, del cual salen Treasury/Reconciliation/Costing y Reporting/Aggregation.

**8.2 — Budget Ledger vs. General Ledger:** dos dominios relacionados, nunca fusionados. Budget: Disponible→Comprometido→Devengado→Pagado. GL: Financial Event→Journal→Posted→Balance.

**8.3 — 5 perfiles de un mismo motor:** AXON Health (full, con consolidación regional vía dimensión Branch) · Hospital/institución pública · Clínica privada · Centro médico/institución · Profesional independiente (simplificado, sin presupuesto fiscal — coincide con nuestra propia propuesta de Core Lite, Parte 9).

**8.4 — Financial Event Model:** 7 orígenes posibles (Clinical/Supply/Procurement/Billing/HR-Payroll/Treasury/Fleet) → Financial Event → Validation → Subledger/GL.

**8.5 — Subledgers (10, actualizado 2026-09-04):** Healthcare Revenue, CxC, CxP, Professional Fees, Payroll, Inventory/Costing, Fixed Assets, Treasury/Cash, Tax Payable, **Customer Deposits/Stored Value** — detalle completo en `AXON_Account_Core_Arquitectura_Consolidada_Definitiva.md` §13.

**8.6 — Closing Engine:** flujo de referencia para nuestra Sección 2.13 pendiente (ver ahí el diagrama completo).

**8.7 — Quién aprueba qué:**
- **Contabilidad decide:** Budget/GL, Financial Events, plan de cuentas, reglas de reconocimiento, subledgers, Closing Engine, políticas de corrección, reportes y auditoría, perfiles por naturaleza jurídica.
- **MAIN decide:** arquitectura de servicios/persistencia, multi-tenant/aislamiento, PBAC, Canonical Model, adapters externos, audit trail técnico, integración nacional, alcance de **Radar**, roadmap técnico.

**8.8 — Radar (nomenclatura corregida):** es **"Radar"**, sin prefijo "AXON" — Aleaxon ya instruyó a ese equipo no usar "AXON" para todo. Es una capacidad/configuración propia de Contabilidad: el analista de datos inteligente del módulo, que detecta anomalías, concentración, saldos sin movimiento y señales de riesgo sobre datos ya validados. Sigue en estado propuesta — el documento fuente todavía dice "AXON RADAR" en el cuerpo, pendiente que ese equipo termine de actualizarlo.

**8.9 — Riesgos a evitar (explícitos en el Consolidado Final):** convertir SIGFE en spec rígida, construir la complejidad pública antes de estabilizar el Ledger, duplicar lógica financiera por módulo, hardcodear tasas, permitir asientos destructivos, mezclar presupuesto fiscal con privado, cerrar sin validación integral, confundir referencia funcional con certificación legal.

*Detalle completo: `AXON_Contabilidad_Archivo_Account_Core_Consolidado_Final.md`.*

---

## PARTE 9 · Contabilidad Core Lite — alcance aprobado (2026-08-30)

Diferencia de fondo, no solo de escala: el profesional independiente opera como persona natural, Segunda Categoría, emite su propia BHE vía portal SII (folio automático, sin CAF ni timbraje local), no paga IDPC, y su cierre real es su Declaración de Renta anual (Global Complementario) — no un cierre contable formal.

| Sección | Alcance |
|---|---|
| Ingresos | Sí, simplificado (menos pagadores/unidades) |
| Egresos | Sí, simplificado (sin multi centro de costo) |
| Honorarios Médicos | No aplica (es para personal pagado por la institución) |
| Honorarios Externos | Opcional (si paga a un contador/gestor) |
| Adquisiciones | Sí, muy simplificado (sin 3 vías formal ni modalidades públicas) |
| Balances | Sí, estructura distinta (sin IDPC — resumen de honorarios/retenciones para su Renta personal) |
| Flujo de Caja | Sí, simplificado |
| Facturación | Sí, mecanismo distinto (BHE, no CAF/DTE comercial) |
| Obligaciones Tributarias | Sí, foco distinto (retención solo si paga una empresa; el evento importante es la Renta anual) |
| Centro de Costo | No aplica |
| Conciliación Bancaria | Sí, simplificado |
| Remuneraciones CUT | Opcional (solo con asistente contratado) |
| Cierre Contable | Sí, muy distinto (prepara la Renta anual personal) |

**Hallazgo de verificación (2026-08-30):** la retención de una BHE solo se aplica automáticamente cuando el pagador es una empresa/institución — si paga un particular directo, no hay retención automática, el profesional debe autoprovisionar. Relevante para cómo se modela Ingresos en este perfil.

**Validación cruzada:** el perfil "Profesional independiente" del Consolidado Final de Account Core (Parte 8.3) describe esto casi palabra por palabra, sin que ninguno de los dos análisis copiara al otro.

---

## PARTE 10 · Investigación NICSP-CGR / SII / TGR — hallazgos clave (en curso, de Aleaxon)

*Detalle completo: `AXON_Contabilidad_Investigacion_NICSP_CGR_SII_TGR.md`.*

- NICSP-CGR corre dos pistas paralelas (patrimonial + presupuestaria), no es NIIF con otro nombre. Incluye un Estado de Comparación Presupuesto vs. Ejecución sin equivalente en NIIF.
- SIGFE confirmado usando directamente la Resolución 16/2015 (= NICSP-CGR) — verificado contra oficio real de Contraloría a TGR.
- TGR es operativo (recauda/custodia/distribuye), no fija normas contables — eso es exclusivo de CGR.
- **Hallazgo grande, sin aplicar todavía:** hospitales públicos probablemente exentos de IDPC (Art. 40 N°1 LIR + DFL 1/2005 + jurisprudencia SII Ord. 1306/2018). Ver 2.7.
- **Nuevo dato del PDF de hospital público/privado:** Dictamen CGR 20.101/2016, Circular 522/1976 (formato de conciliación bancaria pública), SICOGEN II (capa de reporte vigente, no solo legado), Ley 20.727 (obligatoriedad DTE), Resolución Exenta 150/2005 SII (ERP privado libre elección).
- **Sigue pendiente:** confirmar la fecha exacta de vigencia de la Resolución N°1/2026 CGR (existencia confirmada vía vLex, detalle fino por confirmar en LeyChile) — mencionada en el Consolidado Final de Account Core como razón explícita para no cerrar el diseño público todavía.

---

## PARTE 11 · Parámetros legales vigentes — tabla única de referencia rápida

| Parámetro | Valor 2026 | Fuente | Próximo cambio conocido |
|---|---|---|---|
| Retención honorarios (BHE) | 15,25% | Ley 21.133, verificado vs. comunicado SII dic-2025 | 16% en 2027, 17% en 2028 |
| IDPC Régimen 14A | 27% | Art. 20 LIR | Estable |
| IDPC Pro Pyme 14D N°3 | 12,5% | Ley 21.755, transitorio 2025-2027 | 15% en 2028 |
| UTM (referencial) | $68.000 | SII, cambia mensual | Verificar cada mes |
| Interés moratorio | 7,92% anual / 0,022% diario | Res. Ex. SII N°205 | Solo confirmado 1er sem. 2026 — verificar 2° semestre |
| Acuse de Recibo | 8 días corridos | Ley 19.983 mod. Ley 21.131 | — |
| CAF vigencia | 6 meses desde autorización | Instructivo SII | — |
| Previred | Día 13 | Confirmado vía PDF de canal de venta | — |
| Libro Remuneraciones DT | Día 15 (solo 5+ trabajadores) | Confirmado vía PDF de canal de venta | — |

*Recordatorio de Aleaxon (2026-08-30): todos estos valores deben tratarse como versionados con fecha de vigencia — nunca como constantes permanentes.*

---

## PARTE 12 · Pendientes consolidados

| # | Pendiente | Estado / bloqueado por |
|---|---|---|
| 1 | Sección 2.13: Cierre Contable | Bloqueado — espera resolver público/privado en Balances (Aleaxon investigando) |
| 2 | Puerta etiquetada para **MÓDULO DE RECURSOS HUMANOS / WORKFORCE** en Egresos (ex "Remuneraciones CUT") | **Construida y verificada 2026-09-02** — `recibirLiquidacionRRHH(...)`, ver 2.2 |
| 3 | Catálogo real 85+1 roles en Honorarios Médicos | Bloqueado por MAIN (`roles.config.js` + Matrona/Matrón) |
| 4 | Estado `conciliado` en Egresos/Honorarios | **Pausado explícitamente por Aleaxon 2026-09-02** ("esperemos esto aún") |
| 5 | Segregación de funciones en Conciliación Bancaria | Bloqueado — espera diseño de PBAC real (no existe hoy) |
| 6 | Modelo público/privado/mixto para Balances (NIIF vs. NICSP-CGR) | Bloqueado — Aleaxon investigando activamente |
| 7 | Comisión de plataforma AXON en Egresos vs. Ingresos | Diferido explícitamente, sin fecha |
| 8 | Corte de Adquisiciones en 3 dominios (Supply/AIMS/Account Core) | **Ejecutado en código 2026-09-09** (Fase 8) — `resolverDominioResponsable` + eventos `PurchaseOrderApproved`/`GoodsReceived` ya construidos y verificados. Sigue pendiente la confirmación final de Farmacia/Bodega y MAIN sobre el diseño. |
| 9 | Aprobaciones formales de MAIN sobre Account Core (lista completa en 8.7) | **Aprobado de parte de Contabilidad 2026-09-02** — esperando indicaciones de MAIN |
| 10 | Fecha exacta de vigencia de Resolución N°1/2026 CGR | Confirmar en LeyChile directamente |
| 11 | Definición de "Contabilidad Core Lite" | **Resuelto 2026-08-30** — ver Parte 9 |
| 12 | Régimen tributario fijo en 27% en Balances | **Resuelto 2026-08-28** — ver 2.7 |
| 13 | **Anticipo de Clientes** (giftcard/puntos/wallet/convenio prepagado) | **Resuelto 2026-09-09** — construido en Fase 6 (`crearPrepago`, `emitirGiftCard`, `otorgarPuntos` en Ingresos), verificado en Node. El wallet monetario general sigue como pendiente #14 (regulatorio, no técnico). |
| 14 | Diseño de wallet debe ser de circuito cerrado para no caer en Ley Fintech (Ley 21.521 / CMF) | Abierto — decisión de diseño pendiente, no urgente hasta que exista wallet real |
| 15 | `default_enabled=true` universal para Contabilidad | **Confirmado 2026-09-02** — sí, con opción de deshabilitar por tenant específico (ver Parte 4.D) |
| 16 | `Hoja1` vs. `Tipos Tenant` como fuente de verdad | Sigue abierto — Aleaxon lo resuelve junto con PBAC+RBAC+TenantType |
| 17 | El CUC mock de `ContabilidadIngresos.jsx` no calza con el formato oficial (falta segmento de tenant) | Nuevo hallazgo 2026-09-04 — el generador real es de MAIN (`cup.js`), esperando decisión de si se corrige el mock ahora o se deja para cuando MAIN entregue el real |
| 18 | Consolidar `fakeRUT`/`calcDV` (4 archivos) y `semaforo()` (9 archivos) | **Resuelto 2026-09-04** — ver Parte 3.2 y `ContabilidadHelpersCompartidos.js` |
| 19 | KPI "DSO" mal calculado (medía Billing Lag, no DSO real) | **Resuelto 2026-09-05** — renombrado a `diasParaFacturar`; el DSO real sigue sin poder calcularse (falta capturar `fechaPago`) |
| 20 | **Dos auditorías externas recibidas (2026-09-05) con ~70 hallazgos combinados** | **Resuelto 2026-09-08** — incorporadas al Plan de Trabajo Ordenado, reestructurado desde Fase 3 (ahora 11 fases: Counterparty+Charge antes que Payer/Payment, Financial Preauthorization, PaymentPurpose con grounding real de la tabla de líneas AXON) |
| 21 | Refactor PatientFinancialAccount → 3 niveles (EpisodeFinancialAccount → TenantPatientFinancialView → PatientFinancialProfile) + contexto organizacional UnitShell v2.0 (OrgNode vigente a fecha) | **Resuelto 2026-10-16** — en `ContabilidadIngresos.jsx` (1.752 líneas, 32 exports), 916 aserciones OK. Del documento UnitShell v2.0 se implementó solo el contexto OrgNode; el resto sigue sin construir (ver estado vigente) |
| 22 | `handleSave` de Honorarios Externos no asignaba `centroCosto` | **Resuelto 2026-10-17** — 1 línea; verificado ejecutando el handler real (0/12 → 12/12) |
| 23 | `ContabilidadCentroCostoPorUnidad.jsx` ausente de `/mnt/project` (el dossier anterior decía que no hacía falta subirlo) | Abierto — hay que subirlo al proyecto, junto con las nuevas versiones de Ingresos y Honorarios Externos |
| 24 | Fase 9 pendiente: Compensatory Event Framework · Maker/Checker en Conciliación Bancaria · Estados por dominio | Abierto — sin cambios (ver Plan de Trabajo Ordenado) |

---

*Fin del documento. Este archivo es el punto de entrada para cualquier sesión nueva — desde acá se puede navegar a cualquiera de los 7 documentos satélite según el nivel de detalle que se necesite.*
