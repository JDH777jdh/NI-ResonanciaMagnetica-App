import React, { useState, useMemo } from 'react';
import {
  Scale, TrendingUp, Wallet, PiggyBank, Percent, ChevronDown,
  ChevronRight, Download, Info, CheckCircle2, Landmark
} from 'lucide-react';

/* =========================================================================
   DISEÑO — copiado 1:1 desde HISClinico_Layer1.jsx / demás secciones de
   Contabilidad, para que este archivo se pueda previsualizar solo.
   ========================================================================= */
const C = {
  bg: '#F4F6F9', card: '#FFFFFF', border: '#E2E8F0', borderD: '#CBD5E1',
  ink: '#16233E', sub: '#5B6B85', mut: '#94A3B8',
  pri: '#2E7D32', priL: '#EAF6EC',
  info: '#2563EB', infoL: '#EEF3FF',
  warn: '#B45309', warnL: '#FEF3E2',
  err: '#C62828', errL: '#FDECEC',
  vio: '#6D28D9', vioL: '#F2ECFB',
  teal: '#0E7490',
  r: 10, rSm: 7, rLg: 14,
  shadow: '0 1px 3px rgba(16,24,40,.06), 0 1px 2px rgba(16,24,40,.04)',
  font: "'Inter', -apple-system, 'Segoe UI', Roboto, sans-serif",
};

const clp = (n) => (n < 0 ? '-$' : '$') + Math.round(Math.abs(n)).toLocaleString('es-CL');
const pct = (n) => (n > 0 ? '+' : '') + n.toFixed(1) + '%';

/* Datos propios e ilustrativos — independientes de Ingresos/Egresos por ahora.
   Cuando conectemos de verdad, esto se reemplaza por lo que entreguen
   calcularKPIsIngresos() y calcularKPIsEgresos() (puerta etiquetada).

   El rango de meses NO está fijo en "7" — se calcula desde enero hasta el
   mes de HOY. En septiembre serían 9 meses, en diciembre los 12. Al pasar
   a producción, la única línea que cambia es HOY -> new Date(). */
const HOY = new Date('2026-07-05T00:00:00'); // ancla simulada de "hoy" para este demo — en producción: new Date()

function generarMesesDelAnio(hoy) {
  const anio = hoy.getFullYear();
  const mesActual = hoy.getMonth(); // 0 = enero
  const meses = [];
  for (let m = 0; m <= mesActual; m++) meses.push(`${anio}-${String(m + 1).padStart(2, '0')}`);
  return meses;
}
const NOMBRES_MES = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];
const MESES = generarMesesDelAnio(HOY);
const MES_LABEL = Object.fromEntries(MESES.map((m) => [m, `${NOMBRES_MES[Number(m.slice(5, 7)) - 1]} ${m.slice(0, 4)}`]));

/* Datos de ejemplo mes a mes. Solo hay entradas hasta julio porque en este demo
   "hoy" es el 5 de julio de 2026 — MESES nunca pedirá un mes que no exista acá,
   porque ambos se derivan de la misma fecha ancla. Al llegar agosto en la
   realidad, se agrega la entrada de agosto y aparece solo automáticamente.

   CORREGIDO (2026-08-25): estos meses YA NO traen su propia tasaImpuestoRenta.
   Antes cada mes tenía "tasaImpuestoRenta: 0.27" hardcodeado sin importar el
   régimen tributario real del tenant — si el tenant fuera Pro Pyme 14D N°3
   (12,5%, Ley 21.755), esta pantalla igual habría mostrado 27% todos los
   meses, inflando el impuesto y subestimando el Resultado del Ejercicio. El
   régimen es una elección del tenant, no algo que cambie mes a mes, así que
   ahora se selecciona una sola vez (ver REGIMENES) y se aplica a los 7 meses. */
const RESULTADOS_POR_MES = {
  '2026-01': { ingresosOperacionales: 148500000, costoExplotacion: 81200000, gastosAdministracion: 26800000, gastosVentas: 6900000, gastosFinancieros: 2550000, otrosNoOperacionales: -450000 },
  '2026-02': { ingresosOperacionales: 153800000, costoExplotacion: 83900000, gastosAdministracion: 27100000, gastosVentas: 7100000, gastosFinancieros: 2520000, otrosNoOperacionales: -500000 },
  '2026-03': { ingresosOperacionales: 159200000, costoExplotacion: 86700000, gastosAdministracion: 27600000, gastosVentas: 7300000, gastosFinancieros: 2490000, otrosNoOperacionales: -700000 },
  '2026-04': { ingresosOperacionales: 163900000, costoExplotacion: 89100000, gastosAdministracion: 28400000, gastosVentas: 7500000, gastosFinancieros: 2470000, otrosNoOperacionales: -550000 },
  '2026-05': { ingresosOperacionales: 168300000, costoExplotacion: 91600000, gastosAdministracion: 29300000, gastosVentas: 7700000, gastosFinancieros: 2440000, otrosNoOperacionales: -800000 },
  '2026-06': { ingresosOperacionales: 171200000, costoExplotacion: 93500000, gastosAdministracion: 30100000, gastosVentas: 7900000, gastosFinancieros: 2400000, otrosNoOperacionales: -600000 },
  '2026-07': { ingresosOperacionales: 182500000, costoExplotacion: 96800000, gastosAdministracion: 31200000, gastosVentas: 8400000, gastosFinancieros: 2350000, otrosNoOperacionales: -850000 },
};

/* Régimen tributario (Impuesto de Primera Categoría, IDPC) — mismo parámetro y
   mismos valores que ya existen en ContabilidadObligacionesTributarias.jsx
   (REGIMENES), duplicado acá a propósito porque cada archivo de Contabilidad
   es standalone (mismo criterio que TASA_RETENCION_HONORARIOS, duplicada
   igual en Honorarios Médicos/Externos). Al centralizar en producción, debe
   ser la MISMA fuente en ambos archivos, no dos copias que se desincronicen.
   14 A: 27% estable. Pro Pyme 14D N°3: 12,5% transitorio 2025-2027 (Ley
   21.755), sube a 15% en 2028. OJO: esto es la PROVISIÓN mensual para
   gestión interna — el ajuste real y definitivo del IDPC es anual, vía F22 /
   Operación Renta, y le corresponde a la futura sección de Cierre Contable y
   Balance Anual, no a esta pantalla mensual. */
const REGIMENES = {
  regimen_14a: { label: 'Régimen General · 14 A', tasaIDPC: 0.27 },
  pro_pyme_14d3: { label: 'Pro Pyme · 14 D N°3 (transitorio 2025-2027)', tasaIDPC: 0.125 },
};

// Partidas del balance que escalan con el nivel de ingresos del mes (ancladas a la proporción de julio).
const RATIO_BALANCE = { cuentasPorCobrar: 68000000 / 182500000, existencias: 24500000 / 182500000, otrosActivosCorrientes: 5200000 / 182500000, cuentasPorPagar: 42000000 / 182500000, impuestosPorPagar: 15800000 / 182500000, remuneracionesPorPagar: 18500000 / 182500000, provisiones: 9200000 / 182500000 };
// Partidas de largo plazo, que no se mueven mes a mes con la operación.
const ACTIVOS_NO_CORRIENTES_FIJO = { propiedadPlantaEquipo: 420000000, depreciacionAcumulada: -145000000, otrosActivosNoCorrientes: 12000000 };
const PASIVOS_LP_FIJO = { prestamosLP: 85000000, leasingLP: 22000000 };
const CAPITAL_FIJO = 150000000;
const RESULTADOS_ACUMULADOS_INICIAL = 78000000; // utilidades retenidas antes de enero 2026

/* ═══════════════════════════════════════════════════════════════════════
   Cálculo del Estado de Resultados — todo derivado, nada hardcodeado.
   ═══════════════════════════════════════════════════════════════════════ */
function calcularEstadoResultados(input, tasaImpuestoRenta) {
  const margenBruto = input.ingresosOperacionales - input.costoExplotacion;
  const resultadoOperacional = margenBruto - input.gastosAdministracion - input.gastosVentas;
  const resultadoNoOperacional = -input.gastosFinancieros + input.otrosNoOperacionales;
  const resultadoAntesImpuesto = resultadoOperacional + resultadoNoOperacional;
  const impuestoRenta = Math.round(resultadoAntesImpuesto * tasaImpuestoRenta);
  const resultadoEjercicio = resultadoAntesImpuesto - impuestoRenta;
  return { ...input, tasaImpuestoRenta, margenBruto, resultadoOperacional, resultadoNoOperacional, resultadoAntesImpuesto, impuestoRenta, resultadoEjercicio };
}

// Utilidades acumuladas hasta ANTES del mes en mesIdx — es una suma corrida real,
// mes a mes, no un número fijo. Así julio hereda de verdad lo que pasó desde enero.
// Recibe la tasa vigente porque el régimen es del tenant, no de cada mes.
function resultadosAcumuladosAntesDe(mesIdx, tasaImpuestoRenta) {
  let acc = RESULTADOS_ACUMULADOS_INICIAL;
  for (let i = 0; i < mesIdx; i++) acc += calcularEstadoResultados(RESULTADOS_POR_MES[MESES[i]], tasaImpuestoRenta).resultadoEjercicio;
  return acc;
}

/* Balance: Caja y Bancos se calcula como cuadre exacto (Activos = Pasivos + Patrimonio),
   igual que en un cierre real donde la caja es la cuenta que concilia al final. */
function calcularBalance(ingresosMes, resultadosAcumulados, resultadoEjercicio) {
  const activos = {
    cuentasPorCobrar: Math.round(ingresosMes * RATIO_BALANCE.cuentasPorCobrar),
    existencias: Math.round(ingresosMes * RATIO_BALANCE.existencias),
    otrosActivosCorrientes: Math.round(ingresosMes * RATIO_BALANCE.otrosActivosCorrientes),
    ...ACTIVOS_NO_CORRIENTES_FIJO,
  };
  const pasivos = {
    cuentasPorPagar: Math.round(ingresosMes * RATIO_BALANCE.cuentasPorPagar),
    impuestosPorPagar: Math.round(ingresosMes * RATIO_BALANCE.impuestosPorPagar),
    remuneracionesPorPagar: Math.round(ingresosMes * RATIO_BALANCE.remuneracionesPorPagar),
    provisiones: Math.round(ingresosMes * RATIO_BALANCE.provisiones),
    ...PASIVOS_LP_FIJO,
  };
  const totalPasivos = Object.values(pasivos).reduce((s, v) => s + v, 0);
  const totalPatrimonio = CAPITAL_FIJO + resultadosAcumulados + resultadoEjercicio;
  const totalPasivosYPatrimonio = totalPasivos + totalPatrimonio;

  const totalActivosNoCorrientes = activos.propiedadPlantaEquipo + activos.depreciacionAcumulada + activos.otrosActivosNoCorrientes;
  const activosCorrientesSinCaja = activos.cuentasPorCobrar + activos.existencias + activos.otrosActivosCorrientes;
  const cajaYBancos = totalPasivosYPatrimonio - totalActivosNoCorrientes - activosCorrientesSinCaja;
  const totalActivosCorrientes = activosCorrientesSinCaja + cajaYBancos;
  const totalActivos = totalActivosCorrientes + totalActivosNoCorrientes;

  return {
    activos: { ...activos, cajaYBancos }, pasivos, resultadosAcumulados,
    totalActivosCorrientes, totalActivosNoCorrientes, totalActivos,
    totalPasivos, totalPatrimonio, totalPasivosYPatrimonio,
    cuadrado: Math.abs(totalActivos - totalPasivosYPatrimonio) < 1,
  };
}

/* ═══════════════════════════════════════════════════════════════════════
   PUERTA ETIQUETADA — calcularIndicadoresBalance
   Razones financieras clásicas, listas para Alta Dirección (dir_kpis_fin).
   ═══════════════════════════════════════════════════════════════════════ */
export function calcularIndicadoresBalance(resultados, balance) {
  const margenOperacionalPct = resultados.ingresosOperacionales ? Math.round((resultados.resultadoOperacional / resultados.ingresosOperacionales) * 1000) / 10 : 0;
  const margenNetoPct = resultados.ingresosOperacionales ? Math.round((resultados.resultadoEjercicio / resultados.ingresosOperacionales) * 1000) / 10 : 0;
  const liquidezCorriente = balance.totalPasivos ? Math.round((balance.totalActivosCorrientes / (balance.totalPasivos)) * 100) / 100 : 0;
  const endeudamiento = balance.totalPatrimonio ? Math.round((balance.totalPasivos / balance.totalPatrimonio) * 100) / 100 : 0;
  const roe = balance.totalPatrimonio ? Math.round((resultados.resultadoEjercicio / balance.totalPatrimonio) * 1000) / 10 : 0;
  return { seccion: 'balances', margenOperacionalPct, margenNetoPct, liquidezCorriente, endeudamiento, roe };
}

/* ------------------------------- átomos ---------------------------------- */
const KPICard = ({ label, value, sub, icon: Icon, accent }) => (
  <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, padding: '16px 18px', boxShadow: C.shadow, flex: 1, minWidth: 0 }}>
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
      <span style={{ fontSize: 12.5, color: C.sub, fontWeight: 600 }}>{label}</span>
      <div style={{ width: 28, height: 28, borderRadius: 8, background: accent + '18', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon size={14} style={{ color: accent }} /></div>
    </div>
    <div style={{ fontSize: 22, fontWeight: 700, color: C.ink, letterSpacing: -0.3 }}>{value}</div>
    {sub && <div style={{ fontSize: 12, color: C.mut, marginTop: 3 }}>{sub}</div>}
  </div>
);

const Btn = ({ variant = 'ghost', icon: Icon, children, onClick, style }) => {
  const variants = { primary: { background: C.pri, color: '#fff' }, outline: { background: '#fff', color: C.ink, border: `1px solid ${C.border}` } };
  return (
    <button onClick={onClick} style={{ display: 'inline-flex', alignItems: 'center', gap: 7, padding: '9px 15px', borderRadius: C.rSm, fontSize: 13.5, fontWeight: 600, cursor: 'pointer', border: '1px solid transparent', fontFamily: C.font, ...variants[variant], ...style }}>
      {Icon && <Icon size={15} />}{children}
    </button>
  );
};

/* Una línea de un estado financiero: soporta indentación, negrita (subtotales)
   y una columna de comparación con el período anterior. */
function Linea({ label, valor, anterior, nivel = 0, bold = false, top = false, negativo = false, comparar = true }) {
  const variacion = anterior ? ((valor - anterior) / Math.abs(anterior)) * 100 : null;
  return (
    <div style={{
      display: 'grid', gridTemplateColumns: comparar ? '1fr 140px 90px' : '1fr 140px',
      padding: bold ? '10px 0' : '7px 0', paddingLeft: nivel * 18,
      borderTop: top ? `1px solid ${C.border}` : 'none', alignItems: 'center',
    }}>
      <div style={{ fontSize: bold ? 13.5 : 13, fontWeight: bold ? 700 : 400, color: C.ink }}>{label}</div>
      <div style={{ fontSize: bold ? 13.5 : 13, fontWeight: bold ? 700 : 500, color: negativo ? C.err : C.ink, textAlign: 'right' }}>
        {negativo && valor > 0 ? '(' + clp(valor) + ')' : clp(valor)}
      </div>
      {comparar && (
        <div style={{ fontSize: 11.5, color: variacion == null ? C.mut : variacion >= 0 ? C.pri : C.err, textAlign: 'right' }}>
          {variacion == null ? '—' : pct(variacion)}
        </div>
      )}
    </div>
  );
}

function StatementCard({ title, icon: Icon, children, right }) {
  return (
    <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, boxShadow: C.shadow, padding: 20, flex: 1, minWidth: 340 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 14.5, fontWeight: 700, color: C.ink }}><Icon size={16} style={{ color: C.pri }} />{title}</div>
        {right}
      </div>
      <div>{children}</div>
    </div>
  );
}

/* --------------------------------- vista principal ------------------------------------ */
export default function ContabilidadBalances({ addToast }) {
  const toast = addToast || ((msg) => console.log(msg));
  const [mesIdx, setMesIdx] = useState(MESES.length - 1); // arranca en el mes más reciente (julio)
  const [showNotaCaja, setShowNotaCaja] = useState(false);
  const [regimenKey, setRegimenKey] = useState('regimen_14a'); // elección del tenant, no del mes — ver REGIMENES
  const mes = MESES[mesIdx];
  const hayMesAnterior = mesIdx > 0;
  const tasaImpuestoRenta = REGIMENES[regimenKey].tasaIDPC;

  const resultados = useMemo(() => calcularEstadoResultados(RESULTADOS_POR_MES[mes], tasaImpuestoRenta), [mes, tasaImpuestoRenta]);
  const resultadosAnt = useMemo(() => hayMesAnterior ? calcularEstadoResultados(RESULTADOS_POR_MES[MESES[mesIdx - 1]], tasaImpuestoRenta) : null, [mesIdx, hayMesAnterior, tasaImpuestoRenta]);
  const acumuladoAntes = useMemo(() => resultadosAcumuladosAntesDe(mesIdx, tasaImpuestoRenta), [mesIdx, tasaImpuestoRenta]);
  const balance = useMemo(() => calcularBalance(resultados.ingresosOperacionales, acumuladoAntes, resultados.resultadoEjercicio), [resultados, acumuladoAntes]);
  const ind = useMemo(() => calcularIndicadoresBalance(resultados, balance), [resultados, balance]);

  const exportarCSV = () => {
    const lineas = [
      ['Régimen tributario', REGIMENES[regimenKey].label],
      ['Estado de Resultados', ''],
      ['Ingresos Operacionales', resultados.ingresosOperacionales],
      ['Costo de Explotación', -resultados.costoExplotacion],
      ['Margen Bruto', resultados.margenBruto],
      ['Gastos de Administración', -resultados.gastosAdministracion],
      ['Gastos de Ventas', -resultados.gastosVentas],
      ['Resultado Operacional', resultados.resultadoOperacional],
      ['Resultado No Operacional', resultados.resultadoNoOperacional],
      ['Resultado Antes de Impuesto', resultados.resultadoAntesImpuesto],
      ['Impuesto a la Renta', -resultados.impuestoRenta],
      ['Resultado del Ejercicio', resultados.resultadoEjercicio],
      ['', ''],
      ['Estado de Situación Financiera', ''],
      ['Total Activos', balance.totalActivos],
      ['Total Pasivos', balance.totalPasivos],
      ['Total Patrimonio', balance.totalPatrimonio],
    ];
    const blob = new Blob([lineas.map((l) => l.join(';')).join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = `balances_${mes}.csv`; a.click();
    URL.revokeObjectURL(url);
    toast('Archivo CSV descargado');
  };

  return (
    <div style={{ fontFamily: C.font, background: C.bg, minHeight: '100%', padding: 22 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 18, flexWrap: 'wrap', gap: 12 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
          <div style={{ width: 34, height: 34, borderRadius: 9, background: C.priL, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Scale size={17} style={{ color: C.pri }} /></div>
          <div>
            <div style={{ fontSize: 18, fontWeight: 700, color: C.ink }}>Balances</div>
            <div style={{ fontSize: 12.5, color: C.mut }}>Estado de Resultados y Situación Financiera — NIIF</div>
          </div>
        </div>
        <div style={{ display: 'flex', gap: 9, alignItems: 'center' }}>
          <div style={{ display: 'flex', background: C.card, border: `1px solid ${C.border}`, borderRadius: C.rSm, padding: 3 }}>
            {Object.entries(REGIMENES).map(([k, v]) => (
              <button key={k} onClick={() => setRegimenKey(k)} title={v.label} style={{ padding: '6px 10px', borderRadius: 5, border: 'none', cursor: 'pointer', fontSize: 11.5, fontWeight: 600, background: regimenKey === k ? C.pri : 'transparent', color: regimenKey === k ? '#fff' : C.sub, whiteSpace: 'nowrap' }}>
                {(v.tasaIDPC * 100).toFixed(1)}%
              </button>
            ))}
          </div>
          <select value={mesIdx} onChange={(e) => setMesIdx(Number(e.target.value))}
            style={{ padding: '9px 12px', borderRadius: C.rSm, border: `1px solid ${C.border}`, fontSize: 13, fontWeight: 600, color: C.ink, fontFamily: C.font, background: '#fff' }}>
            {MESES.map((m, i) => <option key={m} value={i}>{MES_LABEL[m]}</option>)}
          </select>
          <Btn variant="outline" icon={Download} onClick={exportarCSV}>Exportar CSV</Btn>
        </div>
      </div>
      <div style={{ fontSize: 11.5, color: C.mut, marginBottom: 18, marginTop: -10 }}>
        Mostrando {MES_LABEL[mes]} · histórico disponible desde {MES_LABEL[MESES[0]]} hasta el mes en curso ({MESES.length} {MESES.length === 1 ? 'mes' : 'meses'}) · régimen {REGIMENES[regimenKey].label} — provisión mensual, el ajuste real es anual vía F22
      </div>

      <div style={{ fontSize: 11.5, fontWeight: 700, color: C.mut, textTransform: 'uppercase', letterSpacing: 0.4, marginBottom: 8 }}>Indicadores de gestión</div>
      <div style={{ display: 'flex', gap: 14, marginBottom: 18, flexWrap: 'wrap' }}>
        <KPICard label="Margen operacional" value={ind.margenOperacionalPct + '%'} sub="Resultado operacional / ingresos" icon={TrendingUp} accent={ind.margenOperacionalPct >= 15 ? C.pri : C.warn} />
        <KPICard label="Margen neto" value={ind.margenNetoPct + '%'} sub="Utilidad final / ingresos" icon={Percent} accent={ind.margenNetoPct >= 10 ? C.pri : C.warn} />
        <KPICard label="Liquidez corriente" value={ind.liquidezCorriente + 'x'} sub="Activo corriente / pasivo corriente" icon={Wallet} accent={ind.liquidezCorriente >= 1.5 ? C.pri : C.err} />
        <KPICard label="Endeudamiento" value={ind.endeudamiento + 'x'} sub="Pasivo total / patrimonio" icon={Landmark} accent={ind.endeudamiento <= 1 ? C.pri : C.warn} />
        <KPICard label="ROE" value={ind.roe + '%'} sub="Rentabilidad sobre patrimonio" icon={PiggyBank} accent={ind.roe >= 8 ? C.pri : C.warn} />
      </div>

      <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap', alignItems: 'flex-start' }}>
        <StatementCard title="Estado de Resultados" icon={TrendingUp}
          right={<div style={{ fontSize: 11, color: C.mut }}>{hayMesAnterior ? `vs. ${MES_LABEL[MESES[mesIdx - 1]]}` : 'Primer mes con datos — sin comparación'}</div>}>
          <Linea label="Ingresos Operacionales" valor={resultados.ingresosOperacionales} anterior={resultadosAnt?.ingresosOperacionales} />
          <Linea label="Costo de Explotación" valor={resultados.costoExplotacion} anterior={resultadosAnt?.costoExplotacion} negativo />
          <Linea label="Margen Bruto" valor={resultados.margenBruto} anterior={resultadosAnt?.margenBruto} bold top />
          <Linea label="Gastos de Administración" valor={resultados.gastosAdministracion} anterior={resultadosAnt?.gastosAdministracion} negativo nivel={1} />
          <Linea label="Gastos de Ventas" valor={resultados.gastosVentas} anterior={resultadosAnt?.gastosVentas} negativo nivel={1} />
          <Linea label="Resultado Operacional (EBIT)" valor={resultados.resultadoOperacional} anterior={resultadosAnt?.resultadoOperacional} bold top />
          <Linea label="Resultado No Operacional" valor={resultados.resultadoNoOperacional} anterior={resultadosAnt?.resultadoNoOperacional} negativo={resultados.resultadoNoOperacional < 0} nivel={1} />
          <Linea label="Resultado Antes de Impuesto" valor={resultados.resultadoAntesImpuesto} anterior={resultadosAnt?.resultadoAntesImpuesto} bold top />
          <Linea label={`Impuesto a la Renta (${(tasaImpuestoRenta * 100).toFixed(1)}%)`} valor={resultados.impuestoRenta} anterior={resultadosAnt?.impuestoRenta} negativo nivel={1} />
          <Linea label="Resultado del Ejercicio" valor={resultados.resultadoEjercicio} anterior={resultadosAnt?.resultadoEjercicio} bold top />
        </StatementCard>

        <StatementCard title="Estado de Situación Financiera" icon={Scale}
          right={<span style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 11, color: balance.cuadrado ? C.pri : C.err, fontWeight: 600 }}><CheckCircle2 size={12} />{balance.cuadrado ? 'Cuadrado' : 'Descuadrado'}</span>}>
          <div style={{ fontSize: 12, fontWeight: 700, color: C.sub, textTransform: 'uppercase', letterSpacing: 0.3, marginTop: 4, marginBottom: 2 }}>Activos</div>
          <Linea label="Caja y Bancos" valor={balance.activos.cajaYBancos} comparar={false} nivel={1} />
          <Linea label="Cuentas por Cobrar" valor={balance.activos.cuentasPorCobrar} comparar={false} nivel={1} />
          <Linea label="Existencias" valor={balance.activos.existencias} comparar={false} nivel={1} />
          <Linea label="Otros Activos Corrientes" valor={balance.activos.otrosActivosCorrientes} comparar={false} nivel={1} />
          <Linea label="Total Activos Corrientes" valor={balance.totalActivosCorrientes} comparar={false} bold top />
          <Linea label="Propiedades, Planta y Equipos" valor={balance.activos.propiedadPlantaEquipo} comparar={false} nivel={1} />
          <Linea label="Depreciación Acumulada" valor={balance.activos.depreciacionAcumulada} comparar={false} negativo nivel={1} />
          <Linea label="Otros Activos No Corrientes" valor={balance.activos.otrosActivosNoCorrientes} comparar={false} nivel={1} />
          <Linea label="Total Activos No Corrientes" valor={balance.totalActivosNoCorrientes} comparar={false} bold top />
          <Linea label="TOTAL ACTIVOS" valor={balance.totalActivos} comparar={false} bold top />

          <div style={{ fontSize: 12, fontWeight: 700, color: C.sub, textTransform: 'uppercase', letterSpacing: 0.3, marginTop: 14, marginBottom: 2 }}>Pasivos y Patrimonio</div>
          <Linea label="Cuentas por Pagar" valor={balance.pasivos.cuentasPorPagar} comparar={false} nivel={1} />
          <Linea label="Impuestos por Pagar" valor={balance.pasivos.impuestosPorPagar} comparar={false} nivel={1} />
          <Linea label="Remuneraciones por Pagar" valor={balance.pasivos.remuneracionesPorPagar} comparar={false} nivel={1} />
          <Linea label="Provisiones" valor={balance.pasivos.provisiones} comparar={false} nivel={1} />
          <Linea label="Préstamos y Leasing LP" valor={balance.pasivos.prestamosLP + balance.pasivos.leasingLP} comparar={false} nivel={1} />
          <Linea label="Total Pasivos" valor={balance.totalPasivos} comparar={false} bold top />
          <Linea label="Capital" valor={CAPITAL_FIJO} comparar={false} nivel={1} />
          <Linea label="Resultados Acumulados" valor={balance.resultadosAcumulados} comparar={false} nivel={1} />
          <Linea label="Resultado del Ejercicio" valor={resultados.resultadoEjercicio} comparar={false} nivel={1} />
          <Linea label="Total Patrimonio" valor={balance.totalPatrimonio} comparar={false} bold top />
          <Linea label="TOTAL PASIVOS + PATRIMONIO" valor={balance.totalPasivosYPatrimonio} comparar={false} bold top />

          <button onClick={() => setShowNotaCaja(!showNotaCaja)} style={{ display: 'flex', alignItems: 'center', gap: 5, background: 'none', border: 'none', cursor: 'pointer', color: C.info, fontSize: 11.5, fontWeight: 600, padding: 0, marginTop: 10 }}>
            <Info size={12} /> ¿Por qué Caja y Bancos es la primera línea? {showNotaCaja ? <ChevronDown size={12} /> : <ChevronRight size={12} />}
          </button>
          {showNotaCaja && (
            <div style={{ marginTop: 8, padding: 10, background: C.bg, borderRadius: C.rSm, fontSize: 11.5, color: C.sub, lineHeight: 1.5 }}>
              Con datos de ejemplo propios, Caja y Bancos se calcula para que el balance cuadre exacto (Activos = Pasivos + Patrimonio) — igual que en un cierre real, donde la caja termina siendo la cuenta que concilia. Cuando conectemos Ingresos y Egresos de verdad, Caja pasa a ser un dato real, no un cálculo de cuadre.
            </div>
          )}
        </StatementCard>
      </div>
    </div>
  );
}
