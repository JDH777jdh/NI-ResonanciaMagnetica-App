import React, { useState, useMemo } from 'react';
import {
  Stethoscope, Search, Download, Plus, X, User, FileText, Eye, RotateCcw,
  CheckCircle2, Clock, Ban, Info, ShieldCheck, TrendingUp, Percent,
  BedDouble, Scissors, ScanLine, Video, Briefcase, Wrench, Server, HeartPulse, Sparkles, FlaskConical
} from 'lucide-react';

/* =========================================================================
   DISEÑO — copiado 1:1 desde HISClinico_Layer1.jsx / demás secciones de
   Contabilidad, para que este archivo se pueda previsualizar de forma
   independiente.
   ========================================================================= */
const C = {
  bg: '#F4F6F9', card: '#FFFFFF', border: '#E2E8F0', borderD: '#CBD5E1',
  ink: '#16233E', sub: '#5B6B85', mut: '#94A3B8',
  pri: '#2E7D32', priL: '#EAF6EC',
  info: '#2563EB', infoL: '#EEF3FF',
  warn: '#B45309', warnL: '#FEF3E2',
  err: '#C62828', errL: '#FDECEC',
  vio: '#6D28D9', vioL: '#F2ECFB',
  teal: '#0E7490', tealL: '#E3F6FA',
  r: 10, rSm: 7, rLg: 14,
  shadow: '0 1px 3px rgba(16,24,40,.06), 0 1px 2px rgba(16,24,40,.04)',
  font: "'Inter', -apple-system, 'Segoe UI', Roboto, sans-serif",
};

/* ═══════════════════════════════════════════════════════════════════════
   PARÁMETRO LEGAL — Ley 21.133, tasa de retención sobre Boletas de
   Honorarios Electrónicas. Cronograma legislado:
     2024=13,75% · 2025=14,5% · 2026=15,25% · 2027=16% · 2028=17%
   Esto cambia por ley cada enero — se deja como constante única, nunca
   repetida en el código, para que actualizarla sea un solo lugar.
   Verificar la cifra vigente en sii.cl antes de cada año tributario nuevo.
   ═══════════════════════════════════════════════════════════════════════ */
const TASA_RETENCION_HONORARIOS = 0.1525;
const ANIO_TASA_VIGENTE = 2026;

const UNIDADES = {
  urgencias: { label: 'Urgencias', icon: Stethoscope, color: '#C62828' },
  hospitalizacion: { label: 'Hospitalización', icon: BedDouble, color: '#2563EB' },
  pabellon: { label: 'Pabellón / Cirugías', icon: Scissors, color: '#6D28D9' },
  imagenologia: { label: 'Imagenología', icon: ScanLine, color: '#0E7490' },
  laboratorio: { label: 'Laboratorio', icon: FlaskConical, color: '#B45309' },
  telemedicina: { label: 'Telemedicina', icon: Video, color: '#2E7D32' },
  administracion: { label: 'Administración General', icon: Briefcase, color: '#455A64' },
  mantencion: { label: 'Mantención e Infraestructura', icon: Wrench, color: '#6D4C41' },
  ti: { label: 'Tecnología de la Información', icon: Server, color: '#37474F' },
};

// Dos niveles: categoria (vista alta para gerencia) y tipo (detalle operativo).
// "Personal Clínico" y "Personal Operacional" — honorarios no es solo para médicos,
// cualquier persona a honorarios cae acá sea cual sea su unidad.
const CATEGORIA_PERSONAL = {
  clinico: { label: 'Personal Clínico', color: '#6D28D9' },
  operacional: { label: 'Personal Operacional', color: '#455A64' },
};
const TIPO_PROFESIONAL = {
  medico: { label: 'Médico', categoria: 'clinico', color: '#6D28D9', icon: Stethoscope },
  profesional_salud: { label: 'Clínico', categoria: 'clinico', color: '#0E7490', icon: User },
  tecnico_salud: { label: 'Técnico de Salud', categoria: 'clinico', color: '#2563EB', icon: HeartPulse },
  mantencion: { label: 'Mantención', categoria: 'operacional', color: '#6D4C41', icon: Wrench },
  informatica: { label: 'Informática (TI)', categoria: 'operacional', color: '#37474F', icon: Server },
  guardia: { label: 'Guardia / Seguridad', categoria: 'operacional', color: '#455A64', icon: ShieldCheck },
  aseo: { label: 'Aseo y Sanitización', categoria: 'operacional', color: '#00838F', icon: Sparkles },
};

const ESPECIALIDADES = {
  cardiologia: { label: 'Cardiología', unidad: 'hospitalizacion', base: 4800000, tipo: 'medico' },
  traumatologia: { label: 'Traumatología', unidad: 'pabellon', base: 5200000, tipo: 'medico' },
  anestesiologia: { label: 'Anestesiología', unidad: 'pabellon', base: 5600000, tipo: 'medico' },
  cirugia_general: { label: 'Cirugía General', unidad: 'pabellon', base: 5400000, tipo: 'medico' },
  urgenciologia: { label: 'Medicina de Urgencia', unidad: 'urgencias', base: 3800000, tipo: 'medico' },
  pediatria: { label: 'Pediatría', unidad: 'urgencias', base: 3400000, tipo: 'medico' },
  ginecologia: { label: 'Ginecología y Obstetricia', unidad: 'pabellon', base: 4400000, tipo: 'medico' },
  radiologia: { label: 'Radiología', unidad: 'imagenologia', base: 4100000, tipo: 'medico' },
  psiquiatria: { label: 'Psiquiatría', unidad: 'telemedicina', base: 3200000, tipo: 'medico' },
  kinesiologia: { label: 'Kinesiología', unidad: 'hospitalizacion', base: 1250000, tipo: 'profesional_salud' },
  psicologia: { label: 'Psicología Clínica', unidad: 'telemedicina', base: 1150000, tipo: 'profesional_salud' },
  enfermeria_hon: { label: 'Enfermera/o', unidad: 'urgencias', base: 1450000, tipo: 'profesional_salud' },
  matrona: { label: 'Matrona/Matrón', unidad: 'hospitalizacion', base: 1400000, tipo: 'profesional_salud' },
  tm_imagenologia: { label: 'Tecnólogo Médico · Imagenología, RM y Ecografía', unidad: 'imagenologia', base: 1650000, tipo: 'profesional_salud' },
  tm_laboratorio: { label: 'Tecnólogo Médico · Laboratorio Clínico', unidad: 'laboratorio', base: 1550000, tipo: 'profesional_salud' },
  tm_oftalmologia: { label: 'Tecnólogo Médico · Oftalmología', unidad: 'imagenologia', base: 1500000, tipo: 'profesional_salud' },
  tm_morfofisiopatologia: { label: 'Tecnólogo Médico · Morfofisiopatología', unidad: 'laboratorio', base: 1600000, tipo: 'profesional_salud' },
  tens: { label: 'TENS (Técnico en Enfermería)', unidad: 'hospitalizacion', base: 750000, tipo: 'tecnico_salud' },
  mantencion_tecnico: { label: 'Técnico de Mantención', unidad: 'mantencion', base: 850000, tipo: 'mantencion' },
  soporte_ti: { label: 'Soporte TI', unidad: 'ti', base: 1050000, tipo: 'informatica' },
  guardia_seguridad: { label: 'Guardia de Seguridad', unidad: 'administracion', base: 700000, tipo: 'guardia' },
  aseo_sanitizacion: { label: 'Aseo y Sanitización', unidad: 'mantencion', base: 580000, tipo: 'aseo' },
};

const ESTADOS = {
  pendiente: { label: 'Pendiente de emitir BHE', color: '#B45309', bg: '#FEF3E2', icon: Clock },
  emitida: { label: 'BHE emitida', color: '#2563EB', bg: '#EEF3FF', icon: FileText },
  pagada: { label: 'Pagada', color: '#2E7D32', bg: '#EAF6EC', icon: CheckCircle2 },
  anulada: { label: 'Anulada', color: '#94A3B8', bg: '#F1F5F9', icon: Ban },
};

/* Nota: el personal CON CONTRATO (planilla) no va aquí — va en Egresos, bajo
   "Remuneraciones (liquidaciones de sueldo)". Esta sección es solo para
   quienes trabajan a honorarios (Boleta de Honorarios Electrónica, SII). */

/* ---------------------------- formatters -------------------------------- */
const clp = (n) => '$' + Math.round(n).toLocaleString('es-CL');
const fmtDate = (iso) =>
  new Date(iso + 'T00:00:00').toLocaleDateString('es-CL', { day: '2-digit', month: 'short', year: 'numeric' });
const addDays = (iso, n) => {
  const d = new Date(iso + 'T00:00:00');
  d.setDate(d.getDate() + n);
  return d.toISOString().slice(0, 10);
};

// Ver ContabilidadHelpersCompartidos.js — versión canónica verificada de calcDV/fakeRUT (mismo comportamiento, base 7000000/mult 6079).
function calcDV(rutBody) {
  let suma = 0, mult = 2;
  for (let i = rutBody.length - 1; i >= 0; i--) { suma += parseInt(rutBody[i], 10) * mult; mult = mult === 7 ? 2 : mult + 1; }
  const resto = 11 - (suma % 11);
  if (resto === 11) return '0';
  if (resto === 10) return 'K';
  return String(resto);
}
function fakeRUT(seed) {
  const body = String(7000000 + (seed * 6079) % 8900000);
  return body.slice(0, 2) + '.' + body.slice(2, 5) + '.' + body.slice(5) + '-' + calcDV(body);
}

// Ver ContabilidadHelpersCompartidos.js — versión canónica verificada de semaforo() (idéntica).
function semaforo(valor, metaEsMinimo, umbralBueno, umbralMalo) {
  const esBueno = metaEsMinimo ? valor >= umbralBueno : valor <= umbralBueno;
  const esMalo = metaEsMinimo ? valor < umbralMalo : valor > umbralMalo;
  if (esBueno) return C.pri;
  if (esMalo) return C.err;
  return C.warn;
}

/* ═══════════════════════════════════════════════════════════════════════
   PUERTA ETIQUETADA — calcularKPIsHonorarios
   Misma forma que las secciones anteriores: función pura, solo números.
   ═══════════════════════════════════════════════════════════════════════ */
export function calcularKPIsHonorarios(rows) {
  const sum = (pred) => rows.filter(pred).reduce((s, r) => s + r.montoBruto, 0);

  const totalBruto = rows.reduce((s, r) => s + r.montoBruto, 0);
  const totalRetencion = rows.reduce((s, r) => s + r.montoRetencion, 0);
  const totalLiquido = rows.reduce((s, r) => s + r.montoLiquido, 0);
  const pendientes = rows.filter((r) => r.estado === 'pendiente');
  const montoPendiente = pendientes.reduce((s, r) => s + r.montoBruto, 0);
  const emitidasOPagadas = rows.filter((r) => r.estado === 'emitida' || r.estado === 'pagada').length;
  const tasaEmisionATiempo = rows.length ? Math.round((emitidasOPagadas / rows.length) * 100) : 0;

  // Retención efectiva: debería calzar exacto con TASA_RETENCION_HONORARIOS.
  // Si no calza, es una alerta de integridad de datos (alguien puso una tasa distinta a mano).
  const retencionEfectivaPct = totalBruto ? Math.round((totalRetencion / totalBruto) * 10000) / 100 : 0;

  const porProfesional = {};
  rows.forEach((r) => { porProfesional[r.profesional] = (porProfesional[r.profesional] || 0) + r.montoBruto; });
  const ordenados = Object.entries(porProfesional).sort((a, b) => b[1] - a[1]);
  const concentracionTop = totalBruto ? Math.round(((ordenados[0]?.[1] || 0) / totalBruto) * 100) : 0;

  const porTipo = Object.keys(TIPO_PROFESIONAL).map((id) => ({ id, monto: sum((r) => r.tipo === id) })).sort((a, b) => b.monto - a.monto);
  const porUnidad = Object.keys(UNIDADES).map((id) => ({ id, monto: sum((r) => r.unidad === id) })).sort((a, b) => b.monto - a.monto);
  const porCategoria = Object.keys(CATEGORIA_PERSONAL).map((id) => ({ id, monto: sum((r) => TIPO_PROFESIONAL[r.tipo].categoria === id) }));
  const pctOperacional = totalBruto ? Math.round(((porCategoria.find((c) => c.id === 'operacional')?.monto || 0) / totalBruto) * 100) : 0;

  return {
    seccion: 'honorarios_medicos', profesionales: new Set(rows.map((r) => r.profesional)).size, boletas: rows.length,
    totalBruto, totalRetencion, totalLiquido, montoPendiente, pendienteCount: pendientes.length,
    tasaEmisionATiempo, retencionEfectivaPct, concentracionTop, pctOperacional,
    porTipo, porUnidad, porCategoria,
  };
}

/* ------------------------------ mock data -------------------------------- */
const NOMBRES = ['Dr. Francisco Contreras', 'Dr. Rodrigo Bravo', 'Dra. María Fernanda Silva', 'Dr. Cristián Aguilera', 'Dra. Paula Vásquez', 'Dr. Álvaro Ortiz', 'Dra. Carolina Peña', 'Dr. Sebastián Riquelme', 'Dra. Ximena Castro', 'Klga. Antonia Morales', 'Psic. Tomás Fuentes', 'Enf. Josefa Muñoz', 'Mtna. Bárbara Contreras', 'Tgo. Matías Herrera', 'Tga. Fernanda Campos', 'Tgo. Ignacio Poblete', 'Tga. Camila Andrade', 'TENS Camila Soto', 'Sr. Manuel Torres', 'Srta. Daniela Rojas', 'Sr. Patricio Vega', 'Sra. Rosa Jiménez'];
const ESPECIALIDAD_KEYS = Object.keys(ESPECIALIDADES);

/* Rango dinámico: desde enero hasta el mes de HOY — mismo patrón que las demás secciones. */
const HOY_HON = new Date('2026-07-05T00:00:00');
function mesesDelAnioHasta(hoy) {
  const anio = hoy.getFullYear(), mesActual = hoy.getMonth(), meses = [];
  for (let m = 0; m <= mesActual; m++) meses.push(`${anio}-${String(m + 1).padStart(2, '0')}`);
  return meses;
}
const MESES_HON = mesesDelAnioHasta(HOY_HON);
const NOMBRES_MES_HON = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];
const MES_LABEL_HON = Object.fromEntries(MESES_HON.map((m) => [m, `${NOMBRES_MES_HON[Number(m.slice(5, 7)) - 1]} ${m.slice(0, 4)}`]));

function genMock() {
  const rows = [];
  let seed = 5;
  NOMBRES.forEach((profesional, idx) => {
    seed += 23;
    const especialidadKey = ESPECIALIDAD_KEYS[idx % ESPECIALIDAD_KEYS.length];
    const esp = ESPECIALIDADES[especialidadKey];
    const rut = fakeRUT(seed);
    // cada profesional emite 1 BHE mensual — un registro por cada mes desde enero hasta hoy
    MESES_HON.forEach((periodo, pIdx) => {
      seed += 11;
      const variacion = 1 + (((seed * 7) % 30) - 15) / 100; // ±15%
      const montoBruto = Math.round((esp.base * variacion) / 10000) * 10000;
      const montoRetencion = Math.round(montoBruto * TASA_RETENCION_HONORARIOS);
      const montoLiquido = montoBruto - montoRetencion;
      const esMesActual = pIdx === MESES_HON.length - 1;
      // meses ya cerrados: la BHE ya se emitió y se pagó (a esta altura no queda pendiente en la realidad)
      const estado = esMesActual ? (seed % 4 === 0 ? 'pendiente' : 'emitida') : 'pagada';
      const fechaEmision = estado === 'pendiente' ? null : addDays(periodo + '-28', (seed % 5));
      const folio = estado === 'pendiente' ? null : 55000 + rows.length;
      const prestacionesDelPeriodo = 8 + (seed % 24);
      rows.push({
        id: 'hon_' + (1000 + rows.length),
        periodo, profesional, rut,
        especialidad: esp.label, especialidadKey, unidad: esp.unidad, tipo: esp.tipo,
        montoBruto, montoRetencion, montoLiquido, prestacionesDelPeriodo,
        boleta: { folio, fechaEmision },
        estado,
      });
    });
  });
  return rows.sort((a, b) => (a.periodo < b.periodo ? 1 : a.periodo > b.periodo ? -1 : a.profesional.localeCompare(b.profesional)));
}

/* ------------------------------- átomos ---------------------------------- */
const Badge = ({ color, bg, icon: Icon, children }) => (
  <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, padding: '3px 9px', borderRadius: 999, fontSize: 12, fontWeight: 600, color, background: bg, whiteSpace: 'nowrap' }}>
    {Icon && <Icon size={12} />}{children}
  </span>
);
const Btn = ({ variant = 'ghost', icon: Icon, children, onClick, style, type = 'button' }) => {
  const variants = { primary: { background: C.pri, color: '#fff' }, outline: { background: '#fff', color: C.ink, border: `1px solid ${C.border}` }, ghost: { background: 'transparent', color: C.sub } };
  return (
    <button type={type} onClick={onClick}
      onMouseEnter={(e) => (e.currentTarget.style.filter = 'brightness(0.96)')} onMouseLeave={(e) => (e.currentTarget.style.filter = 'none')}
      style={{ display: 'inline-flex', alignItems: 'center', gap: 7, padding: '9px 15px', borderRadius: C.rSm, fontSize: 13.5, fontWeight: 600, cursor: 'pointer', border: '1px solid transparent', fontFamily: C.font, ...variants[variant], ...style }}>
      {Icon && <Icon size={15} />}{children}
    </button>
  );
};
const KPICard = ({ label, value, sub, icon: Icon, accent }) => (
  <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, padding: '16px 18px', boxShadow: C.shadow, flex: 1, minWidth: 0 }}>
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
      <span style={{ fontSize: 12.5, color: C.sub, fontWeight: 600 }}>{label}</span>
      <div style={{ width: 28, height: 28, borderRadius: 8, background: accent + '18', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon size={14} style={{ color: accent }} /></div>
    </div>
    <div style={{ fontSize: 22, fontWeight: 700, color: C.ink, letterSpacing: -0.3 }}>{value}</div>
    {sub && <div style={{ fontSize: 12, color: C.mut, marginTop: 3 }}>{sub}</div>}
  </div>
);
const FieldLabel = ({ children }) => <label style={{ fontSize: 11.5, fontWeight: 600, color: C.sub, marginBottom: 5, display: 'block' }}>{children}</label>;
const inputStyle = { width: '100%', padding: '8px 10px', borderRadius: C.rSm, border: `1px solid ${C.border}`, fontSize: 13.5, fontFamily: C.font, color: C.ink, outline: 'none', boxSizing: 'border-box', background: '#fff' };

function BreakdownCard({ title, items, total }) {
  return (
    <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, padding: 18, boxShadow: C.shadow, flex: 1, minWidth: 0 }}>
      <div style={{ fontSize: 13, fontWeight: 700, color: C.ink, marginBottom: 14 }}>{title}</div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 11 }}>
        {items.map(([key, meta, monto]) => {
          const pct = total ? Math.round((monto / total) * 100) : 0;
          const Icon = meta.icon || User;
          return (
            <div key={key}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12.5, marginBottom: 4 }}>
                <span style={{ display: 'flex', alignItems: 'center', gap: 6, color: C.ink, fontWeight: 500 }}><Icon size={13} style={{ color: meta.color }} /> {meta.label}</span>
                <span style={{ color: C.sub, fontWeight: 600 }}>{clp(monto)} <span style={{ color: C.mut, fontWeight: 400 }}>({pct}%)</span></span>
              </div>
              <div style={{ height: 6, borderRadius: 4, background: C.bg, overflow: 'hidden' }}><div style={{ height: '100%', width: pct + '%', background: meta.color, borderRadius: 4 }} /></div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function DetailModal({ row, onClose }) {
  if (!row) return null;
  const uni = UNIDADES[row.unidad], est = ESTADOS[row.estado], tp = TIPO_PROFESIONAL[row.tipo];
  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(16,24,40,.45)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100, padding: 20 }} onClick={onClose}>
      <div style={{ background: '#fff', borderRadius: C.rLg, width: 500, maxWidth: '100%', maxHeight: '90vh', overflowY: 'auto', boxShadow: '0 20px 50px rgba(16,24,40,.25)' }} onClick={(e) => e.stopPropagation()}>
        <div style={{ padding: '18px 22px', borderBottom: `1px solid ${C.border}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
            <div style={{ width: 34, height: 34, borderRadius: 9, background: tp.color + '18', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><User size={16} style={{ color: tp.color }} /></div>
            <div>
              <div style={{ fontSize: 15, fontWeight: 700, color: C.ink }}>{row.profesional}</div>
              <div style={{ fontSize: 12, color: C.mut }}>{row.especialidad} · RUT {row.rut}</div>
            </div>
          </div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: C.mut }}><X size={18} /></button>
        </div>
        <div style={{ padding: 22, display: 'flex', flexDirection: 'column', gap: 16 }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
            <div><FieldLabel>Tipo de profesional</FieldLabel><Badge color={tp.color} bg={tp.color + '18'} icon={tp.icon}>{tp.label}</Badge></div>
            <div><FieldLabel>Unidad</FieldLabel><Badge color={uni.color} bg={uni.color + '18'} icon={uni.icon}>{uni.label}</Badge></div>
          </div>
          <div><FieldLabel>Período</FieldLabel><div style={{ fontSize: 12.5, color: C.ink }}>{row.periodo} · {row.prestacionesDelPeriodo} atenciones</div></div>
          <div style={{ background: C.bg, borderRadius: C.rSm, padding: 14 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, color: C.sub, marginBottom: 6 }}><span>Honorario bruto</span><span style={{ color: C.ink, fontWeight: 600 }}>{clp(row.montoBruto)}</span></div>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, color: C.err, marginBottom: 6 }}><span>Retención SII ({(TASA_RETENCION_HONORARIOS * 100).toFixed(2)}%)</span><span style={{ fontWeight: 600 }}>-{clp(row.montoRetencion)}</span></div>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 14.5, paddingTop: 8, borderTop: `1px dashed ${C.borderD}`, marginTop: 4 }}><span style={{ fontWeight: 700, color: C.ink }}>Líquido a pagar</span><span style={{ fontWeight: 700, color: C.pri }}>{clp(row.montoLiquido)}</span></div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
            <div>
              <FieldLabel>Boleta de Honorarios Electrónica</FieldLabel>
              <div style={{ fontSize: 13, color: C.ink, fontWeight: 600 }}>{row.boleta.folio ? `Folio N° ${row.boleta.folio}` : 'Sin emitir'}</div>
              <div style={{ fontSize: 12, color: C.mut }}>{row.boleta.fechaEmision ? fmtDate(row.boleta.fechaEmision) : 'Pendiente'}</div>
            </div>
            <div><FieldLabel>Estado</FieldLabel><Badge color={est.color} bg={est.bg} icon={est.icon}>{est.label}</Badge></div>
          </div>
          {row.boleta.folio && (
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, background: C.infoL, padding: '9px 12px', borderRadius: C.rSm, fontSize: 12, color: '#1D4ED8' }}>
              <ShieldCheck size={13} /> Firma electrónica SII verificada (Ley 19.799)
            </div>
          )}
          <div style={{ fontSize: 11, color: C.mut, paddingTop: 10, borderTop: `1px solid ${C.border}` }}>Recurso FHIR asociado: <span style={{ fontFamily: 'monospace', background: C.bg, padding: '2px 6px', borderRadius: 4 }}>Invoice</span></div>
        </div>
      </div>
    </div>
  );
}

function NewHonorarioModal({ onClose, onSave }) {
  const [form, setForm] = useState({ profesional: '', rut: '', especialidad: 'urgenciologia', montoBruto: '' });
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });
  const puedeGuardar = form.profesional.trim() && Number(form.montoBruto) > 0;
  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(16,24,40,.45)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100, padding: 20 }} onClick={onClose}>
      <div style={{ background: '#fff', borderRadius: C.rLg, width: 440, maxWidth: '100%', boxShadow: '0 20px 50px rgba(16,24,40,.25)' }} onClick={(e) => e.stopPropagation()}>
        <div style={{ padding: '18px 22px', borderBottom: `1px solid ${C.border}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ fontSize: 15, fontWeight: 700, color: C.ink }}>Registrar honorario</div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: C.mut }}><X size={18} /></button>
        </div>
        <div style={{ padding: 22, display: 'flex', flexDirection: 'column', gap: 13 }}>
          <div><FieldLabel>Profesional</FieldLabel><input style={inputStyle} value={form.profesional} onChange={set('profesional')} placeholder="Ej: Dr. Juan Pérez" /></div>
          <div><FieldLabel>RUT</FieldLabel><input style={inputStyle} value={form.rut} onChange={set('rut')} placeholder="12.345.678-9" /></div>
          <div><FieldLabel>Especialidad</FieldLabel><select style={inputStyle} value={form.especialidad} onChange={set('especialidad')}>{Object.entries(ESPECIALIDADES).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}</select></div>
          <div>
            <FieldLabel>Honorario bruto (CLP)</FieldLabel>
            <input style={inputStyle} type="number" value={form.montoBruto} onChange={set('montoBruto')} placeholder="4500000" />
            {Number(form.montoBruto) > 0 && (
              <div style={{ fontSize: 11.5, color: C.mut, marginTop: 5 }}>
                Retención {(TASA_RETENCION_HONORARIOS * 100).toFixed(2)}%: -{clp(Number(form.montoBruto) * TASA_RETENCION_HONORARIOS)} · Líquido: {clp(Number(form.montoBruto) * (1 - TASA_RETENCION_HONORARIOS))}
              </div>
            )}
          </div>
        </div>
        <div style={{ padding: '14px 22px', borderTop: `1px solid ${C.border}`, display: 'flex', justifyContent: 'flex-end', gap: 10 }}>
          <Btn variant="ghost" onClick={onClose}>Cancelar</Btn>
          <Btn variant="primary" icon={Plus} onClick={() => puedeGuardar && onSave(form)} style={{ opacity: puedeGuardar ? 1 : 0.5 }}>Registrar</Btn>
        </div>
      </div>
    </div>
  );
}

/* --------------------------------- vista principal ------------------------------------ */
export default function ContabilidadHonorariosMedicos({ addToast }) {
  const toast = addToast || ((msg) => console.log(msg));
  const [data, setData] = useState(genMock);
  const [filtros, setFiltros] = useState({ periodo: MESES_HON[MESES_HON.length - 1], categoria: 'todas', unidad: 'todas', tipo: 'todos', estado: 'todos', q: '' });
  const [selected, setSelected] = useState(null);
  const [showNew, setShowNew] = useState(false);
  const [page, setPage] = useState(1);
  const perPage = 8;

  const filtered = useMemo(() => data.filter((r) => {
    if (filtros.periodo !== 'todos' && r.periodo !== filtros.periodo) return false;
    if (filtros.categoria !== 'todas' && TIPO_PROFESIONAL[r.tipo].categoria !== filtros.categoria) return false;
    if (filtros.unidad !== 'todas' && r.unidad !== filtros.unidad) return false;
    if (filtros.tipo !== 'todos' && r.tipo !== filtros.tipo) return false;
    if (filtros.estado !== 'todos' && r.estado !== filtros.estado) return false;
    if (filtros.q && !r.profesional.toLowerCase().includes(filtros.q.toLowerCase())) return false;
    return true;
  }), [data, filtros]);

  const kpi = useMemo(() => calcularKPIsHonorarios(filtered), [filtered]);
  const porCategoriaDisplay = kpi.porCategoria.map((item) => [item.id, CATEGORIA_PERSONAL[item.id], item.monto]);
  const porTipoDisplay = kpi.porTipo.filter((item) => item.monto > 0).map((item) => [item.id, TIPO_PROFESIONAL[item.id], item.monto]);
  const porUnidadDisplay = kpi.porUnidad.filter((item) => item.monto > 0).map((item) => [item.id, UNIDADES[item.id], item.monto]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / perPage));
  const pageRows = filtered.slice((page - 1) * perPage, page * perPage);
  const limpiarFiltros = () => { setFiltros({ periodo: MESES_HON[MESES_HON.length - 1], categoria: 'todas', unidad: 'todas', tipo: 'todos', estado: 'todos', q: '' }); setPage(1); };

  const exportarCSV = () => {
    const header = ['Período', 'Profesional', 'RUT', 'Especialidad', 'Bruto', 'Retención', 'Líquido', 'Folio BHE', 'Estado'];
    const lines = filtered.map((r) => [r.periodo, r.profesional, r.rut, r.especialidad, r.montoBruto, r.montoRetencion, r.montoLiquido, r.boleta.folio || '', ESTADOS[r.estado].label].join(';'));
    const blob = new Blob([header.join(';') + '\n' + lines.join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = `honorarios_medicos_${filtros.periodo}.csv`; a.click();
    URL.revokeObjectURL(url);
    toast('Archivo CSV descargado');
  };

  const handleSave = (form) => {
    const esp = ESPECIALIDADES[form.especialidad];
    const montoBruto = Number(form.montoBruto);
    const montoRetencion = Math.round(montoBruto * TASA_RETENCION_HONORARIOS);
    setData([{
      id: 'hon_' + (5000 + data.length), periodo: MESES_HON[MESES_HON.length - 1],
      profesional: form.profesional, rut: form.rut || fakeRUT(data.length + 1),
      especialidad: esp.label, especialidadKey: form.especialidad, unidad: esp.unidad, tipo: esp.tipo,
      montoBruto, montoRetencion, montoLiquido: montoBruto - montoRetencion, prestacionesDelPeriodo: 0,
      boleta: { folio: null, fechaEmision: null }, estado: 'pendiente',
    }, ...data]);
    setShowNew(false);
    toast('Honorario registrado — queda pendiente de emitir BHE');
  };

  return (
    <div style={{ fontFamily: C.font, background: C.bg, minHeight: '100%', padding: 22 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 14, flexWrap: 'wrap', gap: 12 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
          <div style={{ width: 34, height: 34, borderRadius: 9, background: C.vioL, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Stethoscope size={17} style={{ color: C.vio }} /></div>
          <div>
            <div style={{ fontSize: 18, fontWeight: 700, color: C.ink }}>Honorarios Médicos y de Personal</div>
            <div style={{ fontSize: 12.5, color: C.mut }}>Boletas de Honorarios Electrónicas — personal a honorarios, no con contrato</div>
          </div>
        </div>
        <div style={{ display: 'flex', gap: 9 }}>
          <Btn variant="outline" icon={Download} onClick={exportarCSV}>Exportar CSV</Btn>
          <Btn variant="primary" icon={Plus} onClick={() => setShowNew(true)}>Nuevo honorario</Btn>
        </div>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: 7, background: '#fff', border: `1px solid ${C.border}`, borderRadius: C.rSm, padding: '9px 13px', marginBottom: 18, fontSize: 12, color: C.sub }}>
        <Percent size={13} style={{ color: C.vio }} />
        Parámetro vigente: retención de honorarios <b style={{ color: C.ink }}>{(TASA_RETENCION_HONORARIOS * 100).toFixed(2)}% ({ANIO_TASA_VIGENTE})</b> según Ley 21.133 — sube a 16% en 2027 y 17% en 2028. Verificar en sii.cl cada enero.
      </div>

      <div style={{ fontSize: 11.5, fontWeight: 700, color: C.mut, textTransform: 'uppercase', letterSpacing: 0.4, marginBottom: 8 }}>Métricas del período</div>
      <div style={{ display: 'flex', gap: 14, marginBottom: 18, flexWrap: 'wrap' }}>
        <KPICard label="Honorarios brutos" value={clp(kpi.totalBruto)} sub={`${kpi.boletas} boletas · ${kpi.profesionales} profesionales`} icon={TrendingUp} accent={C.vio} />
        <KPICard label="Retención SII" value={clp(kpi.totalRetencion)} sub="A declarar en F29 del mes" icon={Percent} accent={C.err} />
        <KPICard label="Líquido a pagar" value={clp(kpi.totalLiquido)} sub="Bruto menos retención" icon={CheckCircle2} accent={C.pri} />
        <KPICard label="Pendiente de emitir" value={clp(kpi.montoPendiente)} sub={`${kpi.pendienteCount} BHE sin emitir`} icon={Clock} accent={C.warn} />
      </div>

      <div style={{ fontSize: 11.5, fontWeight: 700, color: C.mut, textTransform: 'uppercase', letterSpacing: 0.4, marginBottom: 8 }}>Indicadores de gestión</div>
      <div style={{ display: 'flex', gap: 14, marginBottom: 14, flexWrap: 'wrap' }}>
        <KPICard label="Retención efectiva" value={kpi.retencionEfectivaPct + '%'} sub={`Debe calzar con ${(TASA_RETENCION_HONORARIOS * 100).toFixed(2)}%`} icon={ShieldCheck} accent={Math.abs(kpi.retencionEfectivaPct - TASA_RETENCION_HONORARIOS * 100) < 0.05 ? C.pri : C.err} />
        <KPICard label="BHE al día" value={kpi.tasaEmisionATiempo + '%'} sub="Meta: 100% antes del F29" icon={FileText} accent={semaforo(kpi.tasaEmisionATiempo, true, 95, 80)} />
        <KPICard label="Concentración" value={kpi.concentracionTop + '%'} sub="Del profesional con mayor honorario" icon={Info} accent={semaforo(kpi.concentracionTop, false, 15, 25)} />
        <KPICard label="Personal operacional" value={kpi.pctOperacional + '%'} sub="Del gasto total en honorarios" icon={Wrench} accent={C.mut} />
      </div>

      <div style={{ display: 'flex', gap: 14, marginBottom: 14, flexWrap: 'wrap' }}>
        <BreakdownCard title="Por categoría de personal" items={porCategoriaDisplay} total={kpi.totalBruto} />
        <BreakdownCard title="Por tipo de profesional" items={porTipoDisplay} total={kpi.totalBruto} />
        <BreakdownCard title="Por unidad" items={porUnidadDisplay} total={kpi.totalBruto} />
      </div>

      <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, padding: 16, boxShadow: C.shadow, marginBottom: 14 }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10, marginBottom: 10 }}>
          <div>
            <FieldLabel>Período</FieldLabel>
            <select style={inputStyle} value={filtros.periodo} onChange={(e) => { setFiltros({ ...filtros, periodo: e.target.value }); setPage(1); }}>
              {[...MESES_HON].reverse().map((m) => <option key={m} value={m}>{MES_LABEL_HON[m]}</option>)}<option value="todos">Todos</option>
            </select>
          </div>
          <div>
            <FieldLabel>Categoría</FieldLabel>
            <select style={inputStyle} value={filtros.categoria} onChange={(e) => { setFiltros({ ...filtros, categoria: e.target.value, tipo: 'todos' }); setPage(1); }}>
              <option value="todas">Todas</option>{Object.entries(CATEGORIA_PERSONAL).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
            </select>
          </div>
          <div><FieldLabel>Tipo</FieldLabel><select style={inputStyle} value={filtros.tipo} onChange={(e) => { setFiltros({ ...filtros, tipo: e.target.value }); setPage(1); }}><option value="todos">Todos</option>{Object.entries(TIPO_PROFESIONAL).filter(([k, v]) => filtros.categoria === 'todas' || v.categoria === filtros.categoria).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}</select></div>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10 }}>
          <div><FieldLabel>Unidad</FieldLabel><select style={inputStyle} value={filtros.unidad} onChange={(e) => { setFiltros({ ...filtros, unidad: e.target.value }); setPage(1); }}><option value="todas">Todas</option>{Object.entries(UNIDADES).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}</select></div>
          <div><FieldLabel>Estado</FieldLabel><select style={inputStyle} value={filtros.estado} onChange={(e) => { setFiltros({ ...filtros, estado: e.target.value }); setPage(1); }}><option value="todos">Todos</option>{Object.entries(ESTADOS).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}</select></div>
          <div><FieldLabel>Buscar profesional</FieldLabel><div style={{ position: 'relative' }}><Search size={14} style={{ position: 'absolute', left: 9, top: 10, color: C.mut }} /><input style={{ ...inputStyle, paddingLeft: 28 }} value={filtros.q} onChange={(e) => { setFiltros({ ...filtros, q: e.target.value }); setPage(1); }} /></div></div>
        </div>
        <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 12 }}>
          <button onClick={limpiarFiltros} style={{ display: 'flex', alignItems: 'center', gap: 5, background: 'none', border: 'none', cursor: 'pointer', color: C.sub, fontSize: 12.5, fontWeight: 600, padding: 0 }}><RotateCcw size={13} /> Limpiar filtros</button>
        </div>
      </div>

      <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, boxShadow: C.shadow, overflow: 'hidden' }}>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
            <thead>
              <tr style={{ background: C.bg, textAlign: 'left' }}>
                {['Profesional', 'Especialidad', 'Unidad', 'Bruto', 'Retención', 'Líquido', 'BHE', 'Estado', ''].map((h) => (
                  <th key={h} style={{ padding: '10px 14px', fontSize: 11.5, fontWeight: 700, color: C.sub, textTransform: 'uppercase', letterSpacing: 0.3, whiteSpace: 'nowrap' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {pageRows.map((r) => {
                const uni = UNIDADES[r.unidad], est = ESTADOS[r.estado], tp = TIPO_PROFESIONAL[r.tipo];
                return (
                  <tr key={r.id} style={{ borderTop: `1px solid ${C.border}`, cursor: 'pointer' }} onClick={() => setSelected(r)}
                    onMouseEnter={(e) => (e.currentTarget.style.background = C.bg)} onMouseLeave={(e) => (e.currentTarget.style.background = 'transparent')}>
                    <td style={{ padding: '11px 14px', fontWeight: 600, color: C.ink, whiteSpace: 'nowrap' }}>{r.profesional}</td>
                    <td style={{ padding: '11px 14px', color: C.sub }}>
                      {r.especialidad}
                      <div style={{ marginTop: 3 }}><Badge color={tp.color} bg={tp.color + '15'} icon={tp.icon}>{tp.label}</Badge></div>
                    </td>
                    <td style={{ padding: '11px 14px' }}><Badge color={uni.color} bg={uni.color + '18'} icon={uni.icon}>{uni.label}</Badge></td>
                    <td style={{ padding: '11px 14px', fontWeight: 700, color: C.ink, whiteSpace: 'nowrap' }}>{clp(r.montoBruto)}</td>
                    <td style={{ padding: '11px 14px', color: C.err, whiteSpace: 'nowrap' }}>-{clp(r.montoRetencion)}</td>
                    <td style={{ padding: '11px 14px', fontWeight: 600, color: C.pri, whiteSpace: 'nowrap' }}>{clp(r.montoLiquido)}</td>
                    <td style={{ padding: '11px 14px', color: C.sub, whiteSpace: 'nowrap' }}>{r.boleta.folio ? `N° ${r.boleta.folio}` : '—'}</td>
                    <td style={{ padding: '11px 14px' }}><Badge color={est.color} bg={est.bg} icon={est.icon}>{est.label}</Badge></td>
                    <td style={{ padding: '11px 14px' }}><Eye size={15} style={{ color: C.mut }} /></td>
                  </tr>
                );
              })}
              {pageRows.length === 0 && (
                <tr><td colSpan={9} style={{ padding: '40px 14px', textAlign: 'center', color: C.mut, fontSize: 13 }}>
                  No hay honorarios que calcen con estos filtros. <button onClick={limpiarFiltros} style={{ color: C.info, background: 'none', border: 'none', cursor: 'pointer', fontSize: 13, textDecoration: 'underline', padding: 0 }}>Limpia los filtros</button>.
                </td></tr>
              )}
            </tbody>
          </table>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 16px', borderTop: `1px solid ${C.border}` }}>
          <span style={{ fontSize: 12, color: C.mut }}>{filtered.length} registros · página {page} de {totalPages}</span>
          <div style={{ display: 'flex', gap: 6 }}>
            <Btn variant="outline" onClick={() => setPage(Math.max(1, page - 1))} style={{ padding: '6px 12px', opacity: page === 1 ? 0.4 : 1 }}>Anterior</Btn>
            <Btn variant="outline" onClick={() => setPage(Math.min(totalPages, page + 1))} style={{ padding: '6px 12px', opacity: page === totalPages ? 0.4 : 1 }}>Siguiente</Btn>
          </div>
        </div>
      </div>

      {selected && <DetailModal row={selected} onClose={() => setSelected(null)} />}
      {showNew && <NewHonorarioModal onClose={() => setShowNew(false)} onSave={handleSave} />}
    </div>
  );
}
