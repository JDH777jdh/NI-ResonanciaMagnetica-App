import React, { useState, useMemo } from 'react';
import {
  TrendingDown, Search, Download, Plus, X, Package, Users, Banknote, Zap,
  Wrench, Landmark, ShoppingCart, Briefcase, Server, Stethoscope, BedDouble,
  Scissors, ScanLine, FlaskConical, Video, Pill, Eye,
  RotateCcw, CheckCircle2, Clock, Ban, Info, Hourglass, AlertTriangle
} from 'lucide-react';

/* =========================================================================
   DISEÑO — copiado 1:1 desde HISClinico_Layer1.jsx / ContabilidadIngresos.jsx
   para que este archivo se pueda previsualizar de forma independiente.
   Al integrar a tu proyecto: usa el mismo C / átomos ya definidos.
   ========================================================================= */
const C = {
  bg: '#F4F6F9', card: '#FFFFFF', border: '#E2E8F0', borderD: '#CBD5E1',
  ink: '#16233E', sub: '#5B6B85', mut: '#94A3B8',
  pri: '#2E7D32', priD: '#1B5E20', priL: '#EAF6EC',
  info: '#2563EB', infoL: '#EEF3FF',
  warn: '#B45309', warnL: '#FEF3E2',
  err: '#C62828', errL: '#FDECEC',
  vio: '#6D28D9', vioL: '#F2ECFB',
  teal: '#0E7490', tealL: '#E3F6FA',
  r: 10, rSm: 7, rLg: 14,
  shadow: '0 1px 3px rgba(16,24,40,.06), 0 1px 2px rgba(16,24,40,.04)',
  font: "'Inter', -apple-system, 'Segoe UI', Roboto, sans-serif",
};

/* Centros de costo: las mismas unidades clínicas de Ingresos + centros administrativos.
   Esta lista es, a propósito, la misma que va a usar la sección 11 (Centro de Costo por Unidad). */
const CENTROS = {
  urgencias: { label: 'Urgencias', icon: Stethoscope, color: '#C62828' },
  hospitalizacion: { label: 'Hospitalización', icon: BedDouble, color: '#2563EB' },
  pabellon: { label: 'Pabellón / Cirugías', icon: Scissors, color: '#6D28D9' },
  imagenologia: { label: 'Imagenología', icon: ScanLine, color: '#0E7490' },
  laboratorio: { label: 'Laboratorio', icon: FlaskConical, color: '#B45309' },
  telemedicina: { label: 'Telemedicina', icon: Video, color: '#2E7D32' },
  farmacia: { label: 'Farmacia', icon: Pill, color: '#BE185D' },
  administracion: { label: 'Administración General', icon: Briefcase, color: '#455A64' },
  mantencion: { label: 'Mantención e Infraestructura', icon: Wrench, color: '#6D4C41' },
  ti: { label: 'Tecnología de la Información', icon: Server, color: '#37474F' },
};

const CATEGORIAS = {
  proveedores: { label: 'Proveedores e Insumos', icon: Package, color: '#1565C0' },
  remuneraciones: { label: 'Remuneraciones (liquidaciones de sueldo)', icon: Users, color: '#6D28D9' },
  honorarios: { label: 'Honorarios (pago consolidado)', icon: Banknote, color: '#0E7490' },
  servicios: { label: 'Servicios Básicos', icon: Zap, color: '#B45309' },
  arriendo: { label: 'Arriendo y Mantención', icon: Wrench, color: '#BE185D' },
  impuestos: { label: 'Impuestos y Contribuciones', icon: Landmark, color: '#C62828' },
  adquisiciones: { label: 'Adquisiciones (activos)', icon: ShoppingCart, color: '#2E7D32' },
};

const ESTADOS = {
  pendiente: { label: 'Pendiente de pago', color: '#B45309', bg: '#FEF3E2', icon: Clock },
  pagado: { label: 'Pagado', color: '#2E7D32', bg: '#EAF6EC', icon: CheckCircle2 },
  vencido: { label: 'Vencido', color: '#C62828', bg: '#FDECEC', icon: AlertTriangle },
  rechazado: { label: 'Rechazado', color: '#94A3B8', bg: '#F1F5F9', icon: Ban },
};

/* Nota de diseño: Honorarios y Adquisiciones aparecen aquí SOLO como pago consolidado.
   El detalle transacción-por-transacción vive en sus propias secciones (4, 5 y 6) —
   Egresos es la vista agregada de "toda la plata que sale", no un duplicado de esas secciones. */

/* ---------------------------- formatters -------------------------------- */
const clp = (n) => '$' + Math.round(n).toLocaleString('es-CL');
const fmtDate = (iso) =>
  new Date(iso + 'T00:00:00').toLocaleDateString('es-CL', { day: '2-digit', month: 'short', year: 'numeric' });
const addDays = (iso, n) => {
  const d = new Date(iso + 'T00:00:00');
  d.setDate(d.getDate() + n);
  return d.toISOString().slice(0, 10);
};
const diffDays = (isoA, isoB) => Math.round((new Date(isoB + 'T00:00:00') - new Date(isoA + 'T00:00:00')) / 86400000);

// Ver ContabilidadHelpersCompartidos.js — versión canónica verificada de semaforo() (idéntica).
function semaforo(valor, metaEsMinimo, umbralBueno, umbralMalo) {
  const esBueno = metaEsMinimo ? valor >= umbralBueno : valor <= umbralBueno;
  const esMalo = metaEsMinimo ? valor < umbralMalo : valor > umbralMalo;
  if (esBueno) return C.pri;
  if (esMalo) return C.err;
  return C.warn;
}

/* ═══════════════════════════════════════════════════════════════════════
   PUERTA ETIQUETADA — calcularKPIsEgresos
   Misma forma que calcularKPIsIngresos: función pura, solo números,
   lista para que Alta Dirección (dir_kpis_fin) la consuma más adelante.
   ═══════════════════════════════════════════════════════════════════════ */
export function calcularKPIsEgresos(rows) {
  const sum = (pred) => rows.filter(pred).reduce((s, r) => s + r.monto, 0);

  const totalPeriodo = rows.reduce((s, r) => s + r.monto, 0);
  const pagado = sum((r) => r.estado === 'pagado');
  const pendiente = sum((r) => r.estado === 'pendiente');
  const vencido = sum((r) => r.estado === 'vencido');
  const rechazado = sum((r) => r.estado === 'rechazado');
  const vencidoCount = rows.filter((r) => r.estado === 'vencido').length;
  const egresosValidos = totalPeriodo - rechazado; // excluye lo rechazado del cálculo de tasas

  const pagados = rows.filter((r) => r.estado === 'pagado' && r.fechaPago);
  const pagadosATiempo = pagados.filter((r) => r.fechaPago <= r.fechaVencimiento).length;
  const tasaPagoATiempo = pagados.length ? Math.round((pagadosATiempo / pagados.length) * 100) : 0;
  const pctVencido = egresosValidos ? Math.round((vencido / egresosValidos) * 100) : 0;
  const dpo = pagados.length
    ? Math.round((pagados.reduce((s, r) => s + diffDays(r.fecha, r.fechaPago), 0) / pagados.length) * 10) / 10
    : 0;

  const porProveedor = {};
  rows.forEach((r) => { porProveedor[r.proveedor] = (porProveedor[r.proveedor] || 0) + r.monto; });
  const proveedoresOrdenados = Object.entries(porProveedor).sort((a, b) => b[1] - a[1]);
  const concentracionTop = totalPeriodo ? Math.round(((proveedoresOrdenados[0]?.[1] || 0) / totalPeriodo) * 100) : 0;
  const proveedorPrincipal = proveedoresOrdenados[0]?.[0] || '—';

  const porCategoria = Object.keys(CATEGORIAS).map((id) => ({ id, monto: sum((r) => r.categoria === id) })).sort((a, b) => b.monto - a.monto);
  const porCentro = Object.keys(CENTROS).map((id) => ({ id, monto: sum((r) => r.centroCosto === id) })).sort((a, b) => b.monto - a.monto);

  // % fuera de convenio: solo tiene sentido sobre categorías donde el concepto aplica
  // (proveedores, arriendo, adquisiciones) — remuneraciones/honorarios/servicios/impuestos no lo tienen.
  const conConcepto = rows.filter((r) => r.dentroConvenio !== null);
  const montoConConcepto = conConcepto.reduce((s, r) => s + r.monto, 0);
  const fueraConvenio = conConcepto.filter((r) => r.dentroConvenio === false).reduce((s, r) => s + r.monto, 0);
  const pctFueraConvenio = montoConConcepto ? Math.round((fueraConvenio / montoConConcepto) * 100) : 0;
  const pctNoRecurrente = rows.length ? Math.round((rows.filter((r) => !r.recurrente).length / rows.length) * 100) : 0;

  return {
    seccion: 'egresos', transacciones: rows.length,
    totalPeriodo, pagado, pendiente, vencido, vencidoCount, rechazado, egresosValidos,
    tasaPagoATiempo, pctVencido, dpo, concentracionTop, proveedorPrincipal,
    pctFueraConvenio, fueraConvenio, pctNoRecurrente,
    porCategoria, porCentro,
  };
}

/* ═══════════════════════════════════════════════════════════════════════
   PUERTA ETIQUETADA — recibirLiquidacionRRHH
   Punto de conexión para el MÓDULO DE RECURSOS HUMANOS / WORKFORCE (motor
   separado, confirmado por Aleaxon 2026-09-02 — no es una sección de
   Contabilidad, se sincroniza con este módulo cuando exista). Mientras ese
   motor no esté construido, nadie llama a esta función y Egresos sigue
   mostrando su mock de "Planilla Remuneraciones · Quincena" tal cual está,
   sin ningún cambio visible.

   El desglose de descuentos ya viene con la forma que exige Previred
   (AFP / Salud Fonasa-Isapre / Seguro de Cesantía / Mutualidad, vencimiento
   día 13 del mes siguiente al período — ver
   AXON_Contabilidad_Archivo_PDFs_Fuentes_Legales_y_Tecnicas.md §4), para no
   tener que rediseñar esta puerta el día que RRHH/Workforce empiece a
   enviar liquidaciones reales.
   ═══════════════════════════════════════════════════════════════════════ */
export function recibirLiquidacionRRHH({
  trabajadorId,
  trabajadorNombre,
  centroCosto = 'administracion',
  periodo,              // 'YYYY-MM' — mes de la liquidación
  sueldoBruto,
  descuentos = {},       // { afp, saludFonasaIsapre, seguroCesantia, mutualidad, otros }
  sueldoLiquido,         // si no viene, se calcula como sueldoBruto - suma(descuentos)
  fecha,                 // fecha de la liquidación; por defecto, fin del período
}, idBase) {
  const totalDescuentos = Object.values(descuentos).reduce((s, v) => s + (v || 0), 0);
  const montoLiquido = sueldoLiquido ?? (sueldoBruto - totalDescuentos);
  // Previred vence el día 13 del mes SIGUIENTE al período liquidado, no del mes de la liquidación.
  const [anio, mes] = periodo.split('-').map(Number);
  const mesSig = mes === 12 ? 1 : mes + 1;
  const anioSig = mes === 12 ? anio + 1 : anio;
  const fechaVencimiento = `${anioSig}-${String(mesSig).padStart(2, '0')}-13`;

  return {
    id: `egr_rrhh_${idBase}`,
    fecha: fecha || `${periodo}-28`,
    fechaVencimiento,
    fechaPago: null,
    proveedor: trabajadorNombre || 'Planilla RRHH',
    categoria: 'remuneraciones',
    centroCosto,
    glosa: `Liquidación de sueldo · ${periodo}`,
    monto: montoLiquido,
    condIVA: 'no_aplica',
    recurrente: true,
    dentroConvenio: null,
    documento: { tipo: 'Comprobante interno', folio: null },
    estado: 'pendiente',
    // Campos que esta pantalla no muestra hoy, pero que RRHH/Workforce va a
    // necesitar conservar aguas abajo (Previred día 13, Libro de
    // Remuneraciones Electrónico DT día 15 si hay 5+ trabajadores) — no se
    // pierden, solo no se usan todavía en esta UI.
    trabajadorId,
    sueldoBruto,
    descuentos,
    totalDescuentos,
    origen: 'rrhh_workforce',
  };
}

/* ------------------------------ mock data -------------------------------- */
const PROVEEDORES = ['Suministros Médicos del Pacífico Ltda.', 'ServiClean Hospitalario SpA', 'Farmadistribución Andina S.A.', 'TecnoMed Equipos e Insumos Ltda.', 'Ingeniería Biomédica del Sur SpA', 'Distribuidora Hospitalaria Continental S.A.', 'Laboratorios Reactivos Chile Ltda.', 'Seguridad y Vigilancia Austral SpA'];
const PROVEEDOR_POR_CATEGORIA = {
  proveedores: PROVEEDORES,
  remuneraciones: ['Planilla Remuneraciones · Quincena'],
  honorarios: ['Pago Consolidado Honorarios Médicos', 'Pago Consolidado Honorarios Externos'],
  servicios: ['Compañía General de Electricidad S.A.', 'Aguas Andinas S.A.', 'Metrogas S.A.', 'Movistar Empresas'],
  arriendo: ['Inmobiliaria Rentas Corporativas SpA', 'ServiTécnica Equipos Médicos Ltda.'],
  impuestos: ['Tesorería General de la República', 'Municipalidad Local · Patente y Contribuciones'],
  adquisiciones: ['TecnoMed Equipos e Insumos Ltda.', 'Ingeniería Biomédica del Sur SpA'],
};
const MONTO_BASE = { proveedores: 480000, remuneraciones: 14500000, honorarios: 6200000, servicios: 780000, arriendo: 1400000, impuestos: 1100000, adquisiciones: 3200000 };
const CENTRO_POR_CATEGORIA = {
  proveedores: Object.keys(CENTROS).slice(0, 7),
  remuneraciones: ['administracion'],
  honorarios: ['administracion'],
  servicios: ['administracion', 'mantencion'],
  arriendo: ['administracion', 'mantencion'],
  impuestos: ['administracion'],
  adquisiciones: ['ti', 'mantencion', 'imagenologia', 'laboratorio'],
};
const ESTADO_POOL = ['pagado', 'pagado', 'pagado', 'pendiente', 'vencido', 'rechazado'];
const CATEGORIA_KEYS = Object.keys(CATEGORIAS);

// Dos banderas independientes, no una jerarquía rígida:
// - "recurrente" = eje de TIEMPO (¿se repite mes a mes o es puntual?)
// - "dentroConvenio" = eje de CONTROL INTERNO (¿pasó por el proveedor/precio ya aprobado?)
//   Solo tiene sentido para categorías de compra real (proveedores, arriendo, adquisiciones);
//   para remuneraciones/honorarios/servicios/impuestos no existe el concepto -> null.
const CATEGORIAS_CON_CONVENIO = ['proveedores', 'arriendo', 'adquisiciones'];
function esRecurrente(categoria, seed) {
  if (categoria === 'adquisiciones') return seed % 6 === 0; // compras de activos: casi siempre puntuales
  if (categoria === 'proveedores' || categoria === 'arriendo') return seed % 9 !== 0; // mayoría recurrente, algunas puntuales
  return true; // remuneraciones, honorarios, servicios, impuestos: recurrentes por naturaleza
}
function calcularDentroConvenio(categoria, seed) {
  if (!CATEGORIAS_CON_CONVENIO.includes(categoria)) return null; // no aplica el concepto
  return seed % 8 !== 0; // ~87% dentro de convenio; el resto es la excepción que interesa auditar
}

/* Rango dinámico: desde enero hasta el mes de HOY — mismo patrón que Ingresos y Balances. */
const HOY_EGR = new Date('2026-07-05T00:00:00');
function mesesDelAnioHasta(hoy) {
  const anio = hoy.getFullYear(), mesActual = hoy.getMonth(), meses = [];
  for (let m = 0; m <= mesActual; m++) meses.push(`${anio}-${String(m + 1).padStart(2, '0')}`);
  return meses;
}
const MESES_EGR = mesesDelAnioHasta(HOY_EGR);
const HOY_ISO_EGR = HOY_EGR.toISOString().slice(0, 10);
const DIAS_DEL_MES_EGR = { '01': 31, '02': 28, '03': 31, '04': 30, '05': 31, '06': 30, '07': 31, '08': 31, '09': 30, '10': 31, '11': 30, '12': 31 };
// Meses ya cerrados no deberían mostrar "pendiente" ni "vencido" sin resolver — ya se pagaron o se rechazaron.
const ESTADO_POOL_HISTORICO_EGR = ['pagado', 'pagado', 'pagado', 'pagado', 'rechazado'];

function genMock() {
  const rows = [];
  let seed = 3;
  const REGISTROS_POR_MES = 20;
  MESES_EGR.forEach((mesStr, mesIdx) => {
    const esMesActual = mesIdx === MESES_EGR.length - 1;
    const diasEnMes = esMesActual ? HOY_EGR.getDate() : DIAS_DEL_MES_EGR[mesStr.slice(5, 7)];
    for (let i = 0; i < REGISTROS_POR_MES; i++) {
      seed += 17;
      const categoria = CATEGORIA_KEYS[seed % CATEGORIA_KEYS.length];
      const provOpciones = PROVEEDOR_POR_CATEGORIA[categoria];
      const proveedor = provOpciones[(seed * 3) % provOpciones.length];
      const centroOpciones = CENTRO_POR_CATEGORIA[categoria];
      const centroCosto = centroOpciones[(seed * 5) % centroOpciones.length];
      const variacion = 1 + (((seed * 13) % 40) - 20) / 100; // ±20%
      const monto = Math.round((MONTO_BASE[categoria] * variacion) / 100) * 100;
      const condIVA = ['remuneraciones', 'honorarios', 'impuestos'].includes(categoria) ? 'no_aplica' : 'afecto';
      const recurrente = esRecurrente(categoria, seed);
      const dentroConvenio = calcularDentroConvenio(categoria, seed);
      const dia = 1 + (seed % diasEnMes);
      const fecha = `${mesStr}-${String(dia).padStart(2, '0')}`;
      const fechaVencimiento = addDays(fecha, 15 + (seed % 16)); // 15 a 30 días de plazo
      const pool = esMesActual ? ESTADO_POOL : ESTADO_POOL_HISTORICO_EGR;
      const estado = pool[seed % pool.length];
      const pagadoConAtraso = seed % 5 === 0; // ~20% de lo pagado, pagado tarde
      const fechaPago = estado === 'pagado' ? addDays(fechaVencimiento, pagadoConAtraso ? 3 + (seed % 6) : -(1 + (seed % 8))) : null;
      const folio = estado === 'rechazado' ? null : 8800 + rows.length;
      rows.push({
        id: 'egr_' + (1000 + rows.length),
        fecha, fechaVencimiento, fechaPago,
        proveedor,
        categoria,
        centroCosto,
        glosa: CATEGORIAS[categoria].label + (categoria === 'proveedores' ? ' · insumos clínicos' : ''),
        monto,
        condIVA,
        recurrente,
        dentroConvenio,
        documento: { tipo: condIVA === 'no_aplica' ? 'Comprobante interno' : 'Factura recibida', folio },
        estado,
      });
    }
  });
  return rows.sort((a, b) => (a.fecha < b.fecha ? 1 : -1));
}

/* ------------------------------- átomos ---------------------------------- */
const Badge = ({ color, bg, icon: Icon, children }) => (
  <span style={{
    display: 'inline-flex', alignItems: 'center', gap: 5, padding: '3px 9px',
    borderRadius: 999, fontSize: 12, fontWeight: 600, color, background: bg, whiteSpace: 'nowrap',
  }}>
    {Icon && <Icon size={12} />}{children}
  </span>
);

const Btn = ({ variant = 'ghost', icon: Icon, children, onClick, style, type = 'button' }) => {
  const base = {
    display: 'inline-flex', alignItems: 'center', gap: 7, padding: '9px 15px', borderRadius: C.rSm,
    fontSize: 13.5, fontWeight: 600, cursor: 'pointer', border: '1px solid transparent',
    fontFamily: C.font, transition: 'filter .12s ease',
  };
  const variants = {
    primary: { background: C.pri, color: '#fff' },
    outline: { background: '#fff', color: C.ink, border: `1px solid ${C.border}` },
    ghost: { background: 'transparent', color: C.sub },
  };
  return (
    <button type={type} onClick={onClick}
      onMouseEnter={(e) => (e.currentTarget.style.filter = 'brightness(0.96)')}
      onMouseLeave={(e) => (e.currentTarget.style.filter = 'none')}
      style={{ ...base, ...variants[variant], ...style }}>
      {Icon && <Icon size={15} />}{children}
    </button>
  );
};

const KPICard = ({ label, value, sub, icon: Icon, accent }) => (
  <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, padding: '16px 18px', boxShadow: C.shadow, flex: 1, minWidth: 0 }}>
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
      <span style={{ fontSize: 12.5, color: C.sub, fontWeight: 600 }}>{label}</span>
      <div style={{ width: 28, height: 28, borderRadius: 8, background: accent + '18', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <Icon size={14} style={{ color: accent }} />
      </div>
    </div>
    <div style={{ fontSize: 22, fontWeight: 700, color: C.ink, letterSpacing: -0.3 }}>{value}</div>
    {sub && <div style={{ fontSize: 12, color: C.mut, marginTop: 3 }}>{sub}</div>}
  </div>
);

const FieldLabel = ({ children }) => <label style={{ fontSize: 11.5, fontWeight: 600, color: C.sub, marginBottom: 5, display: 'block' }}>{children}</label>;
const inputStyle = { width: '100%', padding: '8px 10px', borderRadius: C.rSm, border: `1px solid ${C.border}`, fontSize: 13.5, fontFamily: C.font, color: C.ink, outline: 'none', boxSizing: 'border-box', background: '#fff' };

function BreakdownCard({ title, items, total }) {
  return (
    <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, padding: 18, boxShadow: C.shadow, flex: 1, minWidth: 0 }}>
      <div style={{ fontSize: 13, fontWeight: 700, color: C.ink, marginBottom: 14 }}>{title}</div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 11 }}>
        {items.map(([key, meta, monto]) => {
          const pct = total ? Math.round((monto / total) * 100) : 0;
          const Icon = meta.icon;
          return (
            <div key={key}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12.5, marginBottom: 4 }}>
                <span style={{ display: 'flex', alignItems: 'center', gap: 6, color: C.ink, fontWeight: 500 }}><Icon size={13} style={{ color: meta.color }} /> {meta.label}</span>
                <span style={{ color: C.sub, fontWeight: 600 }}>{clp(monto)} <span style={{ color: C.mut, fontWeight: 400 }}>({pct}%)</span></span>
              </div>
              <div style={{ height: 6, borderRadius: 4, background: C.bg, overflow: 'hidden' }}>
                <div style={{ height: '100%', width: pct + '%', background: meta.color, borderRadius: 4 }} />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function DetailModal({ row, onClose }) {
  if (!row) return null;
  const cat = CATEGORIAS[row.categoria], cen = CENTROS[row.centroCosto], est = ESTADOS[row.estado];
  const neto = row.condIVA === 'afecto' ? Math.round(row.monto / 1.19) : row.monto;
  const iva = row.condIVA === 'afecto' ? row.monto - neto : 0;
  const atraso = row.fechaPago && row.fechaPago > row.fechaVencimiento;
  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(16,24,40,.45)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100, padding: 20 }} onClick={onClose}>
      <div style={{ background: '#fff', borderRadius: C.rLg, width: 500, maxWidth: '100%', maxHeight: '90vh', overflowY: 'auto', boxShadow: '0 20px 50px rgba(16,24,40,.25)' }} onClick={(e) => e.stopPropagation()}>
        <div style={{ padding: '18px 22px', borderBottom: `1px solid ${C.border}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
            <div style={{ width: 34, height: 34, borderRadius: 9, background: cat.color + '18', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><cat.icon size={16} style={{ color: cat.color }} /></div>
            <div>
              <div style={{ fontSize: 15, fontWeight: 700, color: C.ink }}>{row.proveedor}</div>
              <div style={{ fontSize: 12, color: C.mut }}>{fmtDate(row.fecha)} · {row.id}</div>
            </div>
          </div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: C.mut }}><X size={18} /></button>
        </div>
        <div style={{ padding: 22, display: 'flex', flexDirection: 'column', gap: 16 }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
            <div><FieldLabel>Categoría</FieldLabel><Badge color={cat.color} bg={cat.color + '18'} icon={cat.icon}>{cat.label}</Badge></div>
            <div><FieldLabel>Centro de costo</FieldLabel><Badge color={cen.color} bg={cen.color + '18'} icon={cen.icon}>{cen.label}</Badge></div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
            <div><FieldLabel>Recurrencia</FieldLabel><div style={{ fontSize: 12.5, color: C.ink }}>{row.recurrente ? 'Recurrente' : 'Puntual / no recurrente'}</div></div>
            <div>
              <FieldLabel>Convenio</FieldLabel>
              {row.dentroConvenio === null
                ? <div style={{ fontSize: 12.5, color: C.mut }}>No aplica</div>
                : <Badge color={row.dentroConvenio ? C.pri : C.err} bg={row.dentroConvenio ? C.priL : C.errL}>{row.dentroConvenio ? 'Dentro de convenio' : 'Fuera de convenio'}</Badge>}
            </div>
          </div>
          <div style={{ background: C.bg, borderRadius: C.rSm, padding: 14 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, color: C.sub, marginBottom: 6 }}><span>Monto neto</span><span style={{ color: C.ink, fontWeight: 600 }}>{clp(neto)}</span></div>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, color: C.sub, marginBottom: 6 }}><span>IVA {row.condIVA === 'no_aplica' ? '(no aplica)' : '(19%)'}</span><span style={{ color: C.ink, fontWeight: 600 }}>{clp(iva)}</span></div>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 14.5, paddingTop: 8, borderTop: `1px dashed ${C.borderD}`, marginTop: 4 }}><span style={{ fontWeight: 700, color: C.ink }}>Total</span><span style={{ fontWeight: 700, color: C.ink }}>{clp(row.monto)}</span></div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 12 }}>
            <div><FieldLabel>Emisión</FieldLabel><div style={{ fontSize: 12.5, color: C.ink }}>{fmtDate(row.fecha)}</div></div>
            <div><FieldLabel>Vencimiento</FieldLabel><div style={{ fontSize: 12.5, color: C.ink }}>{fmtDate(row.fechaVencimiento)}</div></div>
            <div><FieldLabel>Pago</FieldLabel><div style={{ fontSize: 12.5, color: row.fechaPago ? (atraso ? C.err : C.ink) : C.mut }}>{row.fechaPago ? fmtDate(row.fechaPago) + (atraso ? ' · con atraso' : '') : 'Sin pagar'}</div></div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
            <div>
              <FieldLabel>Documento</FieldLabel>
              <div style={{ fontSize: 13, color: C.ink, fontWeight: 600 }}>{row.documento.tipo}</div>
              <div style={{ fontSize: 12, color: C.mut }}>{row.documento.folio ? `Folio N° ${row.documento.folio}` : 'Sin folio'}</div>
            </div>
            <div><FieldLabel>Estado</FieldLabel><Badge color={est.color} bg={est.bg} icon={est.icon}>{est.label}</Badge></div>
          </div>
          <div style={{ fontSize: 11, color: C.mut, paddingTop: 10, borderTop: `1px solid ${C.border}` }}>Recurso FHIR asociado: <span style={{ fontFamily: 'monospace', background: C.bg, padding: '2px 6px', borderRadius: 4 }}>Invoice</span></div>
        </div>
      </div>
    </div>
  );
}

function NewEgresoModal({ onClose, onSave }) {
  const [form, setForm] = useState({ proveedor: '', categoria: 'proveedores', centroCosto: 'administracion', monto: '', dias: '30' });
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });
  const puedeGuardar = form.proveedor.trim() && Number(form.monto) > 0;
  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(16,24,40,.45)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100, padding: 20 }} onClick={onClose}>
      <div style={{ background: '#fff', borderRadius: C.rLg, width: 440, maxWidth: '100%', boxShadow: '0 20px 50px rgba(16,24,40,.25)' }} onClick={(e) => e.stopPropagation()}>
        <div style={{ padding: '18px 22px', borderBottom: `1px solid ${C.border}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ fontSize: 15, fontWeight: 700, color: C.ink }}>Registrar egreso</div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: C.mut }}><X size={18} /></button>
        </div>
        <div style={{ padding: 22, display: 'flex', flexDirection: 'column', gap: 13 }}>
          <div><FieldLabel>Proveedor / beneficiario</FieldLabel><input style={inputStyle} value={form.proveedor} onChange={set('proveedor')} placeholder="Ej: Farmadistribución Andina S.A." /></div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <div><FieldLabel>Categoría</FieldLabel><select style={inputStyle} value={form.categoria} onChange={set('categoria')}>{Object.entries(CATEGORIAS).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}</select></div>
            <div><FieldLabel>Centro de costo</FieldLabel><select style={inputStyle} value={form.centroCosto} onChange={set('centroCosto')}>{Object.entries(CENTROS).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}</select></div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <div><FieldLabel>Monto total (CLP)</FieldLabel><input style={inputStyle} type="number" value={form.monto} onChange={set('monto')} placeholder="480000" /></div>
            <div><FieldLabel>Plazo de pago (días)</FieldLabel><input style={inputStyle} type="number" value={form.dias} onChange={set('dias')} placeholder="30" /></div>
          </div>
        </div>
        <div style={{ padding: '14px 22px', borderTop: `1px solid ${C.border}`, display: 'flex', justifyContent: 'flex-end', gap: 10 }}>
          <Btn variant="ghost" onClick={onClose}>Cancelar</Btn>
          <Btn variant="primary" icon={Plus} onClick={() => puedeGuardar && onSave(form)} style={{ opacity: puedeGuardar ? 1 : 0.5 }}>Registrar egreso</Btn>
        </div>
      </div>
    </div>
  );
}

/* --------------------------------- vista principal ------------------------------------ */
export default function ContabilidadEgresos({ addToast }) {
  const toast = addToast || ((msg) => console.log(msg));
  const [data, setData] = useState(genMock);
  const [filtros, setFiltros] = useState({ desde: MESES_EGR[0] + '-01', hasta: HOY_ISO_EGR, categoria: 'todas', centro: 'todos', estado: 'todos', convenio: 'todos', q: '' });
  const [selected, setSelected] = useState(null);
  const [showNew, setShowNew] = useState(false);
  const [page, setPage] = useState(1);
  const perPage = 8;

  const filtered = useMemo(() => data.filter((r) => {
    if (r.fecha < filtros.desde || r.fecha > filtros.hasta) return false;
    if (filtros.categoria !== 'todas' && r.categoria !== filtros.categoria) return false;
    if (filtros.centro !== 'todos' && r.centroCosto !== filtros.centro) return false;
    if (filtros.estado !== 'todos' && r.estado !== filtros.estado) return false;
    if (filtros.convenio === 'fuera' && r.dentroConvenio !== false) return false;
    if (filtros.convenio === 'dentro' && r.dentroConvenio !== true) return false;
    if (filtros.q && !r.proveedor.toLowerCase().includes(filtros.q.toLowerCase())) return false;
    return true;
  }), [data, filtros]);

  // "Puerta etiquetada": mismo patrón que Ingresos.
  const kpi = useMemo(() => calcularKPIsEgresos(filtered), [filtered]);
  const porCategoriaDisplay = kpi.porCategoria.map((item) => [item.id, CATEGORIAS[item.id], item.monto]);
  const porCentroDisplay = kpi.porCentro.filter((item) => item.monto > 0).map((item) => [item.id, CENTROS[item.id], item.monto]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / perPage));
  const pageRows = filtered.slice((page - 1) * perPage, page * perPage);
  const limpiarFiltros = () => { setFiltros({ desde: MESES_EGR[0] + '-01', hasta: HOY_ISO_EGR, categoria: 'todas', centro: 'todos', estado: 'todos', convenio: 'todos', q: '' }); setPage(1); };

  const exportarCSV = () => {
    const header = ['Fecha', 'Proveedor', 'Categoría', 'Centro de Costo', 'Monto', 'Recurrente', 'Dentro de Convenio', 'Vencimiento', 'Pago', 'Estado'];
    const lines = filtered.map((r) => [r.fecha, r.proveedor, CATEGORIAS[r.categoria].label, CENTROS[r.centroCosto].label, r.monto, r.recurrente ? 'Sí' : 'No', r.dentroConvenio === null ? 'N/A' : (r.dentroConvenio ? 'Sí' : 'No'), r.fechaVencimiento, r.fechaPago || '', ESTADOS[r.estado].label].join(';'));
    const blob = new Blob([header.join(';') + '\n' + lines.join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = `egresos_${filtros.desde}_a_${filtros.hasta}.csv`; a.click();
    URL.revokeObjectURL(url);
    toast('Archivo CSV descargado');
  };

  const handleSave = (form) => {
    const fecha = '2026-07-05';
    const fechaVencimiento = addDays(fecha, Number(form.dias) || 30);
    const condIVA = ['remuneraciones', 'honorarios', 'impuestos'].includes(form.categoria) ? 'no_aplica' : 'afecto';
    setData([{
      id: 'egr_' + (3000 + data.length), fecha, fechaVencimiento, fechaPago: null,
      proveedor: form.proveedor, categoria: form.categoria, centroCosto: form.centroCosto,
      glosa: CATEGORIAS[form.categoria].label, monto: Number(form.monto), condIVA,
      recurrente: true, // por defecto; ajustable desde la tabla una vez creado
      dentroConvenio: CATEGORIAS_CON_CONVENIO.includes(form.categoria) ? true : null,
      documento: { tipo: condIVA === 'no_aplica' ? 'Comprobante interno' : 'Factura recibida', folio: null },
      estado: 'pendiente',
    }, ...data]);
    setShowNew(false);
    toast('Egreso registrado — queda pendiente de pago');
  };

  return (
    <div style={{ fontFamily: C.font, background: C.bg, minHeight: '100%', padding: 22 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 18, flexWrap: 'wrap', gap: 12 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
          <div style={{ width: 34, height: 34, borderRadius: 9, background: C.errL, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><TrendingDown size={17} style={{ color: C.err }} /></div>
          <div>
            <div style={{ fontSize: 18, fontWeight: 700, color: C.ink }}>Egresos</div>
            <div style={{ fontSize: 12.5, color: C.mut }}>Proveedores, remuneraciones, servicios e impuestos</div>
          </div>
        </div>
        <div style={{ display: 'flex', gap: 9 }}>
          <Btn variant="outline" icon={Download} onClick={exportarCSV}>Exportar CSV</Btn>
          <Btn variant="primary" icon={Plus} onClick={() => setShowNew(true)}>Nuevo egreso</Btn>
        </div>
      </div>

      <div style={{ fontSize: 11.5, fontWeight: 700, color: C.mut, textTransform: 'uppercase', letterSpacing: 0.4, marginBottom: 8 }}>Métricas del período</div>
      <div style={{ display: 'flex', gap: 14, marginBottom: 18, flexWrap: 'wrap' }}>
        <KPICard label="Egresos del período" value={clp(kpi.totalPeriodo)} sub={`${kpi.transacciones} documentos · bruto`} icon={TrendingDown} accent={C.err} />
        <KPICard label="Pagado" value={clp(kpi.pagado)} sub="En el período filtrado" icon={CheckCircle2} accent={C.pri} />
        <KPICard label="Pendiente de pago" value={clp(kpi.pendiente)} sub="Aún dentro de plazo" icon={Clock} accent={C.warn} />
        <KPICard label="Rechazado" value={clp(kpi.rechazado)} sub="Facturas disputadas / rechazadas" icon={Ban} accent={C.mut} />
      </div>

      <div style={{ fontSize: 11.5, fontWeight: 700, color: C.mut, textTransform: 'uppercase', letterSpacing: 0.4, marginBottom: 8 }}>Indicadores de gestión</div>
      <div style={{ display: 'flex', gap: 14, marginBottom: 14, flexWrap: 'wrap' }}>
        <KPICard label="Tasa de pago a tiempo" value={kpi.tasaPagoATiempo + '%'} sub="Meta: ≥ 95% sin atraso" icon={CheckCircle2} accent={semaforo(kpi.tasaPagoATiempo, true, 95, 80)} />
        <KPICard label="Gasto vencido" value={kpi.pctVencido + '%'} sub="Meta: ≤ 5% del válido" icon={AlertTriangle} accent={semaforo(kpi.pctVencido, false, 5, 15)} />
        <KPICard label="DPO · días para pagar" value={kpi.dpo + ' días'} sub="Días promedio hasta el pago" icon={Hourglass} accent={C.vio} />
        <KPICard label="Fuera de convenio" value={kpi.pctFueraConvenio + '%'} sub="Sobre proveedores/arriendo/activos" icon={Package} accent={semaforo(kpi.pctFueraConvenio, false, 10, 25)} />
        <KPICard label="Concentración proveedor" value={kpi.concentracionTop + '%'} sub={kpi.proveedorPrincipal} icon={Info} accent={semaforo(kpi.concentracionTop, false, 25, 40)} />
      </div>

      <div style={{ display: 'flex', gap: 14, marginBottom: 14, flexWrap: 'wrap' }}>
        <BreakdownCard title="Por categoría" items={porCategoriaDisplay} total={kpi.totalPeriodo} />
        <BreakdownCard title="Por centro de costo" items={porCentroDisplay} total={kpi.totalPeriodo} />
      </div>

      <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, padding: 16, boxShadow: C.shadow, marginBottom: 14 }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10, marginBottom: 10 }}>
          <div><FieldLabel>Desde</FieldLabel><input type="date" style={inputStyle} value={filtros.desde} onChange={(e) => { setFiltros({ ...filtros, desde: e.target.value }); setPage(1); }} /></div>
          <div><FieldLabel>Hasta</FieldLabel><input type="date" style={inputStyle} value={filtros.hasta} onChange={(e) => { setFiltros({ ...filtros, hasta: e.target.value }); setPage(1); }} /></div>
          <div><FieldLabel>Categoría</FieldLabel><select style={inputStyle} value={filtros.categoria} onChange={(e) => { setFiltros({ ...filtros, categoria: e.target.value }); setPage(1); }}><option value="todas">Todas</option>{Object.entries(CATEGORIAS).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}</select></div>
          <div><FieldLabel>Centro de costo</FieldLabel><select style={inputStyle} value={filtros.centro} onChange={(e) => { setFiltros({ ...filtros, centro: e.target.value }); setPage(1); }}><option value="todos">Todos</option>{Object.entries(CENTROS).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}</select></div>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10 }}>
          <div><FieldLabel>Estado</FieldLabel><select style={inputStyle} value={filtros.estado} onChange={(e) => { setFiltros({ ...filtros, estado: e.target.value }); setPage(1); }}><option value="todos">Todos</option>{Object.entries(ESTADOS).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}</select></div>
          <div>
            <FieldLabel>Convenio <span title="Solo aplica a Proveedores, Arriendo y Adquisiciones"><Info size={10} style={{ color: C.mut, verticalAlign: 'middle' }} /></span></FieldLabel>
            <select style={inputStyle} value={filtros.convenio} onChange={(e) => { setFiltros({ ...filtros, convenio: e.target.value }); setPage(1); }}>
              <option value="todos">Todos</option>
              <option value="dentro">Dentro de convenio</option>
              <option value="fuera">Fuera de convenio</option>
            </select>
          </div>
          <div><FieldLabel>Buscar proveedor</FieldLabel><div style={{ position: 'relative' }}><Search size={14} style={{ position: 'absolute', left: 9, top: 10, color: C.mut }} /><input style={{ ...inputStyle, paddingLeft: 28 }} value={filtros.q} onChange={(e) => { setFiltros({ ...filtros, q: e.target.value }); setPage(1); }} /></div></div>
        </div>
        <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 12 }}>
          <button onClick={limpiarFiltros} style={{ display: 'flex', alignItems: 'center', gap: 5, background: 'none', border: 'none', cursor: 'pointer', color: C.sub, fontSize: 12.5, fontWeight: 600, padding: 0 }}><RotateCcw size={13} /> Limpiar filtros</button>
        </div>
      </div>

      <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, boxShadow: C.shadow, overflow: 'hidden' }}>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
            <thead>
              <tr style={{ background: C.bg, textAlign: 'left' }}>
                {['Fecha', 'Proveedor', 'Categoría', 'Centro de costo', 'Monto', 'Vencimiento', 'Estado', ''].map((h) => (
                  <th key={h} style={{ padding: '10px 14px', fontSize: 11.5, fontWeight: 700, color: C.sub, textTransform: 'uppercase', letterSpacing: 0.3, whiteSpace: 'nowrap' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {pageRows.map((r) => {
                const cat = CATEGORIAS[r.categoria], cen = CENTROS[r.centroCosto], est = ESTADOS[r.estado];
                return (
                  <tr key={r.id} style={{ borderTop: `1px solid ${C.border}`, cursor: 'pointer' }} onClick={() => setSelected(r)}
                    onMouseEnter={(e) => (e.currentTarget.style.background = C.bg)} onMouseLeave={(e) => (e.currentTarget.style.background = 'transparent')}>
                    <td style={{ padding: '11px 14px', color: C.sub, whiteSpace: 'nowrap' }}>{fmtDate(r.fecha)}</td>
                    <td style={{ padding: '11px 14px', fontWeight: 600, color: C.ink, maxWidth: 200 }}>{r.proveedor}</td>
                    <td style={{ padding: '11px 14px' }}>
                      <Badge color={cat.color} bg={cat.color + '18'} icon={cat.icon}>{cat.label}</Badge>
                      {r.dentroConvenio === false && <div style={{ marginTop: 3 }}><Badge color={C.err} bg={C.errL}>Fuera de convenio</Badge></div>}
                    </td>
                    <td style={{ padding: '11px 14px' }}><Badge color={cen.color} bg={cen.color + '18'} icon={cen.icon}>{cen.label}</Badge></td>
                    <td style={{ padding: '11px 14px', fontWeight: 700, color: C.ink, whiteSpace: 'nowrap' }}>{clp(r.monto)}</td>
                    <td style={{ padding: '11px 14px', color: C.sub, whiteSpace: 'nowrap' }}>{fmtDate(r.fechaVencimiento)}</td>
                    <td style={{ padding: '11px 14px' }}><Badge color={est.color} bg={est.bg} icon={est.icon}>{est.label}</Badge></td>
                    <td style={{ padding: '11px 14px' }}><Eye size={15} style={{ color: C.mut }} /></td>
                  </tr>
                );
              })}
              {pageRows.length === 0 && (
                <tr><td colSpan={8} style={{ padding: '40px 14px', textAlign: 'center', color: C.mut, fontSize: 13 }}>
                  No hay egresos que calcen con estos filtros. Ajusta el rango de fechas o la categoría, o <button onClick={limpiarFiltros} style={{ color: C.info, background: 'none', border: 'none', cursor: 'pointer', fontSize: 13, textDecoration: 'underline', padding: 0 }}>limpia los filtros</button>.
                </td></tr>
              )}
            </tbody>
          </table>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 16px', borderTop: `1px solid ${C.border}` }}>
          <span style={{ fontSize: 12, color: C.mut }}>{filtered.length} registros · página {page} de {totalPages}</span>
          <div style={{ display: 'flex', gap: 6 }}>
            <Btn variant="outline" onClick={() => setPage(Math.max(1, page - 1))} style={{ padding: '6px 12px', opacity: page === 1 ? 0.4 : 1 }}>Anterior</Btn>
            <Btn variant="outline" onClick={() => setPage(Math.min(totalPages, page + 1))} style={{ padding: '6px 12px', opacity: page === totalPages ? 0.4 : 1 }}>Siguiente</Btn>
          </div>
        </div>
      </div>

      {selected && <DetailModal row={selected} onClose={() => setSelected(null)} />}
      {showNew && <NewEgresoModal onClose={() => setShowNew(false)} onSave={handleSave} />}
    </div>
  );
}
