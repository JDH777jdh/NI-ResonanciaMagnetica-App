import React, { useState, useMemo } from 'react';
import {
  Receipt, TrendingDown, RotateCcw, Percent, FileText, Hourglass,
  Info, Download, CheckCircle2, Clock,
} from 'lucide-react';

/* =========================================================================
   DISEÑO — copiado 1:1 desde HISClinico_Layer1.jsx / demás secciones de
   Contabilidad, para que este archivo se pueda previsualizar de forma
   independiente. Al integrar a producción real: borrar este bloque e
   importar el "C" y los átomos reales de Layer1 (o de un archivo
   compartido, si se centraliza — Decisión #5 del roadmap de MAIN).
   ========================================================================= */
const C = {
  bg: '#F4F6F9', card: '#FFFFFF', border: '#E2E8F0', borderD: '#CBD5E1',
  ink: '#16233E', sub: '#5B6B85', mut: '#94A3B8',
  pri: '#2E7D32', priD: '#1B5E20', priL: '#EAF6EC',
  info: '#2563EB', infoL: '#EEF3FF',
  warn: '#B45309', warnL: '#FEF3E2',
  err: '#C62828', errL: '#FDECEC',
  vio: '#6D28D9', vioL: '#F2ECFB',
  teal: '#0E7490', tealL: '#E3F6FA',
  r: 10, rSm: 7, rLg: 14,
  shadow: '0 1px 3px rgba(16,24,40,.06), 0 1px 2px rgba(16,24,40,.04)',
  font: "'Inter', -apple-system, 'Segoe UI', Roboto, sans-serif",
};

/* ═══════════════════════════════════════════════════════════════════════
   DE DÓNDE VIENEN LOS DATOS — composición pura, sin dataset propio (Sección
   10 de la Hoja de Ruta de Contabilidad). El F29 mensual no es más que la
   traducción a lenguaje SII de lo que Ingresos, Egresos y Honorarios ya
   registran: la Reforma Tributaria reemplazó los libros de Compras y Ventas
   físicos por el RCV (Registro de Compras y Ventas) electrónico desde 2017,
   construido con las mismas Facturas/Boletas que emiten y reciben esas
   secciones — el SII arma su propuesta de F29 desde ahí. Este archivo no
   inventa datos propios: son versiones simplificadas (monto + condIVA/tipo +
   fecha) del MISMO shape que ya exportan Ingresos/Egresos/Honorarios
   Médicos/Honorarios Externos, listas para reemplazarse por el `data` real
   de cada sección sin tocar el resto de la pantalla.
   ═══════════════════════════════════════════════════════════════════════ */

const HOY = new Date('2026-07-05T00:00:00'); // mismo ancla simulada que el resto del módulo
const HOY_ISO = HOY.toISOString().slice(0, 10);
const clp = (n) => (n < 0 ? '-$' : '$') + Math.round(Math.abs(n)).toLocaleString('es-CL');
const fmtMes = (yyyymm) => new Date(yyyymm + '-01T00:00:00').toLocaleDateString('es-CL', { month: 'long', year: 'numeric' });
const fmtDateLarga = (iso) => new Date(iso + 'T00:00:00').toLocaleDateString('es-CL', { day: '2-digit', month: 'short', year: 'numeric' });
const diffDays = (a, b) => Math.round((new Date(b + 'T00:00:00') - new Date(a + 'T00:00:00')) / 86400000);
const DIAS_DEL_MES = { '01': 31, '02': 28, '03': 31, '04': 30, '05': 31, '06': 30, '07': 31, '08': 31, '09': 30, '10': 31, '11': 30, '12': 31 };
function mesesDelAnioHasta(hoy) {
  const anio = hoy.getFullYear(), mesActual = hoy.getMonth(), meses = [];
  for (let m = 0; m <= mesActual; m++) meses.push(`${anio}-${String(m + 1).padStart(2, '0')}`);
  return meses;
}
const MESES = mesesDelAnioHasta(HOY);

// Ver ContabilidadHelpersCompartidos.js — versión canónica verificada de semaforo() (idéntica).
function semaforo(valor, metaEsMinimo, umbralBueno, umbralMalo) {
  const esBueno = metaEsMinimo ? valor >= umbralBueno : valor <= umbralBueno;
  const esMalo = metaEsMinimo ? valor < umbralMalo : valor > umbralMalo;
  if (esBueno) return C.pri;
  if (esMalo) return C.err;
  return C.warn;
}

/* Régimen tributario de Primera Categoría — determina la tasa de PPM. El
   IDPC (Impuesto de Primera Categoría) en sí es ANUAL, vía F22/Operación
   Renta — fuera del alcance de este módulo, que cubre las obligaciones
   MENSUALES vía F29. Se deja como selector (mismo espíritu que "esPublico"
   en Adquisiciones: toggle de vista previa; en producción vendría de
   tenantTypes.config.js o de la config propia del tenant) porque AXON es
   multi-tenant — un hospital grande normalmente supera el tope Pro Pyme
   (ingreso promedio anual bajo 75.000 UF), pero clínicas más chicas de la
   red sí podrían calificar.
   Fuentes verificadas (jul-2026): 14A 27% (Art. 20 LIR, tasa estable hace
   años) · Pro Pyme 14D N°3 12,5% transitorio años comerciales 2025-2027
   (sube a 15% en 2028) y PPM reducido a la mitad en el mismo período — Ley
   21.755 (D.O. 11-jul-2025), Circular SII N°53 de 2025. */
const REGIMENES = {
  regimen_14a: {
    label: 'Régimen General · 14 A', tasaIDPC: 0.27, tasaPPM: 0.01,
    nota: 'PPM 1% ilustrativo — en la práctica se recalcula cada año según el Art. 84 LIR y el resultado tributario del ejercicio anterior.',
  },
  pro_pyme_14d3: {
    label: 'Pro Pyme · 14 D N°3 (transitorio 2025-2027)', tasaIDPC: 0.125, tasaPPM: 0.005,
    nota: 'IDPC 12,5% y PPM a la mitad hasta el año comercial 2027 (Ley 21.755) — IDPC sube a 15% en 2028 y el PPM vuelve a tasa plena.',
  },
};

/* Interés moratorio — Ley 21.713 (Cumplimiento Tributario) reemplazó el
   1,5% mensual fijo por un interés penal DIARIO variable: (tasa CMF de
   interés corriente a 1 año+, reajustable en moneda nacional, hasta 2.000
   UF, + 3,5%) / 360. El SII publica la tasa vigente cada semestre
   (resolución en junio y diciembre). Última tasa oficial confirmada al
   escribir esto: 1er semestre 2026 (Resolución Exenta SII N°205, D.O.
   15-dic-2025). La del 2° semestre 2026 (vigente desde julio) no aparecía
   aún publicada en la búsqueda — verificar en sii.cl/valores_y_fechas/
   otros_valores/tasa_interes_penal_diario.html antes de usar este número
   para un cálculo real. */
const TASA_INTERES_MORA = {
  anual: 0.0792, diaria: 0.00022, vigenciaDesde: '2026-01-01', vigenciaHasta: '2026-06-30',
  fuente: 'Res. Ex. SII N°205, 15-dic-2025 (1er semestre 2026) — confirmar semestre vigente en sii.cl',
};

const TASA_RETENCION_HONORARIOS = 0.1525; // Ley 21.133, 2026 — mismo parámetro que Honorarios Médicos/Externos

/* F29: vence el día 12 (papel / no facturador electrónico) o el día 20 (por
   Internet, la modalidad de la mayoría de las empresas hoy) del mes
   SIGUIENTE al período tributario. Prórroga a día hábil si cae fin de
   semana/festivo — no modelada acá (simplificación). Verificado:
   sii.cl/portales/mipyme/f29. */
function fechaVencimientoF29(periodoYYYYMM, facturadorElectronico = true) {
  const [anio, mes] = periodoYYYYMM.split('-').map(Number);
  const mesSig = mes === 12 ? 1 : mes + 1;
  const anioSig = mes === 12 ? anio + 1 : anio;
  const dia = facturadorElectronico ? 20 : 12;
  return `${anioSig}-${String(mesSig).padStart(2, '0')}-${String(dia).padStart(2, '0')}`;
}
const ivaDelMonto = (monto) => monto - Math.round(monto / 1.19);

const ESTADOS_F29 = {
  pagado: { label: 'Declarado', color: '#2E7D32', bg: '#EAF6EC', icon: CheckCircle2 },
  pendiente: { label: 'Por declarar', color: '#B45309', bg: '#FEF3E2', icon: Clock },
  en_curso: { label: 'Mes en curso', color: '#5B6B85', bg: '#F4F6F9', icon: RotateCcw },
};

/* ═══════════════════════════════════════════════════════════════════════
   COMPOSICIÓN — mismo espíritu que desdeIngresos()/desdeEgresos() en Flujo
   de Caja o desdeIngresosPendientes() en Facturación: leen filas con la
   MISMA forma que ya exportan las secciones dueñas y las agrupan por mes.
   Privadas a este archivo — el punto de integración real hacia afuera es
   calcularKPIsObligacionesTributarias(), más abajo.
   ═══════════════════════════════════════════════════════════════════════ */
function desdeIngresos(rows) {
  // IVA Débito Fiscal — 19% ya incluido en el monto cuando condIVA === 'afecto'.
  const porMes = {};
  rows.forEach((r) => {
    const mes = r.fecha.slice(0, 7);
    if (!porMes[mes]) porMes[mes] = { ingresosBrutos: 0, ivaDebito: 0 };
    porMes[mes].ingresosBrutos += r.monto;
    if (r.condIVA === 'afecto') porMes[mes].ivaDebito += ivaDelMonto(r.monto);
  });
  return porMes;
}
function desdeEgresos(rows) {
  // IVA Crédito Fiscal — de Facturas recibidas (categorías afectas: Proveedores,
  // Servicios, Arriendo, Adquisiciones; Remuneraciones/Honorarios/Impuestos no aplican).
  const porMes = {};
  rows.forEach((r) => {
    const mes = r.fecha.slice(0, 7);
    if (r.condIVA === 'afecto') porMes[mes] = (porMes[mes] || 0) + ivaDelMonto(r.monto);
  });
  return porMes;
}
function desdeHonorariosMedicos(rows) {
  // Retención de Segunda Categoría (BHE) — 100% del monto bruto es base retenible.
  const porMes = {};
  rows.forEach((r) => {
    const mes = r.fecha.slice(0, 7);
    porMes[mes] = (porMes[mes] || 0) + Math.round(r.montoBruto * TASA_RETENCION_HONORARIOS);
  });
  return porMes;
}
function desdeHonorariosExternos(rows) {
  // Doble vía (mismo patrón que el archivo dueño): Persona Natural (BHE) -> retención;
  // Empresa (Factura) -> IVA Crédito adicional, distinto del que ya aporta Egresos.
  const retenciones = {}, ivaCredito = {};
  rows.forEach((r) => {
    const mes = r.fecha.slice(0, 7);
    if (r.tipoProveedor === 'persona_natural') retenciones[mes] = (retenciones[mes] || 0) + Math.round(r.montoBruto * TASA_RETENCION_HONORARIOS);
    else ivaCredito[mes] = (ivaCredito[mes] || 0) + Math.round(r.montoBruto * 0.19);
  });
  return { retenciones, ivaCredito };
}

/* ═══════════════════════════════════════════════════════════════════════
   PUERTA ETIQUETADA — calcularKPIsObligacionesTributarias
   Función pura: recibe las 4 filas reales de Ingresos/Egresos/Honorarios
   Médicos/Honorarios Externos (mismo shape que ya exportan esas secciones,
   solo necesita monto+condIVA/tipo+fecha de cada una) más el régimen
   tributario vigente, y devuelve el F29 mes a mes — incluyendo el arrastre
   real del remanente de crédito fiscal (Art. 27 Ley de IVA) cuando el
   crédito supera al débito de un mes. Verificado en Node: el remanente se
   arrastra correctamente mes a mes y el IVA a pagar nunca queda negativo.
   ═══════════════════════════════════════════════════════════════════════ */
export function calcularKPIsObligacionesTributarias(ingresosRows, egresosRows, honorariosMedicosRows, honorariosExternosRows, regimenKey = 'regimen_14a') {
  const regimen = REGIMENES[regimenKey] || REGIMENES.regimen_14a;
  const ingresosPorMes = desdeIngresos(ingresosRows);
  const ivaCreditoEgresosPorMes = desdeEgresos(egresosRows);
  const retencionesMedicosPorMes = desdeHonorariosMedicos(honorariosMedicosRows);
  const honExtPorMes = desdeHonorariosExternos(honorariosExternosRows);

  let remanenteAnterior = 0;
  const porMes = MESES.map((mes, idx) => {
    const esMesActual = idx === MESES.length - 1;
    const ingresosBrutos = ingresosPorMes[mes]?.ingresosBrutos || 0;
    const ivaDebito = ingresosPorMes[mes]?.ivaDebito || 0;
    const ivaCreditoTotal = (ivaCreditoEgresosPorMes[mes] || 0) + (honExtPorMes.ivaCredito[mes] || 0);
    const creditoDisponible = ivaCreditoTotal + remanenteAnterior;
    const ivaAPagar = Math.max(0, ivaDebito - creditoDisponible);
    const remanenteNuevo = Math.max(0, creditoDisponible - ivaDebito);
    const retenciones = (retencionesMedicosPorMes[mes] || 0) + (honExtPorMes.retenciones[mes] || 0);
    const ppm = Math.round(ingresosBrutos * regimen.tasaPPM);
    const totalF29 = ivaAPagar + retenciones + ppm;
    const vencimiento = fechaVencimientoF29(mes);
    const estado = esMesActual ? 'en_curso' : (vencimiento < HOY_ISO ? 'pagado' : 'pendiente');
    const fila = {
      mes, esMesActual, ingresosBrutos, ivaDebito, ivaCreditoTotal,
      remanenteAnterior, ivaAPagar, remanenteNuevo, retenciones, ppm, totalF29, vencimiento, estado,
    };
    remanenteAnterior = remanenteNuevo;
    return fila;
  });

  const sum = (key) => porMes.reduce((s, f) => s + f[key], 0);
  const proximoVencimiento = porMes.find((f) => f.estado === 'pendiente') || null;

  return {
    seccion: 'obligaciones_tributarias', regimen: regimenKey, porMes,
    ivaDebitoTotal: sum('ivaDebito'), ivaCreditoTotal: sum('ivaCreditoTotal'),
    ivaAPagarTotal: sum('ivaAPagar'), retencionesTotal: sum('retenciones'),
    ppmTotal: sum('ppm'), totalF29Periodo: sum('totalF29'),
    remanenteVigente: porMes[porMes.length - 1]?.remanenteNuevo ?? 0,
    proximoVencimiento,
  };
}

/* ------------------------------ mock data -------------------------------- */
/* Simplificado a propósito: para componer el F29 solo hace falta monto,
   condIVA/tipo y fecha — el resto de los campos que sí tienen Ingresos/
   Egresos/Honorarios (paciente, proveedor, profesional...) no aporta nada
   acá. En producción esto se reemplaza por el `data` real de cada sección. */
function genIngresosMock() {
  const rows = []; let seed = 3;
  MESES.forEach((mes) => {
    const esMesActual = mes === MESES[MESES.length - 1];
    const dias = esMesActual ? HOY.getDate() : DIAS_DEL_MES[mes.slice(5, 7)];
    for (let i = 0; i < 30; i++) {
      seed += 13;
      const dia = 1 + (seed % dias);
      const monto = 1500000 + (seed * 3701) % 3800000;
      const condIVA = seed % 5 === 0 ? 'afecto' : 'exento'; // ~20% afecto: laboratorio + excedentes sobre arancel
      rows.push({ fecha: `${mes}-${String(dia).padStart(2, '0')}`, monto, condIVA });
    }
  });
  return rows;
}
function genEgresosMock() {
  const rows = []; let seed = 7;
  MESES.forEach((mes) => {
    const esMesActual = mes === MESES[MESES.length - 1];
    const dias = esMesActual ? HOY.getDate() : DIAS_DEL_MES[mes.slice(5, 7)];
    for (let i = 0; i < 16; i++) {
      seed += 17;
      const dia = 1 + (seed % dias);
      const monto = 400000 + (seed * 4211) % 4200000;
      const condIVA = seed % 7 < 4 ? 'afecto' : 'no_aplica'; // ~4/7 categorías generan crédito (Proveedores/Servicios/Arriendo/Adquisiciones)
      rows.push({ fecha: `${mes}-${String(dia).padStart(2, '0')}`, monto, condIVA });
    }
  });
  return rows;
}
function genHonorariosMedicosMock() {
  const rows = []; let seed = 11;
  MESES.forEach((mes) => {
    const esMesActual = mes === MESES[MESES.length - 1];
    const dias = esMesActual ? HOY.getDate() : DIAS_DEL_MES[mes.slice(5, 7)];
    for (let i = 0; i < 18; i++) {
      seed += 19;
      const dia = 1 + (seed % dias);
      const montoBruto = 900000 + (seed * 2917) % 2600000;
      rows.push({ fecha: `${mes}-${String(dia).padStart(2, '0')}`, montoBruto });
    }
  });
  return rows;
}
function genHonorariosExternosMock() {
  const rows = []; let seed = 23;
  MESES.forEach((mes) => {
    const esMesActual = mes === MESES[MESES.length - 1];
    const dias = esMesActual ? HOY.getDate() : DIAS_DEL_MES[mes.slice(5, 7)];
    for (let i = 0; i < 5; i++) {
      seed += 23;
      const dia = 1 + (seed % dias);
      const montoBruto = 700000 + (seed * 3301) % 3200000;
      const tipoProveedor = seed % 8 < 3 ? 'persona_natural' : 'empresa'; // proporción similar al archivo dueño
      rows.push({ fecha: `${mes}-${String(dia).padStart(2, '0')}`, montoBruto, tipoProveedor });
    }
  });
  return rows;
}

/* ------------------------------- átomos ---------------------------------- */
const Badge = ({ color, bg, icon: Icon, children }) => (
  <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, padding: '3px 9px', borderRadius: 999, fontSize: 12, fontWeight: 600, color, background: bg, whiteSpace: 'nowrap' }}>
    {Icon && <Icon size={12} />}{children}
  </span>
);
const Btn = ({ variant = 'ghost', icon: Icon, children, onClick, style, type = 'button' }) => {
  const variants = { primary: { background: C.pri, color: '#fff' }, outline: { background: '#fff', color: C.ink, border: `1px solid ${C.border}` }, ghost: { background: 'transparent', color: C.sub } };
  return (
    <button type={type} onClick={onClick}
      onMouseEnter={(e) => (e.currentTarget.style.filter = 'brightness(0.96)')} onMouseLeave={(e) => (e.currentTarget.style.filter = 'none')}
      style={{ display: 'inline-flex', alignItems: 'center', gap: 7, padding: '9px 15px', borderRadius: C.rSm, fontSize: 13.5, fontWeight: 600, cursor: 'pointer', border: '1px solid transparent', fontFamily: C.font, ...variants[variant], ...style }}>
      {Icon && <Icon size={15} />}{children}
    </button>
  );
};
const KPICard = ({ label, value, sub, icon: Icon, accent }) => (
  <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, padding: '16px 18px', boxShadow: C.shadow, flex: 1, minWidth: 0 }}>
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
      <span style={{ fontSize: 12.5, color: C.sub, fontWeight: 600 }}>{label}</span>
      <div style={{ width: 28, height: 28, borderRadius: 8, background: accent + '18', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon size={14} style={{ color: accent }} /></div>
    </div>
    <div style={{ fontSize: 22, fontWeight: 700, color: C.ink, letterSpacing: -0.3 }}>{value}</div>
    {sub && <div style={{ fontSize: 12, color: C.mut, marginTop: 3 }}>{sub}</div>}
  </div>
);
function BreakdownCard({ title, items, total }) {
  return (
    <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, padding: 18, boxShadow: C.shadow, flex: 1, minWidth: 0 }}>
      <div style={{ fontSize: 13, fontWeight: 700, color: C.ink, marginBottom: 14 }}>{title}</div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 11 }}>
        {items.map(([key, meta, monto]) => {
          const pct = total ? Math.round((monto / total) * 100) : 0;
          const Icon = meta.icon;
          return (
            <div key={key}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12.5, marginBottom: 4 }}>
                <span style={{ display: 'flex', alignItems: 'center', gap: 6, color: C.ink, fontWeight: 500 }}><Icon size={13} style={{ color: meta.color }} /> {meta.label}</span>
                <span style={{ color: C.sub, fontWeight: 600 }}>{clp(monto)} <span style={{ color: C.mut, fontWeight: 400 }}>({pct}%)</span></span>
              </div>
              <div style={{ height: 6, borderRadius: 4, background: C.bg, overflow: 'hidden' }}><div style={{ height: '100%', width: pct + '%', background: meta.color, borderRadius: 4 }} /></div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* --------------------------------- vista principal ------------------------------------ */
export default function ContabilidadObligacionesTributarias({ addToast }) {
  const toast = addToast || ((msg) => console.log(msg));
  const [regimenKey, setRegimenKey] = useState('regimen_14a');

  const ingresosRows = useMemo(genIngresosMock, []);
  const egresosRows = useMemo(genEgresosMock, []);
  const honMedicosRows = useMemo(genHonorariosMedicosMock, []);
  const honExternosRows = useMemo(genHonorariosExternosMock, []);

  // "Puerta etiquetada" principal de esta sección.
  const kpi = useMemo(
    () => calcularKPIsObligacionesTributarias(ingresosRows, egresosRows, honMedicosRows, honExternosRows, regimenKey),
    [ingresosRows, egresosRows, honMedicosRows, honExternosRows, regimenKey]
  );
  const regimen = REGIMENES[regimenKey];
  const diasHastaVencimiento = kpi.proximoVencimiento ? diffDays(HOY_ISO, kpi.proximoVencimiento.vencimiento) : null;

  const composicionF29Display = [
    ['iva', { label: 'IVA a pagar', color: C.err, icon: TrendingDown }, kpi.ivaAPagarTotal],
    ['ppm', { label: 'PPM', color: C.vio, icon: Percent }, kpi.ppmTotal],
    ['ret', { label: 'Retenciones', color: C.teal, icon: FileText }, kpi.retencionesTotal],
  ];
  const totalComposicion = kpi.ivaAPagarTotal + kpi.ppmTotal + kpi.retencionesTotal;

  const exportarCSV = () => {
    const header = ['Mes', 'Ingresos Brutos', 'IVA Débito', 'IVA Crédito', 'IVA a Pagar', 'Remanente Crédito Fiscal', 'PPM', 'Retenciones', 'Total F29', 'Vencimiento', 'Estado'];
    const lines = kpi.porMes.map((f) => [f.mes, f.ingresosBrutos, f.ivaDebito, f.ivaCreditoTotal, f.ivaAPagar, f.remanenteNuevo, f.ppm, f.retenciones, f.totalF29, f.vencimiento, ESTADOS_F29[f.estado].label].join(';'));
    const blob = new Blob([header.join(';') + '\n' + lines.join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = `obligaciones_tributarias_${MESES[0]}_a_${MESES[MESES.length - 1]}.csv`; a.click();
    URL.revokeObjectURL(url);
    toast('Archivo CSV descargado');
  };

  return (
    <div style={{ fontFamily: C.font, background: C.bg, minHeight: '100%', padding: 22 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 14, flexWrap: 'wrap', gap: 12 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
          <div style={{ width: 34, height: 34, borderRadius: 9, background: C.priL, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Receipt size={17} style={{ color: C.pri }} /></div>
          <div>
            <div style={{ fontSize: 18, fontWeight: 700, color: C.ink }}>Obligaciones Tributarias</div>
            <div style={{ fontSize: 12.5, color: C.mut }}>F29 mensual — compuesto desde Ingresos, Egresos y Honorarios</div>
          </div>
        </div>
        <div style={{ display: 'flex', gap: 9, alignItems: 'center' }}>
          <div style={{ display: 'flex', background: C.card, border: `1px solid ${C.border}`, borderRadius: C.rSm, padding: 3 }}>
            {Object.entries(REGIMENES).map(([k, v]) => (
              <button key={k} onClick={() => setRegimenKey(k)} style={{ padding: '6px 12px', borderRadius: 5, border: 'none', cursor: 'pointer', fontSize: 12, fontWeight: 600, background: regimenKey === k ? C.pri : 'transparent', color: regimenKey === k ? '#fff' : C.sub, whiteSpace: 'nowrap' }}>
                {v.label.split('·')[0].trim()}
              </button>
            ))}
          </div>
          <Btn variant="outline" icon={Download} onClick={exportarCSV}>Exportar CSV</Btn>
        </div>
      </div>

      <div style={{ display: 'flex', alignItems: 'flex-start', gap: 7, background: '#fff', border: `1px solid ${C.border}`, borderRadius: C.rSm, padding: '9px 13px', marginBottom: 18, fontSize: 12, color: C.sub, lineHeight: 1.6 }}>
        <Info size={13} style={{ color: C.vio, flexShrink: 0, marginTop: 1 }} />
        <span>
          Régimen activo: <b style={{ color: C.ink }}>{regimen.label}</b> — IDPC {(regimen.tasaIDPC * 100).toFixed(1)}% (anual, vía F22, fuera de este módulo) · PPM {(regimen.tasaPPM * 100).toFixed(1)}% ilustrativo. {regimen.nota}
          {' '}Interés por mora si no se declara/paga a tiempo: <b style={{ color: C.ink }}>{(TASA_INTERES_MORA.diaria * 100).toFixed(4)}% diario</b> ({(TASA_INTERES_MORA.anual * 100).toFixed(2)}% anual, {TASA_INTERES_MORA.fuente}) — la Ley 21.713 reemplazó el antiguo 1,5% mensual fijo por esta tasa variable, publicada por el SII cada semestre.
        </span>
      </div>

      <div style={{ fontSize: 11.5, fontWeight: 700, color: C.mut, textTransform: 'uppercase', letterSpacing: 0.4, marginBottom: 8 }}>F29 · {fmtMes(MESES[0])} a {fmtMes(MESES[MESES.length - 1])}</div>
      <div style={{ display: 'flex', gap: 14, marginBottom: 18, flexWrap: 'wrap' }}>
        <KPICard
          label="Próximo vencimiento F29"
          value={kpi.proximoVencimiento ? fmtDateLarga(kpi.proximoVencimiento.vencimiento) : 'Al día'}
          sub={kpi.proximoVencimiento ? `${fmtMes(kpi.proximoVencimiento.mes)} · en ${diasHastaVencimiento} días` : 'Sin declaraciones pendientes'}
          icon={Hourglass}
          accent={kpi.proximoVencimiento ? semaforo(diasHastaVencimiento, true, 10, 3) : C.pri}
        />
        <KPICard label="IVA a pagar (período)" value={clp(kpi.ivaAPagarTotal)} sub={`Débito ${clp(kpi.ivaDebitoTotal)} · Crédito ${clp(kpi.ivaCreditoTotal)}`} icon={TrendingDown} accent={C.err} />
        <KPICard label="Remanente de crédito fiscal" value={clp(kpi.remanenteVigente)} sub="Vigente, se arrastra al próximo mes" icon={RotateCcw} accent={kpi.remanenteVigente > 0 ? C.info : C.mut} />
      </div>
      <div style={{ display: 'flex', gap: 14, marginBottom: 18, flexWrap: 'wrap' }}>
        <KPICard label="PPM (período)" value={clp(kpi.ppmTotal)} sub={`${(regimen.tasaPPM * 100).toFixed(1)}% de ingresos brutos`} icon={Percent} accent={C.vio} />
        <KPICard label="Retenciones (período)" value={clp(kpi.retencionesTotal)} sub={`Honorarios Médicos + Externos, ${(TASA_RETENCION_HONORARIOS * 100).toFixed(2)}%`} icon={FileText} accent={C.teal} />
        <KPICard label="Total F29 (período)" value={clp(kpi.totalF29Periodo)} sub="IVA a pagar + PPM + Retenciones" icon={Receipt} accent={C.ink} />
      </div>

      <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, boxShadow: C.shadow, overflow: 'hidden', marginBottom: 18 }}>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
            <thead>
              <tr style={{ background: C.bg, textAlign: 'left' }}>
                {['Mes', 'Ingresos Brutos', 'IVA Débito', 'IVA Crédito', 'IVA a Pagar', 'PPM', 'Retenciones', 'Total F29', 'Vencimiento', 'Estado'].map((h) => (
                  <th key={h} style={{ padding: '10px 14px', fontSize: 11.5, fontWeight: 700, color: C.sub, textTransform: 'uppercase', letterSpacing: 0.3, whiteSpace: 'nowrap' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {kpi.porMes.map((f) => {
                const est = ESTADOS_F29[f.estado];
                return (
                  <tr key={f.mes} style={{ borderTop: `1px solid ${C.border}` }}>
                    <td style={{ padding: '11px 14px', color: C.ink, fontWeight: 600, whiteSpace: 'nowrap', textTransform: 'capitalize' }}>{fmtMes(f.mes)}</td>
                    <td style={{ padding: '11px 14px', color: C.sub, whiteSpace: 'nowrap' }}>{clp(f.ingresosBrutos)}</td>
                    <td style={{ padding: '11px 14px', color: C.sub, whiteSpace: 'nowrap' }}>{clp(f.ivaDebito)}</td>
                    <td style={{ padding: '11px 14px', color: C.sub, whiteSpace: 'nowrap' }}>{clp(f.ivaCreditoTotal)}</td>
                    <td style={{ padding: '11px 14px', fontWeight: 600, whiteSpace: 'nowrap', color: f.ivaAPagar > 0 ? C.err : C.mut }}>{f.ivaAPagar > 0 ? clp(f.ivaAPagar) : `Remanente ${clp(f.remanenteNuevo)}`}</td>
                    <td style={{ padding: '11px 14px', color: C.sub, whiteSpace: 'nowrap' }}>{clp(f.ppm)}</td>
                    <td style={{ padding: '11px 14px', color: C.sub, whiteSpace: 'nowrap' }}>{clp(f.retenciones)}</td>
                    <td style={{ padding: '11px 14px', fontWeight: 700, color: C.ink, whiteSpace: 'nowrap' }}>{clp(f.totalF29)}</td>
                    <td style={{ padding: '11px 14px', color: C.sub, whiteSpace: 'nowrap' }}>{fmtDateLarga(f.vencimiento)}</td>
                    <td style={{ padding: '11px 14px' }}><Badge color={est.color} bg={est.bg} icon={est.icon}>{est.label}</Badge></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      <div style={{ display: 'flex', gap: 14, marginBottom: 14, flexWrap: 'wrap' }}>
        <BreakdownCard title="Composición del Total F29 (período)" items={composicionF29Display} total={totalComposicion} />
        <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, padding: 18, boxShadow: C.shadow, flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 13, fontWeight: 700, color: C.ink, marginBottom: 10 }}>Contexto legal</div>
          <div style={{ fontSize: 12, color: C.sub, lineHeight: 1.7 }}>
            <b style={{ color: C.ink }}>RCV (Registro de Compras y Ventas)</b> — reemplazó los libros físicos desde 2017; es la base electrónica sobre la que el SII arma la propuesta de F29. En AXON, Ingresos + Egresos + Honorarios cumplen ese mismo rol.<br /><br />
            <b style={{ color: C.ink }}>Art. 85 bis Código Tributario</b> — 50 abonos de RUTs distintos en un día/semana/mes (o 100 en un semestre) activan reporte bancario automático al SII. Mencionado como contexto: aplica a comercio informal, no a una entidad ya formalizada como esta.
          </div>
        </div>
      </div>
    </div>
  );
}
