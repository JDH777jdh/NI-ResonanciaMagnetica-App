import React, { useState, useMemo } from 'react';
import {
  ShoppingCart, Search, Download, Plus, X, Eye, RotateCcw, CheckCircle2,
  Clock, Ban, Info, Send, PackageCheck, AlertTriangle, FileText, Landmark,
  Hourglass, Package, Activity, Sofa, Laptop, Wrench, Stethoscope, BedDouble,
  Scissors, ScanLine, FlaskConical, Video, Pill, Archive, ClipboardList, BellRing,
  UserCog, Mail, Paperclip, History
} from 'lucide-react';

/* Roles reales copiados desde roles.config.js (Nivel 3 · TENANT_ROLES),
   categorías "contabilidad" y "alta_direccion" — reemplaza al viejo
   { contador, admin_clinica, master } que quedó obsoleto: esos 3 IDs ya
   no existen. La cadena de aprobación real cruza dos categorías: el día
   a día lo maneja Contabilidad, la escalada la resuelve Alta Dirección
   (no existe un techo "master" a nivel de tenant — el techo real es
   Gerente General; por encima de eso ya es axon_owner, personal de AXON,
   no de la clínica, así que no aplica acá).
   Al integrar: borrar este bloque, importar { TENANT_ROLES, findRole }
   desde "../config/roles.config.js". */
const ROLES_FINANCIEROS = {
  t_cont_contador: { label: 'Contador', color: '#2E7D32' },
  t_cont_supervisor: { label: 'Supervisor de Contabilidad', color: '#2E7D32' },
  t_dir_gerente_contabilidad: { label: 'Gerente Contabilidad', color: '#0D47A1' },
  t_dir_gerente_finanzas: { label: 'Gerente Finanzas', color: '#0D47A1' },
  t_dir_gerente_general: { label: 'Gerente General', color: '#0D47A1' },
};

/* =========================================================================
   DISEÑO — copiado 1:1 desde HISClinico_Layer1.jsx / demás secciones de
   Contabilidad, para que este archivo se pueda previsualizar de forma
   independiente.
   ========================================================================= */
const C = {
  bg: '#F4F6F9', card: '#FFFFFF', border: '#E2E8F0', borderD: '#CBD5E1',
  ink: '#16233E', sub: '#5B6B85', mut: '#94A3B8',
  pri: '#2E7D32', priL: '#EAF6EC',
  info: '#2563EB', infoL: '#EEF3FF',
  warn: '#B45309', warnL: '#FEF3E2',
  err: '#C62828', errL: '#FDECEC',
  vio: '#6D28D9', vioL: '#F2ECFB',
  teal: '#0E7490', tealL: '#E3F6FA',
  r: 10, rSm: 7, rLg: 14,
  shadow: '0 1px 3px rgba(16,24,40,.06), 0 1px 2px rgba(16,24,40,.04)',
  font: "'Inter', -apple-system, 'Segoe UI', Roboto, sans-serif",
};

/* Valor referencial de la UTM — cambia CADA MES (a diferencia de la retención,
   que cambia una vez al año). Verificar el valor vigente en sii.cl antes de
   usarlo para decidir montos reales. Se deja como parámetro único, no repetido. */
const UTM_VALOR_REFERENCIA = 68000;

const CATEGORIAS = {
  insumos_clinicos: { label: 'Insumos Clínicos y Farmacia', color: '#BE185D', icon: Package },
  equipamiento_medico: { label: 'Equipamiento Médico', color: '#6D28D9', icon: Activity },
  mobiliario: { label: 'Mobiliario e Infraestructura', color: '#6D4C41', icon: Sofa },
  tecnologia: { label: 'Tecnología y Equipos TI', color: '#37474F', icon: Laptop },
  servicios_generales: { label: 'Servicios Generales', color: '#B45309', icon: Wrench },
};

/* Quién puede originar una requisición. Dos flujos reales distintos:
   - Farmacia/Bodega: piden cuando SU PROPIO stock interno baja del mínimo
     (reabastecimiento) — el resto del hospital les pide a ELLOS primero,
     ese movimiento interno no pasa por Adquisiciones.
   - Cualquier otra unidad: pide directo cuando es equipamiento/servicio
     que no es un ítem de stock (no hay inventario que gestionar en el medio). */
const UNIDADES_SOLICITANTES = {
  farmacia: { label: 'Farmacia', icon: Pill, color: '#BE185D' },
  bodega: { label: 'Bodega Central', icon: Archive, color: '#6D4C41' },
  urgencias: { label: 'Urgencias', icon: Stethoscope, color: '#C62828' },
  hospitalizacion: { label: 'Hospitalización', icon: BedDouble, color: '#2563EB' },
  pabellon: { label: 'Pabellón / Cirugías', icon: Scissors, color: '#6D28D9' },
  imagenologia: { label: 'Imagenología', icon: ScanLine, color: '#0E7490' },
  laboratorio: { label: 'Laboratorio', icon: FlaskConical, color: '#B45309' },
  telemedicina: { label: 'Telemedicina', icon: Video, color: '#2E7D32' },
  ti: { label: 'Tecnología de la Información', icon: Laptop, color: '#37474F' },
  administracion: { label: 'Administración General', icon: ClipboardList, color: '#455A64' },
};

/* Modalidad de compra — solo relevante si el tenant es organismo público
   (Ley 19.886). Si es privado, siempre es "Compra Privada" (compra
   comercial normal, sin ChileCompra). Ojo: que un hospital privado atienda
   pacientes Fonasa vía convenio NO lo convierte en organismo de compras
   públicas — esa es una cuenta de Ingresos, no de Adquisiciones. */
const MODALIDADES_PUBLICAS = {
  convenio_marco: { label: 'Convenio Marco', color: '#2563EB' },
  licitacion_publica: { label: 'Licitación Pública', color: '#6D28D9' },
  licitacion_privada: { label: 'Licitación Privada', color: '#0E7490' },
  trato_directo: { label: 'Trato Directo', color: '#B45309' },
  compra_agil: { label: 'Compra Ágil', color: '#2E7D32' },
  otro_mecanismo: { label: 'Otro mecanismo especial', color: '#94A3B8' },
};
const MODALIDAD_PRIVADA = { label: 'Compra Privada', color: '#455A64' };

const ESTADOS = {
  requisicion: { label: 'Requisición (sin OC)', color: '#6D28D9', bg: '#F2ECFB', icon: ClipboardList },
  solicitada: { label: 'Solicitada', color: '#B45309', bg: '#FEF3E2', icon: Clock },
  aprobada: { label: 'Aprobada', color: '#2563EB', bg: '#EEF3FF', icon: CheckCircle2 },
  enviada: { label: 'Enviada a proveedor', color: '#0E7490', bg: '#E3F6FA', icon: Send },
  recibida_conforme: { label: 'Recibida conforme', color: '#2E7D32', bg: '#EAF6EC', icon: PackageCheck },
  recibida_con_observaciones: { label: 'Recibida con observaciones', color: '#B45309', bg: '#FEF3E2', icon: AlertTriangle },
  factura_retenida: { label: 'Factura retenida — no calza', color: '#C62828', bg: '#FDECEC', icon: AlertTriangle },
  facturada: { label: 'Facturada', color: '#6D28D9', bg: '#F2ECFB', icon: FileText },
  rechazada: { label: 'Rechazada', color: '#94A3B8', bg: '#F1F5F9', icon: Ban },
};

/* Sugerencia de modalidad según monto — informativa, no reemplaza el criterio
   del área de abastecimiento. Basado en Ley 19.886 y su reglamento:
   Convenio Marco es SIEMPRE la primera consulta obligatoria sobre 100 UTM;
   Compra Ágil es solo hasta 100 UTM; Trato Directo y Licitación Privada
   requieren causal justificada, no dependen solo del monto. */
function sugerenciaModalidad(montoTotal) {
  const enUTM = montoTotal / UTM_VALOR_REFERENCIA;
  if (enUTM <= 100) return `≈${enUTM.toFixed(1)} UTM — revisa primero Convenio Marco; si no está disponible, Compra Ágil es válida (mín. 3 cotizaciones)`;
  return `≈${enUTM.toFixed(1)} UTM — sobre 100 UTM: consulta Convenio Marco primero; si no aplica, corresponde Licitación Pública`;
}

/* ---------------------------- formatters -------------------------------- */
const clp = (n) => '$' + Math.round(n).toLocaleString('es-CL');
const fmtDate = (iso) =>
  new Date(iso + 'T00:00:00').toLocaleDateString('es-CL', { day: '2-digit', month: 'short', year: 'numeric' });
const addDays = (iso, n) => {
  const d = new Date(iso + 'T00:00:00');
  d.setDate(d.getDate() + n);
  return d.toISOString().slice(0, 10);
};
const diffDays = (isoA, isoB) => Math.round((new Date(isoB + 'T00:00:00') - new Date(isoA + 'T00:00:00')) / 86400000);
// CORREGIDO: el plazo de Acuse de Recibo es de 8 DÍAS CORRIDOS, no hábiles —
// confirmado directo en sii.cl (Ley 19.983 mod. Ley 20.956): "si el documento es
// recibido en el SII el día 01 de enero, el plazo de los 8 días finaliza el 09 de
// enero" — cuenta calendario simple, sin saltar fines de semana.
function addDiasCorridos(iso, n) { return addDays(iso, n); }
// Ver ContabilidadHelpersCompartidos.js — versión canónica verificada de semaforo() (idéntica).
function semaforo(valor, metaEsMinimo, umbralBueno, umbralMalo) {
  const esBueno = metaEsMinimo ? valor >= umbralBueno : valor <= umbralBueno;
  const esMalo = metaEsMinimo ? valor < umbralMalo : valor > umbralMalo;
  if (esBueno) return C.pri;
  if (esMalo) return C.err;
  return C.warn;
}

/* ═══════════════════════════════════════════════════════════════════════
   PUERTA ETIQUETADA — calcularKPIsAdquisiciones
   ═══════════════════════════════════════════════════════════════════════ */
export function calcularKPIsAdquisiciones(rows) {
  const sum = (pred) => rows.filter(pred).reduce((s, r) => s + r.montoTotal, 0);

  const totalOC = rows.reduce((s, r) => s + r.montoTotal, 0);
  const requisiciones = rows.filter((r) => r.estado === 'requisicion');
  const pendientesRecepcion = rows.filter((r) => ['solicitada', 'aprobada', 'enviada'].includes(r.estado));
  const montoPendienteRecepcion = pendientesRecepcion.reduce((s, r) => s + r.montoTotal, 0);
  const conObservaciones = rows.filter((r) => r.estado === 'recibida_con_observaciones').length;
  const rowsConOC = rows.filter((r) => r.estado !== 'requisicion');
  const pctConObservaciones = rowsConOC.length ? Math.round((conObservaciones / rowsConOC.length) * 100) : 0;

  const cerradas = rows.filter((r) => r.fechaRecepcion);
  const leadTimePromedio = cerradas.length
    ? Math.round((cerradas.reduce((s, r) => s + diffDays(r.fecha, r.fechaRecepcion), 0) / cerradas.length) * 10) / 10
    : 0;

  const conModalidad = rowsConOC.filter((r) => r.modalidad !== 'compra_privada');
  const viaConvenioMarco = conModalidad.filter((r) => r.modalidad === 'convenio_marco').reduce((s, r) => s + r.montoTotal, 0);
  const pctConvenioMarco = conModalidad.length ? Math.round((viaConvenioMarco / conModalidad.reduce((s, r) => s + r.montoTotal, 0)) * 100) : 0;

  const porProveedor = {};
  rowsConOC.forEach((r) => { porProveedor[r.proveedor] = (porProveedor[r.proveedor] || 0) + r.montoTotal; });
  const ordenados = Object.entries(porProveedor).sort((a, b) => b[1] - a[1]);
  const concentracionTop = totalOC ? Math.round(((ordenados[0]?.[1] || 0) / totalOC) * 100) : 0;

  // Validación de 3 vías: cantidad pedida vs. recibida, solo donde ya hubo recepción.
  const conRecepcion = rows.filter((r) => r.cantidadRecibida != null);
  const conDiscrepancia = conRecepcion.filter((r) => r.cantidadRecibida !== r.cantidad).length;
  const pct3ViasOk = conRecepcion.length ? Math.round(((conRecepcion.length - conDiscrepancia) / conRecepcion.length) * 100) : 100;

  // Acuse de Recibo: pendiente de dar, y cuántos están a 2 días o menos del vencimiento (riesgo de aceptación irrevocable).
  const facturadasSinAcuse = rows.filter((r) => r.acuseRecibo && !r.acuseRecibo.dado);
  const acusesPorVencer = facturadasSinAcuse.filter((r) => diffDays(HOY_ADQ.toISOString().slice(0, 10), r.acuseRecibo.fechaLimite) <= 2).length;

  // Facturas retenidas: monto facturado no calza con la OC, aún sin resolver.
  const facturasRetenidas = rows.filter((r) => r.estado === 'factura_retenida');
  const montoRetenido = facturasRetenidas.reduce((s, r) => s + (r.montoFacturado || r.montoTotal), 0);

  const porCategoria = Object.keys(CATEGORIAS).map((id) => ({ id, monto: sum((r) => r.categoria === id) })).sort((a, b) => b.monto - a.monto);

  return {
    seccion: 'adquisiciones', ordenes: rows.length,
    totalOC, montoPendienteRecepcion, pendientesCount: pendientesRecepcion.length,
    pctConObservaciones, leadTimePromedio, pctConvenioMarco, concentracionTop,
    requisicionesPendientes: requisiciones.length, pct3ViasOk, acusesPendientes: facturadasSinAcuse.length, acusesPorVencer,
    facturasRetenidasCount: facturasRetenidas.length, montoRetenido,
    porCategoria,
  };
}

/* ═══════════════════════════════════════════════════════════════════════
   PUERTA ETIQUETADA — recibirRequisicion
   Este es el punto de entrada para cuando Farmacia, Bodega o cualquier
   unidad construya su propia interfaz y necesite generar una solicitud de
   compra desde ahí. Por ahora la usamos internamente (botón "Nueva
   requisición"), pero la firma ya está lista para que otro módulo la
   llame directamente sin que Adquisiciones tenga que cambiar.

   Forma esperada de entrada:
   { unidadSolicitante: 'farmacia'|'bodega'|'urgencias'|... (ver UNIDADES_SOLICITANTES),
     solicitante: 'Nombre de quien pide',
     categoria: 'insumos_clinicos'|'equipamiento_medico'|'mobiliario'|'tecnologia'|'servicios_generales',
     descripcion: string, cantidad: number, urgente: boolean (opcional),
     proveedorSugerido: string (opcional) — quien pide puede proponer proveedor,
       pero Contabilidad/Adquisiciones decide el proveedor final al convertir a OC. }
   ═══════════════════════════════════════════════════════════════════════ */

/* ═══════════════════════════════════════════════════════════════════════
   FASE 8 DEL PLAN DE TRABAJO (2026-09-09) — Procurement + corte real
   Ejecuta el corte Supply Core/AIMS/Account Core aprobado hace semanas
   (ver AXON_Nota_Contabilidad_para_FarmaciaBodega_Supply_Core_AIMS.md).
   No se elimina nada — Adquisiciones sigue funcionando idéntico hoy,
   porque Supply Core y AIMS todavía no existen como módulos reales. Lo
   que se agrega es la frontera explícita: qué le correspondería a cada
   dominio el día que existan, y los eventos de traspaso (`PurchaseOrder-
   Approved`, `GoodsReceived`) ya con la forma que usarán cuando eso pase.
   ═══════════════════════════════════════════════════════════════════════ */

// Mapeo aprobado: insumos_clinicos → Supply Core (evolución Farmacia/Bodega);
// equipamiento_medico/mobiliario/tecnologia → AIMS (activos de capital, no
// stock consumible); servicios_generales → Account Core completo (sin
// evento de recepción posible, una mantención no se "recibe" como un bien).
const DOMINIO_POR_CATEGORIA = {
  insumos_clinicos: 'SUPPLY_CORE',
  equipamiento_medico: 'AIMS',
  mobiliario: 'AIMS',
  tecnologia: 'AIMS',
  servicios_generales: 'ACCOUNT_CORE',
};

/** A quién le correspondería la verdad material de esta categoría — Adquisiciones sigue siendo dueña de la verdad financiera en los 3 casos. */
export function resolverDominioResponsable(categoria) {
  return DOMINIO_POR_CATEGORIA[categoria] || 'ACCOUNT_CORE';
}

/**
 * 3-way match formalizado — compara las 3 fuentes reales (Orden de Compra,
 * Recepción, Factura) en cantidad Y monto, no solo cantidad como hacía la
 * derivación inline original (`hay3Vias`/`discrepancia3Vias` en el render
 * siguen funcionando igual, esta función es la versión reutilizable).
 */
export function evaluarTresVias(row) {
  const tieneRecepcion = row.cantidadRecibida != null;
  const tieneFactura = row.montoFacturado != null;
  const cantidadCalza = !tieneRecepcion || row.cantidadRecibida === row.cantidad;
  const montoCalza = !tieneFactura || row.montoFacturado === row.montoTotal;
  return {
    ordenCompra: { cantidad: row.cantidad, monto: row.montoTotal },
    recepcion: tieneRecepcion ? { cantidad: row.cantidadRecibida } : null,
    factura: tieneFactura ? { monto: row.montoFacturado } : null,
    cantidadCalza,
    montoCalza,
    pasa3Vias: tieneRecepcion && tieneFactura && cantidadCalza && montoCalza,
    requiereRevision: (tieneRecepcion && !cantidadCalza) || (tieneFactura && !montoCalza),
  };
}

/**
 * Procurement Commitment — el compromiso presupuestario nace al aprobar
 * (no al recibir ni al pagar). Separado de Devengo (recepción conforme +
 * factura) y de Pago. Crítico para tenants públicos, donde comprometer,
 * devengar y pagar son 3 momentos legalmente distintos.
 */
export function crearCommitment(row, aprobadoPor) {
  return {
    commitmentId: `cmt_${row.id}`,
    ocId: row.id,
    montoComprometido: row.montoTotal,
    categoria: row.categoria,
    dominioResponsable: resolverDominioResponsable(row.categoria),
    aprobadoPor,
    estado: 'COMPROMETIDO', // COMPROMETIDO → DEVENGADO (al recibir conforme + facturar) → PAGADO
  };
}

/** El compromiso se devenga cuando hay recepción conforme Y factura que calza — nunca antes. */
export function devengarCommitment(commitment, tresVias) {
  if (!tresVias.pasa3Vias) {
    return { error: 'No se puede devengar sin pasar las 3 vías', commitment };
  }
  return { commitment: { ...commitment, estado: 'DEVENGADO' }, error: null };
}

/**
 * Evento de traspaso — el día que Supply Core exista, esto es lo que
 * emitiría hacia Account Core al aprobar una OC. Hoy Adquisiciones lo
 * genera internamente porque Supply Core no existe, pero la forma ya es
 * la del contrato real (mismo nombre de evento que
 * AXON_Contabilidad_Documento_Maestro_Arquitectura_y_Orquestacion.docx §12).
 */
export function emitirPurchaseOrderApproved(row, aprobadoPor) {
  return {
    eventType: 'PurchaseOrderApproved',
    ocId: row.id,
    categoria: row.categoria,
    dominioOrigen: resolverDominioResponsable(row.categoria),
    montoComprometido: row.montoTotal,
    aprobadoPor,
    fecha: row.fechaAprobacion || null,
  };
}

/** Idem — evento de recepción, mismo principio, mismo nombre de evento ya establecido. */
export function emitirGoodsReceived(row) {
  if (row.cantidadRecibida == null) return null; // todavía no hay recepción que emitir
  return {
    eventType: 'GoodsReceived',
    ocId: row.id,
    categoria: row.categoria,
    dominioOrigen: resolverDominioResponsable(row.categoria),
    cantidadRecibida: row.cantidadRecibida,
    conforme: row.cantidadRecibida === row.cantidad,
    fecha: row.fechaRecepcion || null,
  };
}

export function recibirRequisicion({ unidadSolicitante, solicitante, categoria, descripcion, cantidad, urgente = false, proveedorSugerido = null }, idBase = Date.now()) {
  return {
    id: 'oc_' + idBase,
    numeroOC: null, // aún no es una OC formal — se le asigna al convertir
    fecha: new Date().toISOString().slice(0, 10),
    fechaAprobacion: null, fechaEnvio: null, fechaRecepcion: null,
    unidadSolicitante, solicitante, urgente, proveedorSugerido,
    proveedor: null, categoria, descripcion, cantidad, precioUnitario: null, montoTotal: 0,
    cantidadRecibida: null,
    centroCosto: unidadSolicitante,
    modalidad: 'compra_privada', idChileCompra: null,
    cotizaciones: [],
    acuseRecibo: null,
    historial: [{ estado: 'requisicion', fecha: new Date().toISOString().slice(0, 10), actorRole: null }],
    estado: 'requisicion',
  };
}

/* ------------------------------ mock data -------------------------------- */
const PROVEEDORES_POR_CAT = {
  insumos_clinicos: ['Farmadistribución Andina S.A.', 'Suministros Médicos del Pacífico Ltda.'],
  equipamiento_medico: ['TecnoMed Equipos e Insumos Ltda.', 'Ingeniería Biomédica del Sur SpA'],
  mobiliario: ['Mobiliario Hospitalario Chile SpA'],
  tecnologia: ['Soluciones TI Corporativas SpA'],
  servicios_generales: ['Mantención Industrial RM SpA'],
};
const ITEMS_POR_CAT = {
  insumos_clinicos: [['Guantes de nitrilo, caja x100', 8500], ['Jeringas desechables 10ml, caja x100', 22000], ['Mascarillas quirúrgicas, caja x50', 12000]],
  equipamiento_medico: [['Monitor de signos vitales', 1850000], ['Bomba de infusión', 980000], ['Desfibrilador portátil', 3400000]],
  mobiliario: [['Cama clínica eléctrica', 1250000], ['Silla de ruedas estándar', 180000]],
  tecnologia: [['Notebook para estación clínica', 620000], ['Switch de red 24 puertos', 340000]],
  servicios_generales: [['Mantención anual de climatización', 2800000], ['Servicio de fumigación trimestral', 450000]],
};
const CATEGORIA_KEYS = Object.keys(CATEGORIAS);
const MODALIDAD_KEYS_PUBLICAS = Object.keys(MODALIDADES_PUBLICAS);

const HOY_ADQ = new Date('2026-07-05T00:00:00');
function mesesDelAnioHasta(hoy) {
  const anio = hoy.getFullYear(), mesActual = hoy.getMonth(), meses = [];
  for (let m = 0; m <= mesActual; m++) meses.push(`${anio}-${String(m + 1).padStart(2, '0')}`);
  return meses;
}
const MESES_ADQ = mesesDelAnioHasta(HOY_ADQ);
const HOY_ISO_ADQ = HOY_ADQ.toISOString().slice(0, 10);
const DIAS_DEL_MES_ADQ = { '01': 31, '02': 28, '03': 31, '04': 30, '05': 31, '06': 30, '07': 31, '08': 31, '09': 30, '10': 31, '11': 30, '12': 31 };
const ESTADO_POOL = ['recibida_conforme', 'recibida_conforme', 'facturada', 'aprobada', 'enviada', 'solicitada', 'recibida_con_observaciones', 'rechazada'];
const ESTADO_POOL_HISTORICO = ['facturada', 'facturada', 'facturada', 'recibida_conforme', 'rechazada'];

const OTROS_PROVEEDORES = ['Insumos y Equipos Australes SpA', 'Comercial Andina de Salud Ltda.', 'Grupo Proveedor Nacional S.A.', 'Distribuidora Regional Ltda.'];
function generarCotizaciones(proveedorGanador, montoGanador, seed, categoria) {
  const competidores = [0, 1].map((i) => {
    const variacion = 1 + (((seed * (7 + i)) % 25) + 3) / 100; // 3% a 28% más caro que el ganador
    return {
      proveedor: OTROS_PROVEEDORES[(seed + i) % OTROS_PROVEEDORES.length],
      monto: Math.round((montoGanador * variacion) / 100) * 100,
      fecha: null,
      seleccionada: false,
    };
  });
  const ganadora = { proveedor: proveedorGanador, monto: montoGanador, fecha: null, seleccionada: true };
  return [ganadora, ...competidores].sort((a, b) => a.monto - b.monto);
}

function genMock(esPublico) {
  const rows = [];
  let seed = 11;
  const REGISTROS_POR_MES = 6;
  MESES_ADQ.forEach((mesStr, mesIdx) => {
    const esMesActual = mesIdx === MESES_ADQ.length - 1;
    const diasEnMes = esMesActual ? HOY_ADQ.getDate() : DIAS_DEL_MES_ADQ[mesStr.slice(5, 7)];
    for (let i = 0; i < REGISTROS_POR_MES; i++) {
      seed += 29;
      const categoria = CATEGORIA_KEYS[seed % CATEGORIA_KEYS.length];
      const proveedor = PROVEEDORES_POR_CAT[categoria][seed % PROVEEDORES_POR_CAT[categoria].length];
      const [descripcion, precioUnitario] = ITEMS_POR_CAT[categoria][(seed * 3) % ITEMS_POR_CAT[categoria].length];
      const cantidad = categoria === 'insumos_clinicos' ? 5 + (seed % 40) : 1 + (seed % 4);
      const montoTotal = Math.round((precioUnitario * cantidad) / 100) * 100;
      const modalidad = esPublico
        ? (montoTotal / UTM_VALOR_REFERENCIA <= 100 ? (seed % 3 === 0 ? 'compra_agil' : 'convenio_marco') : MODALIDAD_KEYS_PUBLICAS[seed % MODALIDAD_KEYS_PUBLICAS.length])
        : 'compra_privada';
      const idChileCompra = esPublico && modalidad !== 'compra_privada' ? `${2200 + (seed % 700)}-${(seed % 90) + 1}-${modalidad === 'compra_agil' ? 'CO' : 'LE'}26` : null;
      const dia = 1 + (seed % diasEnMes);
      const fecha = `${mesStr}-${String(dia).padStart(2, '0')}`;
      const pool = esMesActual ? ESTADO_POOL : ESTADO_POOL_HISTORICO;
      let estado = pool[seed % pool.length];
      const diasAprobacion = 1 + (seed % 4);
      const diasEnvio = diasAprobacion + 1 + (seed % 3);
      const diasRecepcion = diasEnvio + 3 + (seed % 12);
      const huboRecepcion = !['solicitada', 'aprobada', 'enviada'].includes(estado);
      // 3 vías: la mayoría calza exacto; ~1 de cada 6 recepciones tiene una diferencia real (para poder mostrar la alerta).
      const cantidadRecibida = huboRecepcion ? (seed % 6 === 0 ? cantidad - (1 + (seed % 3)) : cantidad) : null;
      const OBSERVACIONES_EJEMPLO = ['Llegaron ' + (cantidad - 1) + ' de ' + cantidad + ' unidades pedidas, falta 1.', 'Dos unidades llegaron con el embalaje dañado.', 'El proveedor envió un modelo distinto al cotizado.', 'Llegó incompleto, falta la mitad del pedido.'];
      const observaciones = estado === 'recibida_con_observaciones' ? OBSERVACIONES_EJEMPLO[seed % OBSERVACIONES_EJEMPLO.length] : null;
      const fechaFactura = estado === 'facturada' ? addDays(fecha, diasRecepcion + 1 + (seed % 3)) : null;
      // La discrepancia de monto solo se simula en el mes en curso (para tener un caso vivo que
      // se pueda resolver en pantalla) — en meses ya cerrados, lo facturado siempre calza con la
      // OC, porque en la realidad ya se habría resuelto antes de llegar a este punto.
      const hayDiscrepancia = esMesActual && fechaFactura && seed % 9 === 0;
      if (hayDiscrepancia) estado = 'factura_retenida';
      const fechaLimiteAcuse = fechaFactura ? addDiasCorridos(fechaFactura, 8) : null;
      const yaDioAcuse = fechaFactura ? seed % 3 !== 0 : false; // ~2 de cada 3 ya con acuse dado
      const montoFacturado = fechaFactura ? (hayDiscrepancia ? montoTotal + 5000 * (1 + (seed % 4)) : montoTotal) : null;
      const solicitanteUnidad = Object.keys(UNIDADES_SOLICITANTES)[seed % Object.keys(UNIDADES_SOLICITANTES).length];
      const necesitaCotizaciones = modalidad === 'compra_agil' || (modalidad === 'compra_privada' && montoTotal > 500000);
      const historialSimulado = [{ estado: 'solicitada', fecha, actorRole: 't_cont_contador' }];
      if (estado !== 'solicitada') historialSimulado.push({ estado: 'aprobada', fecha: addDays(fecha, diasAprobacion), actorRole: seed % 2 === 0 ? 't_dir_gerente_contabilidad' : 't_cont_contador' });
      rows.push({
        id: 'oc_' + (1000 + rows.length),
        numeroOC: 'OC-' + (4200 + rows.length),
        fecha,
        fechaAprobacion: estado !== 'solicitada' ? addDays(fecha, diasAprobacion) : null,
        fechaEnvio: ['enviada', 'recibida_conforme', 'recibida_con_observaciones', 'facturada'].includes(estado) ? addDays(fecha, diasEnvio) : null,
        fechaRecepcion: huboRecepcion ? addDays(fecha, diasRecepcion) : null,
        unidadSolicitante: solicitanteUnidad, solicitante: null, urgente: false,
        proveedor, categoria, descripcion, cantidad, cantidadRecibida, precioUnitario, montoTotal,
        centroCosto: categoria === 'servicios_generales' ? 'mantencion' : categoria === 'tecnologia' ? 'ti' : 'administracion',
        modalidad, idChileCompra,
        cotizaciones: necesitaCotizaciones ? generarCotizaciones(proveedor, montoTotal, seed, categoria) : [],
        observaciones, facturaFolio: fechaFactura ? String(78000 + rows.length) : null, montoFacturado,
        tipoNotaSolicitada: null, fechaSolicitudNota: null, notasRecibidas: [], justificacionAjuste: null, montoAprobadoFinal: null,
        acuseRecibo: fechaFactura ? { dado: yaDioAcuse, fecha: yaDioAcuse ? addDays(fechaFactura, 1 + (seed % 5)) : null, fechaLimite: fechaLimiteAcuse } : null,
        historial: historialSimulado,
        estado,
      });
    }
  });
  // Un puñado de requisiciones pendientes de convertir a OC — solo del mes en curso, todavía sin proveedor ni precio.
  const REQUISICIONES_PENDIENTES = [
    { unidadSolicitante: 'farmacia', solicitante: 'Enf. Josefa Muñoz', categoria: 'insumos_clinicos', descripcion: 'Paracetamol 500mg, caja x1000', cantidad: 15, urgente: true, proveedorSugerido: 'Farmadistribución Andina S.A.' },
    { unidadSolicitante: 'bodega', solicitante: 'Sr. Manuel Torres', categoria: 'insumos_clinicos', descripcion: 'Alcohol gel 1L', cantidad: 40, urgente: false, proveedorSugerido: 'Suministros Médicos del Pacífico Ltda.' },
    { unidadSolicitante: 'pabellon', solicitante: 'Dr. Cristián Aguilera', categoria: 'equipamiento_medico', descripcion: 'Bisturí eléctrico', cantidad: 1, urgente: true, proveedorSugerido: null },
    { unidadSolicitante: 'ti', solicitante: 'Srta. Daniela Rojas', categoria: 'tecnologia', descripcion: 'Licencias antivirus corporativo', cantidad: 25, urgente: false, proveedorSugerido: 'Soluciones TI Corporativas SpA' },
  ];
  REQUISICIONES_PENDIENTES.forEach((req, i) => {
    const r = recibirRequisicion(req, 9500 + i);
    r.fecha = addDays(HOY_ISO_ADQ, -(1 + i));
    rows.unshift(r);
  });
  return rows.sort((a, b) => (a.fecha < b.fecha ? 1 : -1));
}

/* ------------------------------- átomos ---------------------------------- */
const Badge = ({ color, bg, icon: Icon, children }) => (
  <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, padding: '3px 9px', borderRadius: 999, fontSize: 12, fontWeight: 600, color, background: bg, whiteSpace: 'nowrap' }}>
    {Icon && <Icon size={12} />}{children}
  </span>
);
const Btn = ({ variant = 'ghost', icon: Icon, children, onClick, style, type = 'button' }) => {
  const variants = { primary: { background: C.pri, color: '#fff' }, outline: { background: '#fff', color: C.ink, border: `1px solid ${C.border}` }, ghost: { background: 'transparent', color: C.sub } };
  return (
    <button type={type} onClick={onClick}
      onMouseEnter={(e) => (e.currentTarget.style.filter = 'brightness(0.96)')} onMouseLeave={(e) => (e.currentTarget.style.filter = 'none')}
      style={{ display: 'inline-flex', alignItems: 'center', gap: 7, padding: '9px 15px', borderRadius: C.rSm, fontSize: 13.5, fontWeight: 600, cursor: 'pointer', border: '1px solid transparent', fontFamily: C.font, ...variants[variant], ...style }}>
      {Icon && <Icon size={15} />}{children}
    </button>
  );
};
const KPICard = ({ label, value, sub, icon: Icon, accent }) => (
  <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, padding: '16px 18px', boxShadow: C.shadow, flex: 1, minWidth: 0 }}>
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
      <span style={{ fontSize: 12.5, color: C.sub, fontWeight: 600 }}>{label}</span>
      <div style={{ width: 28, height: 28, borderRadius: 8, background: accent + '18', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon size={14} style={{ color: accent }} /></div>
    </div>
    <div style={{ fontSize: 22, fontWeight: 700, color: C.ink, letterSpacing: -0.3 }}>{value}</div>
    {sub && <div style={{ fontSize: 12, color: C.mut, marginTop: 3 }}>{sub}</div>}
  </div>
);
const FieldLabel = ({ children }) => <label style={{ fontSize: 11.5, fontWeight: 600, color: C.sub, marginBottom: 5, display: 'block' }}>{children}</label>;
const inputStyle = { width: '100%', padding: '8px 10px', borderRadius: C.rSm, border: `1px solid ${C.border}`, fontSize: 13.5, fontFamily: C.font, color: C.ink, outline: 'none', boxSizing: 'border-box', background: '#fff' };

function BreakdownCard({ title, items, total }) {
  return (
    <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, padding: 18, boxShadow: C.shadow, flex: 1, minWidth: 0 }}>
      <div style={{ fontSize: 13, fontWeight: 700, color: C.ink, marginBottom: 14 }}>{title}</div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 11 }}>
        {items.map(([key, meta, monto]) => {
          const pct = total ? Math.round((monto / total) * 100) : 0;
          const Icon = meta.icon || Package;
          return (
            <div key={key}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12.5, marginBottom: 4 }}>
                <span style={{ display: 'flex', alignItems: 'center', gap: 6, color: C.ink, fontWeight: 500 }}><Icon size={13} style={{ color: meta.color }} /> {meta.label}</span>
                <span style={{ color: C.sub, fontWeight: 600 }}>{clp(monto)} <span style={{ color: C.mut, fontWeight: 400 }}>({pct}%)</span></span>
              </div>
              <div style={{ height: 6, borderRadius: 4, background: C.bg, overflow: 'hidden' }}><div style={{ height: '100%', width: pct + '%', background: meta.color, borderRadius: 4 }} /></div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function DetailModal({ row, onClose, esPublico, onAvanzar, onConvertir, rolActual }) {
  const [showObsForm, setShowObsForm] = useState(false);
  const [obsTexto, setObsTexto] = useState('');
  const [showFacturaForm, setShowFacturaForm] = useState(false);
  const [folioInput, setFolioInput] = useState('');
  const [montoInput, setMontoInput] = useState('');
  const [fechaFacturaInput, setFechaFacturaInput] = useState(HOY_ISO_ADQ);
  const [archivoNombre, setArchivoNombre] = useState('');
  const [showCorreo, setShowCorreo] = useState(false);
  const [showAjusteForm, setShowAjusteForm] = useState(false);
  const [justificacionInput, setJustificacionInput] = useState('');
  const [showNotaForm, setShowNotaForm] = useState(false); // registrar la NC/ND que el proveedor ya emitió
  const [notaFolioInput, setNotaFolioInput] = useState('');
  const [notaMontoInput, setNotaMontoInput] = useState('');

  if (!row) return null;
  const cat = CATEGORIAS[row.categoria], est = ESTADOS[row.estado];
  const esRequisicion = row.estado === 'requisicion';
  const unidadSol = UNIDADES_SOLICITANTES[row.unidadSolicitante];
  const mod = row.modalidad === 'compra_privada' ? MODALIDAD_PRIVADA : MODALIDADES_PUBLICAS[row.modalidad];
  const pasos = [
    { label: 'Solicitada', fecha: row.fecha, ok: true },
    { label: 'Aprobada', fecha: row.fechaAprobacion, ok: !!row.fechaAprobacion },
    { label: 'Enviada a proveedor', fecha: row.fechaEnvio, ok: !!row.fechaEnvio },
    { label: 'Recibida', fecha: row.fechaRecepcion, ok: !!row.fechaRecepcion },
  ];
  const hay3Vias = row.cantidadRecibida != null;
  const discrepancia3Vias = hay3Vias && row.cantidadRecibida !== row.cantidad;
  const diasParaVencerAcuse = row.acuseRecibo && !row.acuseRecibo.dado ? diffDays(HOY_ISO_ADQ, row.acuseRecibo.fechaLimite) : null;
  const discrepanciaFactura = row.montoFacturado != null && row.montoFacturado !== row.montoTotal;
  const diferenciaMonto = row.montoFacturado != null ? row.montoFacturado - row.montoTotal : 0;
  // Sobrefacturado (factura > OC) corrige con Nota de Crédito del proveedor (DTE 61, rebaja).
  // Subfacturado (factura < OC) corrige con Nota de Débito del proveedor (DTE 56, aumenta).
  // Confirmado en sii.cl: ambas las emite el VENDEDOR, nosotros solo las recibimos y registramos.
  const tipoNotaNecesaria = diferenciaMonto > 0 ? 'NC' : 'ND';
  const labelNota = tipoNotaNecesaria === 'NC' ? 'Nota de Crédito' : 'Nota de Débito';

  const confirmarObservacion = () => {
    if (!obsTexto.trim()) return;
    onAvanzar(row.id, 'recibida_con_observaciones', { observaciones: obsTexto.trim() });
    setShowObsForm(false); setObsTexto('');
  };
  const confirmarFactura = () => {
    if (!folioInput.trim() || !(Number(montoInput) > 0) || !fechaFacturaInput) return;
    const montoFacturado = Number(montoInput);
    // Si el monto no calza con la OC, la factura queda RETENIDA — no se aprueba sola.
    const calza = montoFacturado === row.montoTotal;
    onAvanzar(row.id, calza ? 'facturada' : 'factura_retenida', { facturaFolio: folioInput.trim(), montoFacturado, fechaFactura: fechaFacturaInput, archivoAdjunto: archivoNombre || null });
    setShowFacturaForm(false);
  };
  // "Solicitar" = pedimos al proveedor que emita su NC/ND — nosotros NO emitimos este
  // documento (el vendedor es quien lo emite ante el SII). Es un evento interno de gestión.
  const confirmarSolicitudNota = () => onAvanzar(row.id, 'nota_solicitada', { tipoNota: tipoNotaNecesaria });
  // "Registrar" = el proveedor YA emitió su NC/ND real y nos llegó — capturamos SU folio y
  // SU monto (no inventamos el ajuste), y calculamos si el neto ahora calza con la OC.
  const confirmarNotaRecibida = () => {
    if (!notaFolioInput.trim() || !(Number(notaMontoInput) > 0)) return;
    const montoNota = Number(notaMontoInput);
    const montoNeto = row.tipoNotaSolicitada === 'NC' ? row.montoFacturado - montoNota : row.montoFacturado + montoNota;
    onAvanzar(row.id, 'nota_recibida', { notaFolio: notaFolioInput.trim(), notaMonto: montoNota, montoNetoResultante: montoNeto });
    setShowNotaForm(false); setNotaFolioInput(''); setNotaMontoInput('');
  };
  const confirmarAjusteOC = () => {
    if (!justificacionInput.trim()) return;
    onAvanzar(row.id, 'ajuste_oc', { justificacionAjuste: justificacionInput.trim() });
    setShowAjusteForm(false); setJustificacionInput('');
  };
  const asuntoCorreo = encodeURIComponent(`Orden de Compra ${row.numeroOC} — ${row.descripcion}`);
  const cuerpoCorreo = encodeURIComponent(
    `Estimados ${row.proveedor},\n\nAdjuntamos Orden de Compra ${row.numeroOC}:\n\n` +
    `Ítem: ${row.descripcion}\nCantidad: ${row.cantidad}\nPrecio unitario: ${clp(row.precioUnitario || 0)}\nMonto total: ${clp(row.montoTotal)}\n\n` +
    `Favor confirmar recepción de este correo y plazo de entrega estimado.\n\nSaludos,\nÁrea de Adquisiciones`
  );

  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(16,24,40,.45)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100, padding: 20 }} onClick={onClose}>
      <div style={{ background: '#fff', borderRadius: C.rLg, width: 540, maxWidth: '100%', maxHeight: '90vh', overflowY: 'auto', boxShadow: '0 20px 50px rgba(16,24,40,.25)' }} onClick={(e) => e.stopPropagation()}>
        <div style={{ padding: '18px 22px', borderBottom: `1px solid ${C.border}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
            <div style={{ width: 34, height: 34, borderRadius: 9, background: cat.color + '18', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><cat.icon size={16} style={{ color: cat.color }} /></div>
            <div>
              <div style={{ fontSize: 15, fontWeight: 700, color: C.ink }}>{row.numeroOC || 'Requisición sin OC'}</div>
              <div style={{ fontSize: 12, color: C.mut }}>{row.proveedor || 'Proveedor aún no elegido'}</div>
            </div>
          </div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: C.mut }}><X size={18} /></button>
        </div>
        <div style={{ padding: 22, display: 'flex', flexDirection: 'column', gap: 16 }}>
          {esRequisicion ? (
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, background: C.vioL, padding: '9px 12px', borderRadius: C.rSm, fontSize: 12, color: C.vio }}>
              <ClipboardList size={13} /> Requisición recibida el {fmtDate(row.fecha)} — todavía no es una Orden de Compra formal.
            </div>
          ) : (
            <div>
              <FieldLabel>Ciclo de la orden</FieldLabel>
              <div style={{ display: 'flex', gap: 6 }}>
                {pasos.map((p, i) => (
                  <div key={i} style={{ flex: 1, textAlign: 'center' }}>
                    <div style={{ height: 4, borderRadius: 2, background: p.ok ? C.pri : C.border, marginBottom: 5 }} />
                    <div style={{ fontSize: 10, color: p.ok ? C.ink : C.mut, fontWeight: p.ok ? 600 : 400 }}>{p.label}</div>
                    <div style={{ fontSize: 9.5, color: C.mut }}>{p.fecha ? fmtDate(p.fecha) : '—'}</div>
                  </div>
                ))}
              </div>
            </div>
          )}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
            <div><FieldLabel>Unidad solicitante</FieldLabel><Badge color={unidadSol.color} bg={unidadSol.color + '18'} icon={unidadSol.icon}>{unidadSol.label}</Badge></div>
            {row.urgente && <div><FieldLabel>Prioridad</FieldLabel><Badge color={C.err} bg={C.errL} icon={AlertTriangle}>Urgente</Badge></div>}
          </div>
          <div>
            <FieldLabel>Ítem</FieldLabel>
            <div style={{ fontSize: 13, color: C.ink }}>{row.descripcion}</div>
            <div style={{ fontSize: 12, color: C.mut }}>{row.cantidad} unid. solicitadas{row.precioUnitario ? ` × ${clp(row.precioUnitario)}` : ''}</div>
          </div>
          {row.estado === 'recibida_con_observaciones' && row.observaciones && (
            <div style={{ background: C.warnL, borderRadius: C.rSm, padding: 12 }}>
              <div style={{ fontSize: 11.5, fontWeight: 700, color: C.warn, marginBottom: 3 }}>Observación registrada por {UNIDADES_SOLICITANTES[row.unidadSolicitante].label}</div>
              <div style={{ fontSize: 12.5, color: C.ink }}>{row.observaciones}</div>
            </div>
          )}
          {hay3Vias && (
            <div>
              <FieldLabel>Validación de 3 vías {discrepancia3Vias ? <span style={{ color: C.err, fontWeight: 700 }}>· hay diferencia</span> : <span style={{ color: C.pri, fontWeight: 700 }}>· calza correcto</span>}</FieldLabel>
              <div style={{ display: 'flex', gap: 10 }}>
                <div style={{ flex: 1, background: C.bg, borderRadius: C.rSm, padding: 10, textAlign: 'center' }}><div style={{ fontSize: 10, color: C.mut }}>Pedido (OC)</div><div style={{ fontSize: 15, fontWeight: 700, color: C.ink }}>{row.cantidad}</div></div>
                <div style={{ flex: 1, background: discrepancia3Vias ? C.errL : C.bg, borderRadius: C.rSm, padding: 10, textAlign: 'center' }}><div style={{ fontSize: 10, color: C.mut }}>Recibido</div><div style={{ fontSize: 15, fontWeight: 700, color: discrepancia3Vias ? C.err : C.ink }}>{row.cantidadRecibida}</div></div>
              </div>
            </div>
          )}
          {row.cotizaciones.length > 0 && (
            <div>
              <FieldLabel>
                Cotizaciones comparadas ({row.cotizaciones.length})
                {row.modalidad === 'compra_agil' && <span style={{ color: row.cotizaciones.length >= 3 ? C.pri : C.err, fontWeight: 700 }}> · {row.cotizaciones.length >= 3 ? 'cumple mínimo legal' : 'falta para el mínimo de 3'}</span>}
              </FieldLabel>
              <div style={{ border: `1px solid ${C.border}`, borderRadius: C.rSm, overflow: 'hidden' }}>
                {row.cotizaciones.map((c, i) => (
                  <div key={i} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '8px 12px', borderTop: i ? `1px solid ${C.border}` : 'none', background: c.seleccionada ? C.priL : '#fff' }}>
                    <span style={{ fontSize: 12.5, color: C.ink, fontWeight: c.seleccionada ? 700 : 400 }}>{c.proveedor}{c.seleccionada && <CheckCircle2 size={11} style={{ color: C.pri, marginLeft: 5, verticalAlign: 'middle' }} />}</span>
                    <span style={{ fontSize: 12.5, color: c.seleccionada ? C.pri : C.sub, fontWeight: c.seleccionada ? 700 : 400 }}>{clp(c.monto)}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
          {!esRequisicion && (
            <div style={{ background: C.bg, borderRadius: C.rSm, padding: 14 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}><span style={{ fontWeight: 700, color: C.ink }}>Monto OC (original aprobado)</span><span style={{ fontWeight: 700, color: C.ink }}>{clp(row.montoTotal)}</span></div>
              {row.facturaFolio && (
                <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 6, paddingTop: 6, borderTop: `1px dashed ${C.borderD}` }}>
                  <span style={{ color: discrepanciaFactura ? C.err : C.sub }}>Facturado (folio {row.facturaFolio}){discrepanciaFactura && ' · no calza con la OC'}</span>
                  <span style={{ fontWeight: 700, color: discrepanciaFactura ? C.err : C.sub }}>{clp(row.montoFacturado)}</span>
                </div>
              )}
              {row.montoAprobadoFinal != null && (
                <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 6, paddingTop: 6, borderTop: `1px dashed ${C.borderD}` }}>
                  <span style={{ color: C.pri, fontWeight: 600 }}>Monto a pagar (ajustado y aprobado)</span>
                  <span style={{ fontWeight: 700, color: C.pri }}>{clp(row.montoAprobadoFinal)}</span>
                </div>
              )}
            </div>
          )}
          {!esRequisicion && (
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
              <div><FieldLabel>Categoría</FieldLabel><Badge color={cat.color} bg={cat.color + '18'} icon={cat.icon}>{cat.label}</Badge></div>
              <div><FieldLabel>Estado</FieldLabel><Badge color={est.color} bg={est.bg} icon={est.icon}>{est.label}</Badge></div>
            </div>
          )}
          {!esRequisicion && (
            <div>
              <FieldLabel>Modalidad de compra</FieldLabel>
              <Badge color={mod.color} bg={mod.color + '18'}>{mod.label}</Badge>
              {row.idChileCompra && <div style={{ fontSize: 11.5, color: C.mut, marginTop: 5 }}>ID Mercado Público: <span style={{ fontFamily: 'monospace' }}>{row.idChileCompra}</span></div>}
              {!esPublico && <div style={{ fontSize: 11.5, color: C.mut, marginTop: 5 }}>Tenant privado — no aplica ChileCompra (Ley 19.886 solo rige organismos públicos)</div>}
            </div>
          )}
          {row.acuseRecibo && (
            <div style={{ background: row.acuseRecibo.dado ? C.priL : (diasParaVencerAcuse <= 2 ? C.errL : C.warnL), borderRadius: C.rSm, padding: 12 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12.5, fontWeight: 700, color: row.acuseRecibo.dado ? C.pri : (diasParaVencerAcuse <= 2 ? C.err : C.warn) }}>
                <BellRing size={13} /> Acuse de Recibo (Ley 19.983, mod. Ley 21.131)
              </div>
              {row.acuseRecibo.dado ? (
                <div style={{ fontSize: 12, color: C.sub, marginTop: 4 }}>Dado el {fmtDate(row.acuseRecibo.fecha)} — dentro de plazo.</div>
              ) : (
                <>
                  <div style={{ fontSize: 12, color: C.sub, marginTop: 4 }}>
                    Plazo legal: 8 días corridos desde la recepción de la factura en el SII. Vence el <b>{fmtDate(row.acuseRecibo.fechaLimite)}</b>
                    {diasParaVencerAcuse < 0 ? <span style={{ color: C.err, fontWeight: 700 }}> — VENCIDO, la factura ya se aceptó irrevocablemente (mérito ejecutivo)</span>
                      : diasParaVencerAcuse <= 2 ? <span style={{ color: C.err, fontWeight: 700 }}> — quedan {diasParaVencerAcuse} día(s)</span>
                      : ` — quedan ${diasParaVencerAcuse} días`}
                  </div>
                  {row.estado === 'factura_retenida' && (
                    <div style={{ fontSize: 10.5, color: C.mut, marginTop: 6, fontStyle: 'italic' }}>
                      Nota: en el SII, dar Acuse de Recibo y presentar un Reclamo formal son acciones excluyentes sobre el mismo documento — una vez que das acuse, ya no puedes reclamar. Si la discrepancia de monto también implica mercadería/servicio incompleto (no solo un error de precio a corregir vía NC/ND), evalúa si corresponde Reclamar en el Registro de Aceptación o Reclamo de un DTE del SII en vez de dar acuse acá. Esta plataforma no gestiona el Reclamo formal todavía — queda para cuando integremos el RCV en Facturación.
                    </div>
                  )}
                  {diasParaVencerAcuse >= 0 && <Btn variant="primary" icon={CheckCircle2} onClick={() => onAvanzar(row.id, 'dar_acuse')} style={{ marginTop: 8 }}>Dar acuse de recibo ahora</Btn>}
                </>
              )}
            </div>
          )}
          {row.estado === 'factura_retenida' && (
            <div style={{ background: C.errL, borderRadius: C.rSm, padding: 14 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12.5, fontWeight: 700, color: C.err, marginBottom: 6 }}>
                <AlertTriangle size={14} /> Factura retenida — el monto no calza con la OC
              </div>
              <div style={{ fontSize: 12, color: C.ink, marginBottom: 10 }}>
                OC: {clp(row.montoTotal)} · Factura: {clp(row.montoFacturado)} · Diferencia: <b>{diferenciaMonto > 0 ? '+' : ''}{clp(diferenciaMonto)}</b> · corresponde <b>{labelNota}</b>
              </div>
              <div style={{ fontSize: 11.5, color: C.sub, marginBottom: 10 }}>
                La {labelNota} la emite el proveedor (nosotros solo la solicitamos y la registramos al llegar) — es un DTE propio, con su propio folio, que referencia la factura original. No se aprueba hasta que el neto calce con la OC.
              </div>
              {!row.tipoNotaSolicitada && !showAjusteForm && (
                <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                  <Btn variant="primary" icon={Send} onClick={confirmarSolicitudNota}>Solicitar {labelNota}</Btn>
                  <Btn variant="outline" icon={FileText} onClick={() => setShowAjusteForm(true)}>Ajustar Orden de Compra</Btn>
                </div>
              )}
              {row.tipoNotaSolicitada && !showNotaForm && (
                <div style={{ background: '#fff', borderRadius: C.rSm, padding: 10, marginTop: 4 }}>
                  <div style={{ fontSize: 12, color: C.ink, marginBottom: 8 }}>{labelNota} solicitada el {fmtDate(row.fechaSolicitudNota)}. Esperando que el proveedor la emita y envíe.</div>
                  <Btn variant="primary" icon={FileText} onClick={() => setShowNotaForm(true)}>Registrar {labelNota} recibida</Btn>
                </div>
              )}
              {showNotaForm && (
                <div style={{ background: '#fff', borderRadius: C.rSm, padding: 10, marginTop: 4 }}>
                  <FieldLabel>Datos de la {labelNota} que emitió el proveedor (obligatorios)</FieldLabel>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 8 }}>
                    <input style={inputStyle} value={notaFolioInput} onChange={(e) => setNotaFolioInput(e.target.value)} placeholder={`N° folio ${labelNota.toLowerCase()}`} />
                    <input style={inputStyle} type="number" value={notaMontoInput} onChange={(e) => setNotaMontoInput(e.target.value)} placeholder="Monto de la nota" />
                  </div>
                  {Number(notaMontoInput) > 0 && (
                    <div style={{ fontSize: 11, color: C.mut, marginBottom: 8 }}>
                      Neto resultante: {clp(row.tipoNotaSolicitada === 'NC' ? row.montoFacturado - Number(notaMontoInput) : row.montoFacturado + Number(notaMontoInput))}
                      {' '}{(row.tipoNotaSolicitada === 'NC' ? row.montoFacturado - Number(notaMontoInput) : row.montoFacturado + Number(notaMontoInput)) === row.montoTotal ? '— ya calza con la OC ✓' : '— aún no calza, quedará retenida'}
                    </div>
                  )}
                  <div style={{ display: 'flex', gap: 8 }}>
                    <Btn variant="primary" icon={CheckCircle2} onClick={confirmarNotaRecibida} style={{ opacity: (notaFolioInput.trim() && Number(notaMontoInput) > 0) ? 1 : 0.5 }}>Registrar y recalcular</Btn>
                    <Btn variant="ghost" onClick={() => setShowNotaForm(false)}>Cancelar</Btn>
                  </div>
                </div>
              )}
              {showAjusteForm && (
                <div style={{ background: '#fff', borderRadius: C.rSm, padding: 10, marginTop: 4 }}>
                  <FieldLabel>Justificación del ajuste (obligatorio)</FieldLabel>
                  <textarea value={justificacionInput} onChange={(e) => setJustificacionInput(e.target.value)} rows={2} style={{ ...inputStyle, resize: 'vertical' }} placeholder="Ej: incluye flete urgente no cotizado en la OC original, autorizado por jefatura." />
                  <div style={{ fontSize: 10.5, color: C.mut, marginTop: 4, marginBottom: 4 }}>Esto NO reemplaza la NC/ND — es para cuando el mayor gasto es legítimo y se decide pagarlo tal cual, dejando registrado el motivo. El monto originalmente aprobado en la OC se conserva para auditoría; el monto a pagar queda marcado aparte.</div>
                  <div style={{ display: 'flex', gap: 8, marginTop: 8 }}>
                    <Btn variant="primary" icon={CheckCircle2} onClick={confirmarAjusteOC} style={{ opacity: justificacionInput.trim() ? 1 : 0.5 }}>Confirmar ajuste y aprobar</Btn>
                    <Btn variant="ghost" onClick={() => setShowAjusteForm(false)}>Cancelar</Btn>
                  </div>
                </div>
              )}
            </div>
          )}
          {row.estado === 'facturada' && (
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, background: C.vioL, padding: '9px 12px', borderRadius: C.rSm, fontSize: 12, color: C.vio }}>
              <FileText size={13} /> El pago se rastrea en Egresos, no acá.
              {row.justificacionAjuste && <span> · OC ajustada: "{row.justificacionAjuste}"</span>}
            </div>
          )}
          {row.estado === 'rechazada' && (
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, background: '#F1F5F9', padding: '9px 12px', borderRadius: C.rSm, fontSize: 12, color: C.mut }}>
              <Ban size={13} /> Orden rechazada — estado final.
            </div>
          )}

          {esRequisicion && (
            <div style={{ borderTop: `1px solid ${C.border}`, paddingTop: 14 }}>
              <Btn variant="primary" icon={ShoppingCart} onClick={() => onConvertir(row)}>Convertir a Orden de Compra</Btn>
            </div>
          )}

          {!esRequisicion && row.estado === 'enviada' && showCorreo && (
            <div style={{ background: C.bg, borderRadius: C.rSm, padding: 12 }}>
              <FieldLabel>Vista previa del correo</FieldLabel>
              <div style={{ fontSize: 12, color: C.sub, marginBottom: 8 }}>Para: {row.proveedor} · Asunto: OC {row.numeroOC} — {row.descripcion}</div>
              <a href={`mailto:?subject=${asuntoCorreo}&body=${cuerpoCorreo}`} style={{ textDecoration: 'none' }}>
                <Btn variant="primary" icon={Mail}>Abrir en mi programa de correo</Btn>
              </a>
              <div style={{ fontSize: 10.5, color: C.mut, marginTop: 6 }}>Redactado por la plataforma, sin API externa. Puerta etiquetada lista para reemplazar esto por un proveedor de envío (SendGrid, etc.) si el cliente lo prefiere más adelante.</div>
            </div>
          )}

          {showObsForm && (
            <div style={{ background: C.warnL, borderRadius: C.rSm, padding: 12 }}>
              <FieldLabel>¿Qué se observó al recibir? (obligatorio)</FieldLabel>
              <textarea value={obsTexto} onChange={(e) => setObsTexto(e.target.value)} rows={3} style={{ ...inputStyle, resize: 'vertical' }} placeholder="Ej: llegaron 8 unidades de las 10 pedidas, faltan 2." />
              <div style={{ display: 'flex', gap: 8, marginTop: 8 }}>
                <Btn variant="primary" icon={AlertTriangle} onClick={confirmarObservacion} style={{ opacity: obsTexto.trim() ? 1 : 0.5 }}>Confirmar con observación</Btn>
                <Btn variant="ghost" onClick={() => setShowObsForm(false)}>Cancelar</Btn>
              </div>
            </div>
          )}

          {showFacturaForm && (
            <div style={{ background: C.vioL, borderRadius: C.rSm, padding: 12 }}>
              <FieldLabel>Datos de la factura recibida (todos obligatorios)</FieldLabel>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 8 }}>
                <input style={inputStyle} value={folioInput} onChange={(e) => setFolioInput(e.target.value)} placeholder="N° folio factura" />
                <input style={inputStyle} type="number" value={montoInput} onChange={(e) => setMontoInput(e.target.value)} placeholder="Monto facturado" />
              </div>
              <input style={{ ...inputStyle, marginBottom: 8 }} type="date" value={fechaFacturaInput} onChange={(e) => setFechaFacturaInput(e.target.value)} />
              <label style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, color: C.sub, cursor: 'pointer', marginBottom: 8 }}>
                <Paperclip size={13} />
                {archivoNombre || 'Adjuntar PDF (opcional — sin backend, solo simula el nombre)'}
                <input type="file" accept="application/pdf" style={{ display: 'none' }} onChange={(e) => setArchivoNombre(e.target.files[0]?.name || '')} />
              </label>
              <div style={{ display: 'flex', gap: 8 }}>
                <Btn variant="primary" icon={FileText} onClick={confirmarFactura} style={{ opacity: (folioInput.trim() && Number(montoInput) > 0) ? 1 : 0.5 }}>Vincular factura</Btn>
                <Btn variant="ghost" onClick={() => setShowFacturaForm(false)}>Cancelar</Btn>
              </div>
            </div>
          )}

          {!esRequisicion && !['facturada', 'rechazada'].includes(row.estado) && !showObsForm && !showFacturaForm && (
            <div style={{ borderTop: `1px solid ${C.border}`, paddingTop: 14, display: 'flex', gap: 8, flexWrap: 'wrap' }}>
              {row.estado === 'solicitada' && (<>
                <Btn variant="primary" icon={CheckCircle2} onClick={() => onAvanzar(row.id, 'aprobada')}>Aprobar orden</Btn>
                <Btn variant="outline" icon={Ban} onClick={() => onAvanzar(row.id, 'rechazada')}>Rechazar</Btn>
              </>)}
              {row.estado === 'aprobada' && (<>
                <Btn variant="primary" icon={Send} onClick={() => onAvanzar(row.id, 'enviada')}>Marcar enviada al proveedor</Btn>
                {row.modalidad !== 'compra_privada' && <div style={{ fontSize: 11, color: C.mut, alignSelf: 'center' }}>El envío real ocurre en Mercado Público, no acá.</div>}
              </>)}
              {row.estado === 'enviada' && (<>
                {row.modalidad === 'compra_privada' && !showCorreo && <Btn variant="outline" icon={Mail} onClick={() => setShowCorreo(true)}>Redactar correo al proveedor</Btn>}
                <Btn variant="primary" icon={PackageCheck} onClick={() => onAvanzar(row.id, 'recibida_conforme')}>Recibida conforme</Btn>
                <Btn variant="outline" icon={AlertTriangle} onClick={() => setShowObsForm(true)}>Recibida con observaciones</Btn>
              </>)}
              {['recibida_conforme', 'recibida_con_observaciones'].includes(row.estado) && (
                <Btn variant="primary" icon={FileText} onClick={() => setShowFacturaForm(true)}>Vincular factura</Btn>
              )}
            </div>
          )}

          {row.historial && row.historial.length > 0 && (
            <div style={{ borderTop: `1px solid ${C.border}`, paddingTop: 12 }}>
              <button onClick={() => setShowCorreo(showCorreo)} style={{ display: 'flex', alignItems: 'center', gap: 5, background: 'none', border: 'none', padding: 0, cursor: 'default', fontSize: 11, fontWeight: 700, color: C.mut, textTransform: 'uppercase', letterSpacing: 0.3, marginBottom: 6 }}>
                <History size={12} /> Historial de auditoría
              </button>
              {row.historial.map((h, i) => (
                <div key={i} style={{ fontSize: 11.5, color: C.sub, marginBottom: 3 }}>
                  {fmtDate(h.fecha)} — <b style={{ color: C.ink }}>{ESTADOS[h.estado]?.label || h.estado}</b> por <span style={{ color: ROLES_FINANCIEROS[h.actorRole]?.color || C.mut }}>{ROLES_FINANCIEROS[h.actorRole]?.label || h.actorRole}</span>
                  {h.nota && <div style={{ color: C.mut, fontStyle: 'italic', marginTop: 1 }}>{h.nota}</div>}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function ConvertirModal({ requisicion, onClose, onConfirm }) {
  const [proveedor, setProveedor] = useState(requisicion.proveedorSugerido || '');
  const [precioUnitario, setPrecioUnitario] = useState('');
  const puedeGuardar = proveedor.trim() && Number(precioUnitario) > 0;
  const montoEstimado = Number(precioUnitario || 0) * requisicion.cantidad;
  const cambioProveedor = requisicion.proveedorSugerido && proveedor.trim() !== requisicion.proveedorSugerido;
  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(16,24,40,.45)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 110, padding: 20 }} onClick={onClose}>
      <div style={{ background: '#fff', borderRadius: C.rLg, width: 440, maxWidth: '100%', boxShadow: '0 20px 50px rgba(16,24,40,.25)' }} onClick={(e) => e.stopPropagation()}>
        <div style={{ padding: '18px 22px', borderBottom: `1px solid ${C.border}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ fontSize: 15, fontWeight: 700, color: C.ink }}>Convertir a Orden de Compra</div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: C.mut }}><X size={18} /></button>
        </div>
        <div style={{ padding: 22, display: 'flex', flexDirection: 'column', gap: 13 }}>
          <div style={{ background: C.bg, borderRadius: C.rSm, padding: 12, fontSize: 12.5, color: C.sub }}>
            <b style={{ color: C.ink }}>{requisicion.descripcion}</b> · {requisicion.cantidad} unid. · pedido por {UNIDADES_SOLICITANTES[requisicion.unidadSolicitante].label}
          </div>
          {requisicion.proveedorSugerido && (
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, background: C.infoL, padding: '8px 12px', borderRadius: C.rSm, fontSize: 12, color: '#1D4ED8' }}>
              <Info size={13} /> {UNIDADES_SOLICITANTES[requisicion.unidadSolicitante].label} sugirió: <b>{requisicion.proveedorSugerido}</b>
            </div>
          )}
          <div>
            <FieldLabel>Proveedor a usar en la OC</FieldLabel>
            <input style={inputStyle} value={proveedor} onChange={(e) => setProveedor(e.target.value)} placeholder="Ej: Farmadistribución Andina S.A." />
            {cambioProveedor && <div style={{ fontSize: 11, color: C.warn, marginTop: 4 }}>Estás cambiando el proveedor sugerido — quedará registrado en el historial.</div>}
          </div>
          <div>
            <FieldLabel>Precio unitario (CLP)</FieldLabel>
            <input style={inputStyle} type="number" value={precioUnitario} onChange={(e) => setPrecioUnitario(e.target.value)} placeholder="8500" />
            {montoEstimado > 0 && <div style={{ fontSize: 11.5, color: C.mut, marginTop: 5 }}>Monto total estimado: {clp(montoEstimado)}</div>}
          </div>
        </div>
        <div style={{ padding: '14px 22px', borderTop: `1px solid ${C.border}`, display: 'flex', justifyContent: 'flex-end', gap: 10 }}>
          <Btn variant="ghost" onClick={onClose}>Cancelar</Btn>
          <Btn variant="primary" icon={ShoppingCart} onClick={() => puedeGuardar && onConfirm(proveedor, Number(precioUnitario), cambioProveedor)} style={{ opacity: puedeGuardar ? 1 : 0.5 }}>Crear Orden de Compra</Btn>
        </div>
      </div>
    </div>
  );
}

function NewOCModal({ onClose, onSave, esPublico }) {
  const [form, setForm] = useState({ proveedor: '', categoria: 'insumos_clinicos', descripcion: '', cantidad: 1, precioUnitario: '', modalidad: 'compra_privada' });
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });
  const montoTotal = Number(form.cantidad || 0) * Number(form.precioUnitario || 0);
  const puedeGuardar = form.proveedor.trim() && form.descripcion.trim() && montoTotal > 0;
  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(16,24,40,.45)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100, padding: 20 }} onClick={onClose}>
      <div style={{ background: '#fff', borderRadius: C.rLg, width: 460, maxWidth: '100%', boxShadow: '0 20px 50px rgba(16,24,40,.25)' }} onClick={(e) => e.stopPropagation()}>
        <div style={{ padding: '18px 22px', borderBottom: `1px solid ${C.border}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ fontSize: 15, fontWeight: 700, color: C.ink }}>Nueva orden de compra</div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: C.mut }}><X size={18} /></button>
        </div>
        <div style={{ padding: 22, display: 'flex', flexDirection: 'column', gap: 13 }}>
          <div><FieldLabel>Proveedor</FieldLabel><input style={inputStyle} value={form.proveedor} onChange={set('proveedor')} placeholder="Ej: TecnoMed Equipos e Insumos Ltda." /></div>
          <div><FieldLabel>Categoría</FieldLabel><select style={inputStyle} value={form.categoria} onChange={set('categoria')}>{Object.entries(CATEGORIAS).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}</select></div>
          <div><FieldLabel>Descripción del ítem</FieldLabel><input style={inputStyle} value={form.descripcion} onChange={set('descripcion')} placeholder="Ej: Monitor de signos vitales" /></div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <div><FieldLabel>Cantidad</FieldLabel><input style={inputStyle} type="number" value={form.cantidad} onChange={set('cantidad')} /></div>
            <div><FieldLabel>Precio unitario (CLP)</FieldLabel><input style={inputStyle} type="number" value={form.precioUnitario} onChange={set('precioUnitario')} placeholder="850000" /></div>
          </div>
          {esPublico && (
            <div>
              <FieldLabel>Modalidad de compra</FieldLabel>
              <select style={inputStyle} value={form.modalidad} onChange={set('modalidad')}>
                <option value="compra_privada">— Selecciona modalidad —</option>
                {Object.entries(MODALIDADES_PUBLICAS).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
              </select>
              {montoTotal > 0 && <div style={{ fontSize: 11, color: C.info, marginTop: 5 }}>{sugerenciaModalidad(montoTotal)}</div>}
            </div>
          )}
        </div>
        <div style={{ padding: '14px 22px', borderTop: `1px solid ${C.border}`, display: 'flex', justifyContent: 'flex-end', gap: 10 }}>
          <Btn variant="ghost" onClick={onClose}>Cancelar</Btn>
          <Btn variant="primary" icon={Plus} onClick={() => puedeGuardar && onSave({ ...form, montoTotal })} style={{ opacity: puedeGuardar ? 1 : 0.5 }}>Crear orden</Btn>
        </div>
      </div>
    </div>
  );
}

/* --------------------------------- vista principal ------------------------------------ */
export default function ContabilidadAdquisiciones({ addToast }) {
  const toast = addToast || ((msg) => console.log(msg));
  // Estos dos toggles son solo para poder previsualizar casos en el chat.
  // En tu app real, "esPublico" viene de la configuración del tenant y "rolActual"
  // del usuario autenticado (token validado, no un selector) — ninguno debería
  // ser un switch en pantalla.
  // Nota sobre "esPublico": tenantTypes.config.js define 20 tipos, y más de uno
  // podría ser sujeto de Ley 19.886 (ej. Hospital Público, Centro de Salud
  // Público) — pero eso es un dato legal/administrativo real del tenant, no
  // algo que se deba inferir del nombre del tipo. En producción esto debería
  // venir de un campo explícito (ej. tenant.esOrganismoPublico), no de esta
  // simplificación binaria.
  const [esPublico, setEsPublico] = useState(false);
  const [rolActual, setRolActual] = useState('t_cont_contador');
  const [data, setData] = useState(() => genMock(false));
  const [filtros, setFiltros] = useState({ desde: MESES_ADQ[0] + '-01', hasta: HOY_ISO_ADQ, categoria: 'todas', estado: 'todos', q: '' });
  const [selectedId, setSelectedId] = useState(null);
  const [showNew, setShowNew] = useState(false);
  const [page, setPage] = useState(1);
  const perPage = 8;

  const cambiarTenant = (valor) => { setEsPublico(valor); setData(genMock(valor)); setPage(1); };
  const selectedRow = data.find((r) => r.id === selectedId) || null;

  const avanzarEstado = (id, nuevoEstado, datosExtra = {}) => {
    if (nuevoEstado === 'dar_acuse') {
      setData(data.map((r) => r.id === id ? {
        ...r, acuseRecibo: { ...r.acuseRecibo, dado: true, fecha: HOY_ISO_ADQ },
        historial: [...(r.historial || []), { estado: 'acuse_recibo_dado', fecha: HOY_ISO_ADQ, actorRole: rolActual }],
      } : r));
      toast('Acuse de recibo dado en el SII');
      return;
    }
    if (nuevoEstado === 'nota_solicitada') {
      const tipoNota = datosExtra.tipoNota;
      const labelNota = tipoNota === 'NC' ? 'Nota de Crédito' : 'Nota de Débito';
      setData(data.map((r) => r.id === id ? {
        ...r, tipoNotaSolicitada: tipoNota, fechaSolicitudNota: HOY_ISO_ADQ,
        historial: [...(r.historial || []), { estado: 'nota_solicitada', fecha: HOY_ISO_ADQ, actorRole: rolActual, nota: `${labelNota} solicitada al proveedor por diferencia de ${clp(Math.abs(r.montoFacturado - r.montoTotal))} (nosotros no la emitimos — la emite el proveedor)` }],
      } : r));
      toast(labelNota + ' solicitada al proveedor');
      return;
    }
    if (nuevoEstado === 'nota_recibida') {
      // Registramos el folio y monto REAL de la nota que el proveedor emitió — no inventamos
      // el ajuste. Si el neto resultante calza con la OC, recién ahí se aprueba; si no,
      // queda retenida con la diferencia actualizada (puede necesitar una nota adicional,
      // esto pasa en la práctica: "puedes emitir varias notas de crédito parciales").
      const calzaAhora = datosExtra.montoNetoResultante === undefined ? false : true;
      setData(data.map((r) => {
        if (r.id !== id) return r;
        const calza = datosExtra.montoNetoResultante === r.montoTotal;
        return {
          ...r,
          montoFacturado: datosExtra.montoNetoResultante,
          notasRecibidas: [...(r.notasRecibidas || []), { tipo: r.tipoNotaSolicitada, folio: datosExtra.notaFolio, monto: datosExtra.notaMonto, fecha: HOY_ISO_ADQ }],
          tipoNotaSolicitada: null, fechaSolicitudNota: null,
          estado: calza ? 'facturada' : 'factura_retenida',
          historial: [...(r.historial || []), { estado: calza ? 'facturada' : 'factura_retenida', fecha: HOY_ISO_ADQ, actorRole: rolActual, nota: `${r.tipoNotaSolicitada === 'NC' ? 'Nota de Crédito' : 'Nota de Débito'} folio ${datosExtra.notaFolio} registrada por ${clp(datosExtra.notaMonto)}${calza ? ' — neto ya calza con la OC' : ' — aún no calza, sigue retenida'}` }],
        };
      }));
      toast(calzaAhora ? 'Nota registrada — recalculado' : 'Nota registrada');
      return;
    }
    if (nuevoEstado === 'ajuste_oc') {
      // El monto ORIGINAL aprobado en la OC se conserva (rastro de auditoría intacto).
      // El monto que efectivamente se va a pagar queda en un campo aparte, con su justificación.
      setData(data.map((r) => r.id === id ? {
        ...r, estado: 'facturada', montoAprobadoFinal: r.montoFacturado, justificacionAjuste: datosExtra.justificacionAjuste,
        historial: [...(r.historial || []), { estado: 'facturada', fecha: HOY_ISO_ADQ, actorRole: rolActual, nota: `OC ajustada: se aprueba pagar ${clp(r.montoFacturado)} sobre el monto original de ${clp(r.montoTotal)} — ${datosExtra.justificacionAjuste}` }],
      } : r));
      toast('Orden de Compra ajustada y facturada');
      return;
    }
    setData(data.map((r) => {
      if (r.id !== id) return r;
      const hoy = HOY_ISO_ADQ;
      const cambios = { estado: nuevoEstado, ...datosExtra };
      if (nuevoEstado === 'aprobada') cambios.fechaAprobacion = hoy;
      if (nuevoEstado === 'enviada') cambios.fechaEnvio = hoy;
      if (nuevoEstado === 'recibida_conforme' || nuevoEstado === 'recibida_con_observaciones') cambios.fechaRecepcion = hoy;
      // El Acuse de Recibo ante el SII corre desde que llega la factura, sin importar si el
      // monto calza — es una obligación independiente del acuerdo interno sobre el monto.
      if ((nuevoEstado === 'facturada' || nuevoEstado === 'factura_retenida') && datosExtra.fechaFactura) {
        cambios.acuseRecibo = { dado: false, fecha: null, fechaLimite: addDiasCorridos(datosExtra.fechaFactura, 8) };
      }
      const historialNuevo = [...(r.historial || []), { estado: nuevoEstado, fecha: hoy, actorRole: rolActual }];
      return { ...r, ...cambios, historial: historialNuevo };
    }));
    toast('Orden actualizada a "' + ESTADOS[nuevoEstado].label + '"');
  };

  const [convirtiendo, setConvirtiendo] = useState(null); // requisición en proceso de convertirse a OC
  const confirmarConversion = (proveedor, precioUnitario, seCambioProveedor) => {
    const montoTotal = Math.round((precioUnitario * convirtiendo.cantidad) / 100) * 100;
    const nuevoNumeroOC = 'OC-' + (4900 + data.length);
    const nota = convirtiendo.proveedorSugerido
      ? (seCambioProveedor ? `Proveedor cambiado: se sugirió "${convirtiendo.proveedorSugerido}", se usó "${proveedor}"` : 'Proveedor sugerido aceptado')
      : null;
    setData(data.map((r) => r.id === convirtiendo.id ? {
      ...r, proveedor, precioUnitario, montoTotal,
      numeroOC: nuevoNumeroOC,
      estado: 'solicitada',
      historial: [...(r.historial || []), { estado: 'convertida_a_oc', fecha: HOY_ISO_ADQ, actorRole: rolActual, nota }],
    } : r));
    setConvirtiendo(null);
    setSelectedId(null);
    toast('Requisición convertida a ' + nuevoNumeroOC);
  };

  const filtered = useMemo(() => data.filter((r) => {
    if (r.fecha < filtros.desde || r.fecha > filtros.hasta) return false;
    if (filtros.categoria !== 'todas' && r.categoria !== filtros.categoria) return false;
    if (filtros.estado !== 'todos' && r.estado !== filtros.estado) return false;
    if (filtros.q) {
      const q = filtros.q.toLowerCase();
      const matchProveedor = (r.proveedor || '').toLowerCase().includes(q);
      const matchOC = (r.numeroOC || '').toLowerCase().includes(q);
      if (!matchProveedor && !matchOC) return false;
    }
    return true;
  }), [data, filtros]);

  const kpi = useMemo(() => calcularKPIsAdquisiciones(filtered), [filtered]);
  const porCategoriaDisplay = kpi.porCategoria.filter((i) => i.monto > 0).map((item) => [item.id, CATEGORIAS[item.id], item.monto]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / perPage));
  const pageRows = filtered.slice((page - 1) * perPage, page * perPage);
  const limpiarFiltros = () => { setFiltros({ desde: MESES_ADQ[0] + '-01', hasta: HOY_ISO_ADQ, categoria: 'todas', estado: 'todos', q: '' }); setPage(1); };

  const exportarCSV = () => {
    const header = ['N° OC', 'Fecha', 'Proveedor', 'Categoría', 'Ítem', 'Monto', 'Modalidad', 'ID ChileCompra', 'Estado'];
    const lines = filtered.map((r) => [r.numeroOC, r.fecha, r.proveedor, CATEGORIAS[r.categoria].label, r.descripcion, r.montoTotal, (r.modalidad === 'compra_privada' ? MODALIDAD_PRIVADA : MODALIDADES_PUBLICAS[r.modalidad]).label, r.idChileCompra || '', ESTADOS[r.estado].label].join(';'));
    const blob = new Blob([header.join(';') + '\n' + lines.join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = `adquisiciones_${filtros.desde}_a_${filtros.hasta}.csv`; a.click();
    URL.revokeObjectURL(url);
    toast('Archivo CSV descargado');
  };

  const handleSave = (form) => {
    setData([{
      id: 'oc_' + (9000 + data.length), numeroOC: 'OC-' + (9000 + data.length),
      fecha: HOY_ISO_ADQ, fechaAprobacion: null, fechaEnvio: null, fechaRecepcion: null,
      unidadSolicitante: 'administracion', solicitante: null, urgente: false, proveedorSugerido: null,
      proveedor: form.proveedor, categoria: form.categoria, descripcion: form.descripcion,
      cantidad: Number(form.cantidad), cantidadRecibida: null, precioUnitario: Number(form.precioUnitario), montoTotal: form.montoTotal,
      centroCosto: 'administracion',
      modalidad: esPublico ? form.modalidad : 'compra_privada',
      idChileCompra: null,
      cotizaciones: [],
      observaciones: null, facturaFolio: null, montoFacturado: null,
      tipoNotaSolicitada: null, fechaSolicitudNota: null, notasRecibidas: [], justificacionAjuste: null, montoAprobadoFinal: null,
      acuseRecibo: null,
      historial: [{ estado: 'solicitada', fecha: HOY_ISO_ADQ, actorRole: rolActual }],
      estado: 'solicitada',
    }, ...data]);
    setShowNew(false);
    toast('Orden de compra creada — pendiente de aprobación');
  };

  return (
    <div style={{ fontFamily: C.font, background: C.bg, minHeight: '100%', padding: 22 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 14, flexWrap: 'wrap', gap: 12 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
          <div style={{ width: 34, height: 34, borderRadius: 9, background: C.priL, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><ShoppingCart size={17} style={{ color: C.pri }} /></div>
          <div>
            <div style={{ fontSize: 18, fontWeight: 700, color: C.ink }}>Adquisiciones</div>
            <div style={{ fontSize: 12.5, color: C.mut }}>Órdenes de compra: desde la solicitud hasta la recepción conforme</div>
          </div>
        </div>
        <div style={{ display: 'flex', gap: 9 }}>
          <Btn variant="outline" icon={Download} onClick={exportarCSV}>Exportar CSV</Btn>
          <Btn variant="primary" icon={Plus} onClick={() => setShowNew(true)}>Nueva orden de compra</Btn>
        </div>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: 10, background: '#fff', border: `1px solid ${C.border}`, borderRadius: C.rSm, padding: '9px 13px', marginBottom: 18, fontSize: 12, color: C.sub, flexWrap: 'wrap' }}>
        <Landmark size={13} style={{ color: C.vio }} />
        <span><b style={{ color: C.ink }}>Vista previa:</b> este tenant es</span>
        <div style={{ display: 'flex', background: C.bg, borderRadius: 6, padding: 2 }}>
          <button onClick={() => cambiarTenant(false)} style={{ padding: '4px 10px', borderRadius: 4, border: 'none', cursor: 'pointer', fontSize: 11.5, fontWeight: 600, background: !esPublico ? '#fff' : 'transparent', color: !esPublico ? C.ink : C.mut, boxShadow: !esPublico ? C.shadow : 'none' }}>Privado</button>
          <button onClick={() => cambiarTenant(true)} style={{ padding: '4px 10px', borderRadius: 4, border: 'none', cursor: 'pointer', fontSize: 11.5, fontWeight: 600, background: esPublico ? '#fff' : 'transparent', color: esPublico ? C.ink : C.mut, boxShadow: esPublico ? C.shadow : 'none' }}>Organismo público</button>
        </div>
        <span style={{ color: C.mut, marginRight: 4 }}>·</span>
        <UserCog size={13} style={{ color: C.vio }} />
        <span>actuando como</span>
        <select value={rolActual} onChange={(e) => setRolActual(e.target.value)} style={{ padding: '4px 8px', borderRadius: 4, border: `1px solid ${C.border}`, fontSize: 11.5, fontWeight: 600, color: ROLES_FINANCIEROS[rolActual].color, fontFamily: C.font, background: '#fff' }}>
          {Object.entries(ROLES_FINANCIEROS).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
        </select>
        <span style={{ color: C.mut }}>— en tu app real, ambos vienen del tenant y del usuario autenticado, no de switches.</span>
      </div>

      <div style={{ fontSize: 11.5, fontWeight: 700, color: C.mut, textTransform: 'uppercase', letterSpacing: 0.4, marginBottom: 8 }}>Métricas del período</div>
      <div style={{ display: 'flex', gap: 14, marginBottom: 18, flexWrap: 'wrap' }}>
        <KPICard label="Total en órdenes" value={clp(kpi.totalOC)} sub={`${kpi.ordenes} órdenes de compra`} icon={ShoppingCart} accent={C.pri} />
        <KPICard label="Pendiente de recepción" value={clp(kpi.montoPendienteRecepcion)} sub={`${kpi.pendientesCount} órdenes en camino`} icon={Clock} accent={C.warn} />
        <KPICard label="Requisiciones sin convertir" value={kpi.requisicionesPendientes} sub="Esperando elegir proveedor" icon={ClipboardList} accent={kpi.requisicionesPendientes > 0 ? C.vio : C.mut} />
        {esPublico && <KPICard label="Vía Convenio Marco" value={kpi.pctConvenioMarco + '%'} sub="Del gasto sujeto a ChileCompra" icon={Landmark} accent={C.info} />}
        {!esPublico && <KPICard label="Concentración proveedor" value={kpi.concentracionTop + '%'} sub="Del proveedor principal" icon={Info} accent={semaforo(kpi.concentracionTop, false, 25, 40)} />}
      </div>

      <div style={{ fontSize: 11.5, fontWeight: 700, color: C.mut, textTransform: 'uppercase', letterSpacing: 0.4, marginBottom: 8 }}>Indicadores de gestión</div>
      <div style={{ display: 'flex', gap: 14, marginBottom: 14, flexWrap: 'wrap' }}>
        <KPICard label="Recibidas con observaciones" value={kpi.pctConObservaciones + '%'} sub="Meta: ≤ 5% de las órdenes" icon={AlertTriangle} accent={semaforo(kpi.pctConObservaciones, false, 5, 15)} />
        <KPICard label="3 vías correcto" value={kpi.pct3ViasOk + '%'} sub="Cantidad pedida = recibida" icon={PackageCheck} accent={semaforo(kpi.pct3ViasOk, true, 95, 80)} />
        <KPICard label="Acuse de recibo por vencer" value={kpi.acusesPorVencer} sub={`${kpi.acusesPendientes} pendientes en total`} icon={BellRing} accent={kpi.acusesPorVencer > 0 ? C.err : C.pri} />
        <KPICard label="Facturas retenidas" value={clp(kpi.montoRetenido)} sub={`${kpi.facturasRetenidasCount} sin resolver`} icon={AlertTriangle} accent={kpi.facturasRetenidasCount > 0 ? C.err : C.pri} />
        <KPICard label="Lead time promedio" value={kpi.leadTimePromedio + ' días'} sub="Solicitud → recepción" icon={Hourglass} accent={C.vio} />
      </div>

      <div style={{ display: 'flex', gap: 14, marginBottom: 14, flexWrap: 'wrap' }}>
        <BreakdownCard title="Por categoría" items={porCategoriaDisplay} total={kpi.totalOC} />
      </div>

      <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, padding: 16, boxShadow: C.shadow, marginBottom: 14 }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 10, alignItems: 'end' }}>
          <div><FieldLabel>Desde</FieldLabel><input type="date" style={inputStyle} value={filtros.desde} onChange={(e) => { setFiltros({ ...filtros, desde: e.target.value }); setPage(1); }} /></div>
          <div><FieldLabel>Hasta</FieldLabel><input type="date" style={inputStyle} value={filtros.hasta} onChange={(e) => { setFiltros({ ...filtros, hasta: e.target.value }); setPage(1); }} /></div>
          <div><FieldLabel>Categoría</FieldLabel><select style={inputStyle} value={filtros.categoria} onChange={(e) => { setFiltros({ ...filtros, categoria: e.target.value }); setPage(1); }}><option value="todas">Todas</option>{Object.entries(CATEGORIAS).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}</select></div>
          <div><FieldLabel>Estado</FieldLabel><select style={inputStyle} value={filtros.estado} onChange={(e) => { setFiltros({ ...filtros, estado: e.target.value }); setPage(1); }}><option value="todos">Todos</option>{Object.entries(ESTADOS).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}</select></div>
          <div><FieldLabel>Buscar</FieldLabel><div style={{ position: 'relative' }}><Search size={14} style={{ position: 'absolute', left: 9, top: 10, color: C.mut }} /><input style={{ ...inputStyle, paddingLeft: 28 }} placeholder="Proveedor o N° OC" value={filtros.q} onChange={(e) => { setFiltros({ ...filtros, q: e.target.value }); setPage(1); }} /></div></div>
        </div>
        <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 12 }}>
          <button onClick={limpiarFiltros} style={{ display: 'flex', alignItems: 'center', gap: 5, background: 'none', border: 'none', cursor: 'pointer', color: C.sub, fontSize: 12.5, fontWeight: 600, padding: 0 }}><RotateCcw size={13} /> Limpiar filtros</button>
        </div>
      </div>

      <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, boxShadow: C.shadow, overflow: 'hidden' }}>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
            <thead>
              <tr style={{ background: C.bg, textAlign: 'left' }}>
                {['N° OC', 'Fecha', 'Proveedor', 'Categoría', 'Monto', 'Modalidad', 'Estado', ''].map((h) => (
                  <th key={h} style={{ padding: '10px 14px', fontSize: 11.5, fontWeight: 700, color: C.sub, textTransform: 'uppercase', letterSpacing: 0.3, whiteSpace: 'nowrap' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {pageRows.map((r) => {
                const cat = CATEGORIAS[r.categoria], est = ESTADOS[r.estado];
                const esReq = r.estado === 'requisicion';
                const mod = r.modalidad === 'compra_privada' ? MODALIDAD_PRIVADA : MODALIDADES_PUBLICAS[r.modalidad];
                return (
                  <tr key={r.id} style={{ borderTop: `1px solid ${C.border}`, cursor: 'pointer' }} onClick={() => setSelectedId(r.id)}
                    onMouseEnter={(e) => (e.currentTarget.style.background = C.bg)} onMouseLeave={(e) => (e.currentTarget.style.background = 'transparent')}>
                    <td style={{ padding: '11px 14px', fontWeight: 600, color: esReq ? C.mut : C.ink, whiteSpace: 'nowrap', fontFamily: 'monospace', fontSize: 12.5 }}>{r.numeroOC || '— sin OC —'}</td>
                    <td style={{ padding: '11px 14px', color: C.sub, whiteSpace: 'nowrap' }}>{fmtDate(r.fecha)}</td>
                    <td style={{ padding: '11px 14px', maxWidth: 200 }}>{r.proveedor || (r.proveedorSugerido ? <span style={{ color: C.info, fontStyle: 'italic' }}>sugerido: {r.proveedorSugerido}</span> : <span style={{ color: C.mut, fontStyle: 'italic' }}>por definir · {UNIDADES_SOLICITANTES[r.unidadSolicitante].label}</span>)}</td>
                    <td style={{ padding: '11px 14px' }}><Badge color={cat.color} bg={cat.color + '18'} icon={cat.icon}>{cat.label}</Badge></td>
                    <td style={{ padding: '11px 14px', fontWeight: 700, color: C.ink, whiteSpace: 'nowrap' }}>{esReq ? '—' : clp(r.montoTotal)}</td>
                    <td style={{ padding: '11px 14px' }}>{esReq ? <span style={{ color: C.mut, fontSize: 12 }}>—</span> : <Badge color={mod.color} bg={mod.color + '18'}>{mod.label}</Badge>}</td>
                    <td style={{ padding: '11px 14px' }}><Badge color={est.color} bg={est.bg} icon={est.icon}>{est.label}</Badge></td>
                    <td style={{ padding: '11px 14px' }}><Eye size={15} style={{ color: C.mut }} /></td>
                  </tr>
                );
              })}
              {pageRows.length === 0 && (
                <tr><td colSpan={8} style={{ padding: '40px 14px', textAlign: 'center', color: C.mut, fontSize: 13 }}>
                  No hay órdenes de compra que calcen con estos filtros. <button onClick={limpiarFiltros} style={{ color: C.info, background: 'none', border: 'none', cursor: 'pointer', fontSize: 13, textDecoration: 'underline', padding: 0 }}>Limpia los filtros</button>.
                </td></tr>
              )}
            </tbody>
          </table>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 16px', borderTop: `1px solid ${C.border}` }}>
          <span style={{ fontSize: 12, color: C.mut }}>{filtered.length} registros · página {page} de {totalPages}</span>
          <div style={{ display: 'flex', gap: 6 }}>
            <Btn variant="outline" onClick={() => setPage(Math.max(1, page - 1))} style={{ padding: '6px 12px', opacity: page === 1 ? 0.4 : 1 }}>Anterior</Btn>
            <Btn variant="outline" onClick={() => setPage(Math.min(totalPages, page + 1))} style={{ padding: '6px 12px', opacity: page === totalPages ? 0.4 : 1 }}>Siguiente</Btn>
          </div>
        </div>
      </div>

      {selectedRow && <DetailModal row={selectedRow} onClose={() => setSelectedId(null)} esPublico={esPublico} onAvanzar={avanzarEstado} onConvertir={(r) => setConvirtiendo(r)} rolActual={rolActual} />}
      {showNew && <NewOCModal onClose={() => setShowNew(false)} onSave={handleSave} esPublico={esPublico} />}
      {convirtiendo && <ConvertirModal requisicion={convirtiendo} onClose={() => setConvirtiendo(null)} onConfirm={confirmarConversion} />}
    </div>
  );
}
