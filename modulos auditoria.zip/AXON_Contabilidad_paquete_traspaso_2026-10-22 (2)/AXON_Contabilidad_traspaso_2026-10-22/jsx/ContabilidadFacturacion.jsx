import React, { useState, useMemo } from 'react';
import {
  FileStack, Download, Send, X, CheckCircle2, Clock, AlertTriangle, Info,
  ShieldCheck, Eye, Search, BellRing, Hash, FileWarning, Timer
} from 'lucide-react';

/* =========================================================================
   DISEÑO — copiado 1:1 desde HISClinico_Layer1.jsx / demás secciones de
   Contabilidad, para que este archivo se pueda previsualizar de forma
   independiente.
   ========================================================================= */
const C = {
  bg: '#F4F6F9', card: '#FFFFFF', border: '#E2E8F0', borderD: '#CBD5E1',
  ink: '#16233E', sub: '#5B6B85', mut: '#94A3B8',
  pri: '#2E7D32', priL: '#EAF6EC',
  info: '#2563EB', infoL: '#EEF3FF',
  warn: '#B45309', warnL: '#FEF3E2',
  err: '#C62828', errL: '#FDECEC',
  vio: '#6D28D9', vioL: '#F2ECFB',
  teal: '#0E7490',
  r: 10, rSm: 7, rLg: 14,
  shadow: '0 1px 3px rgba(16,24,40,.06), 0 1px 2px rgba(16,24,40,.04)',
  font: "'Inter', -apple-system, 'Segoe UI', Roboto, sans-serif",
};

const HOY = new Date('2026-07-05T00:00:00');
const HOY_ISO = HOY.toISOString().slice(0, 10);
const clp = (n) => '$' + Math.round(n).toLocaleString('es-CL');
const fmtDate = (iso) => new Date(iso + 'T00:00:00').toLocaleDateString('es-CL', { day: '2-digit', month: 'short', year: 'numeric' });
const addDays = (iso, n) => { const d = new Date(iso + 'T00:00:00'); d.setDate(d.getDate() + n); return d.toISOString().slice(0, 10); };
const addMeses = (iso, n) => { const d = new Date(iso + 'T00:00:00'); d.setMonth(d.getMonth() + n); return d.toISOString().slice(0, 10); };
const diffDays = (a, b) => Math.round((new Date(b + 'T00:00:00') - new Date(a + 'T00:00:00')) / 86400000);
// Ver ContabilidadHelpersCompartidos.js — versión canónica verificada de semaforo() (idéntica).
function semaforo(valor, metaEsMinimo, umbralBueno, umbralMalo) {
  const esBueno = metaEsMinimo ? valor >= umbralBueno : valor <= umbralBueno;
  const esMalo = metaEsMinimo ? valor < umbralMalo : valor > umbralMalo;
  if (esBueno) return C.pri;
  if (esMalo) return C.err;
  return C.warn;
}

/* Mismos 4 tipos de documento que ya emite Ingresos (doc.codigo) — no se
   inventa una lista nueva, se reutiliza la que ya existe en producción.
   Nota de Crédito (61) se deja lista para cuando exista emisión de NC
   propias (hoy solo modelamos las que RECIBIMOS, del lado comprador, en
   Adquisiciones — son documentos distintos). */
const TIPOS_DTE = {
  33: { label: 'Factura', color: '#2563EB', plazoHorasSII: 24 },
  34: { label: 'Factura Exenta', color: '#0E7490', plazoHorasSII: 24 },
  39: { label: 'Boleta', color: '#2E7D32', plazoHorasSII: 1 },
  41: { label: 'Boleta Exenta', color: '#16A34A', plazoHorasSII: 1 },
};

const ESTADOS_SII = {
  aceptado: { label: 'Aceptado', color: '#2E7D32', bg: '#EAF6EC', icon: CheckCircle2 },
  reparo: { label: 'Aceptado con reparo', color: '#B45309', bg: '#FEF3E2', icon: AlertTriangle },
  pendiente_envio: { label: 'Pendiente de envío a SII', color: '#94A3B8', bg: '#F1F5F9', icon: Clock },
  rechazado: { label: 'Rechazado por SII', color: '#C62828', bg: '#FDECEC', icon: FileWarning },
};

/* ═══════════════════════════════════════════════════════════════════════
   CAF (Código de Autorización de Folios) — un rango independiente POR TIPO
   de documento (un CAF de Factura no sirve para Boleta, confirmado en el
   instructivo SII). Vigencia: 6 meses exactos desde la autorización (regla
   vigente desde 01/07/2018) — se calcula, no se hardcodea la fecha límite.
   Si se agotan los folios, el SII bloquea la emisión: por eso el semáforo
   de "folios disponibles" es un KPI real de continuidad operativa, no solo
   informativo. */
const CAF_POOL_INICIAL = {
  33: { folioDesde: 10000, folioHasta: 10999, folioActual: 10461, fechaAutorizacion: '2026-04-10' },
  34: { folioDesde: 5000, folioHasta: 5999, folioActual: 5212, fechaAutorizacion: '2026-04-10' },
  // Boleta a propósito casi agotada, para que el semáforo de folios se vea funcionando de verdad.
  39: { folioDesde: 40000, folioHasta: 40999, folioActual: 40928, fechaAutorizacion: '2026-01-15' },
  41: { folioDesde: 20000, folioHasta: 20499, folioActual: 20180, fechaAutorizacion: '2026-01-15' },
};

function estadoCAF(caf) {
  const total = caf.folioHasta - caf.folioDesde + 1;
  const usados = caf.folioActual - caf.folioDesde;
  const disponibles = caf.folioHasta - caf.folioActual;
  const pctUsado = Math.round((usados / total) * 100);
  const fechaVencimiento = addMeses(caf.fechaAutorizacion, 6);
  const diasParaVencer = diffDays(HOY_ISO, fechaVencimiento);
  return { total, usados, disponibles, pctUsado, fechaVencimiento, diasParaVencer, agotado: disponibles <= 0 };
}

/* ═══════════════════════════════════════════════════════════════════════
   COMPOSICIÓN — misma idea que Flujo de Caja: esta sección no inventa sus
   propios pendientes, traduce las filas de Ingresos con doc.folio===null
   (mismo shape que Ingresos ya exporta) en borradores listos para emitir.
   ═══════════════════════════════════════════════════════════════════════ */
function desdeIngresosPendientes(rows) {
  return rows.filter((r) => r.doc && r.doc.folio === null).map((r) => ({
    id: 'brw_' + r.id,
    origenId: r.id,
    fecha: r.fecha,
    receptor: r.isapreNombre || r.convenioNombre || (r.pagador === 'particular' ? r.paciente : PAGADOR_LABEL[r.pagador] || r.pagador),
    rutReceptor: r.pagador === 'particular' ? r.rut : RUT_INSTITUCIONAL[r.pagador] || '—',
    codigoDoc: r.doc.codigo,
    monto: r.monto,
    detalle: r.prestacion,
  }));
}
const PAGADOR_LABEL = { fonasa_mai: 'Fondo Nacional de Salud (Fonasa)', fonasa_mle: 'Fondo Nacional de Salud (Fonasa)', mutual: 'Mutual de Seguridad', internacional: 'Convenio Internacional' };
const RUT_INSTITUCIONAL = { fonasa_mai: '61.606.700-9', fonasa_mle: '61.606.700-9', mutual: '70.028.700-9' };

/* ═══════════════════════════════════════════════════════════════════════
   PUERTA ETIQUETADA — emitirDTE
   Hoy simula la emisión completa (consume folio real del CAF correspon-
   diente, genera un timbre de muestra). El día que se conecte a SII
   directo o a un proveedor de facturación certificado (Haulmer, Bsale,
   Nubox...), se reemplaza el CUERPO de esta función — nada del resto de
   la pantalla necesita cambiar, porque la firma (qué entra, qué sale) es
   la misma que usará la integración real:
   entra:  { borrador, cafPool }
   sale:   { documento, cafPoolActualizado } — o { error } si no hay folios.
   ═══════════════════════════════════════════════════════════════════════ */
export function emitirDTE(borrador, cafPool) {
  const caf = cafPool[borrador.codigoDoc];
  const est = estadoCAF(caf);
  if (est.agotado) {
    return { error: `Sin folios disponibles para ${TIPOS_DTE[borrador.codigoDoc].label} — se necesita timbrar un nuevo CAF antes de emitir.` };
  }
  const nuevoFolio = caf.folioActual + 1;
  const timbreSimulado = `TED-${borrador.codigoDoc}-${nuevoFolio}-${HOY_ISO.replace(/-/g, '')}`;
  const documento = {
    id: 'dte_' + nuevoFolio,
    codigoDoc: borrador.codigoDoc, folio: nuevoFolio, timbre: timbreSimulado,
    fechaEmision: HOY_ISO, fechaEnvioSII: HOY_ISO,
    receptor: borrador.receptor, rutReceptor: borrador.rutReceptor,
    monto: borrador.monto, detalle: borrador.detalle,
    origenId: borrador.origenId,
    estadoSII: 'aceptado',
    acuseReceptor: { dado: false, fechaLimite: addDays(HOY_ISO, 8) },
  };
  const cafPoolActualizado = { ...cafPool, [borrador.codigoDoc]: { ...caf, folioActual: nuevoFolio } };
  return { documento, cafPoolActualizado };
}

/* ═══════════════════════════════════════════════════════════════════════
   PUERTA ETIQUETADA — calcularKPIsFacturacion
   ═══════════════════════════════════════════════════════════════════════ */
export function calcularKPIsFacturacion(documentos, cafPool) {
  const totalEmitido = documentos.reduce((s, d) => s + d.monto, 0);
  const conReparo = documentos.filter((d) => d.estadoSII === 'reparo').length;
  const rechazados = documentos.filter((d) => d.estadoSII === 'rechazado').length;
  const tasaAceptacion = documentos.length ? Math.round(((documentos.length - rechazados) / documentos.length) * 100) : 100;

  const boletas = documentos.filter((d) => [39, 41].includes(d.codigoDoc));
  const boletasATiempo = boletas.filter((d) => d.fechaEnvioSII === d.fechaEmision).length; // simplificación: mismo día = dentro de la hora
  const pctBoletasATiempo = boletas.length ? Math.round((boletasATiempo / boletas.length) * 100) : 100;

  const acusesPendientes = documentos.filter((d) => d.acuseReceptor && !d.acuseReceptor.dado);
  const acusesPorVencer = acusesPendientes.filter((d) => diffDays(HOY_ISO, d.acuseReceptor.fechaLimite) <= 2).length;

  const cafEstados = Object.entries(cafPool).map(([codigo, caf]) => ({ codigo: Number(codigo), ...estadoCAF(caf) }));
  const cafConAlerta = cafEstados.filter((c) => c.pctUsado >= 85 || c.diasParaVencer <= 30).length;
  const folioMasBajo = cafEstados.sort((a, b) => a.disponibles - b.disponibles)[0];

  const porTipo = Object.keys(TIPOS_DTE).map((c) => ({ codigo: Number(c), monto: documentos.filter((d) => d.codigoDoc === Number(c)).reduce((s, d) => s + d.monto, 0) }));

  return {
    seccion: 'facturacion', documentosEmitidos: documentos.length, totalEmitido,
    conReparo, rechazados, tasaAceptacion, pctBoletasATiempo,
    acusesPendientesCount: acusesPendientes.length, acusesPorVencer,
    cafConAlerta, folioMasBajo, cafEstados, porTipo,
  };
}

/* ------------------------------ mock data -------------------------------- */
const NOMBRES = ['María José González', 'Pedro Muñoz', 'Camila Rojas', 'Rodrigo Díaz', 'Fernanda Pérez', 'Ignacio Soto', 'Valentina Contreras', 'Cristóbal Silva'];
const ISAPRES = ['Banmédica', 'Consalud', 'Cruz Blanca', 'Colmena Golden Cross'];
const PRESTACIONES = ['Consulta medicina general', 'Ecografía abdominal', 'Radiografía de tórax', 'Día cama básica', 'Hemograma completo', 'Colecistectomía laparoscópica'];

// Ver ContabilidadHelpersCompartidos.js — versión canónica verificada de calcDV/fakeRUT (acá calcDV va inlineado, mismo algoritmo, base 9000000/mult 7919 igual que Ingresos).
function fakeRUT(seed) {
  const body = String(9000000 + (seed * 7919) % 8900000);
  let suma = 0, mult = 2;
  for (let i = body.length - 1; i >= 0; i--) { suma += parseInt(body[i], 10) * mult; mult = mult === 7 ? 2 : mult + 1; }
  const resto = 11 - (suma % 11);
  const dv = resto === 11 ? '0' : resto === 10 ? 'K' : String(resto);
  return body.slice(0, 2) + '.' + body.slice(2, 5) + '.' + body.slice(5) + '-' + dv;
}

function genIngresosPendientesMock() {
  const rows = []; let seed = 21;
  const codigos = [33, 33, 34, 39, 39, 39, 41];
  for (let i = 0; i < 14; i++) {
    seed += 17;
    const codigoDoc = codigos[seed % codigos.length];
    const esInstitucional = codigoDoc === 33 || codigoDoc === 34;
    const pagador = esInstitucional ? (seed % 2 === 0 ? 'isapre' : 'fonasa_mai') : 'particular';
    rows.push({
      id: 1000 + i,
      fecha: addDays(HOY_ISO, -(seed % 6)),
      paciente: NOMBRES[seed % NOMBRES.length],
      rut: fakeRUT(seed),
      pagador,
      isapreNombre: pagador === 'isapre' ? ISAPRES[seed % ISAPRES.length] : null,
      prestacion: PRESTACIONES[seed % PRESTACIONES.length],
      monto: 15000 + (seed * 3701) % 900000,
      doc: { codigo: codigoDoc, folio: null },
    });
  }
  return rows;
}

function genDocumentosEmitidosMock(cafInicial) {
  const documentos = [];
  let cafPool = cafInicial;
  let seed = 55;
  const codigos = [33, 34, 39, 39, 41];
  for (let i = 0; i < 20; i++) {
    seed += 13;
    const codigoDoc = codigos[seed % codigos.length];
    const esInstitucional = codigoDoc === 33 || codigoDoc === 34;
    const borrador = {
      codigoDoc,
      receptor: esInstitucional ? ISAPRES[seed % ISAPRES.length] : NOMBRES[seed % NOMBRES.length],
      rutReceptor: esInstitucional ? '9' + String(seed % 9) + '.111.222-3' : fakeRUT(seed),
      monto: 15000 + (seed * 4201) % 850000,
      detalle: PRESTACIONES[seed % PRESTACIONES.length],
      origenId: 'mock_' + i,
    };
    const resultado = emitirDTE(borrador, cafPool);
    if (resultado.documento) {
      const fecha = addDays(HOY_ISO, -(seed % 20));
      const esReparo = seed % 11 === 0;
      documentos.push({
        ...resultado.documento,
        fechaEmision: fecha, fechaEnvioSII: fecha,
        estadoSII: esReparo ? 'reparo' : 'aceptado',
        acuseReceptor: { dado: seed % 3 !== 0, fecha: seed % 3 !== 0 ? addDays(fecha, 2) : null, fechaLimite: addDays(fecha, 8) },
      });
      cafPool = resultado.cafPoolActualizado;
    }
  }
  return { documentos, cafPool };
}

/* ------------------------------- átomos ---------------------------------- */
const Badge = ({ color, bg, icon: Icon, children }) => (
  <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, padding: '3px 9px', borderRadius: 999, fontSize: 12, fontWeight: 600, color, background: bg, whiteSpace: 'nowrap' }}>
    {Icon && <Icon size={12} />}{children}
  </span>
);
const Btn = ({ variant = 'ghost', icon: Icon, children, onClick, style, type = 'button' }) => {
  const variants = { primary: { background: C.pri, color: '#fff' }, outline: { background: '#fff', color: C.ink, border: `1px solid ${C.border}` }, ghost: { background: 'transparent', color: C.sub } };
  return (
    <button type={type} onClick={onClick}
      onMouseEnter={(e) => (e.currentTarget.style.filter = 'brightness(0.96)')} onMouseLeave={(e) => (e.currentTarget.style.filter = 'none')}
      style={{ display: 'inline-flex', alignItems: 'center', gap: 7, padding: '9px 15px', borderRadius: C.rSm, fontSize: 13.5, fontWeight: 600, cursor: 'pointer', border: '1px solid transparent', fontFamily: C.font, ...variants[variant], ...style }}>
      {Icon && <Icon size={15} />}{children}
    </button>
  );
};
const KPICard = ({ label, value, sub, icon: Icon, accent }) => (
  <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, padding: '16px 18px', boxShadow: C.shadow, flex: 1, minWidth: 0 }}>
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
      <span style={{ fontSize: 12.5, color: C.sub, fontWeight: 600 }}>{label}</span>
      <div style={{ width: 28, height: 28, borderRadius: 8, background: accent + '18', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon size={14} style={{ color: accent }} /></div>
    </div>
    <div style={{ fontSize: 22, fontWeight: 700, color: C.ink, letterSpacing: -0.3 }}>{value}</div>
    {sub && <div style={{ fontSize: 12, color: C.mut, marginTop: 3 }}>{sub}</div>}
  </div>
);
const FieldLabel = ({ children }) => <label style={{ fontSize: 11.5, fontWeight: 600, color: C.sub, marginBottom: 5, display: 'block' }}>{children}</label>;
const inputStyle = { width: '100%', padding: '8px 10px', borderRadius: C.rSm, border: `1px solid ${C.border}`, fontSize: 13.5, fontFamily: C.font, color: C.ink, outline: 'none', boxSizing: 'border-box', background: '#fff' };

function CAFCard({ codigo, caf }) {
  const tipo = TIPOS_DTE[codigo];
  const est = estadoCAF(caf);
  const colorBarra = semaforo(est.pctUsado, false, 70, 90);
  return (
    <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, padding: 16, boxShadow: C.shadow, flex: 1, minWidth: 200 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
        <span style={{ fontSize: 12.5, fontWeight: 700, color: C.ink }}>{tipo.label}</span>
        <Badge color={tipo.color} bg={tipo.color + '18'}>{codigo}</Badge>
      </div>
      <div style={{ fontSize: 11.5, color: C.sub, marginBottom: 6 }}>Folios {caf.folioDesde.toLocaleString('es-CL')}–{caf.folioHasta.toLocaleString('es-CL')} · actual {caf.folioActual.toLocaleString('es-CL')}</div>
      <div style={{ height: 7, borderRadius: 4, background: C.bg, overflow: 'hidden', marginBottom: 6 }}>
        <div style={{ height: '100%', width: est.pctUsado + '%', background: colorBarra, borderRadius: 4 }} />
      </div>
      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11.5 }}>
        <span style={{ color: colorBarra, fontWeight: 600 }}>{est.disponibles.toLocaleString('es-CL')} disponibles</span>
        <span style={{ color: est.diasParaVencer <= 30 ? C.warn : C.mut }}>{est.diasParaVencer <= 30 ? `Vence en ${est.diasParaVencer}d` : `Vence ${fmtDate(est.fechaVencimiento)}`}</span>
      </div>
    </div>
  );
}

function EmitirModal({ borrador, onClose, onConfirm }) {
  const tipo = TIPOS_DTE[borrador.codigoDoc];
  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(16,24,40,.45)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100, padding: 20 }} onClick={onClose}>
      <div style={{ background: '#fff', borderRadius: C.rLg, width: 440, maxWidth: '100%', boxShadow: '0 20px 50px rgba(16,24,40,.25)' }} onClick={(e) => e.stopPropagation()}>
        <div style={{ padding: '18px 22px', borderBottom: `1px solid ${C.border}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ fontSize: 15, fontWeight: 700, color: C.ink }}>Emitir {tipo.label}</div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: C.mut }}><X size={18} /></button>
        </div>
        <div style={{ padding: 22, display: 'flex', flexDirection: 'column', gap: 12 }}>
          <div><FieldLabel>Receptor</FieldLabel><div style={{ fontSize: 13.5, color: C.ink, fontWeight: 600 }}>{borrador.receptor}</div><div style={{ fontSize: 12, color: C.mut }}>{borrador.rutReceptor}</div></div>
          <div><FieldLabel>Detalle</FieldLabel><div style={{ fontSize: 13, color: C.ink }}>{borrador.detalle}</div></div>
          <div style={{ background: C.bg, borderRadius: C.rSm, padding: 12, display: 'flex', justifyContent: 'space-between' }}>
            <span style={{ fontWeight: 700, color: C.ink }}>Monto</span><span style={{ fontWeight: 700, color: C.ink }}>{clp(borrador.monto)}</span>
          </div>
          <div style={{ fontSize: 11, color: C.mut, display: 'flex', gap: 5 }}>
            <Info size={12} style={{ flexShrink: 0, marginTop: 1 }} />
            Se consumirá el próximo folio disponible del CAF de {tipo.label}. {tipo.plazoHorasSII === 1 ? 'Las boletas deben llegar al SII dentro de 1 hora desde la emisión.' : 'Plazo estándar de envío al SII.'}
          </div>
        </div>
        <div style={{ padding: '14px 22px', borderTop: `1px solid ${C.border}`, display: 'flex', justifyContent: 'flex-end', gap: 10 }}>
          <Btn variant="ghost" onClick={onClose}>Cancelar</Btn>
          <Btn variant="primary" icon={Send} onClick={() => onConfirm(borrador)}>Emitir documento</Btn>
        </div>
      </div>
    </div>
  );
}

function DetailModal({ doc, onClose, onDarAcuse }) {
  if (!doc) return null;
  const tipo = TIPOS_DTE[doc.codigoDoc], est = ESTADOS_SII[doc.estadoSII];
  const diasParaVencerAcuse = doc.acuseReceptor && !doc.acuseReceptor.dado ? diffDays(HOY_ISO, doc.acuseReceptor.fechaLimite) : null;
  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(16,24,40,.45)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100, padding: 20 }} onClick={onClose}>
      <div style={{ background: '#fff', borderRadius: C.rLg, width: 480, maxWidth: '100%', maxHeight: '90vh', overflowY: 'auto', boxShadow: '0 20px 50px rgba(16,24,40,.25)' }} onClick={(e) => e.stopPropagation()}>
        <div style={{ padding: '18px 22px', borderBottom: `1px solid ${C.border}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
            <div style={{ width: 34, height: 34, borderRadius: 9, background: tipo.color + '18', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Hash size={16} style={{ color: tipo.color }} /></div>
            <div>
              <div style={{ fontSize: 15, fontWeight: 700, color: C.ink }}>{tipo.label} N° {doc.folio.toLocaleString('es-CL')}</div>
              <div style={{ fontSize: 12, color: C.mut }}>{doc.receptor}</div>
            </div>
          </div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: C.mut }}><X size={18} /></button>
        </div>
        <div style={{ padding: 22, display: 'flex', flexDirection: 'column', gap: 16 }}>
          <div style={{ background: C.bg, borderRadius: C.rSm, padding: 14 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}><span style={{ color: C.sub }}>Monto</span><span style={{ fontWeight: 700, color: C.ink }}>{clp(doc.monto)}</span></div>
          </div>
          <div><FieldLabel>Detalle</FieldLabel><div style={{ fontSize: 13, color: C.ink }}>{doc.detalle}</div></div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
            <div><FieldLabel>Fecha emisión</FieldLabel><div style={{ fontSize: 13, color: C.ink }}>{fmtDate(doc.fechaEmision)}</div></div>
            <div><FieldLabel>Estado SII</FieldLabel><Badge color={est.color} bg={est.bg} icon={est.icon}>{est.label}</Badge></div>
          </div>
          <div>
            <FieldLabel>Timbre electrónico (TED) — muestra</FieldLabel>
            <div style={{ fontFamily: 'monospace', fontSize: 11, color: C.sub, background: C.bg, padding: 10, borderRadius: C.rSm, wordBreak: 'break-all' }}>{doc.timbre}</div>
            <div style={{ fontSize: 10.5, color: C.mut, marginTop: 4 }}>Placeholder — el timbre real lo genera el CAF con la llave privada entregada por el SII.</div>
          </div>
          {doc.acuseReceptor && (
            <div style={{ background: doc.acuseReceptor.dado ? C.priL : (diasParaVencerAcuse <= 2 ? C.errL : C.warnL), borderRadius: C.rSm, padding: 12 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12.5, fontWeight: 700, color: doc.acuseReceptor.dado ? C.pri : (diasParaVencerAcuse <= 2 ? C.err : C.warn) }}>
                <BellRing size={13} /> Acuse de recibo del receptor
              </div>
              {doc.acuseReceptor.dado ? (
                <div style={{ fontSize: 12, color: C.sub, marginTop: 4 }}>Dado el {fmtDate(doc.acuseReceptor.fecha)}.</div>
              ) : (
                <div style={{ fontSize: 12, color: C.sub, marginTop: 4 }}>
                  Plazo 8 días corridos desde la recepción. Vence {fmtDate(doc.acuseReceptor.fechaLimite)}
                  {diasParaVencerAcuse < 0 ? <span style={{ color: C.err, fontWeight: 700 }}> — vencido, se acepta tácitamente</span> : ` — quedan ${diasParaVencerAcuse} días`}
                </div>
              )}
            </div>
          )}
          <div style={{ fontSize: 11, color: C.mut, paddingTop: 10, borderTop: `1px solid ${C.border}` }}>Recurso FHIR asociado: <span style={{ fontFamily: 'monospace', background: C.bg, padding: '2px 6px', borderRadius: 4 }}>Invoice</span></div>
        </div>
      </div>
    </div>
  );
}

/* --------------------------------- vista principal ------------------------------------ */
export default function ContabilidadFacturacion({ addToast }) {
  const toast = addToast || ((msg) => console.log(msg));
  const [cafPool, setCafPool] = useState(() => genDocumentosEmitidosMock(CAF_POOL_INICIAL).cafPool);
  const [documentos, setDocumentos] = useState(() => genDocumentosEmitidosMock(CAF_POOL_INICIAL).documentos);
  const [pendientes, setPendientes] = useState(() => desdeIngresosPendientes(genIngresosPendientesMock()));
  const [emitiendo, setEmitiendo] = useState(null);
  const [selectedDoc, setSelectedDoc] = useState(null);
  const [q, setQ] = useState('');
  const [page, setPage] = useState(1);
  const perPage = 8;

  const kpi = useMemo(() => calcularKPIsFacturacion(documentos, cafPool), [documentos, cafPool]);
  const porTipoDisplay = kpi.porTipo.filter((t) => t.monto > 0).map((t) => [t.codigo, TIPOS_DTE[t.codigo], t.monto]);

  const filtrados = useMemo(() => documentos.filter((d) => !q || d.receptor.toLowerCase().includes(q.toLowerCase()) || String(d.folio).includes(q)).sort((a, b) => (a.fechaEmision < b.fechaEmision ? 1 : -1)), [documentos, q]);
  const totalPages = Math.max(1, Math.ceil(filtrados.length / perPage));
  const pageRows = filtrados.slice((page - 1) * perPage, page * perPage);

  const confirmarEmision = (borrador) => {
    const resultado = emitirDTE(borrador, cafPool);
    if (resultado.error) { toast(resultado.error); setEmitiendo(null); return; }
    setDocumentos([resultado.documento, ...documentos]);
    setCafPool(resultado.cafPoolActualizado);
    setPendientes(pendientes.filter((p) => p.id !== borrador.id));
    setEmitiendo(null);
    toast(`${TIPOS_DTE[borrador.codigoDoc].label} N° ${resultado.documento.folio} emitida`);
  };

  const exportarCSV = () => {
    const header = ['Folio', 'Tipo', 'Receptor', 'RUT', 'Monto', 'Fecha Emisión', 'Estado SII'];
    const lines = filtrados.map((d) => [d.folio, TIPOS_DTE[d.codigoDoc].label, d.receptor, d.rutReceptor, d.monto, d.fechaEmision, ESTADOS_SII[d.estadoSII].label].join(';'));
    const blob = new Blob([header.join(';') + '\n' + lines.join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = `facturacion_${HOY_ISO}.csv`; a.click();
    URL.revokeObjectURL(url);
    toast('Archivo CSV descargado');
  };

  return (
    <div style={{ fontFamily: C.font, background: C.bg, minHeight: '100%', padding: 22 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 14, flexWrap: 'wrap', gap: 12 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
          <div style={{ width: 34, height: 34, borderRadius: 9, background: C.infoL, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><FileStack size={17} style={{ color: C.info }} /></div>
          <div>
            <div style={{ fontSize: 18, fontWeight: 700, color: C.ink }}>Facturación</div>
            <div style={{ fontSize: 12.5, color: C.mut }}>Emisión de DTE, folios CAF y estado ante el SII — documentos que emitimos como vendedor</div>
          </div>
        </div>
        <Btn variant="outline" icon={Download} onClick={exportarCSV}>Exportar CSV</Btn>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: 7, background: '#fff', border: `1px solid ${C.border}`, borderRadius: C.rSm, padding: '9px 13px', marginBottom: 18, fontSize: 12, color: C.sub }}>
        <Info size={13} style={{ color: C.vio }} />
        Simulación sin API: hoy esta pantalla emula el timbraje y consume folios locales. Cuando se conecte a SII directo o a un proveedor de facturación certificado, solo cambia el interior de <code style={{ fontFamily: 'monospace' }}>emitirDTE()</code> — la pantalla no se toca. CAF vigente 6 meses desde autorización · Boletas deben llegar al SII dentro de 1 hora.
      </div>

      <div style={{ fontSize: 11.5, fontWeight: 700, color: C.mut, textTransform: 'uppercase', letterSpacing: 0.4, marginBottom: 8 }}>Métricas del período</div>
      <div style={{ display: 'flex', gap: 14, marginBottom: 18, flexWrap: 'wrap' }}>
        <KPICard label="Documentos emitidos" value={kpi.documentosEmitidos} sub={clp(kpi.totalEmitido) + ' facturado'} icon={FileStack} accent={C.info} />
        <KPICard label="Pendientes de emitir" value={pendientes.length} sub="Vienen de Ingresos" icon={Clock} accent={pendientes.length > 0 ? C.warn : C.pri} />
        <KPICard label="Tasa de aceptación SII" value={kpi.tasaAceptacion + '%'} sub={`${kpi.conReparo} con reparo · ${kpi.rechazados} rechazados`} icon={ShieldCheck} accent={semaforo(kpi.tasaAceptacion, true, 98, 90)} />
        <KPICard label="Boletas enviadas a tiempo" value={kpi.pctBoletasATiempo + '%'} sub="Dentro de 1 hora desde emisión" icon={Timer} accent={semaforo(kpi.pctBoletasATiempo, true, 98, 90)} />
      </div>

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
        <div style={{ fontSize: 11.5, fontWeight: 700, color: C.mut, textTransform: 'uppercase', letterSpacing: 0.4 }}>Folios CAF por tipo de documento</div>
        {kpi.cafConAlerta > 0 && <Badge color={C.err} bg={C.errL} icon={AlertTriangle}>{kpi.cafConAlerta} CAF necesitan atención</Badge>}
      </div>
      <div style={{ display: 'flex', gap: 14, marginBottom: 18, flexWrap: 'wrap' }}>
        {Object.entries(cafPool).map(([codigo, caf]) => <CAFCard key={codigo} codigo={Number(codigo)} caf={caf} />)}
      </div>

      {pendientes.length > 0 && (
        <>
          <div style={{ fontSize: 11.5, fontWeight: 700, color: C.mut, textTransform: 'uppercase', letterSpacing: 0.4, marginBottom: 8 }}>Pendientes de emitir · desde Ingresos</div>
          <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, boxShadow: C.shadow, overflow: 'hidden', marginBottom: 18 }}>
            <div style={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
                <thead><tr style={{ background: C.bg, textAlign: 'left' }}>{['Fecha', 'Receptor', 'Detalle', 'Tipo', 'Monto', ''].map((h) => <th key={h} style={{ padding: '10px 14px', fontSize: 11.5, fontWeight: 700, color: C.sub, textTransform: 'uppercase' }}>{h}</th>)}</tr></thead>
                <tbody>
                  {pendientes.map((p) => {
                    const tipo = TIPOS_DTE[p.codigoDoc];
                    return (
                      <tr key={p.id} style={{ borderTop: `1px solid ${C.border}` }}>
                        <td style={{ padding: '11px 14px', color: C.sub, whiteSpace: 'nowrap' }}>{fmtDate(p.fecha)}</td>
                        <td style={{ padding: '11px 14px', fontWeight: 600, color: C.ink }}>{p.receptor}</td>
                        <td style={{ padding: '11px 14px', color: C.ink }}>{p.detalle}</td>
                        <td style={{ padding: '11px 14px' }}><Badge color={tipo.color} bg={tipo.color + '18'}>{tipo.label}</Badge></td>
                        <td style={{ padding: '11px 14px', fontWeight: 700, color: C.ink, whiteSpace: 'nowrap' }}>{clp(p.monto)}</td>
                        <td style={{ padding: '11px 14px' }}><Btn variant="primary" icon={Send} onClick={() => setEmitiendo(p)} style={{ padding: '6px 12px', fontSize: 12.5 }}>Emitir</Btn></td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}

      <div style={{ display: 'flex', gap: 14, marginBottom: 18, flexWrap: 'wrap' }}>
        <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, padding: 18, boxShadow: C.shadow, flex: 1, minWidth: 260 }}>
          <div style={{ fontSize: 13, fontWeight: 700, color: C.ink, marginBottom: 14 }}>Facturado por tipo de documento</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 11 }}>
            {porTipoDisplay.map(([codigo, meta, monto]) => {
              const pct = kpi.totalEmitido ? Math.round((monto / kpi.totalEmitido) * 100) : 0;
              return (
                <div key={codigo}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12.5, marginBottom: 4 }}>
                    <span style={{ color: C.ink, fontWeight: 500 }}>{meta.label}</span>
                    <span style={{ color: C.sub, fontWeight: 600 }}>{clp(monto)} <span style={{ color: C.mut, fontWeight: 400 }}>({pct}%)</span></span>
                  </div>
                  <div style={{ height: 6, borderRadius: 4, background: C.bg, overflow: 'hidden' }}><div style={{ height: '100%', width: pct + '%', background: meta.color, borderRadius: 4 }} /></div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
        <div style={{ fontSize: 11.5, fontWeight: 700, color: C.mut, textTransform: 'uppercase', letterSpacing: 0.4 }}>Documentos emitidos</div>
        <div style={{ position: 'relative', width: 220 }}>
          <Search size={14} style={{ position: 'absolute', left: 9, top: 9, color: C.mut }} />
          <input style={{ ...inputStyle, paddingLeft: 28 }} placeholder="Receptor o folio" value={q} onChange={(e) => { setQ(e.target.value); setPage(1); }} />
        </div>
      </div>
      <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, boxShadow: C.shadow, overflow: 'hidden' }}>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
            <thead><tr style={{ background: C.bg, textAlign: 'left' }}>{['Folio', 'Tipo', 'Receptor', 'Monto', 'Emisión', 'Estado SII', ''].map((h) => <th key={h} style={{ padding: '10px 14px', fontSize: 11.5, fontWeight: 700, color: C.sub, textTransform: 'uppercase' }}>{h}</th>)}</tr></thead>
            <tbody>
              {pageRows.map((d) => {
                const tipo = TIPOS_DTE[d.codigoDoc], est = ESTADOS_SII[d.estadoSII];
                return (
                  <tr key={d.id} style={{ borderTop: `1px solid ${C.border}`, cursor: 'pointer' }} onClick={() => setSelectedDoc(d)}
                    onMouseEnter={(e) => (e.currentTarget.style.background = C.bg)} onMouseLeave={(e) => (e.currentTarget.style.background = 'transparent')}>
                    <td style={{ padding: '11px 14px', fontFamily: 'monospace', fontSize: 12.5, color: C.ink }}>{d.folio.toLocaleString('es-CL')}</td>
                    <td style={{ padding: '11px 14px' }}><Badge color={tipo.color} bg={tipo.color + '18'}>{tipo.label}</Badge></td>
                    <td style={{ padding: '11px 14px', fontWeight: 600, color: C.ink }}>{d.receptor}</td>
                    <td style={{ padding: '11px 14px', fontWeight: 700, color: C.ink, whiteSpace: 'nowrap' }}>{clp(d.monto)}</td>
                    <td style={{ padding: '11px 14px', color: C.sub, whiteSpace: 'nowrap' }}>{fmtDate(d.fechaEmision)}</td>
                    <td style={{ padding: '11px 14px' }}><Badge color={est.color} bg={est.bg} icon={est.icon}>{est.label}</Badge></td>
                    <td style={{ padding: '11px 14px' }}><Eye size={15} style={{ color: C.mut }} /></td>
                  </tr>
                );
              })}
              {pageRows.length === 0 && <tr><td colSpan={7} style={{ padding: '40px 14px', textAlign: 'center', color: C.mut }}>Sin documentos que calcen con la búsqueda.</td></tr>}
            </tbody>
          </table>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 16px', borderTop: `1px solid ${C.border}` }}>
          <span style={{ fontSize: 12, color: C.mut }}>{filtrados.length} documentos · página {page} de {totalPages}</span>
          <div style={{ display: 'flex', gap: 6 }}>
            <Btn variant="outline" onClick={() => setPage(Math.max(1, page - 1))} style={{ padding: '6px 12px', opacity: page === 1 ? 0.4 : 1 }}>Anterior</Btn>
            <Btn variant="outline" onClick={() => setPage(Math.min(totalPages, page + 1))} style={{ padding: '6px 12px', opacity: page === totalPages ? 0.4 : 1 }}>Siguiente</Btn>
          </div>
        </div>
      </div>

      {emitiendo && <EmitirModal borrador={emitiendo} onClose={() => setEmitiendo(null)} onConfirm={confirmarEmision} />}
      {selectedDoc && <DetailModal doc={selectedDoc} onClose={() => setSelectedDoc(null)} />}
    </div>
  );
}
