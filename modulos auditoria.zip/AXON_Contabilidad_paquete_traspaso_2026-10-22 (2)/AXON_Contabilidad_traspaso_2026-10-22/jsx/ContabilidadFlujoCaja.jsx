import React, { useState, useMemo } from 'react';
import {
  Wallet, Download, Plus, X, TrendingUp, TrendingDown, AlertTriangle, CheckCircle2,
  Info, Stethoscope, Building2, Coins, ArrowDownCircle, ArrowUpCircle
} from 'lucide-react';

/* =========================================================================
   DISEÑO — copiado 1:1 desde HISClinico_Layer1.jsx / demás secciones de
   Contabilidad, para que este archivo se pueda previsualizar de forma
   independiente.
   ========================================================================= */
const C = {
  bg: '#F4F6F9', card: '#FFFFFF', border: '#E2E8F0', borderD: '#CBD5E1',
  ink: '#16233E', sub: '#5B6B85', mut: '#94A3B8',
  pri: '#2E7D32', priL: '#EAF6EC',
  info: '#2563EB', infoL: '#EEF3FF',
  warn: '#B45309', warnL: '#FEF3E2',
  err: '#C62828', errL: '#FDECEC',
  vio: '#6D28D9', vioL: '#F2ECFB',
  teal: '#0E7490',
  r: 10, rSm: 7, rLg: 14,
  shadow: '0 1px 3px rgba(16,24,40,.06), 0 1px 2px rgba(16,24,40,.04)',
  font: "'Inter', -apple-system, 'Segoe UI', Roboto, sans-serif",
};

/* ═══════════════════════════════════════════════════════════════════════
   DE DÓNDE VIENEN LOS DATOS — esto es una COMPOSICIÓN, no una sección con
   datos propios como Balances. En producción, este archivo no genera su
   propio mock: recibe los arreglos `data` reales de Ingresos, Egresos,
   Honorarios Médicos y Honorarios Externos (mismo shape de fila que ya
   exportan esos archivos) y los transforma en una proyección de caja.

   Adquisiciones NO se incluye aparte a propósito: una OC "facturada" ya
   está destinada a pagarse vía Egresos (así quedó dicho en su propia
   pantalla: "el pago se rastrea en Egresos, no acá") — sumarla aquí
   también sería contar el mismo pago dos veces.
   ═══════════════════════════════════════════════════════════════════════ */

const HOY = new Date('2026-07-05T00:00:00'); // ancla simulada — en producción: new Date()
const HOY_ISO = HOY.toISOString().slice(0, 10);

const clp = (n) => (n < 0 ? '-$' : '$') + Math.round(Math.abs(n)).toLocaleString('es-CL');
const fmtDate = (iso) => new Date(iso + 'T00:00:00').toLocaleDateString('es-CL', { day: '2-digit', month: 'short' });
const fmtDateLarga = (iso) => new Date(iso + 'T00:00:00').toLocaleDateString('es-CL', { day: '2-digit', month: 'short', year: 'numeric' });
const addDays = (iso, n) => { const d = new Date(iso + 'T00:00:00'); d.setDate(d.getDate() + n); return d.toISOString().slice(0, 10); };
const diffDays = (a, b) => Math.round((new Date(b + 'T00:00:00') - new Date(a + 'T00:00:00')) / 86400000);

/* Días promedio de cobro/pago por origen — SUPUESTOS explícitos, no datos medidos
   todavía (a diferencia del DSO/DPO de Ingresos/Egresos, que sí se calculan de
   transacciones reales). Sirven para proyectar cuándo un pendiente se hace caja
   mientras no exista el dato real por pagador. Ajustables — quedan aquí, en un
   solo lugar, para no repetirlos sueltos en el código. */
const DIAS_COBRO_POR_PAGADOR = {
  fonasa_mai: 45, fonasa_mle: 45, isapre: 30, particular: 5, mutual: 30, internacional: 45,
  convenio_institucional: 30, // supuesto ilustrativo, similar a Isapre — ajustar por convenio real
};
const DIAS_PAGO_HONORARIOS_MEDICOS = 10; // desde fin del período trabajado
const DIAS_PAGO_HONORARIOS_EXTERNOS = 20; // desde la fecha de la operación, si no hay vencimiento propio

const ORIGENES = {
  ingresos_por_cobrar: { label: 'Ingresos por cobrar', color: '#2E7D32', icon: TrendingUp },
  egresos_por_pagar: { label: 'Egresos por pagar', color: '#C62828', icon: TrendingDown },
  honorarios_medicos: { label: 'Honorarios Médicos', color: '#6D28D9', icon: Stethoscope },
  honorarios_externos: { label: 'Honorarios Externos', color: '#0E7490', icon: Building2 },
  caja_chica: { label: 'Caja chica / boletería', color: '#B45309', icon: Coins },
};

// Ver ContabilidadHelpersCompartidos.js — versión canónica verificada de semaforo() (idéntica).
function semaforo(valor, metaEsMinimo, umbralBueno, umbralMalo) {
  const esBueno = metaEsMinimo ? valor >= umbralBueno : valor <= umbralBueno;
  const esMalo = metaEsMinimo ? valor < umbralMalo : valor > umbralMalo;
  if (esBueno) return C.pri;
  if (esMalo) return C.err;
  return C.warn;
}

/* ═══════════════════════════════════════════════════════════════════════
   COMPOSICIÓN — traduce filas "pendientes" de cada sección (mismo shape
   que ya usan Ingresos/Egresos/Honorarios) a movimientos de caja fechados.
   Estas 4 funciones son el punto de integración real: cuando esto se
   conecte, se les pasa el `data` real de cada archivo tal cual, filtrado
   a lo pendiente, sin tener que tocar el resto de esta sección.
   ═══════════════════════════════════════════════════════════════════════ */
function desdeIngresos(rows) {
  // Punto C del dossier: el copago se cobra EN el momento de la atención (caja/Transbank),
  // no espera el ciclo de cobro del pagador — solo la bonificación (lo que paga el
  // asegurador después) queda sujeta a DIAS_COBRO_POR_PAGADOR. Antes esta función trataba
  // el monto COMPLETO como demorado, sobreestimando cuánto falta por cobrar a futuro.
  const movimientos = [];
  rows.filter((r) => r.estado === 'facturado' || r.estado === 'pendiente').forEach((r) => {
    if (r.montoCopago > 0) {
      movimientos.push({
        id: 'mov_ing_copago_' + r.id, tipo: 'entrada', origen: 'ingresos_por_cobrar',
        descripcion: `${r.prestacion} — ${r.paciente || 'paciente'} (copago)`,
        monto: r.montoCopago, confirmado: false, fecha: r.fecha,
      });
    }
    if (r.montoBonificacion > 0) {
      movimientos.push({
        id: 'mov_ing_bonif_' + r.id, tipo: 'entrada', origen: 'ingresos_por_cobrar',
        descripcion: `${r.prestacion} — ${r.paciente || 'paciente'} (bonificación)`,
        monto: r.montoBonificacion, confirmado: false,
        fecha: addDays(r.fecha, DIAS_COBRO_POR_PAGADOR[r.pagador] ?? 30),
      });
    }
  });
  return movimientos;
}
function desdeEgresos(rows) {
  return rows.filter((r) => r.estado === 'pendiente' || r.estado === 'vencido').map((r) => ({
    id: 'mov_egr_' + r.id, tipo: 'salida', origen: 'egresos_por_pagar',
    descripcion: `${r.proveedor} — ${CATEGORIA_LABEL_EGR[r.categoria] || r.categoria}`,
    monto: r.monto, confirmado: false,
    // Un egreso ya vencido no tiene sentido proyectarlo a futuro — se asume que se
    // paga lo antes posible, así que aparece en el día de hoy de la proyección.
    fecha: r.estado === 'vencido' ? HOY_ISO : r.fechaVencimiento,
  }));
}
function desdeHonorariosMedicos(rows) {
  return rows.filter((r) => r.estado === 'pendiente' || r.estado === 'emitida').map((r) => ({
    id: 'mov_honm_' + r.id, tipo: 'salida', origen: 'honorarios_medicos',
    descripcion: `${r.profesional} — ${r.especialidad}`,
    monto: r.montoLiquido, confirmado: false,
    fecha: addDays(r.periodo + '-01', 30 + DIAS_PAGO_HONORARIOS_MEDICOS),
  }));
}
function desdeHonorariosExternos(rows) {
  return rows.filter((r) => r.estado === 'pendiente' || r.estado === 'emitido').map((r) => ({
    id: 'mov_hone_' + r.id, tipo: 'salida', origen: 'honorarios_externos',
    descripcion: `${r.proveedor}`,
    monto: r.montoBruto, confirmado: false,
    fecha: addDays(r.fecha, DIAS_PAGO_HONORARIOS_EXTERNOS),
  }));
}
// Solo para etiquetas legibles en desdeEgresos — evita importar CATEGORIAS completo.
const CATEGORIA_LABEL_EGR = { proveedores: 'Proveedores e Insumos', remuneraciones: 'Remuneraciones', honorarios: 'Honorarios', servicios: 'Servicios Básicos', arriendo: 'Arriendo y Mantención', impuestos: 'Impuestos', adquisiciones: 'Adquisiciones' };

/* ═══════════════════════════════════════════════════════════════════════
   PUERTA ETIQUETADA — recibirMovimientoCaja
   Punto de entrada para cuando exista un módulo de caja real en el
   mostrador/admisión (med_bonos, hoy pendiente según la hoja de ruta).
   Mientras tanto, el formulario "Registrar movimiento de caja" de esta
   misma pantalla llama a esta función a mano.
   ═══════════════════════════════════════════════════════════════════════ */
export function recibirMovimientoCaja({ tipo, monto, descripcion, fecha = HOY_ISO }, idBase = Date.now()) {
  return { id: 'mov_caja_' + idBase, tipo, origen: 'caja_chica', descripcion, monto, confirmado: true, fecha };
}

/* ═══════════════════════════════════════════════════════════════════════
   PUERTA ETIQUETADA — calcularProyeccionFlujoCaja
   Función pura: recibe saldo inicial + lista de movimientos ya fechados
   (el resultado de las funciones de composición de arriba, más lo que
   entre por recibirMovimientoCaja) y devuelve la proyección día a día y
   los indicadores de gestión. Lista para que Alta Dirección la consuma
   con la misma forma que las demás puertas etiquetadas de Contabilidad.
   ═══════════════════════════════════════════════════════════════════════ */
export function calcularProyeccionFlujoCaja({ saldoInicial, movimientos, horizonteDias = 30, hoy = HOY_ISO }) {
  const dias = [];
  let saldoAcumulado = saldoInicial;
  let puntoQuiebre = null;
  let saldoMinimo = saldoInicial, fechaSaldoMinimo = hoy;

  for (let i = 0; i < horizonteDias; i++) {
    const fecha = addDays(hoy, i);
    const delDia = movimientos.filter((m) => m.fecha === fecha);
    const entradas = delDia.filter((m) => m.tipo === 'entrada').reduce((s, m) => s + m.monto, 0);
    const salidas = delDia.filter((m) => m.tipo === 'salida').reduce((s, m) => s + m.monto, 0);
    const neto = entradas - salidas;
    saldoAcumulado += neto;
    if (saldoAcumulado < saldoMinimo) { saldoMinimo = saldoAcumulado; fechaSaldoMinimo = fecha; }
    if (saldoAcumulado < 0 && puntoQuiebre === null) puntoQuiebre = fecha;
    dias.push({ fecha, entradas, salidas, neto, saldoAcumulado });
  }

  const totalEntradas = dias.reduce((s, d) => s + d.entradas, 0);
  const totalSalidas = dias.reduce((s, d) => s + d.salidas, 0);
  const saldoFinal = dias[dias.length - 1]?.saldoAcumulado ?? saldoInicial;

  const porOrigen = Object.keys(ORIGENES).map((id) => ({
    id, monto: movimientos.filter((m) => m.origen === id).reduce((s, m) => s + (m.tipo === 'entrada' ? m.monto : -m.monto), 0),
  }));

  return {
    seccion: 'flujo_caja', saldoInicial, saldoFinal, horizonteDias,
    totalEntradas, totalSalidas, saldoMinimo, fechaSaldoMinimo, puntoQuiebre,
    dias, porOrigen, movimientosCount: movimientos.length,
  };
}

/* Agrupa la proyección diaria en semanas — más legible que 30-90 filas sueltas. */
function agruparPorSemana(dias) {
  const semanas = [];
  for (let i = 0; i < dias.length; i += 7) {
    const tramo = dias.slice(i, i + 7);
    semanas.push({
      desde: tramo[0].fecha, hasta: tramo[tramo.length - 1].fecha,
      entradas: tramo.reduce((s, d) => s + d.entradas, 0),
      salidas: tramo.reduce((s, d) => s + d.salidas, 0),
      saldoCierre: tramo[tramo.length - 1].saldoAcumulado,
      tuvoNegativo: tramo.some((d) => d.saldoAcumulado < 0),
    });
  }
  return semanas;
}

/* ------------------------------ mock data -------------------------------- */
/* Representativo, no exhaustivo — en producción esto lo reemplaza el `data`
   real de cada sección (ver comentario grande más arriba). Fechado hacia
   ADELANTE desde hoy, a diferencia de las demás secciones (que miran atrás
   desde enero) — acá el objetivo es proyectar, no reportar el histórico. */
const PAGADORES_MOCK = ['fonasa_mai', 'fonasa_mle', 'isapre', 'particular', 'mutual'];
// Mismos valores verificados que PARAMS_COPAGO_PCT en Ingresos (Punto A del dossier, resuelto
// 2026-07-20) — se duplican acá porque este archivo es standalone y no importa de Ingresos.
const PARAMS_COPAGO_PCT_MOCK = { fonasa_mai: 0, fonasa_mle: 0.35, isapre: 0.25, particular: 1.00, mutual: 0 };
function genIngresosPendientesMock() {
  const rows = []; let seed = 40;
  for (let i = 0; i < 22; i++) {
    seed += 13;
    const pagador = PAGADORES_MOCK[seed % PAGADORES_MOCK.length];
    const monto = 80000 + (seed * 3701) % 3200000;
    const pctCopago = PARAMS_COPAGO_PCT_MOCK[pagador] ?? 1;
    // Topado a `monto` — mismo fix de redondeo aplicado en calcularDesgloseCopago() de Ingresos.
    const montoCopago = Math.min(monto, Math.round((monto * pctCopago) / 100) * 100);
    const montoBonificacion = monto - montoCopago;
    rows.push({ id: 1000 + i, fecha: addDays(HOY_ISO, -(seed % 20)), prestacion: 'Prestación clínica', paciente: 'Paciente ' + (i + 1), monto, montoCopago, montoBonificacion, pagador, estado: seed % 4 === 0 ? 'pendiente' : 'facturado' });
  }
  return rows;
}
function genEgresosPendientesMock() {
  const rows = []; let seed = 60;
  const categorias = Object.keys(CATEGORIA_LABEL_EGR);
  const proveedores = ['Farmadistribución Andina S.A.', 'ServiClean Hospitalario SpA', 'CGE Distribución', 'Aguas Andinas S.A.', 'Tesorería General de la República'];
  for (let i = 0; i < 18; i++) {
    seed += 17;
    const categoria = categorias[seed % categorias.length];
    const monto = 90000 + (seed * 4211) % 2800000;
    const diasVenc = (seed % 25) - 8; // algunos ya vencidos (negativo), la mayoría a futuro
    rows.push({ id: 2000 + i, proveedor: proveedores[seed % proveedores.length], categoria, monto, fechaVencimiento: addDays(HOY_ISO, diasVenc), estado: diasVenc < 0 ? 'vencido' : 'pendiente' });
  }
  return rows;
}
function genHonorariosMedicosPendientesMock() {
  const rows = []; let seed = 80;
  const profesionales = ['Dr. Francisco Contreras', 'Dra. Paula Vásquez', 'Klga. Antonia Morales', 'Enf. Josefa Muñoz', 'Dr. Sebastián Riquelme'];
  for (let i = 0; i < 10; i++) {
    seed += 19;
    rows.push({ id: 3000 + i, profesional: profesionales[seed % profesionales.length], especialidad: 'Atención clínica', periodo: '2026-07', montoLiquido: 700000 + (seed * 2917) % 3800000, estado: 'emitida' });
  }
  return rows;
}
function genHonorariosExternosPendientesMock() {
  const rows = []; let seed = 95;
  const proveedores = ['Estudio Jurídico Bravo & Asociados', 'Auditores Consultores del Pacífico Ltda.', 'Soluciones TI Corporativas SpA'];
  for (let i = 0; i < 6; i++) {
    seed += 23;
    rows.push({ id: 4000 + i, proveedor: proveedores[seed % proveedores.length], fecha: addDays(HOY_ISO, -(seed % 15)), montoBruto: 900000 + (seed * 3301) % 2500000, estado: 'pendiente' });
  }
  return rows;
}
function genCajaChicaMock() {
  return [
    recibirMovimientoCaja({ tipo: 'entrada', monto: 145000, descripcion: 'Boletería del día — copagos particulares', fecha: HOY_ISO }, 1),
    recibirMovimientoCaja({ tipo: 'salida', monto: 38000, descripcion: 'Caja chica — insumos de aseo urgentes', fecha: HOY_ISO }, 2),
  ];
}

const SALDO_INICIAL_MOCK = 42000000;

/* ------------------------------- átomos ---------------------------------- */
const Badge = ({ color, bg, icon: Icon, children }) => (
  <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, padding: '3px 9px', borderRadius: 999, fontSize: 12, fontWeight: 600, color, background: bg, whiteSpace: 'nowrap' }}>
    {Icon && <Icon size={12} />}{children}
  </span>
);
const Btn = ({ variant = 'ghost', icon: Icon, children, onClick, style, type = 'button' }) => {
  const variants = { primary: { background: C.pri, color: '#fff' }, outline: { background: '#fff', color: C.ink, border: `1px solid ${C.border}` }, ghost: { background: 'transparent', color: C.sub } };
  return (
    <button type={type} onClick={onClick}
      onMouseEnter={(e) => (e.currentTarget.style.filter = 'brightness(0.96)')} onMouseLeave={(e) => (e.currentTarget.style.filter = 'none')}
      style={{ display: 'inline-flex', alignItems: 'center', gap: 7, padding: '9px 15px', borderRadius: C.rSm, fontSize: 13.5, fontWeight: 600, cursor: 'pointer', border: '1px solid transparent', fontFamily: C.font, ...variants[variant], ...style }}>
      {Icon && <Icon size={15} />}{children}
    </button>
  );
};
const KPICard = ({ label, value, sub, icon: Icon, accent }) => (
  <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, padding: '16px 18px', boxShadow: C.shadow, flex: 1, minWidth: 0 }}>
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
      <span style={{ fontSize: 12.5, color: C.sub, fontWeight: 600 }}>{label}</span>
      <div style={{ width: 28, height: 28, borderRadius: 8, background: accent + '18', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon size={14} style={{ color: accent }} /></div>
    </div>
    <div style={{ fontSize: 22, fontWeight: 700, color: C.ink, letterSpacing: -0.3 }}>{value}</div>
    {sub && <div style={{ fontSize: 12, color: C.mut, marginTop: 3 }}>{sub}</div>}
  </div>
);
const FieldLabel = ({ children }) => <label style={{ fontSize: 11.5, fontWeight: 600, color: C.sub, marginBottom: 5, display: 'block' }}>{children}</label>;
const inputStyle = { width: '100%', padding: '8px 10px', borderRadius: C.rSm, border: `1px solid ${C.border}`, fontSize: 13.5, fontFamily: C.font, color: C.ink, outline: 'none', boxSizing: 'border-box', background: '#fff' };

function BreakdownCard({ title, items, total }) {
  return (
    <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, padding: 18, boxShadow: C.shadow, flex: 1, minWidth: 0 }}>
      <div style={{ fontSize: 13, fontWeight: 700, color: C.ink, marginBottom: 14 }}>{title}</div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 11 }}>
        {items.map(([key, meta, monto]) => {
          const pct = total ? Math.round((Math.abs(monto) / total) * 100) : 0;
          const Icon = meta.icon;
          return (
            <div key={key}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12.5, marginBottom: 4 }}>
                <span style={{ display: 'flex', alignItems: 'center', gap: 6, color: C.ink, fontWeight: 500 }}><Icon size={13} style={{ color: meta.color }} /> {meta.label}</span>
                <span style={{ color: monto < 0 ? C.err : C.pri, fontWeight: 600 }}>{monto < 0 ? '-' : '+'}{clp(monto)}</span>
              </div>
              <div style={{ height: 6, borderRadius: 4, background: C.bg, overflow: 'hidden' }}><div style={{ height: '100%', width: pct + '%', background: meta.color, borderRadius: 4 }} /></div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function NuevoMovimientoModal({ onClose, onSave }) {
  const [form, setForm] = useState({ tipo: 'entrada', monto: '', descripcion: '' });
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });
  const puedeGuardar = form.descripcion.trim() && Number(form.monto) > 0;
  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(16,24,40,.45)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100, padding: 20 }} onClick={onClose}>
      <div style={{ background: '#fff', borderRadius: C.rLg, width: 420, maxWidth: '100%', boxShadow: '0 20px 50px rgba(16,24,40,.25)' }} onClick={(e) => e.stopPropagation()}>
        <div style={{ padding: '18px 22px', borderBottom: `1px solid ${C.border}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ fontSize: 15, fontWeight: 700, color: C.ink }}>Registrar movimiento de caja</div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: C.mut }}><X size={18} /></button>
        </div>
        <div style={{ padding: 22, display: 'flex', flexDirection: 'column', gap: 13 }}>
          <div style={{ fontSize: 11.5, color: C.mut, background: C.bg, padding: 10, borderRadius: C.rSm }}>
            Uso manual, mientras no exista un módulo de caja/boletería en admisión (`med_bonos`, hoy pendiente). Cuando exista, esto se reemplaza por eventos automáticos vía la misma función <code style={{ fontFamily: 'monospace' }}>recibirMovimientoCaja()</code>.
          </div>
          <div>
            <FieldLabel>Tipo</FieldLabel>
            <div style={{ display: 'flex', gap: 8 }}>
              <button onClick={() => setForm({ ...form, tipo: 'entrada' })} style={{ flex: 1, padding: '8px', borderRadius: C.rSm, border: `1px solid ${form.tipo === 'entrada' ? C.pri : C.border}`, background: form.tipo === 'entrada' ? C.priL : '#fff', color: form.tipo === 'entrada' ? C.pri : C.sub, fontWeight: 600, cursor: 'pointer', fontSize: 13 }}>Entrada</button>
              <button onClick={() => setForm({ ...form, tipo: 'salida' })} style={{ flex: 1, padding: '8px', borderRadius: C.rSm, border: `1px solid ${form.tipo === 'salida' ? C.err : C.border}`, background: form.tipo === 'salida' ? C.errL : '#fff', color: form.tipo === 'salida' ? C.err : C.sub, fontWeight: 600, cursor: 'pointer', fontSize: 13 }}>Salida</button>
            </div>
          </div>
          <div><FieldLabel>Descripción</FieldLabel><input style={inputStyle} value={form.descripcion} onChange={set('descripcion')} placeholder="Ej: Boletería del día — copagos" /></div>
          <div><FieldLabel>Monto (CLP)</FieldLabel><input style={inputStyle} type="number" value={form.monto} onChange={set('monto')} placeholder="145000" /></div>
        </div>
        <div style={{ padding: '14px 22px', borderTop: `1px solid ${C.border}`, display: 'flex', justifyContent: 'flex-end', gap: 10 }}>
          <Btn variant="ghost" onClick={onClose}>Cancelar</Btn>
          <Btn variant="primary" icon={Plus} onClick={() => puedeGuardar && onSave(form)} style={{ opacity: puedeGuardar ? 1 : 0.5 }}>Registrar</Btn>
        </div>
      </div>
    </div>
  );
}

/* --------------------------------- vista principal ------------------------------------ */
export default function ContabilidadFlujoCaja({ addToast }) {
  const toast = addToast || ((msg) => console.log(msg));
  const [horizonte, setHorizonte] = useState(30);
  const [showNew, setShowNew] = useState(false);
  const [movimientosCaja, setMovimientosCaja] = useState(genCajaChicaMock);

  // Composición: mock representativo de cada fuente -> movimientos fechados,
  // exactamente lo que en producción hacen las 4 funciones desdeX() con datos reales.
  const movimientos = useMemo(() => [
    ...desdeIngresos(genIngresosPendientesMock()),
    ...desdeEgresos(genEgresosPendientesMock()),
    ...desdeHonorariosMedicos(genHonorariosMedicosPendientesMock()),
    ...desdeHonorariosExternos(genHonorariosExternosPendientesMock()),
    ...movimientosCaja,
  ], [movimientosCaja]);

  // "Puerta etiquetada" principal de esta sección.
  const proy = useMemo(() => calcularProyeccionFlujoCaja({ saldoInicial: SALDO_INICIAL_MOCK, movimientos, horizonteDias: horizonte, hoy: HOY_ISO }), [movimientos, horizonte]);
  const semanas = useMemo(() => agruparPorSemana(proy.dias), [proy.dias]);
  const porOrigenDisplay = proy.porOrigen.filter((o) => o.monto !== 0).map((o) => [o.id, ORIGENES[o.id], o.monto]).sort((a, b) => Math.abs(b[2]) - Math.abs(a[2]));
  const totalMovimientoAbsoluto = proy.porOrigen.reduce((s, o) => s + Math.abs(o.monto), 0);

  const handleNuevoMovimiento = (form) => {
    const mov = recibirMovimientoCaja({ tipo: form.tipo, monto: Number(form.monto), descripcion: form.descripcion }, movimientosCaja.length + 100);
    setMovimientosCaja([...movimientosCaja, mov]);
    setShowNew(false);
    toast('Movimiento de caja registrado');
  };

  const exportarCSV = () => {
    const header = ['Semana desde', 'Semana hasta', 'Entradas', 'Salidas', 'Saldo al cierre'];
    const lines = semanas.map((s) => [s.desde, s.hasta, s.entradas, s.salidas, s.saldoCierre].join(';'));
    const blob = new Blob([header.join(';') + '\n' + lines.join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = `flujo_caja_${horizonte}d.csv`; a.click();
    URL.revokeObjectURL(url);
    toast('Archivo CSV descargado');
  };

  return (
    <div style={{ fontFamily: C.font, background: C.bg, minHeight: '100%', padding: 22 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 14, flexWrap: 'wrap', gap: 12 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
          <div style={{ width: 34, height: 34, borderRadius: 9, background: C.priL, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Wallet size={17} style={{ color: C.pri }} /></div>
          <div>
            <div style={{ fontSize: 18, fontWeight: 700, color: C.ink }}>Control de Flujo de Caja</div>
            <div style={{ fontSize: 12.5, color: C.mut }}>Proyección hacia adelante — compuesta desde Ingresos, Egresos y Honorarios</div>
          </div>
        </div>
        <div style={{ display: 'flex', gap: 9 }}>
          <Btn variant="outline" icon={Download} onClick={exportarCSV}>Exportar CSV</Btn>
          <Btn variant="primary" icon={Plus} onClick={() => setShowNew(true)}>Registrar movimiento de caja</Btn>
        </div>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: 7, background: '#fff', border: `1px solid ${C.border}`, borderRadius: C.rSm, padding: '9px 13px', marginBottom: 18, fontSize: 12, color: C.sub, flexWrap: 'wrap' }}>
        <Info size={13} style={{ color: C.vio }} />
        Supuestos de días para hacer caja (ajustables): Fonasa/Internacional 45 días · Isapre/Mutual 30 días · Particular 5 días · Honorarios Médicos 10 días tras cierre de período · Honorarios Externos 20 días. El copago (se cobra en el momento de la atención) no queda sujeto a este desfase — solo la bonificación que paga el asegurador después. Adquisiciones no se cuenta aparte — su pago ya viaja por Egresos una vez facturada.
      </div>

      <div style={{ fontSize: 11.5, fontWeight: 700, color: C.mut, textTransform: 'uppercase', letterSpacing: 0.4, marginBottom: 8 }}>Posición de caja</div>
      <div style={{ display: 'flex', gap: 14, marginBottom: 18, flexWrap: 'wrap' }}>
        <KPICard label="Saldo actual" value={clp(proy.saldoInicial)} sub={`Al ${fmtDateLarga(HOY_ISO)}`} icon={Wallet} accent={C.ink} />
        <KPICard label={`Saldo proyectado a ${horizonte} días`} value={clp(proy.saldoFinal)} sub={proy.saldoFinal >= proy.saldoInicial ? 'Sube respecto a hoy' : 'Baja respecto a hoy'} icon={proy.saldoFinal >= proy.saldoInicial ? TrendingUp : TrendingDown} accent={semaforo(proy.saldoFinal, true, proy.saldoInicial * 0.5, 0)} />
        <KPICard label="Punto más bajo proyectado" value={clp(proy.saldoMinimo)} sub={fmtDateLarga(proy.fechaSaldoMinimo)} icon={ArrowDownCircle} accent={semaforo(proy.saldoMinimo, true, proy.saldoInicial * 0.2, 0)} />
        <KPICard label="Punto de quiebre" value={proy.puntoQuiebre ? fmtDateLarga(proy.puntoQuiebre) : 'Sin quiebre'} sub={proy.puntoQuiebre ? 'Primer día con saldo negativo' : `Saldo positivo en los ${horizonte} días`} icon={proy.puntoQuiebre ? AlertTriangle : CheckCircle2} accent={proy.puntoQuiebre ? C.err : C.pri} />
      </div>

      {proy.puntoQuiebre && (
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, background: C.errL, border: `1px solid #F5C6C6`, borderRadius: C.rSm, padding: '10px 14px', marginBottom: 18, fontSize: 13, color: C.err, fontWeight: 600 }}>
          <AlertTriangle size={15} /> El saldo proyectado se vuelve negativo el {fmtDateLarga(proy.puntoQuiebre)} si no cambia nada entre hoy y esa fecha.
        </div>
      )}

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
        <div style={{ fontSize: 11.5, fontWeight: 700, color: C.mut, textTransform: 'uppercase', letterSpacing: 0.4 }}>Proyección semanal</div>
        <div style={{ display: 'flex', background: C.card, border: `1px solid ${C.border}`, borderRadius: C.rSm, padding: 3 }}>
          {[30, 60, 90].map((h) => (
            <button key={h} onClick={() => setHorizonte(h)} style={{ padding: '5px 12px', borderRadius: 5, border: 'none', cursor: 'pointer', fontSize: 12, fontWeight: 600, background: horizonte === h ? C.pri : 'transparent', color: horizonte === h ? '#fff' : C.sub }}>{h}d</button>
          ))}
        </div>
      </div>

      <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, boxShadow: C.shadow, overflow: 'hidden', marginBottom: 18 }}>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
            <thead>
              <tr style={{ background: C.bg, textAlign: 'left' }}>
                {['Semana', 'Entradas', 'Salidas', 'Neto', 'Saldo al cierre'].map((h) => (
                  <th key={h} style={{ padding: '10px 14px', fontSize: 11.5, fontWeight: 700, color: C.sub, textTransform: 'uppercase', letterSpacing: 0.3, whiteSpace: 'nowrap' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {semanas.map((s, i) => (
                <tr key={i} style={{ borderTop: `1px solid ${C.border}`, background: s.tuvoNegativo ? C.errL : 'transparent' }}>
                  <td style={{ padding: '11px 14px', color: C.ink, whiteSpace: 'nowrap' }}>{fmtDate(s.desde)} – {fmtDate(s.hasta)}</td>
                  <td style={{ padding: '11px 14px', color: C.pri, fontWeight: 600, whiteSpace: 'nowrap' }}>+{clp(s.entradas)}</td>
                  <td style={{ padding: '11px 14px', color: C.err, fontWeight: 600, whiteSpace: 'nowrap' }}>-{clp(s.salidas)}</td>
                  <td style={{ padding: '11px 14px', fontWeight: 600, whiteSpace: 'nowrap', color: (s.entradas - s.salidas) >= 0 ? C.pri : C.err }}>{(s.entradas - s.salidas) >= 0 ? '+' : ''}{clp(s.entradas - s.salidas)}</td>
                  <td style={{ padding: '11px 14px', fontWeight: 700, whiteSpace: 'nowrap', color: s.saldoCierre < 0 ? C.err : C.ink }}>{clp(s.saldoCierre)}{s.tuvoNegativo && <AlertTriangle size={12} style={{ marginLeft: 5, verticalAlign: 'middle', color: C.err }} />}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div style={{ display: 'flex', gap: 14, marginBottom: 18, flexWrap: 'wrap' }}>
        <BreakdownCard title="Movimiento neto por origen" items={porOrigenDisplay} total={totalMovimientoAbsoluto} />
        <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, padding: 18, boxShadow: C.shadow, flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 13, fontWeight: 700, color: C.ink, marginBottom: 12 }}>Movimientos de caja chica registrados</div>
          {movimientosCaja.length === 0 && <div style={{ fontSize: 12.5, color: C.mut }}>Sin movimientos manuales todavía.</div>}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {movimientosCaja.map((m) => (
              <div key={m.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: 12.5 }}>
                <span style={{ display: 'flex', alignItems: 'center', gap: 6, color: C.ink }}>
                  {m.tipo === 'entrada' ? <ArrowUpCircle size={13} style={{ color: C.pri }} /> : <ArrowDownCircle size={13} style={{ color: C.err }} />}
                  {m.descripcion}
                </span>
                <span style={{ fontWeight: 600, color: m.tipo === 'entrada' ? C.pri : C.err }}>{m.tipo === 'entrada' ? '+' : '-'}{clp(m.monto)}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {showNew && <NuevoMovimientoModal onClose={() => setShowNew(false)} onSave={handleNuevoMovimiento} />}
    </div>
  );
}
