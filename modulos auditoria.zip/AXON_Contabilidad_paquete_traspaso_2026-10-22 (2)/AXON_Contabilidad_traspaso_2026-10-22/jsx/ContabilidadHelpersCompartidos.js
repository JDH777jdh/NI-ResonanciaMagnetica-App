/* ═══════════════════════════════════════════════════════════════════════
   ContabilidadHelpersCompartidos.js
   Versión canónica de 2 funciones que hoy viven duplicadas a propósito en
   9 de los 13 archivos de Contabilidad (cada archivo es standalone para
   poder previsualizarse solo — ver AXON_Contabilidad_Dossier_Tecnico...md
   Parte 0). Este archivo NO reemplaza las copias existentes todavía — es
   la fuente única a importar el día que el módulo se integre a producción
   real (ahí sí se borra el bloque duplicado de cada .jsx, tal como ya
   estaba planeado desde el dossier original).

   Verificado 2026-09-04 contra el código real de los 9 archivos (no de
   memoria) antes de declarar esta versión como la oficial.
   ═══════════════════════════════════════════════════════════════════════ */

/**
 * Dígito verificador de RUT chileno — Módulo 11.
 * Idéntico en Ingresos, Honorarios Médicos y Honorarios Externos como
 * función separada; Facturación tiene la misma lógica inlineada dentro de
 * su propio fakeRUT (por eso no la expone como función aparte).
 */
export function calcDV(rutBody) {
  let suma = 0, mult = 2;
  for (let i = rutBody.length - 1; i >= 0; i--) {
    suma += parseInt(rutBody[i], 10) * mult;
    mult = mult === 7 ? 2 : mult + 1;
  }
  const resto = 11 - (suma % 11);
  if (resto === 11) return '0';
  if (resto === 10) return 'K';
  return String(resto);
}

/**
 * Genera un RUT chileno con formato válido (XX.XXX.XXX-DV) para datos de
 * ejemplo. `base` y `multiplicador` son parámetros a propósito — cada
 * archivo original los fija distinto para que no aparezcan los mismos RUT
 * falsos repetidos entre pacientes, doctores y proveedores. Los valores
 * default reproducen exactamente lo que ya usan Ingresos y Facturación.
 *
 * Tabla de equivalencia con los 4 archivos originales (para no perder el
 * comportamiento visual de cada uno al migrar):
 *   Ingresos               → fakeRUT(seed)                    // base 9.000.000, mult 7919
 *   Facturación             → fakeRUT(seed)                    // base 9.000.000, mult 7919 (idéntico a Ingresos)
 *   Honorarios Médicos     → fakeRUT(seed, 7000000, 6079)
 *   Honorarios Externos    → fakeRUT(seed, 6000000, 5231)
 */
export function fakeRUT(seed, base = 9000000, multiplicador = 7919) {
  const body = String(base + (seed * multiplicador) % 8900000);
  return body.slice(0, 2) + '.' + body.slice(2, 5) + '.' + body.slice(5) + '-' + calcDV(body);
}

/**
 * Semáforo de KPI (verde/ámbar/rojo). Idéntico en 8 de 9 archivos que ya
 * lo usan (Egresos, Honorarios Médicos, Honorarios Externos, Facturación,
 * Adquisiciones, Flujo de Caja, Obligaciones Tributarias, Conciliación
 * Bancaria) — todos vía los tokens de diseño C.pri/C.err/C.warn.
 *
 * CORREGIDO respecto a Ingresos (2026-09-04): ese archivo tenía hex fijo
 * (#2E7D32/#C62828/#B45309) en vez de los tokens — mismos colores exactos,
 * pero hardcodeados en vez de usar C.*. Esta versión usa los tokens, que
 * es el patrón correcto y mayoritario. Requiere que el archivo que la
 * importe tenga definido su objeto de tokens `C` (C.pri/C.err/C.warn).
 *
 * @param {number} valor - el valor del KPI a evaluar.
 * @param {boolean} metaEsMinimo - true si "más alto es mejor" (ej. tasa de
 *   facturación); false si "más bajo es mejor" (ej. % vencido).
 * @param {number} umbralBueno - umbral para pintar verde.
 * @param {number} umbralMalo - umbral para pintar rojo.
 */
export function semaforo(valor, metaEsMinimo, umbralBueno, umbralMalo, C) {
  const esBueno = metaEsMinimo ? valor >= umbralBueno : valor <= umbralBueno;
  const esMalo = metaEsMinimo ? valor < umbralMalo : valor > umbralMalo;
  if (esBueno) return C.pri;
  if (esMalo) return C.err;
  return C.warn;
}
