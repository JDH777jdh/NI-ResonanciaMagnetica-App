import React, { useState, useMemo } from 'react';
import {
  Landmark, Download, X, CheckCircle2, Clock, AlertTriangle, Info,
  ArrowDownCircle, ArrowUpCircle, Link2, Wand2, Plus, Search, Percent
} from 'lucide-react';

/* =========================================================================
   DISEÑO — copiado 1:1 desde HISClinico_Layer1.jsx / demás secciones de
   Contabilidad, para que este archivo se pueda previsualizar de forma
   independiente.
   ========================================================================= */
const C = {
  bg: '#F4F6F9', card: '#FFFFFF', border: '#E2E8F0', borderD: '#CBD5E1',
  ink: '#16233E', sub: '#5B6B85', mut: '#94A3B8',
  pri: '#2E7D32', priL: '#EAF6EC',
  info: '#2563EB', infoL: '#EEF3FF',
  warn: '#B45309', warnL: '#FEF3E2',
  err: '#C62828', errL: '#FDECEC',
  vio: '#6D28D9', vioL: '#F2ECFB',
  teal: '#0E7490',
  r: 10, rSm: 7, rLg: 14,
  shadow: '0 1px 3px rgba(16,24,40,.06), 0 1px 2px rgba(16,24,40,.04)',
  font: "'Inter', -apple-system, 'Segoe UI', Roboto, sans-serif",
};

const HOY = new Date('2026-07-05T00:00:00');
const HOY_ISO = HOY.toISOString().slice(0, 10);
const clp = (n) => (n < 0 ? '-$' : '$') + Math.round(Math.abs(n)).toLocaleString('es-CL');
const fmtDate = (iso) => new Date(iso + 'T00:00:00').toLocaleDateString('es-CL', { day: '2-digit', month: 'short', year: 'numeric' });
const addDays = (iso, n) => { const d = new Date(iso + 'T00:00:00'); d.setDate(d.getDate() + n); return d.toISOString().slice(0, 10); };
const diffDays = (a, b) => Math.round((new Date(b + 'T00:00:00') - new Date(a + 'T00:00:00')) / 86400000);
// Ver ContabilidadHelpersCompartidos.js — versión canónica verificada de semaforo() (idéntica).
function semaforo(valor, metaEsMinimo, umbralBueno, umbralMalo) {
  const esBueno = metaEsMinimo ? valor >= umbralBueno : valor <= umbralBueno;
  const esMalo = metaEsMinimo ? valor < umbralMalo : valor > umbralMalo;
  if (esBueno) return C.pri;
  if (esMalo) return C.err;
  return C.warn;
}

/* Fonasa/Isapre no pagan bono por bono — liquidan en LOTE, un solo depósito
   que cubre decenas de bonificaciones a la vez. Por eso la conciliación acá
   NO es 1 a 1 (un movimiento bancario = un ingreso): es N a 1 (varios
   ingresos pendientes = un solo depósito). El motor de match tiene que
   soportar selección múltiple, no solo emparejar de a pares. */
const ORIGENES_BANCO = {
  fonasa: { label: 'Fonasa (liquidación)', color: '#2563EB', icon: ArrowDownCircle },
  isapre: { label: 'Isapre (liquidación)', color: '#6D28D9', icon: ArrowDownCircle },
  transferencia_particular: { label: 'Transferencia particular', color: '#0E7490', icon: ArrowDownCircle },
  comision_bancaria: { label: 'Comisión bancaria', color: '#C62828', icon: ArrowUpCircle },
  interes_ganado: { label: 'Interés ganado', color: '#2E7D32', icon: ArrowDownCircle },
};

/* ═══════════════════════════════════════════════════════════════════════
   COMPOSICIÓN — misma idea que Flujo de Caja y Facturación: no se inventan
   pendientes propios, se traducen filas de Ingresos con estado 'pagado'
   (ya cobradas, pero todavía no confirmadas contra el banco — 'conciliado'
   es el estado que sigue, y es literalmente lo que esta pantalla produce).
   ═══════════════════════════════════════════════════════════════════════ */
function desdeIngresosPagados(rows) {
  return rows.filter((r) => r.estado === 'pagado').map((r) => ({
    id: 'pend_' + r.id,
    origenId: r.id,
    fecha: r.fecha,
    descripcion: `${r.prestacion} — ${r.paciente}`,
    monto: r.monto,
    pagador: r.pagador,
    isapreNombre: r.isapreNombre,
  }));
}

/* ═══════════════════════════════════════════════════════════════════════
   PUERTA ETIQUETADA — sugerirConciliaciones
   Heurística simple: para cada movimiento bancario sin conciliar, busca
   combinaciones de pendientes del MISMO origen (incluso pagador/isapre)
   cuya suma calce exacta con el monto del depósito. No es Machine
   Learning — es lo que un contador haría a mano, automatizado: agrupar
   por pagador y sumar hasta que calce.
   ═══════════════════════════════════════════════════════════════════════ */
export function sugerirConciliaciones(movimientos, pendientes) {
  const sugerencias = [];
  movimientos.filter((m) => !m.conciliado && m.tipo === 'abono').forEach((mov) => {
    const candidatos = pendientes.filter((p) => {
      if (mov.origen === 'fonasa') return ['fonasa_mai', 'fonasa_mle'].includes(p.pagador);
      if (mov.origen === 'isapre') return p.pagador === 'isapre' && (!mov.isapreNombre || p.isapreNombre === mov.isapreNombre);
      if (mov.origen === 'transferencia_particular') return p.pagador === 'particular';
      return false;
    });
    // Suma acumulada simple ordenada por fecha — encuentra el primer subconjunto que calce exacto.
    let acumulado = 0; const elegidos = [];
    for (const c of candidatos.sort((a, b) => (a.fecha < b.fecha ? -1 : 1))) {
      if (acumulado + c.monto <= mov.monto) { elegidos.push(c.id); acumulado += c.monto; }
      if (acumulado === mov.monto) break;
    }
    if (acumulado === mov.monto && elegidos.length > 0) {
      sugerencias.push({ movimientoId: mov.id, pendienteIds: elegidos, montoTotal: acumulado });
    }
  });
  return sugerencias;
}

/* ═══════════════════════════════════════════════════════════════════════
   PUERTA ETIQUETADA — calcularKPIsConciliacion
   ═══════════════════════════════════════════════════════════════════════ */
export function calcularKPIsConciliacion(movimientos, pendientes) {
  const totalBanco = movimientos.reduce((s, m) => s + (m.tipo === 'abono' ? m.monto : -m.monto), 0);
  const conciliados = movimientos.filter((m) => m.conciliado);
  const sinConciliar = movimientos.filter((m) => !m.conciliado);
  const montoConciliado = conciliados.reduce((s, m) => s + m.monto, 0);
  const montoSinConciliar = sinConciliar.reduce((s, m) => s + m.monto, 0);
  const tasaConciliacion = movimientos.length ? Math.round((conciliados.length / movimientos.length) * 100) : 100;

  const pendientesSinAsignar = pendientes.filter((p) => !p.conciliadoConId);
  const montoPendienteLibros = pendientesSinAsignar.reduce((s, p) => s + p.monto, 0);

  const comisiones = movimientos.filter((m) => m.origen === 'comision_bancaria').reduce((s, m) => s + m.monto, 0);

  const porOrigen = Object.keys(ORIGENES_BANCO).map((id) => ({ id, monto: movimientos.filter((m) => m.origen === id).reduce((s, m) => s + m.monto, 0) }));

  return {
    seccion: 'conciliacion_bancaria', totalBanco, montoConciliado, montoSinConciliar,
    tasaConciliacion, sinConciliarCount: sinConciliar.length,
    montoPendienteLibros, pendientesSinAsignarCount: pendientesSinAsignar.length,
    comisiones, porOrigen,
  };
}

/* ------------------------------ mock data -------------------------------- */
const NOMBRES = ['María José González', 'Pedro Muñoz', 'Camila Rojas', 'Rodrigo Díaz', 'Fernanda Pérez', 'Ignacio Soto', 'Valentina Contreras', 'Cristóbal Silva', 'Antonia Vargas', 'Matías Fuentes'];
const ISAPRES = ['Banmédica', 'Consalud', 'Cruz Blanca', 'Colmena Golden Cross'];
const PRESTACIONES = ['Consulta medicina general', 'Ecografía abdominal', 'Radiografía de tórax', 'Hemograma completo', 'Control médico'];

function genIngresosPagadosMock() {
  const rows = []; let seed = 30;
  // Un lote deliberado: 4 ingresos Fonasa que deben sumar EXACTO a un depósito de lote (para que la sugerencia automática funcione de verdad).
  const loteFonasa = [42000, 38500, 51000, 29500];
  loteFonasa.forEach((monto, i) => {
    rows.push({ id: 5000 + i, fecha: addDays(HOY_ISO, -(6 - i)), paciente: NOMBRES[i], prestacion: PRESTACIONES[i % PRESTACIONES.length], monto, pagador: 'fonasa_mai', isapreNombre: null, estado: 'pagado' });
  });
  // Un lote de Isapre Consalud, también exacto.
  const loteConsalud = [65000, 48000, 33000];
  loteConsalud.forEach((monto, i) => {
    rows.push({ id: 5010 + i, fecha: addDays(HOY_ISO, -(5 - i)), paciente: NOMBRES[4 + i], prestacion: PRESTACIONES[(4 + i) % PRESTACIONES.length], monto, pagador: 'isapre', isapreNombre: 'Consalud', estado: 'pagado' });
  });
  // Resto disperso, sin que necesariamente calce con nada (para mostrar pendientes reales sin sugerencia).
  for (let i = 0; i < 6; i++) {
    seed += 17;
    const pagador = seed % 3 === 0 ? 'particular' : seed % 3 === 1 ? 'fonasa_mai' : 'isapre';
    rows.push({
      id: 5020 + i, fecha: addDays(HOY_ISO, -(seed % 10)),
      paciente: NOMBRES[seed % NOMBRES.length], prestacion: PRESTACIONES[seed % PRESTACIONES.length],
      monto: 15000 + (seed * 3701) % 90000, pagador,
      isapreNombre: pagador === 'isapre' ? ISAPRES[seed % ISAPRES.length] : null,
      estado: 'pagado',
    });
  }
  return rows;
}

function genMovimientosBancariosMock() {
  const sumLoteFonasa = 42000 + 38500 + 51000 + 29500;
  const sumLoteConsalud = 65000 + 48000 + 33000;
  return [
    { id: 'mb_1', fecha: addDays(HOY_ISO, -5), descripcion: 'DEP LIQUIDACION FONASA CONVENIO', monto: sumLoteFonasa, tipo: 'abono', origen: 'fonasa', isapreNombre: null, conciliado: false },
    { id: 'mb_2', fecha: addDays(HOY_ISO, -4), descripcion: 'DEP LIQUIDACION ISAPRE CONSALUD SA', monto: sumLoteConsalud, tipo: 'abono', origen: 'isapre', isapreNombre: 'Consalud', conciliado: false },
    { id: 'mb_3', fecha: addDays(HOY_ISO, -3), descripcion: 'TRANSFERENCIA RECIBIDA JUAN PEREZ', monto: 22000, tipo: 'abono', origen: 'transferencia_particular', isapreNombre: null, conciliado: false },
    { id: 'mb_4', fecha: addDays(HOY_ISO, -8), descripcion: 'COMISION MANTENCION CUENTA CORRIENTE', monto: 8500, tipo: 'cargo', origen: 'comision_bancaria', isapreNombre: null, conciliado: false },
    { id: 'mb_5', fecha: addDays(HOY_ISO, -2), descripcion: 'COMISION TRANSFERENCIAS ELECTRONICAS', monto: 4200, tipo: 'cargo', origen: 'comision_bancaria', isapreNombre: null, conciliado: false },
    { id: 'mb_6', fecha: addDays(HOY_ISO, -1), descripcion: 'ABONO INTERESES CUENTA VISTA', monto: 3100, tipo: 'abono', origen: 'interes_ganado', isapreNombre: null, conciliado: false },
    { id: 'mb_7', fecha: addDays(HOY_ISO, -7), descripcion: 'DEP LIQUIDACION ISAPRE BANMEDICA SA', monto: 118500, tipo: 'abono', origen: 'isapre', isapreNombre: 'Banmédica', conciliado: false },
  ];
}

/* ------------------------------- átomos ---------------------------------- */
const Badge = ({ color, bg, icon: Icon, children }) => (
  <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, padding: '3px 9px', borderRadius: 999, fontSize: 12, fontWeight: 600, color, background: bg, whiteSpace: 'nowrap' }}>
    {Icon && <Icon size={12} />}{children}
  </span>
);
const Btn = ({ variant = 'ghost', icon: Icon, children, onClick, style, disabled }) => {
  const variants = { primary: { background: C.pri, color: '#fff' }, outline: { background: '#fff', color: C.ink, border: `1px solid ${C.border}` }, ghost: { background: 'transparent', color: C.sub } };
  return (
    <button onClick={onClick} disabled={disabled}
      onMouseEnter={(e) => !disabled && (e.currentTarget.style.filter = 'brightness(0.96)')} onMouseLeave={(e) => (e.currentTarget.style.filter = 'none')}
      style={{ display: 'inline-flex', alignItems: 'center', gap: 7, padding: '9px 15px', borderRadius: C.rSm, fontSize: 13.5, fontWeight: 600, cursor: disabled ? 'not-allowed' : 'pointer', border: '1px solid transparent', fontFamily: C.font, opacity: disabled ? 0.5 : 1, ...variants[variant], ...style }}>
      {Icon && <Icon size={15} />}{children}
    </button>
  );
};
const KPICard = ({ label, value, sub, icon: Icon, accent }) => (
  <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, padding: '16px 18px', boxShadow: C.shadow, flex: 1, minWidth: 0 }}>
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
      <span style={{ fontSize: 12.5, color: C.sub, fontWeight: 600 }}>{label}</span>
      <div style={{ width: 28, height: 28, borderRadius: 8, background: accent + '18', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon size={14} style={{ color: accent }} /></div>
    </div>
    <div style={{ fontSize: 22, fontWeight: 700, color: C.ink, letterSpacing: -0.3 }}>{value}</div>
    {sub && <div style={{ fontSize: 12, color: C.mut, marginTop: 3 }}>{sub}</div>}
  </div>
);

function ConciliarModal({ movimiento, pendientesDisponibles, onClose, onConfirm }) {
  const [seleccionados, setSeleccionados] = useState([]);
  const toggle = (id) => setSeleccionados((s) => s.includes(id) ? s.filter((x) => x !== id) : [...s, id]);
  const sumaSeleccion = pendientesDisponibles.filter((p) => seleccionados.includes(p.id)).reduce((s, p) => s + p.monto, 0);
  const calza = sumaSeleccion === movimiento.monto;
  const diferencia = movimiento.monto - sumaSeleccion;

  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(16,24,40,.45)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100, padding: 20 }} onClick={onClose}>
      <div style={{ background: '#fff', borderRadius: C.rLg, width: 500, maxWidth: '100%', maxHeight: '85vh', display: 'flex', flexDirection: 'column', boxShadow: '0 20px 50px rgba(16,24,40,.25)' }} onClick={(e) => e.stopPropagation()}>
        <div style={{ padding: '18px 22px', borderBottom: `1px solid ${C.border}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <div style={{ fontSize: 15, fontWeight: 700, color: C.ink }}>{movimiento.descripcion}</div>
            <div style={{ fontSize: 12, color: C.mut }}>{fmtDate(movimiento.fecha)} · {clp(movimiento.monto)}</div>
          </div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: C.mut }}><X size={18} /></button>
        </div>
        <div style={{ padding: '14px 22px', overflowY: 'auto', flex: 1 }}>
          <div style={{ fontSize: 11.5, fontWeight: 600, color: C.sub, marginBottom: 10 }}>Selecciona los ingresos pendientes que este depósito cubre — Fonasa/Isapre suelen liquidar varios a la vez.</div>
          {pendientesDisponibles.length === 0 && <div style={{ fontSize: 13, color: C.mut, padding: 20, textAlign: 'center' }}>No hay pendientes que calcen con el origen de este movimiento.</div>}
          {pendientesDisponibles.map((p) => (
            <label key={p.id} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '9px 8px', borderRadius: C.rSm, cursor: 'pointer', background: seleccionados.includes(p.id) ? C.priL : 'transparent' }}>
              <input type="checkbox" checked={seleccionados.includes(p.id)} onChange={() => toggle(p.id)} style={{ width: 15, height: 15 }} />
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 12.5, color: C.ink }}>{p.descripcion}</div>
                <div style={{ fontSize: 11, color: C.mut }}>{fmtDate(p.fecha)}</div>
              </div>
              <div style={{ fontSize: 12.5, fontWeight: 600, color: C.ink }}>{clp(p.monto)}</div>
            </label>
          ))}
        </div>
        <div style={{ padding: '14px 22px', borderTop: `1px solid ${C.border}` }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, marginBottom: 4 }}>
            <span style={{ color: C.sub }}>Seleccionado</span><span style={{ fontWeight: 600, color: C.ink }}>{clp(sumaSeleccion)}</span>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, marginBottom: 10 }}>
            <span style={{ color: C.sub }}>Depósito</span><span style={{ fontWeight: 600, color: C.ink }}>{clp(movimiento.monto)}</span>
          </div>
          {!calza && seleccionados.length > 0 && <div style={{ fontSize: 12, color: C.err, marginBottom: 10 }}>Diferencia de {clp(diferencia)} — la selección no calza exacto, revisa antes de confirmar.</div>}
          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10 }}>
            <Btn variant="ghost" onClick={onClose}>Cancelar</Btn>
            <Btn variant="primary" icon={Link2} disabled={!calza || seleccionados.length === 0} onClick={() => onConfirm(movimiento.id, seleccionados)}>Conciliar</Btn>
          </div>
        </div>
      </div>
    </div>
  );
}

function AjusteModal({ movimiento, onClose, onConfirm }) {
  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(16,24,40,.45)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100, padding: 20 }} onClick={onClose}>
      <div style={{ background: '#fff', borderRadius: C.rLg, width: 420, maxWidth: '100%', boxShadow: '0 20px 50px rgba(16,24,40,.25)' }} onClick={(e) => e.stopPropagation()}>
        <div style={{ padding: '18px 22px', borderBottom: `1px solid ${C.border}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ fontSize: 15, fontWeight: 700, color: C.ink }}>Crear ajuste contable</div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: C.mut }}><X size={18} /></button>
        </div>
        <div style={{ padding: 22 }}>
          <div style={{ fontSize: 12.5, color: C.sub, marginBottom: 14 }}>
            <b style={{ color: C.ink }}>{movimiento.descripcion}</b> ({clp(movimiento.monto)}) no tiene contraparte en los libros — es un movimiento que solo existe en el banco. Se creará un registro nuevo para que los libros reflejen la realidad.
          </div>
          <div style={{ background: C.bg, borderRadius: C.rSm, padding: 12, fontSize: 12, color: C.sub }}>
            {movimiento.tipo === 'cargo'
              ? <>Se registrará como <b style={{ color: C.ink }}>nuevo Egreso</b> — categoría "Servicios Generales" (gasto bancario). En producción esto llamaría a la puerta etiquetada de Egresos.</>
              : <>Se registrará como <b style={{ color: C.ink }}>nuevo Ingreso no operacional</b> (interés ganado). En producción esto llamaría a la puerta etiquetada de Ingresos.</>}
          </div>
        </div>
        <div style={{ padding: '14px 22px', borderTop: `1px solid ${C.border}`, display: 'flex', justifyContent: 'flex-end', gap: 10 }}>
          <Btn variant="ghost" onClick={onClose}>Cancelar</Btn>
          <Btn variant="primary" icon={Plus} onClick={() => onConfirm(movimiento.id)}>Crear ajuste y conciliar</Btn>
        </div>
      </div>
    </div>
  );
}

/* --------------------------------- vista principal ------------------------------------ */
export default function ContabilidadConciliacionBancaria({ addToast }) {
  const toast = addToast || ((msg) => console.log(msg));
  const [movimientos, setMovimientos] = useState(genMovimientosBancariosMock);
  const [pendientes, setPendientes] = useState(() => desdeIngresosPagados(genIngresosPagadosMock()).map((p) => ({ ...p, conciliadoConId: null })));
  const [conciliando, setConciliando] = useState(null);
  const [ajustando, setAjustando] = useState(null);
  const [q, setQ] = useState('');

  const kpi = useMemo(() => calcularKPIsConciliacion(movimientos, pendientes), [movimientos, pendientes]);
  const sugerencias = useMemo(() => sugerirConciliaciones(movimientos, pendientes.filter((p) => !p.conciliadoConId)), [movimientos, pendientes]);
  const porOrigenDisplay = kpi.porOrigen.filter((o) => o.monto > 0).map((o) => [o.id, ORIGENES_BANCO[o.id], o.monto]);

  const movimientosFiltrados = useMemo(() => movimientos.filter((m) => !q || m.descripcion.toLowerCase().includes(q.toLowerCase())), [movimientos, q]);

  const confirmarConciliacion = (movimientoId, pendienteIds) => {
    setMovimientos(movimientos.map((m) => m.id === movimientoId ? { ...m, conciliado: true } : m));
    setPendientes(pendientes.map((p) => pendienteIds.includes(p.id) ? { ...p, conciliadoConId: movimientoId } : p));
    setConciliando(null);
    toast(`Conciliado: ${pendienteIds.length} ingreso(s) contra el depósito`);
  };

  const aplicarSugerencia = (sug) => {
    confirmarConciliacion(sug.movimientoId, sug.pendienteIds);
  };

  const confirmarAjuste = (movimientoId) => {
    setMovimientos(movimientos.map((m) => m.id === movimientoId ? { ...m, conciliado: true, ajusteCreado: true } : m));
    setAjustando(null);
    toast('Ajuste creado y movimiento conciliado');
  };

  const exportarCSV = () => {
    const header = ['Fecha', 'Descripción', 'Tipo', 'Origen', 'Monto', 'Conciliado'];
    const lines = movimientos.map((m) => [m.fecha, m.descripcion, m.tipo, ORIGENES_BANCO[m.origen].label, m.monto, m.conciliado ? 'Sí' : 'No'].join(';'));
    const blob = new Blob([header.join(';') + '\n' + lines.join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = `conciliacion_bancaria_${HOY_ISO}.csv`; a.click();
    URL.revokeObjectURL(url);
    toast('Archivo CSV descargado');
  };

  const pendientesDisponibles = (mov) => pendientes.filter((p) => !p.conciliadoConId).filter((p) => {
    if (mov.origen === 'fonasa') return ['fonasa_mai', 'fonasa_mle'].includes(p.pagador);
    if (mov.origen === 'isapre') return p.pagador === 'isapre' && (!mov.isapreNombre || p.isapreNombre === mov.isapreNombre);
    if (mov.origen === 'transferencia_particular') return p.pagador === 'particular';
    return false;
  });

  return (
    <div style={{ fontFamily: C.font, background: C.bg, minHeight: '100%', padding: 22 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 14, flexWrap: 'wrap', gap: 12 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
          <div style={{ width: 34, height: 34, borderRadius: 9, background: C.tealL || '#E3F6FA', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Landmark size={17} style={{ color: C.teal }} /></div>
          <div>
            <div style={{ fontSize: 18, fontWeight: 700, color: C.ink }}>Conciliación Bancaria</div>
            <div style={{ fontSize: 12.5, color: C.mut }}>Cartola del banco vs. libros — cruce N a 1, como liquidan de verdad Fonasa e Isapre</div>
          </div>
        </div>
        <Btn variant="outline" icon={Download} onClick={exportarCSV}>Exportar CSV</Btn>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: 7, background: '#fff', border: `1px solid ${C.border}`, borderRadius: C.rSm, padding: '9px 13px', marginBottom: 18, fontSize: 12, color: C.sub }}>
        <Info size={13} style={{ color: C.vio }} />
        Fonasa/Isapre pagan en lote (un depósito cubre varios bonos), por eso el motor sugiere combinaciones que sumen exacto en vez de buscar pares 1 a 1. Registro de Compras y Ventas (RCV) del SII queda como capa adicional para una fase futura — no se cruza todavía acá.
      </div>

      <div style={{ fontSize: 11.5, fontWeight: 700, color: C.mut, textTransform: 'uppercase', letterSpacing: 0.4, marginBottom: 8 }}>Estado de la conciliación</div>
      <div style={{ display: 'flex', gap: 14, marginBottom: 18, flexWrap: 'wrap' }}>
        <KPICard label="Tasa de conciliación" value={kpi.tasaConciliacion + '%'} sub={`${kpi.sinConciliarCount} movimientos sin conciliar`} icon={CheckCircle2} accent={semaforo(kpi.tasaConciliacion, true, 90, 60)} />
        <KPICard label="Monto sin conciliar (banco)" value={clp(kpi.montoSinConciliar)} sub="Movimientos bancarios abiertos" icon={Clock} accent={kpi.montoSinConciliar > 0 ? C.warn : C.pri} />
        <KPICard label="Pendiente en libros" value={clp(kpi.montoPendienteLibros)} sub={`${kpi.pendientesSinAsignarCount} ingresos sin depósito asociado`} icon={AlertTriangle} accent={kpi.pendientesSinAsignarCount > 0 ? C.warn : C.pri} />
        <KPICard label="Comisiones bancarias del período" value={clp(kpi.comisiones)} sub="Cargo directo del banco" icon={Percent} accent={C.err} />
      </div>

      {sugerencias.length > 0 && (
        <div style={{ background: C.infoL, border: `1px solid #BFDBFE`, borderRadius: C.r, padding: 16, marginBottom: 18 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 7, fontSize: 13, fontWeight: 700, color: C.info, marginBottom: 10 }}>
            <Wand2 size={15} /> {sugerencias.length} conciliación(es) sugerida(s) automáticamente — la suma calza exacta
          </div>
          {sugerencias.map((sug) => {
            const mov = movimientos.find((m) => m.id === sug.movimientoId);
            return (
              <div key={sug.movimientoId} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', background: '#fff', borderRadius: C.rSm, padding: '10px 14px', marginBottom: 8 }}>
                <div>
                  <div style={{ fontSize: 12.5, fontWeight: 600, color: C.ink }}>{mov.descripcion}</div>
                  <div style={{ fontSize: 11.5, color: C.mut }}>{sug.pendienteIds.length} ingresos · {clp(sug.montoTotal)}</div>
                </div>
                <Btn variant="primary" icon={CheckCircle2} onClick={() => aplicarSugerencia(sug)} style={{ padding: '6px 12px', fontSize: 12.5 }}>Aplicar</Btn>
              </div>
            );
          })}
        </div>
      )}

      <div style={{ display: 'flex', gap: 14, marginBottom: 18, flexWrap: 'wrap' }}>
        <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, padding: 18, boxShadow: C.shadow, flex: 1, minWidth: 260 }}>
          <div style={{ fontSize: 13, fontWeight: 700, color: C.ink, marginBottom: 14 }}>Movimiento neto por origen</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 11 }}>
            {porOrigenDisplay.map(([id, meta, monto]) => {
              const pct = kpi.totalBanco ? Math.round((monto / Math.abs(kpi.totalBanco || 1)) * 100) : 0;
              const Icon = meta.icon;
              return (
                <div key={id}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12.5, marginBottom: 4 }}>
                    <span style={{ display: 'flex', alignItems: 'center', gap: 6, color: C.ink, fontWeight: 500 }}><Icon size={13} style={{ color: meta.color }} /> {meta.label}</span>
                    <span style={{ color: C.sub, fontWeight: 600 }}>{clp(monto)}</span>
                  </div>
                  <div style={{ height: 6, borderRadius: 4, background: C.bg, overflow: 'hidden' }}><div style={{ height: '100%', width: Math.min(100, Math.abs(pct)) + '%', background: meta.color, borderRadius: 4 }} /></div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
        <div style={{ fontSize: 11.5, fontWeight: 700, color: C.mut, textTransform: 'uppercase', letterSpacing: 0.4 }}>Cartola bancaria</div>
        <div style={{ position: 'relative', width: 220 }}>
          <Search size={14} style={{ position: 'absolute', left: 9, top: 9, color: C.mut }} />
          <input style={{ width: '100%', padding: '8px 10px 8px 28px', borderRadius: C.rSm, border: `1px solid ${C.border}`, fontSize: 13, fontFamily: C.font, outline: 'none', boxSizing: 'border-box' }} placeholder="Buscar movimiento" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
      </div>
      <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, boxShadow: C.shadow, overflow: 'hidden' }}>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
            <thead><tr style={{ background: C.bg, textAlign: 'left' }}>{['Fecha', 'Descripción', 'Origen', 'Monto', 'Estado', ''].map((h) => <th key={h} style={{ padding: '10px 14px', fontSize: 11.5, fontWeight: 700, color: C.sub, textTransform: 'uppercase' }}>{h}</th>)}</tr></thead>
            <tbody>
              {movimientosFiltrados.map((m) => {
                const origen = ORIGENES_BANCO[m.origen];
                const disponibles = pendientesDisponibles(m);
                return (
                  <tr key={m.id} style={{ borderTop: `1px solid ${C.border}` }}>
                    <td style={{ padding: '11px 14px', color: C.sub, whiteSpace: 'nowrap' }}>{fmtDate(m.fecha)}</td>
                    <td style={{ padding: '11px 14px', color: C.ink }}>{m.descripcion}</td>
                    <td style={{ padding: '11px 14px' }}><Badge color={origen.color} bg={origen.color + '18'} icon={origen.icon}>{origen.label}</Badge></td>
                    <td style={{ padding: '11px 14px', fontWeight: 700, whiteSpace: 'nowrap', color: m.tipo === 'cargo' ? C.err : C.ink }}>{m.tipo === 'cargo' ? '-' : ''}{clp(m.monto)}</td>
                    <td style={{ padding: '11px 14px' }}>
                      {m.conciliado
                        ? <Badge color={C.pri} bg={C.priL} icon={CheckCircle2}>{m.ajusteCreado ? 'Conciliado (ajuste)' : 'Conciliado'}</Badge>
                        : <Badge color={C.warn} bg={C.warnL} icon={Clock}>Sin conciliar</Badge>}
                    </td>
                    <td style={{ padding: '11px 14px', whiteSpace: 'nowrap' }}>
                      {!m.conciliado && (m.origen === 'comision_bancaria' || m.origen === 'interes_ganado'
                        ? <Btn variant="outline" icon={Plus} onClick={() => setAjustando(m)} style={{ padding: '5px 10px', fontSize: 12 }}>Crear ajuste</Btn>
                        : <Btn variant="outline" icon={Link2} onClick={() => setConciliando(m)} disabled={disponibles.length === 0} style={{ padding: '5px 10px', fontSize: 12 }}>Conciliar</Btn>)}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      <div style={{ fontSize: 11.5, fontWeight: 700, color: C.mut, textTransform: 'uppercase', letterSpacing: 0.4, marginTop: 22, marginBottom: 8 }}>Pendientes en libros sin depósito asociado</div>
      <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, boxShadow: C.shadow, overflow: 'hidden' }}>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
            <thead><tr style={{ background: C.bg, textAlign: 'left' }}>{['Fecha', 'Descripción', 'Pagador', 'Monto', 'Estado'].map((h) => <th key={h} style={{ padding: '10px 14px', fontSize: 11.5, fontWeight: 700, color: C.sub, textTransform: 'uppercase' }}>{h}</th>)}</tr></thead>
            <tbody>
              {pendientes.filter((p) => !p.conciliadoConId).map((p) => (
                <tr key={p.id} style={{ borderTop: `1px solid ${C.border}` }}>
                  <td style={{ padding: '11px 14px', color: C.sub, whiteSpace: 'nowrap' }}>{fmtDate(p.fecha)}</td>
                  <td style={{ padding: '11px 14px', color: C.ink }}>{p.descripcion}</td>
                  <td style={{ padding: '11px 14px', color: C.sub }}>{p.isapreNombre || p.pagador}</td>
                  <td style={{ padding: '11px 14px', fontWeight: 700, color: C.ink, whiteSpace: 'nowrap' }}>{clp(p.monto)}</td>
                  <td style={{ padding: '11px 14px' }}><Badge color={C.warn} bg={C.warnL} icon={Clock}>Esperando depósito</Badge></td>
                </tr>
              ))}
              {pendientes.filter((p) => !p.conciliadoConId).length === 0 && <tr><td colSpan={5} style={{ padding: '30px 14px', textAlign: 'center', color: C.mut }}>Todo lo pagado ya quedó conciliado.</td></tr>}
            </tbody>
          </table>
        </div>
      </div>

      {conciliando && <ConciliarModal movimiento={conciliando} pendientesDisponibles={pendientesDisponibles(conciliando)} onClose={() => setConciliando(null)} onConfirm={confirmarConciliacion} />}
      {ajustando && <AjusteModal movimiento={ajustando} onClose={() => setAjustando(null)} onConfirm={confirmarAjuste} />}
    </div>
  );
}
