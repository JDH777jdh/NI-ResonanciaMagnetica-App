# Paquete de traspaso — AXON Contabilidad (2026-10-22)

Copia de seguridad completa del módulo para abrir un chat nuevo sin releer la conversación.

## Contenido
- `jsx/` — los 10 `.jsx` de Contabilidad que existen aquí + `ContabilidadHelpersCompartidos.js`
- `dossier/` — dossier maestro actualizado (abre con «ESTADO VIGENTE AL 2026-10-20»)
- `pruebas/` — arnés y tests del refactor PFA/UnitShell (916 aserciones) y del fix de Honorarios Externos, con sus README

## Estado de los archivos (medido al armar el paquete)
| Archivo | Líneas | Exports | Parseo esbuild | Origen |
|---|---|---|---|---|
| `ContabilidadAdquisiciones.jsx` | 1.232 | 8 + default | OK | proyecto |
| `ContabilidadBalances.jsx` | 354 | 1 + default | OK | proyecto |
| `ContabilidadConciliacionBancaria.jsx` | 457 | 2 + default | OK | proyecto |
| `ContabilidadEgresos.jsx` | 625 | 2 + default | OK | proyecto |
| `ContabilidadFacturacion.jsx` | 539 | 2 + default | OK | proyecto |
| `ContabilidadFlujoCaja.jsx` | 486 | 2 + default | OK | proyecto |
| `ContabilidadHelpersCompartidos.js` | 76 | 3 | OK | proyecto |
| `ContabilidadHonorariosExternos.jsx` | 485 | 1 + default | OK | outputs (versión NUEVA) |
| `ContabilidadHonorariosMedicos.jsx` | 530 | 1 + default | OK | proyecto |
| `ContabilidadIngresos.jsx` | 1.752 | 32 + default | OK | outputs (versión NUEVA) |
| `ContabilidadObligacionesTributarias.jsx` | 469 | 1 + default | OK | proyecto |

**Falta una pieza:** `ContabilidadCentroCostoPorUnidad.jsx` (sección 2.10) no está en `/mnt/project` ni en este paquete; solo la tiene el usuario. Hay que subirla al chat nuevo.

## Estado por fases (según el dossier)
Fases 0-8 completas · Fase 9 parcial (pendiente: eventos compensatorios, Maker/Checker en Conciliación, estados por dominio) · Cierre Contable bloqueado por el modelo público/privado NICSP-CGR · Refactor Patient Financial Profile 3 niveles + OrgNode vigente a fecha: completo (2026-10-16) · Fix `handleSave` Honorarios Externos: completo (2026-10-17).

## Qué subir al chat nuevo (si es dentro del proyecto «CONTABILIAD - AXON»)
Lo demás ya lo ve el chat desde `/mnt/project`. Para gastar menos contexto basta subir: `ContabilidadIngresos.jsx`, `ContabilidadHonorariosExternos.jsx`, `ContabilidadCentroCostoPorUnidad.jsx` y el dossier nuevo. Este `.zip` es la copia de seguridad, no hace falta subirlo entero.

## Mensaje sugerido para abrir el chat nuevo
> Continuamos el trabajo de Contabilidad de AXON. Lee primero el dossier `AXON_Contabilidad_Dossier_Tecnico_y_Sincronizacion_MAIN.md` (abre con «ESTADO VIGENTE AL 2026-10-20»). Te subo las versiones nuevas de ContabilidadIngresos.jsx y ContabilidadHonorariosExternos.jsx, y ContabilidadCentroCostoPorUnidad.jsx, que no estaba en el proyecto. Verifica con wc/grep que lo que ves coincide con el dossier y dime en qué quedamos antes de seguir.
