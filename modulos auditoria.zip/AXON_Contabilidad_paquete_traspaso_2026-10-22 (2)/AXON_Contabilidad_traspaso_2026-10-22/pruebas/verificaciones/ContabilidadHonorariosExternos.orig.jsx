import React, { useState, useMemo } from 'react';
import {
  Building2, Search, Download, Plus, X, FileText, Eye, RotateCcw,
  CheckCircle2, Clock, Ban, Info, Scale, ClipboardCheck, Laptop,
  Target, Megaphone, GraduationCap, User
} from 'lucide-react';

/* =========================================================================
   DISEÑO — copiado 1:1 desde HISClinico_Layer1.jsx / demás secciones de
   Contabilidad, para que este archivo se pueda previsualizar de forma
   independiente.
   ========================================================================= */
const C = {
  bg: '#F4F6F9', card: '#FFFFFF', border: '#E2E8F0', borderD: '#CBD5E1',
  ink: '#16233E', sub: '#5B6B85', mut: '#94A3B8',
  pri: '#2E7D32', priL: '#EAF6EC',
  info: '#2563EB', infoL: '#EEF3FF',
  warn: '#B45309', warnL: '#FEF3E2',
  err: '#C62828', errL: '#FDECEC',
  vio: '#6D28D9', vioL: '#F2ECFB',
  teal: '#0E7490',
  r: 10, rSm: 7, rLg: 14,
  shadow: '0 1px 3px rgba(16,24,40,.06), 0 1px 2px rgba(16,24,40,.04)',
  font: "'Inter', -apple-system, 'Segoe UI', Roboto, sans-serif",
};

/* Misma tasa que Honorarios Médicos — un solo valor en todo el proyecto.
   Ley 21.133: 2024=13,75% · 2025=14,5% · 2026=15,25% · 2027=16% · 2028=17%. */
const TASA_RETENCION_HONORARIOS = 0.1525;
const ANIO_TASA_VIGENTE = 2026;

const CATEGORIAS = {
  legal: { label: 'Asesoría Legal', color: '#6D28D9', icon: Scale },
  auditoria: { label: 'Auditoría Externa', color: '#B45309', icon: ClipboardCheck },
  ti: { label: 'Consultoría TI / Sistemas', color: '#2563EB', icon: Laptop },
  gestion: { label: 'Consultoría de Gestión', color: '#0E7490', icon: Target },
  marketing: { label: 'Marketing y Comunicaciones', color: '#BE185D', icon: Megaphone },
  capacitacion: { label: 'Capacitación y Formación', color: '#2E7D32', icon: GraduationCap },
};

/* GAP CERRADO (2026-09-04): esta sección no capturaba centro de costo, a
   diferencia de sus pares (Egresos, Honorarios Médicos, Adquisiciones) —
   confirmado con grep sobre el código real, ver Mapeo 13 Secciones vs
   Account Core. Mismo criterio simple que ya usa Adquisiciones (derivar el
   centro desde la categoría). Mismas claves/labels que CENTROS en
   ContabilidadEgresos.jsx, para que ambos archivos hablen el mismo idioma
   de centro de costo cuando se integren. */
const CENTRO_POR_CATEGORIA = {
  legal: 'administracion',
  auditoria: 'administracion',
  ti: 'ti',
  gestion: 'administracion',
  marketing: 'administracion',
  capacitacion: 'administracion',
};
const CENTRO_LABEL = {
  administracion: 'Administración General',
  ti: 'Tecnología de la Información',
};

const TIPO_PROVEEDOR = {
  persona_natural: { label: 'Persona Natural (BHE)', color: '#6D28D9', icon: User },
  empresa: { label: 'Empresa (Factura)', color: '#2563EB', icon: Building2 },
};

const ESTADOS = {
  pendiente: { label: 'Pendiente de documento', color: '#B45309', bg: '#FEF3E2', icon: Clock },
  emitido: { label: 'Documento emitido', color: '#2563EB', bg: '#EEF3FF', icon: FileText },
  pagado: { label: 'Pagado', color: '#2E7D32', bg: '#EAF6EC', icon: CheckCircle2 },
  rechazado: { label: 'Rechazado', color: '#94A3B8', bg: '#F1F5F9', icon: Ban },
};

/* Nota: si es persona natural, funciona igual que Honorarios Médicos (BHE +
   retención SII). Si es empresa, va con Factura Electrónica + IVA 19%, igual
   que un proveedor cualquiera de Egresos — la diferencia acá es que son
   servicios profesionales EXTERNOS al giro clínico, no personal que trabaja
   dentro del hospital (eso es la sección 4). */

/* ---------------------------- formatters -------------------------------- */
const clp = (n) => '$' + Math.round(n).toLocaleString('es-CL');
const fmtDate = (iso) =>
  new Date(iso + 'T00:00:00').toLocaleDateString('es-CL', { day: '2-digit', month: 'short', year: 'numeric' });
const addDays = (iso, n) => {
  const d = new Date(iso + 'T00:00:00');
  d.setDate(d.getDate() + n);
  return d.toISOString().slice(0, 10);
};
// Ver ContabilidadHelpersCompartidos.js — versión canónica verificada de calcDV/fakeRUT (mismo comportamiento, base 6000000/mult 5231).
function calcDV(rutBody) {
  let suma = 0, mult = 2;
  for (let i = rutBody.length - 1; i >= 0; i--) { suma += parseInt(rutBody[i], 10) * mult; mult = mult === 7 ? 2 : mult + 1; }
  const resto = 11 - (suma % 11);
  if (resto === 11) return '0';
  if (resto === 10) return 'K';
  return String(resto);
}
function fakeRUT(seed) {
  const body = String(6000000 + (seed * 5231) % 8900000);
  return body.slice(0, 2) + '.' + body.slice(2, 5) + '.' + body.slice(5) + '-' + calcDV(body);
}
// Ver ContabilidadHelpersCompartidos.js — versión canónica verificada de semaforo() (idéntica).
function semaforo(valor, metaEsMinimo, umbralBueno, umbralMalo) {
  const esBueno = metaEsMinimo ? valor >= umbralBueno : valor <= umbralBueno;
  const esMalo = metaEsMinimo ? valor < umbralMalo : valor > umbralMalo;
  if (esBueno) return C.pri;
  if (esMalo) return C.err;
  return C.warn;
}

/* ═══════════════════════════════════════════════════════════════════════
   PUERTA ETIQUETADA — calcularKPIsHonorariosExternos
   ═══════════════════════════════════════════════════════════════════════ */
export function calcularKPIsHonorariosExternos(rows) {
  const sum = (pred) => rows.filter(pred).reduce((s, r) => s + r.montoBruto, 0);

  const totalBruto = rows.reduce((s, r) => s + r.montoBruto, 0);
  const totalPersonaNatural = sum((r) => r.tipoProveedor === 'persona_natural');
  const totalEmpresa = sum((r) => r.tipoProveedor === 'empresa');
  const totalRetencion = rows.filter((r) => r.tipoProveedor === 'persona_natural').reduce((s, r) => s + r.montoRetencionOIva, 0);
  const totalIVA = rows.filter((r) => r.tipoProveedor === 'empresa').reduce((s, r) => s + r.montoRetencionOIva, 0);
  const pendientes = rows.filter((r) => r.estado === 'pendiente');
  const montoPendiente = pendientes.reduce((s, r) => s + r.montoBruto, 0);
  const pagados = rows.filter((r) => r.estado !== 'pendiente' && r.estado !== 'rechazado').length;
  const tasaDocumentado = rows.length ? Math.round((pagados / rows.length) * 100) : 0;

  const porProveedor = {};
  rows.forEach((r) => { porProveedor[r.proveedor] = (porProveedor[r.proveedor] || 0) + r.montoBruto; });
  const ordenados = Object.entries(porProveedor).sort((a, b) => b[1] - a[1]);
  const concentracionTop = totalBruto ? Math.round(((ordenados[0]?.[1] || 0) / totalBruto) * 100) : 0;

  const porCategoria = Object.keys(CATEGORIAS).map((id) => ({ id, monto: sum((r) => r.categoria === id) })).sort((a, b) => b.monto - a.monto);
  const porTipoProveedor = Object.keys(TIPO_PROVEEDOR).map((id) => ({ id, monto: sum((r) => r.tipoProveedor === id) }));
  const porCentro = Object.keys(CENTRO_LABEL).map((id) => ({ id, monto: sum((r) => r.centroCosto === id) })).sort((a, b) => b.monto - a.monto);

  return {
    seccion: 'honorarios_externos', proveedores: new Set(rows.map((r) => r.proveedor)).size, documentos: rows.length,
    totalBruto, totalPersonaNatural, totalEmpresa, totalRetencion, totalIVA,
    montoPendiente, pendienteCount: pendientes.length, tasaDocumentado, concentracionTop,
    porCategoria, porTipoProveedor, porCentro,
  };
}

/* ------------------------------ mock data -------------------------------- */
const PROVEEDORES = {
  legal: [['Estudio Jurídico Bravo & Asociados', 'empresa', 2200000], ['Dra. Constanza Lira, Abogada', 'persona_natural', 1350000]],
  auditoria: [['Auditores Consultores del Pacífico Ltda.', 'empresa', 3400000]],
  ti: [['Soluciones TI Corporativas SpA', 'empresa', 2800000], ['Ing. Rodrigo Salinas, Consultor TI', 'persona_natural', 1100000]],
  gestion: [['Estrategia y Gestión Hospitalaria Consultores SpA', 'empresa', 4200000]],
  marketing: [['Lic. Andrea Fuentes, Comunicaciones', 'persona_natural', 850000]],
  capacitacion: [['Capacita Chile Ltda.', 'empresa', 1600000]],
};
const CATEGORIA_KEYS = Object.keys(CATEGORIAS);

const HOY_HEXT = new Date('2026-07-05T00:00:00');
function mesesDelAnioHasta(hoy) {
  const anio = hoy.getFullYear(), mesActual = hoy.getMonth(), meses = [];
  for (let m = 0; m <= mesActual; m++) meses.push(`${anio}-${String(m + 1).padStart(2, '0')}`);
  return meses;
}
const MESES_HEXT = mesesDelAnioHasta(HOY_HEXT);
const HOY_ISO_HEXT = HOY_HEXT.toISOString().slice(0, 10);
const DIAS_DEL_MES_HEXT = { '01': 31, '02': 28, '03': 31, '04': 30, '05': 31, '06': 30, '07': 31, '08': 31, '09': 30, '10': 31, '11': 30, '12': 31 };
const ESTADO_POOL = ['pagado', 'pagado', 'emitido', 'pendiente', 'rechazado'];
const ESTADO_POOL_HISTORICO = ['pagado', 'pagado', 'pagado', 'pagado', 'rechazado'];

function genMock() {
  const rows = [];
  let seed = 7;
  MESES_HEXT.forEach((mesStr, mesIdx) => {
    const esMesActual = mesIdx === MESES_HEXT.length - 1;
    const diasEnMes = esMesActual ? HOY_HEXT.getDate() : DIAS_DEL_MES_HEXT[mesStr.slice(5, 7)];
    CATEGORIA_KEYS.forEach((categoria) => {
      PROVEEDORES[categoria].forEach(([proveedor, tipoProveedor, base]) => {
        seed += 19;
        const variacion = 1 + (((seed * 11) % 30) - 15) / 100; // ±15%
        const montoBruto = Math.round((base * variacion) / 10000) * 10000;
        const esBHE = tipoProveedor === 'persona_natural';
        const montoRetencionOIva = Math.round(montoBruto * (esBHE ? TASA_RETENCION_HONORARIOS : 0.19));
        const montoLiquidoONeto = esBHE ? montoBruto - montoRetencionOIva : montoBruto - montoRetencionOIva; // neto antes de IVA en el caso factura
        const dia = 1 + (seed % diasEnMes);
        const fecha = `${mesStr}-${String(dia).padStart(2, '0')}`;
        const pool = esMesActual ? ESTADO_POOL : ESTADO_POOL_HISTORICO;
        const estado = pool[seed % pool.length];
        const fechaPago = estado === 'pagado' ? addDays(fecha, 5 + (seed % 20)) : null;
        const folio = estado === 'pendiente' ? null : (esBHE ? 60000 : 3300) + rows.length;
        rows.push({
          id: 'hext_' + (1000 + rows.length),
          fecha, fechaPago,
          proveedor, rut: fakeRUT(seed), tipoProveedor,
          categoria,
          centroCosto: CENTRO_POR_CATEGORIA[categoria],
          montoBruto, montoRetencionOIva, montoLiquidoONeto,
          documento: { tipo: esBHE ? 'Boleta de Honorarios' : 'Factura Electrónica', folio },
          estado,
        });
      });
    });
  });
  return rows.sort((a, b) => (a.fecha < b.fecha ? 1 : -1));
}

/* ------------------------------- átomos ---------------------------------- */
const Badge = ({ color, bg, icon: Icon, children }) => (
  <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, padding: '3px 9px', borderRadius: 999, fontSize: 12, fontWeight: 600, color, background: bg, whiteSpace: 'nowrap' }}>
    {Icon && <Icon size={12} />}{children}
  </span>
);
const Btn = ({ variant = 'ghost', icon: Icon, children, onClick, style, type = 'button' }) => {
  const variants = { primary: { background: C.pri, color: '#fff' }, outline: { background: '#fff', color: C.ink, border: `1px solid ${C.border}` }, ghost: { background: 'transparent', color: C.sub } };
  return (
    <button type={type} onClick={onClick}
      onMouseEnter={(e) => (e.currentTarget.style.filter = 'brightness(0.96)')} onMouseLeave={(e) => (e.currentTarget.style.filter = 'none')}
      style={{ display: 'inline-flex', alignItems: 'center', gap: 7, padding: '9px 15px', borderRadius: C.rSm, fontSize: 13.5, fontWeight: 600, cursor: 'pointer', border: '1px solid transparent', fontFamily: C.font, ...variants[variant], ...style }}>
      {Icon && <Icon size={15} />}{children}
    </button>
  );
};
const KPICard = ({ label, value, sub, icon: Icon, accent }) => (
  <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, padding: '16px 18px', boxShadow: C.shadow, flex: 1, minWidth: 0 }}>
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
      <span style={{ fontSize: 12.5, color: C.sub, fontWeight: 600 }}>{label}</span>
      <div style={{ width: 28, height: 28, borderRadius: 8, background: accent + '18', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon size={14} style={{ color: accent }} /></div>
    </div>
    <div style={{ fontSize: 22, fontWeight: 700, color: C.ink, letterSpacing: -0.3 }}>{value}</div>
    {sub && <div style={{ fontSize: 12, color: C.mut, marginTop: 3 }}>{sub}</div>}
  </div>
);
const FieldLabel = ({ children }) => <label style={{ fontSize: 11.5, fontWeight: 600, color: C.sub, marginBottom: 5, display: 'block' }}>{children}</label>;
const inputStyle = { width: '100%', padding: '8px 10px', borderRadius: C.rSm, border: `1px solid ${C.border}`, fontSize: 13.5, fontFamily: C.font, color: C.ink, outline: 'none', boxSizing: 'border-box', background: '#fff' };

function BreakdownCard({ title, items, total }) {
  return (
    <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, padding: 18, boxShadow: C.shadow, flex: 1, minWidth: 0 }}>
      <div style={{ fontSize: 13, fontWeight: 700, color: C.ink, marginBottom: 14 }}>{title}</div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 11 }}>
        {items.map(([key, meta, monto]) => {
          const pct = total ? Math.round((monto / total) * 100) : 0;
          const Icon = meta.icon || Building2;
          return (
            <div key={key}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12.5, marginBottom: 4 }}>
                <span style={{ display: 'flex', alignItems: 'center', gap: 6, color: C.ink, fontWeight: 500 }}><Icon size={13} style={{ color: meta.color }} /> {meta.label}</span>
                <span style={{ color: C.sub, fontWeight: 600 }}>{clp(monto)} <span style={{ color: C.mut, fontWeight: 400 }}>({pct}%)</span></span>
              </div>
              <div style={{ height: 6, borderRadius: 4, background: C.bg, overflow: 'hidden' }}><div style={{ height: '100%', width: pct + '%', background: meta.color, borderRadius: 4 }} /></div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function DetailModal({ row, onClose }) {
  if (!row) return null;
  const cat = CATEGORIAS[row.categoria], est = ESTADOS[row.estado], tp = TIPO_PROVEEDOR[row.tipoProveedor];
  const esBHE = row.tipoProveedor === 'persona_natural';
  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(16,24,40,.45)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100, padding: 20 }} onClick={onClose}>
      <div style={{ background: '#fff', borderRadius: C.rLg, width: 500, maxWidth: '100%', maxHeight: '90vh', overflowY: 'auto', boxShadow: '0 20px 50px rgba(16,24,40,.25)' }} onClick={(e) => e.stopPropagation()}>
        <div style={{ padding: '18px 22px', borderBottom: `1px solid ${C.border}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
            <div style={{ width: 34, height: 34, borderRadius: 9, background: cat.color + '18', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><cat.icon size={16} style={{ color: cat.color }} /></div>
            <div>
              <div style={{ fontSize: 15, fontWeight: 700, color: C.ink }}>{row.proveedor}</div>
              <div style={{ fontSize: 12, color: C.mut }}>{cat.label} · RUT {row.rut}</div>
            </div>
          </div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: C.mut }}><X size={18} /></button>
        </div>
        <div style={{ padding: 22, display: 'flex', flexDirection: 'column', gap: 16 }}>
          <div><FieldLabel>Tipo de proveedor</FieldLabel><Badge color={tp.color} bg={tp.color + '18'} icon={tp.icon}>{tp.label}</Badge></div>
          <div><FieldLabel>Centro de Costo</FieldLabel><span style={{ fontSize: 13.5, color: C.ink, fontWeight: 600 }}>{CENTRO_LABEL[row.centroCosto]}</span></div>
          <div style={{ background: C.bg, borderRadius: C.rSm, padding: 14 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, color: C.sub, marginBottom: 6 }}><span>Monto bruto</span><span style={{ color: C.ink, fontWeight: 600 }}>{clp(row.montoBruto)}</span></div>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, color: C.err, marginBottom: 6 }}>
              <span>{esBHE ? `Retención SII (${(TASA_RETENCION_HONORARIOS * 100).toFixed(2)}%)` : 'IVA (19%)'}</span><span style={{ fontWeight: 600 }}>{esBHE ? '-' : '+'}{clp(row.montoRetencionOIva)}</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 14.5, paddingTop: 8, borderTop: `1px dashed ${C.borderD}`, marginTop: 4 }}>
              <span style={{ fontWeight: 700, color: C.ink }}>{esBHE ? 'Líquido a pagar' : 'Total a pagar (con IVA)'}</span>
              <span style={{ fontWeight: 700, color: C.pri }}>{clp(esBHE ? row.montoBruto - row.montoRetencionOIva : row.montoBruto + row.montoRetencionOIva)}</span>
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
            <div>
              <FieldLabel>{row.documento.tipo}</FieldLabel>
              <div style={{ fontSize: 13, color: C.ink, fontWeight: 600 }}>{row.documento.folio ? `N° ${row.documento.folio}` : 'Sin emitir'}</div>
            </div>
            <div><FieldLabel>Estado</FieldLabel><Badge color={est.color} bg={est.bg} icon={est.icon}>{est.label}</Badge></div>
          </div>
          <div style={{ fontSize: 11, color: C.mut, paddingTop: 10, borderTop: `1px solid ${C.border}` }}>Recurso FHIR asociado: <span style={{ fontFamily: 'monospace', background: C.bg, padding: '2px 6px', borderRadius: 4 }}>Invoice</span></div>
        </div>
      </div>
    </div>
  );
}

function NewHonorarioExternoModal({ onClose, onSave }) {
  const [form, setForm] = useState({ proveedor: '', tipoProveedor: 'empresa', categoria: 'ti', montoBruto: '' });
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });
  const puedeGuardar = form.proveedor.trim() && Number(form.montoBruto) > 0;
  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(16,24,40,.45)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100, padding: 20 }} onClick={onClose}>
      <div style={{ background: '#fff', borderRadius: C.rLg, width: 440, maxWidth: '100%', boxShadow: '0 20px 50px rgba(16,24,40,.25)' }} onClick={(e) => e.stopPropagation()}>
        <div style={{ padding: '18px 22px', borderBottom: `1px solid ${C.border}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ fontSize: 15, fontWeight: 700, color: C.ink }}>Registrar honorario externo</div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: C.mut }}><X size={18} /></button>
        </div>
        <div style={{ padding: 22, display: 'flex', flexDirection: 'column', gap: 13 }}>
          <div><FieldLabel>Proveedor</FieldLabel><input style={inputStyle} value={form.proveedor} onChange={set('proveedor')} placeholder="Ej: Estudio Jurídico Bravo & Asociados" /></div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <div><FieldLabel>Tipo</FieldLabel><select style={inputStyle} value={form.tipoProveedor} onChange={set('tipoProveedor')}>{Object.entries(TIPO_PROVEEDOR).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}</select></div>
            <div><FieldLabel>Categoría</FieldLabel><select style={inputStyle} value={form.categoria} onChange={set('categoria')}>{Object.entries(CATEGORIAS).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}</select></div>
          </div>
          <div>
            <FieldLabel>Monto bruto (CLP)</FieldLabel>
            <input style={inputStyle} type="number" value={form.montoBruto} onChange={set('montoBruto')} placeholder="2000000" />
            {Number(form.montoBruto) > 0 && (
              <div style={{ fontSize: 11.5, color: C.mut, marginTop: 5 }}>
                {form.tipoProveedor === 'persona_natural'
                  ? `Retención ${(TASA_RETENCION_HONORARIOS * 100).toFixed(2)}%: -${clp(Number(form.montoBruto) * TASA_RETENCION_HONORARIOS)} · Líquido: ${clp(Number(form.montoBruto) * (1 - TASA_RETENCION_HONORARIOS))}`
                  : `IVA 19%: +${clp(Number(form.montoBruto) * 0.19)} · Total: ${clp(Number(form.montoBruto) * 1.19)}`}
              </div>
            )}
          </div>
        </div>
        <div style={{ padding: '14px 22px', borderTop: `1px solid ${C.border}`, display: 'flex', justifyContent: 'flex-end', gap: 10 }}>
          <Btn variant="ghost" onClick={onClose}>Cancelar</Btn>
          <Btn variant="primary" icon={Plus} onClick={() => puedeGuardar && onSave(form)} style={{ opacity: puedeGuardar ? 1 : 0.5 }}>Registrar</Btn>
        </div>
      </div>
    </div>
  );
}

/* --------------------------------- vista principal ------------------------------------ */
export default function ContabilidadHonorariosExternos({ addToast }) {
  const toast = addToast || ((msg) => console.log(msg));
  const [data, setData] = useState(genMock);
  const [filtros, setFiltros] = useState({ desde: MESES_HEXT[0] + '-01', hasta: HOY_ISO_HEXT, categoria: 'todas', tipoProveedor: 'todos', estado: 'todos', q: '' });
  const [selected, setSelected] = useState(null);
  const [showNew, setShowNew] = useState(false);
  const [page, setPage] = useState(1);
  const perPage = 8;

  const filtered = useMemo(() => data.filter((r) => {
    if (r.fecha < filtros.desde || r.fecha > filtros.hasta) return false;
    if (filtros.categoria !== 'todas' && r.categoria !== filtros.categoria) return false;
    if (filtros.tipoProveedor !== 'todos' && r.tipoProveedor !== filtros.tipoProveedor) return false;
    if (filtros.estado !== 'todos' && r.estado !== filtros.estado) return false;
    if (filtros.q && !r.proveedor.toLowerCase().includes(filtros.q.toLowerCase())) return false;
    return true;
  }), [data, filtros]);

  const kpi = useMemo(() => calcularKPIsHonorariosExternos(filtered), [filtered]);
  const porCategoriaDisplay = kpi.porCategoria.filter((i) => i.monto > 0).map((item) => [item.id, CATEGORIAS[item.id], item.monto]);
  const porTipoDisplay = kpi.porTipoProveedor.map((item) => [item.id, TIPO_PROVEEDOR[item.id], item.monto]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / perPage));
  const pageRows = filtered.slice((page - 1) * perPage, page * perPage);
  const limpiarFiltros = () => { setFiltros({ desde: MESES_HEXT[0] + '-01', hasta: HOY_ISO_HEXT, categoria: 'todas', tipoProveedor: 'todos', estado: 'todos', q: '' }); setPage(1); };

  const exportarCSV = () => {
    const header = ['Fecha', 'Proveedor', 'RUT', 'Tipo', 'Categoría', 'Centro de Costo', 'Bruto', 'Retención/IVA', 'Documento', 'Folio', 'Estado'];
    const lines = filtered.map((r) => [r.fecha, r.proveedor, r.rut, TIPO_PROVEEDOR[r.tipoProveedor].label, CATEGORIAS[r.categoria].label, CENTRO_LABEL[r.centroCosto], r.montoBruto, r.montoRetencionOIva, r.documento.tipo, r.documento.folio || '', ESTADOS[r.estado].label].join(';'));
    const blob = new Blob([header.join(';') + '\n' + lines.join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = `honorarios_externos_${filtros.desde}_a_${filtros.hasta}.csv`; a.click();
    URL.revokeObjectURL(url);
    toast('Archivo CSV descargado');
  };

  const handleSave = (form) => {
    const montoBruto = Number(form.montoBruto);
    const esBHE = form.tipoProveedor === 'persona_natural';
    const montoRetencionOIva = Math.round(montoBruto * (esBHE ? TASA_RETENCION_HONORARIOS : 0.19));
    setData([{
      id: 'hext_' + (9000 + data.length), fecha: HOY_ISO_HEXT, fechaPago: null,
      proveedor: form.proveedor, rut: fakeRUT(data.length + 1), tipoProveedor: form.tipoProveedor,
      categoria: form.categoria, montoBruto, montoRetencionOIva, montoLiquidoONeto: montoBruto - montoRetencionOIva,
      documento: { tipo: esBHE ? 'Boleta de Honorarios' : 'Factura Electrónica', folio: null },
      estado: 'pendiente',
    }, ...data]);
    setShowNew(false);
    toast('Honorario externo registrado — pendiente de documento');
  };

  return (
    <div style={{ fontFamily: C.font, background: C.bg, minHeight: '100%', padding: 22 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 18, flexWrap: 'wrap', gap: 12 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
          <div style={{ width: 34, height: 34, borderRadius: 9, background: C.vioL, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Building2 size={17} style={{ color: C.vio }} /></div>
          <div>
            <div style={{ fontSize: 18, fontWeight: 700, color: C.ink }}>Honorarios Externos</div>
            <div style={{ fontSize: 12.5, color: C.mut }}>Consultoras y profesionales fuera del giro clínico — legal, auditoría, TI, gestión</div>
          </div>
        </div>
        <div style={{ display: 'flex', gap: 9 }}>
          <Btn variant="outline" icon={Download} onClick={exportarCSV}>Exportar CSV</Btn>
          <Btn variant="primary" icon={Plus} onClick={() => setShowNew(true)}>Nuevo honorario externo</Btn>
        </div>
      </div>

      <div style={{ fontSize: 11.5, fontWeight: 700, color: C.mut, textTransform: 'uppercase', letterSpacing: 0.4, marginBottom: 8 }}>Métricas del período</div>
      <div style={{ display: 'flex', gap: 14, marginBottom: 18, flexWrap: 'wrap' }}>
        <KPICard label="Gasto total" value={clp(kpi.totalBruto)} sub={`${kpi.documentos} documentos · ${kpi.proveedores} proveedores`} icon={Building2} accent={C.vio} />
        <KPICard label="Vía BHE (personas)" value={clp(kpi.totalPersonaNatural)} sub={`Retención: ${clp(kpi.totalRetencion)}`} icon={User} accent={C.info} />
        <KPICard label="Vía Factura (empresas)" value={clp(kpi.totalEmpresa)} sub={`IVA: ${clp(kpi.totalIVA)}`} icon={Building2} accent={C.teal} />
        <KPICard label="Pendiente de documento" value={clp(kpi.montoPendiente)} sub={`${kpi.pendienteCount} casos`} icon={Clock} accent={C.warn} />
      </div>

      <div style={{ fontSize: 11.5, fontWeight: 700, color: C.mut, textTransform: 'uppercase', letterSpacing: 0.4, marginBottom: 8 }}>Indicadores de gestión</div>
      <div style={{ display: 'flex', gap: 14, marginBottom: 14, flexWrap: 'wrap' }}>
        <KPICard label="Documentado" value={kpi.tasaDocumentado + '%'} sub="Meta: 100% antes del cierre" icon={FileText} accent={semaforo(kpi.tasaDocumentado, true, 95, 80)} />
        <KPICard label="Concentración" value={kpi.concentracionTop + '%'} sub="Del proveedor con mayor gasto" icon={Info} accent={semaforo(kpi.concentracionTop, false, 20, 35)} />
      </div>

      <div style={{ display: 'flex', gap: 14, marginBottom: 14, flexWrap: 'wrap' }}>
        <BreakdownCard title="Por categoría de servicio" items={porCategoriaDisplay} total={kpi.totalBruto} />
        <BreakdownCard title="Por tipo de proveedor" items={porTipoDisplay} total={kpi.totalBruto} />
      </div>

      <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, padding: 16, boxShadow: C.shadow, marginBottom: 14 }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 10, alignItems: 'end' }}>
          <div><FieldLabel>Desde</FieldLabel><input type="date" style={inputStyle} value={filtros.desde} onChange={(e) => { setFiltros({ ...filtros, desde: e.target.value }); setPage(1); }} /></div>
          <div><FieldLabel>Hasta</FieldLabel><input type="date" style={inputStyle} value={filtros.hasta} onChange={(e) => { setFiltros({ ...filtros, hasta: e.target.value }); setPage(1); }} /></div>
          <div><FieldLabel>Categoría</FieldLabel><select style={inputStyle} value={filtros.categoria} onChange={(e) => { setFiltros({ ...filtros, categoria: e.target.value }); setPage(1); }}><option value="todas">Todas</option>{Object.entries(CATEGORIAS).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}</select></div>
          <div><FieldLabel>Tipo</FieldLabel><select style={inputStyle} value={filtros.tipoProveedor} onChange={(e) => { setFiltros({ ...filtros, tipoProveedor: e.target.value }); setPage(1); }}><option value="todos">Todos</option>{Object.entries(TIPO_PROVEEDOR).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}</select></div>
          <div><FieldLabel>Buscar proveedor</FieldLabel><div style={{ position: 'relative' }}><Search size={14} style={{ position: 'absolute', left: 9, top: 10, color: C.mut }} /><input style={{ ...inputStyle, paddingLeft: 28 }} value={filtros.q} onChange={(e) => { setFiltros({ ...filtros, q: e.target.value }); setPage(1); }} /></div></div>
        </div>
        <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 12 }}>
          <button onClick={limpiarFiltros} style={{ display: 'flex', alignItems: 'center', gap: 5, background: 'none', border: 'none', cursor: 'pointer', color: C.sub, fontSize: 12.5, fontWeight: 600, padding: 0 }}><RotateCcw size={13} /> Limpiar filtros</button>
        </div>
      </div>

      <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: C.r, boxShadow: C.shadow, overflow: 'hidden' }}>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
            <thead>
              <tr style={{ background: C.bg, textAlign: 'left' }}>
                {['Fecha', 'Proveedor', 'Categoría', 'Tipo', 'Bruto', 'Documento', 'Estado', ''].map((h) => (
                  <th key={h} style={{ padding: '10px 14px', fontSize: 11.5, fontWeight: 700, color: C.sub, textTransform: 'uppercase', letterSpacing: 0.3, whiteSpace: 'nowrap' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {pageRows.map((r) => {
                const cat = CATEGORIAS[r.categoria], est = ESTADOS[r.estado], tp = TIPO_PROVEEDOR[r.tipoProveedor];
                return (
                  <tr key={r.id} style={{ borderTop: `1px solid ${C.border}`, cursor: 'pointer' }} onClick={() => setSelected(r)}
                    onMouseEnter={(e) => (e.currentTarget.style.background = C.bg)} onMouseLeave={(e) => (e.currentTarget.style.background = 'transparent')}>
                    <td style={{ padding: '11px 14px', color: C.sub, whiteSpace: 'nowrap' }}>{fmtDate(r.fecha)}</td>
                    <td style={{ padding: '11px 14px', fontWeight: 600, color: C.ink, maxWidth: 220 }}>{r.proveedor}</td>
                    <td style={{ padding: '11px 14px' }}><Badge color={cat.color} bg={cat.color + '18'} icon={cat.icon}>{cat.label}</Badge></td>
                    <td style={{ padding: '11px 14px' }}><Badge color={tp.color} bg={tp.color + '18'} icon={tp.icon}>{tp.label}</Badge></td>
                    <td style={{ padding: '11px 14px', fontWeight: 700, color: C.ink, whiteSpace: 'nowrap' }}>{clp(r.montoBruto)}</td>
                    <td style={{ padding: '11px 14px', color: C.sub, whiteSpace: 'nowrap' }}>{r.documento.folio ? `N° ${r.documento.folio}` : '—'}</td>
                    <td style={{ padding: '11px 14px' }}><Badge color={est.color} bg={est.bg} icon={est.icon}>{est.label}</Badge></td>
                    <td style={{ padding: '11px 14px' }}><Eye size={15} style={{ color: C.mut }} /></td>
                  </tr>
                );
              })}
              {pageRows.length === 0 && (
                <tr><td colSpan={8} style={{ padding: '40px 14px', textAlign: 'center', color: C.mut, fontSize: 13 }}>
                  No hay honorarios externos que calcen con estos filtros. <button onClick={limpiarFiltros} style={{ color: C.info, background: 'none', border: 'none', cursor: 'pointer', fontSize: 13, textDecoration: 'underline', padding: 0 }}>Limpia los filtros</button>.
                </td></tr>
              )}
            </tbody>
          </table>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 16px', borderTop: `1px solid ${C.border}` }}>
          <span style={{ fontSize: 12, color: C.mut }}>{filtered.length} registros · página {page} de {totalPages}</span>
          <div style={{ display: 'flex', gap: 6 }}>
            <Btn variant="outline" onClick={() => setPage(Math.max(1, page - 1))} style={{ padding: '6px 12px', opacity: page === 1 ? 0.4 : 1 }}>Anterior</Btn>
            <Btn variant="outline" onClick={() => setPage(Math.min(totalPages, page + 1))} style={{ padding: '6px 12px', opacity: page === totalPages ? 0.4 : 1 }}>Siguiente</Btn>
          </div>
        </div>
      </div>

      {selected && <DetailModal row={selected} onClose={() => setSelected(null)} />}
      {showNew && <NewHonorarioExternoModal onClose={() => setShowNew(false)} onSave={handleSave} />}
    </div>
  );
}
