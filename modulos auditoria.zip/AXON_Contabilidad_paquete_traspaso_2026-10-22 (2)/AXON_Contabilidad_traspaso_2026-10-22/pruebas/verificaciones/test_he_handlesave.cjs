// Verifica el fix de handleSave (Honorarios Externos) ejecutando el handleSave REAL del componente,
// capturado desde el render con stubs mínimos de react / lucide-react.
const fs = require('fs');
const esb = require('/home/claude/.npm-global/lib/node_modules/tsx/node_modules/esbuild');

function cargar(ruta) {
  const src = fs.readFileSync(ruta, 'utf8') + '\nexport const __t = { CATEGORIAS, CENTRO_POR_CATEGORIA, CENTRO_LABEL };\n';
  const { code } = esb.transformSync(src, { loader: 'jsx', format: 'cjs', logLevel: 'silent' });
  const cap = { elementos: [], setters: [], estados: [] };
  const React = {
    createElement: (type, props, ...children) => { const el = { type, props: props || {}, children }; cap.elementos.push(el); return el; },
    useState: (init) => {
      const v = typeof init === 'function' ? init() : init;
      cap.estados.push(v);
      return [init === false ? true : v, (nv) => cap.setters.push(nv)]; // fuerza showNew=true (único useState(false))
    },
    useMemo: (fn) => fn(),
  };
  const mod = { exports: {} };
  const req = (n) => { if (n === 'react') return React; if (n === 'lucide-react') return {}; throw new Error('require inesperado: ' + n); };
  new Function('require', 'module', 'exports', code)(req, mod, mod.exports);
  return { m: mod.exports, cap };
}

function probar(ruta) {
  const { m, cap } = cargar(ruta);
  m.default({ addToast: () => {} });
  const modal = cap.elementos.find((e) => typeof e.type === 'function' && e.type.name === 'NewHonorarioExternoModal');
  if (!modal) throw new Error('no se montó NewHonorarioExternoModal (¿cambió el orden de hooks?)');
  const { CATEGORIAS, CENTRO_POR_CATEGORIA, CENTRO_LABEL } = m.__t;
  const casos = [];
  for (const cat of Object.keys(CATEGORIAS)) for (const tipo of ['persona_natural', 'empresa']) {
    cap.setters.length = 0;
    modal.props.onSave({ proveedor: 'Proveedor Prueba', tipoProveedor: tipo, categoria: cat, montoBruto: '1000000' });
    const rec = cap.setters.find(Array.isArray)[0];
    const k = m.calcularKPIsHonorariosExternos([rec]);
    const sumCentros = k.porCentro.reduce((s, c) => s + c.monto, 0);
    casos.push({ cat, tipo, tieneCentro: rec.centroCosto === CENTRO_POR_CATEGORIA[cat],
      etiquetaOk: CENTRO_LABEL[rec.centroCosto] !== undefined, kpiCuadra: sumCentros === k.totalBruto });
  }
  const cobertura = Object.keys(CATEGORIAS).every((c) => CENTRO_POR_CATEGORIA[c] && CENTRO_LABEL[CENTRO_POR_CATEGORIA[c]]);
  return { m, cap, casos, cobertura, nCat: Object.keys(CATEGORIAS).length };
}

const a = probar('/home/claude/work/ContabilidadHonorariosExternos.orig.jsx');
const b = probar('/home/claude/work/ContabilidadHonorariosExternos.jsx');
const resumen = (r) => { const n = r.casos.length, ok = (f) => r.casos.filter(f).length;
  return `centroCosto asignado ${ok((c) => c.tieneCentro)}/${n} · etiqueta definida ${ok((c) => c.etiquetaOk)}/${n} · desglose por centro cuadra con el total ${ok((c) => c.kpiCuadra)}/${n}`; };
console.log('ORIGINAL  →', resumen(a));
console.log('CORREGIDO →', resumen(b));
console.log(`cobertura categoría→centro (${b.nCat} categorías, todas con etiqueta):`, b.cobertura);
const kA = JSON.stringify(a.m.calcularKPIsHonorariosExternos(a.cap.estados[0]));
const kB = JSON.stringify(b.m.calcularKPIsHonorariosExternos(b.cap.estados[0]));
console.log(`regresión: KPI sobre los datos iniciales idéntico entre versiones: ${kA === kB} (${a.cap.estados[0].length} filas)`);
const fallas = b.casos.filter((c) => !(c.tieneCentro && c.etiquetaOk && c.kpiCuadra)).length;
const bugReproducido = a.casos.every((c) => !c.tieneCentro);
console.log(`bug original reproducido en todos los casos: ${bugReproducido} | fallas en la versión corregida: ${fallas}`);
process.exit(fallas === 0 && bugReproducido && kA === kB && b.cobertura ? 0 : 1);
