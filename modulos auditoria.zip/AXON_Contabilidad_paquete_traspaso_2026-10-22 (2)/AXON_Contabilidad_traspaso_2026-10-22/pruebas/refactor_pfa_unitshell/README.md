# Refactor Patient Financial Profile (3 niveles) + contexto organizacional UnitShell v2.0
Archivo: ContabilidadIngresos.jsx · Estado al 2026-10-16: COMPLETO Y VERIFICADO (916 aserciones OK, 0 fallas)

Entregable vigente: ../ContabilidadIngresos.jsx (1.752 líneas, 33 exports; el original tenía 1.424 líneas y 28).

## Qué cambió
Solo el bloque "Charge + PatientFinancialAccount" (original, líneas 169-202: construirCharge y
resolverPatientFinancialAccount). Cabecera (líneas 1-168), cola (1.222 líneas: átomos, mock, render, JSX)
e imports son idénticos al original: la pantalla no se tocó.

Exports nuevos (5): resolverOrgNode · resolverContextoOrganizacional · construirEpisodeFinancialAccounts (nivel 1)
· resolverTenantPatientFinancialView (nivel 2) · resolverPatientFinancialProfile (nivel 3).
Compatibilidad: construirCharge(row, ctx?) tiene 2º argumento opcional y ahora agrega organizationalContext.
resolverPatientFinancialAccount(rows, rut) queda @deprecated con la misma firma y la misma salida.

## Contenido de esta carpeta
- ContabilidadIngresos.orig.jsx: original previo al refactor (para diff)
- block_p1.jsx / block_p2.jsx / block_p3.jsx: los tres bloques nuevos (OrgNode+Charge · Episodios · Vista tenant+Perfil)
- patch_ingresos.py: splice que reemplaza el bloque viejo por los tres nuevos
- build_tests.cjs: transpila original y refactor a ESM con esbuild y genera los stubs de react/lucide-react
- test/test_a.mjs (suite T1-T4) · test/harness.mjs (helpers de aserción)

## Re-verificar tras un reinicio del sandbox
1. Crear /home/claude/work/test. En /home/claude/work copiar: ../ContabilidadIngresos.jsx, ContabilidadIngresos.orig.jsx
   y build_tests.cjs. En /home/claude/work/test copiar: test/test_a.mjs y test/harness.mjs.
2. Requiere Node >= 22 y esbuild en /home/claude/.npm-global/lib/node_modules/tsx/node_modules/esbuild
   (ruta fija en la línea 3 de build_tests.cjs).
3. Desde /home/claude/work:  node build_tests.cjs && node test/test_a.mjs
   Resultado esperado: "916 aserciones OK, 0 fallas".

## Nota de verificación
T4.6 falló una vez por una ruta incorrecta en el propio test (leía enc.orgNodeIds en lugar de
enc.organizationalContext.orgNodeIds, que es la convención del nivel 3 y de T3.11). Se corrigió el test;
el código de producción no cambió.

## Importante
/mnt/project es de solo lectura: para que un chat nuevo del proyecto vea esta versión hay que subir
../ContabilidadIngresos.jsx al proyecto.
