/* ═══════════════════════════════════════════════════════════════════════
   REFACTOR 2026-10-08 — UnitShell v2.0 + Patient Financial Profile (3 niveles)
   Decidido en UN SOLO PASE (2026-10-06) porque ambos tocan construirCharge().
   Sigue siendo aditivo: no se tocó el render de la pantalla, `unidad` se
   conserva en cada Charge y resolverPatientFinancialAccount() sigue
   existiendo (ver su @deprecated más abajo).

   (1) UnitShell v2.0 — la estructura organizacional real es un árbol de
   OrgNode; `unidad` (la clave operacional de esta pantalla) NO es centro de
   costo ni centro de responsabilidad. Acá solo se resuelve la referencia
   organizacional (OrgNode) "as-of" la fecha de la prestación. CR/CC,
   Cost Allocation y PublicBudgetContext quedan fuera de este pase (ver
   dossier, Parte 13).

   (2) Patient Financial Profile — 3 niveles, entidades separadas:
       EpisodeFinancialAccount    → una cuenta por episodio/atención
       TenantPatientFinancialView → todas las del paciente DENTRO de un tenant
       PatientFinancialProfile    → vista longitudinal multi-tenant AUTORIZADA
   El Profile es una PROYECCIÓN DE LECTURA: nunca es libro mayor ni una única
   cuenta por cobrar — cada deuda sigue perteneciendo a su tenant/entidad.
   ═══════════════════════════════════════════════════════════════════════ */

/* Registro MOCK de OrgNodes. `unitKey` es la clave operacional que hoy usa
   esta pantalla (UNIDADES); `orgNodeId` es la referencia canónica de
   UnitShell. Vigencias INCLUSIVAS y abiertas con null — una reorganización
   se modela agregando un nodo nuevo con effectiveFrom y cerrando el anterior
   con effectiveTo (nunca editando el viejo), para que el historial no se
   reescriba. Los IDs son provisionales: el día que MAIN entregue el registro
   real de OrgNode, cambia el cuerpo de resolverOrgNode(), no su firma. */
const ORGNODES_MOCK = [
  { orgNodeId: 'orgn_001', unitKey: 'atencion_presencial', nodeType: 'UNIT', effectiveFrom: null, effectiveTo: null },
  { orgNodeId: 'orgn_002', unitKey: 'urgencias', nodeType: 'UNIT', effectiveFrom: null, effectiveTo: null },
  { orgNodeId: 'orgn_003', unitKey: 'hospitalizacion', nodeType: 'UNIT', effectiveFrom: null, effectiveTo: null },
  { orgNodeId: 'orgn_004', unitKey: 'pabellon', nodeType: 'UNIT', effectiveFrom: null, effectiveTo: null },
  { orgNodeId: 'orgn_005', unitKey: 'imagenologia', nodeType: 'UNIT', effectiveFrom: null, effectiveTo: null },
  { orgNodeId: 'orgn_006', unitKey: 'laboratorio', nodeType: 'UNIT', effectiveFrom: null, effectiveTo: null },
  { orgNodeId: 'orgn_007', unitKey: 'telemedicina', nodeType: 'UNIT', effectiveFrom: null, effectiveTo: null },
  { orgNodeId: 'orgn_008', unitKey: 'farmacia', nodeType: 'UNIT', effectiveFrom: null, effectiveTo: null },
];

/**
 * Resuelve el OrgNode de una unidad operacional "as-of" una fecha (ISO
 * YYYY-MM-DD, comparación lexicográfica). Nunca adivina: si no hay nodo
 * vigente → UNRESOLVED; si hay más de uno (vigencias solapadas) →
 * AMBIGUOUS con la lista de candidatos y orgNodeId null. En ambos casos el
 * cálculo sigue, pero el caso queda VISIBLE (se cuenta en las vistas) en
 * vez de perderse o imputarse a un nodo elegido a ciegas.
 */
export function resolverOrgNode(unitKey, asOfDate, registro = ORGNODES_MOCK) {
  if (!unitKey || !asOfDate) return { status: 'UNRESOLVED', orgNodeId: null, nodeType: null, candidates: [] };
  const vigentes = registro.filter((n) => n.unitKey === unitKey
    && (!n.effectiveFrom || n.effectiveFrom <= asOfDate)
    && (!n.effectiveTo || asOfDate <= n.effectiveTo));
  if (vigentes.length === 1) return { status: 'RESOLVED', orgNodeId: vigentes[0].orgNodeId, nodeType: vigentes[0].nodeType, candidates: [] };
  if (vigentes.length === 0) return { status: 'UNRESOLVED', orgNodeId: null, nodeType: null, candidates: [] };
  return { status: 'AMBIGUOUS', orgNodeId: null, nodeType: null, candidates: vigentes.map((n) => n.orgNodeId).sort() };
}

/**
 * Contexto organizacional de una fila de Ingresos (forma de
 * `organizationalContext` del FinancialEvent de UnitShell v2.0). La fecha
 * "as-of" es la de la prestación (`asOfBasis: 'SERVICE_DATE'`): hoy Ingresos
 * no captura accountingDate; cuando exista, solo cambia esa base. subunitId /
 * serviceId / locationId se toman de la fila si vienen (null si no) — no se
 * deducen de la unidad.
 */
export function resolverContextoOrganizacional(row, tenantContext, registro = ORGNODES_MOCK) {
  const t = tenantContext || {};
  const asOfDate = row.fecha;
  const nodo = resolverOrgNode(row.unidad, asOfDate, registro);
  return {
    tenantId: t.tenantId ?? null,
    legalEntityId: t.legalEntityId ?? null,
    branchId: t.branchId ?? null,
    orgNodeId: nodo.orgNodeId,
    subunitId: row.subunitId ?? null,
    serviceId: row.serviceId ?? null,
    locationId: row.locationId ?? null,
    asOfDate,
    asOfBasis: 'SERVICE_DATE',
    mappingStatus: nodo.status,
    mappingCandidates: nodo.candidates,
  };
}

/**
 * Charge — extrae el "hecho de cobro" de una fila de Ingresos, separado de
 * Payment/Invoice/Revenue. No reemplaza la fila original, la envuelve —
 * `sourceRowId` conserva la trazabilidad hacia ella.
 *
 * 2026-10-08: agrega `organizationalContext` (OrgNode resuelto as-of la fecha
 * de la prestación). `unidad` se conserva tal cual. El 2º parámetro es
 * OPCIONAL y se ignora si no es un objeto: así sigue siendo válido
 * `rows.map(construirCharge)` (que pasa el índice como 2º argumento), que es
 * como lo llamaba la versión anterior.
 */
export function construirCharge(row, ctx) {
  const opts = ctx && typeof ctx === 'object' ? ctx : {};
  return {
    chargeId: `chg_${row.id}`,
    serviceDate: row.fecha,
    counterparty: resolverContraparte(row),
    unidad: row.unidad,
    organizationalContext: resolverContextoOrganizacional(row, opts.tenantContext, opts.registroOrgNodes),
    grossAmount: row.monto,
    taxResult: row.taxResult || determinarImpuesto(row.unidad, row.pagador),
    status: row.estado,
    sourceRowId: row.id,
  };
}

