import re, sys
orig = open('ContabilidadIngresos.orig.jsx', encoding='utf-8').read()

# 1) ubicar el bloque a reemplazar: desde el JSDoc de construirCharge hasta antes del encabezado de la Fase 6
k_charge = orig.index(' * Charge — extrae el "hecho de cobro"')
start = orig.rfind('/**', 0, k_charge)
k_f6 = orig.index('   FASE 6 DEL PLAN DE TRABAJO (2026-09-09) — Dominios de prepago')
end = orig.rfind('/* ═', 0, k_f6)
assert orig.count(' * Charge — extrae el "hecho de cobro"') == 1
assert orig.count('   FASE 6 DEL PLAN DE TRABAJO (2026-09-09) — Dominios de prepago') == 1
assert start < end
old = orig[start:end]
fns = re.findall(r'export function (\w+)', old)
print('funciones exportadas en el bloque viejo:', fns)
assert fns == ['construirCharge', 'resolverPatientFinancialAccount'], fns

# 2) el bloque nuevo (3 partes)
new = ''.join(open(f, encoding='utf-8').read() for f in ('block_p1.jsx', 'block_p2.jsx', 'block_p3.jsx'))

# 3) no pisar identificadores existentes fuera del bloque viejo
resto = orig[:start] + orig[end:]
for ident in ['ORGNODES_MOCK', 'resolverOrgNode', 'resolverContextoOrganizacional', 'MONEDA_DEFAULT', 'idOpaco',
              'totalesDeFilas', 'porId', 'claveEpisodio', 'construirEpisodeFinancialAccounts',
              'resolverTenantPatientFinancialView', 'mismoPacienteRef', 'CLAVES_TOTALES', 'soloTotales',
              'resolverPatientFinancialProfile']:
    assert not re.search(r'\b' + ident + r'\b', resto), 'colisión de identificador: ' + ident

out = orig[:start] + new + orig[end:]
open('ContabilidadIngresos.jsx', 'w', encoding='utf-8').write(out)
print('bloque viejo: %d líneas | bloque nuevo: %d líneas' % (old.count('\n'), new.count('\n')))
print('archivo: %d -> %d líneas' % (orig.count('\n'), out.count('\n')))
