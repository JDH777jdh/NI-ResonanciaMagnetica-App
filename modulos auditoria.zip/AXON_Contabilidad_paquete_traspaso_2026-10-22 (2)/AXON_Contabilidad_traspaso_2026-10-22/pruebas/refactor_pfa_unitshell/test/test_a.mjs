import { N, O, ok, deepEq, fila, report } from './harness.mjs';
const sinOrg = (c) => { const { organizationalContext, ...r } = c; return r; };
const rowsMock = N.genMock();

// ───── T1 · paridad con la función ORIGINAL (resumen plano) ─────
deepEq(O.genMock(), rowsMock, 'T1.0 genMock idéntico (los datos de prueba no cambiaron)');
const ruts = [...new Set(rowsMock.map((r) => r.rut))];
ruts.forEach((rut) => {
  const { charges: ca, ...ra } = O.resolverPatientFinancialAccount(rowsMock, rut);
  const { charges: cb, ...rb } = N.resolverPatientFinancialAccount(rowsMock, rut);
  deepEq(rb, ra, `T1.1 resumen plano igual (${rut})`);
  deepEq(cb.map(sinOrg), ca, `T1.2 charges iguales sin organizationalContext (${rut})`);
});
const A = '22.222.222-2', B = '33.333.333-3';
const fx = [
  fila({ id: 'a1', rut: A, paciente: 'Ana', unidad: 'urgencias', fecha: '2026-05-10', monto: 30000 }),
  fila({ id: 'b1', rut: B, paciente: 'Beto', unidad: 'laboratorio', fecha: '2026-05-11', monto: 9500, pagador: 'particular', estado: 'pendiente' }),
  fila({ id: 'a2', rut: A, paciente: 'Ana', unidad: 'urgencias', fecha: '2026-05-10', monto: 12000, pagador: 'particular', estado: 'pendiente' }),
  fila({ id: 'a3', rut: A, paciente: 'Ana', unidad: 'imagenologia', fecha: '2026-05-12', monto: 48000, pagador: 'fonasa_mle', estado: 'facturado' }),
  fila({ id: 'a4', rut: A, paciente: 'Ana', unidad: 'pabellon', fecha: '2026-06-02', monto: 1500000, estado: 'anulado' }),
];
[A, B, '99.999.999-9'].forEach((rut) => {
  const { charges: ca, ...ra } = O.resolverPatientFinancialAccount(fx, rut);
  const { charges: cb, ...rb } = N.resolverPatientFinancialAccount(fx, rut);
  deepEq(rb, ra, `T1.3 fixture multi-fila: resumen igual (${rut})`);
  deepEq(cb.map(sinOrg), ca, `T1.3b fixture: charges iguales en el mismo orden (${rut})`);
});
const vA = N.resolverTenantPatientFinancialView(fx, { rut: A }, { tenantId: 'T1' });
const leg = O.resolverPatientFinancialAccount(fx, A);
deepEq({ a: vA.totalCargos, b: vA.totalCopago, c: vA.totalBonificacion, d: vA.montoPendiente },
       { a: leg.totalCargos, b: leg.totalCopago, c: leg.totalBonificacion, d: leg.montoPendiente }, 'T1.4 los 3 niveles conservan la aritmética legada');
ok(vA.montoAnulado === 1500000 && vA.totalCargosVigentes === leg.totalCargos - 1500000, 'T1.5 anulado se separa del vigente; totalCargos sigue siendo bruto');

// ───── T2 · construirCharge compatible y consumidores intactos ─────
rowsMock.forEach((r) => deepEq(sinOrg(N.construirCharge(r)), O.construirCharge(r), `T2.1 charge igual (${r.id})`));
deepEq(rowsMock.slice(0, 40).map(N.construirCharge), rowsMock.slice(0, 40).map((r) => N.construirCharge(r)), 'T2.2 rows.map(construirCharge) no se contamina con (índice, arreglo)');
rowsMock.forEach((r) => {
  const oc = N.construirCharge(r).organizationalContext;
  ok(oc.mappingStatus === 'RESOLVED' && oc.orgNodeId && oc.asOfDate === r.fecha && oc.asOfBasis === 'SERVICE_DATE' && oc.tenantId === null, `T2.3 contexto organizacional del mock (${r.id})`);
});
for (const pg of ['isapre', 'fonasa_mle', 'mutual', 'convenio_institucional', 'particular']) {
  const r = rowsMock.find((x) => x.pagador === pg);
  const cN = N.construirCharge(r), cO = O.construirCharge(r);
  deepEq(N.crearClaim(cN), O.crearClaim(cO), `T2.4 crearClaim igual (${pg})`);
  const ls = [{ source: 'PAYER', amount: r.montoBonificacion, reference: 'c' }, { source: 'PATIENT', amount: r.montoCopago, reference: 'p' }];
  deepEq(N.crearAllocation(cN, ls), O.crearAllocation(cO, ls), `T2.5 crearAllocation igual (${pg})`);
}
const ctxRow = fila({ id: 'ctx1', subunitId: 'sub_7', serviceId: 'svc_2', locationId: 'loc_9' });
const oc = N.construirCharge(ctxRow, { tenantContext: { tenantId: 'T1', legalEntityId: 'LE1', branchId: 'BR1' } }).organizationalContext;
deepEq([oc.subunitId, oc.serviceId, oc.locationId, oc.tenantId, oc.legalEntityId, oc.branchId], ['sub_7', 'svc_2', 'loc_9', 'T1', 'LE1', 'BR1'], 'T2.6 subunit/service/location y tenant/entity/branch pasan desde la fila y el contexto');

// ───── T3 · contexto organizacional AS-OF (reorganización no reescribe la historia) ─────
const reg = [
  { orgNodeId: 'orgn_A', unitKey: 'imagenologia', nodeType: 'UNIT', effectiveFrom: null, effectiveTo: '2026-12-31' },
  { orgNodeId: 'orgn_B', unitKey: 'imagenologia', nodeType: 'UNIT', effectiveFrom: '2027-01-01', effectiveTo: null },
  { orgNodeId: 'orgn_X1', unitKey: 'urgencias', nodeType: 'UNIT', effectiveFrom: null, effectiveTo: null },
  { orgNodeId: 'orgn_X2', unitKey: 'urgencias', nodeType: 'UNIT', effectiveFrom: '2026-06-01', effectiveTo: null },
  { orgNodeId: 'orgn_F', unitKey: 'farmacia', nodeType: 'UNIT', effectiveFrom: '2026-03-01', effectiveTo: null },
];
const R = (u, d) => N.resolverOrgNode(u, d, reg);
deepEq([R('imagenologia', '2026-01-15').orgNodeId, R('imagenologia', '2026-12-31').orgNodeId, R('imagenologia', '2027-01-01').orgNodeId], ['orgn_A', 'orgn_A', 'orgn_B'], 'T3.1 corte de vigencia inclusivo (31-dic → A, 1-ene → B)');
const antes = [{ orgNodeId: 'orgn_A', unitKey: 'imagenologia', nodeType: 'UNIT', effectiveFrom: null, effectiveTo: null }];
deepEq(N.resolverOrgNode('imagenologia', '2026-12-31', antes), R('imagenologia', '2026-12-31'), 'T3.2 agregar el nodo nuevo NO cambia cómo se resuelve una fecha pasada');
deepEq([R('urgencias', '2026-05-31').status, R('urgencias', '2026-06-01').status], ['RESOLVED', 'AMBIGUOUS'], 'T3.3 vigencias solapadas → AMBIGUOUS');
deepEq(R('urgencias', '2026-06-01'), { status: 'AMBIGUOUS', orgNodeId: null, nodeType: null, candidates: ['orgn_X1', 'orgn_X2'] }, 'T3.4 AMBIGUOUS no elige nodo y lista candidatos');
deepEq([R('farmacia', '2026-02-28').status, R('farmacia', '2026-03-01').status], ['UNRESOLVED', 'RESOLVED'], 'T3.5 antes de la primera vigencia → UNRESOLVED');
deepEq([R('quirofano_inexistente', '2026-05-01').status, R('urgencias', undefined).status, R(undefined, '2026-05-01').status], ['UNRESOLVED', 'UNRESOLVED', 'UNRESOLVED'], 'T3.6 unidad desconocida / sin fecha → UNRESOLVED');
deepEq([...N.ORGNODES_MOCK.map((n) => n.unitKey)].sort(), Object.keys(N.UNIDADES).sort(), 'T3.7 el registro mock cubre exactamente las unidades de la pantalla');
ok(new Set(N.ORGNODES_MOCK.map((n) => n.orgNodeId)).size === N.ORGNODES_MOCK.length, 'T3.8 orgNodeId únicos');
Object.keys(N.UNIDADES).forEach((u) => ['2026-01-01', '2026-07-05', '2030-01-01'].forEach((d) => ok(N.resolverOrgNode(u, d).status === 'RESOLVED', `T3.9 mock RESOLVED (${u}, ${d})`)));
const mixto = ['2026-05-31', '2026-06-01'].map((f, i) => fila({ id: 'm' + i, rut: A, unidad: 'urgencias', fecha: f })).concat([fila({ id: 'm2', rut: A, unidad: 'farmacia', fecha: '2026-02-28' }), fila({ id: 'm3', rut: A, unidad: 'farmacia', fecha: '2026-03-01' })]);
const vm = N.resolverTenantPatientFinancialView(mixto, { rut: A }, { tenantId: 'T1' }, { registroOrgNodes: reg });
ok(vm.cargosSinContextoOrganizacional === 2, 'T3.10 la vista cuenta los cargos sin contexto (1 AMBIGUOUS + 1 UNRESOLVED)');
ok(vm.episodes.every((e) => e.organizationalContext.orgNodeIds.every((x) => x !== null)), 'T3.11 orgNodeIds nunca incluye null');

// ───── T4 · EpisodeFinancialAccount (nivel 1) y vista por tenant (nivel 2) ─────
const P = { rut: '11.111.111-1' };
const E = [
  fila({ id: 'e1', unidad: 'urgencias', fecha: '2026-05-10', monto: 30000 }),
  fila({ id: 'e2', unidad: 'urgencias', fecha: '2026-05-10', monto: 12000, pagador: 'particular' }),
  fila({ id: 'e3', unidad: 'imagenologia', fecha: '2026-05-10', monto: 48000 }),
  fila({ id: 'e4', unidad: 'urgencias', fecha: '2026-06-02', monto: 25000, estado: 'anulado' }),
  fila({ id: 'e5', unidad: 'hospitalizacion', fecha: '2026-07-01', monto: 210000, estado: 'pendiente', encounterId: 'ENC1' }),
  fila({ id: 'e6', unidad: 'pabellon', fecha: '2026-07-02', monto: 1000000, estado: 'facturado', encounterId: 'ENC1' }),
  fila({ id: 'e7', unidad: 'farmacia', fecha: '2026-07-03', monto: 26000, episodeOfCareId: 'EOC9', encounterId: 'ENC2' }),
  fila({ id: 'e8', unidad: 'laboratorio', fecha: '2026-07-04', monto: 9500, episodeOfCareId: 'EOC9', encounterId: 'ENC3' }),
];
const v = N.resolverTenantPatientFinancialView(E, P, { tenantId: 'T1' });
ok(v.episodes.length === 5, 'T4.1 5 episodios (e1+e2 / e3 / e4 / e5+e6 por encounter / e7+e8 por episodio de cuidado)');
deepEq(v.episodes.map((e) => e.episodeSource).sort(), ['DERIVED_DEFAULT', 'DERIVED_DEFAULT', 'DERIVED_DEFAULT', 'ENCOUNTER', 'EPISODE_OF_CARE'], 'T4.2 fuente declarada de cada episodio');
deepEq(v.episodes.flatMap((e) => e.clinicalFinancialLink.chargeIds).sort(), E.map((r) => 'chg_' + r.id).sort(), 'T4.3 partición: cada cargo en exactamente un episodio');
const tot = N.totalesDeFilas(E);
Object.keys(tot).forEach((k) => ok(v.episodes.reduce((s, e) => s + e[k], 0) === tot[k] && v[k] === tot[k], `T4.4 conservación de ${k} (Σ episodios = vista = filas)`));
ok(v.montoAnulado === 25000 && v.montoPendiente === 210000 && v.totalCargosVigentes === v.totalCargos - 25000, 'T4.5 anulado / pendiente de facturar / vigente');
const enc = v.episodes.find((e) => e.episodeSource === 'ENCOUNTER'), eoc = v.episodes.find((e) => e.episodeSource === 'EPISODE_OF_CARE');
deepEq([enc.periodo, enc.organizationalContext.orgNodeIds, enc.unidades, enc.clinicalFinancialLink.encounterIds], [{ desde: '2026-07-01', hasta: '2026-07-02' }, ['orgn_003', 'orgn_004'], ['hospitalizacion', 'pabellon'], ['ENC1']], 'T4.6 un encounter que cruza días y unidades es UN episodio');
deepEq([eoc.clinicalFinancialLink.episodeOfCareId, eoc.clinicalFinancialLink.encounterIds], ['EOC9', ['ENC2', 'ENC3']], 'T4.7 el episodio de cuidado agrupa varios encounters');
ok(v.watermark === '2026-07-04' && v.patientRef.source === 'RUT_FALLBACK' && v.currency === 'CLP', 'T4.8 watermark / patientRef / moneda');
deepEq(N.resolverTenantPatientFinancialView([...E].reverse(), P, { tenantId: 'T1' }), v, 'T4.9 invariante al orden de las filas (reversa)');
deepEq(N.resolverTenantPatientFinancialView([...E.slice(3), ...E.slice(0, 3)], P, { tenantId: 'T1' }), v, 'T4.10 invariante al orden (rotación)');
const ids = v.episodes.map((e) => e.episodeFinancialAccountId);
ok(new Set(ids).size === ids.length && ids.every((i) => /^efa_[0-9a-z]{14}$/.test(i) && !i.includes('11111111')), 'T4.11 IDs únicos, con formato opaco y sin el RUT');
ok(N.resolverTenantPatientFinancialView(E, P, { tenantId: 'T2' }).viewId !== v.viewId && N.resolverTenantPatientFinancialView(E, P, { tenantId: 'T2' }).episodes[0].episodeFinancialAccountId !== v.episodes[0].episodeFinancialAccountId, 'T4.12 el mismo paciente en otro tenant tiene otros IDs');
const cr = [fila({ id: 'c1', cup: 'CUP-1', rut: '55.555.555-5' }), fila({ id: 'c2', cup: 'CUP-1', rut: '66.666.666-6' }), fila({ id: 'c3', cup: 'CUP-2', rut: '55.555.555-5' }), fila({ id: 'c4', rut: '55.555.555-5' })];
const vc = N.resolverTenantPatientFinancialView(cr, { cup: 'CUP-1', rut: '55.555.555-5' }, { tenantId: 'T1' });
deepEq(vc.episodes.flatMap((e) => e.clinicalFinancialLink.chargeIds).sort(), ['chg_c1', 'chg_c2', 'chg_c4'], 'T4.13 CUP manda si ambos lo tienen (c2 entra, c3 no); sin CUP en la fila cae a RUT (c4)');
ok(vc.patientRef.source === 'CUP', 'T4.14 patientRef.source = CUP');
ok(N.resolverTenantPatientFinancialView(E, {}, { tenantId: 'T1' }).error && N.resolverTenantPatientFinancialView(E, undefined, null).error, 'T4.15 sin identificador de paciente → { error }');
ok(N.resolverTenantPatientFinancialView([], P, { tenantId: 'T1' }).episodes.length === 0 && N.resolverTenantPatientFinancialView([], P, { tenantId: 'T1' }).totalCargos === 0, 'T4.16 paciente sin filas → vista vacía en cero');
report('test_a (paridad legada · charge · as-of · episodios)');
