export const N = await import('./ingresos.new.mjs');
export const O = await import('./ingresos.orig.mjs');
let pass = 0; const fallos = [];
export const ok = (c, msg) => { if (c) pass++; else fallos.push(msg); };
export const stable = (x) => JSON.stringify(x, (k, v) => (v && typeof v === 'object' && !Array.isArray(v)) ? Object.fromEntries(Object.entries(v).sort(([a], [b]) => (a < b ? -1 : 1))) : v);
export const deepEq = (a, b, msg) => ok(stable(a) === stable(b), `${msg}\n     got: ${String(stable(a)).slice(0, 220)}\n     exp: ${String(stable(b)).slice(0, 220)}`);
let seq = 9000;
export function fila(o = {}) {
  const monto = o.monto ?? 30000, pagador = o.pagador ?? 'isapre';
  const { montoCopago, montoBonificacion } = N.calcularDesgloseCopago(monto, pagador);
  return { id: `fx_${++seq}`, fecha: '2026-05-10', paciente: 'Paciente Prueba', rut: '11.111.111-1', unidad: 'urgencias', prestacion: 'Prestación',
    pagador, isapreNombre: pagador === 'isapre' ? 'Consalud' : null, convenioNombre: null, convenioCUC: null, agreementId: null,
    monto, montoCopago, montoBonificacion, estado: 'pagado', ...o };
}
export function report(titulo) {
  console.log(`${titulo}: ${pass} aserciones OK, ${fallos.length} fallas`);
  fallos.forEach((f) => console.log('  ✗ ' + f));
  if (fallos.length) process.exitCode = 1;
}
