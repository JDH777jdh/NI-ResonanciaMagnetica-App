const MONEDA_DEFAULT = 'CLP';

// ID técnico PROVISIONAL y determinístico (dos acumuladores de 32 bits): existe
// solo para que el mock sea reproducible y para que ningún ID lleve el RUT en
// claro. NO es privacidad fuerte (un RUT se puede recomputar por fuerza bruta).
// En producción los emite el Master Identifier Service — el frontend nunca es
// autoridad emisora de identificadores.
function idOpaco(prefijo, ...partes) {
  const s = partes.map((p) => String(p ?? '')).join('\u001f');
  let h1 = 0x811c9dc5, h2 = 0xdeadbeef;
  for (let i = 0; i < s.length; i++) {
    const c = s.charCodeAt(i);
    h1 = Math.imul(h1 ^ c, 0x01000193) >>> 0;
    h2 = Math.imul(h2 ^ c, 0x5bd1e995) >>> 0;
    h2 = (h2 ^ (h2 >>> 15)) >>> 0;
  }
  return `${prefijo}_${h1.toString(36).padStart(7, '0')}${h2.toString(36).padStart(7, '0')}`;
}

// Una sola fuente de la aritmética para los 3 niveles (y para el resumen plano
// legado). `totalCargos` es BRUTO — incluye anulados, igual que grossCharges en
// calcularKPIsIngresos — y `totalCargosVigentes` / `montoAnulado` lo separan.
// `montoPendiente` es "pendiente de FACTURAR" (estado 'pendiente'), no el saldo
// que el paciente adeuda.
function totalesDeFilas(rows) {
  const suma = (arr, f) => arr.reduce((s, r) => s + f(r), 0);
  return {
    totalCargos: suma(rows, (r) => r.monto),
    totalCargosVigentes: suma(rows.filter((r) => r.estado !== 'anulado'), (r) => r.monto),
    montoAnulado: suma(rows.filter((r) => r.estado === 'anulado'), (r) => r.monto),
    totalCopago: suma(rows, (r) => r.montoCopago || 0),
    totalBonificacion: suma(rows, (r) => r.montoBonificacion || 0),
    montoPendiente: suma(rows.filter((r) => r.estado === 'pendiente'), (r) => r.monto),
  };
}

const porId = (a, b) => (String(a) < String(b) ? -1 : String(a) > String(b) ? 1 : 0);

// Hoy las filas de Ingresos no traen identificador clínico, así que el episodio
// se DERIVA de forma declarada: mismo paciente + misma unidad + misma fecha =
// una atención (`episodeSource: 'DERIVED_DEFAULT'`). Cuando la fuente real
// traiga el identificador, manda ese: EpisodeOfCare > Encounter. Una
// hospitalización que cruza días y unidades es UN episodio, no varios.
function claveEpisodio(row) {
  if (row.episodeOfCareId) return { clave: `eoc|${row.episodeOfCareId}`, source: 'EPISODE_OF_CARE' };
  if (row.encounterId) return { clave: `enc|${row.encounterId}`, source: 'ENCOUNTER' };
  return { clave: `dflt|${row.unidad}|${row.fecha}`, source: 'DERIVED_DEFAULT' };
}

/**
 * NIVEL 1 — EpisodeFinancialAccount. Recibe las filas de UN paciente (el
 * llamador ya filtró) y devuelve una cuenta por episodio. La salida es función
 * del CONJUNTO de filas, no de su orden: todo va ordenado, así los IDs y los
 * arreglos no cambian si la fuente reordena. Cada fila cae en exactamente un
 * episodio (partición). `clinicalFinancialLink` es solo referencia técnica a
 * lo clínico — ningún dato financiero viaja hacia la ficha.
 */
export function construirEpisodeFinancialAccounts(rowsPaciente, { tenantContext, patientKey, registroOrgNodes } = {}) {
  const tenantId = tenantContext?.tenantId ?? null;
  const grupos = new Map();
  rowsPaciente.forEach((r) => {
    const { clave, source } = claveEpisodio(r);
    if (!grupos.has(clave)) grupos.set(clave, { source, rows: [] });
    grupos.get(clave).rows.push(r);
  });
  const episodios = [...grupos.entries()].map(([clave, g]) => {
    const charges = g.rows
      .map((r) => construirCharge(r, { tenantContext, registroOrgNodes }))
      .sort((a, b) => porId(a.serviceDate, b.serviceDate) || porId(a.sourceRowId, b.sourceRowId));
    const fechas = charges.map((c) => c.serviceDate).sort();
    const unicos = (arr) => [...new Set(arr.filter(Boolean))].sort();
    return {
      episodeFinancialAccountId: idOpaco('efa', tenantId, patientKey, clave),
      episodeSource: g.source,
      clinicalFinancialLink: {
        episodeOfCareId: g.rows.find((r) => r.episodeOfCareId)?.episodeOfCareId ?? null,
        encounterIds: unicos(g.rows.map((r) => r.encounterId)),
        chargeIds: charges.map((c) => c.chargeId),
      },
      organizationalContext: {
        tenantId,
        orgNodeIds: unicos(charges.map((c) => c.organizationalContext.orgNodeId)),
        cargosSinContextoOrganizacional: charges.filter((c) => c.organizationalContext.mappingStatus !== 'RESOLVED').length,
      },
      unidades: unicos(charges.map((c) => c.unidad)),
      periodo: { desde: fechas[0], hasta: fechas[fechas.length - 1] },
      currency: MONEDA_DEFAULT,
      charges,
      ...totalesDeFilas(g.rows),
    };
  });
  return episodios.sort((a, b) => porId(b.periodo.hasta, a.periodo.hasta) || porId(a.episodeFinancialAccountId, b.episodeFinancialAccountId));
}

