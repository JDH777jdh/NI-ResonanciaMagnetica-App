// Transforma el JSX COMPLETO (original y nuevo) a ESM con esbuild y lo deja ejecutable en Node,
// con stubs de 'react' y 'lucide-react'. Así se prueba el archivo real, no una copia a mano.
const esbuild = require('/home/claude/.npm-global/lib/node_modules/tsx/node_modules/esbuild');
const fs = require('fs');
function build(src, out, footerNames) {
  const code = fs.readFileSync(src, 'utf8');
  const t = esbuild.transformSync(code, { loader: 'jsx', format: 'esm', footer: `\nexport { ${footerNames.join(', ')} };\n` });
  fs.writeFileSync(out, t.code);
  return code;
}
build('ContabilidadIngresos.orig.jsx', 'test/ingresos.orig.mjs', ['genMock', 'UNIDADES', 'calcularDesgloseCopago']);
const nuevo = build('ContabilidadIngresos.jsx', 'test/ingresos.new.mjs', ['genMock', 'UNIDADES', 'calcularDesgloseCopago', 'ORGNODES_MOCK', 'totalesDeFilas', 'idOpaco', 'claveEpisodio']);
const names = nuevo.match(/import\s*\{([^}]*)\}\s*from\s*'lucide-react'/)[1].split(',').map((s) => s.trim()).filter(Boolean);
fs.mkdirSync('test/node_modules/lucide-react', { recursive: true });
fs.writeFileSync('test/node_modules/lucide-react/package.json', JSON.stringify({ name: 'lucide-react', type: 'module', main: 'index.js' }));
fs.writeFileSync('test/node_modules/lucide-react/index.js', names.map((n) => `export const ${n} = () => null;`).join('\n') + '\n');
fs.mkdirSync('test/node_modules/react', { recursive: true });
fs.writeFileSync('test/node_modules/react/package.json', JSON.stringify({ name: 'react', type: 'module', main: 'index.js' }));
fs.writeFileSync('test/node_modules/react/index.js', "export default { createElement: () => null };\nexport const useState = (v) => [typeof v === 'function' ? v() : v, () => {}];\nexport const useMemo = (f) => f();\n");
console.log('build OK — íconos stub:', names.length);
