/**
 * NIVEL 2 — TenantPatientFinancialView: todas las EpisodeFinancialAccount de
 * un paciente DENTRO de un mismo tenant. Nunca expone datos de otro tenant:
 * una fila que DECLARA otro tenantId no entra (se cuenta en
 * `filasAjenasDescartadas`, no se muestra). El paciente se identifica por CUP
 * y, mientras la fuente no lo traiga, por RUT (`patientRef.source` lo declara).
 * Devuelve `{ error }` si no hay ningún identificador.
 */
export function resolverTenantPatientFinancialView(rows, patient, tenantContext, opts = {}) {
  const pac = patient || {};
  const patientKey = pac.cup || pac.rut || null;
  if (!patientKey) return { error: 'Se requiere patient.cup o patient.rut para resolver la vista' };
  const tenant = {
    tenantId: tenantContext?.tenantId ?? null,
    legalEntityId: tenantContext?.legalEntityId ?? null,
    branchId: tenantContext?.branchId ?? null,
  };
  const delPaciente = rows.filter((r) => ((pac.cup && r.cup) ? r.cup === pac.cup : (pac.rut != null && r.rut === pac.rut)));
  const esAjena = (r) => r.tenantId != null && tenant.tenantId != null && r.tenantId !== tenant.tenantId;
  const propias = delPaciente.filter((r) => !esAjena(r));
  const episodes = construirEpisodeFinancialAccounts(propias, { tenantContext: tenant, patientKey, registroOrgNodes: opts.registroOrgNodes });
  const fechas = propias.map((r) => r.fecha).sort();
  return {
    viewId: idOpaco('tpv', tenant.tenantId, patientKey),
    tenantContext: tenant,
    patientRef: { cup: pac.cup ?? null, rut: pac.rut ?? null, source: pac.cup ? 'CUP' : 'RUT_FALLBACK' },
    patientName: propias[0]?.paciente || null,
    currency: MONEDA_DEFAULT,
    episodes,
    ...totalesDeFilas(propias),
    prepayments: [], // Fase 6 (Prepagos) todavía no se conecta a esta vista
    unappliedCredit: 0,
    cargosSinContextoOrganizacional: episodes.reduce((s, e) => s + e.organizationalContext.cargosSinContextoOrganizacional, 0),
    filasAjenasDescartadas: delPaciente.length - propias.length,
    watermark: fechas.length ? fechas[fechas.length - 1] : null, // última fecha de prestación incluida
    generatedAt: opts.generatedAt || HOY_ISO_ING,
    visibility: { inProfile: opts.visibility?.inProfile !== false },
    provenance: {
      origin: opts.provenance?.origin || 'AXON_NATIVE', // 'AXON_NATIVE' | 'EXTERNAL_ADAPTER'
      sourceSystem: opts.provenance?.sourceSystem || 'AXON_INGRESOS',
      externalContractRef: opts.provenance?.externalContractRef ?? null,
    },
  };
}

// Coincidencia de paciente entre una vista y el perfil: por CUP si ambos lo
// tienen, si no por RUT. Sin identificador común NO se asume que sea la misma
// persona — resolver eso es trabajo del MPI/PIX, no de esta función.
function mismoPacienteRef(a, b) {
  if (a?.cup && b?.cup) return a.cup === b.cup;
  if (a?.rut && b?.rut) return a.rut === b.rut;
  return false;
}

const CLAVES_TOTALES = ['totalCargos', 'totalCargosVigentes', 'montoAnulado', 'totalCopago', 'totalBonificacion', 'montoPendiente'];
const soloTotales = (obj) => Object.fromEntries(CLAVES_TOTALES.map((k) => [k, obj[k] || 0]));

/**
 * NIVEL 3 — PatientFinancialProfile: proyección de lectura longitudinal y
 * multi-tenant, SOLO con lo autorizado. No es libro mayor ni una cuenta por
 * cobrar única: el total por moneda es informativo y cada tenant conserva su
 * propio desglose (`summary.porTenant`). Reglas, en este orden:
 *  - sin `opts.autorizacion.tenantIdsAutorizados` NO se incluye nada (deniega
 *    por defecto: el patientId por sí solo no autoriza acceso);
 *  - una fuente externa (`provenance.origin === 'EXTERNAL_ADAPTER'`) entra solo
 *    con `externalContractRef`;
 *  - una vista repetida (mismo viewId) cuenta una sola vez (la primera gana);
 *  - monedas distintas nunca se suman entre sí.
 * Las fuentes excluidas se informan SOLO como conteo por motivo — nunca el
 * tenant excluido —. `lastSyncStatus` queda fuera: no existe sincronización
 * real todavía y no se inventa.
 */
export function resolverPatientFinancialProfile(vistas, patient, opts = {}) {
  const pac = patient || {};
  const patientKey = pac.cup || pac.rut || null;
  if (!patientKey) return { error: 'Se requiere patient.cup o patient.rut para resolver el perfil' };
  const autorizados = new Set(opts.autorizacion?.tenantIdsAutorizados || []);
  const motivos = {};
  const excluir = (m) => { motivos[m] = (motivos[m] || 0) + 1; };
  const incluidas = [];
  const idsIncluidos = new Set();

  (vistas || []).forEach((v) => {
    const tid = v?.tenantContext?.tenantId ?? null;
    if (!tid) return excluir('SIN_TENANT');
    if (!mismoPacienteRef(v.patientRef, pac)) return excluir('PACIENTE_NO_COINCIDE');
    if (!autorizados.has(tid)) return excluir('SIN_AUTORIZACION');
    if (v.visibility?.inProfile === false) return excluir('NO_VISIBLE_EN_PERFIL');
    if (v.provenance?.origin === 'EXTERNAL_ADAPTER' && !v.provenance?.externalContractRef) return excluir('EXTERNO_SIN_CONTRATO');
    if (idsIncluidos.has(v.viewId)) return excluir('DUPLICADA');
    idsIncluidos.add(v.viewId);
    incluidas.push(v);
  });
  incluidas.sort((a, b) => porId(a.tenantContext.tenantId, b.tenantContext.tenantId) || porId(a.viewId, b.viewId));

  const porMoneda = {};
  incluidas.forEach((v) => {
    const cur = v.currency || MONEDA_DEFAULT;
    if (!porMoneda[cur]) porMoneda[cur] = { tenants: 0, episodios: 0, ...soloTotales({}) };
    porMoneda[cur].tenants += 1;
    porMoneda[cur].episodios += v.episodes.length;
    CLAVES_TOTALES.forEach((k) => { porMoneda[cur][k] += v[k] || 0; });
  });

  return {
    patientFinancialProfileId: idOpaco('pfp', patientKey), // global: no depende del tenant
    patientRef: { cup: pac.cup ?? null, rut: pac.rut ?? null, source: pac.cup ? 'CUP' : 'RUT_FALLBACK' },
    generatedAt: opts.generatedAt || HOY_ISO_ING,
    projectionVersion: 1,
    esProyeccionDeLectura: true,
    sourceWatermarks: incluidas.map((v) => ({ tenantId: v.tenantContext.tenantId, viewId: v.viewId, watermark: v.watermark ?? null })),
    summary: {
      tenants: incluidas.length,
      episodios: incluidas.reduce((s, v) => s + v.episodes.length, 0),
      porMoneda,
      porTenant: incluidas.map((v) => ({
        tenantId: v.tenantContext.tenantId, viewId: v.viewId, currency: v.currency || MONEDA_DEFAULT,
        episodios: v.episodes.length, ...soloTotales(v),
      })),
    },
    episodes: incluidas.flatMap((v) => v.episodes.map((e) => ({
      episodeFinancialAccountId: e.episodeFinancialAccountId, tenantId: v.tenantContext.tenantId, currency: e.currency,
      episodeSource: e.episodeSource, periodo: e.periodo, unidades: e.unidades,
      orgNodeIds: e.organizationalContext.orgNodeIds, ...soloTotales(e),
    }))),
    provenance: incluidas.map((v) => ({
      tenantId: v.tenantContext.tenantId, origin: v.provenance?.origin ?? null,
      sourceSystem: v.provenance?.sourceSystem ?? null, externalContractRef: v.provenance?.externalContractRef ?? null,
    })),
    visibility: {
      scope: 'PATIENT_AUTHORIZED',
      fuentesIncluidas: incluidas.length,
      fuentesExcluidas: Object.values(motivos).reduce((s, n) => s + n, 0),
      motivosExclusion: motivos,
    },
  };
}

/**
 * @deprecated 2026-10-08 — reemplazada por el modelo de 3 niveles
 * (resolverTenantPatientFinancialView / resolverPatientFinancialProfile).
 * Se conserva con la misma firma y la misma forma de salida (resumen PLANO por
 * RUT, sin capa de episodio) para no romper a ningún consumidor; lo único
 * nuevo es que cada Charge de `charges` ahora trae `organizationalContext`.
 * Los totales salen del mismo helper que usan los 3 niveles.
 */
export function resolverPatientFinancialAccount(rows, rut) {
  const propias = rows.filter((r) => r.rut === rut);
  const t = totalesDeFilas(propias);
  return {
    patientRut: rut,
    patientName: propias[0]?.paciente || null,
    charges: propias.map((r) => construirCharge(r)),
    totalCargos: t.totalCargos,
    totalCopago: t.totalCopago,
    totalBonificacion: t.totalBonificacion,
    montoPendiente: t.montoPendiente,
    prepayments: [],
    unappliedCredit: 0,
  };
}

