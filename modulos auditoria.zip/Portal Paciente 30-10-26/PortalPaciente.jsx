import { useState, useRef, useEffect } from "react";
import {
  Eye, EyeOff, AlertCircle, BadgeCheck, LogOut, Lock, Search, ChevronLeft, ChevronRight, ChevronDown,
  Building2, Stethoscope, Calendar, HeartPulse, Truck, BookOpen, Syringe, Users2, Utensils, Bed, Pill,
  FileText, DollarSign, CreditCard, Gift, Star, MessageSquare, Phone, Shield, CheckCircle,
  Video, MapPin, User, CheckSquare, Clock, Download, Pencil, Plus, Trash2, ArrowUpDown,
  Ship, Plane, Accessibility, Armchair,
  Mail, MessageCircle,
} from "lucide-react";

const C = {
  navy: "#1B3A66", slate700: "#334155", slate400: "#94A3B8", slate200: "#E2E8F0", slate100: "#F1F5F9",
  bg: "#F8FAFC", cyan: "#06B6D4", cyanText: "#0E7490", copper: "#A8571E", copperLight: "#C97B3D",
  ink: "#1E293B", inkSoft: "#64748B", danger: "#DC2626", dangerBg: "#FEF2F2",
  success: "#15803D", successBg: "#F0FDF4", warn: "#B45309", warnBg: "#FEF3C7",
};

// Estilos compartidos — mismo look en todo el archivo, escrito una vez.
const F = { d: "'Space Grotesk', sans-serif", b: "'Public Sans', sans-serif", m: "'IBM Plex Mono', monospace" };
const S = {
  page: { minHeight: "100vh", background: C.bg, fontFamily: F.b, padding: "32px 16px", display: "flex", justifyContent: "center" },
  pageCol: { minHeight: "100vh", background: C.bg, fontFamily: F.b, padding: "32px 16px", display: "flex", flexDirection: "column", alignItems: "center" },
  card: { background: "#fff", border: `1px solid ${C.slate200}`, borderRadius: 14, padding: 26 },
  row: { background: "#fff", border: `1px solid ${C.slate200}`, borderRadius: 12, padding: "16px 18px", display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 12, marginBottom: 10 },
  h1: { fontFamily: F.d, fontWeight: 700, color: C.navy, margin: "0 0 6px" },
  muted: { fontSize: 12.5, color: C.inkSoft },
  primaryBtn: { border: "none", background: C.navy, color: "#fff", fontFamily: F.b, fontWeight: 600, cursor: "pointer", borderRadius: 9 },
  tabWrap: { display: "flex", gap: 4, background: C.slate100, borderRadius: 9, padding: 4 },
  input: { width: "100%", height: 46, borderRadius: 9, border: `1px solid ${C.slate200}`, padding: "0 14px", fontSize: 15, fontFamily: F.b, background: C.slate100, color: C.ink, outline: "none", boxSizing: "border-box" },
};

/* ══════ DATOS — ACCESO / DASHBOARD ══════ */

const CARD_VARIANTS = {
  PACIENTE_PARTICULAR: { bg: "linear-gradient(135deg, #C97B3D, #A8571E 55%, #7A3E14)", text: "#F6F0E8", textSoft: "rgba(246,240,232,0.78)", cupColor: "#F6F0E8", pattern: "#F6F0E8", shadow: "rgba(122,62,20,0.32)" },
  PACIENTE_PREMIUM: { bg: "linear-gradient(135deg, #2E2E33, #17171A 60%, #000000)", text: "#F1F1F3", textSoft: "rgba(241,241,243,0.62)", cupColor: "#C97B3D", pattern: "#F1F1F3", shadow: "rgba(0,0,0,0.5)" },
  PACIENTE_CONVENIO: { bg: "linear-gradient(135deg, #B0B8C1, #838B99 55%, #5B6472)", text: "#F0F3F6", textSoft: "rgba(240,243,246,0.75)", cupColor: "#A8571E", pattern: "#334155", shadow: "rgba(60,66,78,0.30)" },
};

const CONVENIOS_DEMO = [
  { id: "club-condores", nombre: "Club Deportivo Los Cóndores", tipo: "Club deportivo", cuc: "CUC-CL-13-2026-00089-D4" },
  { id: "conectasalud", nombre: "Empresa ConectaSalud SpA", tipo: "Convenio corporativo", cuc: "CUC-CL-13-2026-00104-E1" },
];

const CUENTAS_INDIVIDUAL = [
  { rut: "14.582.917-8", password: "demo123", nombres: "Javiera Antonia", apellidoPaterno: "Rojas", apellidoMaterno: "Muñoz", cup: "CUP-CL-13-2026-00003412-A7", userTypeId: "PACIENTE_PARTICULAR", tierLabel: "Usuario Abierto",
    fechaNacimiento: "1994-03-18", email: "javiera.rojas@correo.cl", telefono: "+56 9 8123 4567", region: "13", prevision: "Fonasa",
    contactosEmergencia: [{ id: "ce1", nombre: "Marcela Muñoz Soto", parentesco: "Madre", telefono: "+56 9 7345 1290" }],
    antecedentesClinicos: { alergias: { tiene: true, detalle: "Alergia a la penicilina" }, antecedentesQuirurgicos: { tiene: false, detalle: "" }, dispositivosMedicos: { tiene: false, detalle: "" }, condicionesCronicas: ["Hipotiroidismo"] },
    direccion: "Av. Grecia 1234, Ñuñoa", perfilMovilidad: { medio: "Necesito silla de ruedas", condiciones: ["Movilidad reducida", "Uso de silla de ruedas"], detalle: "" },
    centrosSaludFrecuentes: [{ id: "cs1", nombre: "CESFAM Ñuñoa", tipo: "Centro médico", direccion: "Av. Irarrázaval 3125", comuna: "Ñuñoa" }] },
  { rut: "11.234.567-1", password: "demo123", nombres: "Matías Ignacio", apellidoPaterno: "Fuentes", apellidoMaterno: "Vergara", cup: "CUP-CL-13-2026-00001187-D2", userTypeId: "PACIENTE_PREMIUM", tierLabel: "Usuario VIP / Premium",
    fechaNacimiento: "1988-11-02", email: "matias.fuentes@correo.cl", telefono: "+56 9 5567 8890", region: "13", prevision: "Consalud",
    contactosEmergencia: [{ id: "ce2", nombre: "Valentina Fuentes Vergara", parentesco: "Hermano/a", telefono: "+56 9 6112 4478" }],
    antecedentesClinicos: { alergias: { tiene: false, detalle: "" }, antecedentesQuirurgicos: { tiene: true, detalle: "Apendicectomía (2015)" }, dispositivosMedicos: { tiene: false, detalle: "" }, condicionesCronicas: [] },
    direccion: "", perfilMovilidad: { medio: null, condiciones: [], detalle: "" }, centrosSaludFrecuentes: [] },
];
const CUENTAS_CONVENIO = [
  { rut: "16.789.234-5", password: "demo123", nombres: "Camila Paz", apellidoPaterno: "Herrera", apellidoMaterno: "Contreras", cup: "CUP-CL-13-2026-00007765-K1", userTypeId: "PACIENTE_CONVENIO", tierLabel: "Beneficiaria de Convenio", convenioId: "club-condores",
    fechaNacimiento: "1996-07-25", email: "camila.herrera@correo.cl", telefono: "+56 9 4456 7821", region: "13", prevision: "Fonasa",
    contactosEmergencia: [],
    antecedentesClinicos: { alergias: { tiene: false, detalle: "" }, antecedentesQuirurgicos: { tiene: false, detalle: "" }, dispositivosMedicos: { tiene: false, detalle: "" }, condicionesCronicas: [] },
    direccion: "Los Militares 5620, Las Condes", perfilMovilidad: { medio: null, condiciones: [], detalle: "" }, centrosSaludFrecuentes: [] },
  { rut: "17.845.321-1", password: "demo123", nombres: "Tomás Andrés", apellidoPaterno: "Bravo", apellidoMaterno: "Sepúlveda", cup: "CUP-CL-13-2026-00009284-B6", userTypeId: "PACIENTE_CONVENIO", tierLabel: "Beneficiario de Convenio", convenioId: "conectasalud",
    fechaNacimiento: "1991-01-14", email: "tomas.bravo@correo.cl", telefono: "+56 9 3321 9087", region: "13", prevision: "Banmédica",
    contactosEmergencia: [{ id: "ce3", nombre: "Loreto Sepúlveda Rojas", parentesco: "Cónyuge / Pareja", telefono: "+56 9 2298 4410" }],
    antecedentesClinicos: { alergias: { tiene: false, detalle: "" }, antecedentesQuirurgicos: { tiene: false, detalle: "" }, dispositivosMedicos: { tiene: false, detalle: "" }, condicionesCronicas: [] },
    direccion: "Manuel Montt 890, Providencia", perfilMovilidad: { medio: null, condiciones: [], detalle: "" }, centrosSaludFrecuentes: [] },
];
const ANTECEDENTES_VACIOS = { alergias: { tiene: false, detalle: "" }, antecedentesQuirurgicos: { tiene: false, detalle: "" }, dispositivosMedicos: { tiene: false, detalle: "" }, condicionesCronicas: [] };
const CONDICIONES_CRONICAS_OPCIONES = ["Diabetes", "Hipertensión", "Asma", "Hipotiroidismo", "Enfermedad renal", "Epilepsia"];
const PERFIL_MOVILIDAD_VACIO = { medio: null, condiciones: [], detalle: "" };
const OPCIONES_MEDIO_TRASLADO = ["Puedo caminar sin ayuda", "Puedo caminar con ayuda", "Necesito silla de ruedas", "Debo permanecer acostado (camilla)", "Necesito asistencia para subir o bajar"];
const CONDICIONES_TRASLADO_OPCIONES = ["Movilidad reducida", "Uso de silla de ruedas", "Necesidad de camilla", "Necesidad de asistencia para transferencia", "Embarazo avanzado", "Requiere espacio adicional", "Requiere condiciones especiales de seguridad"];
const OPCIONES_LUGAR_TRASLADO = ["Mi domicilio", "Centro de salud", "Otra dirección"];
/* ══════ DATOS — MOVILIZACIÓN: tarifas, vehículos, medios y reglas simples ══════ */
// MOCK — tarifas por definir con operaciones. El valor real debe venir del catálogo compartido y Revenue Cycle (Account Core); el portal solo lo muestra.
const TARIFAS_TRASLADO = { ambulancia: 35000, dialisis: 15000 /* por tramo */ };
const VEHICULOS_TERRESTRES = [
  { id: "silla", titulo: "Vehículo adaptado para silla de ruedas", detalle: "Para pacientes que viajan en su propia silla.", icon: Accessibility, valor: 30000 },
  { id: "camilla", titulo: "Transporte en camilla", detalle: "Para pacientes que deben permanecer acostados.", icon: Bed, valor: 45000 },
  { id: "sentado", titulo: "Transporte sanitario sentado", detalle: "Para pacientes que pueden viajar sentados.", icon: Armchair, valor: 20000 },
];
const MEDIOS_AVANZADA = [
  { id: "terrestre", sobretitulo: "Terrestre", titulo: "Transporte Sanitario No Emergente", detalle: "Vehículos adaptados para personas con movilidad reducida y requerimientos especiales.", etiqueta: "Ver vehículos →", icon: Truck },
  { id: "maritimo", sobretitulo: "Marítimo", titulo: "Transporte Sanitario Marítimo", detalle: "Para traslados que requieren conexión por vía marítima.", etiqueta: "Ver opciones →", icon: Ship },
  { id: "aereo", sobretitulo: "Aéreo", titulo: "Transporte Sanitario Aéreo", detalle: "Traslados mediante aeronaves sanitarias según disponibilidad y requerimientos.", etiqueta: "Ver opciones →", icon: Plane },
];
const OPCIONES_AYUDA_VEHICULO = [...OPCIONES_MEDIO_TRASLADO, "No estoy seguro"];
// Regla simple (sin IA) para "Ayúdame a elegir": solo sugiere, el paciente decide. A validar con el equipo clínico.
const VEHICULOS_SUGERIDOS = {
  "Puedo caminar sin ayuda": ["sentado"],
  "Puedo caminar con ayuda": ["sentado"],
  "Necesito silla de ruedas": ["silla"],
  "Debo permanecer acostado (camilla)": ["camilla"],
  "Necesito asistencia para subir o bajar": ["silla", "sentado"],
  "No estoy seguro": [],
};
const REQUERIMIENTOS_TRASLADO = ["Oxígeno", "Aislamiento", "Acompañante", "Otra necesidad"];
// MOCK — bloques de recogida para sesiones de diálisis; el horario real lo da la agenda del centro. El regreso se calcula desde la hora de ida.
const BLOQUES_HORA_DIALISIS = ["06:30", "07:00", "07:30", "08:00", "10:30", "11:00", "12:00", "13:00", "13:30", "14:00", "17:00", "18:00"];
const MODALIDADES_DIALISIS = [["ida_regreso", "Ida y regreso"], ["ida", "Solo ida"], ["regreso", "Solo regreso"]];
const sumarMinutos = (hora, min) => { const [h, m] = hora.split(":").map(Number); const t = h * 60 + m + min; return `${String(Math.floor(t / 60) % 24).padStart(2, "0")}:${String(t % 60).padStart(2, "0")}`; };
const opcionesRegreso = (horaIda) => [180, 210, 240, 270, 300].map(min => sumarMinutos(horaIda, min));

// MOCK — traslados de demostración relativos a hoy: uno próximo y uno ya realizado (para probar "Mis Traslados" y su historial).
// Es función y no constante porque usa los helpers de fecha definidos más abajo; se evalúa al montar la vista.
function trasladosDemo() {
  return [
    { id: "tr1", fechaIso: isoFecha(diasDesdeHoy(6)), hora: "10:30", origen: "Domicilio · Av. Grecia 1234, Ñuñoa", destino: "Centro Médico Salud · Av. Providencia 2345, Providencia", servicio: "Ambulancia Programada", estado: "confirmado", valor: 35000, solicitadoIso: isoFecha(diasDesdeHoy(-1)) },
    { id: "tr0", fechaIso: isoFecha(diasDesdeHoy(-24)), hora: "09:00", origen: "Domicilio · Av. Grecia 1234, Ñuñoa", destino: "CESFAM Ñuñoa · Av. Irarrázaval 3125, Ñuñoa", servicio: "Ambulancia Programada", estado: "realizado", valor: 35000, solicitadoIso: isoFecha(diasDesdeHoy(-26)) },
  ];
}

const GRUPOS_DASHBOARD = [
  { id: "agenda", label: "Agenda y Citas", items: [
    { id: "pac_medica", label: "Atención Médica", icon: Stethoscope, fhir: "Appointment", puerta: "Atención Médica (Agendas)" },
    { id: "pac_examenes_apoyo", label: "Exámenes y Apoyo Clínico", icon: Calendar, fhir: "Appointment", puerta: "Especialidades Clínicas, Diagnósticas y Terapéuticas (Agendas)" },
    { id: "pac_activa_llegada", label: "Activa tu Llegada", icon: CheckSquare, fhir: "Appointment", puerta: "Agenda", nuevo: true },
    { id: "pac_traslado", label: "Movilización y Traslado", icon: Truck, fhir: "Transport", puerta: "Movilización y traslado (agenda)" },
    { id: "pac_urgencia", label: "Atención de Urgencia", icon: AlertCircle, fhir: "Encounter", puerta: "Sin definir en Excel — agregada a pedido", nuevo: true },
    { id: "pac_calendario", label: "Calendario", icon: Clock, fhir: "Task", puerta: "Sin definir en Excel — agregada a pedido", nuevo: true },
  ]},
  { id: "salud", label: "Mi Salud", items: [
    { id: "pac_ficha", label: "Ficha Clínica Digital", icon: BookOpen, fhir: "Composition", puerta: "Electronic Medical Record (EMR)", nuevo: true },
    { id: "pac_hospitalizacion", label: "Hospitalización", icon: Bed, fhir: "Encounter", puerta: "Sin definir en Excel — agregada a pedido", nuevo: true, excluirTiers: ["PACIENTE_CONVENIO"] },
    { id: "pac_cirugia", label: "Programa Cirugía", icon: Syringe, fhir: "Procedure", puerta: "Marketing", nuevo: true },
    { id: "pac_social", label: "Programa Social", icon: Users2, fhir: "CarePlan", puerta: "Marketing", nuevo: true },
    { id: "pac_nutricion", label: "Alimentación y Nutrición", icon: Utensils, fhir: "NutritionOrder", puerta: "Alimentación y nutrición", nuevo: true },
    { id: "pac_farmacia", label: "Farmacia", icon: Pill, fhir: "MedicationDispense", puerta: "Sin definir en Excel — agregada a pedido", nuevo: true },
  ]},
  { id: "documentos", label: "Documentos y Pagos", items: [
    { id: "pac_consents", label: "Consentimientos Informados", icon: FileText, fhir: "Consent", puerta: "Motor de documentos y certificados" },
    { id: "pac_certificados", label: "Certificados", icon: FileText, fhir: "DocumentReference", puerta: "Motor de documentos y certificados", nuevo: true },
    { id: "pac_valores", label: "Valores y Cotizaciones", icon: DollarSign, fhir: "ChargeItemDefinition", puerta: "Marketing" },
    { id: "pac_bonos", label: "Bonos y Pagos", icon: CreditCard, fhir: "Invoice", puerta: "Pasarela de pago" },
  ]},
  { id: "beneficios", label: "Beneficios y Comunicación", items: [
    { id: "pac_perfil", label: "Mi Perfil Paciente", icon: User, fhir: "Patient", puerta: "DB datos de paciente (CUP)", nuevo: true },
    { id: "pac_contactos_emergencia", label: "Contactos de Emergencia", icon: Phone, fhir: "Patient", puerta: "DB datos de paciente (CUP)", nuevo: true },
    { id: "pac_puntos", label: "Mis Puntos y Beneficios", icon: Gift, fhir: "Account", puerta: "Marketing", nuevo: true },
    { id: "pac_encuestas", label: "Encuestas de Satisfacción", icon: Star, fhir: "QuestionnaireResponse", puerta: "Calidad y acreditación" },
    { id: "pac_oirs", label: "OIRS", icon: MessageSquare, fhir: "Communication", puerta: "Calidad y acreditación" },
    { id: "pac_contacto", label: "Contacto y Ayuda", icon: Phone, fhir: "Communication", puerta: "Sección administrativa", nuevo: true },
  ]},
];

const REGIONES_CL = [
  { codigo: "15", nombre: "Arica y Parinacota" }, { codigo: "01", nombre: "Tarapacá" }, { codigo: "02", nombre: "Antofagasta" },
  { codigo: "03", nombre: "Atacama" }, { codigo: "04", nombre: "Coquimbo" }, { codigo: "05", nombre: "Valparaíso" },
  { codigo: "13", nombre: "Metropolitana de Santiago" }, { codigo: "06", nombre: "O'Higgins" }, { codigo: "07", nombre: "Maule" },
  { codigo: "16", nombre: "Ñuble" }, { codigo: "08", nombre: "Biobío" }, { codigo: "09", nombre: "La Araucanía" },
  { codigo: "14", nombre: "Los Ríos" }, { codigo: "10", nombre: "Los Lagos" }, { codigo: "11", nombre: "Aysén" }, { codigo: "12", nombre: "Magallanes" },
];

const PAISES_TEL = [
  { codigo: "CL", nombre: "Chile", indicativo: "+56", bandera: "🇨🇱" }, { codigo: "AR", nombre: "Argentina", indicativo: "+54", bandera: "🇦🇷" },
  { codigo: "PE", nombre: "Perú", indicativo: "+51", bandera: "🇵🇪" }, { codigo: "BO", nombre: "Bolivia", indicativo: "+591", bandera: "🇧🇴" },
  { codigo: "CO", nombre: "Colombia", indicativo: "+57", bandera: "🇨🇴" }, { codigo: "EC", nombre: "Ecuador", indicativo: "+593", bandera: "🇪🇨" },
  { codigo: "PY", nombre: "Paraguay", indicativo: "+595", bandera: "🇵🇾" }, { codigo: "UY", nombre: "Uruguay", indicativo: "+598", bandera: "🇺🇾" },
  { codigo: "VE", nombre: "Venezuela", indicativo: "+58", bandera: "🇻🇪" }, { codigo: "BR", nombre: "Brasil", indicativo: "+55", bandera: "🇧🇷" },
  { codigo: "MX", nombre: "México", indicativo: "+52", bandera: "🇲🇽" }, { codigo: "PA", nombre: "Panamá", indicativo: "+507", bandera: "🇵🇦" },
  { codigo: "CR", nombre: "Costa Rica", indicativo: "+506", bandera: "🇨🇷" }, { codigo: "ES", nombre: "España", indicativo: "+34", bandera: "🇪🇸" },
  { codigo: "US", nombre: "Estados Unidos", indicativo: "+1", bandera: "🇺🇸" },
];

const ISAPRES_CL = ["Banmédica", "Consalud", "Cruz Blanca", "Colmena Golden Cross", "Vida Tres", "Nueva Masvida"];

function limpiarRUT(v) { return v.replace(/[^0-9kK]/g, "").toUpperCase(); }
function formatearRUT(v) { const l = limpiarRUT(v); if (l.length <= 1) return l; return `${l.slice(0, -1).replace(/\B(?=(\d{3})+(?!\d))/g, ".")}-${l.slice(-1)}`; }
function validarRUT(v) {
  const l = limpiarRUT(v); if (l.length < 2) return false;
  const cuerpo = l.slice(0, -1), dv = l.slice(-1);
  if (!/^\d+$/.test(cuerpo)) return false;
  let suma = 0, mult = 2;
  for (let i = cuerpo.length - 1; i >= 0; i--) { suma += parseInt(cuerpo[i], 10) * mult; mult = mult === 7 ? 2 : mult + 1; }
  const resto = 11 - (suma % 11);
  return dv === (resto === 11 ? "0" : resto === 10 ? "K" : String(resto));
}
function validarEmail(v) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v); }
function checksumMock(cad) { let s = 0; for (let i = 0; i < cad.length; i++) s = (s + cad.charCodeAt(i) * (i + 1)) % 256; return s.toString(16).toUpperCase().padStart(2, "0"); }
function generarCUP(region) {
  const anio = new Date().getFullYear();
  const seq = String(Math.floor(Math.random() * 99999999)).padStart(8, "0");
  return `CUP-CL-${region}-${anio}-${seq}-${checksumMock(`CL${region}${anio}${seq}`)}`;
}

/* ══════ DATOS — AGENDA MÉDICA (41 especialidades reales, 10 médicos en 8 de ellas) ══════ */

// Atención Médica: las especialidades que NO están en el listado de
// Exámenes y Apoyo Clínico del Excel de distribución.
const ESPECIALIDADES_MEDICAS = [
  { id: "t_med_ambulatorio", label: "Medicina General" }, { id: "t_med_alergologo", label: "Alergología" },
  { id: "t_med_diabetologo", label: "Diabetología" }, { id: "t_med_endocrinologo", label: "Endocrinología" },
  { id: "t_med_genetica_clinica", label: "Genética Clínica" }, { id: "t_med_geriatria", label: "Geriatría" },
  { id: "t_med_hematologo", label: "Hematología" }, { id: "t_med_infectologo", label: "Infectología" },
  { id: "t_med_inmunologo", label: "Inmunología" }, { id: "t_med_nefrologo", label: "Nefrología" },
  { id: "t_med_nutriologo", label: "Nutriología" }, { id: "t_med_pediatra", label: "Pediatría" },
  { id: "t_med_proctologo", label: "Proctología" }, { id: "t_med_psiquiatra", label: "Psiquiatría" },
  { id: "t_med_reumatologo", label: "Reumatología" }, { id: "t_med_sexologo", label: "Sexología Clínica" },
  { id: "t_med_traumatologo", label: "Traumatología" }, { id: "t_med_esp_dolor", label: "Especialista del Dolor" },
  { id: "t_med_cir_cabeza_cuello", label: "Cirugía Cabeza y Cuello" }, { id: "t_med_cir_maxilofacial", label: "Cirugía Oral y Maxilofacial" },
  { id: "t_med_cir_cardiovascular", label: "Cirugía Cardiovascular" }, { id: "t_med_cir_cardiotoracico", label: "Cirugía Cardiotorácica" },
  { id: "t_med_cir_general_digestivo", label: "Cirugía General y Digestiva" }, { id: "t_med_cir_ortopedista", label: "Cirugía Ortopédica y Traumatología" },
  { id: "t_med_cir_pediatra", label: "Cirugía Pediátrica" }, { id: "t_med_cir_plastico", label: "Cirugía Plástica" },
  { id: "t_med_cir_toracico", label: "Cirugía Torácica" }, { id: "t_med_cir_urologo", label: "Cirugía Urológica" },
  { id: "t_med_cir_vascular", label: "Cirugía Vascular" }, { id: "t_med_neurocirujano", label: "Neurocirugía" },
];

// Exámenes y Apoyo Clínico: los 19 ítems exactos del Excel de distribución
// — mezcla especialidades médicas con servicios de apoyo (imagenología,
// laboratorio, odontología, fonoaudiología) que no son roles "medicos" en
// roles.config.js, por eso varios usan id propio (ex_*) en vez de t_med_*.
const ESPECIALIDADES_EXAMENES = [
  { id: "ex_imagenologia", label: "Imagenología" }, { id: "ex_laboratorio", label: "Laboratorio" },
  { id: "t_med_oftalmologo", label: "Oftalmología" }, { id: "t_med_otorrino", label: "Otorrinolaringología" },
  { id: "ex_anatomia_patologica", label: "Anatomía Patológica y Morfofisiopatología" }, { id: "t_med_cardiologo", label: "Cardiología" },
  { id: "t_med_neumologo", label: "Bronco Pulmonar" }, { id: "t_med_gastroenterologo", label: "Gastroenterología" },
  { id: "t_med_ginecologo", label: "Ginecología" }, { id: "t_med_dermatologo", label: "Dermatología" },
  { id: "ex_medicina_nuclear", label: "Medicina Nuclear" }, { id: "t_med_neurologo", label: "Neurología" },
  { id: "t_med_oncologo", label: "Oncología" }, { id: "ex_odontologia", label: "Odontología" },
  { id: "t_med_urologo", label: "Urología" }, { id: "ex_fonoaudiologia", label: "Fonoaudiología" },
  { id: "ex_obstetricia", label: "Obstetricia, Matronería y Puericultura" }, { id: "ex_psicologia", label: "Psicología" },
  { id: "ex_terapia_rehab", label: "Terapia y Rehabilitación" },
];
const TODAS_ESPECIALIDADES = [...ESPECIALIDADES_MEDICAS, ...ESPECIALIDADES_EXAMENES];

const MEDICOS = [
  { id: "m1", especialidadId: "t_med_ambulatorio", nombres: "Roberto", apellidoPaterno: "Sánchez", apellidoMaterno: "Lira" },
  { id: "m2", especialidadId: "t_med_ambulatorio", nombres: "Fernanda", apellidoPaterno: "Castillo", apellidoMaterno: "Rojas" },
  { id: "m3", especialidadId: "t_med_ambulatorio", nombres: "Ignacio", apellidoPaterno: "Peña", apellidoMaterno: "Morales" },
  { id: "m4", especialidadId: "t_med_endocrinologo", nombres: "Matías", apellidoPaterno: "Contreras", apellidoMaterno: "Soto" },
  { id: "m5", especialidadId: "t_med_pediatra", nombres: "Valentina", apellidoPaterno: "Muñoz", apellidoMaterno: "Díaz" },
  { id: "m6", especialidadId: "t_med_traumatologo", nombres: "Cristóbal", apellidoPaterno: "Vargas", apellidoMaterno: "Ibáñez" },
  { id: "m7", especialidadId: "t_med_dermatologo", nombres: "Antonia", apellidoPaterno: "Reyes", apellidoMaterno: "Fuentes" },
  { id: "m8", especialidadId: "t_med_psiquiatra", nombres: "Joaquín", apellidoPaterno: "Torres", apellidoMaterno: "Bravo" },
  { id: "m9", especialidadId: "t_med_ginecologo", nombres: "Constanza", apellidoPaterno: "Silva", apellidoMaterno: "Ortega" },
  { id: "m10", especialidadId: "t_med_cir_general_digestivo", nombres: "Felipe", apellidoPaterno: "Guzmán", apellidoMaterno: "Castro" },
];
const medicosPorEspecialidad = (id) => MEDICOS.filter(m => m.especialidadId === id);
const BLOQUES_HORA = ["09:00", "09:30", "10:30", "11:00", "15:00", "15:30", "16:30", "17:00"];
const DIAS_CORTOS = ["Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"];
const MESES_ES = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"];
const isoFecha = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
const etiquetaFecha = (d) => `${DIAS_CORTOS[d.getDay()]} ${String(d.getDate()).padStart(2, "0")} ${d.toLocaleString("es-CL", { month: "short" })}`;
const DIAS_LARGOS = ["Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado"];
const fechaLarga = (iso) => { const d = new Date(`${iso}T00:00:00`); return `${DIAS_LARGOS[d.getDay()]} ${String(d.getDate()).padStart(2, "0")} de ${MESES_ES[d.getMonth()].toLowerCase()}`; };
// MOCK — fechas de demostración relativas a hoy: ningún dato "próximo" debe quedar vencido al mostrar el portal.
// Los datos históricos (consultas, recetas, signos vitales) pueden tener fecha fija: el pasado sigue siendo pasado.
const diasDesdeHoy = (n) => { const h = new Date(); return new Date(h.getFullYear(), h.getMonth(), h.getDate() + n); };
const fechaCorta = (d) => `${String(d.getDate()).padStart(2, "0")} ${MESES_ES[d.getMonth()].slice(0, 3).toLowerCase()} ${d.getFullYear()}`;
const proximoDiaHabil = () => { let n = 1; while ([0, 6].includes(diasDesdeHoy(n).getDay())) n++; return diasDesdeHoy(n); };
// MOCK — reemplazar por la disponibilidad real del motor de Agenda de MAIN: debe devolver un arreglo de fechas ISO
// "AAAA-MM-DD" con cupo para ese médico / ambulancia / examen. Hoy es determinístico según la "semilla" (id del
// recurso) para simular recursos con cupo toda la semana, solo lunes a viernes, días fijos, o muy pocos días.
function fechasDisponiblesMock(semilla, { perfil, dias = 60 } = {}) {
  const h = [...String(semilla)].reduce((a, c) => (a * 31 + c.charCodeAt(0)) >>> 0, 7);
  const tipo = perfil ?? h % 4;
  const diasFijos = [[2, 4], [1, 3, 5], [1, 4], [2, 3, 5]][(h >>> 3) % 4];
  const hoy = new Date();
  const out = [];
  for (let i = 1; i <= dias; i++) {
    const d = new Date(hoy.getFullYear(), hoy.getMonth(), hoy.getDate() + i);
    const dow = d.getDay();
    const habil = dow >= 1 && dow <= 5;
    const ok = tipo === 0 ? true : tipo === 1 ? habil : tipo === 2 ? diasFijos.includes(dow) : habil && i > 2 && (i + h) % 5 === 0;
    if (ok) out.push(isoFecha(d));
  }
  return out;
}
function horarioOcupado(medicoId, fechaIso, hora) { return (medicoId + fechaIso + hora).split("").reduce((a, c) => a + c.charCodeAt(0), 0) % 5 === 0; }
// MOCK — la cita demo cae siempre en el próximo día hábil (así "Activa tu Llegada" y "Mis Citas" nunca muestran una cita vencida).
const CITAS_MOCK = [{ id: "cita1", especialidadId: "t_med_endocrinologo", medicoId: "m4", fechaLabel: etiquetaFecha(proximoDiaHabil()), hora: "10:30", modalidad: "presencial", estado: "confirmada" }];

/* ══════ DATOS — FARMACIA ══════ */

const RECETAS_MOCK = [
  { id: "r1", medicamento: "Metformina 850mg", indicacion: "1 comprimido cada 12 horas", medico: "Dr. Matías Contreras Soto", especialidad: "Endocrinología", fecha: "28 jul 2026", vigente: true },
  { id: "r2", medicamento: "Losartán 50mg", indicacion: "1 comprimido al día, en la mañana", medico: "Dr. Matías Contreras Soto", especialidad: "Endocrinología", fecha: "28 jul 2026", vigente: true },
  { id: "r3", medicamento: "Clobetasol crema 0,05%", indicacion: "Aplicar 2 veces al día por 10 días", medico: "Dra. Antonia Reyes Fuentes", especialidad: "Dermatología", fecha: "15 jul 2026", vigente: false },
];
const FARMACIAS_MOCK = [
  { id: "f1", nombre: "Cruz Verde", direccion: "Av. Providencia 1234, Providencia" },
  { id: "f2", nombre: "Salcobrand", direccion: "Av. Apoquindo 4501, Las Condes" },
  { id: "f3", nombre: "Farmacias Ahumada", direccion: "Av. Vitacura 3900, Vitacura" },
];
const PEDIDOS_INICIALES = [{ id: "p0", medicamento: "Metformina 850mg", modalidad: "delivery", estado: "en_camino", fecha: fechaCorta(diasDesdeHoy(0)), direccion: "Los Aromos 245, depto 12B" }];
const ESTADOS_PEDIDO = {
  pendiente: { label: "Pendiente", color: C.warn, bg: C.warnBg }, en_preparacion: { label: "En preparación", color: C.cyanText, bg: "#E0F7FA" },
  en_camino: { label: "En camino", color: C.navy, bg: `${C.navy}12` }, listo_retiro: { label: "Listo para retiro", color: C.navy, bg: `${C.navy}12` },
  entregado: { label: "Entregado", color: C.success, bg: C.successBg }, retirado: { label: "Retirado", color: C.success, bg: C.successBg },
};

const ESTADOS_TRASLADO = {
  confirmado: { label: "Confirmado", color: C.success, bg: C.successBg },
  realizado: { label: "Realizado", color: C.inkSoft, bg: C.slate100 },
  en_cotizacion: { label: "En cotización", color: C.warn, bg: C.warnBg },
};

/* ══════ DATOS — CERTIFICADOS / CONTACTOS DE EMERGENCIA ══════ */

const TIPOS_CERTIFICADO = ["Certificado de Atención", "Certificado Médico General", "Certificado de Interconsulta", "Certificado de Vacunación"];
const CERTIFICADOS_MOCK = [
  { id: "cert1", tipo: "Certificado de Atención", motivo: "Control Endocrinología", medico: "Dr. Matías Contreras Soto", fecha: "28 jul 2026", estado: "disponible" },
  { id: "cert2", tipo: "Certificado Médico General", motivo: "Evaluación dermatológica", medico: "Dra. Antonia Reyes Fuentes", fecha: fechaCorta(diasDesdeHoy(-3)), estado: "en_preparacion" },
];
const PARENTESCOS = ["Madre", "Padre", "Cónyuge / Pareja", "Hijo/a", "Hermano/a", "Abuelo/a", "Otro"];
const TIPOS_CENTRO_SALUD = ["Hospital", "Clínica", "Centro médico", "Centro de diálisis"];

/* ══════ DATOS — CONTACTO Y AYUDA ══════ */

// MOCK — en producción los canales y el horario vienen de la configuración de cada institución (tenant), y las
// solicitudes las crea y responde el sistema de atención (Communication / Task en MAIN). Valores de ejemplo, no reales.
const CANALES_CONTACTO = { telefono: "+56 2 0000 0000", correo: "ayuda@ejemplo.invalid", horario: "Lunes a viernes, de 08:00 a 20:00" };
// Canal administrativo. Los reclamos y sugerencias formales son de OIRS (otra función) y las urgencias no pasan por aquí.
const MOTIVOS_CONTACTO = ["Consulta general", "Agenda y citas", "Movilización y traslados", "Pagos y cobros", "Documentos y certificados", "Corregir mis datos", "Problemas con el portal"];
const ESTADOS_SOLICITUD = {
  recibida: { label: "Recibida", color: C.warn, bg: C.warnBg },
  respondida: { label: "Respondida", color: C.success, bg: C.successBg },
};
const solicitudesContactoDemo = () => [
  { id: "sol0", folio: `SOL-${new Date().getFullYear()}-0412`, motivo: "Documentos y certificados", mensaje: "Necesito mi certificado de atención de la consulta de Endocrinología.", canal: "correo", fechaIso: isoFecha(diasDesdeHoy(-3)), estado: "respondida", respuesta: "Tu certificado ya está disponible en la sección Certificados. Si no lo ves, escríbenos de nuevo." },
];

/* ══════ DATOS — CONSENTIMIENTOS INFORMADOS ══════ */

const CONSENTIMIENTOS_MOCK = [
  {
    id: "cons1", titulo: "Consentimiento para Colonoscopía Diagnóstica", procedimiento: "Colonoscopía",
    equipo: "Equipo de Gastroenterología", fechaProcedimiento: fechaCorta(diasDesdeHoy(6)), estado: "pendiente",
    cuerpo: [
      { h: "¿En qué consiste?", p: "Una colonoscopía es un examen que permite observar el interior del colon mediante un tubo flexible con cámara, para evaluar la mucosa intestinal." },
      { h: "Objetivo", p: "Evaluar la causa de los síntomas informados y descartar la presencia de pólipos u otras lesiones." },
      { h: "Riesgos y molestias posibles", p: "Molestia abdominal, distensión y, en casos poco frecuentes, sangrado o perforación intestinal, que se manejan según protocolo del centro." },
      { h: "Beneficios esperados", p: "Diagnóstico preciso que orienta el tratamiento a seguir." },
      { h: "Alternativas", p: "Existen estudios de imagen menos invasivos, con menor capacidad diagnóstica y sin posibilidad de toma de biopsia." },
      { h: "Tus derechos", p: "Puedes revocar este consentimiento en cualquier momento antes del procedimiento y solicitar más información a tu equipo tratante, sin que eso afecte tu atención." },
    ],
  },
  {
    id: "cons2", titulo: "Consentimiento para Control de Endocrinología", procedimiento: "Control Endocrinología",
    equipo: "Dr. Matías Contreras Soto", fechaProcedimiento: "28 jul 2026", estado: "firmado",
    firmadoEn: "28 jul 2026 · 09:14", codigoFirma: "FES-8842-K1",
    cuerpo: [
      { h: "¿En qué consiste?", p: "Autorización para la evaluación clínica, examen físico y eventual solicitud de exámenes de laboratorio asociados al control de endocrinología." },
      { h: "Tus derechos", p: "Puedes revocar este consentimiento en cualquier momento y solicitar más información a tu equipo tratante, sin que eso afecte tu atención." },
    ],
  },
];

/* ══════ DATOS — FICHA CLÍNICA DIGITAL ══════ */

const SECCIONES_FICHA = [
  { id: "identificacion", lbl: "1. Identificación", icon: User },
  { id: "antecedentes", lbl: "2. Antecedentes", icon: Shield },
  { id: "resumen", lbl: "3. Resumen Clínico", icon: FileText },
  { id: "vitales", lbl: "4. Signos Vitales", icon: HeartPulse },
  { id: "consultas", lbl: "5. Consultas", icon: Stethoscope },
  { id: "examenes", lbl: "6. Exámenes", icon: Search },
  { id: "procedimientos", lbl: "7. Procedimientos", icon: Syringe },
  { id: "documentos", lbl: "8. Documentos", icon: Download },
];
const HABITOS_MOCK = { tabaco: "No fumador", alcohol: "Ocasional", actividadFisica: "3 veces por semana" };
// MOCK — antecedentes familiares: se asume que los registra el equipo tratante en el EMR (MAIN); la Ficha solo los muestra (igual que Hábitos).
// Decisión pendiente: si el paciente debe poder editarlos desde Mi Perfil.
const FAMILIARES_MOCK = [
  { id: "fam1", condicion: "Diabetes tipo 2", parentesco: "Madre" },
  { id: "fam2", condicion: "Hipertensión arterial", parentesco: "Padre" },
];
// IMC = peso (kg) / talla (m)². Se calcula con el peso y la talla de cada control; no se guarda como dato aparte.
const calcularIMC = (pesoKg, tallaCm) => (pesoKg && tallaCm ? (pesoKg / ((tallaCm / 100) ** 2)).toFixed(1) : "—");
const SIGNOS_VITALES_MOCK = [
  { fecha: "10 ene 2026", peso: 63.5, talla: 165, presion: "118/76", fc: 72, fr: 16, temp: 36.5, spo2: 98 },
  { fecha: "20 mar 2026", peso: 62.8, talla: 165, presion: "116/74", fc: 70, fr: 15, temp: 36.6, spo2: 98 },
  { fecha: "28 jul 2026", peso: 61.9, talla: 165, presion: "120/78", fc: 74, fr: 16, temp: 36.4, spo2: 99 },
];
const DIAGNOSTICOS_MOCK = [
  { id: "dx1", descripcion: "Hipotiroidismo subclínico", desde: "mar 2024", registradoPor: "Dr. Matías Contreras Soto" },
];
const CONSULTAS_MOCK = [
  { id: "enc1", fecha: "28 jul 2026", especialidad: "Endocrinología", profesional: "Dr. Matías Contreras Soto", motivo: "Control de hipotiroidismo", diagnostico: "Hipotiroidismo subclínico, en tratamiento" },
  { id: "enc2", fecha: "15 jul 2026", especialidad: "Dermatología", profesional: "Dra. Antonia Reyes Fuentes", motivo: "Lesión cutánea en antebrazo", diagnostico: "Dermatitis de contacto" },
];
const EXAMENES_RESULTADOS_MOCK = [
  { id: "res3", tipo: "Laboratorio", nombre: "Hemograma completo", fecha: fechaCorta(diasDesdeHoy(-2)), estado: "pendiente" },
  { id: "res1", tipo: "Laboratorio", nombre: "Perfil tiroideo (TSH, T4L)", fecha: "25 jul 2026", estado: "disponible" },
  { id: "res2", tipo: "Imagenología", nombre: "Ecografía tiroidea", fecha: "20 jun 2026", estado: "disponible" },
];
const PROCEDIMIENTOS_FICHA_MOCK = [
  { id: "proc1", nombre: "Colonoscopía Diagnóstica", fecha: fechaCorta(diasDesdeHoy(6)), estado: "programado" },
  { id: "proc2", nombre: "Biopsia cutánea", fecha: "15 jul 2026", estado: "realizado" },
];

/* ══════ ÁTOMOS COMPARTIDOS ══════ */

const CUPCard = ({ cuenta, revelarCup, convenioNombre }) => {
  const v = CARD_VARIANTS[cuenta?.userTypeId] || CARD_VARIANTS.PACIENTE_PARTICULAR;
  return (
    <div style={{ width: 300, aspectRatio: "1.6", borderRadius: 16, background: `linear-gradient(105deg, transparent 28%, rgba(255,255,255,0.22) 42%, rgba(255,255,255,0.04) 52%, transparent 64%), ${v.bg}`, padding: 20, color: v.text, position: "relative", overflow: "hidden", border: "1px solid rgba(255,255,255,0.10)", boxShadow: `inset 0 1px 0 rgba(255,255,255,0.14), 0 2px 6px rgba(0,0,0,0.18), 0 20px 36px ${v.shadow}`, display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
      <svg viewBox="0 0 120 120" style={{ position: "absolute", top: -14, right: -14, width: 140, height: 140, opacity: 0.16 }}>
        {[[95, 30], [105, 65], [85, 100], [30, 90]].map(([x, y], i) => (
          <g key={i}><line x1="60" y1="60" x2={x} y2={y} stroke={v.pattern} strokeWidth="1.5" /><circle cx={x} cy={y} r="3" fill={v.pattern} /></g>
        ))}
        <circle cx="60" cy="60" r="4" fill={v.pattern} /><line x1="95" y1="30" x2="70" y2="10" stroke={v.pattern} strokeWidth="1" /><circle cx="70" cy="10" r="2" fill={v.pattern} />
      </svg>
      <div style={{ position: "relative", zIndex: 1 }}>
        <div style={{ width: 36, height: 26, borderRadius: 5, background: "linear-gradient(135deg, #E8D9A8, #B8A15E)", marginBottom: 12 }} />
        <div style={{ display: "flex", alignItems: "center", gap: 7 }}>
          <div style={{ width: 20, height: 20, borderRadius: "50%", border: `1.5px dashed ${v.textSoft}`, flexShrink: 0 }} />
          <span style={{ fontFamily: F.d, fontSize: 16, fontWeight: 700 }}>AXON Health</span>
        </div>
        <div style={{ fontFamily: F.m, fontSize: 9, letterSpacing: "0.12em", textTransform: "uppercase", opacity: 0.9, marginTop: 4, color: v.textSoft }}>{cuenta ? cuenta.tierLabel : "Carné digital de salud"}</div>
        {cuenta && <div style={{ fontFamily: F.b, fontSize: 13, fontWeight: 600, marginTop: 10 }}>{cuenta.nombres} {cuenta.apellidoPaterno}</div>}
        {cuenta && convenioNombre && <div style={{ fontFamily: F.b, fontSize: 10.5, marginTop: 3, color: v.textSoft }}>{convenioNombre}</div>}
      </div>
      <div style={{ fontFamily: F.m, fontSize: 14, fontWeight: 600, letterSpacing: "0.05em", position: "relative", zIndex: 1, color: v.cupColor }}>{revelarCup && cuenta ? cuenta.cup : "CUP-CL-13-····"}</div>
    </div>
  );
};

const Field = ({ label, error, children }) => (
  <div style={{ marginBottom: error ? 6 : 20 }}>
    <label style={{ display: "block", fontSize: 13, fontWeight: 600, marginBottom: 6, color: C.ink, fontFamily: F.b }}>{label}</label>
    {children}
    {error && <div style={{ display: "flex", alignItems: "center", gap: 5, marginTop: 6, marginBottom: 14 }}><AlertCircle size={12} color={C.danger} /><span style={{ fontSize: 11.5, color: C.danger, fontFamily: F.b }}>{error}</span></div>}
  </div>
);

const DatoRow = ({ label, valor }) => (
  <div>
    <div style={{ fontFamily: F.m, fontSize: 10, textTransform: "uppercase", letterSpacing: "0.06em", color: C.inkSoft, marginBottom: 4 }}>{label}</div>
    <div style={{ fontSize: 13.5, color: C.ink, fontWeight: 500 }}>{valor || "—"}</div>
  </div>
);

const FirmaCanvas = ({ onCambio }) => {
  const canvasRef = useRef(null);
  const dibujando = useRef(false);
  const vacio = useRef(true);

  const dibujarGuia = (ctx, w, h) => {
    ctx.save();
    ctx.strokeStyle = C.slate200; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(18, h - 26); ctx.lineTo(w - 18, h - 26); ctx.stroke();
    ctx.restore();
    ctx.strokeStyle = C.ink; ctx.lineWidth = 2.4; ctx.lineCap = "round"; ctx.lineJoin = "round";
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    const ratio = window.devicePixelRatio || 1;
    canvas.width = rect.width * ratio;
    canvas.height = rect.height * ratio;
    const ctx = canvas.getContext("2d");
    ctx.scale(ratio, ratio);
    dibujarGuia(ctx, rect.width, rect.height);
  }, []);

  const coords = (e) => {
    const rect = canvasRef.current.getBoundingClientRect();
    const cx = e.touches ? e.touches[0].clientX : e.clientX;
    const cy = e.touches ? e.touches[0].clientY : e.clientY;
    return { x: cx - rect.left, y: cy - rect.top };
  };
  const empezar = (e) => {
    e.preventDefault(); dibujando.current = true;
    const { x, y } = coords(e);
    canvasRef.current.getContext("2d").beginPath();
    canvasRef.current.getContext("2d").moveTo(x, y);
  };
  const mover = (e) => {
    if (!dibujando.current) return;
    e.preventDefault();
    const { x, y } = coords(e);
    const ctx = canvasRef.current.getContext("2d");
    ctx.lineTo(x, y); ctx.stroke();
    if (vacio.current) { vacio.current = false; onCambio(true); }
  };
  const terminar = () => { dibujando.current = false; };
  const limpiar = () => {
    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    const ctx = canvas.getContext("2d");
    ctx.clearRect(0, 0, rect.width, rect.height);
    dibujarGuia(ctx, rect.width, rect.height);
    vacio.current = true; onCambio(false);
  };

  return (
    <div>
      <div style={{ border: `1.5px dashed ${C.slate400}`, borderRadius: 12, background: "#fff", overflow: "hidden", boxShadow: "inset 0 1px 3px rgba(0,0,0,0.04)" }}>
        <canvas
          ref={canvasRef}
          style={{ width: "100%", height: 170, display: "block", cursor: "crosshair", touchAction: "none" }}
          onMouseDown={empezar} onMouseMove={mover} onMouseUp={terminar} onMouseLeave={terminar}
          onTouchStart={empezar} onTouchMove={mover} onTouchEnd={terminar}
        />
      </div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 8 }}>
        <span style={{ fontSize: 11, color: C.inkSoft }}>Firma con el dedo o el mouse sobre la línea.</span>
        <button type="button" onClick={limpiar} style={{ background: "none", border: "none", cursor: "pointer", color: C.cyanText, fontFamily: F.b, fontWeight: 600, fontSize: 11.5 }}>Limpiar firma</button>
      </div>
    </div>
  );
};

const FunctionCard = ({ item, onClick }) => (
  <button onClick={onClick} className="ppa-func" style={{ display: "flex", flexDirection: "column", alignItems: "flex-start", gap: 10, background: "#fff", border: `1px solid ${C.slate200}`, borderRadius: 12, padding: "16px 14px", cursor: "pointer", textAlign: "left", position: "relative", minHeight: 92 }}>
    {item.nuevo && <span style={{ position: "absolute", top: 10, right: 10, fontFamily: F.m, fontSize: 8.5, letterSpacing: "0.06em", textTransform: "uppercase", color: C.cyanText, background: "#E0F7FA", padding: "2px 6px", borderRadius: 4 }}>nuevo</span>}
    <div style={{ width: 34, height: 34, borderRadius: 9, background: `${C.navy}12`, display: "flex", alignItems: "center", justifyContent: "center" }}><item.icon size={16} color={C.navy} /></div>
    <span style={{ fontSize: 12.5, fontWeight: 600, lineHeight: 1.3, color: C.ink, fontFamily: F.b }}>{item.label}</span>
  </button>
);

const Stepper = ({ pasos, actual }) => (
  <div style={{ display: "flex", alignItems: "center", marginBottom: 26, flexWrap: "wrap", gap: 6 }}>
    {pasos.map((p, i) => (
      <div key={p} style={{ display: "flex", alignItems: "center" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 6, color: i <= actual ? C.navy : C.slate400, fontFamily: F.b, fontSize: 12.5, fontWeight: i === actual ? 700 : 500 }}>
          <div style={{ width: 22, height: 22, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", background: i < actual ? C.navy : i === actual ? "#fff" : C.slate100, border: `1.5px solid ${i <= actual ? C.navy : C.slate200}`, color: i < actual ? "#fff" : i === actual ? C.navy : C.slate400, fontSize: 10.5, fontWeight: 700, flexShrink: 0 }}>{i < actual ? <CheckCircle size={13} /> : i + 1}</div>
          {p}
        </div>
        {i < pasos.length - 1 && <ChevronRight size={14} color={C.slate200} style={{ margin: "0 8px" }} />}
      </div>
    ))}
  </div>
);

const OpcionCard = ({ activo, onClick, children, style }) => (
  <button onClick={onClick} className="ppa-opt" style={{ textAlign: "left", cursor: "pointer", borderRadius: 11, padding: "13px 15px", border: `1.5px solid ${activo ? C.navy : C.slate200}`, background: activo ? `${C.navy}08` : "#fff", fontFamily: F.b, ...style }}>{children}</button>
);

const BackLink = ({ onClick, children = "Volver" }) => (
  <button onClick={onClick} style={{ display: "flex", alignItems: "center", gap: 5, background: "none", border: "none", cursor: "pointer", color: C.inkSoft, fontSize: 12.5, fontFamily: F.b, marginBottom: 14, padding: 0 }}><ChevronLeft size={13} /> {children}</button>
);

const EnlaceContacto = ({ onClick, children }) => (
  <button type="button" className="ppa-link" onClick={onClick} style={{ background: "none", border: "none", padding: 0, cursor: "pointer", color: C.cyanText, fontFamily: "inherit", fontWeight: 600, fontSize: "inherit" }}>{children}</button>
);

const SelectorFecha = ({ disponibles, valor, onElegir }) => {
  const ordenadas = [...disponibles].sort();
  const indiceMes = (iso) => { const [a, m] = iso.split("-").map(Number); return a * 12 + (m - 1); };
  const primero = ordenadas.length ? indiceMes(ordenadas[0]) : 0;
  const ultimo = ordenadas.length ? indiceMes(ordenadas[ordenadas.length - 1]) : 0;
  const isoSel = valor ? ordenadas.find(iso => etiquetaFecha(new Date(`${iso}T00:00:00`)) === valor) : null;
  const [mes, setMes] = useState(isoSel ? indiceMes(isoSel) : primero);
  if (!ordenadas.length) return <div style={{ ...S.muted, background: C.slate100, borderRadius: 10, padding: "14px 16px" }}>Por ahora no hay fechas disponibles.</div>;
  const anio = Math.floor(mes / 12), mesNum = mes % 12;
  const conCupo = new Set(ordenadas);
  const offset = (new Date(anio, mesNum, 1).getDay() + 6) % 7;
  const celdas = [...Array(offset).fill(null), ...Array.from({ length: new Date(anio, mesNum + 1, 0).getDate() }, (_, i) => new Date(anio, mesNum, i + 1))];
  const hayNavegacion = ultimo > primero;
  const flecha = (dir, activa) => !hayNavegacion ? <div style={{ width: 32, height: 32 }} /> : (
    <button type="button" className="ppa-cal-nav" disabled={!activa} onClick={() => setMes(mes + dir)} aria-label={dir < 0 ? "Mes anterior" : "Mes siguiente"} style={{ width: 32, height: 32, borderRadius: 8, border: "none", background: "transparent", display: "flex", alignItems: "center", justifyContent: "center", cursor: activa ? "pointer" : "default", opacity: activa ? 1 : 0.3 }}>
      {dir < 0 ? <ChevronLeft size={17} color={C.slate400} /> : <ChevronRight size={17} color={C.slate400} />}
    </button>
  );
  return (
    <div style={{ maxWidth: 380, margin: "0 auto" }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }}>
        {flecha(-1, mes > primero)}
        <div style={{ fontFamily: F.d, fontSize: 14.5, fontWeight: 700, color: C.navy }}>{MESES_ES[mesNum]} {anio}</div>
        {flecha(1, mes < ultimo)}
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)", gap: 4, marginBottom: 4 }}>
        {["Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom"].map(d => <div key={d} style={{ textAlign: "center", fontFamily: F.m, fontSize: 9.5, textTransform: "uppercase", letterSpacing: "0.05em", color: C.inkSoft, padding: "4px 0" }}>{d}</div>)}
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)", gap: 4 }}>
        {celdas.map((d, i) => {
          if (!d) return <div key={`v${i}`} />;
          const disp = conCupo.has(isoFecha(d));
          const sel = valor === etiquetaFecha(d);
          return (
            <button key={i} type="button" disabled={!disp} onClick={() => onElegir(d)} className={`ppa-cal-dia${sel ? " sel" : ""}`} aria-pressed={sel} aria-label={`${d.getDate()} de ${MESES_ES[mesNum].toLowerCase()}${disp ? ", con horas disponibles" : ", sin disponibilidad"}`} style={{ position: "relative", height: 42, borderRadius: 9, border: "none", background: sel ? C.navy : "transparent", color: sel ? "#fff" : disp ? C.ink : C.slate400, fontFamily: F.b, fontWeight: disp ? 700 : 500, fontSize: 13, cursor: disp ? "pointer" : "default", opacity: disp ? 1 : 0.55 }}>
              {d.getDate()}
              {disp && <span style={{ position: "absolute", bottom: 5, left: "50%", transform: "translateX(-50%)", width: 4, height: 4, borderRadius: "50%", background: sel ? "#fff" : C.cyan }} />}
            </button>
          );
        })}
      </div>
      <div style={{ display: "flex", alignItems: "center", gap: 6, marginTop: 12, fontSize: 11, color: C.inkSoft }}>
        <span style={{ width: 5, height: 5, borderRadius: "50%", background: C.cyan }} /> Con horas disponibles
      </div>
    </div>
  );
};

const Tabs = ({ options, active, onChange }) => (
  <div style={S.tabWrap}>
    {options.map(([id, lbl]) => (
      <button key={id} onClick={() => onChange(id)} className="ppa-tab" style={{ padding: "7px 14px", borderRadius: 6, border: "none", cursor: "pointer", background: active === id ? "#fff" : "transparent", boxShadow: active === id ? "0 1px 3px rgba(0,0,0,0.08)" : "none", fontFamily: F.b, fontWeight: 600, fontSize: 12.5, color: active === id ? C.navy : C.inkSoft }}>{lbl}</button>
    ))}
  </div>
);

const FuncionHeader = ({ titulo, usuario, tabs, activeTab, onTabChange }) => (
  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 22, flexWrap: "wrap", gap: 12 }}>
    <div>
      <div style={{ fontFamily: F.d, fontSize: 22, fontWeight: 700, color: C.navy }}>{titulo}</div>
      <div style={{ fontSize: 12, color: C.inkSoft, marginTop: 2 }}>{usuario.nombres} {usuario.apellidoPaterno} · <span style={{ fontFamily: F.m }}>{usuario.cup}</span></div>
    </div>
    {tabs.length > 1 && <Tabs options={tabs} active={activeTab} onChange={onTabChange} />}
  </div>
);

const ConfirmacionExito = ({ titulo, detalle, textoBoton, onClick }) => (
  <div style={{ ...S.card, textAlign: "center", padding: 32 }}>
    <div style={{ width: 52, height: 52, borderRadius: "50%", background: C.successBg, display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 16px" }}><CheckCircle size={26} color={C.success} /></div>
    <div style={{ fontFamily: F.d, fontSize: 18, fontWeight: 700, color: C.navy, marginBottom: 6 }}>{titulo}</div>
    <p style={{ fontSize: 13, color: C.inkSoft, margin: "0 0 22px" }}>{detalle}</p>
    <button className="ppa-btn" onClick={onClick} style={{ ...S.primaryBtn, padding: "11px 22px", fontSize: 13.5 }}>{textoBoton}</button>
  </div>
);

const ToastMsg = ({ msg, Icon = AlertCircle }) => (
  <div style={{ position: "fixed", bottom: 24, left: "50%", transform: "translateX(-50%)", background: C.ink, color: "#fff", padding: "11px 18px", borderRadius: 9, fontFamily: F.b, fontSize: 13, boxShadow: "0 10px 30px rgba(0,0,0,0.25)", display: "flex", alignItems: "center", gap: 8, zIndex: 999, maxWidth: "90vw" }}>
    <Icon size={13} />{msg}
  </div>
);

/* ══════ VISTA — ACCESO (Login + Registro) ══════ */

function VistaAcceso({ onLogin, mostrarToast }) {
  const [modo, setModo] = useState("individual");
  const [convenioSeleccionado, setConvenioSeleccionado] = useState(null);
  const [buscarConvenio, setBuscarConvenio] = useState("");
  const [rut, setRut] = useState(""); const [pass, setPass] = useState(""); const [showPass, setShowPass] = useState(false);
  const [rutTouched, setRutTouched] = useState(false); const [loginError, setLoginError] = useState(""); const [loading, setLoading] = useState(false);
  const [registrando, setRegistrando] = useState(false);
  const [regNombres, setRegNombres] = useState(""); const [regApellidoPaterno, setRegApellidoPaterno] = useState(""); const [regApellidoMaterno, setRegApellidoMaterno] = useState("");
  const [regFechaNacimiento, setRegFechaNacimiento] = useState(""); const [regRut, setRegRut] = useState(""); const [regRegion, setRegRegion] = useState("13");
  const [regEmail, setRegEmail] = useState(""); const [regPaisTel, setRegPaisTel] = useState(PAISES_TEL[0]); const [regTelefono, setRegTelefono] = useState("");
  const [mostrarPaises, setMostrarPaises] = useState(false); const [regPrevision, setRegPrevision] = useState("particular"); const [regIsapre, setRegIsapre] = useState("");
  const [mostrarModalConsentimiento, setMostrarModalConsentimiento] = useState(false);
  const [regPass, setRegPass] = useState(""); const [regPassConfirm, setRegPassConfirm] = useState(""); const [regConsentimiento, setRegConsentimiento] = useState(false);
  const [regTouched, setRegTouched] = useState(false); const [regError, setRegError] = useState("");

  const resetForm = () => { setRut(""); setPass(""); setRutTouched(false); setLoginError(""); };
  const cambiarModo = (m) => { setModo(m); setConvenioSeleccionado(null); setBuscarConvenio(""); setRegistrando(false); resetForm(); };
  const cuentasActivas = modo === "individual" ? CUENTAS_INDIVIDUAL : convenioSeleccionado ? CUENTAS_CONVENIO.filter(c => c.convenioId === convenioSeleccionado.id) : [];
  const cuentaPrevia = rut ? cuentasActivas.find(c => c.rut === rut) : null;
  const convenioActivoNombre = cuentaPrevia?.convenioId ? CONVENIOS_DEMO.find(cv => cv.id === cuentaPrevia.convenioId)?.nombre : null;
  const conveniosFiltrados = CONVENIOS_DEMO.filter(cv => cv.nombre.toLowerCase().includes(buscarConvenio.toLowerCase()));
  const rutValido = rut.length === 0 || validarRUT(rut);

  const handleSubmit = () => {
    setRutTouched(true); setLoginError("");
    if (!validarRUT(rut)) return;
    if (!pass) { setLoginError("Ingresa tu contraseña."); return; }
    setLoading(true);
    setTimeout(() => {
      const match = cuentasActivas.find(c => c.rut === rut && c.password === pass);
      setLoading(false);
      if (match) onLogin(match); else setLoginError("RUT o contraseña incorrectos.");
    }, 550);
  };
  const usarDemo = (c) => { setRut(c.rut); setPass(c.password); setRutTouched(false); setLoginError(""); };
  const volverALogin = () => {
    setRegistrando(false);
    setRegNombres(""); setRegApellidoPaterno(""); setRegApellidoMaterno(""); setRegFechaNacimiento(""); setRegRut(""); setRegRegion("13");
    setRegEmail(""); setRegPaisTel(PAISES_TEL[0]); setRegTelefono(""); setMostrarPaises(false); setRegPrevision("particular"); setRegIsapre("");
    setRegPass(""); setRegPassConfirm(""); setRegConsentimiento(false); setRegTouched(false); setRegError(""); setMostrarModalConsentimiento(false);
  };
  const handleRegistro = () => {
    setRegTouched(true); setRegError("");
    if (!regNombres.trim() || !regApellidoPaterno.trim()) { setRegError("Completa tus nombres y apellido paterno."); return; }
    if (!regFechaNacimiento) { setRegError("Ingresa tu fecha de nacimiento."); return; }
    if (!validarRUT(regRut)) { setRegError("RUT inválido — revisa el dígito verificador."); return; }
    if (!validarEmail(regEmail)) { setRegError("Ingresa un correo electrónico válido."); return; }
    if (regTelefono.replace(/\D/g, "").length < 7) { setRegError("Ingresa un número de teléfono válido."); return; }
    if (regPrevision === "isapre" && !regIsapre) { setRegError("Selecciona tu Isapre."); return; }
    if (regPass.length < 8) { setRegError("La contraseña debe tener al menos 8 caracteres."); return; }
    if (regPass !== regPassConfirm) { setRegError("Las contraseñas no coinciden."); return; }
    if (!regConsentimiento) { setRegError("Debes aceptar la Política de Privacidad y Consentimiento CUP."); return; }
    onLogin({
      rut: regRut, password: regPass, nombres: regNombres.trim(), apellidoPaterno: regApellidoPaterno.trim(), apellidoMaterno: regApellidoMaterno.trim(),
      email: regEmail, telefono: `${regPaisTel.indicativo} ${regTelefono}`, prevision: regPrevision === "isapre" ? regIsapre : regPrevision === "fonasa" ? "Fonasa" : "Particular",
      region: regRegion, fechaNacimiento: regFechaNacimiento, contactosEmergencia: [], antecedentesClinicos: ANTECEDENTES_VACIOS,
      direccion: "", perfilMovilidad: PERFIL_MOVILIDAD_VACIO, centrosSaludFrecuentes: [],
      cup: generarCUP(regRegion), userTypeId: "PACIENTE_PARTICULAR", tierLabel: "Usuario Abierto",
    });
    mostrarToast("CUP generado — bienvenido/a a AXON Health.");
  };

  return (
    <div style={{ ...S.page, alignItems: "center" }}>
      <div style={{ width: "100%", maxWidth: 860, borderRadius: 22, overflow: "hidden", border: `1px solid ${C.slate200}`, display: "flex", flexWrap: "wrap", boxShadow: "0 24px 60px rgba(27,58,102,0.10)" }}>
        <div style={{ flex: "1 1 360px", background: "#fff", padding: "44px 40px" }}>
          <div style={{ width: 220, height: 58, border: `1.5px dashed ${C.slate400}`, borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 26, fontFamily: F.m, fontSize: 10.5, color: C.inkSoft, textAlign: "center", lineHeight: 1.4 }}>[ espacio para tu logo ]</div>

          <div style={{ display: "flex", gap: 6, marginBottom: 26, background: C.slate100, borderRadius: 10, padding: 4 }}>
            {[["individual", "Acceso Individual"], ["colectivo", "Acceso Colectivo"]].map(([id, lbl]) => (
              <button key={id} onClick={() => cambiarModo(id)} style={{ flex: 1, padding: "9px 0", borderRadius: 7, border: "none", cursor: "pointer", background: modo === id ? "#fff" : "transparent", boxShadow: modo === id ? "0 1px 4px rgba(0,0,0,0.08)" : "none", fontFamily: F.b, fontWeight: 600, fontSize: 12.5, color: modo === id ? C.navy : C.inkSoft }}>{lbl}</button>
            ))}
          </div>

          {modo === "colectivo" && !convenioSeleccionado ? (
            <>
              <h1 style={{ ...S.h1, fontSize: 22 }}>¿Cuál es tu convenio?</h1>
              <p style={S.muted}>Empresa, club o institución donde tienes tu beneficio de salud.</p>
              <div style={{ position: "relative", margin: "14px 0" }}>
                <Search size={15} color={C.inkSoft} style={{ position: "absolute", left: 13, top: "50%", transform: "translateY(-50%)" }} />
                <input className="ppa-input" style={{ ...S.input, paddingLeft: 38 }} value={buscarConvenio} onChange={(e) => setBuscarConvenio(e.target.value)} placeholder="Busca tu empresa o club…" />
              </div>
              {conveniosFiltrados.map(cv => (
                <button key={cv.id} className="ppa-row" onClick={() => setConvenioSeleccionado(cv)} style={{ display: "flex", alignItems: "center", gap: 12, width: "100%", textAlign: "left", background: C.slate100, border: `1px solid ${C.slate200}`, borderRadius: 10, padding: "12px 14px", marginBottom: 8, cursor: "pointer" }}>
                  <div style={{ width: 34, height: 34, borderRadius: 8, background: C.slate200, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}><Building2 size={16} color={C.navy} /></div>
                  <div style={{ flex: 1 }}><div style={{ fontSize: 13.5, fontWeight: 600, color: C.ink }}>{cv.nombre}</div><div style={{ fontSize: 11.5, color: C.inkSoft }}>{cv.tipo}</div></div>
                </button>
              ))}
              {!conveniosFiltrados.length && <p style={{ ...S.muted, textAlign: "center", padding: "14px 0" }}>Sin resultados para "{buscarConvenio}".</p>}
            </>
          ) : registrando ? (
            <>
              <BackLink onClick={volverALogin}>Volver a iniciar sesión</BackLink>
              <h1 style={{ ...S.h1, fontSize: 22 }}>Crea tu cuenta</h1>
              <p style={{ ...S.muted, margin: "0 0 22px" }}>Te asignamos tu Código Único de Paciente (CUP) al confirmar.</p>

              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                <Field label="Nombres"><input className="ppa-input" style={S.input} value={regNombres} onChange={(e) => setRegNombres(e.target.value)} placeholder="Javiera Antonia" /></Field>
                <Field label="Apellido paterno"><input className="ppa-input" style={S.input} value={regApellidoPaterno} onChange={(e) => setRegApellidoPaterno(e.target.value)} placeholder="Rojas" /></Field>
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                <Field label="Apellido materno"><input className="ppa-input" style={S.input} value={regApellidoMaterno} onChange={(e) => setRegApellidoMaterno(e.target.value)} placeholder="Muñoz" /></Field>
                <Field label="Fecha de nacimiento"><input className="ppa-input" type="date" style={S.input} value={regFechaNacimiento} onChange={(e) => setRegFechaNacimiento(e.target.value)} max={new Date().toISOString().slice(0, 10)} /></Field>
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                <Field label="RUT" error={regTouched && regRut && !validarRUT(regRut) ? "RUT inválido." : ""}>
                  <input className="ppa-input" style={{ ...S.input, fontFamily: F.m }} value={regRut} onChange={(e) => setRegRut(formatearRUT(e.target.value))} placeholder="12.345.678-9" maxLength={12} />
                </Field>
                <Field label="Región">
                  <select className="ppa-input" style={{ ...S.input, cursor: "pointer" }} value={regRegion} onChange={(e) => setRegRegion(e.target.value)}>
                    {REGIONES_CL.map(r => <option key={r.codigo} value={r.codigo}>{r.nombre}</option>)}
                  </select>
                </Field>
              </div>

              <Field label="Correo electrónico"><input className="ppa-input" type="email" style={S.input} value={regEmail} onChange={(e) => setRegEmail(e.target.value)} placeholder="javiera.rojas@correo.cl" /></Field>

              <Field label="Teléfono">
                <div style={{ display: "flex", gap: 8, position: "relative" }}>
                  <button type="button" onClick={() => setMostrarPaises(p => !p)} style={{ display: "flex", alignItems: "center", gap: 6, height: 46, padding: "0 10px", border: `1px solid ${C.slate200}`, borderRadius: 9, background: C.slate100, cursor: "pointer", flexShrink: 0 }}>
                    <span style={{ fontSize: 17, lineHeight: 1 }}>{regPaisTel.bandera}</span><span style={{ fontFamily: F.m, fontSize: 12.5, color: C.ink }}>{regPaisTel.indicativo}</span><ChevronDown size={13} color={C.inkSoft} />
                  </button>
                  <input className="ppa-input" style={{ ...S.input, flex: 1 }} value={regTelefono} onChange={(e) => setRegTelefono(e.target.value.replace(/[^\d\s]/g, ""))} placeholder="9 1234 5678" />
                  {mostrarPaises && (
                    <div style={{ position: "absolute", top: 52, left: 0, width: 250, maxHeight: 224, overflowY: "auto", background: "#fff", border: `1px solid ${C.slate200}`, borderRadius: 10, boxShadow: "0 14px 34px rgba(0,0,0,0.16)", zIndex: 60 }}>
                      {PAISES_TEL.map(p => (
                        <button key={p.codigo} type="button" onClick={() => { setRegPaisTel(p); setMostrarPaises(false); }} style={{ display: "flex", alignItems: "center", gap: 9, width: "100%", padding: "8px 12px", background: p.codigo === regPaisTel.codigo ? C.slate100 : "#fff", border: "none", cursor: "pointer", textAlign: "left" }}>
                          <span style={{ fontSize: 16, lineHeight: 1 }}>{p.bandera}</span><span style={{ fontSize: 12.5, color: C.ink, flex: 1 }}>{p.nombre}</span><span style={{ fontFamily: F.m, fontSize: 11.5, color: C.inkSoft }}>{p.indicativo}</span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </Field>

              <div style={{ display: "grid", gridTemplateColumns: regPrevision === "isapre" ? "1fr 1fr" : "1fr", gap: 12 }}>
                <Field label="Previsión de salud">
                  <select className="ppa-input" style={{ ...S.input, cursor: "pointer" }} value={regPrevision} onChange={(e) => { setRegPrevision(e.target.value); setRegIsapre(""); }}>
                    <option value="particular">Particular</option><option value="fonasa">Fonasa</option><option value="isapre">Isapre</option>
                  </select>
                </Field>
                {regPrevision === "isapre" && (
                  <Field label="Isapre">
                    <select className="ppa-input" style={{ ...S.input, cursor: "pointer" }} value={regIsapre} onChange={(e) => setRegIsapre(e.target.value)}>
                      <option value="">Selecciona tu Isapre</option>{ISAPRES_CL.map(i => <option key={i} value={i}>{i}</option>)}
                    </select>
                  </Field>
                )}
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                <Field label="Contraseña"><input className="ppa-input" type="password" style={S.input} value={regPass} onChange={(e) => setRegPass(e.target.value)} placeholder="Mínimo 8 caracteres" /></Field>
                <Field label="Confirmar contraseña"><input className="ppa-input" type="password" style={S.input} value={regPassConfirm} onChange={(e) => setRegPassConfirm(e.target.value)} placeholder="Repite tu contraseña" /></Field>
              </div>

              <div style={{ display: "flex", alignItems: "flex-start", gap: 9, marginBottom: 16 }}>
                <input type="checkbox" checked={regConsentimiento} onChange={(e) => { if (e.target.checked) setMostrarModalConsentimiento(true); else setRegConsentimiento(false); }} style={{ marginTop: 2, flexShrink: 0, cursor: "pointer" }} />
                <span style={{ fontSize: 11.5, color: C.inkSoft, lineHeight: 1.4 }}>Acepto la <span className="ppa-link" onClick={() => setMostrarModalConsentimiento(true)} style={{ color: C.cyanText, fontWeight: 600 }}>Política de Privacidad y Consentimiento CUP</span> para el tratamiento de mis datos de salud.</span>
              </div>

              {regError && <div style={{ display: "flex", alignItems: "center", gap: 7, background: C.dangerBg, border: "1px solid #FCA5A5", borderRadius: 8, padding: "9px 12px", marginBottom: 16 }}><AlertCircle size={14} color={C.danger} /><span style={{ fontSize: 12.5, color: C.danger }}>{regError}</span></div>}

              <button className="ppa-btn" onClick={handleRegistro} style={{ ...S.primaryBtn, width: "100%", height: 48, fontSize: 15 }}>Crear cuenta y generar mi CUP</button>
            </>
          ) : (
            <>
              {modo === "colectivo" && convenioSeleccionado && (
                <>
                  <BackLink onClick={() => { setConvenioSeleccionado(null); resetForm(); }}>Cambiar convenio</BackLink>
                  <div style={{ background: C.slate100, border: `1px solid ${C.slate200}`, borderRadius: 10, padding: "10px 13px", marginBottom: 22, fontSize: 12.5, color: C.ink }}>Ingresando como beneficiario/a de <b>{convenioSeleccionado.nombre}</b></div>
                </>
              )}
              <h1 style={{ ...S.h1, fontSize: 24 }}>Bienvenido/a</h1>
              <p style={{ ...S.muted, margin: "0 0 26px" }}>Ingresa con tu RUT para ver tu agenda, ficha y bonos.</p>
              <Field label="RUT" error={rutTouched && rut && !rutValido ? "RUT inválido — revisa el dígito verificador." : ""}>
                <input className="ppa-input" style={{ ...S.input, fontFamily: F.m, borderColor: rutTouched && rut && !rutValido ? C.danger : C.slate200 }} value={rut} onChange={(e) => { setRut(formatearRUT(e.target.value)); setLoginError(""); }} onBlur={() => setRutTouched(true)} placeholder="12.345.678-9" maxLength={12} />
              </Field>
              <Field label="Contraseña">
                <div style={{ position: "relative" }}>
                  <input className="ppa-input" type={showPass ? "text" : "password"} style={{ ...S.input, paddingRight: 42 }} value={pass} onChange={(e) => { setPass(e.target.value); setLoginError(""); }} placeholder="••••••••••" onKeyDown={(e) => e.key === "Enter" && handleSubmit()} />
                  <button onClick={() => setShowPass(p => !p)} style={{ position: "absolute", right: 12, top: "50%", transform: "translateY(-50%)", background: "none", border: "none", cursor: "pointer", color: C.inkSoft, padding: 4, display: "flex" }}>{showPass ? <EyeOff size={16} /> : <Eye size={16} />}</button>
                </div>
              </Field>
              {loginError && <div style={{ display: "flex", alignItems: "center", gap: 7, background: C.dangerBg, border: "1px solid #FCA5A5", borderRadius: 8, padding: "9px 12px", marginBottom: 16 }}><AlertCircle size={14} color={C.danger} /><span style={{ fontSize: 12.5, color: C.danger }}>{loginError}</span></div>}
              <button className="ppa-btn" onClick={handleSubmit} disabled={loading} style={{ ...S.primaryBtn, width: "100%", height: 48, fontSize: 15, background: loading ? C.slate400 : C.navy, cursor: loading ? "default" : "pointer", marginBottom: 18, display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>{loading ? "Verificando…" : "Iniciar sesión"}</button>
              {modo === "individual" && (
                <>
                  <p style={{ fontSize: 13, color: C.inkSoft, textAlign: "center", margin: "0 0 8px" }}><span className="ppa-link" onClick={() => mostrarToast("Recuperación de contraseña — próxima puerta a construir.")} style={{ color: C.cyanText, fontWeight: 600 }}>¿Olvidaste tu contraseña?</span></p>
                  <p style={{ fontSize: 13, color: C.inkSoft, textAlign: "center", margin: "0 0 22px" }}>¿No tienes cuenta?{" "}<span className="ppa-link" onClick={() => setRegistrando(true)} style={{ color: C.cyanText, fontWeight: 600 }}>Crear cuenta</span></p>
                </>
              )}
              <div style={{ marginTop: modo === "individual" ? 8 : 26, paddingTop: 20, borderTop: `1px dashed ${C.slate200}` }}>
                <p style={{ fontFamily: F.m, fontSize: 10, textTransform: "uppercase", letterSpacing: "0.08em", color: C.inkSoft, margin: "0 0 10px" }}>Cuenta{cuentasActivas.length > 1 ? "s" : ""} demo — sin backend real</p>
                {cuentasActivas.map(c => (
                  <button key={c.rut} onClick={() => usarDemo(c)} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", width: "100%", background: C.slate100, border: `1px solid ${C.slate200}`, borderRadius: 8, padding: "8px 12px", marginBottom: 6, cursor: "pointer", textAlign: "left" }}>
                    <span style={{ fontFamily: F.m, fontSize: 11.5, color: C.ink }}>{c.rut}</span><span style={{ fontFamily: F.m, fontSize: 10, color: C.copper, background: "#F7E9DD", padding: "2px 8px", borderRadius: 5 }}>{c.tierLabel}</span>
                  </button>
                ))}
                <p style={{ fontSize: 10.5, color: C.inkSoft, margin: "6px 0 0" }}>Clic en una cuenta para rellenar el formulario · contraseña: demo123</p>
              </div>
            </>
          )}
        </div>
        <div style={{ flex: "1 1 360px", background: C.navy, padding: "44px 40px", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 20 }}>
          <CUPCard cuenta={cuentaPrevia} revelarCup={false} convenioNombre={convenioActivoNombre} />
          <p style={{ fontSize: 12, color: "rgba(255,255,255,0.75)", textAlign: "center", margin: 0 }}>{cuentaPrevia ? "Te reconocemos — ingresa tu contraseña para ver todo." : "Tu carné digital de salud"}</p>
        </div>
      </div>

      {mostrarModalConsentimiento && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(15,23,42,0.55)", display: "flex", alignItems: "center", justifyContent: "center", padding: 20, zIndex: 1000 }}>
          <div style={{ background: "#fff", borderRadius: 16, maxWidth: 460, width: "100%", padding: "28px 26px", maxHeight: "85vh", overflowY: "auto" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 6 }}>
              <div style={{ width: 38, height: 38, borderRadius: 10, background: `${C.navy}12`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}><Shield size={18} color={C.navy} /></div>
              <div style={{ fontFamily: F.d, fontSize: 17, fontWeight: 700, color: C.navy }}>Cómo protegemos tu información</div>
            </div>
            <p style={{ fontSize: 12.5, color: C.inkSoft, lineHeight: 1.6, margin: "14px 0" }}>Antes de continuar, esto es lo que necesitas saber sobre el tratamiento de tus datos de salud en AXON Health.</p>
            {[
              { icon: FileText, titulo: "Marco legal", texto: "Tus datos se tratan conforme a la Ley N° 21.719 de Protección de Datos Personales y la Ley N° 20.584 de Derechos y Deberes del Paciente." },
              { icon: Building2, titulo: "Interoperabilidad", texto: "AXON Health está construido sobre HL7 FHIR, alineado al Núcleo de Interoperabilidad de Datos (NID) de MINSAL." },
              { icon: Lock, titulo: "Acceso controlado", texto: "Solo personal de salud autorizado y con motivo clínico válido puede revisar tu ficha, bajo trazabilidad y ciberseguridad vigentes en Chile." },
              { icon: CheckCircle, titulo: "Tus derechos", texto: "Puedes solicitar acceso, rectificación, cancelación u oposición sobre tus datos (derechos ARCO) en cualquier momento." },
            ].map((item, i) => (
              <div key={i} style={{ display: "flex", gap: 11, marginBottom: 14 }}>
                <item.icon size={15} color={C.copper} style={{ flexShrink: 0, marginTop: 2 }} />
                <div><div style={{ fontSize: 12.5, fontWeight: 700, color: C.ink }}>{item.titulo}</div><div style={{ fontSize: 12, color: C.inkSoft, marginTop: 2, lineHeight: 1.5 }}>{item.texto}</div></div>
              </div>
            ))}
            <div style={{ display: "flex", gap: 10, marginTop: 20 }}>
              <button onClick={() => setMostrarModalConsentimiento(false)} style={{ flex: 1, padding: "10px 0", borderRadius: 9, border: `1px solid ${C.slate200}`, background: "#fff", color: C.ink, fontFamily: F.b, fontWeight: 600, fontSize: 13, cursor: "pointer" }}>Cancelar</button>
              <button className="ppa-btn" onClick={() => { setRegConsentimiento(true); setMostrarModalConsentimiento(false); }} style={{ ...S.primaryBtn, flex: 1, padding: "10px 0", fontSize: 13 }}>Acepto</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* ══════ VISTA — DASHBOARD ══════ */

function VistaDashboard({ usuario, onAbrirFuncion, onCerrarSesion }) {
  const convenioActivoNombre = usuario.convenioId ? CONVENIOS_DEMO.find(cv => cv.id === usuario.convenioId)?.nombre : null;
  return (
    <div style={S.pageCol}>
      <div style={{ width: "100%", maxWidth: 1000 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 28, flexWrap: "wrap", gap: 14 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
            <div style={{ width: 46, height: 46, borderRadius: 12, flexShrink: 0, background: CARD_VARIANTS[usuario.userTypeId]?.bg, display: "flex", alignItems: "center", justifyContent: "center" }}><BadgeCheck size={20} color="#fff" /></div>
            <div>
              <div style={{ fontFamily: F.d, fontSize: 20, fontWeight: 700, color: C.navy }}>Hola, {usuario.nombres.split(" ")[0]}</div>
              <div style={{ fontSize: 12.5, color: C.inkSoft, marginTop: 2 }}>{usuario.tierLabel}{convenioActivoNombre ? ` · ${convenioActivoNombre}` : ""} · <span style={{ fontFamily: F.m }}>{usuario.cup}</span></div>
            </div>
          </div>
          <button className="ppa-btn" onClick={onCerrarSesion} style={{ display: "flex", alignItems: "center", gap: 8, background: "#fff", border: `1px solid ${C.slate200}`, borderRadius: 9, padding: "10px 16px", color: C.ink, fontFamily: F.b, fontWeight: 600, fontSize: 13, cursor: "pointer" }}><LogOut size={14} /> Cerrar sesión</button>
        </div>

        {GRUPOS_DASHBOARD.map(grupo => (
          <div key={grupo.id} style={{ marginBottom: 28 }}>
            <div style={{ fontFamily: F.m, fontSize: 11, textTransform: "uppercase", letterSpacing: "0.08em", color: C.inkSoft, marginBottom: 12 }}>{grupo.label}</div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(180px, 1fr))", gap: 12 }}>
              {grupo.items.filter(item => !item.excluirTiers?.includes(usuario.userTypeId)).map(item => <FunctionCard key={item.id} item={item} onClick={() => onAbrirFuncion(item)} />)}
            </div>
          </div>
        ))}

        <div style={{ ...S.card, padding: "14px 16px", marginTop: 8 }}>
          <p style={{ fontSize: 12, color: C.inkSoft, margin: 0, lineHeight: 1.5 }}>Las funciones están disponibles para los tres tipos de cuenta. Tu nivel de plan afecta valores, prioridad y beneficios dentro de cada una — no el acceso a ellas.</p>
        </div>
      </div>
    </div>
  );
}

/* ══════ VISTA — AGENDA MÉDICA ══════ */

function VistaAgendaMedica({ usuario, onVolver, titulo, especialidades }) {
  const [vista, setVista] = useState("reservar");
  const [modalidad, setModalidad] = useState(null); const [especialidadId, setEspecialidadId] = useState(null); const [medicoId, setMedicoId] = useState(null);
  const [fechaSel, setFechaSel] = useState(null); const [horaSel, setHoraSel] = useState(null); const [confirmado, setConfirmado] = useState(false); const [toast, setToast] = useState("");

  const mostrarToast = (m) => { setToast(m); setTimeout(() => setToast(""), 2600); };
  const especialidad = especialidades.find(e => e.id === especialidadId);
  const medicosDisponibles = especialidadId ? medicosPorEspecialidad(especialidadId) : [];
  const medico = MEDICOS.find(m => m.id === medicoId);
  const paso = !modalidad ? 0 : !especialidadId ? 1 : !medicoId ? 2 : !(fechaSel && horaSel) ? 3 : 4;
  const reiniciar = () => { setModalidad(null); setEspecialidadId(null); setMedicoId(null); setFechaSel(null); setHoraSel(null); setConfirmado(false); };

  return (
    <div style={S.page}>
      <div style={{ width: "100%", maxWidth: 760 }}>
        <BackLink onClick={onVolver}>Volver al Dashboard</BackLink>
        <FuncionHeader titulo={titulo} usuario={usuario} tabs={[["reservar", "Reservar"], ["mis-citas", "Mis Citas"]]} activeTab={vista} onTabChange={setVista} />

        {vista === "mis-citas" ? (
          <div>{CITAS_MOCK.map(cita => {
            const esp = TODAS_ESPECIALIDADES.find(e => e.id === cita.especialidadId), med = MEDICOS.find(m => m.id === cita.medicoId);
            return (
              <div key={cita.id} style={S.row}>
                <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
                  <div style={{ width: 42, height: 42, borderRadius: 10, background: `${C.navy}12`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}><Stethoscope size={18} color={C.navy} /></div>
                  <div>
                    <div style={{ fontSize: 13.5, fontWeight: 600, color: C.ink }}>{esp?.label}</div>
                    <div style={{ fontSize: 12, color: C.inkSoft, marginTop: 2 }}>Dr(a). {med?.nombres} {med?.apellidoPaterno} · {cita.fechaLabel} · {cita.hora}</div>
                    <div style={{ display: "flex", alignItems: "center", gap: 5, marginTop: 4, fontSize: 11, color: C.inkSoft }}>{cita.modalidad === "telemedicina" ? <Video size={11} /> : <MapPin size={11} />}{cita.modalidad === "telemedicina" ? "Telemedicina" : "Presencial"}</div>
                  </div>
                </div>
                <span style={{ fontFamily: F.m, fontSize: 10.5, color: C.success, background: C.successBg, padding: "4px 10px", borderRadius: 6, textTransform: "uppercase", letterSpacing: "0.04em" }}>{cita.estado}</span>
              </div>
            );
          })}</div>
        ) : confirmado ? (
          <ConfirmacionExito titulo="Cita reservada" detalle={`${especialidad?.label} con Dr(a). ${medico?.nombres} ${medico?.apellidoPaterno} — ${fechaSel} · ${horaSel} · ${modalidad === "telemedicina" ? "Telemedicina" : "Presencial"}`} textoBoton="Reservar otra hora" onClick={reiniciar} />
        ) : (
          <div style={S.card}>
            <Stepper pasos={["Modalidad", "Especialidad", "Médico", "Horario"]} actual={paso} />
            {paso === 0 && (
              <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
                <OpcionCard onClick={() => setModalidad("presencial")} style={{ flex: "1 1 220px" }}><MapPin size={18} color={C.navy} style={{ marginBottom: 8 }} /><div style={{ fontSize: 14, fontWeight: 600, color: C.ink }}>Presencial</div><div style={{ fontSize: 11.5, color: C.inkSoft, marginTop: 2 }}>En el centro médico</div></OpcionCard>
                <OpcionCard onClick={() => setModalidad("telemedicina")} style={{ flex: "1 1 220px" }}><Video size={18} color={C.navy} style={{ marginBottom: 8 }} /><div style={{ fontSize: 14, fontWeight: 600, color: C.ink }}>Telemedicina</div><div style={{ fontSize: 11.5, color: C.inkSoft, marginTop: 2 }}>Videollamada desde donde estés</div></OpcionCard>
              </div>
            )}
            {paso === 1 && (
              <>
                <BackLink onClick={() => setModalidad(null)}>Cambiar modalidad</BackLink>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))", gap: 10, maxHeight: 380, overflowY: "auto", paddingRight: 4 }}>
                  {especialidades.map(esp => {
                    const hayMedicos = medicosPorEspecialidad(esp.id).length > 0;
                    return (
                      <button key={esp.id} disabled={!hayMedicos} onClick={() => setEspecialidadId(esp.id)} style={{ textAlign: "left", borderRadius: 9, padding: "10px 12px", border: `1px solid ${C.slate200}`, background: hayMedicos ? "#fff" : C.slate100, cursor: hayMedicos ? "pointer" : "default", opacity: hayMedicos ? 1 : 0.6, fontFamily: F.b }}>
                        <div style={{ fontSize: 12.5, fontWeight: 600, color: hayMedicos ? C.ink : C.inkSoft }}>{esp.label}</div>
                        <div style={{ fontSize: 10.5, color: hayMedicos ? C.cyanText : C.slate400, marginTop: 2 }}>{hayMedicos ? `${medicosPorEspecialidad(esp.id).length} médico(s)` : "Sin médicos disponibles"}</div>
                      </button>
                    );
                  })}
                </div>
              </>
            )}
            {paso === 2 && (
              <>
                <BackLink onClick={() => setEspecialidadId(null)}>Cambiar especialidad</BackLink>
                <div style={{ ...S.muted, marginBottom: 12 }}>{especialidad?.label}</div>
                <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                  {medicosDisponibles.map(m => (
                    <OpcionCard key={m.id} onClick={() => { setMedicoId(m.id); setFechaSel(null); setHoraSel(null); }} style={{ display: "flex", alignItems: "center", gap: 12 }}>
                      <div style={{ width: 36, height: 36, borderRadius: "50%", background: C.slate200, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}><User size={16} color={C.navy} /></div>
                      <div style={{ fontSize: 13, fontWeight: 600, color: C.ink }}>Dr(a). {m.nombres} {m.apellidoPaterno} {m.apellidoMaterno}</div>
                    </OpcionCard>
                  ))}
                </div>
              </>
            )}
            {paso === 3 && (
              <>
                <BackLink onClick={() => setMedicoId(null)}>Cambiar médico</BackLink>
                <div style={{ ...S.muted, marginBottom: 14 }}>Dr(a). {medico?.nombres} {medico?.apellidoPaterno} · {especialidad?.label}</div>
                <div style={{ marginBottom: 18 }}>
                  <SelectorFecha key={medicoId} disponibles={fechasDisponiblesMock(medicoId)} valor={fechaSel} onElegir={(d) => { setFechaSel(etiquetaFecha(d)); setHoraSel(null); }} />
                </div>
                {fechaSel && (
                  <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(84px, 1fr))", gap: 8, maxWidth: 380, margin: "0 auto" }}>
                    {BLOQUES_HORA.map(h => {
                      const ocupado = horarioOcupado(medicoId, fechaSel, h);
                      return <button key={h} disabled={ocupado} onClick={() => setHoraSel(h)} style={{ padding: "9px 0", borderRadius: 8, textAlign: "center", border: `1.5px solid ${horaSel === h ? C.navy : C.slate200}`, background: horaSel === h ? `${C.navy}08` : ocupado ? C.slate100 : "#fff", color: ocupado ? C.slate400 : C.ink, cursor: ocupado ? "not-allowed" : "pointer", fontFamily: F.m, fontSize: 12.5, fontWeight: 600, textDecoration: ocupado ? "line-through" : "none" }}>{h}</button>;
                    })}
                  </div>
                )}
              </>
            )}
            {paso === 4 && (
              <div>
                <div style={{ fontSize: 13, fontWeight: 700, color: C.ink, marginBottom: 14 }}>Confirma tu hora</div>
                <div style={{ background: C.slate100, borderRadius: 10, padding: "14px 16px", marginBottom: 18 }}>
                  <div style={{ fontSize: 13.5, fontWeight: 600, color: C.ink }}>{especialidad?.label}</div>
                  <div style={{ ...S.muted, marginTop: 3 }}>Dr(a). {medico?.nombres} {medico?.apellidoPaterno}</div>
                  <div style={{ ...S.muted, marginTop: 3 }}>{fechaSel} · {horaSel}</div>
                  <div style={{ display: "flex", alignItems: "center", gap: 5, marginTop: 6, fontSize: 11.5, color: C.cyanText }}>{modalidad === "telemedicina" ? <Video size={12} /> : <MapPin size={12} />}{modalidad === "telemedicina" ? "Telemedicina" : "Presencial"}</div>
                </div>
                <div style={{ display: "flex", gap: 10 }}>
                  <button onClick={() => setHoraSel(null)} style={{ flex: 1, padding: "11px 0", borderRadius: 9, border: `1px solid ${C.slate200}`, background: "#fff", color: C.ink, fontFamily: F.b, fontWeight: 600, fontSize: 13, cursor: "pointer" }}>Elegir otra hora</button>
                  <button className="ppa-btn" onClick={() => { setConfirmado(true); mostrarToast("Cita reservada — próxima puerta a construir."); }} style={{ ...S.primaryBtn, flex: 1, padding: "11px 0", fontSize: 13 }}>Confirmar reserva</button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
      {toast && <ToastMsg msg={toast} />}
    </div>
  );
}

/* ══════ VISTA — FARMACIA ══════ */

function VistaFarmacia({ usuario, onVolver }) {
  const [vista, setVista] = useState("recetas");
  const [recetaActiva, setRecetaActiva] = useState(null); const [modalidad, setModalidad] = useState(null); const [farmaciaId, setFarmaciaId] = useState(null);
  const [direccion, setDireccion] = useState(""); const [pedidos, setPedidos] = useState(PEDIDOS_INICIALES); const [confirmado, setConfirmado] = useState(false); const [toast, setToast] = useState("");

  const mostrarToast = (m) => { setToast(m); setTimeout(() => setToast(""), 2800); };
  const iniciarGestion = (r) => { setRecetaActiva(r); setModalidad(null); setFarmaciaId(null); setDireccion(""); setConfirmado(false); };
  const farmacia = FARMACIAS_MOCK.find(f => f.id === farmaciaId);
  const paso = !modalidad ? 0 : modalidad === "retiro" ? (!farmaciaId ? 1 : 2) : (!direccion ? 1 : 2);
  const confirmarPedido = () => {
    setPedidos(p => [{ id: `p${Date.now()}`, medicamento: recetaActiva.medicamento, modalidad, estado: modalidad === "retiro" ? "listo_retiro" : "pendiente", fecha: new Date().toLocaleDateString("es-CL", { day: "2-digit", month: "short", year: "numeric" }), direccion: modalidad === "delivery" ? direccion : null, farmaciaNombre: modalidad === "retiro" ? farmacia?.nombre : null }, ...p]);
    setConfirmado(true); mostrarToast("Pedido generado — próxima puerta a construir.");
  };

  return (
    <div style={S.page}>
      <div style={{ width: "100%", maxWidth: 760 }}>
        <BackLink onClick={onVolver}>Volver al Dashboard</BackLink>
        <FuncionHeader titulo="Farmacia" usuario={usuario} tabs={[["recetas", "Mis Recetas"], ["pedidos", "Mis Pedidos"]]} activeTab={vista} onTabChange={(v) => { setVista(v); setRecetaActiva(null); }} />

        {vista === "pedidos" ? (
          <div>{pedidos.map(p => {
            const est = ESTADOS_PEDIDO[p.estado];
            return (
              <div key={p.id} style={S.row}>
                <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
                  <div style={{ width: 42, height: 42, borderRadius: 10, background: `${C.copper}14`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}><Pill size={18} color={C.copper} /></div>
                  <div><div style={{ fontSize: 13.5, fontWeight: 600, color: C.ink }}>{p.medicamento}</div><div style={{ fontSize: 12, color: C.inkSoft, marginTop: 2 }}>{p.fecha} · {p.modalidad === "delivery" ? `Delivery a ${p.direccion}` : `Retiro en ${p.farmaciaNombre}`}</div></div>
                </div>
                <span style={{ fontFamily: F.m, fontSize: 10.5, color: est.color, background: est.bg, padding: "4px 10px", borderRadius: 6, textTransform: "uppercase", letterSpacing: "0.04em" }}>{est.label}</span>
              </div>
            );
          })}</div>
        ) : recetaActiva ? (
          confirmado ? (
            <ConfirmacionExito titulo="Pedido generado" detalle={`${recetaActiva.medicamento} — ${modalidad === "retiro" ? `Retiro en ${farmacia?.nombre}` : `Delivery a ${direccion}`}`} textoBoton="Ver mis pedidos" onClick={() => { setRecetaActiva(null); setVista("pedidos"); }} />
          ) : (
            <div style={S.card}>
              <BackLink onClick={() => setRecetaActiva(null)}>Volver a mis recetas</BackLink>
              <div style={{ fontSize: 13, fontWeight: 700, color: C.ink, marginBottom: 4 }}>{recetaActiva.medicamento}</div>
              <div style={{ ...S.muted, marginBottom: 20 }}>{recetaActiva.indicacion}</div>
              <Stepper pasos={["Modalidad", modalidad === "retiro" ? "Sucursal" : "Dirección", "Confirmar"]} actual={paso} />
              {paso === 0 && (
                <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
                  <OpcionCard onClick={() => setModalidad("retiro")} style={{ flex: "1 1 220px" }}><MapPin size={18} color={C.navy} style={{ marginBottom: 8 }} /><div style={{ fontSize: 14, fontWeight: 600, color: C.ink }}>Retiro en sucursal</div><div style={{ fontSize: 11.5, color: C.inkSoft, marginTop: 2 }}>En una farmacia asociada</div></OpcionCard>
                  <OpcionCard onClick={() => setModalidad("delivery")} style={{ flex: "1 1 220px" }}><Truck size={18} color={C.navy} style={{ marginBottom: 8 }} /><div style={{ fontSize: 14, fontWeight: 600, color: C.ink }}>Delivery a domicilio</div><div style={{ fontSize: 11.5, color: C.inkSoft, marginTop: 2 }}>Lo recibes donde estés</div></OpcionCard>
                </div>
              )}
              {paso === 1 && modalidad === "retiro" && (
                <>
                  <BackLink onClick={() => setModalidad(null)}>Cambiar modalidad</BackLink>
                  <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                    {FARMACIAS_MOCK.map(f => (
                      <OpcionCard key={f.id} onClick={() => setFarmaciaId(f.id)} style={{ display: "flex", alignItems: "center", gap: 12 }}>
                        <div style={{ width: 36, height: 36, borderRadius: "50%", background: C.slate200, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}><MapPin size={16} color={C.navy} /></div>
                        <div><div style={{ fontSize: 13, fontWeight: 600, color: C.ink }}>{f.nombre}</div><div style={{ fontSize: 11.5, color: C.inkSoft, marginTop: 1 }}>{f.direccion}</div></div>
                      </OpcionCard>
                    ))}
                  </div>
                </>
              )}
              {paso === 1 && modalidad === "delivery" && (
                <>
                  <BackLink onClick={() => setModalidad(null)}>Cambiar modalidad</BackLink>
                  <label style={{ display: "block", fontSize: 13, fontWeight: 600, marginBottom: 6, color: C.ink }}>Dirección de entrega</label>
                  <input className="ppa-input" style={S.input} value={direccion} onChange={(e) => setDireccion(e.target.value)} placeholder="Calle, número, depto/casa, comuna" />
                </>
              )}
              {paso === 2 && (
                <div>
                  <div style={{ fontSize: 13, fontWeight: 700, color: C.ink, marginBottom: 14 }}>Confirma tu pedido</div>
                  <div style={{ background: C.slate100, borderRadius: 10, padding: "14px 16px", marginBottom: 18 }}>
                    <div style={{ fontSize: 13.5, fontWeight: 600, color: C.ink }}>{recetaActiva.medicamento}</div>
                    <div style={{ ...S.muted, marginTop: 3 }}>{recetaActiva.indicacion}</div>
                    <div style={{ display: "flex", alignItems: "center", gap: 5, marginTop: 8, fontSize: 12, color: C.cyanText }}>{modalidad === "retiro" ? <MapPin size={12} /> : <Truck size={12} />}{modalidad === "retiro" ? `Retiro en ${farmacia?.nombre} · ${farmacia?.direccion}` : `Delivery a ${direccion}`}</div>
                  </div>
                  <button className="ppa-btn" onClick={confirmarPedido} style={{ ...S.primaryBtn, width: "100%", padding: "11px 0", fontSize: 13.5 }}>Confirmar pedido</button>
                </div>
              )}
            </div>
          )
        ) : (
          <div>{RECETAS_MOCK.map(r => (
            <div key={r.id} style={{ ...S.row, opacity: r.vigente ? 1 : 0.65 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
                <div style={{ width: 42, height: 42, borderRadius: 10, background: `${C.copper}14`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}><Pill size={18} color={C.copper} /></div>
                <div>
                  <div style={{ fontSize: 13.5, fontWeight: 600, color: C.ink }}>{r.medicamento}</div>
                  <div style={{ fontSize: 12, color: C.inkSoft, marginTop: 2 }}>{r.indicacion}</div>
                  <div style={{ fontSize: 11.5, color: C.inkSoft, marginTop: 3 }}>{r.medico} · {r.especialidad} · {r.fecha}</div>
                </div>
              </div>
              {r.vigente ? <button className="ppa-btn" onClick={() => iniciarGestion(r)} style={{ ...S.primaryBtn, padding: "9px 16px", fontSize: 12.5, flexShrink: 0 }}>Gestionar entrega</button>
                : <span style={{ fontFamily: F.m, fontSize: 10, color: C.inkSoft, background: C.slate100, padding: "4px 10px", borderRadius: 6, textTransform: "uppercase" }}>No vigente</span>}
            </div>
          ))}</div>
        )}
      </div>
      {toast && <ToastMsg msg={toast} />}
    </div>
  );
}

/* ══════ VISTA — ACTIVA TU LLEGADA ══════ */

function VistaActivaLlegada({ usuario, onVolver }) {
  const [activadas, setActivadas] = useState({});
  const [tab, setTab] = useState("pendientes");
  const [toast, setToast] = useState("");
  const mostrarToast = (m) => { setToast(m); setTimeout(() => setToast(""), 2600); };

  const activarLlegada = (cita) => {
    const turno = `${cita.modalidad === "telemedicina" ? "V" : "P"}-${String(Math.floor(100 + Math.random() * 800))}`;
    const hora = new Date().toLocaleTimeString("es-CL", { hour: "2-digit", minute: "2-digit" });
    setActivadas(prev => ({ ...prev, [cita.id]: { turno, hora } }));
    mostrarToast(cita.modalidad === "telemedicina" ? "Sala virtual activada." : "Llegada activada.");
  };

  const pendientes = CITAS_MOCK.filter(c => !activadas[c.id]);
  const activas = CITAS_MOCK.filter(c => activadas[c.id]);
  const lista = tab === "pendientes" ? pendientes : activas;

  return (
    <div style={S.page}>
      <div style={{ width: "100%", maxWidth: 680 }}>
        <BackLink onClick={onVolver}>Volver al Dashboard</BackLink>
        <FuncionHeader titulo="Activa tu Llegada" usuario={usuario} tabs={[["pendientes", `Por activar (${pendientes.length})`], ["activadas", `Activadas (${activas.length})`]]} activeTab={tab} onTabChange={setTab} />

        {lista.length === 0 ? (
          <div style={{ ...S.card, textAlign: "center", padding: 32 }}>
            <Clock size={22} color={C.slate400} style={{ marginBottom: 10 }} />
            <p style={{ ...S.muted, margin: 0 }}>{tab === "pendientes" ? "No tienes citas próximas por activar." : "Todavía no activas ninguna llegada."}</p>
          </div>
        ) : lista.map(cita => {
          const esp = TODAS_ESPECIALIDADES.find(e => e.id === cita.especialidadId);
          const med = MEDICOS.find(m => m.id === cita.medicoId);
          const act = activadas[cita.id];
          return (
            <div key={cita.id} style={{ ...S.card, marginBottom: 12 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 18, flexWrap: "wrap" }}>
                <div style={{ width: 46, height: 46, borderRadius: 11, background: `${C.navy}12`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                  {cita.modalidad === "telemedicina" ? <Video size={19} color={C.navy} /> : <MapPin size={19} color={C.navy} />}
                </div>
                <div style={{ flex: 1, minWidth: 180 }}>
                  <div style={{ fontSize: 14, fontWeight: 700, color: C.ink }}>{esp?.label}</div>
                  <div style={{ fontSize: 12.5, color: C.inkSoft, marginTop: 2 }}>Dr(a). {med?.nombres} {med?.apellidoPaterno} · {cita.fechaLabel} · {cita.hora}</div>
                </div>
              </div>
              {act ? (
                <div style={{ background: C.successBg, border: "1px solid #BBF7D0", borderRadius: 10, padding: "12px 14px", display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 10 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    <CheckCircle size={16} color={C.success} />
                    <span style={{ fontSize: 12.5, color: C.success, fontWeight: 600 }}>{cita.modalidad === "telemedicina" ? "Sala virtual activada" : "En sala de espera"} · {act.hora}</span>
                  </div>
                  <span style={{ fontFamily: F.m, fontSize: 13, fontWeight: 700, color: C.navy, background: "#fff", padding: "4px 12px", borderRadius: 6, border: `1px solid ${C.slate200}` }}>{act.turno}</span>
                </div>
              ) : (
                <button className="ppa-btn" onClick={() => activarLlegada(cita)} style={{ ...S.primaryBtn, width: "100%", height: 44, fontSize: 13.5 }}>
                  {cita.modalidad === "telemedicina" ? "Activar sala virtual" : "Activar mi llegada"}
                </button>
              )}
            </div>
          );
        })}
      </div>
      {toast && <ToastMsg msg={toast} Icon={CheckSquare} />}
    </div>
  );
}

/* ══════ VISTA — CERTIFICADOS ══════ */

function VistaCertificados({ usuario, onVolver }) {
  const [vista, setVista] = useState("mios");
  const [certificados, setCertificados] = useState(CERTIFICADOS_MOCK);
  const [tipo, setTipo] = useState(TIPOS_CERTIFICADO[0]);
  const [motivo, setMotivo] = useState("");
  const [toast, setToast] = useState("");
  const mostrarToast = (m) => { setToast(m); setTimeout(() => setToast(""), 2800); };

  const solicitar = () => {
    if (!motivo.trim()) { mostrarToast("Cuéntanos brevemente el motivo."); return; }
    setCertificados(c => [{ id: `cert${Date.now()}`, tipo, motivo: motivo.trim(), medico: "Por asignar", fecha: new Date().toLocaleDateString("es-CL", { day: "2-digit", month: "short", year: "numeric" }), estado: "en_preparacion" }, ...c]);
    setMotivo("");
    setVista("mios");
    mostrarToast("Solicitud enviada — te avisamos cuando esté listo.");
  };

  return (
    <div style={S.page}>
      <div style={{ width: "100%", maxWidth: 680 }}>
        <BackLink onClick={onVolver}>Volver al Dashboard</BackLink>
        <FuncionHeader titulo="Certificados" usuario={usuario} tabs={[["mios", "Mis Certificados"], ["nuevo", "Solicitar"]]} activeTab={vista} onTabChange={setVista} />

        {vista === "nuevo" ? (
          <div style={S.card}>
            <Field label="Tipo de certificado">
              <select className="ppa-input" style={{ ...S.input, cursor: "pointer" }} value={tipo} onChange={(e) => setTipo(e.target.value)}>
                {TIPOS_CERTIFICADO.map(t => <option key={t} value={t}>{t}</option>)}
              </select>
            </Field>
            <Field label="Motivo"><input className="ppa-input" style={S.input} value={motivo} onChange={(e) => setMotivo(e.target.value)} placeholder="Ej: para presentar en el trabajo" /></Field>
            <button className="ppa-btn" onClick={solicitar} style={{ ...S.primaryBtn, width: "100%", height: 46, fontSize: 14 }}>Enviar solicitud</button>
          </div>
        ) : certificados.length === 0 ? (
          <div style={{ ...S.card, textAlign: "center", padding: 32 }}>
            <FileText size={22} color={C.slate400} style={{ marginBottom: 10 }} />
            <p style={{ ...S.muted, margin: 0 }}>Todavía no tienes certificados. Solicita el primero desde la pestaña "Solicitar".</p>
          </div>
        ) : certificados.map(c => (
          <div key={c.id} style={S.row}>
            <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
              <div style={{ width: 42, height: 42, borderRadius: 10, background: `${C.navy}12`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}><FileText size={18} color={C.navy} /></div>
              <div>
                <div style={{ fontSize: 13.5, fontWeight: 600, color: C.ink }}>{c.tipo}</div>
                <div style={{ fontSize: 12, color: C.inkSoft, marginTop: 2 }}>{c.motivo}</div>
                <div style={{ fontSize: 11.5, color: C.inkSoft, marginTop: 3 }}>{c.medico} · {c.fecha}</div>
              </div>
            </div>
            {c.estado === "disponible"
              ? <button className="ppa-btn" onClick={() => mostrarToast("Descarga — próxima puerta a construir.")} style={{ ...S.primaryBtn, padding: "9px 16px", fontSize: 12.5, flexShrink: 0, display: "flex", alignItems: "center", gap: 6 }}><Download size={13} /> Descargar</button>
              : <span style={{ fontFamily: F.m, fontSize: 10, color: C.warn, background: C.warnBg, padding: "4px 10px", borderRadius: 6, textTransform: "uppercase", display: "flex", alignItems: "center", gap: 5, flexShrink: 0 }}><Clock size={10} /> En preparación</span>}
          </div>
        ))}
      </div>
      {toast && <ToastMsg msg={toast} />}
    </div>
  );
}

/* ══════ VISTA — MI PERFIL PACIENTE ══════ */

function VistaPerfilPaciente({ usuario, onVolver, onActualizarUsuario, onContacto }) {
  const convenioNombre = usuario.convenioId ? CONVENIOS_DEMO.find(cv => cv.id === usuario.convenioId)?.nombre : null;
  const [editando, setEditando] = useState(false);
  const [nombres, setNombres] = useState(usuario.nombres);
  const [apellidoPaterno, setApellidoPaterno] = useState(usuario.apellidoPaterno);
  const [apellidoMaterno, setApellidoMaterno] = useState(usuario.apellidoMaterno || "");
  const [email, setEmail] = useState(usuario.email || "");
  const [telefono, setTelefono] = useState(usuario.telefono || "");
  const [region, setRegion] = useState(usuario.region || "13");
  const [direccion, setDireccion] = useState(usuario.direccion || "");
  const [error, setError] = useState("");
  const [toast, setToast] = useState("");
  const mostrarToast = (m) => { setToast(m); setTimeout(() => setToast(""), 2600); };

  const ant = usuario.antecedentesClinicos || ANTECEDENTES_VACIOS;
  const [editandoAnt, setEditandoAnt] = useState(false);
  const [alergiaTiene, setAlergiaTiene] = useState(ant.alergias.tiene); const [alergiaDetalle, setAlergiaDetalle] = useState(ant.alergias.detalle);
  const [quirTiene, setQuirTiene] = useState(ant.antecedentesQuirurgicos.tiene); const [quirDetalle, setQuirDetalle] = useState(ant.antecedentesQuirurgicos.detalle);
  const [dispTiene, setDispTiene] = useState(ant.dispositivosMedicos.tiene); const [dispDetalle, setDispDetalle] = useState(ant.dispositivosMedicos.detalle);
  const [condicionesSel, setCondicionesSel] = useState(ant.condicionesCronicas);

  const empezarEdicionAnt = () => {
    setAlergiaTiene(ant.alergias.tiene); setAlergiaDetalle(ant.alergias.detalle);
    setQuirTiene(ant.antecedentesQuirurgicos.tiene); setQuirDetalle(ant.antecedentesQuirurgicos.detalle);
    setDispTiene(ant.dispositivosMedicos.tiene); setDispDetalle(ant.dispositivosMedicos.detalle);
    setCondicionesSel(ant.condicionesCronicas); setEditandoAnt(true);
  };
  const alternarCondicion = (c) => setCondicionesSel(prev => prev.includes(c) ? prev.filter(x => x !== c) : [...prev, c]);
  const guardarAnt = () => {
    onActualizarUsuario({ antecedentesClinicos: {
      alergias: { tiene: alergiaTiene, detalle: alergiaTiene ? alergiaDetalle.trim() : "" },
      antecedentesQuirurgicos: { tiene: quirTiene, detalle: quirTiene ? quirDetalle.trim() : "" },
      dispositivosMedicos: { tiene: dispTiene, detalle: dispTiene ? dispDetalle.trim() : "" },
      condicionesCronicas: condicionesSel,
    } });
    setEditandoAnt(false);
    mostrarToast("Antecedentes actualizados.");
  };

  const perfMov = usuario.perfilMovilidad || PERFIL_MOVILIDAD_VACIO;
  const [editandoMov, setEditandoMov] = useState(false);
  const [medioMov, setMedioMov] = useState(perfMov.medio || OPCIONES_MEDIO_TRASLADO[0]);
  const [condicionesMov, setCondicionesMov] = useState(perfMov.condiciones);
  const [detalleMov, setDetalleMov] = useState(perfMov.detalle);

  const empezarEdicionMov = () => {
    setMedioMov(perfMov.medio || OPCIONES_MEDIO_TRASLADO[0]);
    setCondicionesMov(perfMov.condiciones);
    setDetalleMov(perfMov.detalle);
    setEditandoMov(true);
  };
  const alternarCondicionMov = (c) => setCondicionesMov(prev => prev.includes(c) ? prev.filter(x => x !== c) : [...prev, c]);
  const guardarMov = () => {
    onActualizarUsuario({ perfilMovilidad: { medio: medioMov, condiciones: condicionesMov, detalle: detalleMov.trim() } });
    setEditandoMov(false);
    mostrarToast("Perfil de movilidad actualizado.");
  };

  const centros = usuario.centrosSaludFrecuentes || [];
  const [mostrarFormCentro, setMostrarFormCentro] = useState(false);
  const [centroNombre, setCentroNombre] = useState(""); const [centroTipo, setCentroTipo] = useState(TIPOS_CENTRO_SALUD[0]);
  const [centroDireccion, setCentroDireccion] = useState(""); const [centroComuna, setCentroComuna] = useState("");
  const [errorCentro, setErrorCentro] = useState("");

  const resetFormCentro = () => {
    setCentroNombre(""); setCentroTipo(TIPOS_CENTRO_SALUD[0]); setCentroDireccion(""); setCentroComuna(""); setErrorCentro(""); setMostrarFormCentro(false);
  };
  const agregarCentro = () => {
    if (!centroNombre.trim()) { setErrorCentro("Ingresa el nombre del centro de salud."); return; }
    if (!centroDireccion.trim()) { setErrorCentro("Ingresa la dirección del centro."); return; }
    const nuevo = { id: `cs${Date.now()}`, nombre: centroNombre.trim(), tipo: centroTipo, direccion: centroDireccion.trim(), comuna: centroComuna.trim() };
    onActualizarUsuario({ centrosSaludFrecuentes: [...centros, nuevo] });
    resetFormCentro();
    mostrarToast("Centro de salud agregado.");
  };
  const eliminarCentro = (id) => {
    onActualizarUsuario({ centrosSaludFrecuentes: centros.filter(c => c.id !== id) });
    mostrarToast("Centro de salud eliminado.");
  };

  const empezarEdicion = () => {
    setNombres(usuario.nombres); setApellidoPaterno(usuario.apellidoPaterno); setApellidoMaterno(usuario.apellidoMaterno || "");
    setEmail(usuario.email || ""); setTelefono(usuario.telefono || ""); setRegion(usuario.region || "13"); setDireccion(usuario.direccion || "");
    setError(""); setEditando(true);
  };

  const guardar = () => {
    if (!nombres.trim() || !apellidoPaterno.trim()) { setError("Nombres y apellido paterno no pueden quedar vacíos."); return; }
    if (email && !validarEmail(email)) { setError("Ingresa un correo electrónico válido."); return; }
    onActualizarUsuario({ nombres: nombres.trim(), apellidoPaterno: apellidoPaterno.trim(), apellidoMaterno: apellidoMaterno.trim(), email, telefono, region, direccion: direccion.trim() });
    setEditando(false);
    mostrarToast("Perfil actualizado.");
  };

  const regionLabel = REGIONES_CL.find(r => r.codigo === (usuario.region || "13"))?.nombre;
  const fechaNacLabel = usuario.fechaNacimiento ? new Date(`${usuario.fechaNacimiento}T00:00:00`).toLocaleDateString("es-CL", { day: "2-digit", month: "long", year: "numeric" }) : null;

  return (
    <div style={S.page}>
      <div style={{ width: "100%", maxWidth: 700 }}>
        <BackLink onClick={onVolver}>Volver al Dashboard</BackLink>
        <FuncionHeader titulo="Mi Perfil Paciente" usuario={usuario} tabs={[["perfil", "Mis Datos"]]} activeTab="perfil" onTabChange={() => {}} />

        <div style={{ display: "flex", gap: 22, flexWrap: "wrap", marginBottom: 20 }}>
          <CUPCard cuenta={usuario} revelarCup={true} convenioNombre={convenioNombre} />
          <div style={{ flex: "1 1 220px", display: "flex", flexDirection: "column", justifyContent: "center", gap: 14 }}>
            <DatoRow label="Tipo de cuenta" valor={usuario.tierLabel} />
            <DatoRow label="Previsión de salud" valor={usuario.prevision} />
          </div>
        </div>

        <div style={S.card}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 18 }}>
            <div style={{ fontFamily: F.d, fontSize: 15, fontWeight: 700, color: C.navy }}>Datos personales</div>
            {!editando && <button onClick={empezarEdicion} style={{ display: "flex", alignItems: "center", gap: 6, background: "none", border: "none", cursor: "pointer", color: C.cyanText, fontFamily: F.b, fontWeight: 600, fontSize: 12.5 }}><Pencil size={13} /> Editar</button>}
          </div>

          {editando ? (
            <>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                <Field label="Nombres"><input className="ppa-input" style={S.input} value={nombres} onChange={(e) => setNombres(e.target.value)} /></Field>
                <Field label="Apellido paterno"><input className="ppa-input" style={S.input} value={apellidoPaterno} onChange={(e) => setApellidoPaterno(e.target.value)} /></Field>
              </div>
              <Field label="Apellido materno"><input className="ppa-input" style={S.input} value={apellidoMaterno} onChange={(e) => setApellidoMaterno(e.target.value)} /></Field>
              <Field label="Correo electrónico"><input className="ppa-input" type="email" style={S.input} value={email} onChange={(e) => setEmail(e.target.value)} /></Field>
              <Field label="Teléfono"><input className="ppa-input" style={S.input} value={telefono} onChange={(e) => setTelefono(e.target.value)} /></Field>
              <Field label="Región">
                <select className="ppa-input" style={{ ...S.input, cursor: "pointer" }} value={region} onChange={(e) => setRegion(e.target.value)}>
                  {REGIONES_CL.map(r => <option key={r.codigo} value={r.codigo}>{r.nombre}</option>)}
                </select>
              </Field>
              <Field label="Dirección de domicilio"><input className="ppa-input" style={S.input} value={direccion} onChange={(e) => setDireccion(e.target.value)} placeholder="Calle, número, comuna" /></Field>
              {error && <div style={{ display: "flex", alignItems: "center", gap: 7, background: C.dangerBg, border: "1px solid #FCA5A5", borderRadius: 8, padding: "9px 12px", marginBottom: 16 }}><AlertCircle size={14} color={C.danger} /><span style={{ fontSize: 12.5, color: C.danger }}>{error}</span></div>}
              <div style={{ display: "flex", gap: 10 }}>
                <button onClick={() => setEditando(false)} style={{ flex: 1, padding: "11px 0", borderRadius: 9, border: `1px solid ${C.slate200}`, background: "#fff", color: C.ink, fontFamily: F.b, fontWeight: 600, fontSize: 13, cursor: "pointer" }}>Cancelar</button>
                <button className="ppa-btn" onClick={guardar} style={{ ...S.primaryBtn, flex: 1, padding: "11px 0", fontSize: 13 }}>Guardar cambios</button>
              </div>
            </>
          ) : (
            <>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 18 }}>
                <DatoRow label="RUT" valor={usuario.rut} />
                <DatoRow label="Fecha de nacimiento" valor={fechaNacLabel} />
                <DatoRow label="Correo electrónico" valor={usuario.email} />
                <DatoRow label="Teléfono" valor={usuario.telefono} />
                <DatoRow label="Región" valor={regionLabel} />
                <DatoRow label="Dirección de domicilio" valor={usuario.direccion} />
              </div>
              <p style={{ fontSize: 11, color: C.inkSoft, marginTop: 18, marginBottom: 0 }}>RUT y fecha de nacimiento no se editan aquí — si hay un error, escríbenos por {onContacto ? <EnlaceContacto onClick={() => onContacto({ motivo: "Corregir mis datos", mensaje: "Quiero corregir el siguiente dato de mi perfil: ", completar: true })}>Contacto y Ayuda</EnlaceContacto> : "Contacto y Ayuda"}.</p>
            </>
          )}
        </div>

        <div style={{ ...S.card, marginTop: 16 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 18, gap: 12, flexWrap: "wrap" }}>
            <div>
              <div style={{ fontFamily: F.d, fontSize: 15, fontWeight: 700, color: C.navy }}>Antecedentes Clínicos y de Seguridad</div>
              <div style={{ fontSize: 11.5, color: C.inkSoft, marginTop: 2 }}>Se usan para prellenar tus Consentimientos Informados — no tendrás que repetirlos cada vez.</div>
            </div>
            {!editandoAnt && <button onClick={empezarEdicionAnt} style={{ display: "flex", alignItems: "center", gap: 6, background: "none", border: "none", cursor: "pointer", color: C.cyanText, fontFamily: F.b, fontWeight: 600, fontSize: 12.5, flexShrink: 0 }}><Pencil size={13} /> Editar</button>}
          </div>

          {editandoAnt ? (
            <>
              {[
                { label: "¿Tienes alergias?", tiene: alergiaTiene, setTiene: setAlergiaTiene, detalle: alergiaDetalle, setDetalle: setAlergiaDetalle, placeholder: "Ej: penicilina, mariscos" },
                { label: "¿Tienes antecedentes quirúrgicos?", tiene: quirTiene, setTiene: setQuirTiene, detalle: quirDetalle, setDetalle: setQuirDetalle, placeholder: "Ej: apendicectomía (2015)" },
                { label: "¿Tienes dispositivos médicos o implantes?", tiene: dispTiene, setTiene: setDispTiene, detalle: dispDetalle, setDetalle: setDispDetalle, placeholder: "Ej: marcapasos, prótesis de cadera" },
              ].map((item, i) => (
                <div key={i} style={{ marginBottom: 16 }}>
                  <label style={{ display: "flex", alignItems: "center", gap: 9, cursor: "pointer", marginBottom: item.tiene ? 8 : 0 }}>
                    <input type="checkbox" checked={item.tiene} onChange={(e) => item.setTiene(e.target.checked)} style={{ cursor: "pointer" }} />
                    <span style={{ fontSize: 13, fontWeight: 600, color: C.ink }}>{item.label}</span>
                  </label>
                  {item.tiene && <input className="ppa-input" style={{ ...S.input, marginLeft: 26, width: "calc(100% - 26px)" }} value={item.detalle} onChange={(e) => item.setDetalle(e.target.value)} placeholder={item.placeholder} />}
                </div>
              ))}
              <div style={{ marginBottom: 20 }}>
                <label style={{ display: "block", fontSize: 13, fontWeight: 600, marginBottom: 8, color: C.ink }}>Condiciones crónicas relevantes</label>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                  {CONDICIONES_CRONICAS_OPCIONES.map(c => (
                    <button key={c} type="button" onClick={() => alternarCondicion(c)} style={{ padding: "7px 13px", borderRadius: 20, border: `1.5px solid ${condicionesSel.includes(c) ? C.navy : C.slate200}`, background: condicionesSel.includes(c) ? `${C.navy}0D` : "#fff", color: condicionesSel.includes(c) ? C.navy : C.inkSoft, fontFamily: F.b, fontWeight: 600, fontSize: 12, cursor: "pointer" }}>{c}</button>
                  ))}
                </div>
              </div>
              <div style={{ display: "flex", gap: 10 }}>
                <button onClick={() => setEditandoAnt(false)} style={{ flex: 1, padding: "11px 0", borderRadius: 9, border: `1px solid ${C.slate200}`, background: "#fff", color: C.ink, fontFamily: F.b, fontWeight: 600, fontSize: 13, cursor: "pointer" }}>Cancelar</button>
                <button className="ppa-btn" onClick={guardarAnt} style={{ ...S.primaryBtn, flex: 1, padding: "11px 0", fontSize: 13 }}>Guardar antecedentes</button>
              </div>
            </>
          ) : (
            <div style={{ display: "flex", flexDirection: "column", gap: 9 }}>
              {[
                { label: "Alergias", data: ant.alergias },
                { label: "Antecedentes quirúrgicos", data: ant.antecedentesQuirurgicos },
                { label: "Dispositivos médicos o implantes", data: ant.dispositivosMedicos },
              ].map(item => (
                <div key={item.label} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", background: C.slate100, borderRadius: 9, padding: "10px 14px", gap: 10 }}>
                  <div>
                    <div style={{ fontSize: 12.5, fontWeight: 600, color: C.ink }}>{item.label}</div>
                    {item.data.tiene && <div style={{ fontSize: 11.5, color: C.inkSoft, marginTop: 2 }}>{item.data.detalle || "Sin detalle registrado"}</div>}
                  </div>
                  <span style={{ fontFamily: F.m, fontSize: 10, textTransform: "uppercase", padding: "3px 9px", borderRadius: 5, flexShrink: 0, color: item.data.tiene ? C.warn : C.success, background: item.data.tiene ? C.warnBg : C.successBg }}>{item.data.tiene ? "Sí" : "No"}</span>
                </div>
              ))}
              {ant.condicionesCronicas.length > 0 && (
                <div style={{ background: C.slate100, borderRadius: 9, padding: "10px 14px" }}>
                  <div style={{ fontSize: 12.5, fontWeight: 600, color: C.ink }}>Condiciones crónicas</div>
                  <div style={{ fontSize: 11.5, color: C.inkSoft, marginTop: 2 }}>{ant.condicionesCronicas.join(", ")}</div>
                </div>
              )}
            </div>
          )}
        </div>

        <div style={{ ...S.card, marginTop: 16 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 18, gap: 12, flexWrap: "wrap" }}>
            <div>
              <div style={{ fontFamily: F.d, fontSize: 15, fontWeight: 700, color: C.navy }}>Perfil de Movilidad y Transporte</div>
              <div style={{ fontSize: 11.5, color: C.inkSoft, marginTop: 2 }}>Se usa para preparar el vehículo adecuado cuando solicitas un traslado — no tendrás que volver a contarnos cómo te movilizas.</div>
            </div>
            {!editandoMov && <button onClick={empezarEdicionMov} style={{ display: "flex", alignItems: "center", gap: 6, background: "none", border: "none", cursor: "pointer", color: C.cyanText, fontFamily: F.b, fontWeight: 600, fontSize: 12.5, flexShrink: 0 }}><Pencil size={13} /> {perfMov.medio ? "Editar" : "Agregar"}</button>}
          </div>

          {editandoMov ? (
            <>
              <div style={{ marginBottom: 16 }}>
                <label style={{ display: "block", fontSize: 13, fontWeight: 600, marginBottom: 8, color: C.ink }}>¿Cómo te trasladas actualmente?</label>
                <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                  {OPCIONES_MEDIO_TRASLADO.map(op => (
                    <OpcionCard key={op} activo={medioMov === op} onClick={() => setMedioMov(op)}><div style={{ fontSize: 13, color: C.ink }}>{op}</div></OpcionCard>
                  ))}
                </div>
              </div>
              <div style={{ marginBottom: 16 }}>
                <label style={{ display: "block", fontSize: 13, fontWeight: 600, marginBottom: 8, color: C.ink }}>¿Alguna condición especial que debamos considerar?</label>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                  {CONDICIONES_TRASLADO_OPCIONES.map(c => (
                    <button key={c} type="button" onClick={() => alternarCondicionMov(c)} style={{ padding: "7px 13px", borderRadius: 20, border: `1.5px solid ${condicionesMov.includes(c) ? C.navy : C.slate200}`, background: condicionesMov.includes(c) ? `${C.navy}0D` : "#fff", color: condicionesMov.includes(c) ? C.navy : C.inkSoft, fontFamily: F.b, fontWeight: 600, fontSize: 12, cursor: "pointer" }}>{c}</button>
                  ))}
                </div>
              </div>
              <Field label="Detalle adicional (opcional)"><input className="ppa-input" style={S.input} value={detalleMov} onChange={(e) => setDetalleMov(e.target.value)} placeholder="Ej: usa bastón además de la silla" /></Field>
              <div style={{ display: "flex", gap: 10 }}>
                <button onClick={() => setEditandoMov(false)} style={{ flex: 1, padding: "11px 0", borderRadius: 9, border: `1px solid ${C.slate200}`, background: "#fff", color: C.ink, fontFamily: F.b, fontWeight: 600, fontSize: 13, cursor: "pointer" }}>Cancelar</button>
                <button className="ppa-btn" onClick={guardarMov} style={{ ...S.primaryBtn, flex: 1, padding: "11px 0", fontSize: 13 }}>Guardar perfil de movilidad</button>
              </div>
            </>
          ) : perfMov.medio ? (
            <div style={{ display: "flex", flexDirection: "column", gap: 9 }}>
              <div style={{ background: C.slate100, borderRadius: 9, padding: "10px 14px" }}>
                <div style={{ fontSize: 12.5, fontWeight: 600, color: C.ink }}>Cómo te trasladas</div>
                <div style={{ fontSize: 11.5, color: C.inkSoft, marginTop: 2 }}>{perfMov.medio}</div>
              </div>
              {perfMov.condiciones.length > 0 && (
                <div style={{ background: C.slate100, borderRadius: 9, padding: "10px 14px" }}>
                  <div style={{ fontSize: 12.5, fontWeight: 600, color: C.ink }}>Condiciones especiales</div>
                  <div style={{ fontSize: 11.5, color: C.inkSoft, marginTop: 2 }}>{perfMov.condiciones.join(", ")}</div>
                </div>
              )}
              {perfMov.detalle && (
                <div style={{ background: C.slate100, borderRadius: 9, padding: "10px 14px" }}>
                  <div style={{ fontSize: 12.5, fontWeight: 600, color: C.ink }}>Detalle adicional</div>
                  <div style={{ fontSize: 11.5, color: C.inkSoft, marginTop: 2 }}>{perfMov.detalle}</div>
                </div>
              )}
            </div>
          ) : (
            <div style={{ textAlign: "center", padding: "16px 6px" }}>
              <p style={{ ...S.muted, margin: "0 0 4px" }}>Aún no registras tu perfil de movilidad.</p>
              <p style={{ ...S.muted, margin: 0 }}>Lo usaremos para preparar el vehículo adecuado si alguna vez solicitas un traslado.</p>
            </div>
          )}
        </div>

        <div style={{ ...S.card, marginTop: 16 }}>
          <div style={{ marginBottom: 18 }}>
            <div style={{ fontFamily: F.d, fontSize: 15, fontWeight: 700, color: C.navy }}>Centros de Salud Frecuentes</div>
            <div style={{ fontSize: 11.5, color: C.inkSoft, marginTop: 2 }}>Así podrás elegirlos rápido al pedir un traslado, en vez de escribir la dirección cada vez.</div>
          </div>

          {!mostrarFormCentro && (
            centros.length === 0 ? (
              <div style={{ textAlign: "center", padding: "16px 6px" }}>
                <p style={{ ...S.muted, margin: "0 0 4px" }}>Aún no registras centros de salud.</p>
                <p style={{ ...S.muted, margin: 0 }}>Agrega los hospitales, clínicas o centros médicos que visitas seguido.</p>
              </div>
            ) : (
              <div style={{ display: "flex", flexDirection: "column", gap: 9, marginBottom: 16 }}>
                {centros.map(c => (
                  <div key={c.id} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", background: C.slate100, borderRadius: 9, padding: "10px 14px", gap: 10 }}>
                    <div>
                      <div style={{ fontSize: 12.5, fontWeight: 600, color: C.ink }}>{c.nombre}</div>
                      <div style={{ fontSize: 11.5, color: C.inkSoft, marginTop: 2 }}>{c.tipo}{c.comuna ? ` · ${c.comuna}` : ""} · {c.direccion}</div>
                    </div>
                    <button onClick={() => eliminarCentro(c.id)} style={{ background: "none", border: "none", cursor: "pointer", color: C.danger, padding: 6, display: "flex", flexShrink: 0 }}><Trash2 size={15} /></button>
                  </div>
                ))}
              </div>
            )
          )}

          {mostrarFormCentro ? (
            <div>
              <Field label="Nombre del centro"><input className="ppa-input" style={S.input} value={centroNombre} onChange={(e) => setCentroNombre(e.target.value)} placeholder="Ej: Hospital Regional, Clínica Alemana" /></Field>
              <Field label="Tipo">
                <select className="ppa-input" style={{ ...S.input, cursor: "pointer" }} value={centroTipo} onChange={(e) => setCentroTipo(e.target.value)}>
                  {TIPOS_CENTRO_SALUD.map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              </Field>
              <Field label="Dirección"><input className="ppa-input" style={S.input} value={centroDireccion} onChange={(e) => setCentroDireccion(e.target.value)} placeholder="Calle, número" /></Field>
              <Field label="Comuna (opcional)"><input className="ppa-input" style={S.input} value={centroComuna} onChange={(e) => setCentroComuna(e.target.value)} placeholder="Ej: Providencia" /></Field>
              {errorCentro && <div style={{ display: "flex", alignItems: "center", gap: 7, background: C.dangerBg, border: "1px solid #FCA5A5", borderRadius: 8, padding: "9px 12px", marginBottom: 16 }}><AlertCircle size={14} color={C.danger} /><span style={{ fontSize: 12.5, color: C.danger }}>{errorCentro}</span></div>}
              <div style={{ display: "flex", gap: 10 }}>
                <button onClick={resetFormCentro} style={{ flex: 1, padding: "11px 0", borderRadius: 9, border: `1px solid ${C.slate200}`, background: "#fff", color: C.ink, fontFamily: F.b, fontWeight: 600, fontSize: 13, cursor: "pointer" }}>Cancelar</button>
                <button className="ppa-btn" onClick={agregarCentro} style={{ ...S.primaryBtn, flex: 1, padding: "11px 0", fontSize: 13 }}>Guardar centro</button>
              </div>
            </div>
          ) : (
            <button className="ppa-btn" onClick={() => setMostrarFormCentro(true)} style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 8, width: "100%", height: 44, borderRadius: 9, border: `1.5px dashed ${C.slate400}`, background: "transparent", color: C.navy, fontFamily: F.b, fontWeight: 600, fontSize: 13, cursor: "pointer" }}><Plus size={14} /> Agregar centro de salud</button>
          )}
        </div>

        <div style={{ ...S.card, marginTop: 16, display: "flex", gap: 12, alignItems: "flex-start" }}>
          <Shield size={18} color={C.copper} style={{ flexShrink: 0, marginTop: 2 }} />
          <div>
            <div style={{ fontSize: 12.5, fontWeight: 700, color: C.ink }}>Tus derechos sobre tus datos</div>
            <div style={{ fontSize: 12, color: C.inkSoft, marginTop: 3, lineHeight: 1.5 }}>Puedes solicitar acceso, rectificación, cancelación u oposición sobre tus datos de salud (derechos ARCO) cuando quieras, conforme a la Ley N° 21.719.</div>
          </div>
        </div>
      </div>
      {toast && <ToastMsg msg={toast} />}
    </div>
  );
}

/* ══════ VISTA — CONTACTOS DE EMERGENCIA ══════ */

function VistaContactosEmergencia({ usuario, onVolver, onActualizarUsuario }) {
  const contactos = usuario.contactosEmergencia || [];
  const [mostrarForm, setMostrarForm] = useState(false);
  const [nombre, setNombre] = useState(""); const [parentesco, setParentesco] = useState(PARENTESCOS[0]);
  const [paisTel, setPaisTel] = useState(PAISES_TEL[0]); const [telefono, setTelefono] = useState("");
  const [mostrarPaises, setMostrarPaises] = useState(false);
  const [error, setError] = useState(""); const [toast, setToast] = useState("");
  const mostrarToast = (m) => { setToast(m); setTimeout(() => setToast(""), 2600); };

  const resetForm = () => { setNombre(""); setParentesco(PARENTESCOS[0]); setPaisTel(PAISES_TEL[0]); setTelefono(""); setMostrarPaises(false); setError(""); setMostrarForm(false); };

  const agregar = () => {
    if (!nombre.trim()) { setError("Ingresa el nombre del contacto."); return; }
    if (telefono.replace(/\D/g, "").length < 7) { setError("Ingresa un número de teléfono válido."); return; }
    const nuevo = { id: `ce${Date.now()}`, nombre: nombre.trim(), parentesco, telefono: `${paisTel.indicativo} ${telefono}` };
    onActualizarUsuario({ contactosEmergencia: [...contactos, nuevo] });
    resetForm();
    mostrarToast("Contacto agregado.");
  };

  const eliminar = (id) => { onActualizarUsuario({ contactosEmergencia: contactos.filter(c => c.id !== id) }); mostrarToast("Contacto eliminado."); };

  return (
    <div style={S.page}>
      <div style={{ width: "100%", maxWidth: 640 }}>
        <BackLink onClick={onVolver}>Volver al Dashboard</BackLink>
        <FuncionHeader titulo="Contactos de Emergencia" usuario={usuario} tabs={[["lista", "Mis Contactos"]]} activeTab="lista" onTabChange={() => {}} />

        {!mostrarForm && (
          contactos.length === 0 ? (
            <div style={{ ...S.card, textAlign: "center", padding: 32, marginBottom: 16 }}>
              <Phone size={22} color={C.slate400} style={{ marginBottom: 10 }} />
              <p style={{ ...S.muted, margin: "0 0 4px" }}>Todavía no tienes contactos de emergencia.</p>
              <p style={{ ...S.muted, margin: 0 }}>Agrega al menos uno para que podamos ubicar a alguien de confianza si lo necesitas.</p>
            </div>
          ) : contactos.map(c => (
            <div key={c.id} style={S.row}>
              <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
                <div style={{ width: 42, height: 42, borderRadius: "50%", background: C.slate200, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}><User size={18} color={C.navy} /></div>
                <div>
                  <div style={{ fontSize: 13.5, fontWeight: 600, color: C.ink }}>{c.nombre}</div>
                  <div style={{ fontSize: 12, color: C.inkSoft, marginTop: 2 }}>{c.parentesco} · <span style={{ fontFamily: F.m }}>{c.telefono}</span></div>
                </div>
              </div>
              <button onClick={() => eliminar(c.id)} style={{ background: "none", border: "none", cursor: "pointer", color: C.danger, padding: 6, display: "flex", flexShrink: 0 }}><Trash2 size={16} /></button>
            </div>
          ))
        )}

        {mostrarForm ? (
          <div style={S.card}>
            <BackLink onClick={resetForm}>Cancelar</BackLink>
            <Field label="Nombre completo"><input className="ppa-input" style={S.input} value={nombre} onChange={(e) => setNombre(e.target.value)} placeholder="Nombre y apellidos" /></Field>
            <Field label="Parentesco">
              <select className="ppa-input" style={{ ...S.input, cursor: "pointer" }} value={parentesco} onChange={(e) => setParentesco(e.target.value)}>
                {PARENTESCOS.map(p => <option key={p} value={p}>{p}</option>)}
              </select>
            </Field>
            <Field label="Teléfono">
              <div style={{ display: "flex", gap: 8, position: "relative" }}>
                <button type="button" onClick={() => setMostrarPaises(p => !p)} style={{ display: "flex", alignItems: "center", gap: 6, height: 46, padding: "0 10px", border: `1px solid ${C.slate200}`, borderRadius: 9, background: C.slate100, cursor: "pointer", flexShrink: 0 }}>
                  <span style={{ fontSize: 17, lineHeight: 1 }}>{paisTel.bandera}</span><span style={{ fontFamily: F.m, fontSize: 12.5, color: C.ink }}>{paisTel.indicativo}</span><ChevronDown size={13} color={C.inkSoft} />
                </button>
                <input className="ppa-input" style={{ ...S.input, flex: 1 }} value={telefono} onChange={(e) => setTelefono(e.target.value.replace(/[^\d\s]/g, ""))} placeholder="9 1234 5678" />
                {mostrarPaises && (
                  <div style={{ position: "absolute", top: 52, left: 0, width: 250, maxHeight: 224, overflowY: "auto", background: "#fff", border: `1px solid ${C.slate200}`, borderRadius: 10, boxShadow: "0 14px 34px rgba(0,0,0,0.16)", zIndex: 60 }}>
                    {PAISES_TEL.map(p => (
                      <button key={p.codigo} type="button" onClick={() => { setPaisTel(p); setMostrarPaises(false); }} style={{ display: "flex", alignItems: "center", gap: 9, width: "100%", padding: "8px 12px", background: p.codigo === paisTel.codigo ? C.slate100 : "#fff", border: "none", cursor: "pointer", textAlign: "left" }}>
                        <span style={{ fontSize: 16, lineHeight: 1 }}>{p.bandera}</span><span style={{ fontSize: 12.5, color: C.ink, flex: 1 }}>{p.nombre}</span><span style={{ fontFamily: F.m, fontSize: 11.5, color: C.inkSoft }}>{p.indicativo}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </Field>
            {error && <div style={{ display: "flex", alignItems: "center", gap: 7, background: C.dangerBg, border: "1px solid #FCA5A5", borderRadius: 8, padding: "9px 12px", marginBottom: 16 }}><AlertCircle size={14} color={C.danger} /><span style={{ fontSize: 12.5, color: C.danger }}>{error}</span></div>}
            <button className="ppa-btn" onClick={agregar} style={{ ...S.primaryBtn, width: "100%", height: 46, fontSize: 14 }}>Guardar contacto</button>
          </div>
        ) : (
          <button className="ppa-btn" onClick={() => setMostrarForm(true)} style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 8, width: "100%", height: 46, borderRadius: 9, border: `1.5px dashed ${C.slate400}`, background: "transparent", color: C.navy, fontFamily: F.b, fontWeight: 600, fontSize: 13.5, cursor: "pointer" }}><Plus size={15} /> Agregar contacto</button>
        )}
      </div>
      {toast && <ToastMsg msg={toast} />}
    </div>
  );
}

/* ══════ VISTA — CONSENTIMIENTOS INFORMADOS ══════ */
/* Alcance de Portal Paciente aquí: wizard paciente-facing hasta firmado/enviado.
   El wrapping DICOM del PDF firmado y los motores clínicos transversales NO son de este módulo
   (sección 6.3 del dossier de sincronización) — el "Motor de documentos y certificados" es
   quien recibe el consentimiento firmado y decide el resto. */

function VistaConsentimientos({ usuario, onVolver, onActualizarUsuario }) {
  const [consentimientos, setConsentimientos] = useState(CONSENTIMIENTOS_MOCK);
  const [activo, setActivo] = useState(null);
  const [paso, setPaso] = useState(0);
  const ant = usuario.antecedentesClinicos || ANTECEDENTES_VACIOS;
  const [mostrarNuevo, setMostrarNuevo] = useState(false);
  const [tipoNuevo, setTipoNuevo] = useState("alergias");
  const [detalleNuevo, setDetalleNuevo] = useState("");
  const [confirmoVigente, setConfirmoVigente] = useState(false);
  const [autorizo, setAutorizo] = useState(false);
  const [hayFirma, setHayFirma] = useState(false);
  const [canal, setCanal] = useState(null);
  const [otpEnviado, setOtpEnviado] = useState(false);
  const [otpVerificado, setOtpVerificado] = useState(false);
  const [otp, setOtp] = useState(""); const [otpError, setOtpError] = useState("");
  const [firmado, setFirmado] = useState(false);
  const [toast, setToast] = useState("");
  const mostrarToast = (m) => { setToast(m); setTimeout(() => setToast(""), 2800); };

  const iniciarFirma = (c) => {
    setActivo(c); setPaso(0); setMostrarNuevo(false); setTipoNuevo("alergias"); setDetalleNuevo(""); setConfirmoVigente(false);
    setAutorizo(false); setHayFirma(false); setCanal(null);
    setOtpEnviado(false); setOtpVerificado(false); setOtp(""); setOtpError(""); setFirmado(false);
  };

  const guardarNuevoAntecedente = () => {
    if (!detalleNuevo.trim()) return;
    const previo = ant[tipoNuevo];
    const detalleCombinado = previo.tiene && previo.detalle ? `${previo.detalle}; ${detalleNuevo.trim()}` : detalleNuevo.trim();
    onActualizarUsuario({ antecedentesClinicos: { ...ant, [tipoNuevo]: { tiene: true, detalle: detalleCombinado } } });
    setDetalleNuevo(""); setMostrarNuevo(false);
    mostrarToast("Agregado a tu ficha.");
  };

  const enviarOtp = () => { setOtpEnviado(true); mostrarToast(`Código enviado por ${canal === "sms" ? "mensaje de texto" : "WhatsApp"} a ${usuario.telefono || "tu teléfono registrado"}.`); };
  const verificarOtp = () => {
    if (otp.replace(/\D/g, "").length !== 6) { setOtpError("Ingresa el código de 6 dígitos."); return; }
    setOtpVerificado(true);
  };
  const confirmarFirma = () => {
    const codigo = `FES-${String(Math.floor(1000 + Math.random() * 9000))}-${checksumMock(activo.id + otp)}`;
    const firmadoEn = new Date().toLocaleString("es-CL", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" });
    setConsentimientos(cs => cs.map(c => c.id === activo.id ? { ...c, estado: "firmado", firmadoEn, codigoFirma: codigo } : c));
    setActivo(a => ({ ...a, estado: "firmado", firmadoEn, codigoFirma: codigo }));
    setFirmado(true);
    mostrarToast("Consentimiento enviado.");
  };

  if (activo) {
    return (
      <div style={S.page}>
        <div style={{ width: "100%", maxWidth: 640 }}>
          <BackLink onClick={() => (firmado ? onVolver() : setActivo(null))}>{firmado ? "Volver al Dashboard" : "Volver a mis consentimientos"}</BackLink>
          {firmado ? (
            <ConfirmacionExito titulo="Consentimiento enviado" detalle={`${activo.titulo} — firmado el ${activo.firmadoEn}. Código de firma: ${activo.codigoFirma}.`} textoBoton="Volver al Dashboard" onClick={onVolver} />
          ) : (
            <div style={S.card}>
              <Stepper pasos={["Leer", "Antecedentes", "Autorizar", "Firma", "Verificar"]} actual={paso} />
              <div style={{ fontFamily: F.d, fontSize: 16, fontWeight: 700, color: C.navy, marginBottom: 4 }}>{activo.titulo}</div>
              <div style={{ ...S.muted, marginBottom: 18 }}>{activo.equipo}{activo.fechaProcedimiento ? ` · ${activo.fechaProcedimiento}` : ""}</div>

              {paso === 0 && (
                <>
                  <div style={{ maxHeight: 340, overflowY: "auto", paddingRight: 6, marginBottom: 18 }}>
                    {activo.cuerpo.map((sec, i) => (
                      <div key={i} style={{ marginBottom: 14 }}>
                        <div style={{ fontSize: 12.5, fontWeight: 700, color: C.ink, marginBottom: 4 }}>{sec.h}</div>
                        <div style={{ fontSize: 12.5, color: C.inkSoft, lineHeight: 1.6 }}>{sec.p}</div>
                      </div>
                    ))}
                  </div>
                  <button className="ppa-btn" onClick={() => setPaso(1)} style={{ ...S.primaryBtn, width: "100%", height: 46, fontSize: 14 }}>Ya leí el documento</button>
                </>
              )}

              {paso === 1 && (
                <>
                  <p style={{ fontSize: 12.5, color: C.inkSoft, marginBottom: 16, lineHeight: 1.5 }}>Esto es lo que ya tenemos en tu perfil — no hace falta que lo vuelvas a escribir. Revísalo y avísanos si algo cambió.</p>
                  <div style={{ display: "flex", flexDirection: "column", gap: 9, marginBottom: 16 }}>
                    {[
                      { label: "Alergias", data: ant.alergias },
                      { label: "Antecedentes quirúrgicos", data: ant.antecedentesQuirurgicos },
                      { label: "Dispositivos médicos o implantes", data: ant.dispositivosMedicos },
                    ].map(item => (
                      <div key={item.label} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", background: C.slate100, borderRadius: 9, padding: "10px 14px", gap: 10 }}>
                        <div>
                          <div style={{ fontSize: 12.5, fontWeight: 600, color: C.ink }}>{item.label}</div>
                          {item.data.tiene && <div style={{ fontSize: 11.5, color: C.inkSoft, marginTop: 2 }}>{item.data.detalle || "Sin detalle registrado"}</div>}
                        </div>
                        <span style={{ fontFamily: F.m, fontSize: 10, textTransform: "uppercase", padding: "3px 9px", borderRadius: 5, flexShrink: 0, color: item.data.tiene ? C.warn : C.success, background: item.data.tiene ? C.warnBg : C.successBg }}>{item.data.tiene ? "Sí" : "No"}</span>
                      </div>
                    ))}
                    {ant.condicionesCronicas.length > 0 && (
                      <div style={{ background: C.slate100, borderRadius: 9, padding: "10px 14px" }}>
                        <div style={{ fontSize: 12.5, fontWeight: 600, color: C.ink }}>Condiciones crónicas</div>
                        <div style={{ fontSize: 11.5, color: C.inkSoft, marginTop: 2 }}>{ant.condicionesCronicas.join(", ")}</div>
                      </div>
                    )}
                  </div>

                  {!mostrarNuevo ? (
                    <button type="button" onClick={() => setMostrarNuevo(true)} style={{ display: "flex", alignItems: "center", gap: 6, background: "none", border: "none", cursor: "pointer", color: C.cyanText, fontFamily: F.b, fontWeight: 600, fontSize: 12.5, marginBottom: 20, padding: 0 }}><Plus size={13} /> Algo cambió desde hoy</button>
                  ) : (
                    <div style={{ background: C.slate100, borderRadius: 10, padding: "14px 16px", marginBottom: 20 }}>
                      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 10 }}>
                        <select className="ppa-input" style={{ ...S.input, cursor: "pointer", height: 42 }} value={tipoNuevo} onChange={(e) => setTipoNuevo(e.target.value)}>
                          <option value="alergias">Nueva alergia</option>
                          <option value="antecedentesQuirurgicos">Nuevo antecedente quirúrgico</option>
                          <option value="dispositivosMedicos">Nuevo dispositivo o implante</option>
                        </select>
                        <input className="ppa-input" style={{ ...S.input, height: 42 }} value={detalleNuevo} onChange={(e) => setDetalleNuevo(e.target.value)} placeholder="Cuéntanos brevemente" />
                      </div>
                      <button type="button" onClick={guardarNuevoAntecedente} style={{ fontSize: 12, fontWeight: 600, color: C.navy, background: "#fff", border: `1px solid ${C.slate200}`, borderRadius: 7, padding: "7px 14px", cursor: "pointer" }}>Agregar a mi ficha</button>
                    </div>
                  )}

                  <label style={{ display: "flex", alignItems: "flex-start", gap: 10, cursor: "pointer", marginBottom: 20 }}>
                    <input type="checkbox" checked={confirmoVigente} onChange={(e) => setConfirmoVigente(e.target.checked)} style={{ marginTop: 3, flexShrink: 0, cursor: "pointer" }} />
                    <span style={{ fontSize: 13, color: C.ink, lineHeight: 1.5 }}>Confirmo que esta información está al día y es correcta.</span>
                  </label>

                  <BackLink onClick={() => setPaso(0)}>Volver a leer</BackLink>
                  <button className="ppa-btn" disabled={!confirmoVigente} onClick={() => setPaso(2)} style={{ ...S.primaryBtn, width: "100%", height: 46, fontSize: 14, opacity: confirmoVigente ? 1 : 0.5, cursor: confirmoVigente ? "pointer" : "default" }}>Continuar</button>
                </>
              )}

              {paso === 2 && (
                <>
                  <BackLink onClick={() => setPaso(1)}>Volver</BackLink>
                  <div style={{ background: C.slate100, borderRadius: 10, padding: "14px 16px", marginBottom: 20 }}>
                    <label style={{ display: "flex", alignItems: "flex-start", gap: 10, cursor: "pointer" }}>
                      <input type="checkbox" checked={autorizo} onChange={(e) => setAutorizo(e.target.checked)} style={{ marginTop: 3, flexShrink: 0, cursor: "pointer" }} />
                      <span style={{ fontSize: 13, color: C.ink, lineHeight: 1.5, fontWeight: 600 }}>Autorizo la realización de {activo.procedimiento}, conforme a lo descrito en este documento.</span>
                    </label>
                  </div>
                  <button className="ppa-btn" disabled={!autorizo} onClick={() => setPaso(3)} style={{ ...S.primaryBtn, width: "100%", height: 46, fontSize: 14, opacity: autorizo ? 1 : 0.5, cursor: autorizo ? "pointer" : "default" }}>Continuar a la firma</button>
                </>
              )}

              {paso === 3 && (
                <>
                  <BackLink onClick={() => setPaso(2)}>Volver</BackLink>
                  <p style={{ fontSize: 12.5, color: C.inkSoft, marginBottom: 14, lineHeight: 1.5 }}>Firma dentro del recuadro para autorizar {activo.procedimiento}.</p>
                  <FirmaCanvas onCambio={setHayFirma} />
                  <button className="ppa-btn" disabled={!hayFirma} onClick={() => setPaso(4)} style={{ ...S.primaryBtn, width: "100%", height: 46, fontSize: 14, marginTop: 18, opacity: hayFirma ? 1 : 0.5, cursor: hayFirma ? "pointer" : "default" }}>Continuar</button>
                </>
              )}

              {paso === 4 && (
                <>
                  <BackLink onClick={() => setPaso(3)}>Volver a firmar</BackLink>
                  {!canal ? (
                    <>
                      <p style={{ fontSize: 13, color: C.inkSoft, lineHeight: 1.6, marginBottom: 16 }}>Para verificar tu identidad, elige cómo quieres recibir el código.</p>
                      <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
                        <OpcionCard onClick={() => setCanal("sms")} style={{ flex: "1 1 200px" }}><MessageSquare size={18} color={C.navy} style={{ marginBottom: 8 }} /><div style={{ fontSize: 14, fontWeight: 600, color: C.ink }}>Mensaje de texto</div><div style={{ fontSize: 11.5, color: C.inkSoft, marginTop: 2 }}>SMS a {usuario.telefono || "tu teléfono"}</div></OpcionCard>
                        <OpcionCard onClick={() => setCanal("whatsapp")} style={{ flex: "1 1 200px" }}><Phone size={18} color={C.navy} style={{ marginBottom: 8 }} /><div style={{ fontSize: 14, fontWeight: 600, color: C.ink }}>WhatsApp</div><div style={{ fontSize: 11.5, color: C.inkSoft, marginTop: 2 }}>Al mismo número registrado</div></OpcionCard>
                      </div>
                    </>
                  ) : !otpEnviado ? (
                    <>
                      <p style={{ fontSize: 13, color: C.inkSoft, lineHeight: 1.6, marginBottom: 18 }}>Enviaremos un código por {canal === "sms" ? "mensaje de texto" : "WhatsApp"} a <b style={{ color: C.ink }}>{usuario.telefono || "tu teléfono registrado"}</b>.</p>
                      <BackLink onClick={() => setCanal(null)}>Cambiar canal</BackLink>
                      <button className="ppa-btn" onClick={enviarOtp} style={{ ...S.primaryBtn, width: "100%", height: 46, fontSize: 14 }}>Enviar código</button>
                    </>
                  ) : !otpVerificado ? (
                    <>
                      <Field label="Código de verificación" error={otpError}>
                        <input className="ppa-input" style={{ ...S.input, fontFamily: F.m, letterSpacing: "0.3em", textAlign: "center" }} value={otp} onChange={(e) => { setOtp(e.target.value.replace(/\D/g, "").slice(0, 6)); setOtpError(""); }} placeholder="000000" maxLength={6} />
                      </Field>
                      <p style={{ fontSize: 11.5, color: C.inkSoft, margin: "0 0 16px" }}>¿No llegó? <span className="ppa-link" onClick={enviarOtp} style={{ color: C.cyanText, fontWeight: 600 }}>Reenviar código</span></p>
                      <button className="ppa-btn" onClick={verificarOtp} style={{ ...S.primaryBtn, width: "100%", height: 46, fontSize: 14 }}>Verificar código</button>
                    </>
                  ) : (
                    <div>
                      <div style={{ background: C.slate100, borderRadius: 10, padding: "14px 16px", marginBottom: 18 }}>
                        <div style={{ fontSize: 13.5, fontWeight: 600, color: C.ink }}>{activo.titulo}</div>
                        <div style={{ ...S.muted, marginTop: 3 }}>{activo.equipo}{activo.fechaProcedimiento ? ` · ${activo.fechaProcedimiento}` : ""}</div>
                        <div style={{ display: "flex", alignItems: "center", gap: 5, marginTop: 8, fontSize: 11.5, color: C.cyanText }}><CheckCircle size={12} /> Firma capturada · Identidad verificada</div>
                      </div>
                      <button className="ppa-btn" onClick={confirmarFirma} style={{ ...S.primaryBtn, width: "100%", height: 46, fontSize: 14 }}>Enviar consentimiento firmado</button>
                    </div>
                  )}
                </>
              )}
            </div>
          )}
        </div>
        {toast && <ToastMsg msg={toast} />}
      </div>
    );
  }

  return (
    <div style={S.page}>
      <div style={{ width: "100%", maxWidth: 680 }}>
        <BackLink onClick={onVolver}>Volver al Dashboard</BackLink>
        <FuncionHeader titulo="Consentimientos Informados" usuario={usuario} tabs={[["todos", "Mis Consentimientos"]]} activeTab="todos" onTabChange={() => {}} />
        {consentimientos.map(c => (
          <div key={c.id} style={S.row}>
            <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
              <div style={{ width: 42, height: 42, borderRadius: 10, background: `${C.navy}12`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}><FileText size={18} color={C.navy} /></div>
              <div>
                <div style={{ fontSize: 13.5, fontWeight: 600, color: C.ink }}>{c.titulo}</div>
                <div style={{ fontSize: 12, color: C.inkSoft, marginTop: 2 }}>{c.equipo}{c.fechaProcedimiento ? ` · ${c.fechaProcedimiento}` : ""}</div>
                {c.estado === "firmado" && <div style={{ fontSize: 11, color: C.inkSoft, marginTop: 3, fontFamily: F.m }}>Firmado {c.firmadoEn} · {c.codigoFirma}</div>}
              </div>
            </div>
            {c.estado === "pendiente"
              ? <button className="ppa-btn" onClick={() => iniciarFirma(c)} style={{ ...S.primaryBtn, padding: "9px 16px", fontSize: 12.5, flexShrink: 0 }}>Revisar y firmar</button>
              : <span style={{ fontFamily: F.m, fontSize: 10, color: C.success, background: C.successBg, padding: "4px 10px", borderRadius: 6, textTransform: "uppercase", flexShrink: 0 }}>Firmado</span>}
          </div>
        ))}
      </div>
      {toast && <ToastMsg msg={toast} />}
    </div>
  );
}

/* ══════ VISTA — FICHA CLÍNICA DIGITAL ══════ */
/* Es una vista consolidada de lo que ya existe en Portal Paciente — no un repositorio nuevo.
   Identificación/Antecedentes enlazan a Mi Perfil y Contactos de Emergencia en vez de duplicar
   edición; Medicamentos reutiliza Farmacia; Documentos enlaza a Consentimientos y Certificados
   en vez de duplicarlos (Especificación Maestra FCD, principio de no-duplicación). */

function VistaFichaClinica({ usuario, onVolver, onNavegar }) {
  const [seccion, setSeccion] = useState("identificacion");
  const ant = usuario.antecedentesClinicos || ANTECEDENTES_VACIOS;
  const contactos = usuario.contactosEmergencia || [];
  const regionLabel = REGIONES_CL.find(r => r.codigo === (usuario.region || "13"))?.nombre;
  const fechaNacLabel = usuario.fechaNacimiento ? new Date(`${usuario.fechaNacimiento}T00:00:00`).toLocaleDateString("es-CL", { day: "2-digit", month: "long", year: "numeric" }) : null;
  const medicamentosVigentes = RECETAS_MOCK.filter(r => r.vigente);
  const consentPendientes = CONSENTIMIENTOS_MOCK.filter(c => c.estado === "pendiente").length;
  const consentFirmados = CONSENTIMIENTOS_MOCK.filter(c => c.estado === "firmado").length;
  const certDisponibles = CERTIFICADOS_MOCK.filter(c => c.estado === "disponible").length;
  const certPreparacion = CERTIFICADOS_MOCK.filter(c => c.estado === "en_preparacion").length;

  const enlace = (texto, destino) => <span className="ppa-link" onClick={() => onNavegar(destino)} style={{ fontSize: 12, color: C.cyanText, fontWeight: 600, cursor: "pointer" }}>{texto} →</span>;
  const filaAntecedente = (label, data) => (
    <div key={label} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", background: C.slate100, borderRadius: 9, padding: "10px 14px", gap: 10 }}>
      <div>
        <div style={{ fontSize: 12.5, fontWeight: 600, color: C.ink }}>{label}</div>
        {data.tiene && <div style={{ fontSize: 11.5, color: C.inkSoft, marginTop: 2 }}>{data.detalle || "Sin detalle registrado"}</div>}
      </div>
      <span style={{ fontFamily: F.m, fontSize: 10, textTransform: "uppercase", padding: "3px 9px", borderRadius: 5, flexShrink: 0, color: data.tiene ? C.warn : C.success, background: data.tiene ? C.warnBg : C.successBg }}>{data.tiene ? "Sí" : "No"}</span>
    </div>
  );

  return (
    <div style={S.page}>
      <div style={{ width: "100%", maxWidth: 880 }}>
        <BackLink onClick={onVolver}>Volver al Dashboard</BackLink>
        <div style={{ fontFamily: F.d, fontSize: 22, fontWeight: 700, color: C.navy }}>Ficha Clínica Digital</div>
        <div style={{ fontSize: 12, color: C.inkSoft, marginTop: 2, marginBottom: 20 }}>{usuario.nombres} {usuario.apellidoPaterno} · <span style={{ fontFamily: F.m }}>{usuario.cup}</span></div>

        <div style={{ display: "flex", gap: 22, flexWrap: "wrap", alignItems: "flex-start" }}>
          <div style={{ flex: "0 0 190px", minWidth: 190, display: "flex", flexDirection: "column", gap: 3 }}>
            {SECCIONES_FICHA.map(({ id, lbl, icon: SeccionIcon }) => (
              <button key={id} onClick={() => setSeccion(id)} style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 12px", borderRadius: 8, border: "none", background: seccion === id ? C.navy : "transparent", color: seccion === id ? "#fff" : C.inkSoft, fontFamily: F.b, fontWeight: 600, fontSize: 12.5, cursor: "pointer", textAlign: "left", width: "100%" }}>
                <SeccionIcon size={15} color={seccion === id ? "#fff" : C.navy} style={{ flexShrink: 0 }} />
                {lbl}
              </button>
            ))}
          </div>

          <div style={{ flex: "1 1 400px", minWidth: 280 }}>

        {seccion === "identificacion" && (
          <div style={S.card}>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 18, marginBottom: 18 }}>
              <DatoRow label="Nombre completo" valor={`${usuario.nombres} ${usuario.apellidoPaterno} ${usuario.apellidoMaterno || ""}`.trim()} />
              <DatoRow label="RUT" valor={usuario.rut} />
              <DatoRow label="CUP" valor={usuario.cup} />
              <DatoRow label="Fecha de nacimiento" valor={fechaNacLabel} />
              <DatoRow label="Correo electrónico" valor={usuario.email} />
              <DatoRow label="Teléfono" valor={usuario.telefono} />
              <DatoRow label="Región" valor={regionLabel} />
              <DatoRow label="Dirección de domicilio" valor={usuario.direccion} />
              <DatoRow label="Previsión de salud" valor={usuario.prevision} />
            </div>
            <div style={{ borderTop: `1px dashed ${C.slate200}`, paddingTop: 14, display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 10 }}>
              <span style={{ fontSize: 12, color: C.inkSoft }}>{contactos.length} contacto{contactos.length === 1 ? "" : "s"} de emergencia registrado{contactos.length === 1 ? "" : "s"}</span>
              <div style={{ display: "flex", gap: 16 }}>
                {enlace("Editar en Mi Perfil", "perfil")}
                {enlace("Ver contactos", "contactos_emergencia")}
              </div>
            </div>
          </div>
        )}

        {seccion === "antecedentes" && (
          <div style={S.card}>
            <div style={{ display: "flex", flexDirection: "column", gap: 9, marginBottom: 18 }}>
              {filaAntecedente("Alergias", ant.alergias)}
              {filaAntecedente("Antecedentes quirúrgicos", ant.antecedentesQuirurgicos)}
              {filaAntecedente("Dispositivos médicos o implantes", ant.dispositivosMedicos)}
              {ant.condicionesCronicas.length > 0 && (
                <div style={{ background: C.slate100, borderRadius: 9, padding: "10px 14px" }}>
                  <div style={{ fontSize: 12.5, fontWeight: 600, color: C.ink }}>Condiciones crónicas</div>
                  <div style={{ fontSize: 11.5, color: C.inkSoft, marginTop: 2 }}>{ant.condicionesCronicas.join(", ")}</div>
                </div>
              )}
            </div>
            <div style={{ fontFamily: F.m, fontSize: 10, textTransform: "uppercase", letterSpacing: "0.06em", color: C.inkSoft, marginBottom: 8 }}>Antecedentes familiares</div>
            {FAMILIARES_MOCK.length === 0 ? <p style={{ ...S.muted, margin: "0 0 18px" }}>Sin antecedentes familiares registrados.</p> : (
              <div style={{ display: "flex", flexDirection: "column", gap: 9, marginBottom: 18 }}>
                {FAMILIARES_MOCK.map(f => (
                  <div key={f.id} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", background: C.slate100, borderRadius: 9, padding: "10px 14px", gap: 10 }}>
                    <div style={{ fontSize: 12.5, fontWeight: 600, color: C.ink }}>{f.condicion}</div>
                    <span style={{ fontFamily: F.m, fontSize: 10, textTransform: "uppercase", padding: "3px 9px", borderRadius: 5, flexShrink: 0, color: C.navy, background: `${C.navy}12` }}>{f.parentesco}</span>
                  </div>
                ))}
              </div>
            )}
            <div style={{ fontFamily: F.m, fontSize: 10, textTransform: "uppercase", letterSpacing: "0.06em", color: C.inkSoft, marginBottom: 8 }}>Hábitos</div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 12, marginBottom: 18 }}>
              <DatoRow label="Tabaco" valor={HABITOS_MOCK.tabaco} />
              <DatoRow label="Alcohol" valor={HABITOS_MOCK.alcohol} />
              <DatoRow label="Actividad física" valor={HABITOS_MOCK.actividadFisica} />
            </div>
            <div style={{ borderTop: `1px dashed ${C.slate200}`, paddingTop: 14 }}>{enlace("Actualizar en Mi Perfil", "perfil")}</div>
          </div>
        )}

        {seccion === "resumen" && (
          <>
            <div style={{ ...S.card, marginBottom: 14 }}>
              <div style={{ fontFamily: F.d, fontSize: 14, fontWeight: 700, color: C.navy, marginBottom: 12 }}>Diagnósticos activos</div>
              {DIAGNOSTICOS_MOCK.length === 0 ? <p style={S.muted}>Sin diagnósticos activos registrados.</p> : DIAGNOSTICOS_MOCK.map(dx => (
                <div key={dx.id} style={{ background: C.slate100, borderRadius: 9, padding: "10px 14px", marginBottom: 8 }}>
                  <div style={{ fontSize: 13, fontWeight: 600, color: C.ink }}>{dx.descripcion}</div>
                  <div style={{ fontSize: 11.5, color: C.inkSoft, marginTop: 2 }}>Desde {dx.desde} · {dx.registradoPor}</div>
                </div>
              ))}
            </div>
            <div style={{ ...S.card, marginBottom: 14 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
                <div style={{ fontFamily: F.d, fontSize: 14, fontWeight: 700, color: C.navy }}>Medicamentos actuales</div>
                {enlace("Ver en Farmacia", "farmacia")}
              </div>
              {medicamentosVigentes.length === 0 ? <p style={S.muted}>Sin medicamentos vigentes.</p> : medicamentosVigentes.map(m => (
                <div key={m.id} style={{ background: C.slate100, borderRadius: 9, padding: "10px 14px", marginBottom: 8 }}>
                  <div style={{ fontSize: 13, fontWeight: 600, color: C.ink }}>{m.medicamento}</div>
                  <div style={{ fontSize: 11.5, color: C.inkSoft, marginTop: 2 }}>{m.indicacion}</div>
                </div>
              ))}
            </div>
            <div style={S.card}>
              <div style={{ fontFamily: F.d, fontSize: 14, fontWeight: 700, color: C.navy, marginBottom: 12 }}>Alergias y tratamientos crónicos</div>
              {filaAntecedente("Alergias", ant.alergias)}
              {ant.condicionesCronicas.length > 0 && <p style={{ ...S.muted, marginTop: 8 }}>{ant.condicionesCronicas.join(", ")}</p>}
            </div>
          </>
        )}

        {seccion === "vitales" && (
          <div style={S.card}>
            <p style={{ ...S.muted, marginBottom: 16 }}>Registrados en cada control — no solo el último valor. El IMC se calcula con el peso y la talla de cada control.</p>
            <div style={{ overflowX: "auto" }}>
              <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12.5 }}>
                <thead>
                  <tr style={{ borderBottom: `1.5px solid ${C.slate200}` }}>
                    {["Fecha", "Peso", "Talla", "IMC", "Presión", "FC", "FR", "Temp.", "SpO₂"].map(h => <th key={h} style={{ textAlign: "left", padding: "8px 8px", color: C.inkSoft, fontFamily: F.m, fontSize: 10.5, textTransform: h === "SpO₂" ? "none" : "uppercase" }}>{h}</th>)}
                  </tr>
                </thead>
                <tbody>
                  {[...SIGNOS_VITALES_MOCK].reverse().map((s, i) => (
                    <tr key={i} style={{ borderBottom: `1px solid ${C.slate100}` }}>
                      {[s.fecha, `${s.peso} kg`, `${s.talla} cm`, calcularIMC(s.peso, s.talla), s.presion, `${s.fc} lpm`, `${s.fr} rpm`, `${s.temp}°C`, `${s.spo2}%`].map((v, j) => (
                        <td key={j} style={{ padding: "9px 8px", color: C.ink, fontWeight: j === 0 ? 600 : 400, whiteSpace: "nowrap" }}>{v}</td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {seccion === "consultas" && CONSULTAS_MOCK.map(c => (
          <div key={c.id} style={S.row}>
            <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
              <div style={{ width: 42, height: 42, borderRadius: 10, background: `${C.navy}12`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}><Stethoscope size={18} color={C.navy} /></div>
              <div>
                <div style={{ fontSize: 13.5, fontWeight: 600, color: C.ink }}>{c.especialidad} · {c.fecha}</div>
                <div style={{ fontSize: 12, color: C.inkSoft, marginTop: 2 }}>{c.profesional}</div>
                <div style={{ fontSize: 11.5, color: C.inkSoft, marginTop: 4 }}><b>Motivo:</b> {c.motivo}</div>
                <div style={{ fontSize: 11.5, color: C.inkSoft, marginTop: 2 }}><b>Diagnóstico:</b> {c.diagnostico}</div>
              </div>
            </div>
          </div>
        ))}

        {seccion === "examenes" && EXAMENES_RESULTADOS_MOCK.map(r => (
          <div key={r.id} style={S.row}>
            <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
              <div style={{ width: 42, height: 42, borderRadius: 10, background: `${C.navy}12`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}><FileText size={18} color={C.navy} /></div>
              <div><div style={{ fontSize: 13.5, fontWeight: 600, color: C.ink }}>{r.nombre}</div><div style={{ fontSize: 12, color: C.inkSoft, marginTop: 2 }}>{r.tipo} · {r.fecha}</div></div>
            </div>
            {r.estado === "disponible"
              ? <span style={{ fontFamily: F.m, fontSize: 10, color: C.success, background: C.successBg, padding: "4px 10px", borderRadius: 6, textTransform: "uppercase", flexShrink: 0 }}>Disponible</span>
              : <span style={{ fontFamily: F.m, fontSize: 10, color: C.warn, background: C.warnBg, padding: "4px 10px", borderRadius: 6, textTransform: "uppercase", flexShrink: 0 }}>Pendiente</span>}
          </div>
        ))}

        {seccion === "procedimientos" && PROCEDIMIENTOS_FICHA_MOCK.map(p => (
          <div key={p.id} style={S.row}>
            <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
              <div style={{ width: 42, height: 42, borderRadius: 10, background: `${C.navy}12`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}><Syringe size={18} color={C.navy} /></div>
              <div style={{ fontSize: 13.5, fontWeight: 600, color: C.ink }}>{p.nombre}</div>
            </div>
            <span style={{ fontFamily: F.m, fontSize: 10, color: p.estado === "realizado" ? C.success : C.cyanText, background: p.estado === "realizado" ? C.successBg : "#E0F7FA", padding: "4px 10px", borderRadius: 6, textTransform: "uppercase", flexShrink: 0 }}>{p.estado === "realizado" ? `Realizado · ${p.fecha}` : `Programado · ${p.fecha}`}</span>
          </div>
        ))}

        {seccion === "documentos" && (
          <>
            <div style={{ ...S.card, marginBottom: 14 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 4 }}>
                <div style={{ fontFamily: F.d, fontSize: 14, fontWeight: 700, color: C.navy }}>Consentimientos</div>
                {enlace("Ver todos", "consentimientos")}
              </div>
              <p style={S.muted}>{consentFirmados} firmado{consentFirmados === 1 ? "" : "s"}, {consentPendientes} pendiente{consentPendientes === 1 ? "" : "s"}.</p>
            </div>
            <div style={{ ...S.card, marginBottom: 14 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 4 }}>
                <div style={{ fontFamily: F.d, fontSize: 14, fontWeight: 700, color: C.navy }}>Certificados</div>
                {enlace("Ver todos", "certificados")}
              </div>
              <p style={S.muted}>{certDisponibles} disponible{certDisponibles === 1 ? "" : "s"}, {certPreparacion} en preparación.</p>
            </div>
            <div style={S.card}>
              <div style={{ fontFamily: F.d, fontSize: 14, fontWeight: 700, color: C.navy, marginBottom: 8 }}>Epicrisis y altas</div>
              <p style={S.muted}>Todavía no hay epicrisis ni documentos de alta disponibles.</p>
            </div>
          </>
        )}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ══════ VISTA — MOVILIZACIÓN Y TRASLADO ══════ */
/* Pago: solo interfaz — el motor de pago real vive en MAIN. "Confirmar y pagar" simula
   la pasarela y entrega un traslado confirmado a la lista, listo para enchufar el motor real
   sin rediseñar el flujo (mismo criterio que Consentimientos con firma/OTP). */

const FilaTraslado = ({ t, onVerDetalle }) => {
  const est = ESTADOS_TRASLADO[t.estado] || ESTADOS_TRASLADO.confirmado;
  return (
    <div style={S.row}>
      <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
        <div style={{ width: 42, height: 42, borderRadius: 10, background: `${C.navy}12`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}><Truck size={18} color={C.navy} /></div>
        <div>
          <div style={{ fontSize: 13.5, fontWeight: 600, color: C.ink }}>{fechaLarga(t.fechaIso)} · {t.hora}</div>
          <div style={{ fontSize: 12, color: C.inkSoft, marginTop: 2 }}>{t.origen}</div>
          <div style={{ fontSize: 12, color: C.inkSoft, marginTop: 1 }}>→ {t.destino}</div>
          <div style={{ fontSize: 11.5, color: C.inkSoft, marginTop: 3 }}>{t.servicio}{t.detalle ? ` · ${t.detalle}` : ""}</div>
        </div>
      </div>
      <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 8, flexShrink: 0 }}>
        <span style={{ fontFamily: F.m, fontSize: 10, color: est.color, background: est.bg, padding: "4px 10px", borderRadius: 6, textTransform: "uppercase" }}>{est.label}</span>
        {onVerDetalle && <button type="button" className="ppa-link" onClick={onVerDetalle} aria-label={`Ver detalle del traslado del ${fechaLarga(t.fechaIso)}`} style={estiloEnlace}>Ver detalle →</button>}
      </div>
    </div>
  );
};

const MarcadorPasoTraslado = ({ estado }) => estado === "hecho"
  ? <CheckCircle size={18} color={C.success} />
  : <div style={{ width: 18, height: 18, borderRadius: "50%", boxSizing: "border-box", border: `2px solid ${estado === "actual" ? C.cyan : C.slate200}`, background: "#fff", display: "flex", alignItems: "center", justifyContent: "center" }}>
      {estado === "actual" && <div style={{ width: 6, height: 6, borderRadius: "50%", background: C.cyan }} />}
    </div>;

/* Detalle de un traslado (el "Ver detalle →" de Mis Traslados). Muestra solo lo que el traslado trae:
   nada se inventa. Vehículo, equipo, patente y hora estimada aparecen cuando MAIN los entrega (`asignacion`).
   Mapa y seguimiento en vivo: pendientes (necesitan proveedor de mapas y la ubicación del vehículo desde MAIN). */
function DetalleTraslado({ t, usuario, onVolver, onContacto }) {
  const est = ESTADOS_TRASLADO[t.estado] || ESTADOS_TRASLADO.confirmado;
  const esCotizacion = t.estado === "en_cotizacion";
  const realizado = t.estado === "realizado";
  const pagado = !esCotizacion && t.valor != null;
  const asignacion = t.asignacion || null;
  const solicitado = t.solicitadoIso ? fechaLarga(t.solicitadoIso) : "";
  const cuando = `${fechaLarga(t.fechaIso)}${t.hora ? ` · ${t.hora}` : ""}`;
  const monto = t.valor != null ? `$${t.valor.toLocaleString("es-CL")}` : "";
  const pasos = esCotizacion ? [
    { titulo: "Solicitud enviada", detalle: solicitado, estado: "hecho" },
    { titulo: "Cotización en preparación", detalle: "Aquí verás tu cotización cuando esté lista.", estado: "pendiente" },
  ] : [
    { titulo: "Solicitud recibida", detalle: solicitado, estado: "hecho" },
    ...(pagado ? [{ titulo: "Pago confirmado", detalle: monto, estado: "hecho" }] : []),
    { titulo: "Traslado programado", detalle: cuando, estado: "hecho" },
    { titulo: "Vehículo y equipo asignados", detalle: "", estado: asignacion || realizado ? "hecho" : "pendiente" },
    { titulo: "Traslado realizado", detalle: "", estado: realizado ? "hecho" : "pendiente" },
  ];
  const iActual = pasos.findIndex(p => p.estado === "pendiente");
  const condiciones = [...(t.movilidad?.condiciones || []), ...(t.requerimientos || [])];
  const datos = [
    { label: "Paciente", valor: `${usuario.nombres} ${usuario.apellidoPaterno}` },
    { label: "Servicio", valor: t.servicio },
    t.detalle && { label: "Detalle", valor: t.detalle },
    t.movilidad && { label: "Cómo te trasladas", valor: t.movilidad.medio },
    t.movilidad && { label: "Condiciones y requerimientos", valor: condiciones.length ? condiciones.join(", ") : "Ninguno declarado", ancho: true },
    t.nota && { label: "Indicaciones adicionales", valor: t.nota, ancho: true },
    esCotizacion && t.infoClinica && { label: "Información clínica enviada", valor: t.infoClinica, ancho: true },
    { label: esCotizacion ? "Valor" : "Pago", valor: esCotizacion ? "A cotizar" : pagado ? `Confirmado · ${monto}` : "" },
    t.pagoRef && { label: "Referencia de pago", valor: <span style={{ fontFamily: F.m }}>{t.pagoRef}</span> },
  ].filter(Boolean);
  const tituloSeccion = { fontFamily: F.d, fontSize: 14, fontWeight: 700, color: C.navy, marginBottom: 14 };

  return (
    <div style={S.page}>
      <div style={{ width: "100%", maxWidth: 640 }}>
        <BackLink onClick={onVolver}>Volver a Movilización y Traslados</BackLink>
        <h1 style={{ ...S.h1, fontSize: 22 }}>Detalle del traslado</h1>

        <div style={{ ...S.card, marginTop: 14, marginBottom: 14 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 12, flexWrap: "wrap" }}>
            <div>
              <div style={{ fontFamily: F.d, fontSize: 17, fontWeight: 700, color: C.navy }}>{cuando}</div>
              <div style={{ fontSize: 12, color: C.inkSoft, marginTop: 3 }}>{t.servicio}{t.detalle ? ` · ${t.detalle}` : ""}</div>
            </div>
            <span style={{ fontFamily: F.m, fontSize: 10, color: est.color, background: est.bg, padding: "4px 10px", borderRadius: 6, textTransform: "uppercase", flexShrink: 0 }}>{est.label}</span>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 12, marginTop: 18, paddingTop: 16, borderTop: `1px dashed ${C.slate200}` }}>
            <DatoRow label="Origen" valor={t.origen} />
            <DatoRow label="Destino" valor={t.destino} />
          </div>
        </div>

        <div style={{ ...S.card, marginBottom: 14 }}>
          <div style={tituloSeccion}>Estado del traslado</div>
          {pasos.map((p, i) => {
            const estadoPaso = i === iActual ? "actual" : p.estado;
            return (
              <div key={p.titulo} style={{ display: "flex", gap: 12 }}>
                <div style={{ display: "flex", flexDirection: "column", alignItems: "center" }}>
                  <MarcadorPasoTraslado estado={estadoPaso} />
                  {i < pasos.length - 1 && <div style={{ width: 2, flex: 1, minHeight: 16, margin: "3px 0", background: p.estado === "hecho" ? C.success : C.slate200 }} />}
                </div>
                <div style={{ paddingBottom: 14 }}>
                  <div style={{ fontSize: 13, fontWeight: estadoPaso === "actual" ? 700 : 600, color: estadoPaso === "pendiente" ? C.slate400 : C.ink }}>{p.titulo}</div>
                  {p.detalle && <div style={{ fontSize: 11.5, color: C.inkSoft, marginTop: 2 }}>{p.detalle}</div>}
                </div>
              </div>
            );
          })}
        </div>

        {!esCotizacion && (asignacion || !realizado) && (
          <div style={{ ...S.card, marginBottom: 14 }}>
            <div style={tituloSeccion}>Tu traslado</div>
            {asignacion ? (
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: 16 }}>
                {asignacion.vehiculo && <DatoRow label="Vehículo asignado" valor={asignacion.vehiculo} />}
                {asignacion.equipo && <DatoRow label="Conductor / equipo" valor={asignacion.equipo} />}
                {asignacion.patente && <DatoRow label="Patente" valor={<span style={{ fontFamily: F.m }}>{asignacion.patente}</span>} />}
                {asignacion.horaEstimada && <DatoRow label="Hora estimada de llegada" valor={asignacion.horaEstimada} />}
              </div>
            ) : (
              <p style={{ ...S.muted, margin: 0, lineHeight: 1.5 }}>Cuando se asignen el vehículo y el equipo, lo verás aquí: vehículo, conductor o equipo, patente y hora estimada de llegada.</p>
            )}
          </div>
        )}

        <div style={{ ...S.card, marginBottom: 14 }}>
          <div style={tituloSeccion}>Datos del traslado</div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: 18 }}>
            {datos.map(d => <div key={d.label} style={d.ancho ? { gridColumn: "1 / -1" } : undefined}><DatoRow label={d.label} valor={d.valor} /></div>)}
          </div>
        </div>

        {(t.estado === "confirmado" || esCotizacion) && (
          <div style={{ ...S.card, display: "flex", gap: 12, alignItems: "flex-start" }}>
            <Phone size={16} color={C.copper} style={{ flexShrink: 0, marginTop: 2 }} />
            <div style={{ fontSize: 12, color: C.inkSoft, lineHeight: 1.5 }}>Para cambiar o cancelar este traslado, escríbenos por {onContacto ? <EnlaceContacto onClick={() => onContacto({ motivo: "Movilización y traslados", mensaje: `Quiero cambiar o cancelar mi traslado del ${fechaLarga(t.fechaIso)}${t.hora ? ` a las ${t.hora}` : ""} (${t.servicio}${t.detalle ? ` · ${t.detalle}` : ""}).` })}>Contacto y Ayuda</EnlaceContacto> : "Contacto y Ayuda"}.</div>
          </div>
        )}
      </div>
    </div>
  );
}

const TarjetaServicioTraslado = ({ icon: Icon, titulo, detalle, desde, onClick, sobretitulo, etiqueta = "Ver opciones →" }) => (
  <button onClick={onClick} className="ppa-func" style={{ display: "flex", flexDirection: "column", alignItems: "flex-start", gap: 10, background: "#fff", border: `1px solid ${C.slate200}`, borderRadius: 14, padding: 20, cursor: "pointer", textAlign: "left" }}>
    <div style={{ width: 42, height: 42, borderRadius: 11, background: `${C.navy}12`, display: "flex", alignItems: "center", justifyContent: "center" }}><Icon size={19} color={C.navy} /></div>
    {sobretitulo && <div style={{ fontFamily: F.m, fontSize: 9.5, letterSpacing: "0.08em", textTransform: "uppercase", color: C.inkSoft }}>{sobretitulo}</div>}
    <div style={{ fontFamily: F.d, fontSize: 15, fontWeight: 700, color: C.ink }}>{titulo}</div>
    <div style={{ fontSize: 12, color: C.inkSoft, lineHeight: 1.5 }}>{detalle}</div>
    {desde && <div style={{ fontSize: 11, color: C.inkSoft, marginTop: 2 }}>Desde <b style={{ color: C.ink, fontSize: 14 }}>${desde}</b></div>}
    <div style={{ fontSize: 12, color: C.cyanText, fontWeight: 700, marginTop: 4 }}>{etiqueta}</div>
  </button>
);

const BloqueLugarTraslado = ({ etiqueta, tipo, direccion, onTipo, onDireccion, centros, opciones = OPCIONES_LUGAR_TRASLADO }) => (
  <div>
    <div style={{ fontSize: 13, fontWeight: 700, color: C.ink, marginBottom: 10 }}>{etiqueta}</div>
    <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 12 }}>
      {opciones.map(t => (
        <button key={t} onClick={() => onTipo(t)} style={{ padding: "8px 14px", borderRadius: 20, border: `1.5px solid ${tipo === t ? C.navy : C.slate200}`, background: tipo === t ? `${C.navy}0D` : "#fff", color: tipo === t ? C.navy : C.inkSoft, fontFamily: F.b, fontWeight: 600, fontSize: 12, cursor: "pointer" }}>{t}</button>
      ))}
    </div>
    {tipo === "Centro de salud" && centros.length > 0 && (
      <div style={{ display: "flex", flexDirection: "column", gap: 8, marginBottom: 10 }}>
        {centros.map(c => (
          <OpcionCard key={c.id} activo={direccion === c.direccion} onClick={() => onDireccion(c.direccion)}>
            <div style={{ fontSize: 12.5, fontWeight: 600, color: C.ink }}>{c.nombre}</div>
            <div style={{ fontSize: 11, color: C.inkSoft, marginTop: 1 }}>{c.tipo}{c.comuna ? ` · ${c.comuna}` : ""} · {c.direccion}</div>
          </OpcionCard>
        ))}
      </div>
    )}
    <input className="ppa-input" style={{ ...S.input, marginBottom: 8 }} value={direccion} onChange={(e) => onDireccion(e.target.value)} placeholder={tipo === "Centro de salud" && centros.length > 0 ? "O escribe otra dirección" : "Calle, número, comuna"} />
  </div>
);

/* ── Contrato de pago (Account Core) ───────────────────────────────────────────────────────────────────────
   El portal NO decide que algo está pagado: crea una intención de pago con un contexto explícito (PaymentContext)
   y espera la confirmación del backend o del proveedor. Secuencia de estados de Account Core:
   PaymentIntent → PaymentAttempt → Captured / Failed → Allocation → Settlement → Reconciliation.
   Al portal solo le corresponde mostrar "iniciado", "capturado" o "fallido"; asignación, liquidación y conciliación
   las resuelve Account Core y se muestran cuando existan. Volver desde una pasarela, o recibir una respuesta
   simulada, nunca equivale a pago confirmado. Un bono, voucher o subsidio tampoco es un medio de pago. */
function crearContextoPago({ monto, cargoIds }) {
  return {
    tenantId: "AXON_HEALTH", legalEntityId: null, episodeFinancialAccountId: null, // MOCK — los entrega MAIN / Account Core
    chargeIds: cargoIds, amountDue: monto, currency: "CLP",
    coverageState: "sin_cobertura", // MOCK — estado de cobertura / financiamiento
    correlationId: `corr-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`,
  };
}
// MOCK — reemplazar por la creación real del PaymentIntent en Account Core y por la consulta/suscripción del estado confirmado.
const iniciarPagoMock = (contexto) => new Promise((resolver) => setTimeout(() => resolver({ intentId: `pi-${contexto.correlationId}`, estado: "iniciado" }), 450));
const estadoPagoMock = (intentId) => new Promise((resolver) => setTimeout(() => resolver({ intentId, estado: "capturado" }), 700));

const estiloEnlace = { background: "none", border: "none", padding: 0, cursor: "pointer", color: C.cyanText, fontFamily: F.b, fontWeight: 600, fontSize: 12.5 };
const estiloTextarea = { ...S.input, height: 84, padding: "11px 14px", resize: "vertical", lineHeight: 1.5 };
const estiloChip = (activo) => ({ padding: "7px 13px", borderRadius: 20, border: `1.5px solid ${activo ? C.navy : C.slate200}`, background: activo ? `${C.navy}0D` : "#fff", color: activo ? C.navy : C.inkSoft, fontFamily: F.b, fontWeight: 600, fontSize: 12, cursor: "pointer" });

const BotonHora = ({ hora, activo, onClick }) => (
  <button type="button" onClick={onClick} style={{ padding: "9px 0", borderRadius: 8, textAlign: "center", border: `1.5px solid ${activo ? C.navy : C.slate200}`, background: activo ? `${C.navy}08` : "#fff", color: C.ink, cursor: "pointer", fontFamily: F.m, fontSize: 12.5, fontWeight: 600 }}>{hora}</button>
);
const GrillaHoras = ({ horas, elegida, onElegir }) => (
  <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(84px, 1fr))", gap: 8, maxWidth: 380, margin: "0 auto 20px" }}>
    {horas.map(h => <BotonHora key={h} hora={h} activo={elegida === h} onClick={() => onElegir(h)} />)}
  </div>
);
const FilaResumen = ({ label, valor }) => (
  <div style={{ display: "flex", justifyContent: "space-between", gap: 16, padding: "9px 0", borderBottom: `1px dashed ${C.slate200}` }}>
    <span style={{ fontSize: 12.5, color: C.inkSoft, flexShrink: 0 }}>{label}</span>
    <span style={{ fontSize: 12.5, color: C.ink, fontWeight: 600, textAlign: "right" }}>{valor}</span>
  </div>
);

/* Un solo motor para los tres servicios de Movilización (Ambulancia Programada, Traslado para Diálisis y Movilización
   Médica Avanzada): cambian los pasos y los datos que se piden, no el flujo. Marítimo y aéreo se cotizan (no se pagan al
   instante): terminan en "En cotización". */
function FlujoTraslado({ servicio, medio, usuario, onVolver, volverTexto = "Volver a Movilización y Traslados", onActualizarUsuario, onConfirmado, iniciarPago = iniciarPagoMock, consultarEstadoPago = estadoPagoMock }) {
  const esDialisis = servicio === "dialisis";
  const esAvanzada = servicio === "avanzada";
  const cotiza = esAvanzada && medio !== "terrestre";
  const medioInfo = esAvanzada ? MEDIOS_AVANZADA.find(m => m.id === medio) : null;
  const titulo = servicio === "ambulancia" ? "Ambulancia Programada" : esDialisis ? "Traslado para Diálisis" : "Movilización Médica Avanzada";
  const pasos = servicio === "ambulancia" ? ["Fecha", "Origen y destino", "Paciente", "Resumen", "Pago"]
    : esDialisis ? ["Fecha", "Centro y ruta", "Paciente", "Resumen", "Pago"]
    : medio === "terrestre" ? ["Vehículo", "Paciente", "Fecha", "Origen y destino", "Resumen", "Pago"]
    : ["Paciente", "Fecha", "Origen y destino", "Resumen"];
  const [paso, setPaso] = useState(0);
  const actual = pasos[paso];
  const siguiente = () => setPaso(p => Math.min(p + 1, pasos.length - 1));
  const atras = () => setPaso(p => Math.max(p - 1, 0));

  // Fecha y hora
  const [fechaSel, setFechaSel] = useState(null); const [fechaIso, setFechaIso] = useState(null); const [horaSel, setHoraSel] = useState(null);
  const [modalidadDialisis, setModalidadDialisis] = useState("ida_regreso"); const [horaRegreso, setHoraRegreso] = useState(null);
  const fechasDisponibles = fechasDisponiblesMock(esDialisis ? "dialisis" : esAvanzada ? `avanzada-${medio}` : "ambulancia", { perfil: esDialisis ? 1 : cotiza ? 2 : 0 });
  const horasIda = esDialisis ? BLOQUES_HORA_DIALISIS : BLOQUES_HORA;
  const dialisisIdaRegreso = esDialisis && modalidadDialisis === "ida_regreso";

  // Origen y destino
  const centrosSalud = usuario.centrosSaludFrecuentes || [];
  const [origenTipo, setOrigenTipo] = useState("Mi domicilio"); const [origenDireccion, setOrigenDireccion] = useState(usuario.direccion || "");
  const [destinoTipo, setDestinoTipo] = useState(null); const [destinoDireccion, setDestinoDireccion] = useState("");
  const seleccionarTipoOrigen = (t) => {
    setOrigenTipo(t);
    if (t === "Mi domicilio") setOrigenDireccion(usuario.direccion || "");
    else if (t === "Otra dirección") setOrigenDireccion("");
  };
  const seleccionarTipoDestino = (t) => {
    setDestinoTipo(t);
    if (t === "Mi domicilio") setDestinoDireccion(usuario.direccion || "");
    else if (t === "Otra dirección") setDestinoDireccion("");
  };
  const intercambiarOrigenDestino = () => {
    const tOrigen = origenTipo, dOrigen = origenDireccion, tDestino = destinoTipo, dDestino = destinoDireccion;
    setOrigenTipo(tDestino); setOrigenDireccion(dDestino);
    setDestinoTipo(tOrigen); setDestinoDireccion(dOrigen);
  };

  // Centro de diálisis
  const centrosDialisis = centrosSalud.filter(c => c.tipo === "Centro de diálisis");
  const [centroId, setCentroId] = useState(null);
  const [centroNombre, setCentroNombre] = useState(""); const [centroDireccion, setCentroDireccion] = useState("");
  const [guardarCentro, setGuardarCentro] = useState(true);
  const usandoOtroCentro = centroId === "otro" || centrosDialisis.length === 0;
  const centroValido = centroNombre.trim() !== "" && centroDireccion.trim() !== "";
  const elegirCentro = (c) => { setCentroId(c.id); setCentroNombre(c.nombre); setCentroDireccion(c.direccion); };

  // Vehículo (terrestre) y ayuda para elegir
  const [vehiculoId, setVehiculoId] = useState(null);
  const [ayudaAbierta, setAyudaAbierta] = useState(false);
  const [respuestaAyuda, setRespuestaAyuda] = useState(usuario.perfilMovilidad?.medio || null);
  const vehiculo = VEHICULOS_TERRESTRES.find(v => v.id === vehiculoId) || null;
  const sugeridos = respuestaAyuda ? (VEHICULOS_SUGERIDOS[respuestaAyuda] || []) : [];

  // Paciente: perfil de movilidad (se reutiliza y se puede actualizar) + requerimientos de este traslado
  const perfilYaCargado = !!usuario.perfilMovilidad?.medio;
  const [confirmandoPerfil, setConfirmandoPerfil] = useState(perfilYaCargado);
  const [medioNuevo, setMedioNuevo] = useState(usuario.perfilMovilidad?.medio || OPCIONES_MEDIO_TRASLADO[0]);
  const [condicionesNuevas, setCondicionesNuevas] = useState(usuario.perfilMovilidad?.condiciones || []);
  const [requerimientos, setRequerimientos] = useState([]);
  const [infoClinica, setInfoClinica] = useState("");
  const [notas, setNotas] = useState("");
  const extrasValidos = !cotiza || infoClinica.trim().length >= 10;
  const alternarCondicion = (c) => setCondicionesNuevas(prev => prev.includes(c) ? prev.filter(x => x !== c) : [...prev, c]);
  const alternarRequerimiento = (r) => setRequerimientos(prev => prev.includes(r) ? prev.filter(x => x !== r) : [...prev, r]);
  const guardarPerfilNuevo = () => {
    onActualizarUsuario({ perfilMovilidad: { medio: medioNuevo, condiciones: condicionesNuevas, detalle: usuario.perfilMovilidad?.detalle || "" } });
    setConfirmandoPerfil(true);
    siguiente();
  };

  // Valor y tramos
  const tramosPagados = dialisisIdaRegreso ? 2 : 1;
  const valorTramo = servicio === "ambulancia" ? TARIFAS_TRASLADO.ambulancia : esDialisis ? TARIFAS_TRASLADO.dialisis : (vehiculo ? vehiculo.valor : null);
  const valorEstimado = cotiza || valorTramo == null ? null : valorTramo * tramosPagados;
  const lugarOrigen = `${origenTipo} · ${origenDireccion || "sin dirección"}`;
  const lugarDestino = `${destinoTipo} · ${destinoDireccion}`;
  const lugarCentro = `${centroNombre.trim()} · ${centroDireccion.trim()}`;
  const tramosViaje = (() => {
    if (!esDialisis) return [{ tramo: null, hora: horaSel, origen: lugarOrigen, destino: lugarDestino }];
    const ida = { tramo: "Ida", hora: horaSel, origen: lugarOrigen, destino: lugarCentro };
    const regreso = { tramo: "Regreso", hora: modalidadDialisis === "regreso" ? horaSel : horaRegreso, origen: lugarCentro, destino: lugarOrigen };
    return modalidadDialisis === "ida" ? [ida] : modalidadDialisis === "regreso" ? [regreso] : [ida, regreso];
  })();
  const construirTraslados = (estado, pagoRef = null) => tramosViaje.map((t, i) => ({
    id: `tr${Date.now()}${i}`, fechaIso, hora: t.hora || "", origen: t.origen, destino: t.destino, servicio: titulo,
    detalle: esDialisis ? t.tramo : esAvanzada ? `${medioInfo.sobretitulo}${vehiculo ? ` · ${vehiculo.titulo}` : ""}` : "",
    estado, valor: valorTramo != null && !cotiza ? valorTramo : null,
    // Lo que muestra "Ver detalle". Hoy lo arma el portal; cuando MAIN entregue el traslado, vendrá con él
    // (y `asignacion`: { vehiculo, equipo, patente, horaEstimada } solo la entrega MAIN, cuando asigna el vehículo).
    solicitadoIso: isoFecha(new Date()),
    movilidad: usuario.perfilMovilidad?.medio ? { medio: usuario.perfilMovilidad.medio, condiciones: usuario.perfilMovilidad.condiciones || [] } : null,
    requerimientos: esAvanzada ? requerimientos : [], nota: esAvanzada ? notas.trim() : "",
    infoClinica: cotiza ? infoClinica.trim() : "", pagoRef: estado === "confirmado" ? pagoRef : null,
  }));

  // Pago (solo con confirmación del backend) y solicitud de cotización
  const [pagoEstado, setPagoEstado] = useState(null); // null | "iniciado" | "fallido"
  const [resultado, setResultado] = useState(null);
  const pagar = async () => {
    if (pagoEstado === "iniciado") return;
    setPagoEstado("iniciado");
    try {
      const contexto = crearContextoPago({ monto: valorEstimado, cargoIds: tramosViaje.map((_, i) => `cargo-traslado-${i + 1}`) });
      const intencion = await iniciarPago(contexto);
      const confirmacion = await consultarEstadoPago(intencion.intentId);
      if (confirmacion.estado !== "capturado") { setPagoEstado("fallido"); return; }
      if (esDialisis && guardarCentro && !centrosSalud.some(c => c.nombre === centroNombre.trim() && c.direccion === centroDireccion.trim())) {
        onActualizarUsuario({ centrosSaludFrecuentes: [...centrosSalud, { id: `cs${Date.now()}`, nombre: centroNombre.trim(), tipo: "Centro de diálisis", direccion: centroDireccion.trim(), comuna: "" }] });
      }
      setResultado(construirTraslados("confirmado", intencion.intentId));
      setPagoEstado(null);
    } catch (e) { setPagoEstado("fallido"); }
  };
  const enviarSolicitud = () => setResultado(construirTraslados("en_cotizacion"));

  const bloqueExtras = esAvanzada ? (
    <div style={{ borderTop: `1px dashed ${C.slate200}`, paddingTop: 16, marginBottom: 18 }}>
      {cotiza && (
        <Field label="Información clínica relevante" error={infoClinica.length > 0 && !extrasValidos ? "Cuéntanos un poco más (mínimo 10 caracteres)." : ""}>
          <textarea className="ppa-input" style={estiloTextarea} value={infoClinica} onChange={(e) => setInfoClinica(e.target.value)} placeholder="Motivo del traslado y situación clínica" />
        </Field>
      )}
      <div style={{ marginBottom: 16 }}>
        <label style={{ display: "block", fontSize: 13, fontWeight: 600, marginBottom: 8, color: C.ink }}>Requerimientos del traslado</label>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
          {REQUERIMIENTOS_TRASLADO.map(r => <button key={r} type="button" onClick={() => alternarRequerimiento(r)} style={estiloChip(requerimientos.includes(r))}>{r}</button>)}
        </div>
      </div>
      <Field label="¿Hay algo más que debamos saber para preparar tu traslado? (opcional)">
        <textarea className="ppa-input" style={estiloTextarea} value={notas} onChange={(e) => setNotas(e.target.value)} placeholder="Escribe aquí cualquier información útil" />
      </Field>
    </div>
  ) : null;

  const filasResumen = [
    ["Paciente", `${usuario.nombres} ${usuario.apellidoPaterno}`],
    ["Fecha", fechaSel],
    ...(esDialisis
      ? [["Modalidad", MODALIDADES_DIALISIS.find(m => m[0] === modalidadDialisis)[1]], ...tramosViaje.map(t => [t.tramo, `${t.hora} · ${t.origen} → ${t.destino}`])]
      : [["Hora", horaSel], ["Origen", lugarOrigen], ["Destino", lugarDestino]]),
    ["Servicio", `${titulo}${medioInfo ? ` · ${medioInfo.sobretitulo}` : ""}`],
    ...(vehiculo ? [["Vehículo", vehiculo.titulo]] : []),
    ...(esAvanzada && requerimientos.length ? [["Requerimientos", requerimientos.join(", ")]] : []),
    ...(cotiza ? [["Información clínica", infoClinica.trim()]] : []),
    ...(esAvanzada && notas.trim() ? [["Notas", notas.trim()]] : []),
  ];

  if (resultado) {
    const r = resultado[0];
    const enCotizacion = r.estado === "en_cotizacion";
    const detalle = enCotizacion
      ? `Recibimos tu solicitud de ${titulo} (${medioInfo.sobretitulo}) para el ${fechaLarga(r.fechaIso)}. Te enviaremos la cotización para que la apruebes antes de pagar.`
      : esDialisis
        ? `${fechaLarga(r.fechaIso)} · ${resultado.map(x => `${x.detalle.toLowerCase()} ${x.hora}`).join(" y ")} — ${lugarCentro}. Pago confirmado por $${valorEstimado.toLocaleString("es-CL")}.`
        : `${fechaLarga(r.fechaIso)} · ${r.hora} — ${r.destino}. Pago confirmado por $${valorEstimado.toLocaleString("es-CL")}.`;
    return (
      <div style={S.page}>
        <div style={{ width: "100%", maxWidth: 640 }}>
          <BackLink onClick={onVolver}>{volverTexto}</BackLink>
          <ConfirmacionExito titulo={enCotizacion ? "Solicitud enviada" : "Traslado programado"} detalle={detalle} textoBoton="Ver mis traslados" onClick={() => onConfirmado(resultado)} />
        </div>
      </div>
    );
  }

  return (
    <div style={S.page}>
      <div style={{ width: "100%", maxWidth: 640 }}>
        <BackLink onClick={onVolver}>{volverTexto}</BackLink>
        <h1 style={{ ...S.h1, fontSize: 20 }}>{titulo}{medioInfo ? ` · ${medioInfo.sobretitulo}` : ""}</h1>
        <Stepper pasos={pasos} actual={paso} />

        {actual === "Vehículo" && (
          <div style={S.card}>
            <div style={{ fontSize: 13, fontWeight: 700, color: C.ink, marginBottom: 4 }}>¿Qué tipo de vehículo necesitas?</div>
            <p style={{ ...S.muted, margin: "0 0 14px" }}>Elige el que mejor se adapte a cómo viajas.</p>
            <div style={{ display: "flex", flexDirection: "column", gap: 10, marginBottom: 18 }}>
              {VEHICULOS_TERRESTRES.map(v => (
                <OpcionCard key={v.id} activo={vehiculoId === v.id} onClick={() => setVehiculoId(v.id)} style={{ display: "flex", alignItems: "center", gap: 14 }}>
                  <div style={{ width: 40, height: 40, borderRadius: 10, background: `${C.navy}12`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}><v.icon size={18} color={C.navy} /></div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 13.5, fontWeight: 600, color: C.ink }}>{v.titulo}</div>
                    <div style={{ fontSize: 12, color: C.inkSoft, marginTop: 2 }}>{v.detalle}</div>
                  </div>
                  {sugeridos.includes(v.id) && <span style={{ fontFamily: F.m, fontSize: 9.5, letterSpacing: "0.05em", textTransform: "uppercase", color: C.cyanText, background: "#E0F7FA", padding: "3px 8px", borderRadius: 5, flexShrink: 0 }}>Sugerido para ti</span>}
                </OpcionCard>
              ))}
            </div>
            <div style={{ background: C.slate100, borderRadius: 10, padding: "14px 16px", marginBottom: 20 }}>
              <div style={{ fontSize: 13, fontWeight: 600, color: C.ink }}>¿No sabes cuál necesitas?</div>
              <p style={{ ...S.muted, margin: "4px 0 10px" }}>Cuéntanos cómo puedes trasladarte y te mostraremos las alternativas disponibles.</p>
              <button type="button" className="ppa-link" onClick={() => setAyudaAbierta(a => !a)} style={estiloEnlace}>{ayudaAbierta ? "Ocultar ayuda" : "Ayúdame a elegir"}</button>
              {ayudaAbierta && (
                <div style={{ marginTop: 14 }}>
                  <div style={{ fontSize: 12.5, fontWeight: 600, color: C.ink, marginBottom: 8 }}>¿Cómo puedes trasladarte actualmente?</div>
                  <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                    {OPCIONES_AYUDA_VEHICULO.map(op => <OpcionCard key={op} activo={respuestaAyuda === op} onClick={() => setRespuestaAyuda(op)}><div style={{ fontSize: 13, color: C.ink }}>{op}</div></OpcionCard>)}
                  </div>
                  {respuestaAyuda === "No estoy seguro" && <p style={{ ...S.muted, margin: "10px 0 0" }}>Sin problema: revisa las tres alternativas y elige la que sientas más cercana.</p>}
                </div>
              )}
            </div>
            <button className="ppa-btn" disabled={!vehiculoId} onClick={siguiente} style={{ ...S.primaryBtn, width: "100%", height: 46, fontSize: 14, opacity: vehiculoId ? 1 : 0.5, cursor: vehiculoId ? "pointer" : "default" }}>Continuar</button>
          </div>
        )}

        {actual === "Fecha" && (
          <div style={S.card}>
            {paso > 0 && <BackLink onClick={atras}>Volver</BackLink>}
            <div style={{ fontSize: 13, fontWeight: 700, color: C.ink, marginBottom: 14 }}>{esDialisis ? "¿Cuándo es tu sesión de diálisis?" : "¿Cuándo necesitas el traslado?"}</div>
            {esDialisis && (
              <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 16 }}>
                {MODALIDADES_DIALISIS.map(([id, lbl]) => <button key={id} type="button" onClick={() => { setModalidadDialisis(id); setHoraRegreso(null); }} style={estiloChip(modalidadDialisis === id)}>{lbl}</button>)}
              </div>
            )}
            <div style={{ marginBottom: 18 }}>
              <SelectorFecha disponibles={fechasDisponibles} valor={fechaSel} onElegir={(d) => { setFechaSel(etiquetaFecha(d)); setFechaIso(isoFecha(d)); setHoraSel(null); setHoraRegreso(null); }} />
            </div>
            {fechaSel && (
              <>
                {esDialisis && <div style={{ ...S.muted, maxWidth: 380, margin: "0 auto 8px" }}>{modalidadDialisis === "regreso" ? "Hora en que te recogemos en el centro" : "Hora en que te recogemos"}</div>}
                <GrillaHoras horas={horasIda} elegida={horaSel} onElegir={(h) => { setHoraSel(h); setHoraRegreso(null); }} />
              </>
            )}
            {dialisisIdaRegreso && horaSel && (
              <>
                <div style={{ ...S.muted, maxWidth: 380, margin: "0 auto 8px" }}>Hora en que te recogemos al terminar tu sesión</div>
                <GrillaHoras horas={opcionesRegreso(horaSel)} elegida={horaRegreso} onElegir={setHoraRegreso} />
              </>
            )}
            {(() => { const listo = !!fechaSel && !!horaSel && (!dialisisIdaRegreso || !!horaRegreso); return (
              <button className="ppa-btn" disabled={!listo} onClick={siguiente} style={{ ...S.primaryBtn, width: "100%", height: 46, fontSize: 14, opacity: listo ? 1 : 0.5, cursor: listo ? "pointer" : "default" }}>Continuar</button>
            ); })()}
          </div>
        )}

        {actual === "Origen y destino" && (
          <div style={S.card}>
            <BackLink onClick={atras}>Volver</BackLink>
            <BloqueLugarTraslado etiqueta="Origen" tipo={origenTipo} direccion={origenDireccion} onTipo={seleccionarTipoOrigen} onDireccion={setOrigenDireccion} centros={centrosSalud} />
            <div style={{ display: "flex", justifyContent: "center", margin: "2px 0 14px" }}>
              <button onClick={intercambiarOrigenDestino} disabled={!destinoDireccion.trim()} title="Intercambiar origen y destino" style={{ width: 34, height: 34, borderRadius: "50%", border: `1px solid ${C.slate200}`, background: "#fff", display: "flex", alignItems: "center", justifyContent: "center", cursor: destinoDireccion.trim() ? "pointer" : "default", opacity: destinoDireccion.trim() ? 1 : 0.35 }}>
                <ArrowUpDown size={15} color={C.navy} />
              </button>
            </div>
            <BloqueLugarTraslado etiqueta="Destino" tipo={destinoTipo} direccion={destinoDireccion} onTipo={seleccionarTipoDestino} onDireccion={setDestinoDireccion} centros={centrosSalud} />
            {(() => { const listo = !!origenDireccion && !!destinoTipo && !!destinoDireccion; return (
              <button className="ppa-btn" disabled={!listo} onClick={siguiente} style={{ ...S.primaryBtn, width: "100%", height: 46, fontSize: 14, marginTop: 8, opacity: listo ? 1 : 0.5, cursor: listo ? "pointer" : "default" }}>Continuar</button>
            ); })()}
          </div>
        )}

        {actual === "Centro y ruta" && (
          <div style={S.card}>
            <BackLink onClick={atras}>Volver</BackLink>
            <div style={{ fontSize: 13, fontWeight: 700, color: C.ink, marginBottom: 10 }}>Centro de diálisis</div>
            {centrosDialisis.length > 0 && (
              <div style={{ display: "flex", flexDirection: "column", gap: 8, marginBottom: 12 }}>
                {centrosDialisis.map(c => (
                  <OpcionCard key={c.id} activo={centroId === c.id} onClick={() => elegirCentro(c)}>
                    <div style={{ fontSize: 12.5, fontWeight: 600, color: C.ink }}>{c.nombre}</div>
                    <div style={{ fontSize: 11, color: C.inkSoft, marginTop: 1 }}>{c.comuna ? `${c.comuna} · ` : ""}{c.direccion}</div>
                  </OpcionCard>
                ))}
                <OpcionCard activo={centroId === "otro"} onClick={() => { setCentroId("otro"); setCentroNombre(""); setCentroDireccion(""); }}><div style={{ fontSize: 12.5, fontWeight: 600, color: C.ink }}>Otro centro de diálisis</div></OpcionCard>
              </div>
            )}
            {usandoOtroCentro && (
              <div style={{ marginBottom: 6 }}>
                <input className="ppa-input" style={{ ...S.input, marginBottom: 8 }} value={centroNombre} onChange={(e) => setCentroNombre(e.target.value)} placeholder="Nombre del centro de diálisis" aria-label="Nombre del centro de diálisis" />
                <input className="ppa-input" style={{ ...S.input, marginBottom: 10 }} value={centroDireccion} onChange={(e) => setCentroDireccion(e.target.value)} placeholder="Dirección del centro" aria-label="Dirección del centro de diálisis" />
                <label style={{ display: "flex", alignItems: "center", gap: 9, cursor: "pointer" }}>
                  <input type="checkbox" checked={guardarCentro} onChange={(e) => setGuardarCentro(e.target.checked)} style={{ cursor: "pointer" }} />
                  <span style={{ fontSize: 12.5, color: C.ink }}>Guardar en mis centros frecuentes</span>
                </label>
              </div>
            )}
            <div style={{ height: 18 }} />
            <BloqueLugarTraslado etiqueta="Te recogemos en" opciones={["Mi domicilio", "Otra dirección"]} tipo={origenTipo} direccion={origenDireccion} onTipo={seleccionarTipoOrigen} onDireccion={setOrigenDireccion} centros={[]} />
            {(() => { const listo = centroValido && origenDireccion.trim() !== ""; return (
              <button className="ppa-btn" disabled={!listo} onClick={siguiente} style={{ ...S.primaryBtn, width: "100%", height: 46, fontSize: 14, marginTop: 8, opacity: listo ? 1 : 0.5, cursor: listo ? "pointer" : "default" }}>Continuar</button>
            ); })()}
          </div>
        )}

        {actual === "Paciente" && (
          <div style={S.card}>
            {paso > 0 && <BackLink onClick={atras}>Volver</BackLink>}
            {confirmandoPerfil ? (
              <>
                <div style={{ fontSize: 13, fontWeight: 700, color: C.ink, marginBottom: 4 }}>Información del paciente</div>
                <p style={{ ...S.muted, marginBottom: 14 }}>Hemos encontrado información registrada que puede ayudar a preparar tu traslado.</p>
                <div style={{ background: C.slate100, borderRadius: 10, padding: "14px 16px", marginBottom: 18 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}><CheckCircle size={14} color={C.success} /><span style={{ fontSize: 13, color: C.ink, fontWeight: 600 }}>{usuario.perfilMovilidad?.medio || medioNuevo}</span></div>
                  {(usuario.perfilMovilidad?.condiciones || []).map(c => <div key={c} style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 4 }}><CheckCircle size={14} color={C.success} /><span style={{ fontSize: 12.5, color: C.ink }}>{c}</span></div>)}
                </div>
                {bloqueExtras}
                <p style={{ fontSize: 13, color: C.ink, fontWeight: 600, marginBottom: 14 }}>¿Esta información sigue siendo correcta?</p>
                <div style={{ display: "flex", gap: 10 }}>
                  <button onClick={() => setConfirmandoPerfil(false)} style={{ flex: 1, padding: "11px 0", borderRadius: 9, border: `1px solid ${C.slate200}`, background: "#fff", color: C.ink, fontFamily: F.b, fontWeight: 600, fontSize: 13, cursor: "pointer" }}>Actualizar información</button>
                  <button className="ppa-btn" disabled={!extrasValidos} onClick={siguiente} style={{ ...S.primaryBtn, flex: 1, padding: "11px 0", fontSize: 13, opacity: extrasValidos ? 1 : 0.5, cursor: extrasValidos ? "pointer" : "default" }}>Sí, continúa</button>
                </div>
              </>
            ) : (
              <>
                <div style={{ fontSize: 13, fontWeight: 700, color: C.ink, marginBottom: 4 }}>Necesitamos conocer algunos datos</div>
                <p style={{ ...S.muted, marginBottom: 16 }}>Para asegurarnos de que el vehículo sea el adecuado para tu traslado.</p>
                <div style={{ marginBottom: 16 }}>
                  <label style={{ display: "block", fontSize: 13, fontWeight: 600, marginBottom: 8, color: C.ink }}>¿Cómo puedes trasladarte actualmente?</label>
                  <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                    {OPCIONES_MEDIO_TRASLADO.map(op => <OpcionCard key={op} activo={medioNuevo === op} onClick={() => setMedioNuevo(op)}><div style={{ fontSize: 13, color: C.ink }}>{op}</div></OpcionCard>)}
                  </div>
                </div>
                <div style={{ marginBottom: 20 }}>
                  <label style={{ display: "block", fontSize: 13, fontWeight: 600, marginBottom: 8, color: C.ink }}>¿Alguna condición especial que debamos considerar?</label>
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                    {CONDICIONES_TRASLADO_OPCIONES.map(c => <button key={c} type="button" onClick={() => alternarCondicion(c)} style={{ ...estiloChip(condicionesNuevas.includes(c)), fontSize: 11.5 }}>{c}</button>)}
                  </div>
                </div>
                {bloqueExtras}
                <button className="ppa-btn" disabled={!extrasValidos} onClick={guardarPerfilNuevo} style={{ ...S.primaryBtn, width: "100%", height: 46, fontSize: 14, opacity: extrasValidos ? 1 : 0.5, cursor: extrasValidos ? "pointer" : "default" }}>Continuar</button>
              </>
            )}
          </div>
        )}

        {actual === "Resumen" && (
          <div style={S.card}>
            <BackLink onClick={atras}>Volver</BackLink>
            <div style={{ fontSize: 15, fontWeight: 700, color: C.navy, fontFamily: F.d, marginBottom: 16 }}>Resumen del traslado</div>
            {filasResumen.map(([label, valor]) => <FilaResumen key={label} label={label} valor={valor} />)}
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "16px 0 20px" }}>
              <span style={{ fontSize: 13, color: C.ink, fontWeight: 700 }}>Valor estimado</span>
              <span style={{ fontFamily: F.d, fontSize: 20, color: C.navy, fontWeight: 700 }}>{valorEstimado != null ? `$${valorEstimado.toLocaleString("es-CL")}` : "A cotizar"}</span>
            </div>
            {cotiza && <p style={{ ...S.muted, margin: "0 0 16px" }}>Este tipo de traslado se cotiza según disponibilidad y requerimientos. Te enviaremos la cotización para que la apruebes antes de pagar.</p>}
            <button className="ppa-btn" onClick={cotiza ? enviarSolicitud : siguiente} style={{ ...S.primaryBtn, width: "100%", height: 46, fontSize: 14 }}>{cotiza ? "Enviar solicitud de cotización" : "Confirmar solicitud"}</button>
          </div>
        )}

        {actual === "Pago" && (
          <div style={S.card}>
            <BackLink onClick={atras}>Volver</BackLink>
            <div style={{ fontSize: 15, fontWeight: 700, color: C.navy, fontFamily: F.d, marginBottom: 4 }}>Confirmar y pagar</div>
            <p style={{ ...S.muted, marginBottom: 18 }}>Tu traslado está listo para ser solicitado.</p>
            <div style={{ background: C.slate100, borderRadius: 10, padding: "14px 16px", marginBottom: 20 }}>
              <div style={{ display: "flex", justifyContent: "space-between", gap: 16, fontSize: 12.5, color: C.inkSoft, marginBottom: 4 }}><span>Fecha</span><span style={{ color: C.ink, fontWeight: 600, textAlign: "right" }}>{fechaSel} · {esDialisis ? tramosViaje.map(t => `${t.tramo.toLowerCase()} ${t.hora}`).join(" y ") : horaSel}</span></div>
              <div style={{ display: "flex", justifyContent: "space-between", gap: 16, fontSize: 12.5, color: C.inkSoft, marginBottom: 4 }}><span>Servicio</span><span style={{ color: C.ink, fontWeight: 600, textAlign: "right" }}>{titulo}{vehiculo ? ` · ${vehiculo.titulo}` : ""}</span></div>
              <div style={{ borderTop: `1px dashed ${C.slate200}`, marginTop: 10, paddingTop: 10, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <span style={{ fontSize: 13, fontWeight: 700, color: C.ink }}>Total</span>
                <span style={{ fontFamily: F.d, fontSize: 22, color: C.navy, fontWeight: 700 }}>${valorEstimado.toLocaleString("es-CL")}</span>
              </div>
            </div>
            {pagoEstado === "iniciado" && <div style={{ display: "flex", alignItems: "center", gap: 8, background: C.warnBg, borderRadius: 8, padding: "9px 12px", marginBottom: 14 }}><Clock size={14} color={C.warn} /><span style={{ fontSize: 12.5, color: C.warn }}>Pago iniciado — esperando la confirmación del proveedor.</span></div>}
            {pagoEstado === "fallido" && <div style={{ display: "flex", alignItems: "center", gap: 8, background: C.dangerBg, border: "1px solid #FCA5A5", borderRadius: 8, padding: "9px 12px", marginBottom: 14 }}><AlertCircle size={14} color={C.danger} /><span style={{ fontSize: 12.5, color: C.danger }}>El pago no fue confirmado. Puedes intentarlo nuevamente.</span></div>}
            <p style={{ fontSize: 10.5, color: C.inkSoft, marginBottom: 16 }}>Interfaz de pago — la pasarela y la confirmación reales las entrega Account Core; el portal no marca el pago como realizado hasta recibir esa confirmación.</p>
            <button className="ppa-btn" disabled={pagoEstado === "iniciado"} onClick={pagar} style={{ ...S.primaryBtn, width: "100%", height: 48, fontSize: 15 }}>{pagoEstado === "iniciado" ? "Pago iniciado…" : pagoEstado === "fallido" ? "Reintentar pago" : "Confirmar y pagar"}</button>
          </div>
        )}
      </div>
    </div>
  );
}

function VistaMovilizacion({ usuario, onVolver, onActualizarUsuario, onContacto }) {
  const [pantalla, setPantalla] = useState("landing"); // landing | ambulancia | dialisis | avanzada | avanzada_flujo
  const [medioAvanzada, setMedioAvanzada] = useState(null);
  const [traslados, setTraslados] = useState(trasladosDemo);
  const [verHistorial, setVerHistorial] = useState(false);
  const [detalleId, setDetalleId] = useState(null);
  const [toast, setToast] = useState("");
  const mostrarToast = (m) => { setToast(m); setTimeout(() => setToast(""), 2800); };
  const alConfirmar = (nuevos) => {
    setTraslados(t => [...nuevos, ...t]);
    setPantalla("landing");
    mostrarToast(nuevos[0].estado === "en_cotizacion" ? "Solicitud enviada." : "Traslado confirmado.");
  };

  const trasladoDetalle = detalleId ? traslados.find(t => t.id === detalleId) : null;
  if (trasladoDetalle) return <DetalleTraslado t={trasladoDetalle} usuario={usuario} onVolver={() => setDetalleId(null)} onContacto={onContacto} />;

  if (pantalla === "ambulancia" || pantalla === "dialisis") {
    return <FlujoTraslado key={pantalla} servicio={pantalla} usuario={usuario} onVolver={() => setPantalla("landing")} onActualizarUsuario={onActualizarUsuario} onConfirmado={alConfirmar} />;
  }
  if (pantalla === "avanzada_flujo") {
    return <FlujoTraslado key={`avanzada-${medioAvanzada}`} servicio="avanzada" medio={medioAvanzada} usuario={usuario} volverTexto="Volver a Movilización Médica Avanzada" onVolver={() => setPantalla("avanzada")} onActualizarUsuario={onActualizarUsuario} onConfirmado={alConfirmar} />;
  }
  if (pantalla === "avanzada") {
    return (
      <div style={S.page}>
        <div style={{ width: "100%", maxWidth: 760 }}>
          <BackLink onClick={() => setPantalla("landing")}>Volver a Movilización y Traslados</BackLink>
          <h1 style={{ ...S.h1, fontSize: 24 }}>Movilización Médica Avanzada</h1>
          <p style={{ ...S.muted, margin: "0 0 26px", fontSize: 13 }}>Selecciona el medio de transporte que mejor se adapte a tus necesidades.</p>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: 14 }}>
            {MEDIOS_AVANZADA.map(m => (
              <TarjetaServicioTraslado key={m.id} icon={m.icon} sobretitulo={m.sobretitulo} titulo={m.titulo} detalle={m.detalle} etiqueta={m.etiqueta} onClick={() => { setMedioAvanzada(m.id); setPantalla("avanzada_flujo"); }} />
            ))}
          </div>
        </div>
      </div>
    );
  }

  const ahora = new Date();
  const inicioDe = (t) => new Date(`${t.fechaIso}T${t.hora || "00:00"}:00`);
  const cotizaciones = traslados.filter(t => t.estado === "en_cotizacion");
  const proximos = traslados.filter(t => t.estado === "confirmado" && inicioDe(t) >= ahora).sort((a, b) => inicioDe(a) - inicioDe(b));
  const historial = traslados.filter(t => t.estado !== "en_cotizacion" && !proximos.includes(t)).sort((a, b) => inicioDe(b) - inicioDe(a));
  const [proximo, ...otros] = proximos;
  const estProx = proximo ? ESTADOS_TRASLADO[proximo.estado] : null;

  return (
    <div style={S.page}>
      <div style={{ width: "100%", maxWidth: 760 }}>
        <BackLink onClick={onVolver}>Volver al Dashboard</BackLink>
        <h1 style={{ ...S.h1, fontSize: 24 }}>Movilización y Traslados</h1>
        <p style={{ ...S.muted, margin: "0 0 26px", fontSize: 13 }}>¿Cómo podemos ayudarte? Selecciona el tipo de movilización que necesitas — puedes programarla con anticipación según disponibilidad.</p>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: 14, marginBottom: 20 }}>
          <TarjetaServicioTraslado icon={Truck} titulo="Ambulancia Programada" detalle="Traslado sanitario programado por agenda." desde={TARIFAS_TRASLADO.ambulancia.toLocaleString("es-CL")} onClick={() => setPantalla("ambulancia")} />
          <TarjetaServicioTraslado icon={HeartPulse} titulo="Traslado para Diálisis" detalle="Programa tus traslados de ida y regreso a tu centro de diálisis." desde={TARIFAS_TRASLADO.dialisis.toLocaleString("es-CL")} onClick={() => setPantalla("dialisis")} />
          <TarjetaServicioTraslado icon={Bed} titulo="Movilización Médica Avanzada" detalle="Vehículos y transporte para requerimientos especiales." onClick={() => setPantalla("avanzada")} />
        </div>

        <div style={{ ...S.card, display: "flex", alignItems: "center", justifyContent: "space-between", gap: 14, flexWrap: "wrap", marginBottom: 28, border: "1px solid #FCA5A5", background: C.dangerBg }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <AlertCircle size={20} color={C.danger} />
            <div>
              <div style={{ fontSize: 13, fontWeight: 700, color: C.ink }}>¿Necesitas atención de urgencia?</div>
              <div style={{ fontSize: 11.5, color: C.inkSoft, marginTop: 1 }}>Si es una emergencia, solicita atención inmediata.</div>
            </div>
          </div>
          <button onClick={() => mostrarToast("Atención de urgencia — su propio acceso en el Dashboard principal, próximo a construir.")} style={{ background: "#fff", border: `1.5px solid ${C.danger}`, borderRadius: 9, padding: "9px 16px", color: C.danger, fontFamily: F.b, fontWeight: 700, fontSize: 12.5, cursor: "pointer", flexShrink: 0 }}>Solicitar atención de urgencia</button>
        </div>

        <div style={{ fontFamily: F.m, fontSize: 11, textTransform: "uppercase", letterSpacing: "0.08em", color: C.inkSoft, marginBottom: 12 }}>Mis Traslados</div>
        {!proximo ? (
          <div style={{ ...S.card, textAlign: "center", padding: 28, marginBottom: 12 }}><p style={{ ...S.muted, margin: 0 }}>No tienes traslados programados.</p></div>
        ) : (
          <div style={{ ...S.card, marginBottom: 12 }}>
            <span style={{ fontFamily: F.m, fontSize: 9.5, letterSpacing: "0.06em", textTransform: "uppercase", color: C.cyanText, background: "#E0F7FA", padding: "3px 9px", borderRadius: 5 }}>Próximo traslado</span>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", flexWrap: "wrap", gap: 14, marginTop: 12 }}>
              <div>
                <div style={{ fontSize: 14, fontWeight: 700, color: C.ink }}>{fechaLarga(proximo.fechaIso)} · {proximo.hora}</div>
                <div style={{ fontSize: 12, color: C.inkSoft, marginTop: 4 }}>{proximo.origen}</div>
                <div style={{ fontSize: 12, color: C.inkSoft, marginTop: 2 }}>→ {proximo.destino}</div>
                <div style={{ fontSize: 11.5, color: C.inkSoft, marginTop: 4 }}>{proximo.servicio}{proximo.detalle ? ` · ${proximo.detalle}` : ""}</div>
              </div>
              <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 8, flexShrink: 0 }}>
                <span style={{ fontFamily: F.m, fontSize: 10, color: estProx.color, background: estProx.bg, padding: "4px 10px", borderRadius: 6, textTransform: "uppercase" }}>{estProx.label}</span>
                <button type="button" className="ppa-link" onClick={() => setDetalleId(proximo.id)} aria-label={`Ver detalle del traslado del ${fechaLarga(proximo.fechaIso)}`} style={estiloEnlace}>Ver detalle →</button>
              </div>
            </div>
          </div>
        )}
        {otros.length > 0 && (
          <>
            <div style={{ ...S.muted, margin: "14px 0 8px" }}>Otros traslados programados</div>
            {otros.map(t => <FilaTraslado key={t.id} t={t} onVerDetalle={() => setDetalleId(t.id)} />)}
          </>
        )}
        {cotizaciones.length > 0 && (
          <>
            <div style={{ ...S.muted, margin: "14px 0 8px" }}>Solicitudes en cotización</div>
            {cotizaciones.map(t => <FilaTraslado key={t.id} t={t} onVerDetalle={() => setDetalleId(t.id)} />)}
          </>
        )}
        {historial.length > 0 && (
          <>
            <button type="button" className="ppa-link" onClick={() => setVerHistorial(v => !v)} style={{ ...estiloEnlace, margin: "6px 0 12px" }}>{verHistorial ? "Ocultar historial de traslados" : "Ver historial de traslados"} →</button>
            {verHistorial && historial.map(t => <FilaTraslado key={t.id} t={t} onVerDetalle={() => setDetalleId(t.id)} />)}
          </>
        )}
      </div>
      {toast && <ToastMsg msg={toast} />}
    </div>
  );
}

/* ══════ VISTA — CONTACTO Y AYUDA ══════ */
/* Canal administrativo: agenda, pagos, documentos, datos y portal. No recibe reclamos formales (son de OIRS) ni
   urgencias. Las solicitudes son datos transaccionales: estado local, como Certificados y Farmacia. */

// MOCK — punto de conexión: aquí se crea la solicitud en el sistema de atención (MAIN) y vuelve con su folio.
function enviarSolicitudContactoMock({ motivo, mensaje, canal }) {
  return { id: `sol${Date.now()}`, folio: `SOL-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`, motivo, mensaje, canal, fechaIso: isoFecha(new Date()), estado: "recibida", respuesta: "" };
}

function VistaContactoAyuda({ usuario, onVolver, prefill }) {
  const [tab, setTab] = useState("contacto");
  const [solicitudes, setSolicitudes] = useState(solicitudesContactoDemo);
  const [motivo, setMotivo] = useState(prefill?.motivo || MOTIVOS_CONTACTO[0]);
  const [mensaje, setMensaje] = useState(prefill?.mensaje || "");
  const [canal, setCanal] = useState(usuario.email ? "correo" : usuario.telefono ? "telefono" : null);
  const [error, setError] = useState("");
  const [enviada, setEnviada] = useState(null);
  const [abierta, setAbierta] = useState(null);
  const [toast, setToast] = useState("");
  const mostrarToast = (m) => { setToast(m); setTimeout(() => setToast(""), 2600); };
  const contactoDe = (c) => (c === "correo" ? usuario.email : usuario.telefono);

  const enviar = () => {
    if (!canal) { setError("Agrega un correo o un teléfono en Mi Perfil para que podamos responderte."); return; }
    if (prefill?.completar && mensaje.trim() === prefill.mensaje.trim()) { setError("Completa tu mensaje antes de enviarlo."); return; }
    if (mensaje.trim().length < 10) { setError("Cuéntanos con algo más de detalle (mínimo 10 caracteres)."); return; }
    const nueva = enviarSolicitudContactoMock({ motivo, mensaje: mensaje.trim(), canal });
    setSolicitudes(s => [nueva, ...s]); setEnviada(nueva); setMensaje(""); setError("");
  };

  if (enviada) {
    return (
      <div style={S.page}>
        <div style={{ width: "100%", maxWidth: 680 }}>
          <BackLink onClick={onVolver}>Volver al Dashboard</BackLink>
          <ConfirmacionExito titulo="Mensaje enviado" detalle={`Tu número de solicitud es ${enviada.folio}. Te responderemos ${enviada.canal === "correo" ? "por correo a" : "por teléfono al"} ${contactoDe(enviada.canal)}.`} textoBoton="Ver mis solicitudes" onClick={() => { setEnviada(null); setTab("solicitudes"); }} />
        </div>
      </div>
    );
  }

  return (
    <div style={S.page}>
      <div style={{ width: "100%", maxWidth: 680 }}>
        <BackLink onClick={onVolver}>Volver al Dashboard</BackLink>
        <FuncionHeader titulo="Contacto y Ayuda" usuario={usuario} tabs={[["contacto", "Contacto"], ["solicitudes", `Mis solicitudes (${solicitudes.length})`]]} activeTab={tab} onTabChange={setTab} />

        {tab === "solicitudes" ? (
          solicitudes.length === 0 ? (
            <div style={{ ...S.card, textAlign: "center", padding: 32 }}>
              <MessageSquare size={22} color={C.slate400} style={{ marginBottom: 10 }} />
              <p style={{ ...S.muted, margin: 0 }}>Todavía no has enviado mensajes. Escríbenos desde la pestaña "Contacto".</p>
            </div>
          ) : solicitudes.map(sol => {
            const est = ESTADOS_SOLICITUD[sol.estado] || ESTADOS_SOLICITUD.recibida;
            const abre = abierta === sol.id;
            return (
              <div key={sol.id} style={{ ...S.row, display: "block" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12, flexWrap: "wrap" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
                    <div style={{ width: 42, height: 42, borderRadius: 10, background: `${C.navy}12`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}><MessageSquare size={18} color={C.navy} /></div>
                    <div>
                      <div style={{ fontSize: 13.5, fontWeight: 600, color: C.ink }}>{sol.motivo}</div>
                      <div style={{ fontSize: 11.5, color: C.inkSoft, marginTop: 2 }}><span style={{ fontFamily: F.m }}>{sol.folio}</span> · {fechaLarga(sol.fechaIso)}</div>
                    </div>
                  </div>
                  <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 8, flexShrink: 0 }}>
                    <span style={{ fontFamily: F.m, fontSize: 10, color: est.color, background: est.bg, padding: "4px 10px", borderRadius: 6, textTransform: "uppercase" }}>{est.label}</span>
                    <button type="button" className="ppa-link" aria-expanded={abre} onClick={() => setAbierta(abre ? null : sol.id)} style={estiloEnlace}>{abre ? "Ocultar mensaje" : "Ver mensaje"} →</button>
                  </div>
                </div>
                {abre && (
                  <div style={{ marginTop: 14, paddingTop: 14, borderTop: `1px dashed ${C.slate200}`, display: "flex", flexDirection: "column", gap: 12 }}>
                    <DatoRow label="Tu mensaje" valor={sol.mensaje} />
                    <DatoRow label="Respuesta" valor={sol.respuesta || "Aún no hay respuesta."} />
                  </div>
                )}
              </div>
            );
          })
        ) : (
          <>
            <div style={{ ...S.card, display: "flex", alignItems: "center", gap: 12, marginBottom: 14, border: "1px solid #FCA5A5", background: C.dangerBg }}>
              <AlertCircle size={20} color={C.danger} style={{ flexShrink: 0 }} />
              <div>
                <div style={{ fontSize: 13, fontWeight: 700, color: C.ink }}>Este canal no atiende urgencias</div>
                <div style={{ fontSize: 11.5, color: C.inkSoft, marginTop: 1 }}>Si es una emergencia, llama al 131 (SAMU) o acude al servicio de urgencia más cercano.</div>
              </div>
            </div>

            <div style={{ ...S.card, marginBottom: 14 }}>
              <div style={{ fontFamily: F.d, fontSize: 14, fontWeight: 700, color: C.navy, marginBottom: 14 }}>Canales de atención</div>
              <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                {[
                  { icon: Phone, label: "Teléfono", valor: CANALES_CONTACTO.telefono, mono: true },
                  { icon: Mail, label: "Correo electrónico", valor: CANALES_CONTACTO.correo, mono: true },
                  { icon: MessageCircle, label: "WhatsApp", valor: "Próximamente", pronto: true },
                  { icon: Clock, label: "Horario de atención", valor: CANALES_CONTACTO.horario },
                ].map(c => (
                  <div key={c.label} style={{ display: "flex", alignItems: "center", gap: 12 }}>
                    <div style={{ width: 36, height: 36, borderRadius: 9, background: `${C.navy}12`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}><c.icon size={16} color={C.navy} /></div>
                    <div>
                      <div style={{ fontFamily: F.m, fontSize: 10, textTransform: "uppercase", letterSpacing: "0.06em", color: C.inkSoft }}>{c.label}</div>
                      <div style={{ fontSize: 13.5, fontWeight: 500, color: c.pronto ? C.inkSoft : C.ink, fontFamily: c.mono ? F.m : F.b }}>{c.valor}</div>
                    </div>
                  </div>
                ))}
              </div>
              <p style={{ fontSize: 11, color: C.inkSoft, margin: "14px 0 0" }}>Datos de ejemplo: cada institución configura los suyos.</p>
            </div>

            <div style={S.card}>
              <div style={{ fontFamily: F.d, fontSize: 14, fontWeight: 700, color: C.navy, marginBottom: 4 }}>Escríbenos</div>
              <p style={{ ...S.muted, margin: "0 0 16px", lineHeight: 1.5 }}>Para consultas administrativas: agenda, pagos, documentos, tus datos o el portal. Para consultas de salud, agenda una atención médica.</p>
              <Field label="Motivo">
                <select className="ppa-input" style={{ ...S.input, cursor: "pointer" }} value={motivo} onChange={(e) => setMotivo(e.target.value)}>
                  {MOTIVOS_CONTACTO.map(m => <option key={m} value={m}>{m}</option>)}
                </select>
              </Field>
              <Field label="Mensaje">
                <textarea className="ppa-input" style={{ ...S.input, height: 120, padding: "12px 14px", resize: "vertical", lineHeight: 1.5 }} value={mensaje} onChange={(e) => { setMensaje(e.target.value); setError(""); }} placeholder="Cuéntanos en qué podemos ayudarte" />
              </Field>
              <div style={{ marginBottom: 18 }}>
                <label style={{ display: "block", fontSize: 13, fontWeight: 600, marginBottom: 8, color: C.ink }}>¿Cómo prefieres que te respondamos?</label>
                <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
                  {[["correo", "Correo electrónico", usuario.email], ["telefono", "Teléfono", usuario.telefono]].map(([id, lbl, val]) => (
                    <OpcionCard key={id} activo={canal === id} onClick={() => val && setCanal(id)} style={{ flex: "1 1 220px", opacity: val ? 1 : 0.5, cursor: val ? "pointer" : "default" }}>
                      <div style={{ fontSize: 13, fontWeight: 600, color: C.ink }}>{lbl}</div>
                      <div style={{ fontSize: 11.5, color: C.inkSoft, marginTop: 2 }}>{val || "No registrado — agrégalo en Mi Perfil"}</div>
                    </OpcionCard>
                  ))}
                </div>
              </div>
              {error && <div style={{ display: "flex", alignItems: "center", gap: 7, background: C.dangerBg, border: "1px solid #FCA5A5", borderRadius: 8, padding: "9px 12px", marginBottom: 16 }}><AlertCircle size={14} color={C.danger} /><span style={{ fontSize: 12.5, color: C.danger }}>{error}</span></div>}
              <button className="ppa-btn" onClick={enviar} style={{ ...S.primaryBtn, width: "100%", height: 46, fontSize: 14 }}>Enviar mensaje</button>
              <p style={{ fontSize: 11.5, color: C.inkSoft, margin: "14px 0 0", lineHeight: 1.5 }}>Si quieres presentar un reclamo o una sugerencia, usa <EnlaceContacto onClick={() => mostrarToast("OIRS — próxima puerta a construir.")}>OIRS</EnlaceContacto>.</p>
            </div>
          </>
        )}
      </div>
      {toast && <ToastMsg msg={toast} />}
    </div>
  );
}

/* ══════ RAÍZ ══════ */

export default function PortalPaciente() {
  const [usuario, setUsuario] = useState(null);
  const [vista, setVista] = useState("dashboard");
  const [contactoPrefill, setContactoPrefill] = useState(null);
  const abrirContacto = (prefill = null) => { setContactoPrefill(prefill); setVista("contacto"); };
  const [toast, setToast] = useState("");
  const mostrarToast = (msg) => { setToast(msg); setTimeout(() => setToast(""), 2800); };
  const onActualizarUsuario = (cambios) => setUsuario(prev => ({ ...prev, ...cambios }));
  const handleAbrirFuncion = (item) => {
    if (item.id === "pac_medica" || item.id === "pac_examenes_apoyo") { setVista(item.id); return; }
    if (item.id === "pac_farmacia") { setVista("farmacia"); return; }
    if (item.id === "pac_activa_llegada") { setVista("activa_llegada"); return; }
    if (item.id === "pac_certificados") { setVista("certificados"); return; }
    if (item.id === "pac_perfil") { setVista("perfil"); return; }
    if (item.id === "pac_contactos_emergencia") { setVista("contactos_emergencia"); return; }
    if (item.id === "pac_consents") { setVista("consentimientos"); return; }
    if (item.id === "pac_ficha") { setVista("ficha_clinica"); return; }
    if (item.id === "pac_traslado") { setVista("movilizacion"); return; }
    if (item.id === "pac_contacto") { abrirContacto(); return; }
    mostrarToast(`${item.label} — próxima puerta a construir.`);
  };

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=Public+Sans:wght@400;500;600;700&family=IBM+Plex+Mono:wght@400;500&display=swap');
        .ppa-input:focus { border-color: ${C.navy} !important; background: #fff !important; }
        .ppa-input::placeholder { color: ${C.slate400}; }
        .ppa-btn { transition: opacity 0.15s; } .ppa-btn:hover { opacity: 0.9; }
        .ppa-link { cursor: pointer; } .ppa-link:hover { text-decoration: underline; }
        .ppa-row { transition: border-color 0.15s; } .ppa-row:hover { border-color: ${C.navy}88 !important; }
        .ppa-func { transition: box-shadow 0.15s, border-color 0.15s; } .ppa-func:hover { box-shadow: 0 4px 14px rgba(27,58,102,0.12); border-color: ${C.navy}55 !important; }
        .ppa-opt:hover { border-color: ${C.navy}99 !important; }
        .ppa-tab { transition: color 0.15s; }
        .ppa-cal-nav { transition: background 0.15s; } .ppa-cal-nav:hover:not(:disabled) { background: ${C.slate100} !important; }
        .ppa-cal-dia { transition: background 0.12s; } .ppa-cal-dia:hover:not(:disabled):not(.sel) { background: ${C.slate100} !important; }
      `}</style>
      {!usuario ? <VistaAcceso onLogin={(u) => { setUsuario(u); setVista("dashboard"); }} mostrarToast={mostrarToast} />
        : vista === "pac_medica" ? <VistaAgendaMedica usuario={usuario} onVolver={() => setVista("dashboard")} titulo="Atención Médica" especialidades={ESPECIALIDADES_MEDICAS} />
        : vista === "pac_examenes_apoyo" ? <VistaAgendaMedica usuario={usuario} onVolver={() => setVista("dashboard")} titulo="Exámenes y Apoyo Clínico" especialidades={ESPECIALIDADES_EXAMENES} />
        : vista === "farmacia" ? <VistaFarmacia usuario={usuario} onVolver={() => setVista("dashboard")} />
        : vista === "activa_llegada" ? <VistaActivaLlegada usuario={usuario} onVolver={() => setVista("dashboard")} />
        : vista === "certificados" ? <VistaCertificados usuario={usuario} onVolver={() => setVista("dashboard")} />
        : vista === "perfil" ? <VistaPerfilPaciente usuario={usuario} onVolver={() => setVista("dashboard")} onActualizarUsuario={onActualizarUsuario} onContacto={abrirContacto} />
        : vista === "contactos_emergencia" ? <VistaContactosEmergencia usuario={usuario} onVolver={() => setVista("dashboard")} onActualizarUsuario={onActualizarUsuario} />
        : vista === "consentimientos" ? <VistaConsentimientos usuario={usuario} onVolver={() => setVista("dashboard")} onActualizarUsuario={onActualizarUsuario} />
        : vista === "ficha_clinica" ? <VistaFichaClinica usuario={usuario} onVolver={() => setVista("dashboard")} onNavegar={setVista} />
        : vista === "movilizacion" ? <VistaMovilizacion usuario={usuario} onVolver={() => setVista("dashboard")} onActualizarUsuario={onActualizarUsuario} onContacto={abrirContacto} />
        : vista === "contacto" ? <VistaContactoAyuda usuario={usuario} onVolver={() => setVista("dashboard")} prefill={contactoPrefill} />
        : <VistaDashboard usuario={usuario} onAbrirFuncion={handleAbrirFuncion} onCerrarSesion={() => { setUsuario(null); setVista("dashboard"); }} />}
      {toast && <ToastMsg msg={toast} Icon={Lock} />}
    </>
  );
}
