# AXON — Módulo Farmacia Central y Bodega · Dossier de Estado
## Para retomar el trabajo sin releer la conversación completa

**Fecha de este export:** 26-10-2026 — agrega la Parte 17 (correcciones quirúrgicas de la segunda auditoría) la Parte 18 (propuesta de diseño) la Parte 19 (decisiones de las 2 auditorías + 18.1 implementado) la Parte 20 (18.2 cuarentena implementada) la Parte 21 (correcciones chicas de la auditoría cerradas) la Parte 22 (18.3 lote + posición de stock + despacho por vencimiento) la Parte 23 (selección manual de lote + plan del contrato entre dominios) y la Parte 24 (decisiones adoptadas, stock mínimo sobre lo despachable y contrato v0.1 escrito); anterior 25-09-2026 — agrega la Parte 13 (triage de pendientes, ahora cerrado, + diseño de Cuadratura y escaneo de Balances), la Parte 14 (primera auditoría técnica verificada), la Parte 15 (correcciones + Cuadratura de Stock implementadas) y la Parte 16 (segunda auditoría técnica + Balances #9/#16, implementado).
**Alcance:** Prototipo funcional integrado en `HISClinico_Layer1.jsx` (no es una app aparte) + arquitectura documentada + sincronización con main, Contabilidad, y la propuesta de evolución "AXON Supply Core".

---

## 🔑 Empieza por aquí — cómo continuar este trabajo en un chat nuevo

Los 2 archivos que cambian en cada sesión de trabajo son `HISClinico_Layer1.jsx` y este dossier — hay que subir siempre la versión más reciente de ambos al Proyecto (reemplazando), **nunca solo como adjunto del chat**, para que cualquier chat nuevo los tenga disponibles automáticamente. El resto de los archivos del Proyecto sigue vigente tal cual, sin tocar: `arquitectura_farmacia_bodega.md`, `sincronizacion_farmacia_bodega_main.md`, `VISION_SUPPLY_CORE_FUTURO.md`, `AXON_SUPPLY_CORE_CIMIENTOS_ARQUITECTURA.md`, `AXON_Supply_Core.docx`, `Auditoria_SupplyCore.docx`, `Auditoria_SupplyCore2.md`, los 2 de Contabilidad, los de Hospitalización, y los TXT/MD de "Respuestas para el equipo Farmacia y bodega" — este dossier ya absorbió todo lo accionable de esos dos últimos audits (Partes 14 y 16), así que un chat nuevo no necesita releerlos para seguir trabajando. En un chat nuevo, basta con decir algo como "continuemos con Farmacia y Bodega, lee el dossier" — no hace falta pegar contexto adicional.

**Reglas de trabajo** (las diste al iniciar este proyecto — se repiten aquí por si un chat nuevo no las hereda solas):
1. Tus respuestas a mis preguntas llegan como un TXT o PDF llamado "Respuestas para el equipo Farmacia y bodega + (correlativo)".
2. Cuando el chat llegue a su límite, dirás solo "continúa" para que retome desde donde quedamos.
3. Si algo no queda claro, pregunto antes de asumir; busco en la web normas técnicas/legales/tecnológicas cuando haga falta, con los hospitales más grandes y tecnológicos del mundo como referencia. Ninguna decisión mayor sin que ambos la confirmemos.
4. Respuestas o preguntas largas van al dossier del proyecto; las cortas van en el chat.

**Dónde quedamos:** Supply Core fue aprobado por main. Triage de pendientes cerrado (Parte 13.2-13.3): Eventos Adversos/Seguridad, Sinergia, Reuniones y Calendario quedaron fuera del backlog del módulo (capabilities transversales, decisión del usuario). Dos auditorías técnicas externas verificadas contra el código real (Partes 14 y 16) y sus hallazgos corregidos. **Ya están implementados: Trazabilidad (#8/#15), Cuadratura de Stock (Parte 15) y Balances (#9/#16, Parte 16)** — con eso, de la lista "construible ahora, sin depender de nadie" de la Parte 13.3 no queda ningún ítem sin construir. Queda un solo hilo genuinamente abierto para la próxima sesión: la conversación de diseño de cuarentena/lote propio (hallazgos #1, #4, #5 de la Parte 14.2) — deliberadamente no se mezcló con Cuadratura ni con Balances. Limitación menor documentada, no bloqueante: PROPIA no aparece en Balances Bodega (Parte 16.2.1).

---

## PARTE 0 · Archivos de referencia

### Nuestros 3 archivos (export original, sin cambios)

| Archivo | Qué es |
|---|---|
| `HISClinico_Layer1.jsx` | El shell completo de HIS-Clínico con el módulo "Farmacia Central y Bodega" integrado y funcional. Este es el archivo que se abre/ejecuta. |
| `arquitectura_farmacia_bodega.md` | Documento de arquitectura canónico: los 27 submódulos, modelos de datos, y la tabla de las 41 unidades reales con sub-farmacia/sub-bodega. |
| `sincronizacion_farmacia_bodega_main.md` | Documento vivo de sincronización con el equipo main (roles, seguridad, tenant) y con Contabilidad — preguntas, respuestas recibidas, y puertas etiquetadas. |

`FarmaciaBodegaApp.jsx` (de una etapa anterior, standalone) sigue obsoleto — todo su contenido útil ya está dentro de `HISClinico_Layer1.jsx`.

### Documentos incorporados en esta sincronización (25-08-2026)

| Archivo | Qué es | Fecha propia del documento |
|---|---|---|
| `AXON_Supply_Core.docx` | Propuesta de evolución arquitectónica de Farmacia/Bodega hacia un motor reutilizable "AXON Supply Core" (perfiles AXON Health / AXON Core / AXON Core Lite) | Sin fecha explícita en el documento — pendiente confirmar cuándo se generó y de dónde sale |
| `AXON_Contabilidad_Documento_Maestro_Arquitectura_y_Orquestacion.docx` | Arquitectura financiera completa de AXON: Control Plane, capas de dinero, eventos de dominio, tenant registry | 24-08-2026 |
| `AXON_Contabilidad_Observaciones_y_Recomendaciones_Desarrollo.docx` | Recomendaciones internas del equipo de Contabilidad sobre sus propias 12 secciones | 24-08-2026 |

### Documento nuevo (06-09-2026): visión futura consolidada

`VISION_SUPPLY_CORE_FUTURO.md` — consolida en un solo lugar el pensamiento estratégico repartido en `AXON_Supply_Core.docx`, `respuestas_para_SUPPLY_CORE__farmacia_central_y_bodega_.docx` y `AXON_Hospitalizacion_SupplyCore_Guia_Maestra_v1_0.docx` (modelo de negocio AXON Holding, separación Supply Core/Account Core validada contra SAP/Oracle, complejidad progresiva de Core Lite, riesgos identificados). Es un documento de referencia para cuando Supply Core se apruebe — **no afecta el trabajo diario sobre este dossier**. Ver la sección "Empieza por aquí" arriba: todavía no está subido a los archivos del Proyecto.

### Documento nuevo (09-09-2026): cimientos concretos de Supply Core

`AXON_SUPPLY_CORE_CIMIENTOS_ARQUITECTURA.md` — el diseño concreto que sigue a la visión: modelo de datos Item/SupplyNode/ledger, el catálogo de tipos de evento derivado directamente del prototipo (incluido `MOVIMIENTO_TIPO_META`, ver Parte 12), el contrato de `SupplyRequest` hacia módulos satélite, y el hallazgo de que cada tipo de nodo ya construido (Central/Sub/PROPIA/ClienteExterno) mapea a `SupplyNode` sin cambiar de forma. Mismo estatus que el anterior: referencia para cuando se apruebe, no bloquea el trabajo diario. Tampoco está subido todavía a los archivos del Proyecto.

Detalle completo de qué aporta cada uno, en la Parte 5.

---

## PARTE 1 · Qué está funcional hoy dentro de `HISClinico_Layer1.jsx`

Entrar por el sidebar → "Farmacia Central y Bodega" (grupo Operaciones). Estructura de navegación: `[Dashboard] [Farmacia Central] [Bodega]` arriba + fila de compartidos (Clientes Externos, Gestión Proveedores, Balances Unidades, Eventos Adversos, Eventos Seguridad, Sinergia, Reuniones, Calendario, Bodega Propia, Soporte, Mantenciones).

### Dashboard (#1) — funcional
KPIs calculados de datos reales del prototipo (no inventados): solicitudes pendientes, en curso, ítems bajo mínimo, alertas de caducidad, tiempo promedio de despacho, unidades con alerta sobre 41. Gráfico semanal Farmacia vs. Bodega.

### Farmacia Central → #3 Stock y Sub-farmacias — funcional
- Las **24 unidades reales** confirmadas (Imagenología, Urgencias, Laboratorio, At. Quirúrgica, Hospitalización, y el resto de la lista de "ambas").
- Solo 4 unidades con stock de ejemplo cargado (Imagenología, Urgencias, Laboratorio, At. Quirúrgica) — el resto muestra "Sin datos cargados", no números inventados.
- Catálogo de 8 ítems (4 medicamentos + 4 insumos clínicos) con **modelo de 3 niveles**: Concepto Fármaco (DCI + SNOMED CT ilustrativo) → Producto Comercial (marca, laboratorio, Registro ISP) → Código CENABAST. Visible como subtítulo en la tabla de stock.
- Código de barra, stock mínimo y máximo (PAR sugerido) por ítem y por unidad.

### Farmacia Central → #5 Solicitud de Pedidos — funcional
Cola de solicitudes con **flujo de 2 filtros**: técnico de la unidad solicita → coordinador de la unidad autoriza (primer filtro interno) → Farmacia Central aprueba → prepara → despacha (cantidad ajustable según disponible) → la unidad confirma recepción (detecta completo/parcial/excedente automáticamente). Cada rol ve solo las acciones que le corresponden.

### Bodega → #12/#14 — funcional, mismo patrón que Farmacia
Las 41 unidades completas en el selector. Catálogo separado de 6 ítems no clínicos (papel, tóner, bolsas de basura, cloro gel, papel higiénico, lápiz pasta) — nunca se mezcla con el catálogo clínico de Farmacia. Mismo ciclo de 2 filtros, folios con prefijo `SOLB`.

### Bodega e Insumos Propios (#25, compartido) — funcional (nuevo)
Inventario interno de la propia unidad de Farmacia Central y Bodega (papel térmico, etiquetas, tóner, papel carta) — no confundir con la Bodega Central (#11). Reutiliza exactamente los mismos componentes de Stock y Solicitudes que las otras 41 unidades, tratando "Farmacia y Bodega" como una unidad más que le pide reposición a Bodega Central. No se agregó a la lista de las 41 unidades reales (ese conteo canónico no se tocó) — es una unidad adicional, separada, con su propio stock/folio (prefijo `SOLP`).

### Clientes Externos (#18, compartido) — funcional (nuevo)
Directorio de clientes externos (préstamo/convenio/venta/donación — nunca sub-farmacia ni sub-bodega interna) con ficha expandible y registro de nuevos clientes. Despacho a cliente descuenta stock central real, desde Farmacia o desde Bodega según se elija (nunca mezclando catálogos). Para préstamo/convenio, seguimiento de devolución esperada (pendiente/devuelto/devuelto-parcial/no-devuelto) que también reingresa stock al confirmarse. 3 clientes de ejemplo cargados (uno por cada estado: activo con convenio, activo con donación, suspendido).

### Gestión Proveedores (compartido) — funcional
- 6 proveedores de ejemplo (3 Farmacia, 3 Bodega), modelo unificado con campo `dominio`.
- Directorio con filtro Todos/Farmacia/Bodega, ficha expandible (contacto, condiciones comerciales, evaluación).
- **"Hacer pedido"**: por proveedor, catálogo específico de lo que ESE proveedor vende (`FB_CATALOGO_PROVEEDOR`), con presentación de compra real (caja/paquete/bidón), factor de conversión a unidades de dispensación, cantidad mínima de compra, y código propio del proveedor.
- Seguimiento del pedido (enviado → confirmado → en tránsito → recibido total) — al recibir, el stock ingresa de verdad al Central correspondiente.

### Roles simulados (selector en el header)
`Farmacia/Bodega Central` · `Coordinador de Unidad` · `Encargado Sub-farmacia/Bodega` — placeholders hasta que el roles.config.js real esté listo (ver Parte 4).

### Farmacia Central → #4 y Bodega → #13 Recepciones — funcional (nuevo, ver Parte 7)
Registro formal de recepción desde proveedores, con o sin orden de compra vinculada. El stock central ahora sube solo al aceptar una recepción, por la cantidad realmente recibida — reemplaza el atajo anterior donde "recibido total" en Gestión Proveedores bumpeaba stock directo por lo solicitado. Lotes con vencimiento capturados en la recepción alimentan el widget de caducidad del Dashboard.

### Farmacia → #8 y Bodega → #15 Trazabilidad — funcional (nuevo, ver Parte 12)
Registro real de movimientos de stock (`FbTrazabilidadView`, tabla filtrable por ítem y tipo), alimentado desde los puntos donde el stock realmente cambia: recepción de proveedor, despacho a unidad, confirmación de recepción en unidad, despacho a cliente externo y devolución de cliente externo. Insumos Propios (#25) también registra en `movimientosBodega`, comparte Bodega Central.

### Todavía en "Próximamente" (sin construir)
Farmacia: #6 Delivery, #7 Recetas Retenidas. (#9 y #16 Balances ya construidos, Parte 16.)
Bodega: —
Compartidos: Balances Unidades, Eventos Adversos, Eventos Seguridad, Sinergia, Reuniones, Calendario, Soporte, Mantenciones (todo excepto Gestión Proveedores, Clientes Externos y Bodega e Insumos Propios). Cuadratura/Ajuste de stock forzado.

---

## PARTE 2 · Decisiones de arquitectura ya tomadas (no volver a discutir salvo que algo cambie)

1. **Farmacia y Bodega es UN módulo**, no dos — comparten los mismos 5 roles reales (`t_farm_*`) y la misma fila de compartidos.
2. **41 unidades reales**, no 4 genéricas: 24 con sub-farmacia + sub-bodega, 17 solo con sub-bodega, Salud Colectiva sin ninguna (deriva a la unidad clínica que corresponda). Tabla completa en `arquitectura_farmacia_bodega.md`.
3. **Separación de roles estricta**: quien solicita nunca es quien aprueba/despacha, y viceversa. Filtro de 2 etapas (coordinador de unidad → Farmacia/Bodega Central).
4. **Catálogo de Farmacia (clínico) y de Bodega (no clínico) nunca se mezclan** — listas, stock y proveedores completamente separados.
5. **Compra por presentación, no por unidad de dispensación** — se pide en cajas/paquetes, el sistema convierte a unidades reales al recibir.
6. **Modelo de 3 niveles para medicamentos** (DCI/SNOMED → marca/ISP → CENABAST) — solo aplica a Farmacia, no a Bodega.
7. **Gestión Proveedores unificada** con separación interna por dominio — reemplaza los antiguos #10/#17 como pestañas separadas.
8. **No se replica el "protocolo fantasma"** (bypass de auditoría para un rol) en ningún ajuste futuro de stock — motivo obligatorio y trazabilidad siempre, sin excepción de rol, validado contra práctica real de auditoría de inventario.
9. **Farmacia/Bodega y Contabilidad se alinean, no se fusionan** — cada módulo sigue con su propia forma de datos hasta que llegue una etapa de integración explícita.
10. **Nunca se construye algo que otro módulo ya resuelve** — ej. Nota de Crédito ya existe en `ContabilidadAdquisiciones.jsx`, no se construyó una versión propia.

---

## PARTE 3 · Principios de trabajo con este proyecto

- **Ninguna decisión sin aprobación** — cuando algo no está confirmado, se pregunta antes de escribir código, no se asume.
- **Los datos de ejemplo se marcan siempre como ejemplo** — nunca se presentan como si fueran el catálogo oficial de AXON.
- **Verificación antes de entregar** — balance de llaves/paréntesis, chequeo de íconos contra el import real, y compilación de sintaxis con `tsc` en cada cambio al `.jsx`, antes de copiar a `outputs` y presentar.
- **El entorno de cómputo es efímero** — se reinicia entre turnos. Los únicos archivos persistentes son los de `/mnt/user-data/outputs/`. Si el entorno se reinicia a mitad de una tarea, se recuperan desde ahí antes de seguir editando.
- **Hechos verificados por búsqueda web cuando corresponde** (leyes, decretos, estándares, plataformas de referencia) — nunca se toma un documento externo al pie de la letra sin confirmar sus datos verificables.

---

## PARTE 4 · Pendientes reales (no resueltos, no bloquean seguir trabajando)

1. **`roles.config.js` real** — el usuario lo está terminando. Los 3 roles simulados quedan hasta que esté listo; cuando llegue, hay que mapear "Encargado de Sub-farmacia/Bodega" a los roles clínicos reales de cada unidad (no hay un rol único equivalente).
2. **Catálogo oficial de insumos de AXON** — todo el catálogo actual (Farmacia y Bodega) es de ejemplo.
3. **Integración real con Contabilidad** — puertas etiquetadas documentadas (16 de su lado, 21+ del nuestro en `sincronizacion_farmacia_bodega_main.md`), pero sin conectar código todavía. Diferencia de forma detectada: `recibirRequisicion()` de Contabilidad espera una necesidad a la vez; nuestro flujo de pedido es multi-ítem a un proveedor ya elegido — falta decidir el adaptador cuando se integre.
4. **Gap real en Contabilidad** (no nuestro): `bodega` no existe como centro de costo, solo `farmacia`. Sin notificación de pago a proveedor. Sin concepto de presupuesto/tope.
5. **CENABAST / registro ISP** en el catálogo son de ejemplo — pendiente el dato oficial real por producto.
6. **Terminología de `AXON_Supply_Core.docx`** (`SupplyNode`, `SupplyEvent`, capability engine) — no urgente; tenerla en mente al nombrar cosas nuevas para que sea más fácil de generalizar después, sin que esto cambie el diseño actual. Ver Parte 5.2.
7. **Take Rate "Acceso a Red Interna de Farmacia/Bodega"** — todavía sin aclarar; ubicación exacta ya entregada al usuario para que revise el Excel fuente (ver Parte 5.5.a). **Delivery Hospitalizado/Urgencia** — confirmado que sí lleva cobro asociado, pero es exclusivo de AXON Health (ver Parte 5.5.b); afecta el diseño de #6 cuando se construya.

---

## PARTE 5 · Sincronización 25-08-2026 — Documentos nuevos incorporados

### 5.1 Contexto

El dossier anterior (23-08-2026) no incluía tres documentos que llegaron después: `AXON_Supply_Core.docx`, `AXON_Contabilidad_Documento_Maestro_Arquitectura_y_Orquestacion.docx` y `AXON_Contabilidad_Observaciones_y_Recomendaciones_Desarrollo.docx`. Esta sección deja registro de qué aportan, dónde confirman lo ya sabido, y qué preguntas nuevas abren — sin haber tomado ninguna decisión (pendiente de confirmación, según el principio de trabajo #1 de la Parte 3).

### 5.2 `AXON_Supply_Core.docx`

Propone evolucionar el módulo actual hacia un motor común reutilizable ("AXON Supply Core") que sirva tanto a AXON Health (perfil hospitalario completo, el que ya tenemos) como a AXON Core (institucional configurable) y AXON Core Lite (profesional independiente).

**Puntos clave:**
- Es explícito en que **no se parte de cero**: el JSX actual pasa a ser "la referencia operacional" desde la cual se generaliza, no una versión descartable.
- Su propio mapa de fases (sección 28) empieza con **"Fase 1: Preservar HISClinico_Layer1.jsx"** e **"Inventariar entidades y estados actuales"** — no pide detener ni tocar el desarrollo actual. Las fases de extracción de modelo común, tenant scope y capability engine son posteriores.
- Introduce vocabulario que generaliza lo que ya existe, sin contradecirlo: `SupplyNode` generaliza Farmacia Central / Sub-farmacia / Bodega Central / Sub-bodega; `SupplyEvent` (con `tenantId`, `actorId`, `sourceNode`, `destinationNode`, etc.) generaliza `MovimientoFarmacia`/`MovimientoBodega`.
- Reitera (no descubre de nuevo) el hallazgo ya conocido de `sincronizacion_farmacia_bodega_main.md` B1: los roles `farmaceutico`/`encargado_unidad` del prototipo son placeholders, no el modelo final.
- Su sección 20 (Matriz Maestra de Configuración) confirma que Delivery, Recetas Retenidas y Clientes Externos deben quedar como **capacidades configurables** (`capability.delivery = true/false`, etc.), no universales — coincide con el criterio ya aplicado (ej. Delivery limitado a Hospitalización/Urgencia domiciliaria + Portal Paciente).

**No se encontraron contradicciones** con las 10 decisiones de arquitectura ya tomadas (Parte 2) — todo lo que propone es aditivo o es una generalización posterior.

**Estado:** no bloquea ni cambia el trabajo actual. Ver pregunta abierta 5.5.c.

### 5.3 Contabilidad — Documento Maestro de Arquitectura

Es la arquitectura financiera completa de AXON (no específica de Farmacia/Bodega), pero contiene piezas directamente relevantes:

**a) Confirma nuestro módulo en su catálogo maestro** (Apéndice A, ítem 17: "Farmacia Central y Bodega") — mismo nombre, sin discrepancia.

**b) Propone contratos de eventos/API que probablemente sean la futura superficie de integración** (sección 24, dominio "Procurement"): `createRequisition`, `approvePO`, `receiveGoods`, `matchInvoice`; y en la lista de eventos de dominio (sección 12): `PurchaseOrderApproved`, `GoodsReceived`, `VendorInvoiceMatched`, `VendorInvoiceDisputed`. Es consistente con lo ya sabido por `sincronizacion_farmacia_bodega_main.md` (la función real `recibirRequisicion()` y la diferencia de forma ya detectada: ellos esperan una necesidad a la vez, nuestro "Hacer pedido" es multi-ítem) — ahora con nombres de eventos más formales para cuando se conecte de verdad. No cambia nada de lo construido; es información para la integración real futura.

**c) Hallazgo nuevo — Take Rate incluye "Acceso a Red Interna de Farmacia" y "Acceso a Red Interna de Bodega"** (sección 18.2, ítems #28 y #29 de una lista de 29 servicios monetizables de AXON Health). No aparece mencionado en ningún documento nuestro hasta ahora. → Pregunta abierta 5.5.a.

**d) Hallazgo nuevo — Delivery aparece 3 veces en el Take Rate, no 1**: ítems #21 "Delivery Medicamento Ambulatorio", #22 "Delivery Medicamento Hospitalizado", #23 "Delivery Medicamento Urgencia". Hasta ahora, `sincronizacion_farmacia_bodega_main.md` (puerta #6 de la tabla F) solo confirmaba el gancho de cobro (`TRANSACTION_EVENTS.TRASLADO`) para el caso **ambulatorio** vía Portal Paciente (gating: solo `PACIENTE_PREMIUM`). Los casos Hospitalizado y Urgencia domiciliaria estaban documentados como puramente operacionales (los activa la unidad solicitante, no Farmacia — puerta #4). Que aparezcan en la hoja de Take Rate sugiere que también podrían llevar cobro asociado. → Pregunta abierta 5.5.b.

**e) Advertencia que ya coincide con nuestro criterio** (recuadro "SEPARACIÓN NECESARIA", sección 18.2): el Take Rate es monetización de plataforma, no debe convertirse en descuento oculto de los ingresos del tenant sin definición comercial explícita. Coincide con el principio ya aplicado en `sincronizacion_farmacia_bodega_main.md` (ninguna comisión se resta implícitamente).

### 5.4 Contabilidad — Observaciones y Recomendaciones para Desarrollo

Documento interno de Contabilidad sobre sus propias 12 secciones. No aporta hallazgos nuevos específicos de Farmacia/Bodega más allá del Documento Maestro, pero confirma que sus prioridades P0 incluyen exactamente lo que ya teníamos anotado como pendiente compartido: "Contrato de datos / IDs / ownership entre módulos" (coincide con la Parte 4, punto 3 — la diferencia de forma entre `recibirRequisicion()` y nuestro pedido multi-ítem). Nada que contradiga el estado actual.

### 5.5 Preguntas abiertas — estado tras `Respuestas para el equipo Farmacia y bodega + 1.txt`

**a) "Acceso a Red Interna de Farmacia/Bodega" — SIGUE ABIERTA.** El usuario no recuerda el detalle y necesita revisarlo. Ubicación exacta entregada: `AXON_Contabilidad_Documento_Maestro_Arquitectura_y_Orquestacion.docx`, sección 18.2 "Take Rate AXON Health", ítems #28 y #29 de una tabla de 29 servicios. El docx no da más detalle que el nombre de la línea — si hay más contexto, probablemente esté en la hoja Excel fuente que ese documento cita ("Estructuración y arquitectura(1).xlsx", hoja "Take Rate AXON Health"), que no forma parte de los archivos de este proyecto.

**b) Delivery Hospitalizado/Urgencia — RESUELTA.** Sí lleva cobro asociado, pero es una **característica exclusiva de AXON Health** (el "hospital clínico digital" que hace atención domiciliaria de todo tipo) — AXON Core y AXON Core Lite no la tienen. Los módulos de Urgencias y Hospitalización todavía no separan/crean esa parte por su lado. No se le pidió al usuario averiguar nada ahí por ahora — no es bloqueante para diseñar #6: se puede construir con el flujo operacional ya documentado (unidad solicita → Farmacia despacha vía dron/vehículo → tracking) y dejar el gancho de cobro como puerta etiquetada (mismo patrón que el caso ambulatorio), pendiente hasta que Urgencias/Hospitalización lo formalicen. Cuando eso ocurra, lo útil sería conocer: (i) el contrato de datos exacto de la solicitud de delivery domiciliario desde esos módulos, y (ii) si el evento de cobro es el mismo `TRANSACTION_EVENTS.TRASLADO` ya documentado para el caso ambulatorio o uno distinto.

**c) AXON Supply Core — RESUELTA.** ~~Confirmado por el usuario: todavía no está aprobado desde main.~~ **DESACTUALIZADO — Supply Core fue aprobado por main (ver Parte 13 y cabecera).** Texto histórico: no se hacía ningún trabajo de refactorización hacia Supply Core mientras tanto — se sigue construyendo Farmacia/Bodega en el modelo actual, sin referencias a `SupplyNode`/`SupplyEvent` en el código real (la Parte 4, punto 6 de este dossier queda solo como nota mental para nombrar cosas de forma más fácil de generalizar después, nada más).

### 5.6 Próximos pasos — recomendación entregada, pendiente confirmación final

Con (b) y (c) resueltas, la recomendación es **partir con Recepciones (#4 Farmacia / #13 Bodega)**:
- Cierra la Fase 2 (Abastecimiento) — la única pieza que falta ahí.
- No depende de ningún otro módulo (proveedor → recepción → stock central es un ciclo interno de Farmacia/Bodega).
- No depende de las preguntas 5.5.a ni 5.5.b — ninguna de las dos cambia cómo se recibe mercadería de un proveedor.
- Formaliza un atajo real que hoy existe: en `GestionProveedoresView`, cuando un pedido llega a "recibido total", el stock central se actualiza directo (`onAvanzar` → suma a `centralStock`) sin pasar por un registro de recepción real (checklist de verificación, lote/vencimiento, embalaje íntegro, aceptada/aceptada-con-observaciones/rechazada). Construir #4/#13 reemplaza ese atajo por el flujo formal ya modelado en `arquitectura_farmacia_bodega.md`.

**Clientes Externos (#18)** queda como candidato siguiente, pero se prefiere esperar a que se resuelva 5.5.a (Red Interna) antes de tocarlo, por si está relacionado.

**Confirmado por el usuario** — se construye Recepciones (#4/#13) ahora. Ver Parte 7 para el detalle de lo implementado.

---

## PARTE 6 · Glosario de Mapeo — Modelo actual ↔ AXON Supply Core

> Documentación de respaldo, sin efecto en el código actual. Sirve para el día que main apruebe Supply Core y haya que conversar en el mismo idioma. Basado en el listado de entidades de la Fase 3 de `AXON_Supply_Core.docx` (sección 28): Item, Supplier, SupplierItem, Stock, Lot, SupplyNode, Request, Receipt, Movement, TraceabilityEvent.

| Entidad Supply Core | Farmacia (hoy) | Bodega (hoy) | Nota |
|---|---|---|---|
| `Item` | `Medicamento`, `InsumoClinico` | `InsumoBodega` | Catálogos separados se mantienen — `Item` es solo la superclase conceptual, no implica fusionarlos. |
| `Supplier` | `Proveedor` (dominio: farmacia) | `Proveedor` (dominio: bodega) | Ya unificado con campo `dominio`, tal como recomienda la sección 6 del documento. |
| `SupplierItem` | Filas de `FB_CATALOGO_PROVEEDOR` | (mismo modelo) | Ya calza casi campo a campo: `codigoProveedor`→`supplierItemCode`, `presentacionCompra`→`purchasePresentation`, `unidadesPorPresentacion`→`unitsPerPresentation`, `cantidadMinimaCompra`→`minimumPurchaseQuantity`, `precioReferencialCaja`→`referencePrice`. |
| `Stock` | `stock` de `Medicamento`/`InsumoClinico` (central) + `StockSubFarmacia` | `stock` de `InsumoBodega` (central) + `StockSubBodega` | Dos niveles: central y por sub-nodo. |
| `Lot` | `Lote` | `Lote` (mismo modelo, se usa menos en Bodega) | |
| `SupplyNode` | Farmacia Central, Sub-farmacia (24 unidades) | Bodega Central, Sub-bodega (41 unidades) | Generaliza "nodo de la red". Las 41 unidades siguen siendo datos del tenant, no de Supply Core (sección 5 del documento). |
| `Request` | `SolicitudReposicionSubFarmacia` | `SolicitudReposicionSubBodega` | Máquina de estados de 2 filtros ya construida — el propio documento la cita como patrón reutilizable (sección 8.3). |
| `Receipt` | `RecepcionFarmacia` (#4) | `RecepcionBodega` (#13) | Justo lo que se construye en esta sesión (ver Parte 7). |
| `Movement` / `SupplyEvent` | `MovimientoFarmacia` | `MovimientoBodega` | Trazabilidad (#8/#15), todavía no construida. `SupplyEvent` (sección 8.6) le agrega `tenantId`/`actorId` — campos que hoy no existen (gaps B5/B6 ya conocidos). |
| *(sin nombre formal en el documento)* — Orden de Compra | `PedidoFarmacia` | `PedidoBodega` | Ya funcional. Los eventos que propone Contabilidad (`PurchaseOrderApproved`, `GoodsReceived`) probablemente terminen siendo la interfaz de esto hacia afuera. |
| *(capacidad, no clase)* `externalSupplyRelationships` | `ClienteExterno` / `DespachoClienteExterno` (#18) | (mismo) | Capacidad institucional, no universal — coincide con la sección 12 del documento. Posible relación con la pregunta abierta sobre "Red Interna" (Parte 5.5.a, todavía abierta). |
| *(capacidad)* `capability.delivery` | `OrdenDelivery`, `ModalidadDelivery` (#6) | No aplica | Ya sabemos que el cobro asociado es exclusivo de AXON Health (Parte 5.5.b) — encaja con el patrón `capability.x = true/false` de la sección 20 del documento. |
| *(sin generalizar, a propósito)* | `RecetaRetenida` (#7) | No aplica | El propio documento (sección 8.5) dice explícitamente que esto NO se generaliza — queda como capacidad específica de Farmacia. |

Campos que Supply Core espera y que hoy no existen en ningún lado del prototipo (mismos gaps B5/B6 ya documentados, no son nuevos): `tenantId`, `actorId` (hoy es un `role` string genérico, no un CUT/CUP real), `facility`/`organizationScope`.

---

## PARTE 7 · Recepciones (#4 Farmacia / #13 Bodega) — implementado

**Qué se construyó**, siguiendo el modelo de `RecepcionFarmacia`/`RecepcionBodega` de `arquitectura_farmacia_bodega.md`:

- `FbNuevaRecepcionForm` — formulario de recepción: proveedor, orden de compra vinculada (opcional), guía de despacho (obligatoria), N° de factura (opcional), tabla de ítems (lote, fecha de vencimiento, cantidad facturada vs. recibida — editables por separado para detectar diferencias, cumple especificaciones, observaciones), checklist de verificación (embalaje íntegro, documentación completa, cadena de frío conforme — este último solo en Farmacia), observaciones generales. Dos acciones: "Registrar recepción" (calcula automáticamente `aceptada` vs. `aceptada-con-observaciones` según el checklist y las diferencias por ítem) o "Rechazar recepción" (estado `rechazada`, no toca stock).
- `FbRecepcionCard` — tarjeta de una recepción ya registrada, mostrando folio, proveedor, orden de compra vinculada si existe, ítems con cantidad recibida vs. facturada y diferencias resaltadas, y estado del checklist.
- `FbRecepcionesView` — la vista de la pestaña, con botón "Nueva recepción" y el listado histórico. Sirve para Farmacia y Bodega con los mismos componentes (parametrizados por `dominio`, `catalogo`, `proveedores`, y `mostrarCadenaFrio`), igual que ya se hacía con `FbStockPorUnidad`/`FbColaSolicitudes`.

**Decisión de diseño clave — se eliminó el atajo, tal como se había prometido:** antes, en Gestión Proveedores, un pedido en "en tránsito" tenía un botón que sumaba stock directo al marcar "recibido total" (por la cantidad *solicitada*, no la que realmente llegó). Ahora:
1. Ese botón cambió a **"Registrar recepción"**, que lleva a la pestaña de Recepciones con el pedido pre-cargado (proveedor y cantidades solicitadas como sugerencia editable).
2. El stock **solo sube al aceptar la Recepción**, usando la cantidad *realmente recibida* por ítem — no la solicitada. Si hay diferencia, queda marcada.
3. Si la Recepción está vinculada a un pedido, ese pedido pasa a `recibido-total` o `recibido-parcial` según si se recibió todo lo solicitado o menos (el estado `recibido-parcial` ya existía en `PEDIDO_ESTADO_META` pero nunca se usaba — ahora sí).
4. También se puede registrar una Recepción **sin** pedido asociado (ej. donación, entrega fuera de sistema), agregando ítems manualmente desde el catálogo.
5. Cada ítem recibido con lote + fecha de vencimiento se agrega a la lista de lotes, que ahora es estado (`useState`) en vez de la constante fija `FB_LOTES_INICIAL` — así el widget de "próximos a caducar" del Dashboard queda conectado de verdad a lo que se va recibiendo, no solo a los 3 lotes de ejemplo iniciales.

**Simplificaciones explícitas de esta primera versión** (para que quede registrado, no se decidió eliminarlas, solo no se hicieron todavía):
- No incluye el registro de "ítem nuevo" (código de barra que no matchea ningún ítem del catálogo) — el formulario solo permite recibir ítems que ya existen en `FB_CATALOGO`/`FB_CATALOGO_BODEGA`. Registrar un ítem nunca antes visto necesita su propio flujo (como anticipa el campo `esNuevoItem` de la arquitectura) — queda pendiente para una siguiente vuelta.
- El escaneo de código de barra sigue siendo simulado (selector/dropdown), igual que en el resto del prototipo — no hay lector real conectado.
- `firmaRecepcion` (Firma Electrónica) no está representada todavía — mismo gap B5 ya conocido (no hay CUP/CUT real, solo `role`).

**Archivo actualizado:** `HISClinico_Layer1.jsx` (mismo archivo, no uno nuevo).

### 7.1 Actualización — Registro de ítem nuevo con el esquema completo del módulo

A pedido del usuario, se agregó lo que había quedado explícitamente fuera de la primera versión: registrar un ítem que no existe en el catálogo, directamente desde la Recepción, **con el mismo esquema que usa todo el módulo** — no un formulario simplificado aparte:

- **Farmacia:** elige Medicamento o Insumo clínico. Si es medicamento, pide **Nombre DCI**, concentración y forma farmacéutica (mismo modelo de 3 niveles que ya tenía el catálogo: DCI/SNOMED → marca/Registro ISP → Código CENABAST). En ambos casos pide **Registro ISP** y **Código CENABAST**, obligatorios — igual que el resto del catálogo de Farmacia, donde hasta los insumos clínicos (no fármacos) llevan Registro ISP como dispositivo médico.
- **Bodega:** esquema simple (nombre, categoría, marca, unidad) — sin ISP/CENABAST/DCI, porque no aplica a insumos no clínicos. Nunca se mezcla con el esquema de Farmacia.
- Si el DCI escrito coincide (por nombre) con un concepto ya existente en `FB_CONCEPTOS_FARMACO`, se reutiliza ese concepto; si no, se crea uno nuevo automáticamente y queda marcado `snomedCT: "pendiente de codificar"` — no se inventa un código SNOMED, mismo criterio de no inventar datos clínicos sin verificar que ya regía para el catálogo de ejemplo.
- El ítem nuevo queda **de verdad** en el catálogo (ya no son las constantes fijas `FB_CATALOGO`/`FB_CATALOGO_BODEGA`, ahora son estado) con stock inicial en 0, y aparece de inmediato en el resto del módulo: Stock por unidad, futuros Pedidos, etc. — no es un dato que solo vive dentro de esa Recepción.
- Queda marcado con una insignia "nuevo" tanto en la tabla del formulario como en la tarjeta histórica de la Recepción ya registrada (campo `esNuevoItem`, tal como lo define `arquitectura_farmacia_bodega.md`).

**Simplificaciones de esta parte, para que quede registrado:**
- El campo "Marca / laboratorio" del mini-formulario es uno solo (llena ambos campos del catálogo con el mismo valor) — si se necesitan distintos desde el inicio, hay que separarlos en un siguiente ajuste.
- El ítem se agrega al catálogo apenas se registra en el mini-formulario, no recién cuando se acepta la Recepción completa — si la Recepción se cancela después, el ítem nuevo igual queda en el catálogo (con stock en 0). Se decidió así porque el dato regulatorio (ISP/CENABAST/DCI) ya quedó capturado y no tendría sentido perderlo, pero es una decisión de diseño, no algo obvio — queda documentado para que se pueda revisar si no es el comportamiento esperado.
- Solo se puede registrar un ítem nuevo cuando la Recepción NO está vinculada a un pedido (mismo lugar donde ya se podían agregar ítems existentes manualmente). Si llega algo no pedido dentro de un envío que SÍ tiene orden de compra asociada, todavía no hay forma de agregarlo ahí mismo.

---

## PARTE 8 · Estandarización de concentración de medicamentos (Respuestas +2)

### 8.1 Puntos 1 y 2 — resueltos

- **Punto 1** (el ítem nuevo queda en el catálogo apenas se registra, aunque la Recepción se cancele después): aceptado por el usuario, sin cambios.
- **Punto 2** (separar marca de laboratorio): hecho. `FbNuevoItemMiniForm` ahora tiene dos campos independientes.

### 8.2 Punto 3 — el problema real y lo que se verificó

El documento que trajo el usuario (una investigación externa, con dos "agentes" opinando en cadena) plantea el problema correcto: `concentracion` era texto libre (`"20 mg/2 mL"`, `"0.9%"`, `"300 mg I/mL"`) mezclando masa, volumen y porcentaje en un solo campo — imposible de validar o calcular con eso. Propone construir un "AXON Medication Engine" separado, con capas de terminología clínica (SNOMED CT/RxNorm) y catálogo comercial nacional (ISP), y una tabla `medication_strength` con numerador/denominador.

Antes de decidir algo, se verificó lo verificable (ninguna afirmación del documento se tomó al pie de la letra):

| Afirmación del documento | Verificación (26-08-2026) |
|---|---|
| SNOMED CT es gratuito para Chile | **Confirmado.** Chile es miembro de SNOMED International desde el 1 de noviembre de 2013; SNOMED International no cobra por el uso de SNOMED CT dentro de países miembros. Fuente: snomed.org/member/chile, snomed.org/get-snomed. |
| RxNorm es gratuito pero centrado en EE.UU. | **Confirmado.** La NLM no cobra por licenciar RxNorm (uso comercial permitido), pero "contiene pocos o ningún medicamento no estadounidense" — coincide exactamente con la advertencia del propio documento de no usarlo como catálogo comercial chileno. Fuente: nlm.nih.gov (FAQ y Terms of Service de RxNorm). |
| Hay que separar "estándar clínico universal" de "catálogo comercial nacional" | Correcto como principio — pero con un hallazgo importante que el documento no menciona (ver 8.3). |

### 8.3 Hallazgo — Chile ya tiene esto: TFC (Terminología Farmacéutica Chilena) + HL7 FHIR Chile Core

Buscando la pieza que le faltaba al documento (el "catálogo nacional" del lado chileno), apareció algo que ya está mencionado de pasada en `sincronizacion_farmacia_bodega_main.md` (sección B3b) pero nunca se había profundizado: la **Terminología Farmacéutica Chilena (TFC)** — y, en una segunda vuelta de búsqueda (26-08-2026, a pedido del usuario para actualizar el hallazgo anterior), algo más fuerte todavía: **HL7 FHIR Chile Core**.

**TFC (la base conceptual):**
- Iniciativa público-impulsada por CORFO, desarrollada con participación de MINSAL (se distribuye vía **Semantikos**, el servidor de terminología de MINSAL).
- Combina exactamente lo que el documento pedía: **"Conceptos SNOMED CT + Elementos locales"**, pensada específicamente para la cadena **Prescripción → Dispensación → Compra**.
- Modelo de datos (Guía Editorial TFC): `Sustancia → Medicamento Básico → Medicamento Clínico → Producto Comercial → Producto Comercial con Envase` — prácticamente el mismo problema que resuelven nuestro `FB_CONCEPTOS_FARMACO` (nivel clínico) y `FB_CATALOGO` (nivel comercial/logístico), solo que ya estandarizado a nivel país.
- La guía de implementación que se encontró primero (simplifier.net/guide/tfc-ig) está en **FHIR STU3, v0.9**, con material de 2017-2021 — desactualizada.

**HL7 FHIR Chile Core — la pieza actual y activa (corrige el hallazgo anterior):**
- Guía de implementación oficial en **FHIR R4**, mantenida activamente: la versión revisada (1.8.2) indica explícitamente que ya fue superada por la 1.9.3 — no es un proyecto abandonado. Fuente: hl7chile.cl/fhir/ig/clcore.
- Tiene un perfil **"CL Medicamento"** (`StructureDefinition-CoreMedicamentoCl`, activo desde 2023-09-01) que el propio documento describe como desarrollado **"desde la visión del TFC"** — es decir, es TFC llevado a un FHIR R4 vigente, no un estándar aparte.
- **Confirma exactamente el modelo que ya implementamos:** `Medication.amount` (cantidad en el envase) y `Medication.ingredient.strength` (concentración) están definidos como tipo **`Ratio`** (numerador/denominador, cada uno con su propio valor y unidad) — igual que verificamos contra el FHIR R4 genérico, ahora confirmado también en el perfil chileno específico.
- Define identificadores propios apuntando al servidor Semantikos de MINSAL: `identifier:DescripcionId` (`http://minsal.cl/semantikos/description-id`) e `identifier:ConceptId` (`http://minsal.cl/semantikos/concept-id`, "se obtiene a través del TFC... según SNOMED-CT") — este sería el destino real de nuestros campos `dci`/`conceptoId` el día que haya integración de verdad.
- **Advertencia honesta que trae el propio documento oficial, no una limitación nuestra:** en las definiciones de esos dos identificadores aparece la nota **"Estos EndPoint deberán estar disponibles pronto"** — es decir, el estándar está definido y vigente, pero el propio MINSAL reconoce que el servidor Semantikos puede no estar públicamente disponible todavía. No se pudo confirmar el estado actual de esos endpoints en 2026 — queda pendiente de verificar cuando corresponda integrar, no se asume resuelto.

**Conclusión (reafirmada, más fuerte que antes):** no hace falta diseñar un "AXON Medication Engine" desde cero copiando SNOMED+RxNorm+CIMA como piezas sueltas — Chile ya tiene una respuesta oficial y vigente (TFC + HL7 FHIR Chile Core "CL Medicamento") que combina justamente eso, en el mismo estándar FHIR R4 que ya usamos en todo AXON. Si en algún momento se necesita interoperar de verdad (receta electrónica, reporte MINSAL, Ley 21.668), el objetivo correcto es alinearse con el perfil **CL Medicamento** de Chile Core — revisando la versión más reciente en hl7chile.cl/fhir/ig/clcore/history.html — y no inventar un esquema paralelo.

### 8.4 Decisión — qué se hizo ahora vs. qué queda documentado para después

Siguiendo el mismo criterio que ya se aplicó con AXON Supply Core (no refactorizar en grande sin aprobar, resolver el problema puntual primero):

**Se implementó ahora** (cambio acotado, dentro del modelo que ya existe):
- `concentracion` en `FB_CONCEPTOS_FARMACO` y en el registro de ítem nuevo dejó de ser texto libre. Ahora es un objeto `{ numeradorValor, numeradorUnidad, denominadorValor, denominadorUnidad }` — **el mismo patrón que usa FHIR R4 en `Medication.ingredient.strength`**, que está definido oficialmente como tipo `Ratio` (numerador y denominador, cada uno con su propio valor y unidad). Fuente: hl7.org/fhir/medication.html — confirmado que es el estándar R4 real, no una convención inventada para AXON.
- Las unidades del numerador (mg, g, mcg, UI, mg I, %) y del denominador (mL, L, comprimido, cápsula, dosis, unidad) quedaron en listas separadas y controladas (`FB_UNIDADES_NUMERADOR` / `FB_UNIDADES_DENOMINADOR`) en vez de texto libre — así no se puede repetir el problema de mezclar "mg/dL" con "ampollas" en el mismo campo.
- Nuevo formateador `fbFormatConcentracion()` para mostrarlo bien (ej. "20 mg / 2 mL", o "0.9 %" cuando no hay denominador) — y ya se usa en la tabla de Stock por Unidad, que antes no mostraba la concentración en absoluto.

**Queda documentado como decisión futura, no se construye ahora:**
- Un "AXON Medication Engine" como servicio separado, con las tablas propuestas en el documento (`medication_substance`, `medication_product`, `medication_strength`, `medication_package`, `medication_commercial_package`).
- Integración real con Semantikos/HL7 FHIR Chile Core vía API — el estándar (perfil CL Medicamento) ya se identificó como el objetivo correcto (ver 8.3), pero los endpoints del servidor de terminología pueden no estar públicamente disponibles todavía (advertencia del propio documento oficial, no nuestra).
- El flujo en cascada completo (medicamento → forma farmacéutica → concentraciones ya conocidas para esa forma → presentación → envase) — hoy el registro de ítem nuevo sigue siendo "escribe los datos", no "elige de lo ya conocido". Es una buena idea de UX del documento, pero requiere tener primero un catálogo de conceptos mucho más poblado del que tenemos (4 conceptos de ejemplo) para que tenga sentido ofrecer opciones ya existentes.

### 8.5 Fuentes usadas para esta verificación (búsqueda web, 26-08-2026)

- snomed.org/member/chile, snomed.org/members, snomed.org/get-snomed — membresía y licenciamiento SNOMED CT.
- nlm.nih.gov/research/umls/rxnorm/faq.html, .../termsofservice.html — licenciamiento y alcance geográfico de RxNorm.
- simplifier.net/guide/tfc-ig — Terminología Farmacéutica Chilena (versión STU3/v0.9, desactualizada), modelo de datos y perfiles FHIR originales.
- tfarmacia.tanu.cl (webinar QF, 2021) — confirma TFC como desarrollo MINSAL vía Semantikos, orientado a Prescripción/Dispensación/Compra.
- hl7.org/fhir (recurso `Medication`, R4) y hapifhir.io — confirma `Medication.ingredient.strength` como tipo `Ratio` (numerador/denominador) a nivel del estándar internacional.
- **hl7chile.cl/fhir/ig/clcore — HL7 FHIR Chile Core, perfil "CL Medicamento" (v1.8.2, superada por 1.9.3, activa desde 2023-09-01). La fuente más importante de esta ronda: confirma el modelo `Ratio` a nivel del perfil chileno específico, y expone los identificadores reales de Semantikos (`description-id`, `concept-id`).**
- interoperabilidad.minsal.cl/fhir/ig/eis — "Estándares de Información de Salud" de MINSAL (Unidad de Interoperabilidad, © 2024+), confirma que hay una base terminológica FHIR R4 activa y mantenida por MINSAL más allá de Chile Core.

### 8.6 Puerta etiquetada agregada — Recepción ↔ Orden de Compra formal

A pedido del usuario: el campo "Orden de compra (opcional)" del formulario de Recepción hoy referencia nuestro folio interno de Pedido (`PED-2026-XXXX`), no la Orden de Compra formal que aprueba Contabilidad (`ContabilidadAdquisiciones.jsx`, función `recibirRequisicion()` — folio nace `null`/"Requisición sin OC" hasta la aprobación, ver G3 de `sincronizacion_farmacia_bodega_main.md`). Se agregó como **puerta etiquetada #22** en la tabla de la sección F de ese documento, y como nota visible directamente en el formulario (bajo el campo, en el JSX) para que quede a la vista, no solo documentada aparte. No se construyó ninguna conexión real — sigue siendo, como el resto de puertas de esa tabla, documentada y no construida.

---

## PARTE 9 · Clientes Externos (#18) — implementado

**Qué se construyó**, siguiendo `ClienteExterno`/`DespachoClienteExterno` de `arquitectura_farmacia_bodega.md`:

- `FbClienteExternoCard` + `FbNuevoClienteExternoForm` — directorio expandible y alta de nuevos clientes (razón social, RUT, tipo de relación, contacto, datos de convenio si aplica).
- `FbNuevoDespachoExternoForm` — despacho a un cliente activo: elige Farmacia o Bodega (nunca ambos a la vez), agrega ítems del catálogo correspondiente con cantidad clamped al stock disponible (mismo patrón ya usado en Solicitudes), valor referencial opcional, guía de despacho, documento de respaldo, y fecha límite de devolución cuando el tipo de operación es préstamo o convenio.
- `FbDespachoExternoCard` — historial de despachos, con panel para registrar devolución (parcial o total) ítem por ítem cuando corresponde; al confirmar, el stock central real vuelve a subir.
- `ClientesExternosView` — vista con pestañas Directorio / Despachos, siguiendo el mismo patrón que Gestión Proveedores.
- 3 clientes de ejemplo (Hospital San José de Melipilla — convenio activo, Fundación Las Rosas — donación activa, Centro Médico Vitalis — venta suspendida), marcados como ejemplo, sin despachos históricos inventados.

**Decisión de interpretación que tomé — para que la confirmes:** `arquitectura_farmacia_bodega.md` ubica el #18 formalmente dentro del rango de Bodega (#11-18), pero el propio modelo de datos `DespachoClienteExterno` referencia `InsumoBodega | Medicamento` (ambos catálogos), y la descripción que ya existía en el JSX antes de esta sesión (`FB_COMPARTIDOS`) decía explícitamente "insumos de Farmacia **o** Bodega". Construí Clientes Externos como **vista única compartida** (igual que Gestión Proveedores) que puede despachar desde cualquiera de los dos dominios, en vez de limitarlo solo a Bodega. Si la intención real era que #18 fuera exclusivo de Bodega, hay que sacar la opción "Desde Farmacia" del formulario de despacho — es un cambio acotado si corresponde.

**Archivo actualizado:** `HISClinico_Layer1.jsx` (mismo archivo).

### 9.1 Ajuste — estándares clínicos que faltaban en el despacho

A pedido del usuario: la primera versión del despacho a Clientes Externos solo mostraba el nombre comercial del ítem, sin nada del trabajo de identificación clínica ya hecho (DCI, concentración estructurada, Registro ISP, Código CENABAST) ni el campo `lote` que el propio modelo de `arquitectura_farmacia_bodega.md` ya define en `DespachoClienteExterno.items`. Se corrigió:

- **Campo `lote` agregado** por ítem en el formulario de despacho y en el historial — se había omitido en la primera versión aunque el modelo de datos ya lo contemplaba.
- **Identificación clínica visible, solo para despachos desde Farmacia** (Bodega no tiene estos datos, correctamente): el selector de "agregar ítem" ahora muestra el DCI cuando el ítem es un medicamento; cada fila de la tabla y cada línea del historial muestra el mismo subtítulo que ya usa Stock por Unidad — DCI + concentración formateada (usando `fbFormatConcentracion`) + Registro ISP + Código CENABAST.
- Esto importa especialmente aquí porque un despacho a un cliente externo (préstamo, convenio, donación) es exactamente el tipo de movimiento donde la trazabilidad regulatoria debería quedar más clara, no menos — la institución receptora necesita saber con precisión qué recibió.
- No se agregó nada de SNOMED CT/TFC/FHIR más allá de lo ya construido (el dato sigue viviendo en `FB_CONCEPTOS_FARMACO`/`FB_CATALOGO`); esto es mostrar mejor lo que ya existe, no una integración nueva.

---

## PARTE 10 · Bodega e Insumos Propios (#25) — implementado

**La idea del usuario, y por qué es mejor que lo que decía la arquitectura original:** `arquitectura_farmacia_bodega.md` describía Insumos Propios como un inventario totalmente aparte (tipo `InsumoPropio`, sin conexión con nada). El usuario propuso algo mejor: tratar a "Farmacia y Bodega" como una unidad más de la red, que le solicita reposición a Bodega Central usando el **mismo flujo de 2 filtros ya construido** — igual que las otras 41 unidades. Esto evita inventar un sistema paralelo y de paso permite probar el flujo de solicitud completo de punta a punta con un caso concreto y propio.

**Qué se construyó:**
- `FB_UNIDAD_PROPIA` — una "unidad" (`PROPIA`, "Farmacia y Bodega — Uso Interno"), separada de las 41 reales.
- `BodegaInsumosPropiosView` — envoltorio delgado con pestañas Stock/Solicitudes que reutiliza **sin modificar** `FbStockPorUnidad` y `FbColaSolicitudes`, y una nueva instancia `hPropia` de la misma fábrica `fbCrearHandlers` ya usada por Farmacia y Bodega — cero lógica de negocio nueva.
- `hPropia` solicita contra `centralStockBod` (Bodega Central), nunca contra Farmacia Central — coherente con que Insumos Propios es, por definición, no clínico.
- Se agregaron 2 ítems al catálogo de Bodega que faltaban y que son justo los ejemplos que da la arquitectura para este submódulo: **papel térmico para impresora de etiquetas** (BOD-007) y **etiquetas autoadhesivas de código de barra** (BOD-008).
- Stock de ejemplo cargado con 2 ítems bajo mínimo (papel térmico, tóner) para que el semáforo y la alerta se vean funcionando de inmediato.
- Folios con prefijo `SOLP`, separados de `SOL`/`SOLB`.

**Dos decisiones de interpretación que tomé — para que las confirmes:**

1. **Solo se construyó el lado Bodega, no un "Farmacia Insumos Propios" paralelo.** El mensaje del usuario menciona "sub farmacia y sub bodega" de la unidad, pero `arquitectura_farmacia_bodega.md` solo define Insumos Propios como no clínico (papel térmico, etiquetas, embalaje, EPP, oficina) — no hay un caso de uso documentado donde el propio equipo de Farmacia necesite su propio stock de medicamentos separado del que ya administra. Si la idea es que también exista un lado Farmacia (y qué contendría clínicamente), se agrega con el mismo patrón — es un cambio simétrico y acotado.
2. **No se agregó "PROPIA" a `FB_UNIDADES_SUBBODEGA`** (las 41 reales) — se mantiene como unidad separada en su propia pantalla (#25). Esto evita que el conteo canónico "41 unidades" del Dashboard y de la arquitectura se corrompa silenciosamente. Si se prefiere que aparezca *dentro* del selector de la pestaña "Stock y Sub-bodegas" en vez de en su propia pantalla, es una decisión de UI distinta a tomar — hoy vive donde ya existía su entrada en el menú (#25, fila de compartidos).

**No conectado todavía (fuera de alcance de este pedido):** el Dashboard (#1) no muestra todavía alertas de Insumos Propios — la arquitectura sí documenta esa conexión (`#25 → #1`), pero no se tocó `FbDashboard` en esta vuelta.

### 10.1 Aclaración — el botón de "Nueva solicitud" depende del rol activo

El usuario reportó no ver ningún botón para crear solicitudes en Insumos Propios, solo la pestaña vacía. No es un bug nuevo de esta sesión: `FbStockPorUnidad` (reutilizado tal cual, sin cambios de lógica) solo muestra el botón "Nueva solicitud de reposición" cuando el rol activo (selector arriba a la derecha) es **"Encargado Sub-farmacia/Bodega"** — con "Farmacia/Bodega Central" o "Coordinador de Unidad" seleccionados, se muestra solo un texto explicativo en su lugar. Es la misma separación de roles ya confirmada como decisión de arquitectura (Parte 2, punto 3) aplicándose también aquí. Se mejoró el mensaje para que diga explícitamente qué rol elegir — mejora que aplica a las 41 unidades reales también, no solo a Insumos Propios.

### 10.2 Diagnóstico — "el flujo no se termina start to end"

El usuario reportó que el flujo completo de solicitud (crear → autorizar → aprobar → preparar → despachar → confirmar recepción) no se completaba de punta a punta al probarlo en Insumos Propios.

**Verificación hecha:** se extrajo `fbCrearHandlers()` tal cual vive en el JSX y se simularon las 6 etapas en Node.js, fuera del navegador, con la unidad `PROPIA`. Resultado: la máquina de estados completa correctamente las 6 etapas (`pendiente-coordinador → pendiente → aprobada → en-preparacion → despachada → recibida`), el stock central baja lo despachado (150→130) y el stock de la unidad sube lo recibido (4→24). La lógica en sí **no tiene el bug** — el problema más probable es de navegación/rol, no de datos.

**Hipótesis más probable, y mejora aplicada:** cada etapa del flujo requiere cambiar el rol activo (Encargado → Coordinador → Farmacia/Bodega Central → de vuelta a Encargado) — ya se había mejorado este aviso en la pestaña Stock (ver 10.1), pero **dentro de `FbSolicitudCard` los 5 mensajes de "esperando" no decían qué rol elegir**, solo explicaban que estaba esperando algo. Se corrigieron los 5 (pendiente-coordinador, pendiente, aprobada, en-preparación, despachada) para que cada uno diga explícitamente qué rol activar — mejora que aplica a las 41 unidades reales también, no solo a Insumos Propios.

**Si después de esto el flujo sigue sin completarse**, hace falta que se indique en qué paso exacto se traba (¿no aparece la solicitud después de crearla? ¿el botón de una etapa no hace nada al hacer clic? ¿aparece un error?) para diagnosticarlo más a fondo — la simulación descarta un error en la lógica de datos, pero no descarta un problema puntual de la interfaz que solo se ve interactuando con ella.

### 10.3 Mejora — PROPIA ahora también visible dentro de "Bodega → Stock y Sub-bodegas" / "#14 Solicitudes"

El usuario reportó (correctamente) que buscaba el stock de PROPIA dentro de la pestaña normal de Bodega y no lo encontraba, porque solo vivía en su propia pantalla (#25). Se agregó una lista combinada `FB_UNIDADES_SUBBODEGA_MAS_PROPIA` (las 41 reales + PROPIA) que se usa **solo** para renderizar esas 2 pestañas — `FB_UNIDADES_SUBBODEGA` (la constante de las 41) no se tocó, y el Dashboard sigue leyendo esa constante directo, así que el "/41" del KPI no se corrompe.

Para que crear/aprobar/despachar/confirmar funcione igual desde ahí, se agregaron funciones puente (`crearSolicitudBodComp`, `autorizarCoordinadorBodComp`, etc.) que enrutan cada acción al handler correcto (`hBod` o `hPropia`) según el `subFarmaciaId` (al crear) o el prefijo del folio (`SOLB-` vs `SOLP-`, al operar sobre una ya creada) — las dos listas de datos (`solicitudesBod` / `solicitudesPropia`, `subStockBod` / `subStockPropia`) siguen separadas por dentro, solo se combinan para mostrarlas y para dirigir el clic al lugar correcto.

La pantalla propia de Insumos Propios (#25) se dejó tal cual, sin quitar nada — ahora hay dos caminos hacia los mismos datos, no uno reemplazando al otro.

**Verificación adicional:** se simuló también el flujo completo usando las funciones puente reales (`crearSolicitudBodComp`, `autorizarCoordinadorBodComp`, etc., copiadas tal cual del JSX) en vez de solo `fbCrearHandlers` en aislado — confirma que el enrutamiento por folio funciona, que `subStockPropia.PROPIA` sube correctamente (4→19 en la prueba) al confirmar recepción, y que la unidad URG (una de las 41 reales) queda intacta en la misma vista combinada, sin filtrarse datos entre listas.

**Archivo actualizado:** `HISClinico_Layer1.jsx` (mismo archivo).

---

## PARTE 11 · Corrección de bug (sobre-despacho) + #2/#11 Catálogo Maestro y Stock Central

### 11.1 Bug real encontrado por el usuario probando la interfaz — corregido

Al probar el flujo completo con 100 unidades de cada ítem, algunos campos aparecían en rojo antes de despachar, pero el sistema igual permitió despachar 100 en todos. Causa real: `abrirDespacho()` prellenaba el panel con la cantidad **solicitada**, sin toparla al stock **disponible** en Central. El clamp que sí existía (`Math.min(disponible, ...)`) solo se aplicaba si el usuario editaba manualmente ese campo — si lo dejaba tal cual, el tope nunca se ejecutaba, y `despachar()` registraba `cantidadDespachada` igual a lo pedido, sin verificar contra el stock real. Resultado: una unidad podía terminar "recibiendo" más de lo que Central realmente tenía — stock creado de la nada.

**Es un bug preexistente**, no introducido en esta sesión — no se había tocado `abrirDespacho()` ni `despachar()` hasta ahora.

**Corrección aplicada (dos capas):**
1. `abrirDespacho()` ahora prellena cada ítem ya topado al disponible real (`Math.min(disponible, cantidadSolicitada)`), no solo lo solicitado.
2. `despachar()` (dentro de `fbCrearHandlers`, compartida por Farmacia/Bodega/Insumos Propios) ahora calcula la cantidad real topada al momento de aplicar el descuento, y usa **ese mismo valor** tanto para restar stock como para registrar `cantidadDespachada` — nunca pueden quedar desincronizados. Mismo criterio aplicado también en el despacho a Clientes Externos, por consistencia.

### 11.2 #2 Farmacia: Medicamentos / #11 Bodega: Insumos — construidos

El usuario notó que no había forma de ver el stock **consolidado** de Farmacia/Bodega Central — solo el desglose por unidad (#3/#12). Estos dos submódulos (#2 y #11) estaban documentados en `arquitectura_farmacia_bodega.md` desde el principio pero nunca se habían construido como pantalla propia.

**`FbStockCentralView`** — tabla con el catálogo completo y su stock central (actual, mínimo, semáforo), reutilizable para ambos dominios:
- Farmacia (#2): incluye el mismo subtítulo DCI/concentración/Registro ISP/CENABAST que ya se usa en Stock por Unidad.
- Bodega (#11): sin esos campos clínicos, que no aplican.

Ahora "Farmacia" y "Bodega" quedan con 4 pestañas construidas cada una en vez de 3 (Farmacia: #2, #3, #4, #5 · Bodega: #11, #12, #13, #14).

**Archivo actualizado:** `HISClinico_Layer1.jsx` (mismo archivo).

---

## PARTE 12 · Trazabilidad (#8 Farmacia / #15 Bodega) — implementado

**Qué se construyó**, siguiendo el modelo `MovimientoFarmacia`/`MovimientoBodega` de `arquitectura_farmacia_bodega.md` (y ya alineado campo a campo con el diseño de `SupplyEvent` de `AXON_SUPPLY_CORE_CIMIENTOS_ARQUITECTURA.md`, sin que eso implique ningún refactor hacia Supply Core — sigue sin estar aprobado por main):

- **`MOVIMIENTO_TIPO_META`** — catálogo de 6 tipos de movimiento: `ingreso-proveedor`, `despacho-unidad`, `recepcion-unidad`, `despacho-cliente-externo`, `devolucion`, `ajuste` (este último reservado en el catálogo para cuando se construya Cuadratura/Ajuste de stock forzado — todavía no tiene ningún botón que lo dispare).
- **`fbCrearMovimiento(...)`** — helper que arma un movimiento con id, fecha, y los campos `origen`/`destino` como `{tipo, referencia}` — mismo patrón que ya usaba el resto del módulo para objetos con procedencia/destino.
- **`FbTrazabilidadView`** — tabla filtrable por ítem (texto libre) y por tipo de movimiento, mostrando fecha, tipo (badge de color), ítem, lote, cantidad con signo, stock resultante, origen→destino, documento de respaldo y quién lo registró. Reutilizable para ambos dominios (recibe `movimientos`, `catalogo`, `label`).

**Puntos donde ahora se registra un movimiento real** (no se inventó ningún movimiento histórico de ejemplo — las tablas empiezan vacías):

| Acción | Tipo de movimiento | Dónde |
|---|---|---|
| Se acepta una Recepción de proveedor (#4/#13) | `ingreso-proveedor` | `fbCrearHandlersRecepcion` |
| Farmacia/Bodega Central despacha una solicitud aprobada | `despacho-unidad` | `fbCrearHandlers.despachar` |
| La unidad confirma recepción de lo despachado | `recepcion-unidad` | `fbCrearHandlers.confirmarRecepcion` |
| Se despacha a un Cliente Externo (#18) | `despacho-cliente-externo` | `crearDespacho` en `ClientesExternosView` |
| Un Cliente Externo devuelve (préstamo/convenio) | `devolucion` | `registrarDevolucion` en `ClientesExternosView` |

`hFarm`/`hBod`/`hPropia` (la fábrica compartida `fbCrearHandlers`) y `hFarmRecepcion`/`hBodRecepcion` ahora reciben además `setMovimientos`, `nodoLabel` y `role` — Insumos Propios (#25) registra en `movimientosBodega` porque solicita contra Bodega Central, igual que ya comparte stock con las 41 unidades reales en esa vista combinada (Parte 10.3).

**Decisión de diseño — dos movimientos, no uno, para despacho→recepción de una solicitud:** `despacho-unidad` (salida real de Central, en el momento del despacho) y `recepcion-unidad` (entrada real a la unidad, en el momento de la confirmación) quedan como dos eventos separados, no uno solo. Esto es intencional: permite que la cantidad despachada y la cantidad recibida difieran (mermas o diferencias de conteo en tránsito, ya soportado desde antes por el formulario de confirmación) y que ambas queden trazadas por separado — mismo criterio que ya usa `arquitectura_farmacia_bodega.md` al definir movimientos con signo `+`/`-` independientes para cada extremo.

**Verificado con una simulación en Node.js** (fuera de React, replicando `fbCrearMovimiento` + `despachar` + `confirmarRecepcion` + `registrar` de Recepción tal cual del archivo): recepción de 50 unidades → despacho de 30 → confirmación de solo 28 recibidas (2 de diferencia, con observación) — los 3 movimientos quedan registrados en el orden correcto, con el `stockResultante` de cada uno coincidiendo exactamente con el stock real después de esa operación, y la observación de la diferencia queda preservada en el movimiento de `recepcion-unidad`.

**Simplificaciones explícitas de esta primera versión** (para que quede registrado, no se decidió eliminarlas):
- No hay exportación ni impresión del listado de movimientos — solo la tabla en pantalla con filtros.
- El filtro de fecha no está implementado todavía (solo ítem y tipo) — se puede agregar si hace falta.
- `ajuste` está en el catálogo de tipos pero sin ningún flujo que lo genere — es el tipo que usaría la futura Cuadratura/Ajuste de stock forzado (Parte 2, decisión #8: motivo obligatorio y trazabilidad siempre, sin excepción de rol).

**Nota operativa de esta sesión:** el entorno de cómputo se reinició a mitad del desarrollo de este submódulo y se perdió el trabajo que no se había copiado todavía a `/mnt/user-data/outputs/`. Se reconstruyó completo desde cero en la misma sesión, sin cambios de diseño respecto a lo perdido. Se guardaron checkpoints intermedios en `outputs` durante la reconstrucción para reducir este riesgo a futuro.

**Archivo actualizado:** `HISClinico_Layer1.jsx` (mismo archivo).

---

## PARTE 13 · Triage de pendientes tras aprobación de Supply Core (25-09-2026)

**Contexto:** Supply Core fue aprobado por main. La pregunta que quedó abierta al cierre de la sesión anterior (¿seguimos con Balances #9/#16, u otra prioridad?) se resolvió con una propuesta más amplia: antes de elegir el próximo submódulo, reorganizar TODO lo pendiente distinguiendo qué es realmente de Farmacia y Bodega y qué depende de motores transversales que todavía no existen (Workforce, AIMS, motor de recetas/firmas electrónicas).

### 13.1 La pregunta de fondo — ¿organizar el cambio a Supply Core o completar lo pendiente?

No son alternativas — es la misma actividad. `AXON_Supply_Core.docx` (sección 28, Fases 1-3) y `AXON_SUPPLY_CORE_CIMIENTOS_ARQUITECTURA.md` ya establecían que la migración no es una reescritura de golpe: es seguir construyendo dentro de `HISClinico_Layer1.jsx`, pero con esquemas de campos ya compatibles con `SupplyEvent`/`SupplyNode`, para que el día de la extracción real (Fase 3 en adelante) sea un cambio de nombre, no una reescritura. Es exactamente lo que ya se hizo con Trazabilidad (#8/#15): sigue llamándose `MovimientoFarmacia`/`MovimientoBodega` en el código, pero con la forma de campos que después usará `SupplyEvent`.

"Organizar el cambio" entonces significa dos cosas, no una decisión de parar a rediseñar: (1) seguir con ese mismo criterio en cada pieza nueva, y (2) hacer el triage ítem por ítem de qué es nuestro y qué depende de otro motor — que es justo lo que se propuso, y lo que responde la sección siguiente.

### 13.2 Triage ítem por ítem — dónde coincido y dónde no

| # | Ítem | Lectura propuesta | Verificación contra la arquitectura documentada | Veredicto |
|---|---|---|---|---|
| #9/#16 | Balances Farmacia/Bodega | Viene de un motor externo de balances de todas las unidades | `arquitectura_farmacia_bodega.md` los define como internos: consumen Pedidos (#5/#14), Stock (#3/#12), Delivery (#6) y **Trazabilidad (#8/#15)** — datos que el módulo ya tiene. #19 (Balances Unidades) y #22 (Sinergia) sí son consolidaciones globales, pero se alimentan de #9/#16, no al revés — nada de esto viene de afuera. | **No coincidí, y el usuario lo aceptó (25-09-2026): queda como opción viable para construir ahora.** |
| #6 | Delivery | Mejor cuando Supply Core esté resuelto | Coincide con dos cosas ya documentadas: (a) el modelo de capacidad configurable (`capability.delivery`) es del Capability Engine — Fase 5 del roadmap de Supply Core, no Fase 1-3; (b) sigue bloqueado externamente — Urgencias/Hospitalización todavía no formalizan el contrato de solicitud de delivery domiciliario (pregunta 5.5.b del dossier, sigue abierta). | **Coincido**, por ambos motivos. |
| #7 | Recetas Retenidas | Espera el motor de recetas y firmas electrónicas | Coincide con el gap B5 ya conocido (sin CUP/CUT, `firmaRecepcion` no representado ni en Recepciones) y con B3b (Firma Electrónica Avanzada + hash del documento como requisito legal de la receta, capa HL7 CDA). | **Coincido.** |
| #20/#21 | Eventos Adversos / Seguridad | Motor transversal propio | Parcialmente cierto: la **estructura** es reutilizada de Atención Quirúrgica ("misma estructura y normativa"), pero no hay ningún motor central documentado que capture los datos por nosotros — cada módulo (Hospitalización incluida, según su propia guía) construye su propia instancia con el patrón compartido. | No coincidí del todo, pero **decisión final del usuario (25-09-2026): capability transversal, no nos corresponde por ahora.** Queda fuera del backlog de este módulo, no solo "bloqueada". |
| #22/#23 | Sinergia / Reuniones | De Workforce | Los documentos de Hospitalización sí mencionan "Workforce" como domain service transversal (mapa de dominios, sección 1.1 de la Guía Maestra) — pero es una visión a futuro de ESE módulo, no algo resuelto para Farmacia y Bodega. Nuestra propia arquitectura sigue listando Reuniones (#23) como instancia local, igual que Atención Quirúrgica tiene la suya. | **Resuelto por el usuario (25-09-2026): capability transversal, no nos corresponde por ahora.** |
| #24 | Calendario y Turnos | De otro motor aparte | Mismo caso que Sinergia/Reuniones — conectado al mismo "Workforce" aspiracional de Hospitalización, sin resolver todavía para este módulo. | **Resuelto por el usuario (25-09-2026): capability transversal, no nos corresponde por ahora** — misma decisión que #22/#23. |
| #26 | Soporte y Solicitudes | De AIMS | Parcial: el propio texto original dice "Tickets hacia **TI**, Logística **e Infraestructura**" — dos destinos, no solo uno. TI/tickets vive en el módulo `informatica` (`ti_tickets`), no en `equipamiento`/AIMS. | **Coincido en parte** — Logística/Infraestructura sí es AIMS; TI no. Sin revisar por el usuario todavía. |
| #27 | Registro de Mantenciones | De AIMS | Confirmado, y con precedente ya construido: la guía de Hospitalización (sección 13) documenta exactamente este patrón ya validado — Hospitalización solo ve activos y reporta fallas, AIMS es dueño del ciclo de mantención completo, nunca se edita desde afuera. AIMS ya existe como módulo propio en `HISClinico_Layer1.jsx` (`equ_mantencion`). | **Coincido, es el caso más sólido de todos.** |

> **Nota de interpretación:** el usuario escribió "eventos adversos" en singular al resolver esto — se interpretó como #20 y #21 juntos (misma fila, mismo veredicto en la tabla de arriba), porque siempre se presentaron como par en este dossier y comparten la misma nota de arquitectura ("misma estructura y normativa"). Si la intención era excluir solo #20 y dejar #21 abierto, avisar para corregir.

### 13.3 Triage CERRADO (25-09-2026) — lo que queda como pendiente real de Farmacia y Bodega

- **Construible ahora, sin depender de nadie, y sin construir todavía:** únicamente **Balances (#9/#16)**. Es la única pieza que queda en esta categoría — Cuadratura ya se construyó (Parte 15), y Eventos Adversos/Seguridad salió del backlog por decisión del usuario.
- **Fuera del backlog de este módulo por decisión de producto, no por bloqueo técnico:** Eventos Adversos (#20), Eventos de Seguridad (#21), Sinergia (#22), Reuniones (#23), Calendario (#24) — las 5 son capabilities transversales, no responsabilidad de Farmacia y Bodega por ahora.
- **Bloqueado por un motor externo que todavía no existe:** Delivery (#6), Recetas Retenidas (#7), Mantenciones (#27), y la mitad "Logística/Infraestructura" de Soporte (#26) — la mitad "TI" de Soporte no depende de AIMS y sigue sin revisar.

### 13.4 Cuadratura/Ajuste de stock forzado — sí, y con un ajuste al diseño original

Coincido en que es la mejor opción para cerrar la trazabilidad interna actual, por una razón muy concreta y no solo conceptual: el tipo `ajuste` **ya existe** en `MOVIMIENTO_TIPO_META` desde que se construyó Trazabilidad, reservado exactamente para esto y sin ningún flujo que lo dispare todavía. Es la pieza con menos fricción para empezar.

Antes de construirlo, un ajuste al diseño que ya está documentado y que no conviene perder: `VISION_SUPPLY_CORE_FUTURO.md` (sección 5, punto 6) ya identificó que un `ajuste` único y genérico es un error — un conteo físico siempre encuentra diferencias, y lo correcto es separar **Merma** (pérdida, hurto, deterioro) de **Diferencia de conteo** (ajuste post-inventario físico), cada una con motivo obligatorio, trazabilidad completa y, a futuro, su propia cuenta contable de destino. Esto coincide además con el modelo original de `arquitectura_farmacia_bodega.md`, que ya distinguía `merma`, `vencimiento` y `ajuste-inventario` como tipos separados en `MovimientoFarmacia.tipoMovimiento` — la implementación actual los colapsó todos en un `ajuste` genérico.

Verificado contra SAP MM (la misma referencia que ya usamos para validar Supply Core ↔ Account Core, búsqueda del 25-09-2026): confirma exactamente esta separación. Los movement types de scrapping/merma (551 para stock sin restricción, 553 para stock en inspección de calidad, 555 para stock bloqueado — incluye expirados, que se dan de baja directo por scrapping, no por otro camino) son un grupo completamente distinto de los movement types de diferencia de inventario físico (701/702), y cada uno impacta cuentas contables distintas. SAP incluso va más allá: es práctica común desagregar el motivo dentro del mismo scrapping (dañado vs. vencido vs. otro) creando variantes del movement type solo para que cada motivo golpee una cuenta contable distinta. No es una preferencia nuestra — es el patrón estándar de la industria.

De paso, esto resuelve un gap que no estaba en la lista original: hoy un lote vencido solo genera una alerta en el Dashboard (`alertasCaducidad`) pero nunca se descuenta realmente del stock — no existe ningún flujo que lo retire. Si `vencimiento` queda como motivo separado en Cuadratura, se cierra ese gap de paso.

**Propuesta concreta, pendiente de tu confirmación:** construir Cuadratura con 3 motivos estructurados desde el inicio — `merma`, `vencimiento`, `diferencia-conteo` — en vez de un único formulario "Ajuste de stock" genérico. Cada uno con motivo obligatorio y sin excepción de rol (Parte 2, decisión #8), y el de vencimiento ofreciendo directamente los lotes que hoy solo generan alerta como punto de partida.

### 13.5 Balances (#9/#16) — qué se puede calcular con datos reales, antes de construir

Con el triage cerrado, Balances queda como la única pieza "construible ahora, sin depender de nadie" todavía sin construir (13.3). Antes de armarlo, una verificación rápida de qué datos existen de verdad hoy — para no prometer una métrica que no se puede calcular, mismo criterio que ya rige todo el módulo.

**Sí se puede calcular ya**, con `solicitudes`/`solicitudesBod`, `movimientosFarmacia`/`movimientosBodega` (Trazabilidad), `recepciones`/`recepcionesBod` y `pedidosProveedores`, todos reales desde las Partes 7 y 12:
- `metricasSubFarmacias`/`metricasSubBodegas`: tiempo promedio de despacho (desde `fechaSolicitud` hasta el movimiento `despacho-unidad`), solicitudes atendidas/pendientes, tasa de rechazo, consumo mensual.
- `metricasProveedores.tasaEntregaCompleta`: comparando los ítems del Pedido contra los de la Recepción vinculada (cuando existe).
- `metricasProveedores.tasaCumplimientoPlazo`: comparando `proveedor.comercial.plazoEntregaDias` (esperado) contra `fechaRecepcion - pedido.fecha` (real) — solo para pedidos con Recepción vinculada.

**No se puede calcular todavía, con honestidad** — falta el dato, no se inventa:
- `tiempoPromedioRespuesta` de proveedor: el modelo de Pedido solo guarda `fecha` de creación y un `estado` que se sobreescribe — no hay timestamp propio de "cuándo confirmó el proveedor" (el botón "Marcar confirmado" cambia el estado pero no registra cuándo). Quedaría en `—`, igual que ya hace `tiempoPromedioDespachoHrs` del Dashboard cuando no hay datos.
- `metricasDelivery`: vacío, porque Delivery (#6) no está construido (13.3).

**Propuesta:** construir Balances con las métricas reales de arriba, dejando `tiempoPromedioRespuesta` documentado como pendiente (no inventado) — agregar timestamps por transición de estado al modelo de Pedido sería un cambio aparte, no parte de este submódulo.

---

## PARTE 14 · Auditoría técnica externa del JSX — hallazgos verificados (25-09-2026)

**Contexto:** A pedido tuyo, se leyó `Auditoria_SupplyCore.docx` — una revisión externa de 34 secciones que audita, en orden, este dossier, `VISION_SUPPLY_CORE_FUTURO.md`, `AXON_SUPPLY_CORE_CIMIENTOS_ARQUITECTURA.md`, `sincronizacion_farmacia_bodega_main.md`, y recién después el `HISClinico_Layer1.jsx` directamente. Antes de dar por válido cualquier hallazgo, se verificaron los más concretos y accionables contra el código real — no se aceptó ninguno solo porque el documento lo afirma.

### 14.1 Veredicto general — coincide con el rumbo ya tomado

Su conclusión principal ("no conviene rehacer este JSX... ya constituye una base funcional bastante buena para la futura implementación de Supply Core") coincide con la Parte 2 de este dossier y con el mapa de fases de `AXON_Supply_Core.docx`. No propone ningún cambio de rumbo — refuerza la evolución progresiva ya decidida, no una reescritura.

### 14.2 Hallazgos P0 — verificados uno por uno contra el código real

| # | Hallazgo de la auditoría | Verificación en `HISClinico_Layer1.jsx` | ¿Real? |
|---|---|---|---|
| 1 | Una Recepción `aceptada-con-observaciones` (embalaje dañado, cadena de frío rota, documentación incompleta, o especificaciones no cumplidas) sube el stock exactamente igual que una `aceptada` limpia — no hay cuarentena. | Confirmado en `fbCrearHandlersRecepcion.registrar()`: la condición para sumar a `centralStock` es solo `estado !== "rechazada"` — no distingue `aceptada` de `aceptada-con-observaciones`. | **Sí, real.** |
| 2 | `confirmarRecepcion()` registra el movimiento de trazabilidad con origen/destino invertidos. | Confirmado: queda `origen: { tipo: "sub-unidad", ... }`, `destino: { tipo: nodoLabel, ... }` — pero físicamente el flujo es Central → sub-unidad, igual que `despachar()`, que sí lo tiene bien (`origen: nodoLabel, destino: sub-unidad`). Quedó invertido solo en la confirmación de recepción. | **Sí, real.** |
| 3 | Se mutan objetos externos dentro del *updater* de `setState` y se leen inmediatamente después, como si fuera código síncrono. | Confirmado en `despachar()`, `registrar()` (Recepción) y `registrarDevolucion()` — los tres arman `cantidadesReales`/`stockResultantes` mutando un objeto declarado fuera de `setCentralStock(prev => ...)` y lo leen justo después de la llamada. Funciona hoy, pero no es un contrato garantizado de React (Strict Mode invoca el *updater* dos veces a propósito para exponer justo este tipo de impureza). | **Sí, real — repetido en 3 lugares.** |
| 5 | Una devolución de Cliente Externo reingresa a stock disponible sin ningún paso de inspección. | Confirmado en `registrarDevolucion()`: suma directo a `stockActual`, mismo patrón que el punto 1. | **Sí, real.** |
| 4 | Falta separar "lote" de "existencia del lote" (cantidad/nodo/estado propios, no solo `numeroLote` + `fechaVencimiento`). | No es un bug puntual — es una limitación de diseño real (los lotes no llevan cantidad ni ubicación propia), pero es un cambio de modelo más grande, no una corrección quirúrgica. | **Real, pero es rediseño, no bug.** |

### 14.3 Hallazgo adicional verificado — sección 25 de la auditoría, no estaba en su propia lista P0

| Hallazgo | Verificación | ¿Real? |
|---|---|---|
| `unidadesConAlerta` del Dashboard puede sobre-contar: suma alertas de `FB_UNIDADES_SUBFARMACIA` (24) + `FB_UNIDADES_SUBBODEGA` (41) contra un denominador de 41 únicas, pero las 24 "ambas" están incluidas en las dos listas — si una tiene alerta en Farmacia Y en Bodega a la vez, se cuenta dos veces. | Confirmado: `FB_UNIDADES_SUBBODEGA = [...FB_UNIDADES_SUBFARMACIA, ...17 más]` — las 24 están literalmente duplicadas en el array antes de mapear a semáforos. | **Sí, real.** |
| `FB_DATA_SEMANA` (gráfico "Despachos de la semana") sigue siendo una constante fija, etiquetada como si fuera dato real (badge "FHIR SupplyDelivery"), pese a que Trazabilidad ya genera movimientos reales de los que se podría calcular. | Confirmado: `FB_DATA_SEMANA` no se toca en ningún handler. | **Sí, real — y ahora es barato de arreglar**, porque `movimientosFarmacia`/`movimientosBodega` ya tienen lo necesario para calcularlo de verdad. |

### 14.4 Lo que la auditoría confirma de forma independiente sobre Cuadratura

Las secciones 14 y 34 de la auditoría llegan, por su cuenta, a la misma conclusión que la Parte 13.4 de este dossier: separar `MERMA` / `VENCIMIENTO` / `DIFERENCIA_CONTEO` en vez de un `ajuste` único, conectado a `FbTrazabilidadView`, como el siguiente paso más útil. Son **tres coincidencias independientes** en la misma conclusión (tu instinto, este dossier, y ahora esta auditoría externa) — refuerza bastante la confianza en ese plan.

### 14.5 Secuencia confirmada por el usuario (25-09-2026)

No se mezclan los 5 hallazgos P0 en un solo paquete — tienen tamaños de cambio distintos:

**Correcciones quirúrgicas, sin decisiones de diseño pendientes, junto con Cuadratura:**
- #2 — corregir origen/destino en `confirmarRecepcion()`.
- #3 — calcular `cantidadesReales`/`stockResultantes` en una variable local antes de llamar a `setState`, no mutando dentro del *updater* (mismo criterio en los 3 lugares donde aparece, y usado desde el inicio en el código nuevo de Cuadratura).
- Los 2 hallazgos del Dashboard (14.3) — recalcular el gráfico semanal desde los movimientos reales, y corregir el doble conteo de `unidadesConAlerta`.

**Necesitan una decisión de diseño antes de tocar código — no los mezclaría con Cuadratura:**
- #1 y #5 apuntan al mismo hueco: hoy el stock es un solo número, sin estado intermedio de "cuarentena/bloqueado". Antes de decidir cómo entra una Recepción con observaciones o una devolución sin inspeccionar, hay que decidir si se introduce esa dimensión ahora (aunque sea de forma simple) o se deja documentada para cuando se formalice el ledger — la propia auditoría (sección 12) la trata como dimensión "a futuro", no como bloqueante inmediato.
- #4 (lote sin existencia propia) — mismo caso, cambio de modelo, no corrección puntual.

**Confirmado:** las 4 correcciones quirúrgicas primero (chicas, sin ambigüedad de diseño), después Cuadratura ya con el patrón corregido desde el inicio, y dejar #1/#4/#5 (cuarentena + lote como posición de stock propia) como la conversación de diseño que sigue después — no antes. **Implementado en esta misma sesión — ver Parte 15.**

---

## PARTE 15 · Correcciones P0 + Cuadratura de Stock — implementado (25-09-2026)

**Qué se corrigió** (la secuencia confirmada en la Parte 14.5), directamente en `HISClinico_Layer1.jsx`:

- **Hallazgo #2** (`confirmarRecepcion()` con origen/destino invertidos): corregido — ahora dice `origen: Central`, `destino: sub-unidad`, igual que `despachar()`.
- **Hallazgo #3** (*side effects* dentro del *updater* de `setState`): corregido en **5 lugares**, no 3 — al revisar el código para aplicar la corrección aparecieron 2 casos más que no estaban contados en la Parte 14.2 (`crearDespacho()` y `registrarDevolucion()`, ambos en `ClientesExternosView`). Los 5 (`despachar()`, `confirmarRecepcion()`, `registrar()` de Recepción, `crearDespacho()`, `registrarDevolucion()`) ahora calculan sobre una copia local del stock *antes* de llamar a `setState`, nunca mutando un objeto externo dentro del *updater*.
- **Dashboard — `unidadesConAlerta`**: corregido el doble conteo de las 24 unidades "ambas" (antes sumaba dos listas con superposición contra un denominador de 41 únicas).
- **Dashboard — gráfico semanal**: `FB_DATA_SEMANA` (constante fija) eliminada; el gráfico "Despachos de la semana" ahora se calcula de verdad desde `movimientosFarmacia`/`movimientosBodega` (Trazabilidad) con el nuevo helper `fbCalcularDespachosSemana()`. Empieza en cero hasta que ocurra un despacho real — no se inventan datos.

**Qué se construyó — Cuadratura de Stock** (Farmacia y Bodega, mismo patrón que Recepciones/Trazabilidad: componentes compartidos, una pestaña por dominio, sin número canónico porque no está en los 27 submódulos originales):

- `CUADRATURA_MOTIVO_INFO` / `CUADRATURA_CAUSA_MERMA` — 3 motivos estructurados: **merma** (con causa: pérdida/hurto/deterioro), **vencimiento**, **diferencia de conteo** — reemplazan el tipo genérico `ajuste` de `MOVIMIENTO_TIPO_META` (que llevaba reservado desde Trazabilidad sin ningún flujo que lo disparara).
- `FbNuevaCuadraturaForm` — formulario con motivo obligatorio siempre (Parte 2, decisión #8, sin excepción de rol): merma/vencimiento solo pueden bajar el stock (cantidad a retirar, topada al disponible); diferencia de conteo puede subir o bajar (se ingresa el stock real contado, la diferencia se calcula sola). Para vencimiento en Farmacia, ofrece directamente los lotes que hoy generan alerta en el Dashboard (≤ 60 días) como punto de partida — **limitación conocida y documentada en el propio formulario**: como el lote todavía no tiene cantidad propia (hallazgo #4 de la Parte 14.2, no resuelto en esta pasada), la cantidad a retirar se sigue ingresando a mano.
- `FbCuadraturaCard` / `FbCuadraturaView` — historial y pestaña, mismo patrón visual que Recepciones.
- Cada ajuste genera un movimiento real en Trazabilidad (`tipoMovimiento`: `merma` | `vencimiento` | `diferencia-conteo`), con `origen`/`destino` según el signo: si baja, `origen: Central → destino: baja/<motivo>`; si sube (solo posible en diferencia de conteo), `origen: conteo-fisico/<motivo> → destino: Central` — construido con el patrón corregido desde el día uno, no heredó el bug de los 5 lugares de arriba.
- Estado nuevo por dominio: `cuadraturaFarm`/`cuadraturaFarmFolioSeq` (folio `AJU-2026-XXXX`) y `cuadraturaBod`/`cuadraturaBodFolioSeq` (folio `AJB-2026-XXXX`). Empiezan vacíos, igual que Recepciones y Trazabilidad.

**Verificación antes de entregar** (Parte 3 del dossier, principio de trabajo):
- Sintaxis: `esbuild` sobre el archivo completo, sin errores; llaves/paréntesis/corchetes balanceados (conteo automático).
- Ícono `CheckSquare` (Cuadratura) ya estaba importado — sin imports faltantes.
- Simulación en Node.js, fuera de React, de los 5 casos: `despachar()` topando a disponible real, `confirmarRecepcion()` con la dirección ya corregida, Cuadratura-merma (solo baja), Cuadratura-diferencia-conteo (sube), y `unidadesConAlerta` sin doble conteo con una unidad que tiene alerta en ambos dominios a la vez — las 5 aserciones pasaron.

**Qué NO se tocó, a propósito** (queda para la conversación de diseño de la Parte 14.5): hallazgos #1 (Recepción con observaciones sube a stock disponible sin cuarentena), #4 (lote sin cantidad/ubicación propia) y #5 (devolución de Cliente Externo sin inspección) — los tres apuntan al mismo hueco de fondo: falta un estado intermedio de "cuarentena/bloqueado" en el modelo de stock actual.

**Archivo actualizado:** `HISClinico_Layer1.jsx` (mismo archivo).

---

## PARTE 16 · Segunda auditoría técnica (hallazgos nuevos corregidos) + Balances (#9/#16) — implementado (25-09-2026)

**Contexto:** a pedido del usuario, se leyó `Auditoria_SupplyCore2.md` antes de construir Balances — una segunda auditoría externa (44 puntos) que revisa la Parte 15 ya implementada y encuentra hallazgos nuevos, distintos de los de `Auditoria_SupplyCore.docx` (Parte 14). Dos de esos hallazgos se corrigieron antes de construir Balances, porque Balances habría heredado el mismo tipo de error si no se corregían primero.

### 16.1 Dos hallazgos nuevos, verificados y corregidos

| # de la auditoría | Hallazgo | Verificación en el código | Corrección aplicada |
|---|---|---|---|
| 7 | `lotes` era **un solo array compartido** entre Farmacia y Bodega — una Recepción de Bodega con lote/vencimiento terminaba en la misma lista que lee el Dashboard de Farmacia y el selector de vencimiento de Cuadratura Farmacia. | Confirmado: `hFarmRecepcion` y `hBodRecepcion` recibían el mismo `setLotes`. | Separado en `lotesFarmacia`/`lotesBodega`, cada uno alimentado solo por su propio dominio. De paso, Bodega gana el mismo selector de "lotes próximos a vencer" en Cuadratura que ya tenía Farmacia (antes se le pasaba `lotes={null}` justamente para evitar la contaminación). |
| 35 | El gráfico semanal (recién corregido en la Parte 14/15 para usar datos reales) contaba **movimientos**, no **despachos**: `despachar()` crea un movimiento por cada ítem de la solicitud, todos con el mismo folio — una solicitud de 5 ítems se despachaba en un solo acto pero el gráfico mostraba "5 despachos". | Confirmado revisando `despachar()`: `sol.items.filter(...).map(...)` genera un movimiento por ítem. | `fbCalcularDespachosSemana()` ahora cuenta folios (`documentoRespaldo`) únicos por día, no movimientos — un `Set` por día en vez de un contador simple. |

El resto de los 44 puntos de esta segunda auditoría son correctamente de fase backend (SupplyNode/UnitShell, Lot/StockPosition, Procurement vs. Supply vs. Account, reserva/tránsito, etc.) — no aplican al prototipo React todavía, coincide con el criterio ya establecido en la Parte 14.5 de no mezclar eso con el trabajo de hoy.

### 16.2 Balances (#9 Farmacia / #16 Bodega) — implementado

Siguiendo exactamente el escaneo de la Parte 13.5 (qué es calculable con datos reales hoy) y la lección de "MetricDefinition" de esta segunda auditoría (fuente, fórmula y unidad de conteo explícitas para cada métrica — directamente motivada por el propio hallazgo #35 de arriba):

- **Por sub-unidad** (`fbCalcularBalanceSubUnidades`): total de solicitudes, atendidas, pendientes, tasa de rechazo, tiempo promedio de despacho (desde `fechaSolicitud` hasta el movimiento real `despacho-unidad` en Trazabilidad de esa misma solicitud) y consumo total — etiquetado "total", no "mensual", porque el prototipo no tiene corte por mes en ningún lado todavía.
- **Por proveedor** (`fbCalcularBalancePorProveedor`): total de pedidos, tasa de entrega completa y tasa de cumplimiento de plazo — **corrige de paso el hallazgo #8 de la primera auditoría** (Parte 14, no listado ahí como corregido): antes de esto, nada en el código acumulaba correctamente una Orden de Compra recibida en varias Recepciones parciales; ahora `fbCalcularBalancePorProveedor` suma TODAS las recepciones vinculadas a un mismo `ordenCompraFolio`, no solo la última.
- **Tiempo de respuesta de proveedor**: queda en "—", documentado en la propia UI — el Pedido no guarda cuándo el proveedor confirmó (ya anotado en la Parte 13.5, sin cambios).
- Ambas pestañas (`balances_farm`/`balances_bod`) ya no muestran "Próximamente" — `built: true` en `FB_FARMACIA_SUBMODULOS`/`FB_BODEGA_SUBMODULOS`.

**Verificación antes de entregar:** `esbuild` sin errores, llaves/paréntesis/corchetes balanceados, sin declaraciones duplicadas. Simulación en Node.js de ambas funciones: `fbCalcularBalanceSubUnidades` con una unidad sin solicitudes (queda excluida, no aparece como fila vacía) y otra con 3 solicitudes de distinto estado (conteos, tasa de rechazo y tiempo de despacho verificados contra el resultado esperado a mano); `fbCalcularBalancePorProveedor` con una Orden de Compra recibida en 2 recepciones parciales (40 + 60 de 100) — confirma que acumula a 100% de entrega completa, a diferencia de mirar solo la última recepción (que habría dado 60%).

### 16.2.1 Limitación conocida, encontrada en la revisión final de este export — PROPIA fuera de Balances

`FbBalancesView` de Bodega recibe `unidades={FB_UNIDADES_SUBBODEGA}` y `solicitudes={solicitudesBod}` — ninguno de los dos incluye a "PROPIA" (#25, Insumos Propios), cuyas solicitudes viven en `solicitudesPropia`, una lista separada. Resultado: Balances no muestra ninguna fila para PROPIA. No es un bug nuevo introducido ahora — es consistente con que el modelo original (`arquitectura_farmacia_bodega.md`, #19 "Balances Unidades") solo contempla las 41 unidades reales, no la unidad interna. Queda documentado, no corregido en esta vuelta — si se prefiere que PROPIA también aparezca en Balances Bodega, es un cambio acotado (usar `FB_UNIDADES_SUBBODEGA_MAS_PROPIA` y combinar `solicitudesBod`+`solicitudesPropia`, mismo patrón ya usado para las pestañas de Stock/Solicitudes en la Parte 10.3).

### 16.3 Nota operativa — el entorno de cómputo se reinició a mitad de esta tarea

Tal como anticipa la Parte 3 del dossier ("el entorno es efímero... si se reinicia a mitad de una tarea, se recuperan desde ahí [`/mnt/user-data/outputs/`] antes de seguir editando"): el contenedor se reinició después de terminar la separación de `lotes` pero antes de guardar ese avance en `outputs/`, perdiendo ese cambio y el fix del gráfico semanal. Se recuperó el último archivo guardado en `outputs/` (que sí tenía la Parte 15 completa) y se rehicieron ambos cambios desde ahí, sin pérdida real una vez identificado — ya quedaron guardados checkpoints intermedios en `outputs/` durante el resto de esta sesión para reducir este riesgo a futuro (mismo criterio que ya se había anotado en la Parte 12, nota operativa, la primera vez que pasó esto).

**Archivo actualizado:** `HISClinico_Layer1.jsx` (mismo archivo).

---

---

## PARTE 17 · Correcciones quirúrgicas de la segunda auditoría — implementado (26-10-2026)

Paso 1 del orden propuesto tras releer el dossier; aprobado por el usuario. Cambios en `HISClinico_Layer1.jsx`, sin tocar la máquina de estados:

| # | Hallazgo (Auditoria_SupplyCore2) | Corrección |
|---|---|---|
| 8 | `crearDespacho()` (Clientes Externos) descontaba `Math.min(cantidad, stock)` pero registraba `it.cantidad` en Trazabilidad y en el despacho. | Se calcula la cantidad aplicada por ítem; stock, despacho y movimiento usan ese mismo valor. |
| 4 (despacho) | Un despacho de 30 sobre 100 solicitados quedaba como "despachada" igual que uno completo. | Flag `despachoParcial` + badge "Despacho parcial". **No se agregó estado nuevo**: separar `PARTIALLY_FULFILLED/FULFILLED` queda como contrato de backend. |
| 12 | `confirmarRecepcion()` aceptaba más de lo despachado sin marcarlo. | Campo `discrepancia` (`excedente` / `faltante` / null), badge en la tarjeta, prefijo `[EXCEDENTE]`/`[FALTANTE]` en la observación del movimiento, y **observación obligatoria** si hay excedente. El stock sigue subiendo por lo físicamente recibido (decisión: recepción provisional con discrepancia visible; si se prefiere bloquear, es cambio acotado). |
| 16.2.1 | PROPIA no aparecía en Balances Bodega. | `FbBalancesView` de Bodega usa `FB_UNIDADES_SUBBODEGA_MAS_PROPIA` y combina `solicitudesBod` + `solicitudesPropia`. El "/41" del Dashboard no cambia. |

**Verificación:** `esbuild` sobre el archivo completo sin errores. No se ejecutó simulación en navegador.

**Sigue abierto (conversación de diseño, no se tocó):** recepción 1:N contra un pedido (hoy tras la primera recepción parcial el pedido queda en `recibido-parcial` y no ofrece "Registrar recepción", imposibilitando una segunda; además el handler compara solo la recepción actual contra el total) y, junto con ello, cuarentena, lote con existencia propia e inspección de devoluciones (Partes 14.2 #1/#4/#5).

---

## PARTE 18 · Propuesta de diseño — recepción 1:N, cuarentena, lote con existencia, devoluciones (26-10-2026)

**Estado: PROPUESTA, nada construido. Requiere tu confirmación (regla 3 del proyecto).** Cubre los hallazgos abiertos de las Partes 14.2 (#1, #4, #5) y 17. Principio: cambios mínimos sobre el modelo actual, sin adelantar el ledger ni `SupplyNode` de backend.

### 18.1 Recepción 1:N contra un pedido (el bloqueo más concreto hoy)
- Hoy: tras la primera recepción parcial el pedido queda en `recibido-parcial` y la UI no ofrece "Registrar recepción"; además se compara solo la recepción actual contra el total.
- Propuesta: el pedido guarda `recepcionFolios[]` (reemplaza `recepcionFolio`); el acumulado por línea = suma de `cantidadRecibida` de recepciones no rechazadas vinculadas. El formulario precarga **lo pendiente** (solicitado − acumulado). El botón "Registrar recepción" aparece en `en-transito` y `recibido-parcial`. Pasa a `recibido-total` cuando todas las líneas alcanzan lo solicitado.
- Cierre con faltante: acción manual "Cerrar pedido con faltante" con motivo obligatorio (el proveedor no entregará el resto). Queda en trazabilidad documental del pedido.
- Impacto: `fbCrearHandlersRecepcion.registrar`, `FbPedidoCard`, `FbNuevaRecepcionForm`. `fbCalcularBalancePorProveedor` ya acumula, no cambia.

### 18.2 Cuarentena (stock no disponible)
- Propuesta mínima: cada ítem de stock suma un campo `stockCuarentena`. `stockActual` sigue significando **disponible**, así que despacho, clamp, alertas, Balances y Dashboard no cambian.
- Entra a cuarentena en vez de a disponible: ítems de una recepción con embalaje dañado, cadena de frío no conforme, documentación incompleta o `cumpleEspecificaciones = false`. Una mera diferencia de cantidad facturada/recibida, con todo lo demás conforme, entra a disponible.
- Salida: nueva acción **Liberar** (pasa a disponible) o **Dar de baja / devolver a proveedor** (motivo obligatorio, sin excepción de rol, decisión #8). Cada una genera movimiento en Trazabilidad (`liberacion-cuarentena`, `baja-cuarentena`). Vive como pestaña "Cuarentena" por dominio, junto a Cuadratura.
- Devoluciones de Cliente Externo: en Farmacia entran **siempre** a cuarentena hasta inspección; en Bodega (no clínico) directo a disponible. Es la regla más discutible: confirmar.
- Quién libera: hoy solo existe el rol placeholder Farmacia/Bodega Central; en producción debería ser `t_farm_quimico` / coordinador (pendiente de roles reales).

### 18.3 Lote con existencia propia (el cambio más grande)
- Propuesta: el lote pasa a `{ id, itemId, numeroLote, fechaVencimiento, cantidadDisponible, cantidadCuarentena }` por dominio. Recepción crea/suma el lote con su cantidad. Despacho descuenta por **FEFO** (vence primero, sale primero). Cuadratura "vencimiento" precarga la cantidad del lote (cierra la limitación documentada en la Parte 15).
- Problema a resolver: el stock inicial de ejemplo no tiene lote. Propuesta: un lote técnico `SIN-LOTE` por ítem que absorbe stock sin lote identificado; invariante `Σ lotes = stock disponible + cuarentena`.
- Toca: `despachar`, Recepción, Cuadratura, Dashboard (caducidad) y Clientes Externos (campo lote hoy manual).

### 18.4 Orden sugerido
1. **18.1** (destraba un flujo hoy imposible, bajo riesgo).
2. **18.2** (cuarentena + devoluciones).
3. **18.3** (lotes + FEFO), recién después, porque se apoya en los dos anteriores.

### 18.5 Decisiones que necesito de ti
1. ¿Aceptas el orden 18.1 → 18.2 → 18.3, construyendo de a una y verificando cada una?
2. 18.1: ¿"Cerrar con faltante" manual está bien, o el pedido queda siempre abierto hasta completarse?
3. 18.2: ¿qué condiciones mandan a cuarentena (la lista de arriba)? ¿Devolución externa de Farmacia siempre a cuarentena?
4. 18.3: ¿FEFO automático al despachar, o el operador elige lote? ¿Te sirve el lote técnico `SIN-LOTE` para el stock legacy?
5. Pendiente de la Parte 17: ¿el excedente en recepción de unidad sigue subiendo stock con discrepancia visible, o se bloquea?

---

## PARTE 19 · Decisiones tomadas con las auditorías 3 y 4 + 18.1 implementado (26-10-2026)

**Fuentes absorbidas** (el usuario indicó confiar en su visión; sus contenidos accionables quedan aquí y ya no hace falta releerlos): `Auditoría del dossier DOSSIER SupplyCore.docx` (responde las 5 preguntas de la 18.5 y corrige 2 puntos del diseño) y `Auditoría técnica integral del jsx de Supply Core.docx` (revisión estática del JSX). Los archivos subidos quedan en la carpeta de uploads del chat (solo lectura, no pude borrarlos); no se copiaron a outputs.

### 19.1 Respuestas a la 18.5 (decididas)
1. **Orden 18.1 → 18.2 → 18.3: sí**, pero el contrato de 18.1 ya distingue cantidad recibida (física) / aceptada / en cuarentena / rechazada.
2. **Cerrar con faltante: sí**, manual, motivo obligatorio, sin tocar las recepciones previas. Describe cumplimiento comercial: no implica factura conciliada ni pagada.
3. **Cuarentena:** embalaje/envase dañado, cadena de frío no conforme, documentación sanitaria obligatoria incompleta, producto/lote/vencimiento que no coincide, especificaciones no cumplidas. Una diferencia facturado-vs-recibido con producto conforme **no** bloquea (es discrepancia comercial). **Devolución externa de Farmacia: siempre a cuarentena**; Bodega: inspección proporcional, política más simple. **Quién libera:** autorización contextual (actor + unidad + nodo + tipo de producto), no un rol fijo en el JSX; en Farmacia exige habilitación profesional.
4. **FEFO:** automático por defecto, selección manual autorizada con motivo, respetando lote exigido por una solicitud clínica. **No usar `SIN-LOTE` como lote real:** el stock heredado queda como *existencia heredada sin lote*, a reconciliar antes de exigir trazabilidad completa.
5. **Excedente en recepción de unidad: NO entra a stock disponible** (revierte lo decidido en la Parte 17). Se concilia contra lo despachado; el excedente queda como discrepancia pendiente. Un faltante queda vinculado al movimiento original, no desaparece.

### 19.2 Dos correcciones al diseño de la Parte 18
- **`stockActual` es campo transicional** (= disponible). El modelo destino es `StockPosition { onHand, available, reserved, quarantined, blocked, damaged, expired }`. En el prototipo se mantiene `stockActual` pero no se redefine silenciosamente.
- **El lote no es dueño de una cantidad global.** `Lot` (identidad: producto, número, vencimiento, referencias) se separa de `StockPosition` (nodo + lote + estado + cantidad), porque un mismo lote está a la vez en Central, subfarmacia, bodega y carro de paro. Esto reemplaza `cantidadDisponible/cantidadCuarentena` por lote de la 18.3.

### 19.3 Implementado ahora (`HISClinico_Layer1.jsx`; `esbuild` sin errores, sin prueba en navegador)
- **18.1 Recepción 1:N:** el pedido guarda `recibidoPorLinea` y `recepcionFolios[]` (reemplaza `recepcionFolio`); el cumplimiento se calcula **por línea**. "Registrar recepción" aparece también en `recibido-parcial` ("Registrar otra recepción (saldo)") y el formulario precarga solo lo **pendiente**. Nuevo estado `cerrado-con-faltante` con motivo, faltante por línea y fecha. Cada línea de recepción lleva `cantidadAceptada`, `cantidadCuarentena` (0 hasta 18.2) y `cantidadRechazada`; el stock sube por la aceptada.
- **Excedente en unidad:** el stock de la unidad sube solo por `min(recibido, despachado)`; `cantidadConciliada` y `cantidadExcedente` quedan en la línea; el movimiento de Trazabilidad registra lo conciliado y la observación `[EXCEDENTE n sin ingresar a stock]`.
- **Balances por proveedor:** cumplimiento por línea, no por total global (auditoría integral 2.7).
- **FHIR:** el módulo declara `Medication, SupplyRequest, SupplyDelivery` (R4); se retira `InventoryReport` (es R5) y `MedicationRequest` (era prescripción clínica, no reposición). **Pendiente de revisar:** otros módulos del shell etiquetan `InventoryReport` en sus submódulos "Gestión Bodega", y `med_traslados` usa `Transport` (R5); no se tocaron por ser de otros equipos.
- **Falta en 18.1:** registrar quién cierra con faltante (la vista de proveedores no recibe el rol) y documento de respaldo del cierre.

### 19.4 Pendiente — siguiente en orden
1. **18.2 Cuarentena e inspección** con las reglas de 19.1 (ítem 3), movimientos `liberacion-cuarentena` / `baja-cuarentena` y devoluciones externas a cuarentena en Farmacia.
2. **18.3 Lote + posición de stock + FEFO** según 19.2 y 19.1 (ítem 4).
3. **Hallazgos de la auditoría integral aún sin corregir:**
   - Devolución externa parcial no acumulativa: tras la primera queda `devuelto-parcial` y no se puede registrar otra; no conserva lote.
   - `ClientesExternosView` guarda sus datos en estado local: al navegar a otra sección se pierden clientes y despachos (elevar estado al padre).
   - Despacho de solicitud con cantidad total cero debería rechazarse.
   - Los checks de inspección de recepción parten en "conforme"; deberían partir sin marcar.
   - `consumoTotal` de Balances mide abastecimiento, no consumo; renombrar.
   - Prefijo de folio (`SOLP-`) decide el handler: debe derivarse de la entidad.
4. **Contrato Supply–Procurement–Account Core–UnitShell** (en paralelo, solo diseño): `ProcurementRequest` multiítem con `lineId`, `SupplyBinding` entre unidad y nodo, `FinancialEvent` idempotente; `recibirRequisicion()` queda como adaptador transicional. Base FHIR objetivo: R4 4.0.1 + Chile Core 1.9.3 + guía MINSAL 0.2.0 (fijar versiones al integrar). "Acceso a Red Interna de Farmacia/Bodega" se trata como entitlement/monetización en Account Core, no como movimiento físico.

---

## PARTE 20 · 18.2 Cuarentena e inspección — implementado (27-10-2026)

Sigue las reglas de 19.1 (ítem 3). `esbuild` sin errores; **no probado en navegador**.

- **Modelo:** cada ítem de stock central suma `stockCuarentena`; `stockActual` sigue siendo el disponible (campo transicional, 19.2), así que despacho, alertas, Balances y Dashboard no cambian. Stock Central (#2/#11) muestra la columna "En cuarentena".
- **Recepción:** si embalaje, documentación o cadena de frío no son conformes (afectan toda la entrega) o el ítem no cumple especificaciones, lo recibido entra a cuarentena (`cantidadCuarentena`), no a disponible. Una diferencia facturado-vs-recibido con producto conforme **no** retiene. *Limitación:* la retención es por ítem completo; aún no se puede retener solo "las unidades afectadas".
- **Nueva pestaña Cuarentena** (Farmacia y Bodega): por ítem, **Liberar a disponible** o **Dar de baja / devolver**, con motivo obligatorio y sin excepción de rol. Genera movimientos `liberacion-cuarentena` / `baja-cuarentena`; el ingreso genera `ingreso-cuarentena`. En estos movimientos `stockResultante` es el stock disponible. Quién puede liberar queda abierto hasta tener roles reales (hoy cualquier rol del prototipo).
- **Devoluciones de Clientes Externos:** en Farmacia van **siempre** a cuarentena; en Bodega, directo a disponible. Además ahora son **acumulativas**: se puede registrar una segunda devolución mientras quede saldo (topada al pendiente por ítem), el estado se calcula con el acumulado y el movimiento conserva el lote. (Cierra un hallazgo de la auditoría integral, 19.4 ítem 3.)
- Arreglo menor: las pestañas sin número canónico (Cuadratura, Cuarentena) ya no muestran "#null".

**Sigue pendiente:** 18.3 (lote + posición de stock + FEFO, existencia heredada sin lote); retención parcial por unidades; el resto de la lista de 19.4 ítem 3 (Clientes Externos pierde datos al navegar, rechazar despacho con cantidad cero, checks de inspección que parten marcados, renombrar `consumoTotal`, prefijo de folio); registrar quién cierra con faltante (18.1); contrato Supply–Procurement–Account Core–UnitShell.

---

## PARTE 21 · Correcciones chicas de la auditoría integral — cerradas (27-10-2026)

`esbuild` sin errores; **no probado en navegador** (conviene probar en especial el formulario de recepción, que cambió de comportamiento).

| Hallazgo | Corrección |
|---|---|
| Clientes Externos perdía clientes, despachos y folios al navegar a otra sección | El estado se elevó a `FarmaciaBodegaView` (`clientesExt`, `despachosExt` y sus correlativos). |
| Se podía confirmar un despacho con todo en cero | Botón deshabilitado y guarda en `despachar()`: si no sale nada, no cambia estado ni stock. |
| Los checks de inspección de recepción partían en "conforme" | Ahora son selectores `Sin verificar / Conforme / No conforme`, sin valor por defecto; **aceptar** una recepción exige registrarlos (rechazar no). La tarjeta muestra "sin verificar" si corresponde. |
| `consumoTotal` de Balances medía abastecimiento, no consumo | Renombrado `abastecidoTotal`, columna "Abastecido total". El consumo real queda para cuando existan eventos de consumo/dispensación. |
| El prefijo del folio (`SOLP-`) decidía el handler | Se deriva de la entidad: `esPropia(folio)` busca la solicitud en la lista de PROPIA. |
| El cierre con faltante no registraba quién lo hizo | Guarda `cerradoPor` (rol; pasará a CUT/actor real), documento de respaldo opcional y los muestra en la tarjeta del pedido. |

**Sigue abierto:** 18.3 (lote + posición de stock + FEFO + existencia heredada sin lote); retención parcial por unidades en recepción; contrato Supply–Procurement–Account Core–UnitShell; identidad real del actor (`role` sigue siendo placeholder); otros módulos del shell con recursos FHIR R5 (`InventoryReport`, `Transport`).

---

## PARTE 22 · 18.3 Lote, posición de stock y despacho por vencimiento (FEFO) — implementado (28-10-2026)

Aplica 19.1 ítem 4 y 19.2. Verificación: `esbuild` y `eslint no-undef` sin errores; los helpers se simularon en Node (FEFO, lotes vencidos, cuarentena, devolución). **No probado en navegador.**

**Modelo**
- **`Lot`** = identidad (`itemId`, `numeroLote`, `fechaVencimiento`), sin cantidad.
- **`StockPosition`** (nodo Central, por dominio: `posFarm`, `posBod`) = `{ itemId, loteId | null, disponible, cuarentena }`. `loteId = null` es la **existencia heredada sin lote** (no es un lote ficticio).
- `stockActual` / `stockCuarentena` del stock central son ahora **derivados** de las posiciones (`fbSincronizarStock`) — siguen existiendo como campo transicional, nada más los escribe a mano.
- Stock de ejemplo: los 3 lotes de muestra reciben cantidades de ejemplo (`FB_LOTE_CANTIDADES_INICIAL`: 30 / 10 / 100), recortadas del stock inicial; el resto es existencia heredada. Los lotes L-1 y L-2 **ya están vencidos** hoy, a propósito, para ver que no se despachan.

**Comportamiento**
- **Despacho de solicitudes y a Clientes Externos:** consume por **FEFO** (vence antes, sale antes; existencia sin lote al final) y **nunca despacha lotes vencidos**. Los formularios ven el stock *despachable* (sin vencidos). Se genera un movimiento de Trazabilidad **por lote asignado**; el lote ya no se digita (campo "Auto (FEFO)").
- **Recepción:** reutiliza el lote existente (mismo ítem y número) o crea uno si hay número **y** vencimiento; sin eso entra a existencia sin lote. Cuarentena y disponible se registran por lote.
- **Cuarentena:** la pestaña ahora lista **por lote**; liberar/dar de baja actúa sobre esa posición.
- **Devolución externa:** vuelve a los lotes de los que salió (a cuarentena en Farmacia).
- **Cuadratura:** vencimiento retira del lote elegido (cantidad topada a lo que hay en el lote, y se precarga); merma y diferencia de conteo bajan por FEFO sobre todo el disponible; una diferencia positiva entra a existencia sin lote.
- **Dashboard:** las alertas de caducidad solo consideran lotes con existencia y muestran la cantidad. Stock Central muestra el desglose por lote y marca "VENCIDO, no despachable".

**Limitaciones conocidas / decisiones abiertas**
- Sub-farmacias y sub-bodegas siguen con stock **agregado**, sin lote (solo el nodo Central tiene posiciones). El lote viaja en el movimiento y en la línea del despacho.
- `stockActual` (disponible) **incluye** lotes vencidos hasta que se den de baja por Cuadratura/vencimiento; la alerta "bajo mínimo" del Dashboard lo usa tal cual. Decidir si el mínimo debe medirse sobre el despachable.
- **Selección manual de lote** (excepción autorizada con motivo, 19.1 ítem 4) y lote exigido por una solicitud clínica: **no implementados**; hoy FEFO es siempre automático.
- La devolución se reparte entre los lotes del despacho en orden, sin llevar cuenta por lote de lo ya devuelto.
- Sin reserva ni tránsito (`reserved`, `inTransit`) ni reconciliación de la existencia heredada.

**Con esto la Parte 18 queda completa (18.1, 18.2, 18.3).** Siguiente en la lista: selección manual de lote con motivo; contrato Supply–Procurement–Account Core–UnitShell (solo diseño); identidad real del actor; recursos FHIR R5 en otros módulos del shell; revisar si el mínimo de stock debe medirse sobre lo despachable.

---

## PARTE 23 · Selección manual de lote (implementado) + plan del contrato entre dominios (propuesta) — 29-10-2026

### 23.1 Selección manual de lote — implementada
Cierra la excepción autorizada a FEFO de 19.1 ítem 4. `esbuild` y `eslint no-undef` sin errores; helpers simulados en Node; **no probado en navegador**.
- **Dónde:** panel "Preparar despacho" de las solicitudes y formulario de despacho a Clientes Externos. Por ítem aparece un selector "Automático (vence primero)" o un lote concreto; solo ofrece **lotes vigentes con existencia** (los vencidos no se pueden elegir).
- **Regla:** elegir un lote a mano exige **motivo** (botón deshabilitado sin él), y la cantidad queda topada a lo que hay en ese lote. Se consume solo de ese lote; si el lote no alcanza, no completa con otros.
- **Trazabilidad:** la línea guarda `excepcionLote { loteId, motivo, por }`, el movimiento lleva la observación `[LOTE MANUAL] motivo`, y la tarjeta de la solicitud marca "(lote manual)". Hoy `por` es el rol (placeholder de identidad).
- **No implementado:** lote exigido por una solicitud clínica (no existe todavía el consumidor, Hospitalización/Urgencias) ni autorización por contexto de *quién* puede hacer la excepción (depende de roles reales). En Bodega el selector casi no aparece porque no hay lotes cargados.

### 23.2 Plan para el contrato Supply–Procurement–Account Core–UnitShell (PROPUESTA, solo diseño, nada de código)
Objetivo: un documento único que los 3 equipos puedan firmar, construido **desde lo que el prototipo ya hace**, no desde cero. Entregable: `AXON_SUPPLY_CONTRATO_ENTRE_DOMINIOS.md`.
1. **Inventario honesto** (existente / documentado / placeholder / gap) de cada objeto y estado del JSX: solicitud, pedido, recepción, posición de stock, lote, movimiento, devolución, cuarentena, cuadratura.
2. **Tabla de propiedad de datos** por dominio (UnitShell, Supply, Procurement, Account Core, Identity, Interoperabilidad): quién crea, quién lee, quién nunca escribe.
3. **Entidades canónicas con IDs estables:** `SupplyRequest`, `ProcurementRequest` multiítem con `lineId`, referencia a `PurchaseOrder`, `Receipt` con líneas (recibida / aceptada / cuarentena / rechazada), `StockPosition`, `SupplyEvent` (sobre-evento derivado de los campos de `fbCrearMovimiento` + tenant, actor, versión, correlación), `SupplyBinding`.
4. **Máquinas de estado separadas por dimensión** (compra, recepción, inventario, factura, presupuesto, contabilidad), nunca un único `estado`.
5. **Tabla SupplyEvent → ¿FinancialEvent?:** para cada tipo de movimiento que ya existe (`ingreso-proveedor`, `ingreso-cuarentena`, `baja-cuarentena`, `merma`, `vencimiento`, `diferencia-conteo`, `despacho-cliente-externo` por tipo de operación, etc.) decir si genera consecuencia económica, cuál, y qué dato mínimo debe viajar. Los traslados internos no generan evento financiero.
6. **Reglas transversales:** idempotencia (`sourceSystem`, `sourceEventId`, `eventVersion`), correlación/causalidad, versionado, outbox, identidad real del actor (CUT) en vez de `role`.
7. **Mapeo FHIR R4** (SupplyRequest por línea, SupplyDelivery, Medication/Chile Core) y lo que no tiene representación directa (saldos por lote, cuarentena).
8. **Preguntas abiertas por equipo** (Account Core, UnitShell, Procurement, Identity), y **adaptador transicional** `recibirRequisicion()` hasta que exista el contrato real.
Método: contrastar cada punto contra los documentos oficiales de cada equipo (FinancialEvent de Account Core, metamodelo de UnitShell) y contra el código real; lo que no se pueda confirmar se marca como **pendiente**, no se inventa.
**Decisiones que necesito antes de escribirlo:** (a) ¿Procurement es una capability aparte o vive dentro de Adquisiciones de Contabilidad? (b) ¿Quién será dueño de `SupplyBinding`: Supply (propuesta de las auditorías) o UnitShell? (c) ¿Tienes el documento actual del contrato `FinancialEvent` de Account Core para contrastar campo a campo?

**Sigue pendiente además:** decidir si el stock mínimo se mide sobre lo despachable (hoy incluye lotes vencidos); lotes en sub-unidades; identidad real del actor; recursos FHIR R5 en otros módulos del shell.

---

## PARTE 24 · Decisiones adoptadas + stock mínimo + contrato entre dominios v0.1 (29-10-2026)

**Fuente absorbida:** `respuestas_para_equipo_supply_20-10-2026.docx` (respuestas a las 3 preguntas de la Parte 23.2, la decisión del stock mínimo y el contexto de las matrices A–I de UnitShell). No pude borrarlo del chat (uploads es de solo lectura); su contenido accionable queda aquí.

**Decisiones adoptadas**
1. **Procurement es un dominio/capability independiente**; su interfaz puede seguir en `ContabilidadAdquisiciones.jsx` por ahora. `recibirRequisicion()` queda como adaptador transitorio.
2. **UnitShell es dueño de `OrgNode`; Supply Core es dueño de `SupplyNode` y `SupplyBinding`** (consume los IDs de UnitShell, no duplica su árbol; referencias validadas por Tenant).
3. **`FinancialEvent` de Account Core se usa como baseline**, no como contrato firmado; Supply no modifica reglas de contabilización. Idempotencia: `sourceSystem + sourceEventId + eventVersion`.
4. **Stock mínimo sobre lo despachable** (sin vencido, cuarentena, bloqueado, dañado, reservado); el stock físico sigue visible; `stockActual` queda como compatibilidad transitoria.
5. **Contexto A–I:** el contrato es un documento técnico **derivado y alineado** con las matrices A–I de UnitShell, no otra matriz ni fuente de verdad paralela.

**Implementado ahora (`HISClinico_Layer1.jsx`; `esbuild` y `eslint no-undef` sin errores; no probado en navegador)**
- Dashboard (ítems bajo mínimo, unidades con alerta) y Stock Central (estado Ok / Bajo mínimo / Crítico) usan el stock **despachable**. Stock Central muestra "despachable N" cuando difiere del disponible (p. ej. por lotes vencidos).
- Alcance: solo el nodo Central. Las sub-unidades no tienen lotes ni cuarentena, así que su stock mínimo sigue como antes.

**Escrito ahora:** `AXON_SUPPLY_CONTRATO_ENTRE_DOMINIOS.md` v0.1 (solo diseño): decisiones, inventario honesto del prototipo (existente / placeholder / gap), propiedad de datos, entidades e IDs, estados por dimensión, sobre `SupplyEvent`, tabla SupplyEvent → ¿FinancialEvent?, reglas transversales, mapeo FHIR R4, preguntas abiertas por equipo, adaptadores y criterios de aceptación. Todo lo no respaldado por código o por contrato vigente está marcado `PROPUESTA` o `ABIERTO`.

**Pendiente**
- Validación del contrato por cada equipo: Account Core (campos y tabla §7), Procurement, UnitShell, Identity.
- Contrastar el `SupplyEvent` campo a campo contra el `FinancialEvent` vigente cuando Account Core confirme su versión.
- Respuesta a las preguntas abiertas de §10 del contrato (reservas/tránsito, lotes en sub-unidades, actor real, perfil FHIR para saldos).
- Revisar recursos FHIR R5 en otros módulos del shell.

*Fin del dossier. Cualquier sesión nueva debería poder continuar leyendo solo este archivo + `arquitectura_farmacia_bodega.md` + `sincronizacion_farmacia_bodega_main.md` + `HISClinico_Layer1.jsx`. `VISION_SUPPLY_CORE_FUTURO.md` y `AXON_SUPPLY_CORE_CIMIENTOS_ARQUITECTURA.md` importan solo cuando el trabajo del día toque la evolución a Supply Core. `Auditoria_SupplyCore.docx`, `Auditoria_SupplyCore2.md`, los documentos de Contabilidad y los de Hospitalización son contexto adicional — lo accionable de ambas auditorías ya quedó absorbido en las Partes 14 y 16; no hace falta releer ninguno de estos para continuar el trabajo día a día sobre los submódulos.*
